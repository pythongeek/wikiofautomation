<?php
/**
 * Admin Controller - registers menus, settings, AJAX X-Ray, Answer-Gap & Sandbox handlers.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WebMCP_Gateway_Admin' ) ) {
	/**
	 * Coordinates the wp-admin interface for WebMCP Gateway.
	 */
	final class WebMCP_Gateway_Admin {

		/**
		 * Register admin hooks.
		 *
		 * @return void
		 */
		public static function init() {
			WebMCP_Gateway_Loader::register_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
			WebMCP_Gateway_Loader::register_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
			WebMCP_Gateway_Loader::register_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
			WebMCP_Gateway_Loader::register_action( 'wp_ajax_webmcp_gateway_run_sandbox_tool', array( __CLASS__, 'ajax_run_sandbox_tool' ) );
			WebMCP_Gateway_Loader::register_action( 'wp_ajax_webmcp_gateway_preview_markdown', array( __CLASS__, 'ajax_preview_markdown' ) );
			WebMCP_Gateway_Loader::register_action( 'wp_ajax_webmcp_gateway_run_xray_audit', array( __CLASS__, 'ajax_run_xray_audit' ) );
			WebMCP_Gateway_Loader::register_action( 'wp_ajax_webmcp_gateway_inject_answer_gaps', array( __CLASS__, 'ajax_inject_answer_gaps' ) );
			WebMCP_Gateway_Loader::register_action( 'wp_ajax_webmcp_gateway_inspect_endpoint', array( __CLASS__, 'ajax_inspect_endpoint' ) );
			WebMCP_Gateway_Loader::register_action( 'wp_ajax_webmcp_gateway_clear_activity_log', array( __CLASS__, 'ajax_clear_activity_log' ) );
			WebMCP_Gateway_Loader::register_action( 'wp_ajax_webmcp_gateway_get_activity', array( __CLASS__, 'ajax_get_activity' ) );
			WebMCP_Gateway_Loader::register_action( 'wp_ajax_webmcp_gateway_search_posts', array( __CLASS__, 'ajax_search_posts' ) );
			// Agent audit / Cloudflare AJAX hooks are registered in WebMCP_Gateway_Agent_Audit::init().
			WebMCP_Gateway_Loader::register_action( 'wp_ajax_webmcp_gateway_get_exec_token', array( __CLASS__, 'ajax_get_exec_token' ) );
			WebMCP_Gateway_Loader::register_action( 'wp_ajax_webmcp_gateway_validate_schema', array( __CLASS__, 'ajax_validate_schema' ) );
			WebMCP_Gateway_Loader::register_action( 'wp_ajax_webmcp_gateway_generate_api_key', array( __CLASS__, 'ajax_generate_api_key' ) );
			WebMCP_Gateway_Loader::register_action( 'wp_ajax_webmcp_gateway_revoke_api_key', array( __CLASS__, 'ajax_revoke_api_key' ) );
			WebMCP_Gateway_Loader::register_filter( 'plugin_action_links_' . WEBMCP_CORE_BASENAME, array( __CLASS__, 'add_plugin_action_links' ) );
		}

		/**
		 * Add top-level admin menu.
		 *
		 * @return void
		 */
		public static function add_menu() {
			add_menu_page(
				__( 'WebMCP Gateway', 'webmcp-gateway' ),
				__( 'WebMCP Gateway', 'webmcp-gateway' ),
				'manage_options',
				'webmcp-gateway',
				array( __CLASS__, 'render_admin_page' ),
				'dashicons-rest-api',
				65
			);
		}

		/**
		 * Add quick links on the Plugins list screen.
		 *
		 * @param mixed $links Existing plugin action links.
		 * @return array
		 */
		public static function add_plugin_action_links( $links = array() ) {
			if ( ! is_array( $links ) ) {
				$links = array();
			}
			$xray_link     = sprintf(
				'<a href="%s">%s</a>',
				esc_url( admin_url( 'admin.php?page=webmcp-gateway&tab=xray' ) ),
				esc_html__( 'Page AEO X-Ray', 'webmcp-gateway' )
			);
			$sandbox_link  = sprintf(
				'<a href="%s">%s</a>',
				esc_url( admin_url( 'admin.php?page=webmcp-gateway&tab=sandbox' ) ),
				esc_html__( 'Agent Sandbox', 'webmcp-gateway' )
			);
			$settings_link = sprintf(
				'<a href="%s">%s</a>',
				esc_url( admin_url( 'admin.php?page=webmcp-gateway&tab=schema' ) ),
				esc_html__( 'Settings', 'webmcp-gateway' )
			);
			array_unshift( $links, $xray_link, $sandbox_link, $settings_link );
			return $links;
		}

		/**
		 * Register all plugin settings with explicit sanitization callbacks.
		 *
		 * @return void
		 */
		public static function register_settings() {
			$bool_settings = array(
				'webmcp_gateway_enabled',
				'webmcp_gateway_schema_enabled',
				'webmcp_gateway_speakable_enabled',
				'webmcp_gateway_auto_faq_enabled',
				'webmcp_gateway_woo_schema_on',
				'webmcp_gateway_markdown_enabled',
				'webmcp_gateway_llmstxt_enabled',
				'webmcp_gateway_llmsfull_enabled',
				'webmcp_gateway_robots_enabled',
				'webmcp_gateway_activity_log_on',
			);

			foreach ( $bool_settings as $opt ) {
				register_setting(
					'webmcp_gateway_settings',
					$opt,
					array(
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
						'default'           => 1,
					)
				);
			}

			// Frontend widgets default to OFF until the site owner opts in.
			foreach ( array( 'webmcp_gateway_ai_summary_render', 'webmcp_gateway_cite_bar_render' ) as $opt ) {
				register_setting(
					'webmcp_gateway_settings',
					$opt,
					array(
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
						'default'           => 0,
					)
				);
			}

			$bot_keys = array(
				'webmcp_gateway_bot_oai_search',
				'webmcp_gateway_bot_chatgpt_user',
				'webmcp_gateway_bot_perplexity',
				'webmcp_gateway_bot_claude',
				'webmcp_gateway_bot_google_ext',
				'webmcp_gateway_bot_gptbot',
				'webmcp_gateway_bot_ccbot',
			);

			foreach ( $bot_keys as $bot_key ) {
				register_setting(
					'webmcp_gateway_settings',
					$bot_key,
					array(
						'type'              => 'string',
						'sanitize_callback' => array( __CLASS__, 'sanitize_bot_rule' ),
						'default'           => 'allow',
					)
				);
			}

			register_setting(
				'webmcp_gateway_settings',
				'webmcp_gateway_rate_limit',
				array(
					'type'              => 'integer',
					'sanitize_callback' => array( __CLASS__, 'sanitize_rate_limit' ),
					'default'           => 60,
				)
			);

			register_setting(
				'webmcp_gateway_settings',
				'webmcp_gateway_entity_type',
				array(
					'type'              => 'string',
					'sanitize_callback' => array( __CLASS__, 'sanitize_entity_type' ),
					'default'           => 'Organization',
				)
			);

			register_setting(
				'webmcp_gateway_settings',
				'webmcp_gateway_entity_name',
				array(
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
					'default'           => '',
				)
			);

			register_setting(
				'webmcp_gateway_settings',
				'webmcp_gateway_logo_url',
				array(
					'type'              => 'string',
					'sanitize_callback' => array( __CLASS__, 'sanitize_http_url' ),
					'default'           => '',
				)
			);

			register_setting(
				'webmcp_gateway_settings',
				'webmcp_gateway_same_as',
				array(
					'type'              => 'string',
					'sanitize_callback' => array( __CLASS__, 'sanitize_url_list' ),
					'default'           => '',
				)
			);

			register_setting(
				'webmcp_gateway_settings',
				'webmcp_gateway_speakable_css',
				array(
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
					'default'           => 'h1.entry-title, .entry-title, .entry-content > p:first-of-type, .wp-block-post-content > p:first-of-type, .webmcp-ai-summary',
				)
			);

			register_setting(
				'webmcp_gateway_settings',
				'webmcp_gateway_default_schema',
				array(
					'type'              => 'string',
					'sanitize_callback' => array( __CLASS__, 'sanitize_default_schema' ),
					'default'           => 'BlogPosting',
				)
			);

			register_setting(
				'webmcp_gateway_settings',
				'webmcp_gateway_ai_box_theme',
				array(
					'type'              => 'string',
					'sanitize_callback' => array( __CLASS__, 'sanitize_ai_box_theme' ),
					'default'           => 'auto',
				)
			);

			register_setting(
				'webmcp_gateway_settings',
				'webmcp_gateway_content_signal',
				array(
					'type'              => 'string',
					'sanitize_callback' => array( __CLASS__, 'sanitize_content_signal' ),
					'default'           => 'allow_all',
				)
			);

			register_setting(
				'webmcp_gateway_settings',
				'webmcp_gateway_cloudflare_scan',
				array(
					'type'              => 'integer',
					'sanitize_callback' => 'absint',
					'default'           => 0,
				)
			);

			// MCP REST API access control (Issue 1): optional API-key requirement, default OFF.
			register_setting(
				'webmcp_gateway_settings',
				'webmcp_gateway_require_api_key',
				array(
					'type'              => 'integer',
					'sanitize_callback' => 'absint',
					'default'           => 0,
				)
			);
		}

		/**
		 * Sanitize the Content Signals policy choice.
		 *
		 * @param mixed $val Raw input.
		 * @return string
		 */
		public static function sanitize_content_signal( $val ) {
			$clean   = sanitize_key( (string) $val );
			$allowed = array( 'off', 'allow_all', 'no_training', 'search_only', 'block_all' );
			return in_array( $clean, $allowed, true ) ? $clean : 'allow_all';
		}

		/**
		 * Sanitize a single URL, allowing only http(s) schemes.
		 *
		 * Blocks file://, phar://, javascript:, and other non-HTTP schemes at
		 * save time; anything disallowed becomes an empty string.
		 *
		 * @param mixed $val Raw input.
		 * @return string
		 */
		public static function sanitize_http_url( $val ) {
			$url = esc_url_raw( trim( (string) $val ) );
			if ( '' === $url ) {
				return '';
			}
			$scheme = wp_parse_url( $url, PHP_URL_SCHEME );
			if ( ! in_array( strtolower( (string) $scheme ), array( 'http', 'https' ), true ) ) {
				return '';
			}
			return $url;
		}

		/**
		 * Sanitize a newline/comma-separated URL list, keeping only http(s) URLs.
		 *
		 * @param mixed $val Raw input.
		 * @return string
		 */
		public static function sanitize_url_list( $val ) {
			$parts = preg_split( '/[\r\n,]+/', (string) $val );
			$keep  = array();
			if ( is_array( $parts ) ) {
				foreach ( $parts as $part ) {
					$url = self::sanitize_http_url( $part );
					if ( '' !== $url ) {
						$keep[] = $url;
					}
				}
			}
			return implode( "\n", $keep );
		}

		/**
		 * Resolve a stable asset version (file mtime, falling back to the plugin version).
		 *
		 * @param string $relative_path Path relative to the plugin folder.
		 * @return string
		 */
		private static function asset_version( $relative_path ) {
			$mtime = filemtime( WEBMCP_CORE_PATH . $relative_path );
			return $mtime ? (string) $mtime : WEBMCP_CORE_VERSION;
		}

		/**
		 * Sanitize per-bot rule (allow or disallow).
		 *
		 * @param mixed $val Raw input.
		 * @return string
		 */
		public static function sanitize_bot_rule( $val ) {
			$clean = sanitize_key( (string) $val );
			return 'disallow' === $clean ? 'disallow' : 'allow';
		}

		/**
		 * Sanitize rate limit (10 to 600 requests/min).
		 *
		 * @param mixed $val Raw input.
		 * @return int
		 */
		public static function sanitize_rate_limit( $val ) {
			return min( 600, max( 10, absint( $val ) ) );
		}

		/**
		 * Sanitize Publisher Entity Type.
		 *
		 * @param mixed $val Raw input.
		 * @return string
		 */
		public static function sanitize_entity_type( $val ) {
			$clean = sanitize_text_field( (string) $val );
			return in_array( $clean, array( 'Organization', 'Person' ), true ) ? $clean : 'Organization';
		}

		/**
		 * Sanitize Default Article Schema Type.
		 *
		 * @param mixed $val Raw input.
		 * @return string
		 */
		public static function sanitize_default_schema( $val ) {
			$clean   = sanitize_text_field( (string) $val );
			$allowed = array( 'BlogPosting', 'Article', 'NewsArticle', 'TechArticle' );
			return in_array( $clean, $allowed, true ) ? $clean : 'BlogPosting';
		}

		/**
		 * Sanitize the frontend AI box theme choice.
		 *
		 * @param mixed $val Raw input.
		 * @return string
		 */
		public static function sanitize_ai_box_theme( $val ) {
			$clean = sanitize_key( (string) $val );
			return in_array( $clean, array( 'light', 'dark', 'auto' ), true ) ? $clean : 'auto';
		}

		/**
		 * Enqueue admin CSS and JS strictly on WebMCP Gateway plugin and post-edit screens.
		 *
		 * @param mixed $hook Current admin screen hook suffix.
		 * @return void
		 */
		public static function enqueue_assets( $hook = '' ) {
			$hook        = (string) $hook;
			$is_app      = ( 'toplevel_page_webmcp-gateway' === $hook );
			$is_editor   = ( 'post.php' === $hook || 'post-new.php' === $hook );

			if ( ! $is_app && ! $is_editor ) {
				return;
			}

			wp_enqueue_style(
				'webmcp-gateway-admin',
				WEBMCP_CORE_URL . 'admin/css/webmcp-gateway-admin.css',
				array( 'dashicons' ),
				self::asset_version( 'admin/css/webmcp-gateway-admin.css' )
			);

			if ( $is_editor ) {
				wp_enqueue_style(
					'webmcp-gateway-metabox',
					WEBMCP_CORE_URL . 'admin/css/webmcp-gateway-metabox.css',
					array( 'webmcp-gateway-admin' ),
					self::asset_version( 'admin/css/webmcp-gateway-metabox.css' )
				);
				wp_enqueue_script(
					'webmcp-gateway-metabox',
					WEBMCP_CORE_URL . 'admin/js/webmcp-gateway-metabox.js',
					array(),
					self::asset_version( 'admin/js/webmcp-gateway-metabox.js' ),
					true
				);
				return;
			}

			wp_enqueue_script(
				'webmcp-gateway-admin',
				WEBMCP_CORE_URL . 'admin/js/webmcp-gateway-admin.js',
				array( 'jquery' ),
				self::asset_version( 'admin/js/webmcp-gateway-admin.js' ),
				true
			);

			wp_localize_script(
				'webmcp-gateway-admin',
				'WebMCPGatewayAdmin',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( 'webmcp_gateway_sandbox_nonce' ),
					'version' => WEBMCP_CORE_VERSION,
					'i18n'    => array(
						'no_activity'       => __( 'No AI activity yet', 'webmcp-gateway' ),
						'no_activity_hint'  => __( 'AI crawler and agent traffic appears here as it happens - every entry is a real request your server received.', 'webmcp-gateway' ),
						// translators: %d: Total recorded event count.
						'show_all_events'   => __( 'Show all %d events', 'webmcp-gateway' ),
						'revoke_confirm'    => __( 'Revoke this API key? Clients using it will immediately lose access.', 'webmcp-gateway' ),
						'key_label_needed'  => __( 'Enter a label for the new key first.', 'webmcp-gateway' ),
						'key_generated'     => __( 'API key generated — copied to clipboard. It will not be shown again; list refreshes in 8s.', 'webmcp-gateway' ),
						'key_revoked'       => __( 'API key revoked.', 'webmcp-gateway' ),
						'request_failed'    => __( 'Request failed.', 'webmcp-gateway' ),
						// translators: %s: Readiness level name from Cloudflare.
						'cf_verdict'        => __( 'Cloudflare verdict: %s', 'webmcp-gateway' ),
						'just_now'          => __( 'just now', 'webmcp-gateway' ),
						// translators: %d: Minutes since the event.
						'mins_ago'          => __( '%dm ago', 'webmcp-gateway' ),
						// translators: %d: Hours since the event.
						'hours_ago'         => __( '%dh ago', 'webmcp-gateway' ),
						// translators: %d: Days since the event.
						'days_ago'          => __( '%dd ago', 'webmcp-gateway' ),
					),
				)
			);
		}

		/**
		 * Render the WebMCP Gateway app shell (topbar + rail nav + active screen).
		 *
		 * @return void
		 */
		public static function render_admin_page() {
			if ( ! current_user_can( 'manage_options' ) ) {
				return;
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$active_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard';
			if ( ! in_array( $active_tab, array( 'dashboard', 'xray', 'sandbox', 'audit', 'schema' ), true ) ) {
				$active_tab = 'dashboard';
			}

			$screens = array(
				'dashboard' => array(
					'label'    => __( 'Overview', 'webmcp-gateway' ),
					'subtitle' => __( 'Live proof that your site is AI-ready: health score, agent activity, and endpoint previews.', 'webmcp-gateway' ),
				),
				'audit'     => array(
					'label'    => __( 'Agent Audit', 'webmcp-gateway' ),
					'subtitle' => __( 'Industry-standard agent-readiness audit — the same checks Cloudflare\'s isitagentready.com runs, scanned from your own server.', 'webmcp-gateway' ),
				),
				'xray'      => array(
					'label'    => __( 'X-Ray Scanner', 'webmcp-gateway' ),
					'subtitle' => __( 'See exactly what AI answer engines will quote from any page — and fix the gaps in one click.', 'webmcp-gateway' ),
				),
				'sandbox'   => array(
					'label'    => __( 'Agent Sandbox', 'webmcp-gateway' ),
					'subtitle' => __( 'Run any of the 6 MCP tools against your live site and inspect the exact JSON an agent receives.', 'webmcp-gateway' ),
				),
				'schema'    => array(
					'label'    => __( 'Settings', 'webmcp-gateway' ),
					'subtitle' => __( 'Control the schema engine, per-bot crawler policy, frontend widgets, and rate limits.', 'webmcp-gateway' ),
				),
			);

			$is_active = (bool) get_option( 'webmcp_gateway_enabled', 1 );
			?>
			<div class="wrap wm-app" data-wm-theme="light">
				<header class="wm-topbar">
					<div class="wm-topbar__brand">
						<button type="button" class="wm-nav-toggle" id="wm-nav-toggle" aria-expanded="false" aria-controls="wm-rail" aria-label="<?php esc_attr_e( 'Toggle navigation', 'webmcp-gateway' ); ?>">
							<span class="dashicons dashicons-menu-alt3" aria-hidden="true"></span>
						</button>
						<span class="wm-logo" aria-hidden="true">
							<svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
								<rect width="26" height="26" rx="7" fill="url(#wmLogoGrad)"/>
								<circle cx="8.4" cy="13" r="2.5" fill="#fff"/>
								<circle cx="17.6" cy="8.6" r="2.5" fill="#fff" fill-opacity="0.92"/>
								<circle cx="17.6" cy="17.4" r="2.5" fill="#fff" fill-opacity="0.92"/>
								<path d="M10.6 12.1L15.4 9.5M10.6 13.9L15.4 16.5" stroke="#fff" stroke-width="1.5" stroke-linecap="round"/>
								<defs>
									<linearGradient id="wmLogoGrad" x1="0" y1="0" x2="26" y2="26" gradientUnits="userSpaceOnUse">
										<stop stop-color="#6366F1"/>
										<stop offset="1" stop-color="#22D3EE"/>
									</linearGradient>
								</defs>
							</svg>
						</span>
						<div class="wm-topbar__title">
							<h1><?php esc_html_e( 'WebMCP Gateway', 'webmcp-gateway' ); ?></h1>
						</div>
						<span class="wm-status-pill <?php echo $is_active ? 'wm-status-pill--on' : 'wm-status-pill--off'; ?>">
							<span class="wm-status-pill__dot"></span>
							<?php echo esc_html( $is_active ? __( 'Gateway Active', 'webmcp-gateway' ) : __( 'Gateway Paused', 'webmcp-gateway' ) ); ?>
						</span>
					</div>
					<div class="wm-topbar__actions">
						<button type="button" class="wm-btn wm-btn--primary" id="wm-run-audit-top-btn">
							<span class="dashicons dashicons-shield"></span><span class="wm-btn__label"><?php esc_html_e( 'Run audit', 'webmcp-gateway' ); ?></span>
						</button>
						<a href="<?php echo esc_url( home_url( '/.well-known/mcp.json' ) ); ?>" target="_blank" rel="noopener noreferrer" class="wm-btn wm-btn--ghost">
							<span class="dashicons dashicons-external"></span><span class="wm-btn__label"><?php esc_html_e( 'Live MCP JSON', 'webmcp-gateway' ); ?></span>
						</a>
					</div>
				</header>

				<div class="wm-body">
					<nav class="wm-rail" id="wm-rail" aria-label="<?php esc_attr_e( 'WebMCP Gateway sections', 'webmcp-gateway' ); ?>">
						<?php foreach ( $screens as $slug => $meta ) : ?>
							<a class="wm-rail__item <?php echo $active_tab === $slug ? 'wm-rail__item--active' : ''; ?>"
								<?php echo $active_tab === $slug ? 'aria-current="page"' : ''; ?>
								href="<?php echo esc_url( admin_url( 'admin.php?page=webmcp-gateway&tab=' . $slug ) ); ?>">
								<span class="dashicons <?php echo esc_attr( self::rail_icon( $slug ) ); ?>"></span>
								<span><?php echo esc_html( $meta['label'] ); ?></span>
							</a>
						<?php endforeach; ?>
						<div class="wm-rail__footer">
							<span class="wm-rail__version"><?php echo esc_html( 'v' . WEBMCP_CORE_VERSION ); ?></span>
							<a href="<?php echo esc_url( 'https://webmcp-nexus.wikiofautomation.com/' ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Docs', 'webmcp-gateway' ); ?> ↗</a>
						</div>
					</nav>

					<main class="wm-content">
						<div class="wm-screen-head">
							<h2><?php echo esc_html( $screens[ $active_tab ]['label'] ); ?></h2>
							<p><?php echo esc_html( $screens[ $active_tab ]['subtitle'] ); ?></p>
						</div>

						<div class="wm-screen">
							<?php
							switch ( $active_tab ) {
								case 'xray':
									include __DIR__ . '/partials/view-xray.php';
									break;
								case 'sandbox':
									include __DIR__ . '/partials/view-sandbox.php';
									break;
								case 'audit':
									include __DIR__ . '/partials/view-audit.php';
									break;
								case 'schema':
									include __DIR__ . '/partials/view-schema.php';
									break;
								default:
									include __DIR__ . '/partials/view-dashboard.php';
									break;
							}
							?>
						</div>
					</main>
				</div>

				<div class="wm-toasts" id="wm-toasts" aria-live="polite"></div>
			</div>
			<?php
		}

		/**
		 * Dashicon class for each rail item.
		 *
		 * @param string $slug Tab slug.
		 * @return string
		 */
		private static function rail_icon( $slug ) {
			$icons = array(
				'dashboard' => 'dashicons-chart-line',
				'audit'     => 'dashicons-shield',
				'xray'      => 'dashicons-search',
				'sandbox'   => 'dashicons-editor-code',
				'schema'    => 'dashicons-admin-settings',
			);
			return isset( $icons[ $slug ] ) ? $icons[ $slug ] : 'dashicons-marker';
		}

		/**
		 * AJAX handler: Run any of the 6 MCP tools in the Admin Agent Sandbox.
		 *
		 * @return void
		 */
		/**
		 * Per-user fixed-window throttle for expensive AJAX handlers.
		 *
		 * Counters live in the options table using the same atomic window-naming
		 * scheme as the REST rate limiter: one INSERT ... ON DUPLICATE KEY UPDATE
		 * per call, shared across load-balanced web nodes and untouched by
		 * cache-plugin purges. Call AFTER nonce + capability checks.
		 *
		 * @param string $bucket Handler group identifier.
		 * @param int    $limit  Maximum calls per window per user.
		 * @param int    $window Window length in seconds.
		 * @return true|WP_Error
		 */
		public static function throttle_ajax( $bucket, $limit = 30, $window = MINUTE_IN_SECONDS ) {
			$user_id = get_current_user_id();
			if ( $user_id <= 0 ) {
				return true; // Anonymous callers are already rejected by the capability check.
			}

			$now          = time();
			$window_start = $now - ( $now % $window );
			$option_name  = 'webmcp_throttle_' . sanitize_key( $bucket ) . '_' . $user_id . '_' . $window_start;

			global $wpdb;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Single-statement atomic upsert; caching would defeat the counter.
			$wpdb->query(
				$wpdb->prepare(
					"INSERT INTO {$wpdb->options} ( option_name, option_value, autoload ) VALUES ( %s, 1, 'no' ) " .
					'ON DUPLICATE KEY UPDATE option_value = option_value + 1',
					$option_name
				)
			);

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Read-back of the atomic counter written above.
			$row   = $wpdb->get_row( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $option_name ) );
			$count = ( $row && is_numeric( $row->option_value ) ) ? (int) $row->option_value : 1;

			// Occasionally sweep counters from expired windows (about 2% of calls).
			if ( 0 === wp_rand( 0, 49 ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Opportunistic maintenance DELETE; nothing to cache.
				$wpdb->query(
					$wpdb->prepare(
						"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND SUBSTRING_INDEX( option_name, '_', -1 ) + 0 < %d",
						'webmcp\\_throttle\\_%',
						$now - 5 * MINUTE_IN_SECONDS
					)
				);
			}

			if ( $count > $limit ) {
				return new WP_Error(
					'webmcp_throttled',
					__( 'Too many requests. Please wait a moment and try again.', 'webmcp-gateway' ),
					array( 'status' => 429 )
				);
			}

			return true;
		}

		/**
		 * Throttle guard for AJAX handlers: sends a JSON 429 and stops when the
		 * per-user budget for the bucket is exhausted.
		 *
		 * @param string $bucket Handler group identifier.
		 * @param int    $limit  Maximum calls per minute per user.
		 * @return void
		 */
		private static function guard_ajax( $bucket, $limit ) {
			$ok = self::throttle_ajax( $bucket, $limit );
			if ( is_wp_error( $ok ) ) {
				wp_send_json_error( array( 'error' => $ok->get_error_message() ), 429 );
			}
		}

		/**
		 * AJAX: issue a short-lived (60s) one-time execution token for the sandbox.
		 *
		 * The standard 24h nonce stays as the first factor; this token narrows the
		 * window for replaying a leaked sandbox request to one minute and one use.
		 *
		 * @return void
		 */
		public static function ajax_get_exec_token() {
			check_ajax_referer( 'webmcp_gateway_sandbox_nonce', 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'error' => __( 'Unauthorized access.', 'webmcp-gateway' ) ), 403 );
			}

			$token = wp_generate_password( 32, false, false );
			set_transient( 'webmcp_exec_' . md5( $token ), get_current_user_id(), 60 );

			wp_send_json_success( array( 'token' => $token ) );
		}

		/**
		 * Verify and burn a one-time sandbox execution token.
		 *
		 * @return void Sends JSON 403 and exits when the token is missing, stale,
		 *              already used, or issued to a different user.
		 */
		private static function verify_exec_token() {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- check_ajax_referer runs in ajax_run_sandbox_tool before this guard is invoked.
			$provided = isset( $_POST['exec_token'] ) ? sanitize_text_field( wp_unslash( $_POST['exec_token'] ) ) : '';
			$key      = 'webmcp_exec_' . md5( $provided );

			if ( '' === $provided ) {
				wp_send_json_error( array( 'error' => __( 'Missing execution token. Reload the Sandbox and try again.', 'webmcp-gateway' ) ), 403 );
			}

			$owner = get_transient( $key );
			if ( false === $owner || (int) $owner !== get_current_user_id() ) {
				wp_send_json_error( array( 'error' => __( 'Execution token expired or invalid. Reload the Sandbox and try again.', 'webmcp-gateway' ) ), 403 );
			}

			// One-time burn: a replayed request fails even inside the 60s window.
			delete_transient( $key );
		}

		public static function ajax_run_sandbox_tool() {
			check_ajax_referer( 'webmcp_gateway_sandbox_nonce', 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'error' => __( 'Unauthorized access.', 'webmcp-gateway' ) ), 403 );
			}

			self::guard_ajax( 'sandbox', 30 );
			self::verify_exec_token();

			$start = microtime( true );
			$tool  = isset( $_POST['tool'] ) ? sanitize_text_field( wp_unslash( $_POST['tool'] ) ) : '';
			$param = isset( $_POST['param'] ) ? sanitize_text_field( wp_unslash( $_POST['param'] ) ) : '';

			$params = array();
			if ( 'searchSite' === $tool ) {
				$params['query'] = '' !== $param ? $param : 'WordPress';
				$params['limit'] = 5;
			} elseif ( 'getPostContent' === $tool ) {
				$post_id = absint( $param );
				if ( $post_id <= 0 ) {
					$recent_post = get_posts(
						array(
							'post_type'      => array( 'post', 'page' ),
							'post_status'    => 'publish',
							'posts_per_page' => 1,
						)
					);
					$post_id     = ! empty( $recent_post[0] ) ? (int) $recent_post[0]->ID : 1;
				}
				$params['post_id'] = $post_id;
			} elseif ( 'getFeaturedContent' === $tool || 'getSiteTaxonomies' === $tool ) {
				$params['limit'] = '' !== $param ? min( 20, max( 1, absint( $param ) ) ) : 5;
			} elseif ( 'getCatalogItems' === $tool ) {
				$params['query'] = $param;
				$params['limit'] = 5;
			}

			$req = new WP_REST_Request( 'POST', '/webmcp-gateway/v1/call/' . $tool );
			$req->set_param( 'tool', $tool );
			$req->set_body( (string) wp_json_encode( $params ) );
			$req->set_header( 'content-type', 'application/json' );

			$res        = WebMCP_Gateway_REST::call_tool( $req );
			$elapsed_ms = round( ( microtime( true ) - $start ) * 1000, 2 );

			if ( is_wp_error( $res ) ) {
				wp_send_json_error(
					array(
						'error'      => $res->get_error_message(),
						'elapsed_ms' => $elapsed_ms,
					)
				);
			}

			wp_send_json_success(
				array(
					'tool'       => $tool,
					'elapsed_ms' => $elapsed_ms,
					'result'     => $res->get_data(),
				)
			);
		}

		/**
		 * AJAX handler: Preview the clean Markdown content negotiation stream for a post.
		 *
		 * @return void
		 */
		public static function ajax_preview_markdown() {
			check_ajax_referer( 'webmcp_gateway_sandbox_nonce', 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'error' => __( 'Unauthorized access.', 'webmcp-gateway' ) ), 403 );
			}

			self::guard_ajax( 'preview', 30 );

			$post_id = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0;
			if ( $post_id <= 0 ) {
				$recent = get_posts(
					array(
						'post_type'      => array( 'post', 'page' ),
						'post_status'    => 'publish',
						'posts_per_page' => 1,
					)
				);
				if ( ! empty( $recent[0] ) ) {
					$post_id = (int) $recent[0]->ID;
				}
			}

			$post = $post_id > 0 ? get_post( $post_id ) : null;
			if ( ! ( $post instanceof WP_Post ) ) {
				wp_send_json_error( array( 'error' => __( 'No published posts or pages found to preview.', 'webmcp-gateway' ) ) );
			}

			WebMCP_Gateway_Activity_Log::record_event(
				'markdown',
				'Admin Markdown Inspector',
				get_the_title( $post ),
				__( 'Generated clean AI Markdown preview with YAML frontmatter', 'webmcp-gateway' )
			);

			$markdown = WebMCP_Gateway_Markdown::build_post_markdown_document( $post );
			wp_send_json_success(
				array(
					'post_id'  => $post->ID,
					'title'    => get_the_title( $post ),
					'markdown' => $markdown,
				)
			);
		}

		/**
		 * AJAX handler: Run the Page AEO & Agent X-Ray Audit on a selected post/page.
		 *
		 * @return void
		 */
		public static function ajax_run_xray_audit() {
			check_ajax_referer( 'webmcp_gateway_sandbox_nonce', 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'error' => __( 'Unauthorized access.', 'webmcp-gateway' ) ), 403 );
			}

			self::guard_ajax( 'xray', 20 );

			$post_id = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0;
			if ( $post_id <= 0 ) {
				$recent = get_posts(
					array(
						'post_type'      => array( 'post', 'page' ),
						'post_status'    => 'publish',
						'posts_per_page' => 1,
					)
				);
				if ( ! empty( $recent[0] ) ) {
					$post_id = (int) $recent[0]->ID;
				}
			}

			$post = $post_id > 0 ? get_post( $post_id ) : null;
			if ( ! ( $post instanceof WP_Post ) ) {
				wp_send_json_error( array( 'error' => __( 'No published post or page found to scan.', 'webmcp-gateway' ) ) );
			}

			$report = WebMCP_Gateway_Activity_Log::run_post_xray_audit( $post );
			wp_send_json_success( $report );
		}

		/**
		 * AJAX handler: Inject selected Answer-Gap questions (with user-edited answers)
		 * into a post's FAQPage schema metadata, deduped by question text, then
		 * re-run the X-Ray audit so the score updates immediately.
		 *
		 * @return void
		 */
		public static function ajax_inject_answer_gaps() {
			check_ajax_referer( 'webmcp_gateway_sandbox_nonce', 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'error' => __( 'Unauthorized access.', 'webmcp-gateway' ) ), 403 );
			}

			self::guard_ajax( 'inject', 10 );

			$post_id = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0;
			$post    = $post_id > 0 ? get_post( $post_id ) : null;
			if ( ! ( $post instanceof WP_Post ) ) {
				wp_send_json_error( array( 'error' => __( 'Invalid post selected.', 'webmcp-gateway' ) ) );
			}

			// Client sends the user's checked & edited gaps as JSON; fall back to auto-generated ones.
			$incoming = array();
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- JSON decoded & sanitized item-by-item below.
			$raw_gaps = isset( $_POST['gaps'] ) ? wp_unslash( $_POST['gaps'] ) : '';
			if ( is_string( $raw_gaps ) && '' !== $raw_gaps ) {
				$decoded = json_decode( $raw_gaps, true );
				if ( is_array( $decoded ) ) {
					foreach ( $decoded as $item ) {
						if ( ! is_array( $item ) ) {
							continue;
						}
						$q = isset( $item['q'] ) ? sanitize_text_field( (string) $item['q'] ) : '';
						$a = isset( $item['a'] ) ? sanitize_textarea_field( (string) $item['a'] ) : '';
						if ( '' !== $q && '' !== $a ) {
							$incoming[] = array(
								'q' => $q,
								'a' => $a,
							);
						}
					}
				}
			}
			if ( empty( $incoming ) ) {
				$generated = WebMCP_Gateway_Activity_Log::generate_answer_gap_questions( $post );
				foreach ( $generated as $g ) {
					$incoming[] = array(
						'q' => $g['q'],
						'a' => $g['a_hint'],
					);
				}
			}

			$existing = get_post_meta( $post_id, '_webmcp_gateway_faq_items', true );
			$existing = is_array( $existing ) ? $existing : array();

			$seen = array();
			foreach ( $existing as $item ) {
				$seen[ md5( mb_strtolower( trim( (string) ( isset( $item['q'] ) ? $item['q'] : '' ) ) ) ) ] = true;
			}

			$injected = 0;
			$skipped  = 0;
			foreach ( $incoming as $item ) {
				$key = md5( mb_strtolower( trim( $item['q'] ) ) );
				if ( isset( $seen[ $key ] ) ) {
					continue;
				}
				// Never store instructional Answer-Gap placeholders in FAQPage meta.
				if ( ! WebMCP_Gateway_Schema_Graph::is_publishable_faq_answer( $item['a'] ) ) {
					++$skipped;
					continue;
				}
				$seen[ $key ] = true;
				$existing[]   = $item;
				++$injected;
			}

			if ( $injected > 0 ) {
				update_post_meta( $post_id, '_webmcp_gateway_faq_items', array_values( $existing ) );
			}

			WebMCP_Gateway_Activity_Log::record_event(
				'xray',
				'Answer-Gap Auto-Injector',
				get_the_title( $post ),
				sprintf(
					/* translators: 1: Number of FAQs injected, 2: Post ID */
					__( 'Injected %1$d new Answer-Gap FAQPage nodes into Post #%2$d (duplicates skipped)', 'webmcp-gateway' ),
					$injected,
					$post_id
				)
			);

			$report            = WebMCP_Gateway_Activity_Log::run_post_xray_audit( $post );
			$report['injected'] = $injected;
			$report['skipped']  = $skipped;
			if ( 0 === $injected && $skipped > 0 ) {
				$report['inject_notice'] = __( 'Placeholder Answer-Gap hints were not injected. Edit each answer into a real factual reply (40+ characters), then inject again.', 'webmcp-gateway' );
			}
			wp_send_json_success( $report );
		}

		/**
		 * AJAX handler: Inspect the live output of /llms.txt, /llms-full.txt, or /.well-known/mcp.json.
		 *
		 * @return void
		 */
		public static function ajax_inspect_endpoint() {
			check_ajax_referer( 'webmcp_gateway_sandbox_nonce', 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'error' => __( 'Unauthorized access.', 'webmcp-gateway' ) ), 403 );
			}

			self::guard_ajax( 'inspect', 30 );

			$endpoint = isset( $_POST['endpoint'] ) ? sanitize_key( wp_unslash( $_POST['endpoint'] ) ) : 'llmstxt';

			if ( 'llmsfull' === $endpoint ) {
				$output = WebMCP_Gateway_LlmsTxt::generate_full_content();
				$label  = home_url( '/llms-full.txt' );
			} elseif ( 'wellknown' === $endpoint ) {
				$manifest = WebMCP_Gateway_Schema_Builder::build( 'homepage', 0 );
				$output   = (string) wp_json_encode( $manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
				$label    = home_url( '/.well-known/mcp.json' );
			} else {
				$output = WebMCP_Gateway_LlmsTxt::generate_summary_content();
				$label  = home_url( '/llms.txt' );
			}

			wp_send_json_success(
				array(
					'label'  => $label,
					'output' => $output,
				)
			);
		}

		/**
		 * AJAX handler: Clear the local AI Activity Log.
		 *
		 * @return void
		 */
		public static function ajax_clear_activity_log() {
			check_ajax_referer( 'webmcp_gateway_sandbox_nonce', 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'error' => __( 'Unauthorized access.', 'webmcp-gateway' ) ), 403 );
			}

			delete_option( 'webmcp_gateway_activity_events' );
			delete_option( 'webmcp_gateway_activity_counters' );

			wp_send_json_success( array( 'cleared' => true ) );
		}

		/**
		 * AJAX: generate a new MCP API key (raw key is returned exactly once).
		 *
		 * @return void
		 */
		/**
		 * AJAX: run the local Schema.org validation on the homepage graph and the
		 * latest published post's graph; returns per-context pass/error lists.
		 *
		 * @return void
		 */
		public static function ajax_validate_schema() {
			check_ajax_referer( 'webmcp_gateway_sandbox_nonce', 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'error' => __( 'Unauthorized access.', 'webmcp-gateway' ) ), 403 );
			}

			self::guard_ajax( 'validate', 20 );

			$latest     = get_posts(
				array(
					'post_type'      => array( 'post', 'page' ),
					'post_status'    => 'publish',
					'posts_per_page' => 1,
					'no_found_rows'  => true,
				)
			);
			$latest_id  = ! empty( $latest[0] ) ? (int) $latest[0]->ID : 0;

			$contexts = array(
				'homepage' => WebMCP_Gateway_Schema_Graph::generate( 0, 'homepage' ),
			);
			if ( $latest_id > 0 ) {
				$contexts[ 'post_' . $latest_id ] = WebMCP_Gateway_Schema_Graph::generate( $latest_id, 'single' );
			}

			$results = array();
			foreach ( $contexts as $label => $graph ) {
				$results[ $label ] = WebMCP_Gateway_Schema_Graph::validate_graph( $graph );
			}

			wp_send_json_success( array( 'results' => $results ) );
		}

		public static function ajax_generate_api_key() {
			check_ajax_referer( 'webmcp_gateway_sandbox_nonce', 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'error' => __( 'Unauthorized access.', 'webmcp-gateway' ) ), 403 );
			}

			self::guard_ajax( 'keys', 20 );

			$label = isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : '';
			$raw   = WebMCP_Gateway_REST::generate_api_key( $label );

			if ( is_wp_error( $raw ) ) {
				wp_send_json_error( array( 'error' => $raw->get_error_message() ), 400 );
			}

			wp_send_json_success(
				array(
					'key'   => $raw,
					'label' => $label,
				)
			);
		}

		/**
		 * AJAX: revoke a stored MCP API key by hash.
		 *
		 * @return void
		 */
		public static function ajax_revoke_api_key() {
			check_ajax_referer( 'webmcp_gateway_sandbox_nonce', 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'error' => __( 'Unauthorized access.', 'webmcp-gateway' ) ), 403 );
			}

			self::guard_ajax( 'keys', 20 );

			$hash = isset( $_POST['hash'] ) ? sanitize_text_field( wp_unslash( $_POST['hash'] ) ) : '';
			if ( '' === $hash || ! preg_match( '/^[a-f0-9]{64}$/i', $hash ) ) {
				wp_send_json_error( array( 'error' => __( 'Invalid key identifier.', 'webmcp-gateway' ) ), 400 );
			}

			$revoked = WebMCP_Gateway_REST::revoke_api_key( $hash );
			if ( ! $revoked ) {
				wp_send_json_error( array( 'error' => __( 'Key not found (it may already be revoked).', 'webmcp-gateway' ) ), 404 );
			}

			wp_send_json_success( array( 'revoked' => true ) );
		}

		/**
		 * AJAX handler: Return current activity events + counters for the live feed.
		 *
		 * @return void
		 */
		public static function ajax_get_activity() {
			check_ajax_referer( 'webmcp_gateway_sandbox_nonce', 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'error' => __( 'Unauthorized access.', 'webmcp-gateway' ) ), 403 );
			}

			wp_send_json_success(
				array(
					'events'   => WebMCP_Gateway_Activity_Log::get_events(),
					'counters' => WebMCP_Gateway_Activity_Log::get_counters(),
				)
			);
		}

		/**
		 * AJAX handler: Search published content for the post picker combobox.
		 *
		 * @return void
		 */
		public static function ajax_search_posts() {
			check_ajax_referer( 'webmcp_gateway_sandbox_nonce', 'nonce' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'error' => __( 'Unauthorized access.', 'webmcp-gateway' ) ), 403 );
			}

			$search     = isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '';
			$post_types = array( 'post', 'page' );
			if ( post_type_exists( 'product' ) ) {
				$post_types[] = 'product';
			}

			$query_args = array(
				'post_type'              => $post_types,
				'post_status'            => 'publish',
				'posts_per_page'         => 20,
				'orderby'                => 'modified',
				'order'                  => 'DESC',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			);
			if ( '' !== $search ) {
				$query_args['s'] = $search;
			}

			$posts   = get_posts( $query_args );
			$results = array();
			foreach ( $posts as $p ) {
				$results[] = array(
					'id'    => (int) $p->ID,
					'title' => html_entity_decode( get_the_title( $p ), ENT_QUOTES, 'UTF-8' ),
					'type'  => (string) $p->post_type,
				);
			}

			wp_send_json_success( $results );
		}
	}
}
