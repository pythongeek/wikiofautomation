<?php
/**
 * Post, Page & WooCommerce Product AEO Meta Box - WebMCP Gateway.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WebMCP_Gateway_Metabox' ) ) {
	/**
	 * Registers and saves the AEO & Agent Optimization meta box on posts, pages, and products.
	 */
	final class WebMCP_Gateway_Metabox {

		/**
		 * Register meta box hooks.
		 *
		 * @return void
		 */
		public static function init() {
			WebMCP_Gateway_Loader::register_action( 'add_meta_boxes', array( __CLASS__, 'register_meta_boxes' ) );
			WebMCP_Gateway_Loader::register_action( 'save_post', array( __CLASS__, 'save_meta_box' ), 10, 2 );
		}

		/**
		 * Add the WebMCP AEO meta box to public post types.
		 *
		 * @return void
		 */
		public static function register_meta_boxes() {
			$screens = array( 'post', 'page' );
			if ( post_type_exists( 'product' ) ) {
				$screens[] = 'product';
			}

			foreach ( $screens as $screen ) {
				add_meta_box(
					'webmcp_gateway_aeo_metabox',
					__( 'WebMCP Gateway — AEO & AI Answer Engine Optimization', 'webmcp-gateway' ),
					array( __CLASS__, 'render_meta_box' ),
					$screen,
					'normal',
					'high'
				);
			}
		}

		/**
		 * Render the meta box HTML.
		 *
		 * @param mixed $post Current post object.
		 * @return void
		 */
		public static function render_meta_box( $post = null ) {
			if ( ! ( $post instanceof WP_Post ) ) {
				return;
			}
			wp_nonce_field( 'webmcp_gateway_save_metabox', 'webmcp_gateway_metabox_nonce' );

			$ai_summary        = (string) get_post_meta( $post->ID, '_webmcp_gateway_ai_summary', true );
			$auto_summary      = WebMCP_Gateway_Activity_Log::get_effective_ai_summary( $post );
			$schema_type       = (string) get_post_meta( $post->ID, '_webmcp_gateway_schema_type', true );
			$speakable_disable = (bool) get_post_meta( $post->ID, '_webmcp_gateway_speakable_disable', true );
			$speakable_on      = (bool) get_option( 'webmcp_gateway_speakable_enabled', 1 ) && ! $speakable_disable;
			$faqs              = get_post_meta( $post->ID, '_webmcp_gateway_faq_items', true );
			$auto_faqs         = WebMCP_Gateway_Activity_Log::extract_auto_faqs_from_html( $post->post_content );

			$faqs_manual = is_array( $faqs ) && ! empty( $faqs );
			if ( ! $faqs_manual ) {
				$faqs = ! empty( $auto_faqs ) ? $auto_faqs : array(
					array(
						'q' => '',
						'a' => '',
					),
				);
			}

			$permalink = get_permalink( $post );
			$md_url    = $permalink ? add_query_arg( 'format', 'markdown', $permalink ) : '';
			$xray_url  = admin_url( 'admin.php?page=webmcp-gateway&tab=xray&post_id=' . (int) $post->ID );
			?>
			<div class="wm-mb">

				<div class="wm-mb__hero">
					<div class="wm-mb__hero-text">
						<strong><?php esc_html_e( 'See exactly what ChatGPT, Perplexity & Google AI see on this page', 'webmcp-gateway' ); ?></strong>
						<span><?php esc_html_e( 'Run the X-Ray Scanner for your 0–100 AEO score, or place [webmcp_ai_summary] anywhere in your content.', 'webmcp-gateway' ); ?></span>
					</div>
					<div class="wm-mb__hero-actions">
						<a href="<?php echo esc_url( $xray_url ); ?>" class="wm-btn wm-btn--primary wm-btn--sm">
							<span class="dashicons dashicons-search"></span><?php esc_html_e( 'Run X-Ray Scan', 'webmcp-gateway' ); ?>
						</a>
						<?php if ( 'publish' === $post->post_status && '' !== $md_url ) : ?>
							<a href="<?php echo esc_url( $md_url ); ?>" target="_blank" rel="noopener noreferrer" class="wm-btn wm-btn--ghost wm-btn--sm">
								<?php esc_html_e( 'AI Markdown ↗', 'webmcp-gateway' ); ?>
							</a>
						<?php endif; ?>
					</div>
				</div>

				<div class="wm-mb__chips">
					<span class="wm-chip <?php echo '' !== trim( $ai_summary ) ? 'wm-chip--pass' : 'wm-chip--auto'; ?>">
						<?php echo '' !== trim( $ai_summary ) ? esc_html__( 'Summary ✓ custom', 'webmcp-gateway' ) : esc_html__( 'Summary Ⓐ auto', 'webmcp-gateway' ); ?>
					</span>
					<span class="wm-chip <?php echo $faqs_manual ? 'wm-chip--pass' : ( ! empty( $auto_faqs ) ? 'wm-chip--auto' : 'wm-chip--none' ); ?>">
						<?php
						printf(
							/* translators: %d: FAQ pair count */
							esc_html( $faqs_manual ? 'FAQ ✓ %d manual' : ( ! empty( $auto_faqs ) ? 'FAQ Ⓐ %d from headings' : 'FAQ — none yet' ) ),
							(int) count( $faqs )
						);
						?>
					</span>
					<span class="wm-chip <?php echo $speakable_on ? 'wm-chip--pass' : 'wm-chip--none'; ?>">
						<?php echo $speakable_on ? esc_html__( 'Speakable ✓', 'webmcp-gateway' ) : esc_html__( 'Speakable off', 'webmcp-gateway' ); ?>
					</span>
					<?php if ( 'product' === $post->post_type ) : ?>
						<span class="wm-chip wm-chip--pass"><?php esc_html_e( 'Woo Product & Offer schema ✓', 'webmcp-gateway' ); ?></span>
					<?php endif; ?>
				</div>

				<?php if ( 'product' === $post->post_type ) : ?>
					<div class="wm-mb__note wm-mb__note--pass">
						<?php esc_html_e( 'WooCommerce Product Schema & MCP Catalog active: WebMCP Gateway automatically outputs Schema.org Product & Offer JSON-LD (price, currency, SKU, availability) and exposes this item via the getCatalogItems MCP tool.', 'webmcp-gateway' ); ?>
					</div>
				<?php endif; ?>

				<section class="wm-mb__section">
					<h4 class="wm-mb__section-title">
						<span class="wm-mb__stepnum">1</span>
						<?php esc_html_e( 'AI Direct Answer / Executive Summary', 'webmcp-gateway' ); ?>
						<span class="wm-mb__section-hint"><?php esc_html_e( 'The TL;DR answer engines quote', 'webmcp-gateway' ); ?></span>
					</h4>
					<?php
					$webmcp_gateway_placeholder = '' !== $auto_summary
						? sprintf(
							/* translators: %s: Auto-detected lead summary text */
							__( 'Auto-detected from lead paragraph: "%s" (type here to override with a custom TL;DR)', 'webmcp-gateway' ),
							$auto_summary
						)
						: __( 'Write a concise 1-3 sentence factual answer summarizing this page…', 'webmcp-gateway' );
					?>
					<textarea
						id="webmcp_gateway_ai_summary"
						name="webmcp_gateway_ai_summary"
						rows="3"
						class="wm-mb__textarea"
						placeholder="<?php echo esc_attr( $webmcp_gateway_placeholder ); ?>"
					><?php echo esc_textarea( $ai_summary ); ?></textarea>
					<p class="wm-mb__help"><?php esc_html_e( 'Left blank? A summary is auto-synthesized from your opening paragraph so the page is never empty to AI crawlers.', 'webmcp-gateway' ); ?></p>
				</section>

				<section class="wm-mb__section wm-mb__section--row">
					<h4 class="wm-mb__section-title">
						<span class="wm-mb__stepnum">2</span>
						<?php esc_html_e( 'Schema & Speakable', 'webmcp-gateway' ); ?>
					</h4>
					<div class="wm-mb__row">
						<label class="wm-mb__field" for="webmcp_gateway_schema_type">
							<span><?php esc_html_e( 'Primary entity type', 'webmcp-gateway' ); ?></span>
							<select id="webmcp_gateway_schema_type" name="webmcp_gateway_schema_type">
								<option value="" <?php selected( $schema_type, '' ); ?>><?php esc_html_e( 'Default (Auto-detect)', 'webmcp-gateway' ); ?></option>
								<option value="BlogPosting" <?php selected( $schema_type, 'BlogPosting' ); ?>><?php esc_html_e( 'BlogPosting', 'webmcp-gateway' ); ?></option>
								<option value="Article" <?php selected( $schema_type, 'Article' ); ?>><?php esc_html_e( 'Article', 'webmcp-gateway' ); ?></option>
								<option value="NewsArticle" <?php selected( $schema_type, 'NewsArticle' ); ?>><?php esc_html_e( 'NewsArticle', 'webmcp-gateway' ); ?></option>
								<option value="TechArticle" <?php selected( $schema_type, 'TechArticle' ); ?>><?php esc_html_e( 'TechArticle (Docs / Guide)', 'webmcp-gateway' ); ?></option>
								<option value="WebPage" <?php selected( $schema_type, 'WebPage' ); ?>><?php esc_html_e( 'WebPage Only', 'webmcp-gateway' ); ?></option>
								<option value="AboutPage" <?php selected( $schema_type, 'AboutPage' ); ?>><?php esc_html_e( 'AboutPage', 'webmcp-gateway' ); ?></option>
								<option value="ContactPage" <?php selected( $schema_type, 'ContactPage' ); ?>><?php esc_html_e( 'ContactPage', 'webmcp-gateway' ); ?></option>
							</select>
						</label>
						<label class="wm-mb__check">
							<input type="checkbox" name="webmcp_gateway_speakable_disable" value="1" <?php checked( $speakable_disable ); ?>>
							<span><?php esc_html_e( 'Disable SpeakableSpecification on this post', 'webmcp-gateway' ); ?></span>
						</label>
					</div>
				</section>

				<section class="wm-mb__section">
					<h4 class="wm-mb__section-title">
						<span class="wm-mb__stepnum">3</span>
						<?php esc_html_e( 'FAQPage Schema Builder', 'webmcp-gateway' ); ?>
						<span class="wm-mb__section-hint"><?php esc_html_e( 'Manual pairs + auto-extracted "?" headings', 'webmcp-gateway' ); ?></span>
					</h4>

					<?php if ( ! empty( $auto_faqs ) && ! $faqs_manual ) : ?>
						<p class="wm-mb__note wm-mb__note--pass">
							<?php
							printf(
								/* translators: %d: Number of auto-detected question headings */
								esc_html__( 'Auto-FAQ Engine detected %d question heading(s) ending in "?" inside your content and pre-filled them below.', 'webmcp-gateway' ),
								(int) count( $auto_faqs )
							);
							?>
						</p>
					<?php elseif ( $faqs_manual ) : ?>
						<p class="wm-mb__note wm-mb__note--pass">
							<?php
							printf(
								/* translators: %d: Number of manual FAQ pairs */
								esc_html__( '%d manual Question & Answer pair(s) are broadcasting in FAQPage JSON-LD.', 'webmcp-gateway' ),
								(int) count( $faqs )
							);
							?>
						</p>
					<?php else : ?>
						<p class="wm-mb__help"><?php esc_html_e( 'Add Q&A pairs below — or simply write H2/H3 headings ending with "?" in your article — to generate valid Schema.org FAQPage JSON-LD.', 'webmcp-gateway' ); ?></p>
					<?php endif; ?>

					<div id="webmcp-faq-rows" class="wm-mb__faqs">
						<?php foreach ( $faqs as $faq_item ) : ?>
							<div class="wm-faq-row">
								<div class="wm-faq-row__bar">
									<span class="wm-faq-row__handle dashicons dashicons-menu" aria-hidden="true"></span>
									<span class="wm-faq-row__qnum"></span>
									<button type="button" class="wm-faq-row__remove" aria-label="<?php esc_attr_e( 'Remove this FAQ pair', 'webmcp-gateway' ); ?>">&times;</button>
								</div>
								<input
									type="text"
									name="webmcp_gateway_faq_q[]"
									class="wm-faq-row__q"
									value="<?php echo esc_attr( (string) ( isset( $faq_item['q'] ) ? $faq_item['q'] : '' ) ); ?>"
									placeholder="<?php esc_attr_e( 'Question (e.g., How does Model Context Protocol work on WordPress?)', 'webmcp-gateway' ); ?>"
								>
								<textarea
									name="webmcp_gateway_faq_a[]"
									rows="2"
									class="wm-faq-row__a"
									placeholder="<?php esc_attr_e( 'Direct, factual answer for AI citation and FAQPage schema…', 'webmcp-gateway' ); ?>"
								><?php echo esc_textarea( (string) ( isset( $faq_item['a'] ) ? $faq_item['a'] : '' ) ); ?></textarea>
							</div>
						<?php endforeach; ?>
					</div>

					<button type="button" class="wm-btn wm-btn--ghost wm-btn--sm" id="webmcp-faq-add">
						<span class="dashicons dashicons-plus-alt2"></span><?php esc_html_e( 'Add FAQ Pair', 'webmcp-gateway' ); ?>
					</button>
					<template id="webmcp-faq-template">
						<div class="wm-faq-row">
							<div class="wm-faq-row__bar">
								<span class="wm-faq-row__handle dashicons dashicons-menu" aria-hidden="true"></span>
								<span class="wm-faq-row__qnum"></span>
								<button type="button" class="wm-faq-row__remove" aria-label="<?php esc_attr_e( 'Remove this FAQ pair', 'webmcp-gateway' ); ?>">&times;</button>
							</div>
							<input type="text" name="webmcp_gateway_faq_q[]" class="wm-faq-row__q" placeholder="<?php esc_attr_e( 'Question…', 'webmcp-gateway' ); ?>">
							<textarea name="webmcp_gateway_faq_a[]" rows="2" class="wm-faq-row__a" placeholder="<?php esc_attr_e( 'Direct, factual answer…', 'webmcp-gateway' ); ?>"></textarea>
						</div>
					</template>
				</section>
			</div>
			<?php
		}

		/**
		 * Save meta box fields securely.
		 *
		 * @param mixed $post_id Post ID.
		 * @param mixed $post    Post object.
		 * @return void
		 */
		public static function save_meta_box( $post_id = 0, $post = null ) {
			$post_id = absint( $post_id );
			if ( $post_id <= 0 || ! isset( $_POST['webmcp_gateway_metabox_nonce'] ) ) {
				return;
			}

			$nonce = sanitize_text_field( wp_unslash( $_POST['webmcp_gateway_metabox_nonce'] ) );
			if ( ! wp_verify_nonce( $nonce, 'webmcp_gateway_save_metabox' ) ) {
				return;
			}

			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
				return;
			}

			if ( wp_is_post_revision( $post_id ) ) {
				return;
			}

			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				return;
			}

			if ( isset( $_POST['webmcp_gateway_ai_summary'] ) ) {
				$summary = sanitize_textarea_field( wp_unslash( $_POST['webmcp_gateway_ai_summary'] ) );
				update_post_meta( $post_id, '_webmcp_gateway_ai_summary', $summary );
			}

			if ( isset( $_POST['webmcp_gateway_schema_type'] ) ) {
				$type          = sanitize_text_field( wp_unslash( $_POST['webmcp_gateway_schema_type'] ) );
				$allowed_types = array( '', 'BlogPosting', 'Article', 'NewsArticle', 'TechArticle', 'WebPage', 'AboutPage', 'ContactPage' );
				if ( in_array( $type, $allowed_types, true ) ) {
					update_post_meta( $post_id, '_webmcp_gateway_schema_type', $type );
				}
			}

			$speakable_disable = isset( $_POST['webmcp_gateway_speakable_disable'] ) ? 1 : 0;
			update_post_meta( $post_id, '_webmcp_gateway_speakable_disable', $speakable_disable );

			if ( isset( $_POST['webmcp_gateway_faq_q'] ) && is_array( $_POST['webmcp_gateway_faq_q'] ) ) {
				$raw_qs = array_map( 'sanitize_text_field', wp_unslash( $_POST['webmcp_gateway_faq_q'] ) );
				$raw_as = isset( $_POST['webmcp_gateway_faq_a'] ) && is_array( $_POST['webmcp_gateway_faq_a'] )
					? array_map( 'sanitize_textarea_field', wp_unslash( $_POST['webmcp_gateway_faq_a'] ) )
					: array();

				$faqs = array();
				foreach ( $raw_qs as $index => $question ) {
					$q_clean = trim( $question );
					$a_clean = isset( $raw_as[ $index ] ) ? trim( $raw_as[ $index ] ) : '';
					if ( '' !== $q_clean && WebMCP_Gateway_Schema_Graph::is_publishable_faq_answer( $a_clean ) ) {
						$faqs[] = array(
							'q' => $q_clean,
							'a' => $a_clean,
						);
					}
				}
				if ( ! empty( $faqs ) ) {
					update_post_meta( $post_id, '_webmcp_gateway_faq_items', $faqs );
				} else {
					delete_post_meta( $post_id, '_webmcp_gateway_faq_items' );
				}
			}
		}
	}
}
