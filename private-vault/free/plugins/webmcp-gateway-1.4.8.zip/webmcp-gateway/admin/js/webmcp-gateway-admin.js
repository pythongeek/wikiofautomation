/*! WebMCP Gateway admin app v1.4.8 — © n4nion — GPL-2.0-or-later */
/* global jQuery, WebMCPGatewayAdmin */
(function ($) {
	'use strict';

	if (!jQuery) { return; }
	var $doc = $(document);

	/* ==================================================================
	   Helpers
	   ================================================================== */
	function esc(str) {
		return String(str == null ? '' : str)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#39;');
	}

	function t(key, fallback) {
		var dict = (window.WebMCPGatewayAdmin && window.WebMCPGatewayAdmin.i18n) || {};
		return dict[key] || fallback || key;
	}

	function api(action, data) {
		var payload = $.extend({ action: action, nonce: WebMCPGatewayAdmin.nonce }, data || {});
		return $.ajax({ url: WebMCPGatewayAdmin.ajaxUrl, type: 'POST', data: payload }).then(function (response) {
			if (response && response.success && typeof response.data !== 'undefined') {
				return response.data;
			}
			var msg = (response && response.data && response.data.error) ? response.data.error : t('request_failed', 'Request failed.');
			throw new Error(msg);
		});
	}

	function toast(message, type) {
		var $toasts = $('#wm-toasts');
		if (!$toasts.length) { return; }
		var $t = $('<div/>', { 'class': 'wm-toast wm-toast--' + (type || 'success'), text: message });
		$toasts.append($t);
		requestAnimationFrame(function () { $t.addClass('is-in'); });
		setTimeout(function () {
			$t.removeClass('is-in');
			setTimeout(function () { $t.remove(); }, 260);
		}, 3200);
	}

	function countUp($el) {
		var target = parseInt($el.attr('data-count'), 10) || 0;
		if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
			$el.text(target);
			return;
		}
		// Background/occluded tabs never fire rAF: land on the final value immediately.
		if (document.hidden) {
			$el.text(target);
			return;
		}
		var startVal = parseInt($el.text().replace(/[^\d-]/g, ''), 10) || 0;
		if (startVal === target) { $el.text(target); return; }
		var t0 = null, dur = 700, done = false;
		function step(ts) {
			if (!t0) { t0 = ts; }
			var p = Math.min(1, (ts - t0) / dur);
			var eased = 1 - Math.pow(1 - p, 3);
			$el.text(Math.round(startVal + (target - startVal) * eased));
			if (p < 1) {
				requestAnimationFrame(step);
			} else {
				done = true;
			}
		}
		requestAnimationFrame(step);
		// Safety net: if rAF is throttled, snap to the final value.
		setTimeout(function () {
			if (!done) { $el.text(target); }
		}, dur + 120);
	}

	function relTime(mysql) {
		if (!mysql) { return ''; }
		var ts = new Date(String(mysql).replace(' ', 'T'));
		if (isNaN(ts.getTime())) { return String(mysql); }
		var diff = Math.max(0, (Date.now() - ts.getTime()) / 1000);
		if (diff < 60) { return t('just_now', 'just now'); }
		if (diff < 3600) { return t('mins_ago', '%dm ago').replace('%d', Math.floor(diff / 60)); }
		if (diff < 86400) { return t('hours_ago', '%dh ago').replace('%d', Math.floor(diff / 3600)); }
		return t('days_ago', '%dd ago').replace('%d', Math.floor(diff / 86400));
	}

	function highlightJson(text) {
		var safe = esc(text);
		return safe.replace(
			/("(\\u[a-fA-F0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)/g,
			function (m) {
				var cls = 'tok-num';
				if (m.charAt(0) === '"') { cls = (m.slice(-1) === ':') ? 'tok-key' : 'tok-str'; }
				else if (m === 'true' || m === 'false' || m === 'null') { cls = 'tok-bool'; }
				return '<span class="' + cls + '">' + m + '</span>';
			}
		);
	}

	function copyText(text, $btn, doneLabel) {
		var finish = function () {
			if (!$btn || !$btn.length) { return; }
			var orig = $btn.text();
			$btn.text(doneLabel || 'Copied!');
			setTimeout(function () { $btn.text(orig); }, 1600);
		};
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(text).then(finish);
		} else {
			var ta = document.createElement('textarea');
			ta.value = text;
			document.body.appendChild(ta);
			ta.select();
			document.execCommand('copy');
			document.body.removeChild(ta);
			finish();
		}
	}

	function busy($btn, label) {
		var orig = $btn.html();
		$btn.addClass('is-busy').attr('aria-busy', 'true');
		if (label) { $btn.text(label); }
		return function done(newLabel) {
			$btn.removeClass('is-busy').removeAttr('aria-busy').html(orig);
			if (newLabel) {
				$btn.text(newLabel);
				setTimeout(function () { $btn.html(orig); }, 2600);
			}
		};
	}

	/* ==================================================================
	   Gauge
	   ================================================================== */
	var GAUGE_C = 326.73;

	function paintGauge($gauge, score) {
		if (!$gauge || !$gauge.length) { return; }
		var band = score < 60 ? 'fail' : (score < 90 ? 'warn' : 'pass');
		$gauge.removeClass('wm-gauge--pass wm-gauge--warn wm-gauge--fail').addClass('wm-gauge--' + band);
		$gauge.attr('data-score', score);
		$gauge.find('.wm-gauge__arc').css('stroke-dashoffset', (GAUGE_C * (1 - score / 100)).toFixed(2));
	}

	function initGauges() {
		$('.wm-gauge').each(function () {
			var score = parseFloat($(this).attr('data-score')) || 0;
			var $arc = $(this).find('.wm-gauge__arc');
			$arc.css('stroke-dashoffset', GAUGE_C);
			requestAnimationFrame(function () {
				requestAnimationFrame(function () {
					$arc.css('stroke-dashoffset', (GAUGE_C * (1 - score / 100)).toFixed(2));
				});
			});
		});
	}

	/* ==================================================================
	   Activity feed
	   ================================================================== */
	var feedIcons = {};
	var feedFilter = 'all';
	var feedShowAll = false;
	var feedTimer = null;

	function feedIcon(type) {
		return feedIcons[type] || 'dashicons-marker';
	}

	function feedRow(ev) {
		var type = esc(ev.type || 'info');
		return '<li class="wm-feed__item" data-type="' + type + '">' +
			'<span class="wm-feed__icon wm-feed__icon--' + type + '"><span class="dashicons ' + feedIcon(ev.type) + '"></span></span>' +
			'<div class="wm-feed__body">' +
				'<div class="wm-feed__meta"><strong>' + esc(ev.actor) + '</strong>' +
				'<time title="' + esc(ev.time) + '">' + esc(relTime(ev.time)) + '</time></div>' +
				'<code class="wm-feed__target">' + esc(ev.target) + '</code>' +
				'<p class="wm-feed__summary">' + esc(ev.summary) + '</p>' +
			'</div></li>';
	}

	function feedEmptyRow() {
		return '<li class="wm-empty">' +
			'<span class="dashicons dashicons-robot wm-empty__icon" aria-hidden="true"></span>' +
			'<strong>' + esc(t('no_activity', 'No AI activity yet')) + '</strong>' +
			'<p>' + esc(t('no_activity_hint', 'AI crawler and agent traffic appears here as it happens - every entry is a real request your server received.')) + '</p>' +
			'</li>';
	}

	function renderFeed(events) {
		var $feed = $('#wm-feed');
		if (!$feed.length) { return; }
		events = events || [];
		if (!events.length) {
			$feed.html(feedEmptyRow());
			$('#wm-feed-more').remove();
			return;
		}
		var limit = feedShowAll ? events.length : Math.min(15, events.length);
		var html = '';
		for (var i = 0; i < limit; i++) { html += feedRow(events[i]); }
		$feed.html(html);
		applyFeedFilter();

		var $more = $('#wm-feed-more');
		if (!feedShowAll && events.length > 15) {
			if ($more.length) {
				$more.text(t('show_all_events', 'Show all %d events').replace('%d', events.length)).show();
			} else {
				$('<button type="button" class="wm-btn wm-btn--ghost wm-btn--block" id="wm-feed-more">Show all ' + events.length + ' events</button>')
					.insertAfter($feed);
			}
		} else if ($more.length) {
			$more.hide();
		}
	}

	function applyFeedFilter() {
		$('#wm-feed .wm-feed__item').each(function () {
			var type = $(this).attr('data-type');
			var show = (feedFilter === 'all') ||
				(feedFilter === 'discovery' && (type === 'llmstxt' || type === 'wellknown')) ||
				(feedFilter === type);
			$(this).toggle(show);
		});
	}

	function updateCounters(counters) {
		counters = counters || {};
		var llms = (parseInt(counters.llmstxt, 10) || 0) + (parseInt(counters.wellknown, 10) || 0);
		var map = {
			'#wm-cnt-tools': counters.tool_call,
			'#wm-cnt-md': counters.markdown,
			'#wm-cnt-llms': llms,
			'#wm-cnt-bots': counters.bot_crawl,
			'#wm-cnt-xray': counters.xray
		};
		$.each(map, function (sel, val) {
			var $el = $(sel);
			if (!$el.length) { return; }
			$el.attr('data-count', parseInt(val, 10) || 0);
			countUp($el);
		});
	}

	function fetchFeed() {
		api('webmcp_gateway_get_activity').then(function (data) {
			renderFeed(data.events);
			updateCounters(data.counters);
		}).catch(function (err) { if (window.webmcpDebug === true) { console.warn('[WebMCP] feed refresh failed', err); } /* silent for polling */ });
	}

	function setLive(on) {
		if (feedTimer) { clearInterval(feedTimer); feedTimer = null; }
		if (on) {
			feedTimer = setInterval(function () {
				if (!document.hidden) { fetchFeed(); }
			}, 30000);
		}
	}

	/* ==================================================================
	   Run the Agent-Ready audit (single source of truth for the score)
	   ================================================================== */
	$doc.on('click', '#wm-run-audit-top-btn, #wm-steps-audit-btn, #wm-empty-audit-btn, #wm-hero-run-audit', function (e) {
		e.preventDefault();
		runAudit($(this));
	});

	$doc.on('click', '#wm-feed-refresh-btn', function () { fetchFeed(); });

	$doc.on('click', '#wm-feed-more', function () {
		feedShowAll = true;
		fetchFeed();
	});

	$doc.on('click', '.wm-filter', function () {
		$('.wm-filter').removeClass('is-active');
		$(this).addClass('is-active');
		feedFilter = $(this).attr('data-filter') || 'all';
		applyFeedFilter();
	});

	$doc.on('change', '#wm-feed-live', function () { setLive(this.checked); });

	$doc.on('click', '#wm-clear-log-btn', function () {
		var $btn = $(this);
		var done = busy($btn);
		api('webmcp_gateway_clear_activity_log').then(function () {
			done();
			feedShowAll = false;
			renderFeed([]);
			$('#wm-cnt-tools, #wm-cnt-md, #wm-cnt-llms, #wm-cnt-bots, #wm-cnt-xray').attr('data-count', 0).text('0');
			toast('Activity log cleared');
		}).catch(function (err) { done(); toast(err.message, 'error'); });
	});

	/* ==================================================================
	   Onboarding dismiss
	   ================================================================== */
	try {
		if (window.localStorage && window.localStorage.getItem('wm_onboard_dismissed') === '1') {
			$('#wm-onboard-card').hide();
		}
	} catch (e) { /* storage unavailable */ }

	$doc.on('click', '#wm-onboard-dismiss', function () {
		// Instant hide: slideUp-style animation may never tick in occluded tabs.
		$('#wm-onboard-card').hide();
		try {
			if (window.localStorage) { window.localStorage.setItem('wm_onboard_dismissed', '1'); }
		} catch (e) { /* storage unavailable */ }
	});

	/* ==================================================================
	   Endpoint inspector
	   ================================================================== */
	$doc.on('click', '#wm-ep-tabs .wm-seg__btn', function () {
		var $btn = $(this);
		$('#wm-ep-tabs .wm-seg__btn').removeClass('is-active').attr('aria-selected', 'false');
		$btn.addClass('is-active').attr('aria-selected', 'true');
		var $code = $('#wm-ep-code');
		$code.text('// Loading live endpoint output…');
		api('webmcp_gateway_inspect_endpoint', { endpoint: $btn.attr('data-endpoint') }).then(function (data) {
			$('#wm-ep-label').text(data.label);
			if ($btn.attr('data-endpoint') === 'wellknown') {
				$code.html(highlightJson(data.output));
			} else {
				$code.text(data.output);
			}
		}).catch(function (err) {
			$code.text('// ' + err.message);
		});
	});

	$doc.on('click', '#wm-ep-copy', function () {
		copyText($('#wm-ep-code').text(), $(this));
	});

	/* ==================================================================
	   Post picker combobox
	   ================================================================== */
	function initPicker() {
		var $input = $('#wm-xray-post-input');
		var $hidden = $('#wm-xray-post-id');
		var $results = $('#wm-xray-post-results');
		if (!$input.length) { return; }

		var debounce = null;
		var hoverIdx = -1;

		function close() {
			$results[0].hidden = true;
			$results.hide();
			hoverIdx = -1;
		}

		function search(q) {
			$results.html('<div class="wm-pickbar__none">Searching…</div>').removeAttr('hidden').show();
			api('webmcp_gateway_search_posts', { search: q }).then(function (list) {
				if (!list.length) {
					$results.html('<div class="wm-pickbar__none">No matching published content.</div>').removeAttr('hidden').show();
					return;
				}
				var html = '';
				list.forEach(function (item) {
					html += '<div class="wm-pickbar__opt" role="option" data-id="' + parseInt(item.id, 10) + '" data-title="' + esc(item.title) + '">' +
						'<span>' + esc('#' + item.id + ' — ' + item.title) + '</span><em>' + esc(item.type) + '</em></div>';
				});
				$results.html(html).removeAttr('hidden').show();
				hoverIdx = -1;
			}).catch(function () { close(); });
		}

		$input.on('input', function () {
			var q = $(this).val();
			clearTimeout(debounce);
			debounce = setTimeout(function () { search(q); }, 260);
		});

		$input.on('keydown', function (e) {
			var $opts = $results.find('.wm-pickbar__opt');
			if (!$opts.length) { return; }
			if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
				e.preventDefault();
				hoverIdx = e.key === 'ArrowDown' ? Math.min(hoverIdx + 1, $opts.length - 1) : Math.max(hoverIdx - 1, 0);
				$opts.removeClass('is-hover').eq(hoverIdx).addClass('is-hover');
			} else if (e.key === 'Enter' && hoverIdx >= 0) {
				e.preventDefault();
				$opts.eq(hoverIdx).trigger('click');
			} else if (e.key === 'Escape') {
				close();
			}
		});

		$results.on('click', '.wm-pickbar__opt', function () {
			$hidden.val($(this).attr('data-id'));
			$input.val($(this).find('span').first().text());
			close();
		});

		$doc.on('click', function (e) {
			if (!$(e.target).closest('.wm-postpicker').length) { close(); }
		});
	}

	/* ==================================================================
	   X-Ray scanner
	   ================================================================== */
	function bandOf(score) {
		return score < 60 ? 'fail' : (score < 90 ? 'warn' : 'pass');
	}

	function renderChecks(checks) {
		var html = '';
		(checks || []).forEach(function (chk) {
			var status = chk.status === 'pass' ? 'pass' : 'warn';
			var icon = status === 'pass' ? 'dashicons-yes-alt' : 'dashicons-warning';
			html += '<details class="wm-fixlist__item wm-fixlist__item--' + status + '">' +
				'<summary><span class="dashicons ' + icon + '"></span><strong>' + esc(chk.title) + '</strong>' +
				'<span class="wm-fixlist__chev dashicons dashicons-arrow-down-alt2"></span></summary>' +
				'<p>' + esc(chk.advice) + '</p></details>';
		});
		$('#wm-xr-checks').html(html);
	}

	function renderGaps(gaps) {
		var html = '';
		(gaps || []).forEach(function (g) {
			html += '<label class="wm-gap"><span class="wm-gap__select"><input type="checkbox" class="wm-gap__check" checked></span>' +
				'<span class="wm-gap__body">' +
				'<span class="wm-gap__intent">' + esc(g.intent) + '</span>' +
				'<strong class="wm-gap__q">' + esc(g.q) + '</strong>' +
				'<textarea class="wm-gap__a" rows="2">' + esc(g.a_hint) + '</textarea>' +
				'</span></label>';
		});
		$('#wm-xr-gaps').html(html);
	}

	function setCodePane($viewer, key, content) {
		$viewer.find('.wm-code__pre[data-pane="' + key + '"]').text(content);
	}

	function renderXrayReport(report) {
		if (!report) { return; }
		var $results = $('#wm-xray-results');
		if (!$results.length) { return; }

		var $gauge = $('#wm-xr-gauge');
		$('#wm-xr-score').text(report.score);
		$('#wm-xr-grade').text('Grade ' + report.grade);
		paintGauge($gauge, parseFloat(report.score) || 0);

		$('#wm-xr-entities').text((report.entity_cards || []).length);
		$('#wm-xr-faqs').text(report.faq_count || 0);
		$('#wm-xr-qheads').text(report.question_h_count || 0);
		$('#wm-xr-words').text(report.word_count || 0);

		$('#wm-xr-headline').text(report.speakable_headline || '');
		$('#wm-xr-summary').text(report.speakable_summary || '');
		$('#wm-xr-lead').text(report.speakable_lead || '');

		$('#wm-xr-edit-btn').attr('href', report.edit_url || '#');
		$('#wm-xr-google-btn').attr('href', report.rich_results_url || '#');
		$('#wm-xr-schema-btn').attr('href', report.schema_val_url || '#');

		renderChecks(report.checks);
		renderGaps(report.answer_gaps);

		var pills = '';
		(report.entity_cards || []).forEach(function (ec) {
			pills += '<span class="wm-pill">' + esc(ec.type) + '</span>';
		});
		$('#wm-xr-entity-pills').html(pills || '<span class="wm-pill">—</span>');

		var $viewer = $('#wm-xr-codeviewer');
		setCodePane($viewer, 'markdown', report.markdown_preview || '');
		setCodePane($viewer, 'jsonld', report.schema_json || '');
		$viewer.find('.wm-code__pre').each(function () {
			var $pre = $(this);
			if ($pre.attr('data-pane') === 'jsonld') {
				$pre.html(highlightJson($pre.text()));
			}
		});
	}

	$doc.on('click', '#wm-run-xray-btn', function () {
		var $btn = $(this);
		var postId = $('#wm-xray-post-id').val() || '';
		var done = busy($btn);
		api('webmcp_gateway_run_xray_audit', { post_id: postId }).then(function (report) {
			done();
			renderXrayReport(report);
			toast('X-Ray scan complete — score ' + report.score + '/100');
		}).catch(function (err) { done(); toast(err.message, 'error'); });
	});

	$doc.on('click', '#wm-inject-gaps-btn', function () {
		var $btn = $(this);
		var done = busy($btn);
		var selected = [];
		$('#wm-xr-gaps .wm-gap').each(function () {
			var $gap = $(this);
			if (!$gap.find('.wm-gap__check').is(':checked')) { return; }
			var q = $.trim($gap.find('.wm-gap__q').text());
			var a = $.trim($gap.find('.wm-gap__a').val());
			if (q && a) { selected.push({ q: q, a: a }); }
		});

		api('webmcp_gateway_inject_answer_gaps', {
			post_id: $('#wm-xray-post-id').val() || '',
			gaps: JSON.stringify(selected)
		}).then(function (report) {
			done();
			renderXrayReport(report);
			if (report.injected > 0) {
				toast('Injected ' + report.injected + ' new FAQ pair(s) — duplicates skipped');
			} else if (report.inject_notice) {
				toast(report.inject_notice, 'error');
			} else {
				toast('Nothing new to inject — those FAQs already exist.', 'error');
			}
		}).catch(function (err) { done(); toast(err.message, 'error'); });
	});

	/* Code viewer tabs (generic) */
	$doc.on('click', '.wm-code__tab', function () {
		var $tab = $(this);
		var $viewer = $tab.closest('.wm-code');
		$viewer.find('.wm-code__tab').removeClass('is-active').attr('aria-selected', 'false');
		$tab.addClass('is-active').attr('aria-selected', 'true');
		$viewer.find('.wm-code__pre').removeClass('is-active');
		$viewer.find('.wm-code__pre[data-pane="' + $tab.attr('data-tab') + '"]').addClass('is-active');
	});

	$doc.on('click', '#wm-xr-copy', function () {
		var $viewer = $('#wm-xr-codeviewer');
		copyText($viewer.find('.wm-code__pre.is-active').text(), $(this));
	});

	/* ==================================================================
	   Sandbox
	   ================================================================== */
	var $console = $('#wm-json-viewer');
	var $status = $('#wm-status-label');
	var $timer = $('#wm-exec-time');

	function setStatus(text, isError) {
		$status.text(text).toggleClass('wm-console__chip--err', !!isError);
	}

	function runTool(tool, param, $btn) {
		var done = $btn ? busy($btn) : null;
		setStatus('DISPATCH → POST /wp-json/webmcp-gateway/v1/call/' + tool);
		$timer.text('…');
		$console.text('// Executing MCP tool: ' + tool + '\n// Waiting for gateway response…');

		api('webmcp_gateway_get_exec_token', {}).then(function (tok) {
			return api('webmcp_gateway_run_sandbox_tool', { tool: tool, param: param || '', exec_token: (tok && tok.token) || '' });
		}).then(function (data) {
			if (done) { done(); }
			setStatus('HTTP 200 · ' + tool);
			$timer.text((data.elapsed_ms || 1) + ' ms');
			$console.html(highlightJson(JSON.stringify(data.result, null, 2)));
		}).catch(function (err) {
			if (done) { done(); }
			setStatus('ERROR', true);
			$timer.text('');
			$console.text('// ' + err.message);
		});
	}

	$doc.on('click', '.wpwebmcp-run-tool-btn', function (e) {
		e.preventDefault();
		var $btn = $(this);
		var tool = $btn.attr('data-tool');
		var param = $btn.closest('.wm-tool').find('.wpwebmcp-tool-input').first().val() || '';
		runTool(tool, param, $btn);
	});

	$doc.on('submit', '#wm-cmd-form', function (e) {
		e.preventDefault();
		$('#wm-simulate-prompt-btn').trigger('click');
	});

	$doc.on('click', '#wm-simulate-prompt-btn', function (e) {
		e.preventDefault();
		var $btn = $(this);
		var prompt = ($('#wm-agent-prompt').val() || '').toLowerCase();
		var tool = 'getSiteInfo';
		var param = '';

		if (prompt.indexOf('category') !== -1 || prompt.indexOf('categories') !== -1 || prompt.indexOf('taxonomy') !== -1 || prompt.indexOf('topics') !== -1) {
			tool = 'getSiteTaxonomies';
		} else if (prompt.indexOf('product') !== -1 || prompt.indexOf('catalog') !== -1 || prompt.indexOf('shop') !== -1) {
			tool = 'getCatalogItems';
		} else if (prompt.indexOf('search') !== -1 || prompt.indexOf('find') !== -1 || prompt.indexOf('look for') !== -1) {
			tool = 'searchSite';
			param = prompt.replace(/^(search|find|look for|articles about|posts about)\s+/i, '').replace(/^(my site for|for)\s+/i, '').trim() || 'WordPress';
		} else if (prompt.indexOf('latest') !== -1 || prompt.indexOf('recent') !== -1 || prompt.indexOf('featured') !== -1) {
			tool = 'getFeaturedContent';
			param = '5';
		} else if (prompt.indexOf('read') !== -1 || prompt.indexOf('post') !== -1 || prompt.indexOf('article') !== -1) {
			tool = 'getPostContent';
			param = $('#wm-sandbox-post-select').val() || '';
		}

		setStatus('routed → ' + tool);
		runTool(tool, param, $btn);
	});

	$doc.on('click', '#wm-cmd-chips .wm-hint', function () {
		var label = $(this).text();
		if (/search/i.test(label)) {
			$('#wm-agent-prompt').val('Search my site for ').trigger('input').focus();
		} else {
			$('#wm-agent-prompt').val(label.charAt(0).toLowerCase() + label.slice(1));
			$('#wm-simulate-prompt-btn').trigger('click');
		}
	});

	$doc.on('click', '#wm-preview-md-btn', function () {
		var $btn = $(this);
		var done = busy($btn);
		setStatus('GET ?format=markdown · Accept: text/markdown');
		$timer.text('');
		$console.text('// Fetching clean semantic Markdown stream…');
		api('webmcp_gateway_preview_markdown', { post_id: $('#wm-sandbox-post-select').val() || '' }).then(function (data) {
			done();
			setStatus('HTTP 200 · text/markdown');
			$timer.text('Post #' + data.post_id);
			$console.text(data.markdown);
		}).catch(function (err) {
			done();
			setStatus('ERROR', true);
			$console.text('// ' + err.message);
		});
	});

	$doc.on('click', '#wm-console-copy', function () {
		copyText($console.text(), $(this));
	});

	$doc.on('click', '#wm-console-clear', function () {
		$console.text('// Console cleared. Run a tool to see its payload.');
		setStatus('Ready');
		$timer.text('');
	});

	/* ==================================================================
	   Settings
	   ================================================================== */
	$doc.on('input change', '#wm-settings-form input, #wm-settings-form select, #wm-settings-form textarea', function () {
		$('#wm-savebar').addClass('is-dirty');
	});

	$doc.on('input', '#wm-rate-range', function () {
		$('#webmcp_gateway_rate_limit').val($(this).val());
	});
	$doc.on('input', '#webmcp_gateway_rate_limit', function () {
		var v = Math.min(600, Math.max(10, parseInt($(this).val(), 10) || 10));
		$('#wm-rate-range').val(v);
	});

	$doc.on('click', '#wm-preset-all', function () {
		$('#wm-sec-bots .wm-bot').each(function () {
			$(this).find('input[value="allow"]').prop('checked', true);
		});
		$('#wm-savebar').addClass('is-dirty');
		toast('Preset applied: all bots allowed — remember to save.');
	});

	$doc.on('click', '#wm-preset-search', function () {
		$('#wm-sec-bots .wm-bot').each(function () {
			var $bot = $(this);
			var isTraining = $bot.find('input[value="allow"]').first().attr('name').indexOf('_gptbot') !== -1 ||
				$bot.find('input[value="allow"]').first().attr('name').indexOf('_ccbot') !== -1;
			$bot.find('input[value="' + (isTraining ? 'disallow' : 'allow') + '"]').prop('checked', true);
		});
		$('#wm-savebar').addClass('is-dirty');
		toast('Preset applied: search allowed, training blocked — remember to save.');
	});

	$doc.on('click', '#wm-copy-schema-btn', function () {
		copyText($('#wm-schema-preview-code').text(), $(this));
	});

	/* ==================================================================
	   Agent-Ready Audit
	   ================================================================== */
	var AUDIT_GROUP_LABELS = {
		publicAccess: 'Public Bot Access (edge reality)',
		discoverability: 'Discoverability',
		contentAccessibility: 'Content Accessibility',
		botAccessControl: 'Bot Access Control',
		discovery: 'API, MCP & Skill Discovery',
		commerce: 'Commerce Signals (informational)'
	};
	var AUDIT_CHECK_LABELS = {
		botUaReachability: 'Public reachability for AI crawlers (GPTBot)',
		robotsTxt: 'robots.txt', sitemap: 'Sitemap', linkHeaders: 'Agent Link headers',
		dnsAid: 'DNS-AID records', markdownNegotiation: 'Markdown for Agents',
		robotsTxtAiRules: 'AI bot rules', contentSignals: 'Content Signals', webBotAuth: 'Web Bot Auth',
		apiCatalog: 'API Catalog (RFC 9727)', oauthDiscovery: 'OAuth / OIDC discovery',
		oauthProtectedResource: 'OAuth Protected Resource', authMd: 'auth.md',
		mcpServerCard: 'MCP Server Card', a2aAgentCard: 'A2A Agent Card',
		agentSkills: 'Agent Skills index', webMcp: 'WebMCP (document.modelContext)',
		ard: 'ARD manifest (ai-catalog.json)', personalAgentProtocol: 'Personal Agent Protocol',
		x402: 'x402 payments', mpp: 'MPP payments', ucp: 'UCP profile', acp: 'ACP discovery', ap2: 'AP2 mandates'
	};

	function auditStatusMeta(status) {
		if (status === 'pass') { return { icon: 'dashicons-yes-alt', cls: 'pass', label: 'Pass' }; }
		if (status === 'fail') { return { icon: 'dashicons-warning', cls: 'fail', label: 'Fix' }; }
		if (status === 'unverified') { return { icon: 'dashicons-search', cls: 'unverified', label: 'Unverified' }; }
		return { icon: 'dashicons-info', cls: 'neutral', label: 'Info' };
	}

	var scanTheaterTimer = null;
	var SCAN_MIN_MS = 13000; // the scan visibly digs deep — never a instant blip

	function scanTheaterStages() {
		return [
			'Fetching robots.txt & sitemap',
			'Inspecting Link headers & Markdown negotiation',
			'Checking AI bot policy & Content Signals',
			'Probing /.well-known discovery documents',
			'Verifying MCP card, Agent Skills & ARD manifest',
			'Reading schema graph & speakable markup',
			'Testing AI-crawler access from the public internet',
			'Scoring & grading your site'
		];
	}

	function scanTheaterMarkup() {
		var lis = scanTheaterStages().map(function (s) { return '<li>' + esc(s) + '</li>'; }).join('');
		return '<div class="wm-scantheater">' +
			'<div class="wm-scan-radar"><div class="wm-scan-sweep"></div>' +
			'<div class="wm-scan-ring"></div><div class="wm-scan-ring wm-scan-ring--2"></div>' +
			'<span class="dashicons dashicons-shield-alt"></span></div>' +
			'<div class="wm-scan-side"><strong>Deep-scanning your site…</strong>' +
			'<p class="wm-scan-sub">Running the full 24-point agent-readiness suite against your live URLs.</p>' +
			'<ul class="wm-scan-stages" id="wm-scan-stages">' + lis + '</ul></div></div>';
	}

	function scanTheaterStart($target, heroMode) {
		scanTheaterStop();
		if (heroMode) {
			var $hero = $('.wm-hero').first();
			$hero.addClass('wm-hero--scanning');
			$hero.find('.wm-hero__gauge, #wm-onboard-card').hide();
			$hero.find('.wm-scantheater').remove();
			$hero.append(scanTheaterMarkup());
		} else {
			$target.html(scanTheaterMarkup());
		}
		var items = $('#wm-scan-stages li');
		var i = 0;
		scanTheaterTimer = setInterval(function () {
			var $items = $('#wm-scan-stages li');
			if (i > 0) { $items.eq(i - 1).removeClass('is-active').addClass('is-done'); }
			if (i < $items.length) {
				$items.eq(i).addClass('is-active');
			} else {
				$items.removeClass('is-active');
			}
			i++;
		}, Math.max(1200, Math.floor(SCAN_MIN_MS / (scanTheaterStages().length + 1))));
	}

	function scanTheaterStop() {
		if (scanTheaterTimer) { clearInterval(scanTheaterTimer); scanTheaterTimer = null; }
	}

	var lastAuditReport = null;

	function renderAuditReport(report) {
		scanTheaterStop();
		lastAuditReport = report;
		var $dl = $('#wm-audit-download');
		if ($dl.length) { $dl.removeAttr('hidden'); }
		var $summary = $('#wm-audit-summary');
		var band = report.counts.score < 60 ? 'fail' : (report.counts.score < 90 ? 'warn' : 'pass');
		$summary.html(
			'<div class="wm-xray-scorecard">' +
				'<div class="wm-gauge wm-gauge--lg wm-gauge--' + band + '" id="wm-audit-gauge" data-score="' + report.counts.score + '">' +
					'<svg viewBox="0 0 120 120" width="140" height="140" aria-hidden="true">' +
					'<circle class="wm-gauge__track" cx="60" cy="60" r="52"></circle>' +
					'<circle class="wm-gauge__arc" cx="60" cy="60" r="52"></circle></svg>' +
					'<div class="wm-gauge__center"><span class="wm-gauge__num">' + report.counts.score + '</span>' +
					'<span class="wm-gauge__cap">Agent-ready</span></div></div>' +
				'<div class="wm-audit-meta"><h3>' + esc(report.levelName) + '</h3>' +
				'<p class="wm-card__sub"><span>' + report.counts.pass + ' passing · ' + report.counts.fail + ' failing · ' + report.counts.neutral + ' informational' + (report.counts.unverified ? ' · ' + report.counts.unverified + ' unverified' : '') + '</span>' +
				' · <span>' + esc(relTime((report.scannedAt || '').replace('T', ' ').replace(/:\d\d\.\d+Z$/, ''))) + '</span></p></div>' +
			'</div>'
		);
		paintGauge($('#wm-audit-gauge'), parseFloat(report.counts.score) || 0);

		var html = '';
		$.each(report.checks, function (groupId, group) {
			var gLabel = AUDIT_GROUP_LABELS[groupId] || groupId;
			html += '<section class="wm-card wm-sec" id="wm-audit-group-' + esc(groupId) + '">' +
				'<div class="wm-card__head"><div><h3>' + esc(gLabel) + '</h3></div></div><div class="wm-fixlist">';
			$.each(group, function (checkId, check) {
				var meta = auditStatusMeta(check.status);
				var cLabel = AUDIT_CHECK_LABELS[checkId] || checkId;
				html += '<details class="wm-fixlist__item wm-fixlist__item--' + meta.cls + '" data-check="' + esc(checkId) + '">' +
					'<summary><span class="dashicons ' + meta.icon + '"></span><strong>' + esc(cLabel) + '</strong>' +
					'<span class="wm-audit-status wm-audit-status--' + meta.cls + '">' + meta.label + '</span>' +
					'<span class="wm-fixlist__chev dashicons dashicons-arrow-down-alt2"></span></summary>' +
					'<p>' + esc(check.message) + '</p></details>';
			});
			html += '</div></section>';
		});
		$('#wm-audit-groups').html(html);
	}

	function runAudit($btn) {
		// Single runner for every audit trigger (Overview hero/topbar, onboarding,
		// empty state, audit page button, auto-run). Shows the deep-scan theater
		// for a minimum duration so the user sees the work; renders inline on the
		// audit page and reloads everywhere else so the gauge updates.
		var onAuditPage = $('#wm-audit-summary').length > 0;
		var done = $btn && $btn.length ? busy($btn, 'Scanning…') : null;
		var startedAt = Date.now();
		if (onAuditPage) {
			scanTheaterStart($('#wm-audit-summary'), false);
		} else {
			scanTheaterStart($('.wm-hero').first(), true);
		}
		api('webmcp_gateway_run_audit', { force: '1' }).then(function (report) {
			var wait = Math.max(0, SCAN_MIN_MS - (Date.now() - startedAt));
			setTimeout(function () {
				scanTheaterStop();
				if (done) { done(); }
				if (onAuditPage) {
					renderAuditReport(report);
				} else {
					toast('Audit complete — score ' + report.counts.score + '/100');
					window.location.reload();
				}
			}, wait);
		}).catch(function (err) {
			scanTheaterStop();
			if (done) { done(); }
			var msg = err.message || 'Audit failed';
			if (onAuditPage) {
				$('#wm-audit-summary').html('<div class="wm-empty"><strong>Audit failed</strong><p>' + esc(msg) + '</p></div>');
			}
			toast(msg, 'error');
		});
	}

	$doc.on('click', '#wm-audit-download', function () {
		if (!lastAuditReport) { toast('Run an audit first.', 'error'); return; }
		var blob = new Blob([JSON.stringify(lastAuditReport, null, 2)], { type: 'application/json' });
		var a = document.createElement('a');
		a.href = URL.createObjectURL(blob);
		a.download = 'webmcp-agent-audit-' + new Date().toISOString().substring(0, 10) + '.json';
		a.click();
		URL.revokeObjectURL(a.href);
		toast('Detailed audit report downloaded.');
	});

	$doc.on('click', '#wm-audit-run-btn, #wm-audit-empty-run', function (e) {
		e.preventDefault();
		runAudit($(this));
	});

	// No fresh report on load -> run a REAL audit immediately and render it inline.
	if ($('#wm-audit-summary[data-auto-run="1"]').length) {
		runAudit();
	}

	$doc.on('change', '#wm-cf-optin', function () {
		var enabled = this.checked ? '1' : '0';
		api('webmcp_gateway_toggle_cf_scan', { enabled: enabled }).then(function (data) {
			$('#wm-cf-scan-btn').prop('disabled', !data.enabled);
			toast(data.enabled
				? 'External scan enabled — only your site URL is sent to isitagentready.com.'
				: 'External scan disabled — auditing stays fully local.');
		}).catch(function (err) { toast(err.message, 'error'); });
	});

	$doc.on('click', '#wm-cf-scan-btn', function () {
		var $btn = $(this);
		var done = busy($btn);
		$('#wm-cf-result').removeAttr('hidden');
		$('#wm-cf-result-code').text('// Contacting isitagentready.com — this takes about 10–20 seconds…');
		api('webmcp_gateway_cloudflare_scan').then(function (report) {
			done();
			var $code = $('#wm-cf-result-code');
			$code.html(highlightJson(JSON.stringify(report, null, 2)));
			var level = report.levelName || ('Level ' + report.level);
			toast(t('cf_verdict', 'Cloudflare verdict: %s').replace('%s', level));
		}).catch(function (err) {
			done();
			$('#wm-cf-result-code').text('// ' + err.message);
			toast(err.message, 'error');
		});
	});

	/* ==================================================================
	   MCP API key manager (Settings → MCP API access)
	   ================================================================== */
	$doc.on('click', '#wm-apikey-generate', function () {
		var $btn = $(this);
		var label = String($('#wm-apikey-label').val() || '').trim();
		if (!label) { toast(t('key_label_needed', 'Enter a label for the new key first.'), 'error'); return; }
		$btn.prop('disabled', true);
		api('webmcp_gateway_generate_api_key', { label: label }).then(function (data) {
			$btn.prop('disabled', false);
			var $box = $('#wm-apikey-result');
			var raw = String(data && data.key ? data.key : '');
			$box.removeClass('is-hidden');
			$('#wm-apikey-value').text(raw);
			if (navigator.clipboard && navigator.clipboard.writeText) {
				navigator.clipboard.writeText(raw).catch(function () { /* clipboard may be blocked; key stays visible */ });
			}
			toast(t('key_generated', 'API key generated — copied to clipboard. It will not be shown again; list refreshes in 8s.'));
			setTimeout(function () { window.location.reload(); }, 8000);
		}).catch(function (err) {
			$btn.prop('disabled', false);
			toast(err.message, 'error');
		});
	});

	$doc.on('click', '#wm-validate-schema-btn', function () {
		var $btn = $(this);
		var $out = $('#wm-schema-validation');
		$btn.prop('disabled', true);
		$out.removeAttr('hidden').html('<p>Validating…</p>');
		api('webmcp_gateway_validate_schema', {}).then(function (data) {
			$btn.prop('disabled', false);
			var html = '';
			$.each(data.results || {}, function (label, res) {
				var ok = res && res.valid;
				html += '<p><strong>' + (ok ? 'PASS' : 'FAIL') + '</strong> — ' + esc(label) + ' (' + (res.node_count || 0) + ' nodes)</p>';
				(res.errors || []).forEach(function (e) { html += '<p>· ' + esc(e) + '</p>'; });
			});
			$out.html(html || '<p>No results.</p>');
			toast('Schema validation complete.');
		}).catch(function (err) {
			$btn.prop('disabled', false);
			$out.removeAttr('hidden').html('<p>' + esc(err.message) + '</p>');
			toast(err.message, 'error');
		});
	});

	$doc.on('click', '.wm-apikey-revoke', function () {
		var $btn = $(this);
		if (!window.confirm(t('revoke_confirm', 'Revoke this API key? Clients using it will immediately lose access.'))) { return; }
		$btn.prop('disabled', true);
		api('webmcp_gateway_revoke_api_key', { hash: String($btn.attr('data-hash') || '') }).then(function () {
			toast(t('key_revoked', 'API key revoked.'));
			window.location.reload();
		}).catch(function (err) {
			$btn.prop('disabled', false);
			toast(err.message, 'error');
		});
	});

	/* ==================================================================
	   Boot
	   ================================================================== */
	$(function () {
		var $icons = $('#wm-feed');
		if ($icons.length && $icons.attr('data-icons')) {
			try { feedIcons = JSON.parse($icons.attr('data-icons')) || {}; } catch (e) { feedIcons = {}; }
		}
		initGauges();
		initPicker();

		$('.wm-stat__num[data-count]').each(function () { countUp($(this)); });

		// Highlight any pre-rendered JSON panes.
		$('.wm-code__pre--json').each(function () {
			$(this).html(highlightJson($(this).text()));
		});

		setLive($('#wm-feed-live').prop('checked'));

		/* Mobile / tablet rail toggle */
		$doc.on('click', '#wm-nav-toggle', function () {
			var $btn = $(this);
			var open = !$('.wm-app').hasClass('is-nav-open');
			$('.wm-app').toggleClass('is-nav-open', open);
			$btn.attr('aria-expanded', open ? 'true' : 'false');
		});
		$doc.on('click', '.wm-rail__item', function () {
			if (window.matchMedia('(max-width: 900px)').matches) {
				$('.wm-app').removeClass('is-nav-open');
				$('#wm-nav-toggle').attr('aria-expanded', 'false');
			}
		});
	});
})(jQuery);
