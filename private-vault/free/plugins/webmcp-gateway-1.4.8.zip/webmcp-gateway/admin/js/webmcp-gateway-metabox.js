/*! WebMCP Gateway metabox v1.4.8 — © n4nion — GPL-2.0-or-later */
(function () {
	'use strict';

	function renumber() {
		var rows = document.querySelectorAll('#webmcp-faq-rows .wm-faq-row');
		for (var i = 0; i < rows.length; i++) {
			var label = rows[i].querySelector('.wm-faq-row__qnum');
			if (label) { label.textContent = 'FAQ ' + (i + 1); }
		}
	}

	function wireRow(row) {
		var remove = row.querySelector('.wm-faq-row__remove');
		if (remove) {
			remove.addEventListener('click', function () {
				row.remove();
				renumber();
			});
		}
		var handle = row.querySelector('.wm-faq-row__handle');
		if (handle) {
			handle.addEventListener('mousedown', function () { row.setAttribute('draggable', 'true'); });
			handle.addEventListener('mouseup', function () { row.removeAttribute('draggable'); });
		}
		row.addEventListener('dragstart', function (e) {
			row.classList.add('is-dragging');
			if (e.dataTransfer) {
				e.dataTransfer.effectAllowed = 'move';
				try { e.dataTransfer.setData('text/plain', 'wm-faq'); } catch (err) { /* IE */ }
			}
		});
		row.addEventListener('dragend', function () {
			row.classList.remove('is-dragging');
			row.removeAttribute('draggable');
			renumber();
		});
		row.addEventListener('dragover', function (e) {
			if (!row.previousElementSibling) { return; }
			e.preventDefault();
		});
		row.addEventListener('drop', function (e) {
			e.preventDefault();
			var dragging = document.querySelector('#webmcp-faq-rows .wm-faq-row.is-dragging');
			if (!dragging || dragging === row) { return; }
			var rect = row.getBoundingClientRect();
			var after = (e.clientY - rect.top) > rect.height / 2;
			row.parentNode.insertBefore(dragging, after ? row.nextSibling : row);
		});
	}

	function init() {
		var list = document.getElementById('webmcp-faq-rows');
		var addBtn = document.getElementById('webmcp-faq-add');
		var template = document.getElementById('webmcp-faq-template');
		if (!list) { return; }

		Array.prototype.forEach.call(list.querySelectorAll('.wm-faq-row'), wireRow);
		renumber();

		if (addBtn && template) {
			addBtn.addEventListener('click', function () {
				var clone = template.content ? template.content.firstElementChild : null;
				if (!clone) { return; }
				var row = clone.cloneNode(true);
				list.appendChild(row);
				wireRow(row);
				renumber();
				var input = row.querySelector('.wm-faq-row__q');
				if (input) { input.focus(); }
			});
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
