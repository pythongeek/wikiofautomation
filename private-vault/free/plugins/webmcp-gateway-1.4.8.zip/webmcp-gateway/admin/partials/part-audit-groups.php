<?php
/**
 * Audit groups partial - renders the grouped check cards.
 *
 * Expects query vars: wm_audit_report (array), wm_audit_group_labels (array).
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$webmcp_gateway_audit_report = get_query_var( 'wm_audit_report' );
$webmcp_gateway_audit_labels = get_query_var( 'wm_audit_group_labels' );

if ( ! is_array( $webmcp_gateway_audit_report ) || ! isset( $webmcp_gateway_audit_report['checks'] ) ) {
	return;
}

$webmcp_gateway_audit_status_icons = array(
	'pass'    => 'dashicons-yes-alt',
	'fail'    => 'dashicons-warning',
	'neutral' => 'dashicons-info',
);

$webmcp_gateway_audit_check_labels = array(
	'robotsTxt'             => __( 'robots.txt', 'webmcp-gateway' ),
	'sitemap'               => __( 'Sitemap', 'webmcp-gateway' ),
	'linkHeaders'           => __( 'Agent Link headers', 'webmcp-gateway' ),
	'dnsAid'                => __( 'DNS-AID records', 'webmcp-gateway' ),
	'markdownNegotiation'   => __( 'Markdown for Agents', 'webmcp-gateway' ),
	'robotsTxtAiRules'      => __( 'AI bot rules', 'webmcp-gateway' ),
	'contentSignals'        => __( 'Content Signals', 'webmcp-gateway' ),
	'webBotAuth'            => __( 'Web Bot Auth', 'webmcp-gateway' ),
	'apiCatalog'            => __( 'API Catalog (RFC 9727)', 'webmcp-gateway' ),
	'oauthDiscovery'        => __( 'OAuth / OIDC discovery', 'webmcp-gateway' ),
	'oauthProtectedResource' => __( 'OAuth Protected Resource', 'webmcp-gateway' ),
	'authMd'                => __( 'auth.md', 'webmcp-gateway' ),
	'mcpServerCard'         => __( 'MCP Server Card', 'webmcp-gateway' ),
	'a2aAgentCard'          => __( 'A2A Agent Card', 'webmcp-gateway' ),
	'agentSkills'           => __( 'Agent Skills index', 'webmcp-gateway' ),
	'webMcp'                => __( 'WebMCP (document.modelContext)', 'webmcp-gateway' ),
	'ard'                   => __( 'ARD manifest (ai-catalog.json)', 'webmcp-gateway' ),
	'personalAgentProtocol' => __( 'Personal Agent Protocol', 'webmcp-gateway' ),
	'x402'                  => __( 'x402 payments', 'webmcp-gateway' ),
	'mpp'                   => __( 'MPP payments', 'webmcp-gateway' ),
	'ucp'                   => __( 'UCP profile', 'webmcp-gateway' ),
	'acp'                   => __( 'ACP discovery', 'webmcp-gateway' ),
	'ap2'                   => __( 'AP2 mandates', 'webmcp-gateway' ),
);

foreach ( $webmcp_gateway_audit_report['checks'] as $webmcp_gateway_audit_group_id => $webmcp_gateway_audit_group ) :
	$webmcp_gateway_audit_group_label = isset( $webmcp_gateway_audit_labels[ $webmcp_gateway_audit_group_id ] ) ? $webmcp_gateway_audit_labels[ $webmcp_gateway_audit_group_id ] : ucfirst( $webmcp_gateway_audit_group_id );
	?>
	<section class="wm-card wm-sec" id="wm-audit-group-<?php echo esc_attr( (string) $webmcp_gateway_audit_group_id ); ?>">
		<div class="wm-card__head">
			<div>
				<h3><?php echo esc_html( $webmcp_gateway_audit_group_label ); ?></h3>
			</div>
		</div>
		<div class="wm-fixlist">
			<?php foreach ( $webmcp_gateway_audit_group as $webmcp_gateway_audit_check_id => $webmcp_gateway_audit_check ) : ?>
				<details class="wm-fixlist__item wm-fixlist__item--<?php echo esc_attr( (string) $webmcp_gateway_audit_check['status'] ); ?>"
					data-check="<?php echo esc_attr( (string) $webmcp_gateway_audit_check_id ); ?>">
					<summary>
						<span class="dashicons <?php echo esc_attr( isset( $webmcp_gateway_audit_status_icons[ $webmcp_gateway_audit_check['status'] ] ) ? $webmcp_gateway_audit_status_icons[ $webmcp_gateway_audit_check['status'] ] : 'dashicons-marker' ); ?>"></span>
						<strong><?php echo esc_html( isset( $webmcp_gateway_audit_check_labels[ $webmcp_gateway_audit_check_id ] ) ? $webmcp_gateway_audit_check_labels[ $webmcp_gateway_audit_check_id ] : ucfirst( str_replace( array( 'A', 'Z' ), array( ' a', ' z' ), $webmcp_gateway_audit_check_id ) ) ); ?></strong>
						<span class="wm-audit-status wm-audit-status--<?php echo esc_attr( (string) $webmcp_gateway_audit_check['status'] ); ?>">
							<?php
							echo esc_html( 'pass' === $webmcp_gateway_audit_check['status'] ? __( 'Pass', 'webmcp-gateway' ) : ( 'fail' === $webmcp_gateway_audit_check['status'] ? __( 'Fix', 'webmcp-gateway' ) : __( 'Info', 'webmcp-gateway' ) ) );
							?>
						</span>
						<span class="wm-fixlist__chev dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>
					</summary>
					<p><?php echo esc_html( (string) $webmcp_gateway_audit_check['message'] ); ?></p>
				</details>
			<?php endforeach; ?>
		</div>
	</section>
	<?php
endforeach;
