<?php
/**
 * Admin View: Industry-standard Agent-Ready Audit (self-scan + optional Cloudflare scan).
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$webmcp_gateway_cf_enabled = (bool) get_option( 'webmcp_gateway_cloudflare_scan', 0 );
// Only a fresh (<=5 min, real) audit is displayed — stale reports never render.
$webmcp_gateway_cached     = WebMCP_Gateway_Agent_Audit::get_fresh_report();
$webmcp_gateway_auto_audit = ! is_array( $webmcp_gateway_cached );
$webmcp_gateway_signal     = (string) get_option( 'webmcp_gateway_content_signal', 'allow_all' );

$webmcp_gateway_group_labels = array(
	'discoverability'       => __( 'Discoverability', 'webmcp-gateway' ),
	'contentAccessibility'  => __( 'Content Accessibility', 'webmcp-gateway' ),
	'botAccessControl'      => __( 'Bot Access Control', 'webmcp-gateway' ),
	'discovery'             => __( 'API, MCP & Skill Discovery', 'webmcp-gateway' ),
	'publicAccess'          => __( 'Public Bot Access (edge reality)', 'webmcp-gateway' ),
	'commerce'              => __( 'Commerce Signals (informational)', 'webmcp-gateway' ),
);
?>

<div class="wm-audit-intro wm-card">
	<div class="wm-card__head">
		<div>
			<h3><?php esc_html_e( 'Industry-standard agent readiness', 'webmcp-gateway' ); ?></h3>
			<p class="wm-card__sub"><?php esc_html_e( 'The same checks Cloudflare\'s isitagentready.com runs — robots.txt, sitemaps, Link headers, Markdown negotiation, Content Signals, MCP cards, API catalogs, agent skills — executed locally against your own site. No data leaves your server.', 'webmcp-gateway' ); ?></p>
		</div>
		<div class="wm-card__tools">
			<button type="button" class="wm-btn wm-btn--primary" id="wm-audit-run-btn">
				<span class="dashicons dashicons-update"></span><?php echo $webmcp_gateway_cached ? esc_html__( 'Re-run audit', 'webmcp-gateway' ) : esc_html__( 'Run audit now', 'webmcp-gateway' ); ?>
			</button>
		</div>
	</div>

	<div class="wm-audit-verify">
		<label class="wm-switch wm-switch--inline" for="wm-cf-optin">
			<input type="checkbox" id="wm-cf-optin" name="webmcp_gateway_cloudflare_scan" value="1" <?php checked( $webmcp_gateway_cf_enabled ); ?>>
			<span class="wm-switch__track"><span class="wm-switch__thumb"></span></span>
			<span class="wm-switch__label"><?php esc_html_e( 'Allow external Cloudflare scan', 'webmcp-gateway' ); ?></span>
		</label>
		<p class="description"><?php esc_html_e( 'Optional. Sends only your site URL to isitagentready.com (Cloudflare\'s free scanner, no account or key) for a third-party verification report. Off = fully local auditing.', 'webmcp-gateway' ); ?></p>
		<div class="wm-audit-verify-actions">
			<button type="button" class="wm-btn wm-btn--ghost wm-btn--sm" id="wm-cf-scan-btn" <?php disabled( ! $webmcp_gateway_cf_enabled ); ?>><?php esc_html_e( 'Verify via Cloudflare', 'webmcp-gateway' ); ?></button>
			<a class="wm-btn wm-btn--ghost wm-btn--sm" href="<?php echo esc_url( 'https://isitagentready.com/' . wp_parse_url( home_url(), PHP_URL_HOST ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open public report ↗', 'webmcp-gateway' ); ?></a>
		</div>
		<div id="wm-cf-result" class="wm-code" hidden>
			<div class="wm-code__bar"><span class="wm-code__label">isitagentready.com</span></div>
			<pre class="wm-code__pre is-active wm-code__pre--json" id="wm-cf-result-code"></pre>
		</div>
	</div>
</div>

<div class="wm-audit-summary wm-card" id="wm-audit-summary"<?php echo $webmcp_gateway_auto_audit ? ' data-auto-run="1"' : ''; ?>>
	<?php if ( is_array( $webmcp_gateway_cached ) ) : ?>
		<div class="wm-xray-scorecard">
			<div class="wm-gauge wm-gauge--lg" id="wm-audit-gauge" data-score="<?php echo esc_attr( (string) $webmcp_gateway_cached['counts']['score'] ); ?>">
				<svg viewBox="0 0 120 120" width="140" height="140" aria-hidden="true">
					<circle class="wm-gauge__track" cx="60" cy="60" r="52"></circle>
					<circle class="wm-gauge__arc" cx="60" cy="60" r="52"></circle>
				</svg>
				<div class="wm-gauge__center">
					<span class="wm-gauge__num" id="wm-audit-score"><?php echo esc_html( (string) $webmcp_gateway_cached['counts']['score'] ); ?></span>
					<span class="wm-gauge__cap"><?php esc_html_e( 'Agent-ready', 'webmcp-gateway' ); ?></span>
				</div>
			</div>
			<div class="wm-audit-meta">
				<h3 id="wm-audit-level"><?php echo esc_html( (string) $webmcp_gateway_cached['levelName'] ); ?></h3>
				<p class="wm-card__sub">
					<span id="wm-audit-counts">
						<?php
						printf(
							/* translators: 1: passed, 2: failed, 3: informational */
							esc_html__( '%1$d passing · %2$d failing · %3$d informational', 'webmcp-gateway' ),
							(int) $webmcp_gateway_cached['counts']['pass'],
							(int) $webmcp_gateway_cached['counts']['fail'],
							(int) $webmcp_gateway_cached['counts']['neutral']
						);
						?>
						<?php if ( ! empty( $webmcp_gateway_cached['counts']['unverified'] ) ) {
							/* translators: %d: Number of unverified audit checks */
							echo ' · ' . esc_html( sprintf( __( '%d unverified', 'webmcp-gateway' ), (int) $webmcp_gateway_cached['counts']['unverified'] ) );
						} ?>
					</span>
					· <span id="wm-audit-timestamp"><?php
						$webmcp_audit_ago = time() - (int) $webmcp_gateway_cached['generated_at'];
						/* translators: %s: Human-readable time difference */
						echo esc_html( sprintf( __( 'live report, %s ago', 'webmcp-gateway' ), human_time_diff( (int) $webmcp_gateway_cached['generated_at'], time() ) ) );
						unset( $webmcp_audit_ago );
						?></span>
			</div>
		</div>
	<?php else : ?>
		<div class="wm-empty" id="wm-audit-empty">
			<span class="dashicons dashicons-shield wm-empty__icon" aria-hidden="true"></span>
			<strong><?php esc_html_e( 'No audit yet', 'webmcp-gateway' ); ?></strong>
			<p><?php esc_html_e( 'Run the self-audit to score your site against the industry agent-readiness checklist.', 'webmcp-gateway' ); ?></p>
			<button type="button" class="wm-btn wm-btn--primary wm-btn--sm" id="wm-audit-empty-run"><?php esc_html_e( 'Run audit now', 'webmcp-gateway' ); ?></button>
		</div>
	<?php endif; ?>
</div>

<div id="wm-audit-groups">
	<?php if ( is_array( $webmcp_gateway_cached ) ) : ?>
		<?php
		set_query_var( 'wm_audit_report', $webmcp_gateway_cached );
		set_query_var( 'wm_audit_group_labels', $webmcp_gateway_group_labels );
		include __DIR__ . '/part-audit-groups.php';
		?>
	<?php endif; ?>
</div>
