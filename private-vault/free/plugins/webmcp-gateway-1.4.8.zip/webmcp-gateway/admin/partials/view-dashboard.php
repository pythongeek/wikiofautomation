<?php
/**
 * Admin View: Overview — AEO readiness gauge, live activity feed, health checklist, endpoint inspector.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$webmcp_gateway_is_active     = (bool) get_option( 'webmcp_gateway_enabled', 1 );
$webmcp_gateway_schema_on     = (bool) get_option( 'webmcp_gateway_schema_enabled', 1 );
$webmcp_gateway_speakable_on  = (bool) get_option( 'webmcp_gateway_speakable_enabled', 1 );
$webmcp_gateway_markdown_on   = (bool) get_option( 'webmcp_gateway_markdown_enabled', 1 );
$webmcp_gateway_llmstxt_on    = (bool) get_option( 'webmcp_gateway_llmstxt_enabled', 1 );
$webmcp_gateway_permalinks_on = '' !== (string) get_option( 'permalink_structure' );
$webmcp_gateway_tagline_set   = '' !== trim( (string) get_bloginfo( 'description' ) );
$webmcp_gateway_public_site   = '0' !== (string) get_option( 'blog_public', '1' );
$webmcp_gateway_logo_ready    = ( (int) get_theme_mod( 'custom_logo' ) > 0 ) || '' !== trim( (string) get_option( 'webmcp_gateway_logo_url', '' ) ) || ( function_exists( 'get_site_icon_url' ) && '' !== (string) get_site_icon_url() );

$webmcp_gateway_counters = WebMCP_Gateway_Activity_Log::get_counters();
$webmcp_gateway_events   = WebMCP_Gateway_Activity_Log::get_events();

$webmcp_gateway_checks = array(
	array(
		'label'  => __( 'Model Context Protocol (WebMCP) Gateway & 6 Callable Read Tools', 'webmcp-gateway' ),
		'passed' => $webmcp_gateway_is_active,
		'detail' => $webmcp_gateway_is_active
			? __( 'Active — AI agents can query getSiteInfo, searchSite, getFeaturedContent, getPostContent, getSiteTaxonomies, and getCatalogItems.', 'webmcp-gateway' )
			: __( 'Disabled in Settings.', 'webmcp-gateway' ),
	),
	array(
		'label'  => __( 'Interconnected Schema.org @graph, Speakable, Auto-FAQ & WooCommerce Product Engine', 'webmcp-gateway' ),
		'passed' => $webmcp_gateway_schema_on && $webmcp_gateway_speakable_on,
		'detail' => ( $webmcp_gateway_schema_on && $webmcp_gateway_speakable_on )
			? __( 'Active — Organization, WebSite, WebPage, BreadcrumbList, Article, Product/Offer, Speakable & Auto-FAQPage are live.', 'webmcp-gateway' )
			: __( 'Partially disabled — enable both under Schema & Entity settings.', 'webmcp-gateway' ),
	),
	array(
		'label'  => __( 'Clean AI Markdown Stream (?format=markdown)', 'webmcp-gateway' ),
		'passed' => $webmcp_gateway_markdown_on,
		'detail' => $webmcp_gateway_markdown_on
			? __( 'Active — Appending ?format=markdown to any post or product serves clean LLM-ready Markdown with YAML metadata.', 'webmcp-gateway' )
			: __( 'Disabled in Settings.', 'webmcp-gateway' ),
	),
	array(
		'label'  => __( '/llms.txt & /llms-full.txt AI Corpus Index', 'webmcp-gateway' ),
		'passed' => $webmcp_gateway_llmstxt_on && $webmcp_gateway_permalinks_on,
		'detail' => $webmcp_gateway_permalinks_on
			? __( 'Active — /llms.txt and /llms-full.txt are live at your domain root.', 'webmcp-gateway' )
			: __( 'Action needed: enable pretty permalinks under Settings > Permalinks so /llms.txt routes cleanly.', 'webmcp-gateway' ),
	),
	array(
		'label'  => __( 'Publisher Brand Logo & Site Tagline', 'webmcp-gateway' ),
		'passed' => $webmcp_gateway_logo_ready && $webmcp_gateway_tagline_set,
		'detail' => ( $webmcp_gateway_logo_ready && $webmcp_gateway_tagline_set )
			? __( 'Configured — Your brand logo ImageObject and description are embedded in Schema.org.', 'webmcp-gateway' )
			: __( 'Tip: set a Site Tagline (Settings > General) and a fallback logo URL (Settings > Schema & Entity) for 100% Google validation.', 'webmcp-gateway' ),
	),
	array(
		'label'  => __( 'Search Engine & AI Answer Bot Visibility', 'webmcp-gateway' ),
		'passed' => $webmcp_gateway_public_site,
		'detail' => $webmcp_gateway_public_site
			? __( 'Public — ChatGPT Search, Perplexity, Claude, and Google AI Overviews are allowed to index your site.', 'webmcp-gateway' )
			: __( 'Warning: "Discourage search engines from indexing this site" is checked under Settings > Reading!', 'webmcp-gateway' ),
	),
);

$webmcp_gateway_passed_count = 0;
foreach ( $webmcp_gateway_checks as $webmcp_gateway_c ) {
	if ( $webmcp_gateway_c['passed'] ) {
		++$webmcp_gateway_passed_count;
	}
}

// Single source of truth for the readiness score: the industry-standard local
// audit (same cached report the Agent Audit screen renders). No second score.
$webmcp_gateway_audit      = WebMCP_Gateway_Agent_Audit::get_fresh_report();
$webmcp_gateway_audit_ok   = is_array( $webmcp_gateway_audit ) && isset( $webmcp_gateway_audit['counts']['score'] );
$webmcp_gateway_score      = $webmcp_gateway_audit_ok ? (int) $webmcp_gateway_audit['counts']['score'] : null;
$webmcp_gateway_level_name = $webmcp_gateway_audit_ok && isset( $webmcp_gateway_audit['levelName'] ) ? (string) $webmcp_gateway_audit['levelName'] : '';
$webmcp_gateway_band       = null === $webmcp_gateway_score ? 'empty' : ( $webmcp_gateway_score < 60 ? 'fail' : ( $webmcp_gateway_score < 90 ? 'warn' : 'pass' ) );

$webmcp_gateway_ev_icons = array(
	'tool_call' => 'dashicons-rest-api',
	'markdown'  => 'dashicons-format-aside',
	'llmstxt'   => 'dashicons-media-text',
	'wellknown' => 'dashicons-media-text',
	'bot_crawl' => 'dashicons-robot',
	'xray'      => 'dashicons-search',
);

$webmcp_gateway_start = admin_url( 'admin.php?page=webmcp-gateway' );
?>

<div class="wm-card wm-hero">
	<div class="wm-hero__gauge">
		<div class="wm-gauge wm-gauge--lg wm-gauge--<?php echo esc_attr( $webmcp_gateway_band ); ?>" data-score="<?php echo esc_attr( (string) $webmcp_gateway_score ); ?>">
			<svg viewBox="0 0 120 120" width="132" height="132" aria-hidden="true">
				<circle class="wm-gauge__track" cx="60" cy="60" r="52"></circle>
				<circle class="wm-gauge__arc" cx="60" cy="60" r="52"></circle>
			</svg>
			<div class="wm-gauge__center">
				<span class="wm-gauge__num"><?php echo esc_html( null === $webmcp_gateway_score ? '—' : (string) $webmcp_gateway_score . '%' ); ?></span>
				<span class="wm-gauge__cap"><?php echo esc_html( '' !== $webmcp_gateway_level_name ? $webmcp_gateway_level_name : __( 'No audit yet', 'webmcp-gateway' ) ); ?></span>
			</div>
		</div>
		<div class="wm-hero__gauge-caption">
			<strong><?php esc_html_e( 'Agent-Ready Audit Score', 'webmcp-gateway' ); ?></strong>
			<span>
			<?php if ( $webmcp_gateway_audit_ok ) : ?>
				<?php
				printf(
					/* translators: 1: Passing checks, 2: Failing checks, 3: Informational checks */
					esc_html__( '%1$d passing · %2$d failing · %3$d informational', 'webmcp-gateway' ),
					(int) $webmcp_gateway_audit['counts']['pass'],
					(int) $webmcp_gateway_audit['counts']['fail'],
					(int) $webmcp_gateway_audit['counts']['neutral']
				);
				?>
			<?php else : ?>
				<?php esc_html_e( 'Run the industry-standard audit to get your score.', 'webmcp-gateway' ); ?>
			<?php endif; ?>
			</span>
			<button type="button" class="wm-btn wm-btn--ghost wm-btn--sm" id="wm-hero-run-audit" style="margin-top:8px;"><?php esc_html_e( 'Run audit now', 'webmcp-gateway' ); ?></button>
		</div>
	</div>

	<div class="wm-hero__steps" id="wm-onboard-card">
		<button type="button" class="wm-hero__dismiss" id="wm-onboard-dismiss" aria-label="<?php esc_attr_e( 'Hide this checklist', 'webmcp-gateway' ); ?>">&times;</button>
		<h3 class="wm-hero__steps-title"><?php esc_html_e( 'Get verifiable results in 60 seconds', 'webmcp-gateway' ); ?></h3>
		<ol class="wm-steps">
			<li class="wm-steps__item">
				<div>
					<strong><?php esc_html_e( 'Run the Agent-Ready audit', 'webmcp-gateway' ); ?></strong>
					<p><?php esc_html_e( "21 industry-standard checks against your live site - the same ones Cloudflare's isitagentready.com runs.", 'webmcp-gateway' ); ?></p>
				</div>
				<button type="button" class="wm-btn wm-btn--primary wm-btn--sm" id="wm-steps-audit-btn"><?php esc_html_e( 'Run it', 'webmcp-gateway' ); ?></button>
			</li>
			<li class="wm-steps__item">
				<div>
					<strong><?php esc_html_e( 'Scan a page with the X-Ray', 'webmcp-gateway' ); ?></strong>
					<p><?php esc_html_e( 'See the 0–100 AEO grade, what AI will quote, and fix Answer-Gaps in one click.', 'webmcp-gateway' ); ?></p>
				</div>
				<a class="wm-btn wm-btn--ghost wm-btn--sm" href="<?php echo esc_url( $webmcp_gateway_start . '&tab=xray' ); ?>"><?php esc_html_e( 'Open X-Ray', 'webmcp-gateway' ); ?></a>
			</li>
			<li class="wm-steps__item">
				<div>
					<strong><?php esc_html_e( 'Set your bot policy', 'webmcp-gateway' ); ?></strong>
					<p><?php esc_html_e( 'Choose which AI crawlers may access your site and turn on the reader "Ask AI" bar.', 'webmcp-gateway' ); ?></p>
				</div>
				<a class="wm-btn wm-btn--ghost wm-btn--sm" href="<?php echo esc_url( $webmcp_gateway_start . '&tab=schema' ); ?>"><?php esc_html_e( 'Settings', 'webmcp-gateway' ); ?></a>
			</li>
		</ol>
	</div>
</div>

<div class="wm-stats wm-stats--5">
	<div class="wm-stat" title="<?php esc_attr_e( 'Total MCP tool executions recorded in the local log', 'webmcp-gateway' ); ?>">
		<span class="wm-stat__icon dashicons dashicons-rest-api"></span>
		<span class="wm-stat__num" id="wm-cnt-tools" data-count="<?php echo esc_attr( (string) ( isset( $webmcp_gateway_counters['tool_call'] ) ? $webmcp_gateway_counters['tool_call'] : 0 ) ); ?>">0</span>
		<span class="wm-stat__cap"><?php esc_html_e( 'MCP tool calls', 'webmcp-gateway' ); ?></span>
	</div>
	<div class="wm-stat" title="<?php esc_attr_e( 'Markdown streams served to agents and readers', 'webmcp-gateway' ); ?>">
		<span class="wm-stat__icon dashicons dashicons-format-aside"></span>
		<span class="wm-stat__num" id="wm-cnt-md" data-count="<?php echo esc_attr( (string) ( isset( $webmcp_gateway_counters['markdown'] ) ? $webmcp_gateway_counters['markdown'] : 0 ) ); ?>">0</span>
		<span class="wm-stat__cap"><?php esc_html_e( 'Markdown reads', 'webmcp-gateway' ); ?></span>
	</div>
	<div class="wm-stat" title="<?php esc_attr_e( '/llms.txt and /.well-known/mcp.json fetches', 'webmcp-gateway' ); ?>">
		<span class="wm-stat__icon dashicons dashicons-media-text"></span>
		<span class="wm-stat__num" id="wm-cnt-llms" data-count="<?php echo esc_attr( (string) ( ( isset( $webmcp_gateway_counters['llmstxt'] ) ? $webmcp_gateway_counters['llmstxt'] : 0 ) + ( isset( $webmcp_gateway_counters['wellknown'] ) ? $webmcp_gateway_counters['wellknown'] : 0 ) ) ); ?>">0</span>
		<span class="wm-stat__cap"><?php esc_html_e( 'Discovery reads', 'webmcp-gateway' ); ?></span>
	</div>
	<div class="wm-stat" title="<?php esc_attr_e( 'Known AI crawlers detected on public pages', 'webmcp-gateway' ); ?>">
		<span class="wm-stat__icon dashicons dashicons-robot"></span>
		<span class="wm-stat__num" id="wm-cnt-bots" data-count="<?php echo esc_attr( (string) ( isset( $webmcp_gateway_counters['bot_crawl'] ) ? $webmcp_gateway_counters['bot_crawl'] : 0 ) ); ?>">0</span>
		<span class="wm-stat__cap"><?php esc_html_e( 'AI bot visits', 'webmcp-gateway' ); ?></span>
	</div>
	<div class="wm-stat" title="<?php esc_attr_e( 'X-Ray audits run from this dashboard', 'webmcp-gateway' ); ?>">
		<span class="wm-stat__icon dashicons dashicons-search"></span>
		<span class="wm-stat__num" id="wm-cnt-xray" data-count="<?php echo esc_attr( (string) ( isset( $webmcp_gateway_counters['xray'] ) ? $webmcp_gateway_counters['xray'] : 0 ) ); ?>">0</span>
		<span class="wm-stat__cap"><?php esc_html_e( 'X-Ray audits', 'webmcp-gateway' ); ?></span>
	</div>
</div>

<div class="wm-card">
	<div class="wm-card__head">
		<div>
			<h3><?php esc_html_e( 'What happened — live agent & crawler feed', 'webmcp-gateway' ); ?></h3>
			<p class="wm-card__sub"><?php esc_html_e( 'Every AI crawler, MCP client, and sandbox call is recorded locally on your server (max 60 events, never leaves this site).', 'webmcp-gateway' ); ?></p>
		</div>
		<div class="wm-card__tools">
			<label class="wm-switch wm-switch--inline" for="wm-feed-live">
				<input type="checkbox" id="wm-feed-live" checked>
				<span class="wm-switch__track"><span class="wm-switch__thumb"></span></span>
				<span class="wm-switch__label"><?php esc_html_e( 'Live', 'webmcp-gateway' ); ?></span>
			</label>
			<button type="button" class="wm-btn wm-btn--ghost wm-btn--sm" id="wm-feed-refresh-btn">
				<span class="dashicons dashicons-update"></span><?php esc_html_e( 'Refresh', 'webmcp-gateway' ); ?>
			</button>
			<button type="button" class="wm-btn wm-btn--danger-ghost wm-btn--sm" id="wm-clear-log-btn">
				<?php esc_html_e( 'Clear log', 'webmcp-gateway' ); ?>
			</button>
		</div>
	</div>

	<div class="wm-chiprow" role="group" aria-label="<?php esc_attr_e( 'Filter feed by event type', 'webmcp-gateway' ); ?>">
		<button type="button" class="wm-filter is-active" data-filter="all"><?php esc_html_e( 'All', 'webmcp-gateway' ); ?></button>
		<button type="button" class="wm-filter" data-filter="tool_call"><?php esc_html_e( 'Tool calls', 'webmcp-gateway' ); ?></button>
		<button type="button" class="wm-filter" data-filter="markdown"><?php esc_html_e( 'Markdown', 'webmcp-gateway' ); ?></button>
		<button type="button" class="wm-filter" data-filter="discovery"><?php esc_html_e( 'Discovery', 'webmcp-gateway' ); ?></button>
		<button type="button" class="wm-filter" data-filter="bot_crawl"><?php esc_html_e( 'Bot visits', 'webmcp-gateway' ); ?></button>
		<button type="button" class="wm-filter" data-filter="xray"><?php esc_html_e( 'X-Ray', 'webmcp-gateway' ); ?></button>
	</div>

	<ol class="wm-feed" id="wm-feed" data-icons="<?php echo esc_attr( (string) wp_json_encode( $webmcp_gateway_ev_icons ) ); ?>">
		<?php if ( empty( $webmcp_gateway_events ) ) : ?>
			<li class="wm-empty" id="wm-feed-empty">
				<span class="dashicons dashicons-robot wm-empty__icon" aria-hidden="true"></span>
				<strong><?php esc_html_e( 'No AI activity yet', 'webmcp-gateway' ); ?></strong>
				<p><?php esc_html_e( 'AI crawler and agent traffic appears here as it happens - every entry is a real request your server received.', 'webmcp-gateway' ); ?></p>
				<button type="button" class="wm-btn wm-btn--primary wm-btn--sm" id="wm-empty-audit-btn"><?php esc_html_e( 'Run Agent Audit', 'webmcp-gateway' ); ?></button>
			</li>
		<?php else : ?>
			<?php foreach ( array_slice( $webmcp_gateway_events, 0, 15 ) as $webmcp_gateway_ev ) : ?>
				<?php
				$webmcp_gateway_type  = (string) ( isset( $webmcp_gateway_ev['type'] ) ? $webmcp_gateway_ev['type'] : 'info' );
				$webmcp_gateway_icon  = isset( $webmcp_gateway_ev_icons[ $webmcp_gateway_type ] ) ? $webmcp_gateway_ev_icons[ $webmcp_gateway_type ] : 'dashicons-marker';
				$webmcp_gateway_ts    = strtotime( (string) ( isset( $webmcp_gateway_ev['time'] ) ? $webmcp_gateway_ev['time'] : '' ) );
				$webmcp_gateway_diff  = $webmcp_gateway_ts ? sprintf(
					/* translators: %s: Human-readable time difference */
					__( '%s ago', 'webmcp-gateway' ),
					human_time_diff( $webmcp_gateway_ts, current_time( 'timestamp' ) )
				) : '';
				?>
				<li class="wm-feed__item" data-type="<?php echo esc_attr( $webmcp_gateway_type ); ?>">
					<span class="wm-feed__icon wm-feed__icon--<?php echo esc_attr( $webmcp_gateway_type ); ?>"><span class="dashicons <?php echo esc_attr( $webmcp_gateway_icon ); ?>"></span></span>
					<div class="wm-feed__body">
						<div class="wm-feed__meta">
							<strong><?php echo esc_html( (string) ( isset( $webmcp_gateway_ev['actor'] ) ? $webmcp_gateway_ev['actor'] : '' ) ); ?></strong>
							<time datetime="<?php echo esc_attr( (string) ( isset( $webmcp_gateway_ev['time'] ) ? $webmcp_gateway_ev['time'] : '' ) ); ?>" title="<?php echo esc_attr( (string) ( isset( $webmcp_gateway_ev['time'] ) ? $webmcp_gateway_ev['time'] : '' ) ); ?>"><?php echo esc_html( $webmcp_gateway_diff ); ?></time>
						</div>
						<code class="wm-feed__target"><?php echo esc_html( (string) ( isset( $webmcp_gateway_ev['target'] ) ? $webmcp_gateway_ev['target'] : '' ) ); ?></code>
						<p class="wm-feed__summary"><?php echo esc_html( (string) ( isset( $webmcp_gateway_ev['summary'] ) ? $webmcp_gateway_ev['summary'] : '' ) ); ?></p>
					</div>
				</li>
			<?php endforeach; ?>
		<?php endif; ?>
	</ol>
	<?php if ( count( $webmcp_gateway_events ) > 15 ) : ?>
		<button type="button" class="wm-btn wm-btn--ghost wm-btn--block" id="wm-feed-more">
			<?php
			printf(
				/* translators: %d: Number of hidden events */
				esc_html__( 'Show all %d events', 'webmcp-gateway' ),
				(int) count( $webmcp_gateway_events )
			);
			?>
		</button>
	<?php endif; ?>
</div>

<div class="wm-grid wm-grid--2">
	<div class="wm-card">
		<div class="wm-card__head">
			<div>
				<h3><?php esc_html_e( 'Sitewide health checklist', 'webmcp-gateway' ); ?></h3>
				<p class="wm-card__sub"><?php esc_html_e( 'Everything answer engines look for before they cite you.', 'webmcp-gateway' ); ?></p>
			</div>
		</div>
		<ul class="wm-checklist">
			<?php foreach ( $webmcp_gateway_checks as $webmcp_gateway_item ) : ?>
				<li class="wm-checklist__item <?php echo $webmcp_gateway_item['passed'] ? 'wm-checklist__item--pass' : 'wm-checklist__item--warn'; ?>">
					<span class="dashicons <?php echo $webmcp_gateway_item['passed'] ? 'dashicons-yes-alt' : 'dashicons-warning'; ?>"></span>
					<div>
						<strong><?php echo esc_html( $webmcp_gateway_item['label'] ); ?></strong>
						<p><?php echo esc_html( $webmcp_gateway_item['detail'] ); ?></p>
					</div>
				</li>
			<?php endforeach; ?>
		</ul>
		<div class="wm-card__foot">
			<a href="<?php echo esc_url( 'https://search.google.com/test/rich-results?url=' . rawurlencode( home_url( '/' ) ) ); ?>" target="_blank" rel="noopener noreferrer" class="wm-btn wm-btn--ghost wm-btn--sm"><?php esc_html_e( 'Google Rich Results ↗', 'webmcp-gateway' ); ?></a>
			<a href="<?php echo esc_url( 'https://validator.schema.org/#url=' . rawurlencode( home_url( '/' ) ) ); ?>" target="_blank" rel="noopener noreferrer" class="wm-btn wm-btn--ghost wm-btn--sm"><?php esc_html_e( 'Schema.org Validator ↗', 'webmcp-gateway' ); ?></a>
		</div>
	</div>

	<div class="wm-card">
		<div class="wm-card__head">
			<div>
				<h3><?php esc_html_e( 'Endpoint inspector', 'webmcp-gateway' ); ?></h3>
				<p class="wm-card__sub"><?php esc_html_e( 'Preview exactly what AI agents fetch from your domain — without leaving WordPress.', 'webmcp-gateway' ); ?></p>
			</div>
		</div>

		<div class="wm-seg wm-seg--tabs" id="wm-ep-tabs" role="tablist">
			<button type="button" class="wm-seg__btn is-active" data-endpoint="llmstxt" role="tab" aria-selected="true">/llms.txt</button>
			<button type="button" class="wm-seg__btn" data-endpoint="llmsfull" role="tab" aria-selected="false">/llms-full.txt</button>
			<button type="button" class="wm-seg__btn" data-endpoint="wellknown" role="tab" aria-selected="false">mcp.json</button>
		</div>

		<div class="wm-code">
			<div class="wm-code__bar">
				<span class="wm-code__label" id="wm-ep-label"><?php echo esc_html( home_url( '/llms.txt' ) ); ?></span>
				<button type="button" class="wm-btn wm-btn--ghost wm-btn--xs" id="wm-ep-copy"><?php esc_html_e( 'Copy', 'webmcp-gateway' ); ?></button>
			</div>
			<pre class="wm-code__pre wm-code__pre--plain" id="wm-ep-code"><?php echo esc_html( WebMCP_Gateway_LlmsTxt::generate_summary_content() ); ?></pre>
		</div>
	</div>
</div>
