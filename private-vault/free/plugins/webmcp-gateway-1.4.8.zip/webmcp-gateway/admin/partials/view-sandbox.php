<?php
/**
 * Admin View: Interactive Live Agent Sandbox (6 unlocked MCP tools).
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$webmcp_gateway_recent_posts = get_posts(
	array(
		'post_type'              => array( 'post', 'page' ),
		'post_status'            => 'publish',
		'posts_per_page'         => 15,
		'no_found_rows'          => true,
		'update_post_meta_cache' => false,
		'update_post_term_cache' => false,
	)
);
?>

<div class="wm-card">
	<form class="wm-cmd" id="wm-cmd-form" onsubmit="return false;">
		<span class="wm-cmd__chevron dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span>
		<input type="text" id="wm-agent-prompt" class="wm-cmd__input" autocomplete="off"
			value="<?php esc_attr_e( 'What is this website about and what are its latest articles?', 'webmcp-gateway' ); ?>"
			placeholder="<?php esc_attr_e( 'Type an agent prompt, e.g. search my site for… / latest articles / show categories', 'webmcp-gateway' ); ?>"
			aria-label="<?php esc_attr_e( 'Run an agent prompt', 'webmcp-gateway' ); ?>">
		<button type="submit" class="wm-btn wm-btn--primary" id="wm-simulate-prompt-btn"><?php esc_html_e( 'Run as agent', 'webmcp-gateway' ); ?></button>
	</form>
	<div class="wm-chiprow wm-chiprow--hints" id="wm-cmd-chips">
		<button type="button" class="wm-hint"><?php esc_html_e( 'Latest articles', 'webmcp-gateway' ); ?></button>
		<button type="button" class="wm-hint"><?php esc_html_e( 'Search my site for…', 'webmcp-gateway' ); ?></button>
		<button type="button" class="wm-hint"><?php esc_html_e( 'Show categories', 'webmcp-gateway' ); ?></button>
		<button type="button" class="wm-hint"><?php esc_html_e( 'Show products', 'webmcp-gateway' ); ?></button>
	</div>
</div>

<div class="wm-grid wm-grid--workbench">

	<div class="wm-workbench__tools">
		<div class="wm-tool">
			<input type="radio" name="wm-tool-sel" id="wm-tool-getsiteinfo" class="wm-tool__toggle" checked>
			<label class="wm-tool__head" for="wm-tool-getsiteinfo">
				<span class="wm-tool__badge">1</span>
				<span class="wm-tool__name">getSiteInfo</span>
				<span class="wm-tool__desc"><?php esc_html_e( 'Site identity, counts, top categories & AEO capabilities', 'webmcp-gateway' ); ?></span>
			</label>
			<div class="wm-tool__body">
				<p class="wm-tool__hint"><?php esc_html_e( 'No arguments — returns a full site profile.', 'webmcp-gateway' ); ?></p>
				<button type="button" class="wm-btn wm-btn--primary wm-btn--sm wpwebmcp-run-tool-btn" data-tool="getSiteInfo"><?php esc_html_e( 'Run tool', 'webmcp-gateway' ); ?></button>
			</div>
		</div>

		<div class="wm-tool">
			<input type="radio" name="wm-tool-sel" id="wm-tool-searchsite" class="wm-tool__toggle">
			<label class="wm-tool__head" for="wm-tool-searchsite">
				<span class="wm-tool__badge">2</span>
				<span class="wm-tool__name">searchSite</span>
				<span class="wm-tool__desc"><?php esc_html_e( 'Keyword search across posts, pages & products', 'webmcp-gateway' ); ?></span>
			</label>
			<div class="wm-tool__body">
				<input type="text" class="wm-tool__input wpwebmcp-tool-input regular-text" placeholder="<?php esc_attr_e( 'Search query (e.g. WordPress)', 'webmcp-gateway' ); ?>" value="WordPress">
				<button type="button" class="wm-btn wm-btn--primary wm-btn--sm wpwebmcp-run-tool-btn" data-tool="searchSite"><?php esc_html_e( 'Run tool', 'webmcp-gateway' ); ?></button>
			</div>
		</div>

		<div class="wm-tool">
			<input type="radio" name="wm-tool-sel" id="wm-tool-getfeatured" class="wm-tool__toggle">
			<label class="wm-tool__head" for="wm-tool-getfeatured">
				<span class="wm-tool__badge">3</span>
				<span class="wm-tool__name">getFeaturedContent</span>
				<span class="wm-tool__desc"><?php esc_html_e( 'Latest headlines, categories, reading time & summaries', 'webmcp-gateway' ); ?></span>
			</label>
			<div class="wm-tool__body">
				<label class="wm-tool__field">
					<span><?php esc_html_e( 'Max items', 'webmcp-gateway' ); ?></span>
					<input type="number" class="wm-tool__input wpwebmcp-tool-input small-text" min="1" max="10" value="5">
				</label>
				<button type="button" class="wm-btn wm-btn--primary wm-btn--sm wpwebmcp-run-tool-btn" data-tool="getFeaturedContent"><?php esc_html_e( 'Run tool', 'webmcp-gateway' ); ?></button>
			</div>
		</div>

		<div class="wm-tool">
			<input type="radio" name="wm-tool-sel" id="wm-tool-getpostcontent" class="wm-tool__toggle">
			<label class="wm-tool__head" for="wm-tool-getpostcontent">
				<span class="wm-tool__badge">4</span>
				<span class="wm-tool__name">getPostContent</span>
				<span class="wm-tool__desc"><?php esc_html_e( 'Clean Markdown, AI summary & FAQs for one post', 'webmcp-gateway' ); ?></span>
			</label>
			<div class="wm-tool__body">
				<div class="wm-postpicker">
					<select id="wm-sandbox-post-select" class="wm-tool__input wpwebmcp-tool-input">
						<?php if ( ! empty( $webmcp_gateway_recent_posts ) ) : ?>
							<?php foreach ( $webmcp_gateway_recent_posts as $webmcp_gateway_p ) : ?>
								<option value="<?php echo esc_attr( (string) $webmcp_gateway_p->ID ); ?>">
									<?php echo esc_html( sprintf( '#%d — %s', $webmcp_gateway_p->ID, wp_trim_words( wp_strip_all_tags( get_the_title( $webmcp_gateway_p ) ), 8 ) ) ); ?>
								</option>
							<?php endforeach; ?>
						<?php else : ?>
							<option value="1"><?php esc_html_e( 'Latest published post', 'webmcp-gateway' ); ?></option>
						<?php endif; ?>
					</select>
				</div>
				<div class="wm-tool__row">
					<button type="button" class="wm-btn wm-btn--primary wm-btn--sm wpwebmcp-run-tool-btn" data-tool="getPostContent"><?php esc_html_e( 'Run tool', 'webmcp-gateway' ); ?></button>
					<button type="button" class="wm-btn wm-btn--ghost wm-btn--sm" id="wm-preview-md-btn"><?php esc_html_e( 'View Markdown', 'webmcp-gateway' ); ?></button>
				</div>
			</div>
		</div>

		<div class="wm-tool">
			<input type="radio" name="wm-tool-sel" id="wm-tool-gettaxonomies" class="wm-tool__toggle">
			<label class="wm-tool__head" for="wm-tool-gettaxonomies">
				<span class="wm-tool__badge">5</span>
				<span class="wm-tool__name">getSiteTaxonomies</span>
				<span class="wm-tool__desc"><?php esc_html_e( 'Topical authority map: categories, tags & counts', 'webmcp-gateway' ); ?></span>
			</label>
			<div class="wm-tool__body">
				<p class="wm-tool__hint"><?php esc_html_e( 'No arguments needed — returns your taxonomy hierarchy.', 'webmcp-gateway' ); ?></p>
				<button type="button" class="wm-btn wm-btn--primary wm-btn--sm wpwebmcp-run-tool-btn" data-tool="getSiteTaxonomies"><?php esc_html_e( 'Run tool', 'webmcp-gateway' ); ?></button>
			</div>
		</div>

		<div class="wm-tool">
			<input type="radio" name="wm-tool-sel" id="wm-tool-getcatalog" class="wm-tool__toggle">
			<label class="wm-tool__head" for="wm-tool-getcatalog">
				<span class="wm-tool__badge">6</span>
				<span class="wm-tool__name">getCatalogItems</span>
				<span class="wm-tool__desc"><?php esc_html_e( 'WooCommerce products: price, SKU & stock status', 'webmcp-gateway' ); ?></span>
			</label>
			<div class="wm-tool__body">
				<input type="text" class="wm-tool__input wpwebmcp-tool-input regular-text" placeholder="<?php esc_attr_e( 'Optional product keyword', 'webmcp-gateway' ); ?>">
				<button type="button" class="wm-btn wm-btn--primary wm-btn--sm wpwebmcp-run-tool-btn" data-tool="getCatalogItems"><?php esc_html_e( 'Run tool', 'webmcp-gateway' ); ?></button>
			</div>
		</div>

		<div class="wm-devnote">
			<h4><span class="dashicons dashicons-editor-code" aria-hidden="true"></span><?php esc_html_e( 'Register your own tools', 'webmcp-gateway' ); ?></h4>
			<p><?php esc_html_e( 'Extend the gateway from any theme or plugin:', 'webmcp-gateway' ); ?></p>
			<code>add_filter( 'webmcp_gateway_register_tools', 'my_tools' );<br>add_filter( 'webmcp_gateway_call_tool', 'my_executor', 10, 4 );</code>
		</div>
	</div>

	<div class="wm-console">
		<div class="wm-console__bar">
			<span class="wm-console__dots" aria-hidden="true"><i></i><i></i><i></i></span>
			<span class="wm-console__chip" id="wm-status-label"><?php esc_html_e( 'Ready', 'webmcp-gateway' ); ?></span>
			<span class="wm-console__chip wm-console__chip--dim" id="wm-exec-time"></span>
			<span class="wm-console__spacer"></span>
			<button type="button" class="wm-console__btn" id="wm-console-copy"><?php esc_html_e( 'Copy', 'webmcp-gateway' ); ?></button>
			<button type="button" class="wm-console__btn" id="wm-console-clear"><?php esc_html_e( 'Clear', 'webmcp-gateway' ); ?></button>
		</div>
		<div class="wm-console__body">
			<pre class="wm-console__out" id="wm-json-viewer"><?php echo esc_html( '// ' . __( 'Click "Run tool" or "Run as agent" to inspect the exact JSON an AI agent receives from your gateway.', 'webmcp-gateway' ) ); ?></pre>
		</div>
	</div>

</div>
