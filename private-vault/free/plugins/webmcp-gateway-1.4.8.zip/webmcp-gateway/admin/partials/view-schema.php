<?php
/**
 * Admin View: AEO Schema Engine, Per-Bot AI Crawler Policy & live @graph preview.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$webmcp_gateway_sample_post = get_posts(
	array(
		'post_type'              => array( 'post', 'page' ),
		'post_status'            => 'publish',
		'posts_per_page'         => 1,
		'no_found_rows'          => true,
		'update_post_meta_cache' => false,
		'update_post_term_cache' => false,
	)
);
$webmcp_gateway_sample_id    = ! empty( $webmcp_gateway_sample_post[0] ) ? (int) $webmcp_gateway_sample_post[0]->ID : 0;
$webmcp_gateway_sample_graph = WebMCP_Gateway_Schema_Graph::generate(
	$webmcp_gateway_sample_id,
	$webmcp_gateway_sample_id > 0 ? 'single' : 'homepage'
);
// UA tokens come from definitions; display copy from translated labels.
$webmcp_gateway_bot_defs     = WebMCP_Gateway_Crawler_Policy::get_bot_matrix_definitions();
$webmcp_gateway_bot_labels   = WebMCP_Gateway_Crawler_Policy::get_bot_matrix_labels();
$webmcp_gateway_bots_search  = array(
	'webmcp_gateway_bot_oai_search',
	'webmcp_gateway_bot_chatgpt_user',
	'webmcp_gateway_bot_perplexity',
	'webmcp_gateway_bot_claude',
	'webmcp_gateway_bot_google_ext',
);
$webmcp_gateway_bots_train   = array( 'webmcp_gateway_bot_gptbot', 'webmcp_gateway_bot_ccbot' );

if ( ! function_exists( 'webmcp_gateway_render_toggle' ) ) {
	/**
	 * Render an accessible toggle switch row for a boolean setting.
	 *
	 * @param string $name  Option name.
	 * @param string $label Field label.
	 * @param string $desc  One-line explanation.
	 * @param bool   $on    Current value.
	 */
	function webmcp_gateway_render_toggle( $name, $label, $desc, $on ) {
		?>
		<div class="wm-setting">
			<div class="wm-setting__text">
				<strong><?php echo esc_html( $label ); ?></strong>
				<p><?php echo esc_html( $desc ); ?></p>
			</div>
			<label class="wm-switch">
				<?php // Hidden 0 ensures options.php clears the option when the checkbox is unchecked. ?>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="0">
				<input type="checkbox" name="<?php echo esc_attr( $name ); ?>" value="1" <?php checked( $on ); ?>>
				<span class="wm-switch__track"><span class="wm-switch__thumb"></span></span>
			</label>
		</div>
		<?php
	}
}
?>

<?php if ( isset( $_GET['settings-updated'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
	<div class="wm-saved-banner" id="wm-saved-banner">
		<h4>✓ <?php esc_html_e( 'Settings saved.', 'webmcp-gateway' ); ?></h4>
		<p><?php esc_html_e( 'Your AEO & protocol configuration is live. Endpoint and robots.txt changes are broadcast immediately.', 'webmcp-gateway' ); ?></p>
	</div>
<?php endif; ?>

<form method="post" action="options.php" id="wm-settings-form">
	<?php settings_fields( 'webmcp_gateway_settings' ); ?>

	<div class="wm-grid wm-grid--settings">

		<div class="wm-settings__main">

			<div class="wm-chiprow wm-chiprow--jump">
				<a class="wm-hint" href="#wm-sec-protocol"><?php esc_html_e( 'Protocol', 'webmcp-gateway' ); ?></a>
				<a class="wm-hint" href="#wm-sec-schema"><?php esc_html_e( 'Schema & Entity', 'webmcp-gateway' ); ?></a>
				<a class="wm-hint" href="#wm-sec-bots"><?php esc_html_e( 'Bot Policy', 'webmcp-gateway' ); ?></a>
				<a class="wm-hint" href="#wm-sec-frontend"><?php esc_html_e( 'Frontend Widgets', 'webmcp-gateway' ); ?></a>
				<a class="wm-hint" href="#wm-sec-data"><?php esc_html_e( 'Data & Limits', 'webmcp-gateway' ); ?></a>
			</div>

			<section class="wm-card wm-sec" id="wm-sec-protocol">
				<div class="wm-card__head">
					<div>
						<h3><?php esc_html_e( 'Protocol & discovery', 'webmcp-gateway' ); ?></h3>
						<p class="wm-card__sub"><?php esc_html_e( 'The core broadcast layer AI agents use to find your site.', 'webmcp-gateway' ); ?></p>
					</div>
				</div>
				<?php
				webmcp_gateway_render_toggle(
					'webmcp_gateway_enabled',
					__( 'WebMCP Protocol Gateway', 'webmcp-gateway' ),
					__( 'Discovery headers, /.well-known/mcp.json, and all 6 MCP read tools.', 'webmcp-gateway' ),
					(bool) get_option( 'webmcp_gateway_enabled', 1 )
				);
				webmcp_gateway_render_toggle(
					'webmcp_gateway_markdown_enabled',
					__( 'Semantic Markdown stream', 'webmcp-gateway' ),
					__( 'Serve clean Markdown via ?format=markdown or Accept: text/markdown.', 'webmcp-gateway' ),
					(bool) get_option( 'webmcp_gateway_markdown_enabled', 1 )
				);
				webmcp_gateway_render_toggle(
					'webmcp_gateway_llmstxt_enabled',
					__( '/llms.txt summary index', 'webmcp-gateway' ),
					__( 'Serve the llmstxt.org summary index for AI crawlers.', 'webmcp-gateway' ),
					(bool) get_option( 'webmcp_gateway_llmstxt_enabled', 1 )
				);
				webmcp_gateway_render_toggle(
					'webmcp_gateway_llmsfull_enabled',
					__( '/llms-full.txt extended corpus', 'webmcp-gateway' ),
					__( 'Also serve the extended Markdown digest of published content.', 'webmcp-gateway' ),
					(bool) get_option( 'webmcp_gateway_llmsfull_enabled', 1 )
				);
				?>
			</section>

			<section class="wm-card wm-sec" id="wm-sec-schema">
				<div class="wm-card__head">
					<div>
						<h3><?php esc_html_e( 'Schema & publisher entity', 'webmcp-gateway' ); ?></h3>
						<p class="wm-card__sub"><?php esc_html_e( 'Who you are in the knowledge graph, and what every page declares.', 'webmcp-gateway' ); ?></p>
					</div>
				</div>
				<?php
				webmcp_gateway_render_toggle(
					'webmcp_gateway_schema_enabled',
					__( 'Schema.org @graph engine', 'webmcp-gateway' ),
					__( 'Inject interconnected Organization, WebSite, WebPage, BreadcrumbList, Article & FAQPage nodes.', 'webmcp-gateway' ),
					(bool) get_option( 'webmcp_gateway_schema_enabled', 1 )
				);
				webmcp_gateway_render_toggle(
					'webmcp_gateway_woo_schema_on',
					__( 'WooCommerce Product & Offer schema', 'webmcp-gateway' ),
					__( 'Rich Product JSON-LD with SKU, price, currency, and availability on product pages.', 'webmcp-gateway' ),
					(bool) get_option( 'webmcp_gateway_woo_schema_on', 1 )
				);
				webmcp_gateway_render_toggle(
					'webmcp_gateway_auto_faq_enabled',
					__( 'Auto-FAQ from "?" headings', 'webmcp-gateway' ),
					__( 'Extract H2/H3 question headings plus their following paragraph into FAQPage JSON-LD and Markdown.', 'webmcp-gateway' ),
					(bool) get_option( 'webmcp_gateway_auto_faq_enabled', 1 )
				);
				webmcp_gateway_render_toggle(
					'webmcp_gateway_speakable_enabled',
					__( 'SpeakableSpecification', 'webmcp-gateway' ),
					__( 'Tell voice & answer engines which passages to quote.', 'webmcp-gateway' ),
					(bool) get_option( 'webmcp_gateway_speakable_enabled', 1 )
				);
				?>

				<div class="wm-setting wm-setting--stacked">
					<div class="wm-setting__text">
						<strong><label for="webmcp_gateway_speakable_css"><?php esc_html_e( 'Speakable CSS selectors', 'webmcp-gateway' ); ?></label></strong>
						<p><?php esc_html_e( 'Comma-separated selectors pointing at your headline and lead paragraph.', 'webmcp-gateway' ); ?></p>
					</div>
					<input type="text" name="webmcp_gateway_speakable_css" id="webmcp_gateway_speakable_css" class="wm-input wm-input--wide"
						value="<?php echo esc_attr( (string) get_option( 'webmcp_gateway_speakable_css', 'h1.entry-title, .entry-title, .entry-content > p:first-of-type, .wp-block-post-content > p:first-of-type, .webmcp-ai-summary' ) ); ?>">
				</div>

				<div class="wm-setting wm-setting--stacked">
					<div class="wm-setting__text">
						<strong><label for="webmcp_gateway_default_schema"><?php esc_html_e( 'Default article schema type', 'webmcp-gateway' ); ?></label></strong>
						<p><?php esc_html_e( 'Used on posts without a per-post override.', 'webmcp-gateway' ); ?></p>
					</div>
					<select id="webmcp_gateway_default_schema" name="webmcp_gateway_default_schema" class="wm-input">
						<?php $webmcp_gateway_def_schema = (string) get_option( 'webmcp_gateway_default_schema', 'BlogPosting' ); ?>
						<option value="BlogPosting" <?php selected( $webmcp_gateway_def_schema, 'BlogPosting' ); ?>><?php esc_html_e( 'BlogPosting', 'webmcp-gateway' ); ?></option>
						<option value="Article" <?php selected( $webmcp_gateway_def_schema, 'Article' ); ?>><?php esc_html_e( 'Article', 'webmcp-gateway' ); ?></option>
						<option value="NewsArticle" <?php selected( $webmcp_gateway_def_schema, 'NewsArticle' ); ?>><?php esc_html_e( 'NewsArticle', 'webmcp-gateway' ); ?></option>
						<option value="TechArticle" <?php selected( $webmcp_gateway_def_schema, 'TechArticle' ); ?>><?php esc_html_e( 'TechArticle', 'webmcp-gateway' ); ?></option>
					</select>
				</div>

				<div class="wm-setting wm-setting--stacked">
					<div class="wm-setting__text">
						<strong><label for="webmcp_gateway_entity_type"><?php esc_html_e( 'Publisher entity type', 'webmcp-gateway' ); ?></label></strong>
						<p><?php esc_html_e( 'Organization for brands & publications, Person for individual creators.', 'webmcp-gateway' ); ?></p>
					</div>
					<select id="webmcp_gateway_entity_type" name="webmcp_gateway_entity_type" class="wm-input">
						<?php $webmcp_gateway_entity_type = (string) get_option( 'webmcp_gateway_entity_type', 'Organization' ); ?>
						<option value="Organization" <?php selected( $webmcp_gateway_entity_type, 'Organization' ); ?>><?php esc_html_e( 'Organization', 'webmcp-gateway' ); ?></option>
						<option value="Person" <?php selected( $webmcp_gateway_entity_type, 'Person' ); ?>><?php esc_html_e( 'Person', 'webmcp-gateway' ); ?></option>
					</select>
				</div>

				<div class="wm-setting wm-setting--stacked">
					<div class="wm-setting__text">
						<strong><label for="webmcp_gateway_entity_name"><?php esc_html_e( 'Publisher name override', 'webmcp-gateway' ); ?></label></strong>
						<p><?php esc_html_e( 'Leave empty to use the site name.', 'webmcp-gateway' ); ?></p>
					</div>
					<input type="text" id="webmcp_gateway_entity_name" name="webmcp_gateway_entity_name" class="wm-input"
						value="<?php echo esc_attr( (string) get_option( 'webmcp_gateway_entity_name', '' ) ); ?>"
						placeholder="<?php echo esc_attr( (string) get_bloginfo( 'name' ) ); ?>">
				</div>

				<div class="wm-setting wm-setting--stacked">
					<div class="wm-setting__text">
						<strong><label for="webmcp_gateway_logo_url"><?php esc_html_e( 'Publisher logo URL (fallback)', 'webmcp-gateway' ); ?></label></strong>
						<p><?php esc_html_e( 'Used when no custom site logo is set. Falls back to your site icon.', 'webmcp-gateway' ); ?></p>
					</div>
					<input type="url" id="webmcp_gateway_logo_url" name="webmcp_gateway_logo_url" class="wm-input wm-input--wide"
						value="<?php echo esc_attr( (string) get_option( 'webmcp_gateway_logo_url', '' ) ); ?>"
						placeholder="https://example.com/wp-content/uploads/logo.png">
				</div>

				<div class="wm-setting wm-setting--stacked">
					<div class="wm-setting__text">
						<strong><label for="webmcp_gateway_same_as"><?php esc_html_e( 'Knowledge graph sameAs URLs', 'webmcp-gateway' ); ?></label></strong>
						<p><?php esc_html_e( 'One profile URL per line — LinkedIn, GitHub, X, YouTube…', 'webmcp-gateway' ); ?></p>
					</div>
					<textarea id="webmcp_gateway_same_as" name="webmcp_gateway_same_as" rows="3" class="wm-input wm-input--wide"
						placeholder="https://www.linkedin.com/company/example&#10;https://github.com/example"><?php echo esc_textarea( (string) get_option( 'webmcp_gateway_same_as', '' ) ); ?></textarea>
				</div>
			</section>

			<section class="wm-card wm-sec" id="wm-sec-bots">
				<div class="wm-card__head">
					<div>
						<h3><?php esc_html_e( 'AI bot policy (robots.txt)', 'webmcp-gateway' ); ?></h3>
						<p class="wm-card__sub"><?php esc_html_e( 'Decide per bot whether it may crawl your site. Discovery pointers (LLMs-Txt / MCP-Manifest) are always emitted.', 'webmcp-gateway' ); ?></p>
					</div>
				</div>

				<?php
				webmcp_gateway_render_toggle(
					'webmcp_gateway_robots_enabled',
					__( 'Enable virtual robots.txt policy', 'webmcp-gateway' ),
					__( 'Append per-bot rules to WordPress’s virtual robots.txt.', 'webmcp-gateway' ),
					(bool) get_option( 'webmcp_gateway_robots_enabled', 1 )
				);
				?>

				<div class="wm-setting wm-setting--stacked">
					<div class="wm-setting__text">
						<strong><label for="webmcp_gateway_content_signal"><?php esc_html_e( 'Content Signals policy', 'webmcp-gateway' ); ?></label></strong>
						<p><?php esc_html_e( 'Declares your AI usage preferences (ai-train / search / ai-input) to crawlers via the Content-Signal line in robots.txt. This is the check industry scanners score for "Bot-Aware" readiness.', 'webmcp-gateway' ); ?></p>
					</div>
					<select id="webmcp_gateway_content_signal" name="webmcp_gateway_content_signal" class="wm-input">
						<?php $webmcp_gateway_signal_current = (string) get_option( 'webmcp_gateway_content_signal', 'allow_all' ); ?>
						<?php foreach ( WebMCP_Gateway_Crawler_Policy::get_content_signal_presets() as $webmcp_gateway_signal_key => $webmcp_gateway_signal_preset ) : ?>
							<option value="<?php echo esc_attr( $webmcp_gateway_signal_key ); ?>" <?php selected( $webmcp_gateway_signal_current, $webmcp_gateway_signal_key ); ?>><?php echo esc_html( $webmcp_gateway_signal_preset['label'] ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>

				<div class="wm-chiprow wm-chiprow--presets">
					<button type="button" class="wm-hint" id="wm-preset-all"><?php esc_html_e( 'Preset: allow all (max citations)', 'webmcp-gateway' ); ?></button>
					<button type="button" class="wm-hint" id="wm-preset-search"><?php esc_html_e( 'Preset: allow search, block training', 'webmcp-gateway' ); ?></button>
				</div>

				<h4 class="wm-h4"><?php esc_html_e( 'Answer & search engines', 'webmcp-gateway' ); ?></h4>
				<div class="wm-botlist">
					<?php foreach ( $webmcp_gateway_bots_search as $webmcp_gateway_bkey ) : ?>
						<?php
						if ( empty( $webmcp_gateway_bot_defs[ $webmcp_gateway_bkey ]['ua'] ) ) {
							continue;
						}
						$webmcp_gateway_bua    = (string) $webmcp_gateway_bot_defs[ $webmcp_gateway_bkey ]['ua'];
						$webmcp_gateway_blabel = isset( $webmcp_gateway_bot_labels[ $webmcp_gateway_bkey ] )
							? (string) $webmcp_gateway_bot_labels[ $webmcp_gateway_bkey ]
							: (string) $webmcp_gateway_bot_defs[ $webmcp_gateway_bkey ]['label'];
						$webmcp_gateway_bval   = (string) get_option( $webmcp_gateway_bkey, 'allow' );
						?>
						<div class="wm-bot">
							<div class="wm-bot__id">
								<code><?php echo esc_html( $webmcp_gateway_bua ); ?></code>
								<span><?php echo esc_html( wp_strip_all_tags( $webmcp_gateway_blabel ) ); ?></span>
							</div>
							<div class="wm-seg" role="radiogroup" aria-label="<?php echo esc_attr( $webmcp_gateway_bua ); ?>">
								<label class="wm-seg__opt"><input type="radio" name="<?php echo esc_attr( $webmcp_gateway_bkey ); ?>" value="allow" <?php checked( $webmcp_gateway_bval, 'allow' ); ?>><span><?php esc_html_e( 'Allow', 'webmcp-gateway' ); ?></span></label>
								<label class="wm-seg__opt"><input type="radio" name="<?php echo esc_attr( $webmcp_gateway_bkey ); ?>" value="disallow" <?php checked( $webmcp_gateway_bval, 'disallow' ); ?>><span><?php esc_html_e( 'Block', 'webmcp-gateway' ); ?></span></label>
							</div>
						</div>
					<?php endforeach; ?>
				</div>

				<h4 class="wm-h4"><?php esc_html_e( 'Training scrapers', 'webmcp-gateway' ); ?></h4>
				<div class="wm-botlist">
					<?php foreach ( $webmcp_gateway_bots_train as $webmcp_gateway_bkey ) : ?>
						<?php
						if ( empty( $webmcp_gateway_bot_defs[ $webmcp_gateway_bkey ]['ua'] ) ) {
							continue;
						}
						$webmcp_gateway_bua    = (string) $webmcp_gateway_bot_defs[ $webmcp_gateway_bkey ]['ua'];
						$webmcp_gateway_blabel = isset( $webmcp_gateway_bot_labels[ $webmcp_gateway_bkey ] )
							? (string) $webmcp_gateway_bot_labels[ $webmcp_gateway_bkey ]
							: (string) $webmcp_gateway_bot_defs[ $webmcp_gateway_bkey ]['label'];
						$webmcp_gateway_bval   = (string) get_option( $webmcp_gateway_bkey, 'allow' );
						?>
						<div class="wm-bot">
							<div class="wm-bot__id">
								<code><?php echo esc_html( $webmcp_gateway_bua ); ?></code>
								<span><?php echo esc_html( wp_strip_all_tags( $webmcp_gateway_blabel ) ); ?></span>
							</div>
							<div class="wm-seg" role="radiogroup" aria-label="<?php echo esc_attr( $webmcp_gateway_bua ); ?>">
								<label class="wm-seg__opt"><input type="radio" name="<?php echo esc_attr( $webmcp_gateway_bkey ); ?>" value="allow" <?php checked( $webmcp_gateway_bval, 'allow' ); ?>><span><?php esc_html_e( 'Allow', 'webmcp-gateway' ); ?></span></label>
								<label class="wm-seg__opt"><input type="radio" name="<?php echo esc_attr( $webmcp_gateway_bkey ); ?>" value="disallow" <?php checked( $webmcp_gateway_bval, 'disallow' ); ?>><span><?php esc_html_e( 'Block', 'webmcp-gateway' ); ?></span></label>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</section>

			<section class="wm-card wm-sec" id="wm-sec-frontend">
				<div class="wm-card__head">
					<div>
						<h3><?php esc_html_e( 'Frontend reader widgets', 'webmcp-gateway' ); ?></h3>
						<p class="wm-card__sub"><?php esc_html_e( 'Reader-facing tools at the top of your posts. Off by default — enable what fits your audience.', 'webmcp-gateway' ); ?></p>
					</div>
				</div>
				<?php
				webmcp_gateway_render_toggle(
					'webmcp_gateway_ai_summary_render',
					__( 'Key Summary (TL;DR) callout', 'webmcp-gateway' ),
					__( 'Show the AI summary box at the top of posts. Also available anywhere via the [webmcp_ai_summary] shortcode.', 'webmcp-gateway' ),
					(bool) get_option( 'webmcp_gateway_ai_summary_render', 0 )
				);
				webmcp_gateway_render_toggle(
					'webmcp_gateway_cite_bar_render',
					__( '"Ask AI / Cite this page" bar', 'webmcp-gateway' ),
					__( 'One-click Ask ChatGPT, Cite in Perplexity, Ask Claude, and View AI Markdown buttons.', 'webmcp-gateway' ),
					(bool) get_option( 'webmcp_gateway_cite_bar_render', 0 )
				);
				?>
				<div class="wm-setting wm-setting--stacked">
					<div class="wm-setting__text">
						<strong><label for="webmcp_gateway_ai_box_theme"><?php esc_html_e( 'Widget color theme', 'webmcp-gateway' ); ?></label></strong>
						<p><?php esc_html_e( 'Auto follows the visitor’s system preference.', 'webmcp-gateway' ); ?></p>
					</div>
					<select id="webmcp_gateway_ai_box_theme" name="webmcp_gateway_ai_box_theme" class="wm-input">
						<?php $webmcp_gateway_theme = (string) get_option( 'webmcp_gateway_ai_box_theme', 'auto' ); ?>
						<option value="auto" <?php selected( $webmcp_gateway_theme, 'auto' ); ?>><?php esc_html_e( 'Auto (follow system)', 'webmcp-gateway' ); ?></option>
						<option value="light" <?php selected( $webmcp_gateway_theme, 'light' ); ?>><?php esc_html_e( 'Light', 'webmcp-gateway' ); ?></option>
						<option value="dark" <?php selected( $webmcp_gateway_theme, 'dark' ); ?>><?php esc_html_e( 'Dark', 'webmcp-gateway' ); ?></option>
					</select>
				</div>
			</section>

			<section class="wm-card wm-sec" id="wm-sec-data">
				<div class="wm-card__head">
					<div>
						<h3><?php esc_html_e( 'Data & rate limits', 'webmcp-gateway' ); ?></h3>
						<p class="wm-card__sub"><?php esc_html_e( 'Everything stays on your server. Tune how much the public API may be called.', 'webmcp-gateway' ); ?></p>
					</div>
				</div>
				<?php
				webmcp_gateway_render_toggle(
					'webmcp_gateway_activity_log_on',
					__( 'Local "What Happened" activity log', 'webmcp-gateway' ),
					__( 'Record AI bot crawls, MCP calls, and endpoint reads locally (max 60 events). Can be cleared any time.', 'webmcp-gateway' ),
					(bool) get_option( 'webmcp_gateway_activity_log_on', 1 )
				);
				?>
				<div class="wm-setting wm-setting--stacked">
					<div class="wm-setting__text">
						<strong><label for="webmcp_gateway_rate_limit"><?php esc_html_e( 'Public rate limit', 'webmcp-gateway' ); ?></label></strong>
						<p>
							<?php
							printf(
								/* translators: %d: Rate limit number */
								esc_html__( 'Maximum MCP calls per minute, per IP address (admins are never limited). Current: %d', 'webmcp-gateway' ),
								(int) get_option( 'webmcp_gateway_rate_limit', 60 )
							);
							?>
						</p>
					</div>
					<div class="wm-range">
						<input type="range" id="wm-rate-range" min="10" max="600" step="10" value="<?php echo esc_attr( (string) get_option( 'webmcp_gateway_rate_limit', 60 ) ); ?>" aria-hidden="true">
						<input type="number" id="webmcp_gateway_rate_limit" name="webmcp_gateway_rate_limit" class="wm-input wm-input--num" min="10" max="600" value="<?php echo esc_attr( (string) get_option( 'webmcp_gateway_rate_limit', 60 ) ); ?>">
					</div>
				</div>
			</section>

			<section class="wm-card wm-sec" id="wm-sec-apikeys">
				<div class="wm-card__head">
					<div>
						<h3><?php esc_html_e( 'MCP API access (optional)', 'webmcp-gateway' ); ?></h3>
						<p class="wm-card__sub"><?php esc_html_e( 'Public agent reads stay open by default — that is how AI engines discover your content. Turn on key enforcement only if you need to lock the REST API down.', 'webmcp-gateway' ); ?></p>
					</div>
				</div>
				<?php
				webmcp_gateway_render_toggle(
					'webmcp_gateway_require_api_key',
					__( 'Require API key on MCP REST endpoints', 'webmcp-gateway' ),
					__( 'When enabled, every /webmcp-gateway/v1/ call must send your key via the X-WebMCP-Key header (or api_key parameter). Logged-in admins are always allowed.', 'webmcp-gateway' ),
					(bool) get_option( 'webmcp_gateway_require_api_key', 0 )
				);
				$webmcp_api_keys = WebMCP_Gateway_REST::get_api_keys();
				?>
				<div class="wm-setting wm-setting--stacked">
					<div class="wm-setting__text">
						<strong><?php esc_html_e( 'API keys', 'webmcp-gateway' ); ?></strong>
						<p><?php esc_html_e( 'Keys are stored as SHA-256 hashes — the raw value is shown only once, right after generation.', 'webmcp-gateway' ); ?></p>
					</div>
					<?php if ( ! empty( $webmcp_api_keys ) ) : ?>
						<ul class="wm-apikey-list">
							<?php foreach ( $webmcp_api_keys as $webmcp_key_record ) : ?>
								<li>
									<span class="wm-apikey__meta">
										<strong><?php echo esc_html( '' !== (string) $webmcp_key_record['label'] ? $webmcp_key_record['label'] : __( 'Unlabeled key', 'webmcp-gateway' ) ); ?></strong>
										<span>
											<?php
											printf(
												/* translators: %s: Human-readable date */
												esc_html__( 'Created %1$s · ends in %2$s', 'webmcp-gateway' ),
												esc_html( date_i18n( get_option( 'date_format', 'F j, Y' ), (int) $webmcp_key_record['created'] ) ),
												esc_html( substr( (string) $webmcp_key_record['hash'], 0, 8 ) )
											);
											?>
										</span>
									</span>
									<button type="button" class="wm-btn wm-btn--ghost wm-btn--xs wm-apikey-revoke" data-hash="<?php echo esc_attr( (string) $webmcp_key_record['hash'] ); ?>"><?php esc_html_e( 'Revoke', 'webmcp-gateway' ); ?></button>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php else : ?>
						<p class="wm-apikey-empty"><?php esc_html_e( 'No API keys yet. Generate one, then enable enforcement above to require it.', 'webmcp-gateway' ); ?></p>
					<?php endif; ?>
					<div class="wm-apikey-controls">
						<input type="text" id="wm-apikey-label" class="wm-input" maxlength="60" placeholder="<?php esc_attr_e( 'Key label (e.g. n8n Production)', 'webmcp-gateway' ); ?>">
						<button type="button" class="wm-btn wm-btn--primary wm-btn--xs" id="wm-apikey-generate"><?php esc_html_e( 'Generate API Key', 'webmcp-gateway' ); ?></button>
					</div>
					<div class="wm-apikey-result is-hidden" id="wm-apikey-result">
						<p><strong><?php esc_html_e( 'Copy your new key now — it will not be shown again.', 'webmcp-gateway' ); ?></strong></p>
						<div class="wm-code">
							<pre class="wm-code__pre" id="wm-apikey-value"></pre>
						</div>
					</div>
				</div>
			</section>

			<div class="wm-savebar" id="wm-savebar">
				<span class="wm-savebar__msg" id="wm-savebar-msg"><?php esc_html_e( 'You have unsaved changes', 'webmcp-gateway' ); ?></span>
				<button type="submit" class="wm-btn wm-btn--primary"><?php esc_html_e( 'Save AEO & protocol settings', 'webmcp-gateway' ); ?></button>
			</div>
		</div>

		<aside class="wm-settings__aside">
			<div class="wm-card wm-card--sticky">
				<div class="wm-card__head">
					<div>
						<h3><?php esc_html_e( 'Live @graph output', 'webmcp-gateway' ); ?></h3>
						<p class="wm-card__sub"><?php esc_html_e( 'The JSON-LD currently generated for your latest post.', 'webmcp-gateway' ); ?></p>
					</div>
					<button type="button" class="wm-btn wm-btn--ghost wm-btn--xs" id="wm-validate-schema-btn"><?php esc_html_e( 'Validate', 'webmcp-gateway' ); ?></button>
					<button type="button" class="wm-btn wm-btn--ghost wm-btn--xs" id="wm-copy-schema-btn"><?php esc_html_e( 'Copy', 'webmcp-gateway' ); ?></button>
				</div>
				<div class="wm-code">
					<pre class="wm-code__pre wm-code__pre--json wm-code__pre--tall" id="wm-schema-preview-code"><?php echo esc_html( (string) wp_json_encode( $webmcp_gateway_sample_graph, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) ); ?></pre>
				<div class="wm-schema-validation" id="wm-schema-validation" hidden></div>
				</div>
			</div>
		</aside>

	</div>
</form>
