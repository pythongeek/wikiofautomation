<?php
/**
 * Admin View: Page AEO X-Ray & Answer-Gap Scanner.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$webmcp_gateway_post_types = array( 'post', 'page' );
if ( post_type_exists( 'product' ) ) {
	$webmcp_gateway_post_types[] = 'product';
}

$webmcp_gateway_posts = get_posts(
	array(
		'post_type'      => $webmcp_gateway_post_types,
		'post_status'    => 'publish',
		'posts_per_page' => 30,
		'orderby'        => 'modified',
		'order'          => 'DESC',
	)
);

// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$webmcp_gateway_selected_id = isset( $_GET['post_id'] ) ? absint( wp_unslash( $_GET['post_id'] ) ) : 0;
if ( $webmcp_gateway_selected_id <= 0 && ! empty( $webmcp_gateway_posts[0] ) ) {
	$webmcp_gateway_selected_id = (int) $webmcp_gateway_posts[0]->ID;
}

$webmcp_gateway_initial_post   = $webmcp_gateway_selected_id > 0 ? get_post( $webmcp_gateway_selected_id ) : null;
$webmcp_gateway_initial_report = ( $webmcp_gateway_initial_post instanceof WP_Post )
	? WebMCP_Gateway_Activity_Log::run_post_xray_audit( $webmcp_gateway_initial_post )
	: null;

if ( $webmcp_gateway_initial_report ) {
	$webmcp_gateway_band = $webmcp_gateway_initial_report['score'] < 60 ? 'fail' : ( $webmcp_gateway_initial_report['score'] < 90 ? 'warn' : 'pass' );
}
?>

<div class="wm-card">
	<div class="wm-pickbar">
		<label class="wm-pickbar__label" for="wm-xray-post-input"><?php esc_html_e( 'Scan target', 'webmcp-gateway' ); ?></label>
		<div class="wm-pickbar__combo wm-postpicker">
			<input type="text" id="wm-xray-post-input" class="wm-pickbar__input" autocomplete="off"
				placeholder="<?php esc_attr_e( 'Search posts, pages, products…', 'webmcp-gateway' ); ?>"
				value="<?php echo $webmcp_gateway_initial_post ? esc_attr( sprintf( '#%d — %s', $webmcp_gateway_initial_post->ID, wp_strip_all_tags( get_the_title( $webmcp_gateway_initial_post ) ) ) ) : ''; ?>">
			<input type="hidden" id="wm-xray-post-id" value="<?php echo esc_attr( (string) $webmcp_gateway_selected_id ); ?>">
			<div class="wm-pickbar__results" id="wm-xray-post-results" hidden></div>
		</div>
		<button type="button" class="wm-btn wm-btn--primary" id="wm-run-xray-btn">
			<span class="dashicons dashicons-search"></span><?php esc_html_e( 'Run X-Ray Scan', 'webmcp-gateway' ); ?>
		</button>
	</div>
</div>

<?php if ( null !== $webmcp_gateway_initial_report ) : ?>
<div id="wm-xray-results">

	<div class="wm-xray-scorecard">
		<div class="wm-gauge wm-gauge--lg wm-gauge--<?php echo esc_attr( $webmcp_gateway_band ); ?>" id="wm-xr-gauge" data-score="<?php echo esc_attr( (string) $webmcp_gateway_initial_report['score'] ); ?>">
			<svg viewBox="0 0 120 120" width="140" height="140" aria-hidden="true">
				<circle class="wm-gauge__track" cx="60" cy="60" r="52"></circle>
				<circle class="wm-gauge__arc" cx="60" cy="60" r="52"></circle>
			</svg>
			<div class="wm-gauge__center">
				<span class="wm-gauge__num" id="wm-xr-score"><?php echo esc_html( (string) $webmcp_gateway_initial_report['score'] ); ?></span>
				<span class="wm-gauge__grade" id="wm-xr-grade">Grade <?php echo esc_html( (string) $webmcp_gateway_initial_report['grade'] ); ?></span>
			</div>
		</div>
		<div class="wm-stats wm-stats--4 wm-xray-scorecard__stats">
			<div class="wm-stat">
				<span class="wm-stat__num" id="wm-xr-entities"><?php echo esc_html( (string) count( $webmcp_gateway_initial_report['entity_cards'] ) ); ?></span>
				<span class="wm-stat__cap"><?php esc_html_e( 'Schema entities', 'webmcp-gateway' ); ?></span>
			</div>
			<div class="wm-stat">
				<span class="wm-stat__num" id="wm-xr-faqs"><?php echo esc_html( (string) $webmcp_gateway_initial_report['faq_count'] ); ?></span>
				<span class="wm-stat__cap"><?php esc_html_e( 'FAQPage Q&As', 'webmcp-gateway' ); ?></span>
			</div>
			<div class="wm-stat">
				<span class="wm-stat__num" id="wm-xr-qheads"><?php echo esc_html( (string) $webmcp_gateway_initial_report['question_h_count'] ); ?></span>
				<span class="wm-stat__cap"><?php esc_html_e( '"?" headings', 'webmcp-gateway' ); ?></span>
			</div>
			<div class="wm-stat">
				<span class="wm-stat__num" id="wm-xr-words"><?php echo esc_html( (string) $webmcp_gateway_initial_report['word_count'] ); ?></span>
				<span class="wm-stat__cap"><?php esc_html_e( 'Word count', 'webmcp-gateway' ); ?></span>
			</div>
		</div>
	</div>

	<div class="wm-grid wm-grid--2">

		<div class="wm-card">
			<div class="wm-card__head">
				<div>
					<h3><?php esc_html_e( 'Speakable citation preview', 'webmcp-gateway' ); ?></h3>
					<p class="wm-card__sub"><?php esc_html_e( 'The passages AI Overviews, Perplexity, and voice assistants are instructed to quote.', 'webmcp-gateway' ); ?></p>
				</div>
			</div>

			<figure class="wm-quote">
				<blockquote class="wm-quote__body">
					<p class="wm-quote__headline" id="wm-xr-headline"><?php echo esc_html( (string) $webmcp_gateway_initial_report['speakable_headline'] ); ?></p>
					<p class="wm-quote__text" id="wm-xr-summary"><?php echo esc_html( (string) $webmcp_gateway_initial_report['speakable_summary'] ); ?></p>
					<p class="wm-quote__lead" id="wm-xr-lead"><?php echo esc_html( (string) $webmcp_gateway_initial_report['speakable_lead'] ); ?></p>
				</blockquote>
				<figcaption class="wm-quote__cite">
					<span class="wm-quote__dot" aria-hidden="true"></span>
					<span id="wm-xr-quote-source"><?php echo esc_html( wp_parse_url( home_url(), PHP_URL_HOST ) ); ?></span>
					<span class="wm-quote__cite-hint"><?php esc_html_e( 'headline · summary · lead paragraph', 'webmcp-gateway' ); ?></span>
				</figcaption>
			</figure>

			<h4 class="wm-h4"><?php esc_html_e( '5-point diagnostic', 'webmcp-gateway' ); ?></h4>
			<div id="wm-xr-checks" class="wm-fixlist">
				<?php foreach ( $webmcp_gateway_initial_report['checks'] as $webmcp_gateway_chk ) : ?>
					<details class="wm-fixlist__item wm-fixlist__item--<?php echo esc_attr( (string) $webmcp_gateway_chk['status'] ); ?>">
						<summary>
							<span class="dashicons <?php echo 'pass' === $webmcp_gateway_chk['status'] ? 'dashicons-yes-alt' : 'dashicons-warning'; ?>"></span>
							<strong><?php echo esc_html( (string) $webmcp_gateway_chk['title'] ); ?></strong>
							<span class="wm-fixlist__chev dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>
						</summary>
						<p><?php echo esc_html( (string) $webmcp_gateway_chk['advice'] ); ?></p>
					</details>
				<?php endforeach; ?>
			</div>

			<div class="wm-card__foot">
				<a id="wm-xr-edit-btn" href="<?php echo esc_url( (string) $webmcp_gateway_initial_report['edit_url'] ); ?>" class="wm-btn wm-btn--primary wm-btn--sm"><?php esc_html_e( 'Edit AEO summary & FAQs', 'webmcp-gateway' ); ?></a>
				<a id="wm-xr-google-btn" href="<?php echo esc_url( (string) $webmcp_gateway_initial_report['rich_results_url'] ); ?>" target="_blank" rel="noopener noreferrer" class="wm-btn wm-btn--ghost wm-btn--sm"><?php esc_html_e( 'Google test ↗', 'webmcp-gateway' ); ?></a>
				<a id="wm-xr-schema-btn" href="<?php echo esc_url( (string) $webmcp_gateway_initial_report['schema_val_url'] ); ?>" target="_blank" rel="noopener noreferrer" class="wm-btn wm-btn--ghost wm-btn--sm"><?php esc_html_e( 'Validate ↗', 'webmcp-gateway' ); ?></a>
			</div>
		</div>

		<div class="wm-card">
			<div class="wm-card__head">
				<div>
					<h3><?php esc_html_e( 'Answer-Gap finder', 'webmcp-gateway' ); ?></h3>
					<p class="wm-card__sub"><?php esc_html_e( 'High-intent questions users ask AI about this topic. Edit the answers, pick which to publish, then inject.', 'webmcp-gateway' ); ?></p>
				</div>
			</div>

			<div id="wm-xr-gaps" class="wm-gaplist">
				<?php foreach ( $webmcp_gateway_initial_report['answer_gaps'] as $webmcp_gateway_gap ) : ?>
					<label class="wm-gap">
						<span class="wm-gap__select">
							<input type="checkbox" class="wm-gap__check" checked>
						</span>
						<span class="wm-gap__body">
							<span class="wm-gap__intent"><?php echo esc_html( (string) $webmcp_gateway_gap['intent'] ); ?></span>
							<strong class="wm-gap__q"><?php echo esc_html( (string) $webmcp_gateway_gap['q'] ); ?></strong>
							<textarea class="wm-gap__a" rows="2"><?php echo esc_textarea( (string) $webmcp_gateway_gap['a_hint'] ); ?></textarea>
						</span>
					</label>
				<?php endforeach; ?>
			</div>

			<button type="button" class="wm-btn wm-btn--primary wm-btn--block" id="wm-inject-gaps-btn">
				<span class="dashicons dashicons-superhero"></span><span id="wm-inject-gaps-label"><?php esc_html_e( 'Inject checked FAQs into schema (+20 pts)', 'webmcp-gateway' ); ?></span>
			</button>

			<h4 class="wm-h4"><?php esc_html_e( 'Connected @graph entities', 'webmcp-gateway' ); ?></h4>
			<div id="wm-xr-entity-pills" class="wm-pills">
				<?php foreach ( $webmcp_gateway_initial_report['entity_cards'] as $webmcp_gateway_ec ) : ?>
					<span class="wm-pill"><?php echo esc_html( (string) $webmcp_gateway_ec['type'] ); ?></span>
				<?php endforeach; ?>
			</div>

			<h4 class="wm-h4"><?php esc_html_e( 'Agent output', 'webmcp-gateway' ); ?></h4>
			<div class="wm-code" id="wm-xr-codeviewer">
				<div class="wm-code__bar">
					<div class="wm-code__tabs" role="tablist">
						<button type="button" class="wm-code__tab is-active" data-tab="markdown" role="tab" aria-selected="true"><?php esc_html_e( 'Markdown', 'webmcp-gateway' ); ?></button>
						<button type="button" class="wm-code__tab" data-tab="jsonld" role="tab" aria-selected="false">JSON-LD</button>
					</div>
					<button type="button" class="wm-btn wm-btn--ghost wm-btn--xs" id="wm-xr-copy"><?php esc_html_e( 'Copy', 'webmcp-gateway' ); ?></button>
				</div>
				<pre class="wm-code__pre is-active wm-code__pre--plain" data-pane="markdown"><?php echo esc_html( (string) $webmcp_gateway_initial_report['markdown_preview'] ); ?></pre>
				<pre class="wm-code__pre wm-code__pre--json" data-pane="jsonld"><?php echo esc_html( (string) $webmcp_gateway_initial_report['schema_json'] ); ?></pre>
			</div>
		</div>

	</div>
</div>
<?php endif; ?>
