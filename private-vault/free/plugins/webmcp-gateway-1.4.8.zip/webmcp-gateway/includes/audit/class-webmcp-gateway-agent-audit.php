<?php
/**
 * Agent-Ready Audit Engine - WebMCP Gateway.
 *
 * Replicates the industry-standard agent-readiness checks (as published by
 * Cloudflare's "Is Your Site Agent-Ready?" scanner, isitagentready.com) as a
 * 100% local self-audit, and can optionally relay a scan through Cloudflare's
 * free public endpoint when the site owner explicitly opts in.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


if ( ! class_exists( 'WebMCP_Gateway_Agent_Audit' ) ) {
	/**
	 * Runs the agent-readiness self-audit against the site's own public URLs.
	 */
	final class WebMCP_Gateway_Agent_Audit {

		/**
		 * Cloudflare public scan endpoint (documented in readme; opt-in only).
		 */
		const CF_ENDPOINT = 'https://isitagentready.com/api/scan';

		/**
		 * Relation types considered agent-useful by industry scanners.
		 *
		 * @var string[]
		 */
		private static $agent_rels = array( 'api-catalog', 'service-desc', 'service-doc', 'describedby', 'a2a', 'agent-card', 'ai-catalog' );

		/**
		 * Register AJAX handlers.
		 *
		 * @return void
		 */
		public static function init() {
			WebMCP_Gateway_Loader::register_action( 'wp_ajax_webmcp_gateway_run_audit', array( __CLASS__, 'ajax_run_audit' ) );
			WebMCP_Gateway_Loader::register_action( 'wp_ajax_webmcp_gateway_cloudflare_scan', array( __CLASS__, 'ajax_cloudflare_scan' ) );
			WebMCP_Gateway_Loader::register_action( 'wp_ajax_webmcp_gateway_toggle_cf_scan', array( __CLASS__, 'ajax_toggle_cf_scan' ) );
		}

		/**
		 * AJAX: toggle the external Cloudflare scan opt-in.
		 *
		 * @return void
		 */
		public static function ajax_toggle_cf_scan() {
			check_ajax_referer( 'webmcp_gateway_sandbox_nonce', 'nonce' );
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'error' => __( 'Unauthorized access.', 'webmcp-gateway' ) ), 403 );
			}
			$enabled = isset( $_POST['enabled'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['enabled'] ) );
			update_option( 'webmcp_gateway_cloudflare_scan', $enabled ? 1 : 0 );
			wp_send_json_success( array( 'enabled' => $enabled ) );
		}

		/**
		 * AJAX: run the local self-audit (cached 30 minutes).
		 *
		 * @return void
		 */
		public static function ajax_run_audit() {
			check_ajax_referer( 'webmcp_gateway_sandbox_nonce', 'nonce' );
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'error' => __( 'Unauthorized access.', 'webmcp-gateway' ) ), 403 );
			}
			$throttle = WebMCP_Gateway_Admin::throttle_ajax( 'audit', 30 );
			if ( is_wp_error( $throttle ) ) {
				wp_send_json_error( array( 'error' => $throttle->get_error_message() ), 429 );
			}
			$force = isset( $_POST['force'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['force'] ) );
			if ( ! $force ) {
				$fresh = self::get_fresh_report();
				if ( is_array( $fresh ) ) {
					$fresh['cached'] = true;
					wp_send_json_success( $fresh );
				}
			}
			$report = self::run_local_audit();
			set_transient( 'webmcp_gateway_audit_cache', $report, 5 * MINUTE_IN_SECONDS );
			$report['cached'] = false;
			wp_send_json_success( $report );
		}

		/**
		 * AJAX: relay an opt-in scan through Cloudflare's free public scanner.
		 *
		 * @return void
		 */
		public static function ajax_cloudflare_scan() {
			check_ajax_referer( 'webmcp_gateway_sandbox_nonce', 'nonce' );
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( array( 'error' => __( 'Unauthorized access.', 'webmcp-gateway' ) ), 403 );
			}
			$throttle = WebMCP_Gateway_Admin::throttle_ajax( 'cfscan', 10 );
			if ( is_wp_error( $throttle ) ) {
				wp_send_json_error( array( 'error' => $throttle->get_error_message() ), 429 );
			}
			if ( ! (bool) get_option( 'webmcp_gateway_cloudflare_scan', 0 ) ) {
				wp_send_json_error( array( 'error' => __( 'Enable "External Cloudflare scan" in Settings > Agent-Ready Audit first — no data leaves your site until you opt in.', 'webmcp-gateway' ) ), 403 );
			}

			$url = home_url( '/' );
			$raw = self::cloudflare_scan( $url );
			if ( is_wp_error( $raw ) ) {
				wp_send_json_error( array( 'error' => $raw->get_error_message() ) );
			}
			set_transient( 'webmcp_gateway_cf_scan_cache', $raw, 30 * MINUTE_IN_SECONDS );
			wp_send_json_success( $raw );
		}

		/**
		 * Call Cloudflare's free public scanner for a URL.
		 *
		 * @param string $url Site URL to scan.
		 * @return array|WP_Error
		 */
		public static function cloudflare_scan( $url ) {
			$response = wp_remote_post(
				self::CF_ENDPOINT,
				array(
					'timeout'    => 45,
					'headers'    => array( 'Content-Type' => 'application/json' ),
					'body'       => wp_json_encode( array( 'url' => $url ) ),
					'data_format' => 'body',
				)
			);
			if ( is_wp_error( $response ) ) {
				return $response;
			}
			$code = (int) wp_remote_retrieve_response_code( $response );
			$body = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( 200 !== $code || ! is_array( $body ) ) {
				return new WP_Error(
					'webmcp_cf_scan_failed',
					sprintf(
						/* translators: %d: HTTP status code */
						__( 'Cloudflare scanner returned HTTP %d. Try again in a moment.', 'webmcp-gateway' ),
						$code
					)
				);
			}
			return $body;
		}

		/**
		 * Run the local self-audit. Only the site's own public URLs are requested.
		 *
		 * @return array
		 */
		public static function run_local_audit() {
			$home    = home_url( '/' );
			$started = microtime( true );
			$checks  = array();

			// Loopback health probe: many hosts (WAF / page cache / anti-bot rules)
			// block a server's own HTTP requests while the same URLs work from the
			// public internet. When the probe fails, feature checks fall back to
			// local plugin evidence and are reported as such — never invented.
			$loopback_dead = self::loopback_blocked();

			// --- Discoverability -------------------------------------------------
			$robots = self::fetch( $home . 'robots.txt' );
			$checks['discoverability']['robotsTxt'] = self::check_robots_txt( $robots );
			$checks['discoverability']['sitemap']   = self::check_sitemap( $home, is_array( $robots ) ? (string) $robots['body'] : '' );
			$checks['discoverability']['linkHeaders'] = self::check_link_headers( is_array( $robots ) ? ( $robots['headers'] ?? array() ) : array(), $home );
			// DNS-AID: perform a real lookup of the discovery SVCB/TXT record.
			$host  = wp_parse_url( $home, PHP_URL_HOST );
			$found = false;
			if ( $host && function_exists( 'dns_get_record' ) ) {
				$records = @dns_get_record( $host, DNS_ALL );
				if ( is_array( $records ) ) {
					foreach ( $records as $record ) {
						if ( ! empty( $record['txt'] ) && false !== stripos( (string) $record['txt'], 'ai' ) ) {
							$found = true;
							break;
						}
					}
				}
			}
			if ( $found ) {
				$checks['discoverability']['dnsAid'] = array(
					'status'  => 'pass',
					'message' => __( 'AI discovery DNS record found for this domain.', 'webmcp-gateway' ),
				);
			} else {
				$checks['discoverability']['dnsAid'] = array(
					'status'  => 'fail',
					'message' => __( 'DNS for AI Discovery (DNS-AID) records not found. Publish an AI-discovery record in your DNS zone (ask your DNS host).', 'webmcp-gateway' ),
				);
			}
			$checks['discoverability']['dnsAid'] = array(
				'status'  => 'fail',
				'message' => __( 'DNS for AI Discovery (DNS-AID) records not found. Publish an AI-discovery record in your DNS zone (ask your DNS host).', 'webmcp-gateway' ),
			);

			// --- Content accessibility -------------------------------------------
			$checks['contentAccessibility']['markdownNegotiation'] = self::check_markdown_negotiation( $home );

			// --- Bot access control ----------------------------------------------
			$checks['botAccessControl']['robotsTxtAiRules'] = self::check_bot_rules( is_array( $robots ) ? (string) $robots['body'] : '' );
			$checks['botAccessControl']['contentSignals']   = self::check_content_signals( is_array( $robots ) ? (string) $robots['body'] : '' );
			$checks['botAccessControl']['webBotAuth'] = self::neutral(
				__( 'Web Bot Auth requires cryptographic message-signing keys — informational only for read-only content gateways.', 'webmcp-gateway' )
			);

			// --- API / MCP / skill discovery --------------------------------------
			$checks['discovery']['apiCatalog']    = self::check_wellknown_json( $home . '.well-known/api-catalog', array( 'linkset' ), __( 'API Catalog (RFC 9727)', 'webmcp-gateway' ), 'api_catalog' );
			$checks['discovery']['oauthDiscovery'] = self::neutral(
				__( 'OAuth/OIDC discovery applies when your agent APIs require user-delegated auth. This gateway is public and read-only.', 'webmcp-gateway' )
			);
			$checks['discovery']['oauthProtectedResource'] = self::neutral(
				__( 'No protected resources are exposed; OAuth Protected Resource Metadata is not applicable.', 'webmcp-gateway' )
			);
			$checks['discovery']['authMd'] = self::check_auth_md( $home );
			$checks['discovery']['mcpServerCard'] = self::check_mcp_card( $home );
			$checks['discovery']['a2aAgentCard'] = self::neutral(
				__( 'A2A Agent Cards describe task-delegating agents. This site exposes read-only tools, so it is optional.', 'webmcp-gateway' )
			);
			$checks['discovery']['agentSkills'] = self::check_agent_skills( $home );
			$checks['discovery']['webMcp'] = self::check_webmcp_bridge();
			$checks['discovery']['ard'] = self::check_wellknown_json( $home . '.well-known/ai-catalog.json', array( 'entries' ), __( 'Agentic Resource Discovery (ARD) manifest', 'webmcp-gateway' ), 'ai_catalog' );
			$checks['discovery']['personalAgentProtocol'] = self::neutral(
				__( 'The Personal Agent Protocol applies to individual personal sites; optional for publications and stores.', 'webmcp-gateway' )
			);

			// --- Commerce (informational for this gateway) -------------------------
			// --- Public bot access (edge reality) ---------------------------------
			// A browser-UA fetch can succeed even when the host's edge blocks AI
			// crawler user agents (bot filters answer 429/403 before WordPress
			// loads). External scanners and AI engines see that block, so the audit
			// must verify the key endpoints exactly as an AI crawler would.
			$checks['publicAccess']['botUaReachability'] = self::check_bot_ua_access( $home );

			$commerce_note = __( 'Payment and commerce agent protocols (x402, MPP, UCP, ACP, AP2) are out of scope for a content/MCP gateway. If you run agentic checkout, look at WooCommerce agent extensions.', 'webmcp-gateway' );
			foreach ( array( 'x402', 'mpp', 'ucp', 'acp', 'ap2' ) as $commerce_id ) {
				$checks['commerce'][ $commerce_id ] = self::neutral( $commerce_note );
			}

			// If self-requests are blocked, checks that could not be re-verified live
			// are marked 'unverified' — they are shown honestly as UNVERIFIED and do
			// NOT count as passes. No simulated or assumed results, ever.
			if ( $loopback_dead && class_exists( 'WebMCP_Gateway_Frontend' ) && WebMCP_Gateway_Frontend::is_enabled() ) {
				$evidence_ids = array(
					'discoverability' => array( 'linkHeaders' ),
					'contentAccessibility' => array( 'markdownNegotiation' ),
					'discovery' => array( 'apiCatalog', 'authMd', 'mcpServerCard', 'agentSkills', 'ard' ),
				);
				foreach ( $evidence_ids as $group_key => $ids ) {
					foreach ( $ids as $id ) {
						if ( isset( $checks[ $group_key ][ $id ] ) && 'fail' === $checks[ $group_key ][ $id ]['status'] ) {
							$checks[ $group_key ][ $id ]['status'] = 'unverified';
							$checks[ $group_key ][ $id ]['message'] = __( 'This server blocks its own HTTP requests (loopback), so this could not be verified live. The feature is active in the plugin — verify externally via "Verify via Cloudflare".', 'webmcp-gateway' );
						}
					}
				}
			}

			return self::summarize( $checks, round( microtime( true ) - $started, 2 ) );
		}

		/**
		 * Build the normalized report with counts, score, and level hint.
		 *
		 * @param array $checks Grouped checks.
		 * @param float $took   Seconds elapsed.
		 * @return array
		 */
		private static function summarize( $checks, $took ) {
			$pass = 0;
			$fail = 0;
			$neutral = 0;
			foreach ( $checks as $group ) {
				foreach ( $group as $check ) {
					if ( 'pass' === $check['status'] ) {
						++$pass;
					} elseif ( 'fail' === $check['status'] ) {
						++$fail;
					} else {
						++$neutral;
					}
				}
			}
			// Industry-strict scoring (matches external scanners like isitagentready):
			// every check counts. pass=1, everything else (fail/unverified/neutral)
			// scores 0 — a missing capability is a missing capability, whether it is
			// 'not applicable' or genuinely absent. Unverified is reported separately.
			$score = $pass + $fail + $neutral > 0 ? (int) round( $pass / ( $pass + $fail + $neutral ) * 100 ) : 0;
			$level   = 1;
			$level_name = __( 'Basic Web Presence', 'webmcp-gateway' );
			if ( $pass >= 8 ) {
				$level = 2;
				/* translators: Industry readiness level name */
				$level_name = __( 'Bot-Aware', 'webmcp-gateway' );
			}
			if ( $pass >= 12 ) {
				$level = 3;
				/* translators: Industry readiness level name */
				$level_name = __( 'Agent-Discoverable', 'webmcp-gateway' );
			}
			if ( $pass >= 16 ) {
				$level = 4;
				/* translators: Industry readiness level name */
				$level_name = __( 'Fully Agent-Ready', 'webmcp-gateway' );
			}
			$unverified = 0;
			foreach ( $checks as $group ) {
				foreach ( $group as $check ) {
					if ( 'unverified' === $check['status'] ) {
						++$unverified;
					}
				}
			}

			return array(
				'source'   => 'local',
				'url'      => home_url( '/' ),
				'took'     => $took,
				'checks'   => $checks,
				'counts'   => array(
					'pass'       => $pass,
					'fail'       => $fail,
					'neutral'    => $neutral,
					'unverified' => $unverified,
					'score'      => $score,
				),
				'level'    => $level,
				'levelName' => $level_name,
				'scannedAt' => gmdate( 'c' ),
				'generated_at' => time(),
			);
		}

		/**
		 * Neutral / informational check helper.
		 *
		 * @param string $message Explanation.
		 * @return array
		 */
		private static function neutral( $message ) {
			return array(
				'status'  => 'neutral',
				'message' => $message,
			);
		}

		/**
		 * Fetch a public URL of this site (loopback).
		 *
		 * @param string $url Absolute URL.
		 * @return array{body:string,headers:array,status:int}|null
		 */
		/**
		 * Return the cached audit report ONLY when it is real and fresh.
		 *
		 * Fresh means: carries a generated_at stamp (reports from older plugin
		 * versions are ignored, never displayed) and is younger than 5 minutes.
		 * Views never show stale numbers — they trigger a live run instead.
		 *
		 * @return array|null
		 */
		public static function get_fresh_report() {
			$report = get_transient( 'webmcp_gateway_audit_cache' );
			if ( ! is_array( $report ) || ! isset( $report['generated_at'] ) ) {
				return null;
			}
			$age = time() - (int) $report['generated_at'];
			if ( $age < 0 || $age > 5 * MINUTE_IN_SECONDS ) {
				return null;
			}
			return $report;
		}

		/**
		 * Detect whether this server can make HTTP requests to itself.
		 *
		 * Probes a public, cache-free plugin endpoint. A non-200 from the server
		 * to itself (while the endpoint is publicly routed) means audit checks
		 * that rely on loopback HTTP cannot be verified live.
		 *
		 * @return bool True when self-requests appear blocked.
		 */
		public static function loopback_blocked() {
			$probe_url = add_query_arg( 'webmcp_loopback_probe', (string) time(), rest_url( 'webmcp-gateway/v1/tools' ) );
			$probe     = self::fetch_robust( $probe_url );
			if ( null === $probe ) {
				return true;
			}
			return 200 !== (int) $probe['status'];
		}

		/**
		 * Verify the key discovery endpoints are reachable with a REAL AI-crawler
		 * user agent from the server (edge reality check).
		 *
		 * @param string $home Home URL.
		 * @return array
		 */
		public static function check_bot_ua_access( $home ) {
			$targets = array(
				'robots.txt'                => __( 'robots.txt', 'webmcp-gateway' ),
				'.well-known/mcp.json'      => __( 'MCP Server Card', 'webmcp-gateway' ),
				'llms.txt'                  => __( 'llms.txt index', 'webmcp-gateway' ),
				'.well-known/agent-skills/index.json' => __( 'Agent Skills index', 'webmcp-gateway' ),
			);
			$bot_ua  = 'GPTBot/1.0 (+https://openai.com/gptbot)';
			$blocked = array();

			foreach ( $targets as $path => $label ) {
				// Space the probes out slightly so the audit measures real blocking
				// instead of tripping per-second edge rate limits itself.
				if ( ! headers_sent() ) { usleep( 350000 ); }
				$res = self::fetch_as_bot( $home . $path, $bot_ua );
				if ( null === $res ) {
					$blocked[] = $label . ' (connection failed)';
					continue;
				}
				if ( 200 !== (int) $res['status'] ) {
					$blocked[] = sprintf( /* translators: 1: label, 2: HTTP code */ __( '%1$s (HTTP %2$d)', 'webmcp-gateway' ), $label, (int) $res['status'] );
				}
			}

			if ( empty( $blocked ) ) {
				return array(
					'status'  => 'pass',
					'message' => __( 'AI crawler user agents (GPTBot) can reach robots.txt, the MCP card, llms.txt and the Agent Skills index from the public internet.', 'webmcp-gateway' ),
				);
			}

			return array(
				'status'  => 'fail',
				'message' => sprintf(
					/* translators: %s: Comma-separated blocked endpoint list */
					__( 'Your host/CDN edge BLOCKS AI-crawler user agents before WordPress loads. AI engines receive errors and cannot read: %s. Fix: allow AI-crawler user agents (GPTBot, ClaudeBot, PerplexityBot, OAI-SearchBot) in your host security / LiteSpeed bot settings, then re-run this audit and verify externally.', 'webmcp-gateway' ),
					implode( ', ', $blocked )
				),
			);
		}

		/**
		 * Single-attempt fetch with an AI-crawler user agent (NO browser retry —
			* the whole point is to see what a bot sees).
		 *
		 * @param string $url Target URL.
		 * @param string $ua  User agent to send.
		 * @return array|null{status:int,body:string,headers:array}
		 */
		public static function fetch_as_bot( $url, $ua ) {
			$response = wp_remote_get(
				$url,
				array(
					'timeout'     => 12,
					'redirection' => 2,
					'headers'     => array( 'Accept' => 'text/html,application/json,text/plain,*/*' ),
					'user-agent'  => $ua,
				)
			);
			if ( is_wp_error( $response ) ) {
				return null;
			}
			return array(
				'status'  => (int) wp_remote_retrieve_response_code( $response ),
				'body'    => (string) wp_remote_retrieve_body( $response ),
				'headers' => wp_remote_retrieve_headers( $response ),
			);
		}

		/**
		 * Fetch with retries: default UA first, then a browser-like UA for hosts
		 * whose WAF/anti-bot rules reject the default WordPress user agent.
		 *
		 * @param string $url   Target URL.
		 * @param string $accept Optional Accept header value.
		 * @return array|null{status:int,body:string,headers:array}
		 */
		private static function fetch_robust( $url, $accept = null ) {
			$attempts = array(
				null,
				'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36',
			);
			$last = null;
			foreach ( $attempts as $ua ) {
				$args = array(
					'timeout'     => 12,
					'redirection' => 2,
					'headers'     => array( 'Accept' => null !== $accept ? $accept : 'text/html,application/json,text/plain,*/*' ),
				);
				if ( null !== $ua ) {
					$args['user-agent'] = $ua;
				}
				$response = wp_remote_get( $url, $args );
				if ( is_wp_error( $response ) ) {
					$last = null;
					continue;
				}
				$last = array(
					'status'  => (int) wp_remote_retrieve_response_code( $response ),
					'body'    => (string) wp_remote_retrieve_body( $response ),
					'headers' => wp_remote_retrieve_headers( $response ),
				);
				if ( 200 === $last['status'] ) {
					return $last;
				}
			}
			return $last;
		}

		private static function fetch( $url ) {
			// Delegate to the retrying fetcher: default UA first, then a browser UA
			// for hosts whose WAF rejects WordPress's own user agent.
			return self::fetch_robust( $url );
		}

		/**
		 * Fetch with an Accept header (content negotiation test).
		 *
		 * @param string $url   Absolute URL.
		 * @param string $accept Accept header value.
		 * @return array|null
		 */
		private static function fetch_accept( $url, $accept ) {
			// Same retrying behavior as fetch(), with the requested Accept header.
			$result = self::fetch_robust( $url, $accept );
			// A page cache can return 200 text/html for the default UA even when the
			// live response negotiates correctly — retry once with a browser UA.
			if ( is_array( $result ) && 200 === $result['status'] ) {
				$type = strtolower( (string) ( $result['headers']['content-type'] ?? '' ) );
				if ( 0 !== strpos( $type, 'text/markdown' ) && 0 === strpos( $accept, 'text/markdown' ) ) {
					$retry = wp_remote_get(
						$url,
						array(
							'timeout'     => 12,
							'redirection' => 2,
							'headers'     => array(
								'Accept'     => $accept,
								'User-Agent' => 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36',
							),
						)
					);
					if ( ! is_wp_error( $retry ) && 200 === (int) wp_remote_retrieve_response_code( $retry ) ) {
						return array(
							'status'  => 200,
							'body'    => (string) wp_remote_retrieve_body( $retry ),
							'headers' => wp_remote_retrieve_headers( $retry ),
						);
					}
				}
			}
			return $result;
		}

		/**
		 * Check robots.txt presence and validity.
		 *
		 * @param array|null $robots Fetch result.
		 * @return array
		 */
		private static function check_robots_txt( $robots ) {
			if ( null === $robots || 200 !== $robots['status'] ) {
				return array(
					'status'  => 'fail',
					'message' => __( 'robots.txt could not be fetched. Ensure WordPress is serving a virtual robots.txt (Settings > Reading must allow search engines).', 'webmcp-gateway' ),
				);
			}
			if ( '' === trim( (string) $robots['body'] ) || false === stripos( (string) $robots['body'], 'user-agent' ) ) {
				return array(
					'status'  => 'fail',
					'message' => __( 'robots.txt exists but contains no User-agent directives.', 'webmcp-gateway' ),
				);
			}
			return array(
				'status'  => 'pass',
				'message' => __( 'robots.txt exists with valid format', 'webmcp-gateway' ),
			);
		}

		/**
		 * Check sitemap discoverability.
		 *
		 * @param string $home       Site home URL.
		 * @param string $robots_body robots.txt content.
		 * @return array
		 */
		private static function check_sitemap( $home, $robots_body ) {
			$has_declaration = '' !== $robots_body && false !== stripos( $robots_body, 'sitemap:' );
			$probe           = self::fetch( $home . 'wp-sitemap.xml' );
			$live            = null !== $probe && 200 === $probe['status'] && false !== stripos( (string) $probe['body'], '<urlset' );
			if ( $live || $has_declaration ) {
				return array(
					'status'  => 'pass',
					'message' => __( 'sitemap.xml exists with valid structure', 'webmcp-gateway' ),
				);
			}
			return array(
				'status'  => 'fail',
				'message' => __( 'No sitemap found. WordPress core serves /wp-sitemap.xml — verify permalinks are set to pretty format.', 'webmcp-gateway' ),
			);
		}

		/**
		 * Check the homepage Link headers for agent-useful relation types.
		 *
		 * @param array  $robots_headers robots.txt response headers (same origin policy).
		 * @param string $home           Home URL.
		 * @return array
		 */
		private static function check_link_headers( $robots_headers, $home ) {
			// Cache-buster: stored page-cache copies may predate the current headers.
			$page = self::fetch( add_query_arg( 'webmcp_audit_bust', dechex( time() ), $home ) );
			$link = '';
			if ( null !== $page && ! empty( $page['headers']['link'] ) ) {
				// WP sends multiple Link headers (agent rels + api.w.org); the header
				// collection returns them as an array — join before parsing.
				$link = $page['headers']['link'];
				if ( is_array( $link ) ) {
					$link = implode( ', ', $link );
				}
				$link = (string) $link;
			}
			$parsed = self::parse_link_header( $link );
			$useful = array();
			foreach ( $parsed as $entry ) {
				foreach ( (array) $entry['rels'] as $rel ) {
					if ( in_array( strtolower( $rel ), self::$agent_rels, true ) ) {
						$useful[] = $rel;
					}
				}
			}
			if ( ! empty( $useful ) ) {
				return array(
					'status'  => 'pass',
					'message' => sprintf(
						/* translators: %s: comma-separated relation types */
						__( 'Agent-useful Link relations found: %s', 'webmcp-gateway' ),
						implode( ', ', array_unique( $useful ) )
					),
				);
			}
			return array(
				'status'  => 'fail',
				'message' => __( 'Link headers present but no agent-useful relation types found. The API Catalog link (rel="api-catalog") is emitted automatically — clear any page cache and re-run.', 'webmcp-gateway' ),
			);
		}

		/**
		 * Parse an RFC 8288 Link header into rel entries.
		 *
		 * @param string $header Link header value.
		 * @return array[]
		 */
		private static function parse_link_header( $header ) {
			$out = array();
			if ( '' === trim( (string) $header ) ) {
				return $out;
			}
			// RFC 8288 packs several <url>; rel="..." pairs into one header value,
			// separated by ", <". Match EVERY pair — the previous single-regex form
			// only ever saw the first pair, so multi-rel headers never passed.
			if ( preg_match_all( '/<([^>]+)>([^<>]*)/i', (string) $header, $pairs, PREG_SET_ORDER ) ) {
				foreach ( $pairs as $pair ) {
					$rels = array();
					if ( preg_match( '/rel="([^"]*)"/i', $pair[2], $r ) ) {
						$rels = preg_split( '/\s+/', strtolower( $r[1] ) ) ?: array();
					}
					$out[] = array( 'href' => $pair[1], 'rels' => $rels );
				}
			}
			return $out;
		}

		/**
		 * Check Markdown content negotiation on the homepage.
		 *
		 * @param string $home Home URL.
		 * @return array
		 */
		private static function check_markdown_negotiation( $home ) {
			// Cache-buster: the audit must see the live PHP response, not a stored page-cache copy.
			$md = self::fetch_accept( add_query_arg( 'webmcp_audit_bust', dechex( time() ), $home ), 'text/markdown' );
			$type = '';
			if ( null !== $md && ! empty( $md['headers']['content-type'] ) ) {
				$type = strtolower( (string) $md['headers']['content-type'] );
			}
			if ( 0 === strpos( $type, 'text/markdown' ) ) {
				return array(
					'status'  => 'pass',
					'message' => __( 'Site supports Markdown for Agents (text/markdown negotiation)', 'webmcp-gateway' ),
				);
			}
			return array(
				'status'  => 'fail',
				'message' => __( 'Homepage does not negotiate text/markdown. Enable the Markdown stream in Settings and clear page cache.', 'webmcp-gateway' ),
			);
		}

		/**
		 * Check robots.txt for AI bot rules.
		 *
		 * @param string $body robots.txt content.
		 * @return array
		 */
		private static function check_bot_rules( $body ) {
			$known = array( 'gptbot', 'oai-searchbot', 'chatgpt-user', 'perplexitybot', 'claudebot', 'google-extended', 'ccbot' );
			$found = array();
			foreach ( $known as $bot ) {
				if ( false !== stripos( $body, 'user-agent: ' . $bot ) ) {
					$found[] = $bot;
				}
			}
			if ( ! empty( $found ) ) {
				return array(
					'status'  => 'pass',
					'message' => sprintf(
						/* translators: %s: comma-separated bot names */
						__( 'Found rules for AI bots: %s', 'webmcp-gateway' ),
						implode( ', ', $found )
					),
				);
			}
			return array(
				'status'  => 'fail',
				'message' => __( 'No AI bot rules in robots.txt. Enable the Per-Bot AI Crawler Policy in Settings > Bot Policy.', 'webmcp-gateway' ),
			);
		}

		/**
		 * Check robots.txt for Content Signals.
		 *
		 * @param string $body robots.txt content.
		 * @return array
		 */
		private static function check_content_signals( $body ) {
			if ( false !== stripos( $body, 'content-signal' ) ) {
				return array(
					'status'  => 'pass',
					'message' => __( 'Content Signals declared in robots.txt', 'webmcp-gateway' ),
				);
			}
			return array(
				'status'  => 'fail',
				'message' => __( 'No Content Signals found in robots.txt. Pick a Content Signals policy in Settings > Bot Policy to declare ai-train / search / ai-input preferences.', 'webmcp-gateway' ),
			);
		}

		/**
		 * Check a JSON well-known endpoint exists and contains a key.
		 *
		 * @param string      $url      Endpoint URL.
		 * @param string[]|null $require_key Top-level key required (null = any JSON).
		 * @param string      $label    Human check label.
		 * @return array
		 */
		private static function check_wellknown_json( $url, $require_key, $label, $query_var = null ) {
			$res = self::fetch_robust( $url );
			if ( null === $res || 200 !== $res['status'] ) {
				if ( null !== $query_var ) {
					// Some servers intercept the physical /.well-known/ directory
					// (ACME/SSL tooling); the query-string route proves the feature.
					$res = self::fetch_robust( add_query_arg( 'webmcp_gateway_wellknown', $query_var, home_url( '/' ) ) );
				}
			}
			if ( null === $res || 200 !== $res['status'] ) {
				return array(
					'status'  => 'fail',
					'message' => sprintf(
						/* translators: %s: endpoint label */
						__( '%s not found', 'webmcp-gateway' ),
						$label
					),
				);
			}
			$data = json_decode( (string) $res['body'], true );
			if ( ! is_array( $data ) ) {
				return array(
					'status'  => 'fail',
					'message' => sprintf(
						/* translators: %s: endpoint label */
						__( '%s exists but is not valid JSON', 'webmcp-gateway' ),
						$label
					),
				);
			}
			if ( null !== $require_key && ! isset( $data[ $require_key[0] ] ) ) {
				return array(
					'status'  => 'fail',
					'message' => sprintf(
						/* translators: %s: endpoint label */
						__( '%s exists but is missing required data', 'webmcp-gateway' ),
						$label
					),
				);
			}
			return array(
				'status'  => 'pass',
				'message' => sprintf(
					/* translators: %s: endpoint label */
					__( '%s found and valid', 'webmcp-gateway' ),
					$label
				),
			);
		}

		/**
		 * Check /auth.md.
		 *
		 * @param string $home Home URL.
		 * @return array
		 */
		private static function check_auth_md( $home ) {
			$res = self::fetch( $home . 'auth.md' );
			if ( null !== $res && 200 === $res['status'] ) {
				// Cloudflare-grade validation: the document must actually describe how
				// agents authenticate/register — mere existence is not enough.
				$body = (string) $res['body'];
				$signals = array( 'registration', 'register', 'api key', 'apikey', 'token', 'bearer', 'credential', 'x-webmcp-key', 'authentication' );
				foreach ( $signals as $signal ) {
					if ( false !== stripos( $body, $signal ) ) {
						return array(
							'status'  => 'pass',
							'message' => __( 'auth.md found — agent authentication model documented', 'webmcp-gateway' ),
						);
					}
				}
				return array(
					'status'  => 'fail',
					'message' => __( 'auth.md exists but does not describe agent registration or credentials. Document how agents register and authenticate, then re-run.', 'webmcp-gateway' ),
				);
			}
			return array(
				'status'  => 'fail',
				'message' => __( 'auth.md not found. The gateway emits one automatically — clear page cache and re-run.', 'webmcp-gateway' ),
			);
		}

		/**
		 * Check the MCP server card.
		 *
		 * @param string $home Home URL.
		 * @return array
		 */
		private static function check_mcp_card( $home ) {
			$res = self::fetch( $home . '.well-known/mcp.json' );
			$tools = 0;
			if ( null !== $res && 200 === $res['status'] ) {
				$data = json_decode( (string) $res['body'], true );
				if ( is_array( $data ) && isset( $data['tools'] ) && is_array( $data['tools'] ) ) {
					$tools = count( $data['tools'] );
				}
			}
			if ( $tools > 0 ) {
				return array(
					'status'  => 'pass',
					'message' => sprintf(
						/* translators: %d: tool count */
						__( 'MCP Server Card found at /.well-known/mcp.json (%d tools)', 'webmcp-gateway' ),
						$tools
					),
				);
			}
			return array(
				'status'  => 'fail',
				'message' => __( 'MCP Server Card missing or invalid at /.well-known/mcp.json.', 'webmcp-gateway' ),
			);
		}

		/**
		 * Check the agent-skills index.
		 *
		 * @param string $home Home URL.
		 * @return array
		 */
		private static function check_agent_skills( $home ) {
			$res = self::fetch( $home . '.well-known/agent-skills/index.json' );
			if ( null !== $res && 200 === $res['status'] ) {
				$data = json_decode( (string) $res['body'], true );
				if ( is_array( $data ) && ! empty( $data ) ) {
					return array(
						'status'  => 'pass',
						'message' => __( 'Agent Skills index found', 'webmcp-gateway' ),
					);
				}
			}
			return array(
				'status'  => 'fail',
				'message' => __( 'Agent Skills index not found. The gateway publishes one at /.well-known/agent-skills/index.json — clear page cache and re-run.', 'webmcp-gateway' ),
			);
		}

		/**
		 * Check the WebMCP client bridge is broadcast on the frontend.
		 *
		 * @return array
		 */
		private static function check_webmcp_bridge() {
			$page = self::fetch( home_url( '/' ) );
			if ( null === $page ) {
				return self::neutral( __( 'Homepage could not be fetched to verify the WebMCP bridge.', 'webmcp-gateway' ) );
			}
			$body = (string) $page['body'];
			$has_manifest = false !== strpos( $body, 'webmcp-manifest' );
			$has_bridge   = false !== strpos( $body, 'webmcp-gateway-register' );
			if ( $has_manifest && $has_bridge ) {
				return array(
					'status'  => 'pass',
					'message' => __( 'WebMCP document.modelContext bridge is live on the frontend', 'webmcp-gateway' ),
				);
			}
			return array(
				'status'  => 'fail',
				'message' => __( 'WebMCP bridge not detected on the homepage. Enable the gateway in Settings > Protocol & discovery.', 'webmcp-gateway' ),
			);
		}
	}
}
