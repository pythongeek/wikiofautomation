<?php
/**
 * WP-CLI Commands - WebMCP Gateway.
 *
 * Operations: clear the activity log, run the local agent audit, flush all
 * schema/llms.txt caches, list registered MCP tools, and show gateway status.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WebMCP_Gateway_CLI' ) && class_exists( 'WP_CLI' ) ) {
	/**
	 * Registers the `wp webmcp` command family.
	 */
	final class WebMCP_Gateway_CLI {

		/**
		 * Register CLI commands.
		 *
		 * @return void
		 */
		public static function register() {
			WP_CLI::add_command( 'webmcp clear-log', array( __CLASS__, 'clear_log' ), array(
				'shortdesc' => 'Clear the WebMCP Gateway activity log and lifetime counters.',
			) );
			WP_CLI::add_command( 'webmcp audit', array( __CLASS__, 'audit' ), array(
				'shortdesc' => 'Run the local Agent-Ready audit and print the score.',
			) );
			WP_CLI::add_command( 'webmcp flush-cache', array( __CLASS__, 'flush_cache' ), array(
				'shortdesc' => 'Invalidate all schema graph and llms.txt caches.',
			) );
			WP_CLI::add_command( 'webmcp tools', array( __CLASS__, 'tools' ), array(
				'shortdesc' => 'List the MCP tools this gateway exposes.',
			) );
			WP_CLI::add_command( 'webmcp status', array( __CLASS__, 'status' ), array(
				'shortdesc' => 'Show gateway status, endpoints, and activity counters.',
			) );
		}

		/**
		 * wp webmcp clear-log
		 *
		 * @return void
		 */
		public static function clear_log() {
			delete_option( 'webmcp_gateway_activity_events' );
			delete_option( 'webmcp_gateway_activity_counters' );
			WP_CLI::success( 'Activity log and counters cleared.' );
		}

		/**
		 * wp webmcp audit
		 *
		 * @return void
		 */
		public static function audit() {
			$report = WebMCP_Gateway_Agent_Audit::run_local_audit();
			if ( ! is_array( $report ) || empty( $report ) ) {
				WP_CLI::error( 'Audit could not run.' );
			}
			$level = isset( $report['levelName'] ) ? $report['levelName'] : ( isset( $report['level'] ) ? $report['level'] : '' );
			WP_CLI::line( 'Agent-Ready score: ' . ( isset( $report['score'] ) ? $report['score'] : '?' ) . '/100 (' . $level . ')' );
			if ( isset( $report['checks'] ) && is_array( $report['checks'] ) ) {
				foreach ( $report['checks'] as $check ) {
					$label = isset( $check['title'] ) ? $check['title'] : ( isset( $check['label'] ) ? $check['label'] : 'check' );
					$pass  = ! empty( $check['passed'] );
					WP_CLI::line( ( $pass ? '  [PASS] ' : '  [FAIL] ' ) . $label );
				}
			}
			WP_CLI::success( 'Audit complete.' );
		}

		/**
		 * wp webmcp flush-cache
		 *
		 * @return void
		 */
		public static function flush_cache() {
			update_option( 'webmcp_gateway_schema_rev', (int) get_option( 'webmcp_gateway_schema_rev', 0 ) + 1, false );
			update_option( 'webmcp_gateway_llmstxt_rev', (int) get_option( 'webmcp_gateway_llmstxt_rev', 0 ) + 1, false );
			delete_option( 'webmcp_gateway_llmstxt_cache' );
			global $wpdb;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time cache flush; caching is pointless here.
			$cleared = $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s", '_webmcp_graph_cache' ) );
			WP_CLI::success( 'Schema and llms.txt caches flushed (' . (int) $cleared . ' post graph entries removed).' );
		}

		/**
		 * wp webmcp tools
		 *
		 * @return void
		 */
		public static function tools() {
			$tools = (array) apply_filters( 'webmcp_gateway_register_tools', WebMCP_Gateway_Schema_Builder::get_core_tools( 0 ), 'homepage', 0 );
			if ( empty( $tools ) ) {
				WP_CLI::line( 'No tools registered.' );
				return;
			}
			foreach ( $tools as $tool ) {
				$tool  = (array) $tool;
				$name  = isset( $tool['name'] ) ? $tool['name'] : '?';
				$desc  = isset( $tool['description'] ) ? $tool['description'] : '';
				WP_CLI::line( $name . ' — ' . wp_strip_all_tags( (string) $desc ) );
			}
		}

		/**
		 * wp webmcp status
		 *
		 * @return void
		 */
		public static function status() {
			WP_CLI::line( 'Gateway: ' . ( WebMCP_Gateway_Frontend::is_enabled() ? 'active' : 'paused' ) );
			WP_CLI::line( 'Version: ' . WEBMCP_CORE_VERSION );
			WP_CLI::line( 'Manifest:  ' . rest_url( 'webmcp-gateway/v1/manifest' ) );
			WP_CLI::line( 'llms.txt:  ' . home_url( '/llms.txt' ) );
			WP_CLI::line( 'mcp.json:  ' . home_url( '/.well-known/mcp.json' ) );
			$counters = WebMCP_Gateway_Activity_Log::get_counters();
			foreach ( $counters as $type => $count ) {
				WP_CLI::line( '  ' . $type . ': ' . (int) $count );
			}
		}
	}
}
