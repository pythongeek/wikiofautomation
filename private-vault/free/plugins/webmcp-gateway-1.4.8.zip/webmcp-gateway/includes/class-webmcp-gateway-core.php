<?php
/**
 * Main Plugin Orchestrator - WebMCP Gateway.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WebMCP_Gateway_Core' ) ) {
	/**
	 * Loads dependencies using __DIR__ so paths can never collide with other plugins.
	 */
	final class WebMCP_Gateway_Core {

		/**
		 * Singleton instance.
		 *
		 * @var WebMCP_Gateway_Core|null
		 */
		private static $instance = null;

		/**
		 * Retrieve singleton instance.
		 *
		 * @return WebMCP_Gateway_Core
		 */
		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Constructor.
		 */
		private function __construct() {
			self::load_dependencies();
		}

		/**
		 * Require all modular class files relative to __DIR__.
		 *
		 * @return void
		 */
		public static function load_dependencies() {
			static $loaded = false;
			if ( $loaded ) {
				return;
			}
			$loaded = true;

			$base = dirname( __DIR__ );

			require_once __DIR__ . '/class-webmcp-gateway-loader.php';
			require_once __DIR__ . '/features/class-webmcp-gateway-activity-log.php';
			require_once __DIR__ . '/schema/class-webmcp-gateway-schema-builder.php';
			require_once __DIR__ . '/schema/class-webmcp-gateway-schema-graph.php';
			require_once __DIR__ . '/features/class-webmcp-gateway-markdown.php';
			require_once __DIR__ . '/features/class-webmcp-gateway-llmstxt.php';
			require_once __DIR__ . '/features/class-webmcp-gateway-well-known.php';
			require_once __DIR__ . '/features/class-webmcp-gateway-crawler-policy.php';
			require_once __DIR__ . '/api/class-webmcp-gateway-rest.php';
			require_once __DIR__ . '/audit/class-webmcp-gateway-agent-audit.php';
			if ( class_exists( 'WP_CLI' ) ) {
				require_once __DIR__ . '/class-webmcp-gateway-cli.php';
			}
			require_once __DIR__ . '/class-webmcp-gateway-frontend.php';

			if ( is_admin() ) {
				require_once $base . '/admin/class-webmcp-gateway-admin.php';
				require_once $base . '/admin/class-webmcp-gateway-metabox.php';
			}
		}

		/**
		 * Initialize modules and run the loader.
		 *
		 * @return void
		 */
		public function run() {
			WebMCP_Gateway_Activity_Log::init();
			WebMCP_Gateway_Frontend::init();
			WebMCP_Gateway_Markdown::init();
			WebMCP_Gateway_LlmsTxt::init();
			WebMCP_Gateway_Well_Known::init();
			WebMCP_Gateway_Crawler_Policy::init();
			WebMCP_Gateway_REST::init();
			WebMCP_Gateway_Agent_Audit::init();

			if ( class_exists( 'WP_CLI' ) && class_exists( 'WebMCP_Gateway_CLI' ) ) {
				WebMCP_Gateway_CLI::register();
			}

			if ( is_admin() ) {
				WebMCP_Gateway_Admin::init();
				WebMCP_Gateway_Metabox::init();
			}

			WebMCP_Gateway_Loader::run();
		}
	}
}
