<?php
/**
 * Frontend Hooks & Output Layer - WebMCP Gateway.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WebMCP_Gateway_Frontend' ) ) {
	/**
	 * Manages frontend protocol broadcasting and reader-facing AI tools.
	 */
	final class WebMCP_Gateway_Frontend {

		/**
		 * Register frontend hooks and shortcode.
		 *
		 * @return void
		 */
		public static function init() {
			WebMCP_Gateway_Loader::register_action( 'init', array( __CLASS__, 'register_shortcodes' ) );
			WebMCP_Gateway_Loader::register_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_scripts' ) );
			WebMCP_Gateway_Loader::register_action( 'wp_head', array( __CLASS__, 'render_head' ), 1 );
			WebMCP_Gateway_Loader::register_filter( 'wp_headers', array( __CLASS__, 'filter_wp_headers' ) );
			WebMCP_Gateway_Loader::register_filter( 'the_content', array( __CLASS__, 'maybe_prepend_ai_widget' ), 8 );
			WebMCP_Gateway_Loader::register_action( 'save_post', array( 'WebMCP_Gateway_Schema_Graph', 'purge_graph_cache' ) );
			WebMCP_Gateway_Loader::register_action( 'deleted_post', array( 'WebMCP_Gateway_Schema_Graph', 'purge_graph_cache' ) );
			WebMCP_Gateway_Loader::register_action( 'updated_option', array( 'WebMCP_Gateway_Schema_Graph', 'maybe_bump_graph_rev' ) );
		}

		/**
		 * Register the `[webmcp_ai_summary]` shortcode.
		 *
		 * @return void
		 */
		public static function register_shortcodes() {
			add_shortcode( 'webmcp_ai_summary', array( __CLASS__, 'render_ai_summary_shortcode' ) );
		}

		/**
		 * Check whether the WebMCP Gateway is enabled.
		 *
		 * @return bool
		 */
		public static function is_enabled() {
			return (bool) get_option( 'webmcp_gateway_enabled', 1 );
		}

		/**
		 * Header lines applied to the plugin's own non-HTML responses.
		 *
		 * @return array<int, string>
		 */
		public static function hardening_header_lines() {
			return array(
				'X-Content-Type-Options: nosniff',
				"Content-Security-Policy: default-src 'none'; sandbox",
				'Referrer-Policy: no-referrer',
			);
		}

		/**
		 * Defense-in-depth headers for the plugin's own non-HTML responses
		 * (markdown streams, llms.txt, discovery documents, robots policy).
		 *
		 * Scoped strictly to plugin-emitted responses — never sent site-wide,
		 * where a plugin-emitted CSP could break themes or other plugins.
		 *
		 * @return void
		 */
		public static function send_hardening_headers() {
			if ( headers_sent() ) {
				return;
			}
			foreach ( self::hardening_header_lines() as $header_line ) {
				header( $header_line );
			}
		}

		/**
		 * Enqueue the lightweight client navigator/document registration bridge
		 * and the AI Summary / citation bar stylesheet.
		 *
		 * @return void
		 */
		public static function enqueue_scripts() {
			if ( ! self::is_enabled() ) {
				return;
			}

			wp_register_script(
				'webmcp-gateway-register',
				WEBMCP_CORE_URL . 'public/js/webmcp-gateway-register.js',
				array(),
				WEBMCP_CORE_VERSION,
				true
			);
			if ( function_exists( 'wp_script_add_data' ) ) {
				wp_script_add_data( 'webmcp-gateway-register', 'strategy', 'defer' );
			}

			wp_localize_script(
				'webmcp-gateway-register',
				'WebMCPGatewayConfig',
				array(
					'restUrl'     => esc_url_raw( rest_url( 'webmcp-gateway/v1/call/' ) ),
					'manifestUrl' => esc_url_raw( rest_url( 'webmcp-gateway/v1/manifest' ) ),
					'toolsUrl'    => esc_url_raw( rest_url( 'webmcp-gateway/v1/tools' ) ),
					'wellKnown'   => esc_url_raw( home_url( '/.well-known/mcp.json' ) ),
					'llmsTxtUrl'  => esc_url_raw( home_url( '/llms.txt' ) ),
					'postId'      => (int) get_queried_object_id(),
					'version'     => WEBMCP_CORE_VERSION,
				)
			);

			wp_enqueue_script( 'webmcp-gateway-register' );

			wp_enqueue_style(
				'webmcp-gateway-ai-box',
				WEBMCP_CORE_URL . 'public/css/webmcp-ai-box.css',
				array(),
				WEBMCP_CORE_VERSION
			);
		}

		/**
		 * Filter HTTP response headers via WordPress wp_headers filter.
		 *
		 * @param mixed $headers Existing HTTP headers.
		 * @return array
		 */
		public static function filter_wp_headers( $headers = array() ) {
			if ( ! is_array( $headers ) ) {
				$headers = array();
			}
			if ( is_admin() || ! self::is_enabled() ) {
				return $headers;
			}

			$links = array(
				'<' . esc_url_raw( rest_url( 'webmcp-gateway/v1/manifest' ) ) . '>; rel="model-context-protocol"',
				'<' . esc_url_raw( home_url( '/.well-known/mcp.json' ) ) . '>; rel="mcp-server"',
				'<' . esc_url_raw( home_url( '/llms.txt' ) ) . '>; rel="llms-txt"',
				'<' . esc_url_raw( home_url( '/.well-known/api-catalog' ) ) . '>; rel="api-catalog"',
				'<' . esc_url_raw( rest_url( 'webmcp-gateway/v1/manifest' ) ) . '>; rel="service-desc"',
			);

			$headers['X-WebMCP']               = WEBMCP_CORE_VERSION;
			$headers['X-ModelContextProtocol'] = '1.0';

			if ( ! empty( $headers['Link'] ) ) {
				$headers['Link'] .= ', ' . implode( ', ', $links );
			} else {
				$headers['Link'] = implode( ', ', $links );
			}

			return $headers;
		}

		/**
		 * Render discovery <meta>, <link>, manifest JSON, and Schema.org @graph in <head>.
		 *
		 * @return void
		 */
		public static function render_head() {
			if ( ! self::is_enabled() ) {
				return;
			}

			$post_id      = (int) get_queried_object_id();
			$context      = self::resolve_context();
			$manifest     = WebMCP_Gateway_Schema_Builder::build( $context, $post_id );
			$manifest_url = rest_url( 'webmcp-gateway/v1/manifest' );
			$well_known   = home_url( '/.well-known/mcp.json' );
			$llms_url     = home_url( '/llms.txt' );
			$canonical    = WebMCP_Gateway_Schema_Graph::get_canonical_url( $post_id );
			$md_url       = add_query_arg( 'format', 'markdown', $canonical );
			$rate_limit   = max( 10, absint( get_option( 'webmcp_gateway_rate_limit', 60 ) ) );

			printf(
				'<meta name="webmcp-policy" content="%s">' . "\n",
				esc_attr( sprintf( 'allow=read-tools; max-calls-per-minute=%d; crawl-delay=1', $rate_limit ) )
			);
			printf( '<meta name="model-context-protocol" content="%s">' . "\n", esc_url( $manifest_url ) );
			printf( '<meta name="ai-content-format" content="markdown">' . "\n" );
			printf( '<link rel="model-context-protocol" href="%s" type="application/json">' . "\n", esc_url( $manifest_url ) );
			printf( '<link rel="mcp-server" href="%s" type="application/json">' . "\n", esc_url( $well_known ) );
			printf( '<link rel="llms-txt" href="%s" type="text/plain">' . "\n", esc_url( $llms_url ) );
			printf( '<link rel="ai-catalog" href="%s" type="application/json">' . "\n", esc_url( home_url( '/.well-known/ai-catalog.json' ) ) );

			if ( (bool) get_option( 'webmcp_gateway_markdown_enabled', 1 ) ) {
				printf(
					'<link rel="alternate" type="text/markdown" href="%s" title="%s">' . "\n",
					esc_url( $md_url ),
					esc_attr__( 'Clean Semantic Markdown for AI Agents', 'webmcp-gateway' )
				);
			}

			$manifest_json = wp_json_encode( $manifest, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
			if ( is_string( $manifest_json ) && '' !== $manifest_json ) {
				if ( function_exists( 'wp_print_inline_script_tag' ) ) {
					wp_print_inline_script_tag(
						$manifest_json,
						array(
							'type' => 'application/json',
							'id'   => 'webmcp-manifest',
						)
					);
				}
			}

			$schema_ld = WebMCP_Gateway_Schema_Graph::generate( $post_id, $context );
			if ( ! empty( $schema_ld ) ) {
				$schema_json = wp_json_encode( $schema_ld, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
				if ( is_string( $schema_json ) && '' !== $schema_json ) {
					if ( function_exists( 'wp_print_inline_script_tag' ) ) {
						wp_print_inline_script_tag(
							$schema_json,
							array(
								'type' => 'application/ld+json',
								'id'   => 'webmcp-jsonld',
							)
						);
					}
				}
			}
		}

		/**
		 * Resolve the configured AI box color theme (light, dark, or auto).
		 *
		 * @return string
		 */
		public static function get_ai_box_theme() {
			$theme = (string) get_option( 'webmcp_gateway_ai_box_theme', 'auto' );
			return in_array( $theme, array( 'light', 'dark', 'auto' ), true ) ? $theme : 'auto';
		}

		/**
		 * Render the AI Summary + "Ask AI / Cite This Page" widget HTML for a post.
		 *
		 * @param WP_Post $post            Target post.
		 * @param bool    $include_summary Whether to display the TL;DR summary box.
		 * @param bool    $include_citebar Whether to display the "Ask AI / View Markdown" bar.
		 * @return string
		 */
		public static function build_frontend_ai_box_html( $post, $include_summary = true, $include_citebar = true ) {
			if ( ! ( $post instanceof WP_Post ) ) {
				return '';
			}
			$summary   = WebMCP_Gateway_Activity_Log::get_effective_ai_summary( $post );
			$permalink = (string) get_permalink( $post );
			$md_url    = add_query_arg( 'format', 'markdown', $permalink );
			$prompt    = sprintf(
				/* translators: 1: Post title, 2: Permalink URL */
				__( 'Summarize and cite the key insights from "%1$s" (%2$s)', 'webmcp-gateway' ),
				get_the_title( $post ),
				$permalink
			);

			$chatgpt_url    = 'https://chatgpt.com/?q=' . rawurlencode( $prompt );
			$perplexity_url = 'https://www.perplexity.ai/search?q=' . rawurlencode( $prompt );
			$claude_url     = 'https://claude.ai/new?q=' . rawurlencode( $prompt );

			$html = '<aside class="wm-ai-box" data-wm-theme="' . esc_attr( self::get_ai_box_theme() ) . '" aria-label="' . esc_attr__( 'AI Summary and Citation Tools', 'webmcp-gateway' ) . '">';

			if ( $include_summary && '' !== $summary ) {
				$html .= '<p class="wm-ai-box__summary">';
				$html .= '<strong class="wm-ai-box__summary-label">' . esc_html__( '✦ Key Summary (TL;DR)', 'webmcp-gateway' ) . '</strong>';
				$html .= '<span class="wm-ai-box__summary-text">' . esc_html( $summary ) . '</span>';
				$html .= '</p>';
			}

			if ( $include_citebar ) {
				$html .= '<div class="wm-ai-box__actions">';
				$html .= '<span class="wm-ai-box__actions-label">' . esc_html__( 'Verify or summarize with AI', 'webmcp-gateway' ) . '</span>';
				$html .= '<span class="wm-ai-box__buttons">';
				$html .= '<a class="wm-ai-box__btn" href="' . esc_url( $chatgpt_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Ask ChatGPT', 'webmcp-gateway' ) . ' ↗</a>';
				$html .= '<a class="wm-ai-box__btn" href="' . esc_url( $perplexity_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Cite in Perplexity', 'webmcp-gateway' ) . ' ↗</a>';
				$html .= '<a class="wm-ai-box__btn" href="' . esc_url( $claude_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Ask Claude', 'webmcp-gateway' ) . ' ↗</a>';
				$html .= '<a class="wm-ai-box__btn wm-ai-box__btn--accent" href="' . esc_url( $md_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'View AI Markdown', 'webmcp-gateway' ) . '</a>';
				$html .= '</span>';
				$html .= '</div>';
			}

			$html .= '</aside>';

			// Smart auto theme: resolve against the page's actual background, not the OS setting.
			if ( 'auto' === self::get_ai_box_theme() ) {
				$html .= '<script>(function(){'
					. 'var box=document.currentScript&&document.currentScript.previousElementSibling;'
					. "if(!box||!box.classList.contains('wm-ai-box')){return;}"
					. 'var el=box,lum=1,depth=0;'
					. 'while(el&&el!==document.body&&depth<6){'
					. "var bg=getComputedStyle(el).backgroundColor;"
					. "var m=bg&&bg.match(/rgba?\\(([\\d.]+)[,\\s]+([\\d.]+)[,\\s]+([\\d.]+)/);"
					. "if(m&&!/rgba?\\([^)]*,\\s*0\\s*\\)/.test(bg)){"
					. 'var r=m[1]/255,g=m[2]/255,b=m[3]/255;'
					. 'lum=0.2126*r+0.7152*g+0.0722*b;'
					. 'break;'
					. '}'
					. 'el=el.parentElement;depth++;'
					. '}'
					. "if(lum<0.45){box.setAttribute('data-wm-resolved','dark');}"
					. '})();</script>';
			}

			return (string) apply_filters( 'webmcp_gateway_ai_box_html', $html, $post, $include_summary, $include_citebar );
		}

		/**
		 * Shortcode callback for `[webmcp_ai_summary]`.
		 *
		 * @return string
		 */
		public static function render_ai_summary_shortcode() {
			$post = get_post();
			if ( ! ( $post instanceof WP_Post ) ) {
				return '';
			}
			return self::build_frontend_ai_box_html( $post, true, true );
		}

		/**
		 * Automatically prepend the AI Summary and/or "Ask AI" bar when opted in via settings.
		 *
		 * @param mixed $content Post HTML content.
		 * @return string
		 */
		public static function maybe_prepend_ai_widget( $content = '' ) {
			$content = (string) $content;
			if ( is_admin() || ! is_singular() || ! in_the_loop() || ! is_main_query() ) {
				return $content;
			}

			$show_summary = (bool) get_option( 'webmcp_gateway_ai_summary_render', 0 );
			$show_citebar = (bool) get_option( 'webmcp_gateway_cite_bar_render', 0 );

			if ( ! $show_summary && ! $show_citebar ) {
				return $content;
			}

			$post = get_post();
			if ( ! ( $post instanceof WP_Post ) ) {
				return $content;
			}

			return self::build_frontend_ai_box_html( $post, $show_summary, $show_citebar ) . $content;
		}

		/**
		 * Resolve current WordPress request context.
		 *
		 * @return string
		 */
		public static function resolve_context() {
			if ( is_404() ) {
				return '404';
			}
			if ( is_search() ) {
				return 'search';
			}
			if ( is_singular() ) {
				return 'single';
			}
			if ( is_home() || is_front_page() ) {
				return 'homepage';
			}
			if ( is_archive() ) {
				return 'archive';
			}
			return 'homepage';
		}
	}
}
