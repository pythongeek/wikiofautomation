<?php
/**
 * Hook Loader - registers and coordinates all WordPress actions and filters.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WebMCP_Gateway_Loader' ) ) {
	/**
	 * Centralized registration manager for WordPress hooks.
	 */
	final class WebMCP_Gateway_Loader {

		/**
		 * Registered actions list.
		 *
		 * @var array
		 */
		private static $actions = array();

		/**
		 * Registered filters list.
		 *
		 * @var array
		 */
		private static $filters = array();

		/**
		 * Queue an action hook.
		 *
		 * @param string $hook          Hook name.
		 * @param mixed  $callback      Callback function or method.
		 * @param int    $priority      Execution priority.
		 * @param int    $accepted_args Number of arguments.
		 * @return void
		 */
		public static function register_action( $hook, $callback, $priority = 10, $accepted_args = 1 ) {
			self::$actions[] = array(
				'hook'          => (string) $hook,
				'callback'      => $callback,
				'priority'      => (int) $priority,
				'accepted_args' => (int) $accepted_args,
			);
		}

		/**
		 * Queue a filter hook.
		 *
		 * @param string $hook          Filter name.
		 * @param mixed  $callback      Callback function or method.
		 * @param int    $priority      Execution priority.
		 * @param int    $accepted_args Number of arguments.
		 * @return void
		 */
		public static function register_filter( $hook, $callback, $priority = 10, $accepted_args = 1 ) {
			self::$filters[] = array(
				'hook'          => (string) $hook,
				'callback'      => $callback,
				'priority'      => (int) $priority,
				'accepted_args' => (int) $accepted_args,
			);
		}

		/**
		 * Bind all queued actions and filters to WordPress.
		 *
		 * @return void
		 */
		public static function run() {
			foreach ( self::$actions as $action ) {
				add_action( $action['hook'], $action['callback'], $action['priority'], $action['accepted_args'] );
			}
			foreach ( self::$filters as $filter ) {
				add_filter( $filter['hook'], $filter['callback'], $filter['priority'], $filter['accepted_args'] );
			}
		}
	}
}
