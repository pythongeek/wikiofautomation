<?php
/**
 * Local "What Happened" AI Activity Log, Page AEO X-Ray Scanner & Answer-Gap Finder.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WebMCP_Gateway_Activity_Log' ) ) {
	/**
	 * Tracks local AI agent activity, runs Page AEO X-Ray diagnostics, and generates Answer-Gap questions.
	 */
	final class WebMCP_Gateway_Activity_Log {

		/**
		 * Register frontend AI crawler detection hook.
		 *
		 * @return void
		 */
		public static function init() {
			WebMCP_Gateway_Loader::register_action( 'template_redirect', array( __CLASS__, 'detect_ai_crawler_visit' ), 5 );
		}

		/**
		 * Detect known AI search & answer engine crawlers on public page loads.
		 *
		 * @return void
		 */
		public static function detect_ai_crawler_visit() {
			if ( is_admin() || ! (bool) get_option( 'webmcp_gateway_activity_log_on', 1 ) ) {
				return;
			}

			$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
			if ( '' === $ua ) {
				return;
			}

			$known_bots = array(
				'OAI-SearchBot'     => 'ChatGPT Search (OAI-SearchBot)',
				'ChatGPT-User'      => 'ChatGPT Live Browsing Agent',
				'GPTBot'            => 'OpenAI GPTBot Crawler',
				'PerplexityBot'     => 'Perplexity AI Answer Engine',
				'Perplexity-User'   => 'Perplexity Live User Agent',
				'ClaudeBot'         => 'Anthropic ClaudeBot',
				'Claude-Web'        => 'Anthropic Claude Web Agent',
				'Google-Extended'   => 'Google Gemini / AI Overviews',
				'Applebot-Extended' => 'Apple Intelligence Crawler',
				'DuckAssistBot'     => 'DuckDuckGo AI Assist Bot',
			);

			foreach ( $known_bots as $token => $bot_label ) {
				if ( false !== stripos( $ua, $token ) ) {
					$uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
					self::record_event(
						'bot_crawl',
						$bot_label,
						$uri,
						__( 'Read page HTML + Schema.org @graph', 'webmcp-gateway' )
					);
					break;
				}
			}
		}

		/**
		 * Record an AI event into the local ring buffer (capped at 60 events).
		 *
		 * @param string $type    Event category.
		 * @param string $actor   Tool name or AI Agent label.
		 * @param string $target  Target endpoint, post title, or query.
		 * @param string $summary Plain-English explanation of what happened.
		 * @return void
		 */
		public static function record_event( $type, $actor, $target, $summary ) {
			if ( ! (bool) get_option( 'webmcp_gateway_activity_log_on', 1 ) ) {
				return;
			}

			$events = get_option( 'webmcp_gateway_activity_events', array() );
			if ( ! is_array( $events ) ) {
				$events = array();
			}

			array_unshift(
				$events,
				array(
					'time'    => current_time( 'mysql' ),
					'type'    => sanitize_key( (string) $type ),
					'actor'   => sanitize_text_field( (string) $actor ),
					'target'  => sanitize_text_field( (string) $target ),
					'summary' => sanitize_text_field( (string) $summary ),
				)
			);

			if ( count( $events ) > 60 ) {
				$events = array_slice( $events, 0, 60 );
			}

			update_option( 'webmcp_gateway_activity_events', $events, false );

			$counters = get_option( 'webmcp_gateway_activity_counters', array() );
			if ( ! is_array( $counters ) ) {
				$counters = array();
			}
			$key              = sanitize_key( (string) $type );
			$counters[ $key ] = isset( $counters[ $key ] ) ? ( (int) $counters[ $key ] + 1 ) : 1;
			update_option( 'webmcp_gateway_activity_counters', $counters, false );
		}

		/**
		 * Retrieve recent activity log events.
		 *
		 * @return array
		 */
		public static function get_events() {
			$events = get_option( 'webmcp_gateway_activity_events', array() );
			return is_array( $events ) ? $events : array();
		}

		/**
		 * Retrieve lifetime activity counters.
		 *
		 * @return array
		 */
		public static function get_counters() {
			$defaults = array(
				'tool_call' => 0,
				'markdown'  => 0,
				'llmstxt'   => 0,
				'wellknown' => 0,
				'bot_crawl' => 0,
				'xray'      => 0,
			);
			$saved    = get_option( 'webmcp_gateway_activity_counters', array() );
			return is_array( $saved ) ? array_merge( $defaults, $saved ) : $defaults;
		}

		/**
		 * Automatically extract Question & Answer pairs from H2/H3 headings ending with `?`
		 * followed by a paragraph in the post content.
		 *
		 * @param string $html Post HTML content.
		 * @return array
		 */
		public static function extract_auto_faqs_from_html( $html ) {
			$clean = strip_shortcodes( (string) $html );
			$faqs  = array();

			$pattern = '/<h[23][^>]*>(.*?\?)<\/h[23]>\s*(?:<!--[^>]*-->\s*)*<p[^>]*>(.*?)<\/p>/is';
			if ( preg_match_all( $pattern, $clean, $matches, PREG_SET_ORDER ) ) {
				foreach ( $matches as $m ) {
					$q = trim( wp_strip_all_tags( html_entity_decode( $m[1], ENT_QUOTES, 'UTF-8' ) ) );
					$a = trim( wp_strip_all_tags( html_entity_decode( $m[2], ENT_QUOTES, 'UTF-8' ) ) );
					if ( '' !== $q && strlen( $a ) >= 20 ) {
						$faqs[] = array(
							'q' => $q,
							'a' => wp_trim_words( $a, 65 ),
						);
					}
					if ( count( $faqs ) >= 8 ) {
						break;
					}
				}
			}

			return $faqs;
		}

		/**
		 * Automatically synthesize a clean TL;DR summary from the post lead paragraph
		 * if no custom AI Summary was entered in the post metabox.
		 *
		 * @param WP_Post $post Target post object.
		 * @return string
		 */
		public static function get_effective_ai_summary( $post ) {
			if ( ! ( $post instanceof WP_Post ) ) {
				return '';
			}
			$manual = trim( (string) get_post_meta( $post->ID, '_webmcp_gateway_ai_summary', true ) );
			if ( '' !== $manual ) {
				return $manual;
			}

			if ( ! empty( $post->post_excerpt ) ) {
				return wp_trim_words( wp_strip_all_tags( $post->post_excerpt ), 38 );
			}

			$clean = strip_shortcodes( $post->post_content );
			if ( preg_match( '/<p[^>]*>(.*?)<\/p>/is', $clean, $m ) ) {
				$first_p = trim( wp_strip_all_tags( html_entity_decode( $m[1], ENT_QUOTES, 'UTF-8' ) ) );
				if ( strlen( $first_p ) >= 30 ) {
					return wp_trim_words( $first_p, 42 );
				}
			}

			return wp_trim_words( wp_strip_all_tags( $clean ), 38 );
		}

		/**
		 * Generate high-intent "Answer-Gap" questions for a post topic so SEO users know
		 * what questions to answer in their article or FAQPage schema to win AI citations.
		 *
		 * @param WP_Post $post Target post.
		 * @return array
		 */
		public static function generate_answer_gap_questions( $post ) {
			if ( ! ( $post instanceof WP_Post ) ) {
				return array();
			}
			$title = trim( wp_strip_all_tags( get_the_title( $post ) ) );
			if ( '' === $title ) {
				$title = (string) get_bloginfo( 'name' );
			}

			// Strip trailing site name or punctuation to isolate the core topic.
			$topic = preg_replace( '/\s*[\|\-–—:]\s*.*$/u', '', $title );
			$topic = trim( (string) $topic );
			if ( '' === $topic ) {
				$topic = $title;
			}

			$summary   = self::get_effective_ai_summary( $post );
			$paragraphs = array();
			$clean      = strip_shortcodes( $post->post_content );
			if ( preg_match_all( '/<p[^>]*>(.*?)<\/p>/is', $clean, $pm ) ) {
				foreach ( $pm[1] as $raw_p ) {
					$p = trim( wp_strip_all_tags( html_entity_decode( $raw_p, ENT_QUOTES, 'UTF-8' ) ) );
					if ( strlen( $p ) >= 40 ) {
						$paragraphs[] = wp_trim_words( $p, 55 );
					}
					if ( count( $paragraphs ) >= 4 ) {
						break;
					}
				}
			}
			// Draft answers must be real prose (schema.org rejects instructional placeholders).
			$draft_def  = '' !== $summary ? $summary : ( isset( $paragraphs[0] ) ? $paragraphs[0] : '' );
			$draft_how  = isset( $paragraphs[1] ) ? $paragraphs[1] : ( isset( $paragraphs[0] ) ? $paragraphs[0] : $draft_def );
			$draft_ben  = isset( $paragraphs[2] ) ? $paragraphs[2] : $draft_how;
			$draft_mist = isset( $paragraphs[3] ) ? $paragraphs[3] : $draft_ben;

			return array(
				array(
					/* translators: %s: Core post topic */
					'q'      => sprintf( __( 'What is %s and why does it matter?', 'webmcp-gateway' ), $topic ),
					'a_hint' => $draft_def,
					'intent' => __( 'Definitional Overview (Google AI Overviews & Perplexity Lead Citation)', 'webmcp-gateway' ),
				),
				array(
					/* translators: %s: Core post topic */
					'q'      => sprintf( __( 'How does %s work step by step?', 'webmcp-gateway' ), $topic ),
					'a_hint' => $draft_how,
					'intent' => __( 'Procedural / How-To Query (ChatGPT Search & Claude Prompt)', 'webmcp-gateway' ),
				),
				array(
					/* translators: %s: Core post topic */
					'q'      => sprintf( __( 'What are the main benefits and best practices for %s?', 'webmcp-gateway' ), $topic ),
					'a_hint' => $draft_ben,
					'intent' => __( 'Comparative Evaluation (Buyer / Decision-Maker Prompt)', 'webmcp-gateway' ),
				),
				array(
					/* translators: %s: Core post topic */
					'q'      => sprintf( __( 'What are the most common mistakes to avoid with %s?', 'webmcp-gateway' ), $topic ),
					'a_hint' => $draft_mist,
					'intent' => __( 'Troubleshooting / Problem-Solving Query', 'webmcp-gateway' ),
				),
			);
		}

		/**
		 * Run a complete local AEO & Agent X-Ray Audit on a specific WP_Post.
		 *
		 * @param WP_Post $post Target post.
		 * @return array
		 */
		public static function run_post_xray_audit( $post ) {
			$post_id       = (int) $post->ID;
			$title         = get_the_title( $post );
			$permalink     = (string) get_permalink( $post );
			$md_url        = add_query_arg( 'format', 'markdown', $permalink );
			$manual_sum    = trim( (string) get_post_meta( $post_id, '_webmcp_gateway_ai_summary', true ) );
			$effective_sum = self::get_effective_ai_summary( $post );
			$plain_body    = wp_strip_all_tags( strip_shortcodes( $post->post_content ) );
			$word_count    = webmcp_gateway_word_count( $plain_body );

			$headings          = array();
			$question_headings = array();
			if ( preg_match_all( '/<h([23])[^>]*>(.*?)<\/h\1>/is', $post->post_content, $h_matches, PREG_SET_ORDER ) ) {
				foreach ( $h_matches as $hm ) {
					$h_text = trim( wp_strip_all_tags( html_entity_decode( $hm[2], ENT_QUOTES, 'UTF-8' ) ) );
					if ( '' !== $h_text ) {
						$headings[] = 'H' . $hm[1] . ': ' . $h_text;
						if ( '?' === substr( $h_text, -1 ) ) {
							$question_headings[] = $h_text;
						}
					}
				}
			}

			$first_paragraph = '';
			if ( preg_match( '/<p[^>]*>(.*?)<\/p>/is', strip_shortcodes( $post->post_content ), $p_match ) ) {
				$first_paragraph = trim( wp_strip_all_tags( html_entity_decode( $p_match[1], ENT_QUOTES, 'UTF-8' ) ) );
			}
			if ( '' === $first_paragraph ) {
				$first_paragraph = wp_trim_words( $plain_body, 45 );
			}

			$manual_faqs = get_post_meta( $post_id, '_webmcp_gateway_faq_items', true );
			$manual_faqs = is_array( $manual_faqs ) ? $manual_faqs : array();
			$auto_faqs   = self::extract_auto_faqs_from_html( $post->post_content );
			$all_faqs    = ! empty( $manual_faqs ) ? $manual_faqs : $auto_faqs;

			$schema_graph = WebMCP_Gateway_Schema_Graph::generate( $post_id, 'single' );
			$entity_cards = array();
			if ( isset( $schema_graph['@graph'] ) && is_array( $schema_graph['@graph'] ) ) {
				foreach ( $schema_graph['@graph'] as $node ) {
					$type           = isset( $node['@type'] ) ? (string) $node['@type'] : 'Thing';
					$id             = isset( $node['@id'] ) ? (string) $node['@id'] : '';
					$name           = isset( $node['name'] ) ? (string) $node['name'] : ( isset( $node['headline'] ) ? (string) $node['headline'] : $type );
					$entity_cards[] = array(
						'type' => $type,
						'name' => $name,
						'id'   => $id,
					);
				}
			}

			$score  = 0;
			$checks = array();

			if ( ! empty( $entity_cards ) ) {
				$score   += 20;
				$checks[] = array(
					'status' => 'pass',
					'title'  => __( 'Schema.org @graph Injected (20/20 pts)', 'webmcp-gateway' ),
					'advice' => sprintf(
						/* translators: %d: Number of schema entities */
						__( 'Pass! %d connected Schema.org entities are live on this page.', 'webmcp-gateway' ),
						count( $entity_cards )
					),
				);
			} else {
				$checks[] = array(
					'status' => 'warn',
					'title'  => __( 'Schema.org @graph Disabled (0/20 pts)', 'webmcp-gateway' ),
					'advice' => __( 'Enable the Schema.org @graph Engine in AEO Settings so AI engines can disambiguate this page.', 'webmcp-gateway' ),
				);
			}

			$speakable_disabled = (bool) get_post_meta( $post_id, '_webmcp_gateway_speakable_disable', true );
			if ( (bool) get_option( 'webmcp_gateway_speakable_enabled', 1 ) && ! $speakable_disabled && strlen( $first_paragraph ) >= 40 ) {
				$score   += 20;
				$checks[] = array(
					'status' => 'pass',
					'title'  => __( 'Speakable Citation Target Verified (20/20 pts)', 'webmcp-gateway' ),
					'advice' => __( 'Pass! Answer engines have a clear headline and lead paragraph to quote in AI Overviews.', 'webmcp-gateway' ),
				);
			} else {
				$score   += 10;
				$checks[] = array(
					'status' => 'warn',
					'title'  => __( 'Speakable Lead Passage Too Short (10/20 pts)', 'webmcp-gateway' ),
					'advice' => __( 'Write a clear 2–3 sentence opening paragraph (40+ characters) that directly answers the topic.', 'webmcp-gateway' ),
				);
			}

			if ( '' !== $manual_sum ) {
				$score   += 20;
				$checks[] = array(
					'status' => 'pass',
					'title'  => __( 'Custom AI Direct Answer / TL;DR Set (20/20 pts)', 'webmcp-gateway' ),
					'advice' => __( 'Pass! Your custom executive summary is embedded in Schema.org abstract, /llms.txt, and MCP getPostContent.', 'webmcp-gateway' ),
				);
			} elseif ( '' !== $effective_sum ) {
				$score   += 14;
				$checks[] = array(
					'status' => 'warn',
					'title'  => __( 'Using Auto-Synthesized TL;DR Summary (14/20 pts)', 'webmcp-gateway' ),
					'advice' => __( 'Good! We auto-generated an AI summary from your first paragraph. To get 20/20, write a tailored TL;DR in the post editor AEO box.', 'webmcp-gateway' ),
				);
			}

			if ( ! empty( $all_faqs ) ) {
				$score       += 20;
				$source_label = ! empty( $manual_faqs ) ? __( 'manual metabox', 'webmcp-gateway' ) : __( 'auto-extracted H2/H3 question headings', 'webmcp-gateway' );
				$checks[]     = array(
					'status' => 'pass',
					'title'  => __( 'FAQPage Schema Active (20/20 pts)', 'webmcp-gateway' ),
					'advice' => sprintf(
						/* translators: 1: FAQ count, 2: FAQ source label */
						__( 'Pass! %1$d Question & Answer pairs (%2$s) are broadcast in FAQPage JSON-LD and AI Markdown.', 'webmcp-gateway' ),
						count( $all_faqs ),
						$source_label
					),
				);
			} else {
				$checks[] = array(
					'status' => 'warn',
					'title'  => __( 'No FAQPage Schema Yet — Use the Answer-Gap Finder Below! (0/20 pts)', 'webmcp-gateway' ),
					'advice' => __( 'Click "1-Click Inject Answer-Gap FAQs into This Post" below (or add H2/H3 headings ending in "?") to immediately add FAQPage schema and gain +20 AEO points!', 'webmcp-gateway' ),
				);
			}

			$has_thumb = has_post_thumbnail( $post_id );
			if ( $word_count >= 300 && count( $headings ) >= 2 && $has_thumb ) {
				$score   += 20;
				$checks[] = array(
					'status' => 'pass',
					'title'  => __( 'Strong Content Depth & Visual Entity (20/20 pts)', 'webmcp-gateway' ),
					'advice' => sprintf(
						/* translators: 1: Word count, 2: Subheading count */
						__( 'Pass! %1$d words, %2$d structured subheadings, and a Featured ImageObject are present.', 'webmcp-gateway' ),
						$word_count,
						count( $headings )
					),
				);
			} else {
				$partial  = ( $word_count >= 150 ? 8 : 4 ) + ( ! empty( $headings ) ? 4 : 0 ) + ( $has_thumb ? 4 : 0 );
				$score   += $partial;
				$checks[] = array(
					'status' => 'warn',
					'title'  => sprintf(
						/* translators: %d: Partial score out of 20 */
						__( 'Content Structure & Entity Signals (%d/20 pts)', 'webmcp-gateway' ),
						$partial
					),
					'advice' => __( 'Aim for 300+ words, at least two H2/H3 subheadings, and a Featured Image so Google Discover and AI answer engines rank this page higher.', 'webmcp-gateway' ),
				);
			}

			$grade = 'A+';
			if ( $score < 60 ) {
				$grade = 'C';
			} elseif ( $score < 75 ) {
				$grade = 'B';
			} elseif ( $score < 90 ) {
				$grade = 'A';
			}

			self::record_event(
				'xray',
				'Admin AEO X-Ray Scanner',
				$title,
				sprintf(
					/* translators: 1: Post ID, 2: Score, 3: Grade */
					__( 'Audited Post #%1$d — Score: %2$d/100 (%3$s)', 'webmcp-gateway' ),
					$post_id,
					$score,
					$grade
				)
			);

			return array(
				'post_id'            => $post_id,
				'title'              => $title,
				'url'                => $permalink,
				'edit_url'           => get_edit_post_link( $post_id, 'raw' ),
				'markdown_url'       => $md_url,
				'rich_results_url'   => 'https://search.google.com/test/rich-results?url=' . rawurlencode( $permalink ),
				'schema_val_url'     => 'https://validator.schema.org/#url=' . rawurlencode( $permalink ),
				'score'              => $score,
				'grade'              => $grade,
				'word_count'         => $word_count,
				'headings_count'     => count( $headings ),
				'question_h_count'   => count( $question_headings ),
				'faq_count'          => count( $all_faqs ),
				'faqs'               => $all_faqs,
				'answer_gaps'        => self::generate_answer_gap_questions( $post ),
				'speakable_headline' => $title,
				'speakable_summary'  => $effective_sum,
				'speakable_lead'     => $first_paragraph,
				'entity_cards'       => $entity_cards,
				'checks'             => $checks,
				'markdown_preview'   => WebMCP_Gateway_Markdown::build_post_markdown_document( $post ),
				'schema_json'        => wp_json_encode( $schema_graph, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
			);
		}
	}
}
