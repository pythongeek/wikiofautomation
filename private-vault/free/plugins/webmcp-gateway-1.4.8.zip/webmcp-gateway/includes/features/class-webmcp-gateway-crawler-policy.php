<?php
/**
 * Per-Bot AI Crawler Policy Matrix & Virtual robots.txt Enhancer - WebMCP Gateway.
 *
 * Allows site owners to individually Allow or Disallow specific AI bots
 * (ChatGPT Search, Perplexity, Claude, Google Gemini, GPTBot training, CCBot)
 * in WordPress's virtual robots.txt.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WebMCP_Gateway_Crawler_Policy' ) ) {
	/**
	 * Manages granular per-bot robots.txt directives and AI snippet meta tags.
	 */
	final class WebMCP_Gateway_Crawler_Policy {

		/**
		 * Register robots_txt and wp_robots filters.
		 *
		 * @return void
		 */
		public static function init() {
			WebMCP_Gateway_Loader::register_filter( 'robots_txt', array( __CLASS__, 'filter_robots_txt' ), 20, 2 );
			WebMCP_Gateway_Loader::register_filter( 'wp_robots', array( __CLASS__, 'filter_wp_robots' ), 20 );
			// robots.txt and discovery output are page-cacheable: purge popular page caches
			// (LiteSpeed et al.) whenever a policy option changes, so crawlers never see stale rules.
			WebMCP_Gateway_Loader::register_action( 'update_option_webmcp_gateway_robots_enabled', array( __CLASS__, 'purge_page_cache' ) );
			WebMCP_Gateway_Loader::register_action( 'update_option_webmcp_gateway_llmstxt_enabled', array( __CLASS__, 'purge_page_cache' ) );
			WebMCP_Gateway_Loader::register_action( 'update_option_webmcp_gateway_llmsfull_enabled', array( __CLASS__, 'purge_page_cache' ) );
			foreach ( array_keys( self::get_bot_matrix_definitions() ) as $webmcp_gateway_bot_option ) {
				WebMCP_Gateway_Loader::register_action( 'update_option_' . $webmcp_gateway_bot_option, array( __CLASS__, 'purge_page_cache' ) );
			}
		}

		/**
		 * Return the bot labels. Translated lazily — calling this before `init`
			* would trigger just-in-time translation loading too early (WP 6.7 notice).
		 *
		 * @return array<string, string> Bot option key => translated label.
		 */
		public static function get_bot_matrix_labels() {
			return array(
				'webmcp_gateway_bot_oai_search'   => __( 'ChatGPT Search (OAI-SearchBot) — Live AI Search Citations', 'webmcp-gateway' ),
				'webmcp_gateway_bot_chatgpt_user' => __( 'ChatGPT User Agent (ChatGPT-User) — Live User Browsing', 'webmcp-gateway' ),
				'webmcp_gateway_bot_perplexity'   => __( 'Perplexity AI (PerplexityBot) — Answer Engine Citations', 'webmcp-gateway' ),
				'webmcp_gateway_bot_claude'       => __( 'Anthropic Claude (ClaudeBot) — Claude Search & Citations', 'webmcp-gateway' ),
				'webmcp_gateway_bot_google_ext'   => __( 'Google-Extended — Gemini / AI Overviews Training', 'webmcp-gateway' ),
				'webmcp_gateway_bot_gptbot'       => __( 'OpenAI GPTBot — Model Training Crawler', 'webmcp-gateway' ),
				'webmcp_gateway_bot_ccbot'        => __( 'Common Crawl (CCBot) — Dataset & Training Crawler', 'webmcp-gateway' ),
			);
		}

		/**
		 * Purge the LiteSpeed page cache after crawler-policy changes.
		 *
		 * @return void
		 */
		public static function purge_page_cache() {
			if ( class_exists( 'LiteSpeed_Cache_API' ) && method_exists( 'LiteSpeed_Cache_API', 'purge_all' ) ) {
				LiteSpeed_Cache_API::purge_all();
			}
		}

		/**
		 * Return the configurable AI bot definitions.
		 *
		 * @return array
		 */
		public static function get_bot_matrix_definitions() {
			// Labels are intentionally NOT translated here: this array is read at
			// plugins_loaded (see init()), before the 'init' action where WordPress
			// allows translation loading. Use get_bot_matrix_labels() for display.
			return array(
				'webmcp_gateway_bot_oai_search'   => array(
					'ua'    => 'OAI-SearchBot',
					'label' => 'ChatGPT Search (OAI-SearchBot)',
				),
				'webmcp_gateway_bot_chatgpt_user' => array(
					'ua'    => 'ChatGPT-User',
					'label' => 'ChatGPT-User',
				),
				'webmcp_gateway_bot_perplexity'   => array(
					'ua'    => 'PerplexityBot',
					'label' => 'PerplexityBot',
				),
				'webmcp_gateway_bot_claude'       => array(
					'ua'    => 'ClaudeBot',
					'label' => 'ClaudeBot',
				),
				'webmcp_gateway_bot_google_ext'   => array(
					'ua'    => 'Google-Extended',
					'label' => 'Google-Extended',
				),
				'webmcp_gateway_bot_gptbot'       => array(
					'ua'    => 'GPTBot',
					'label' => 'GPTBot',
				),
				'webmcp_gateway_bot_ccbot'        => array(
					'ua'    => 'CCBot',
					'label' => 'CCBot',
				),
			);
		}

		/**
		 * Return the configurable Content Signals policies (contentsignals.org).
		 *
		 * @return array<string, array{label: string, value: string}>
		 */
		public static function get_content_signal_presets() {
			return array(
				'off'        => array(
					'label' => __( 'Off — do not emit a Content-Signal line', 'webmcp-gateway' ),
					'value' => '',
				),
				'allow_all'  => array(
					'label' => __( 'Allow all — ai-train=yes, search=yes, ai-input=yes', 'webmcp-gateway' ),
					'value' => 'ai-train=yes, search=yes, ai-input=yes',
				),
				'no_training' => array(
					'label' => __( 'Cite, don\'t train — ai-train=no, search=yes, ai-input=yes', 'webmcp-gateway' ),
					'value' => 'ai-train=no, search=yes, ai-input=yes',
				),
				'search_only' => array(
					'label' => __( 'Search only — ai-train=no, search=yes, ai-input=no', 'webmcp-gateway' ),
					'value' => 'ai-train=no, search=yes, ai-input=no',
				),
				'block_all'  => array(
					'label' => __( 'Block all AI usage — ai-train=no, search=no, ai-input=no', 'webmcp-gateway' ),
					'value' => 'ai-train=no, search=no, ai-input=no',
				),
			);
		}

		/**
		 * Resolve the active Content-Signal directive string (empty = off).
		 *
		 * @return string
		 */
		public static function get_content_signal() {
			$choice = (string) get_option( 'webmcp_gateway_content_signal', 'allow_all' );
			$presets = self::get_content_signal_presets();
			if ( ! isset( $presets[ $choice ] ) ) {
				$choice = 'allow_all';
			}
			return (string) $presets[ $choice ]['value'];
		}

		/**
		 * Append per-bot AI crawler access rules, Content Signals and discovery pointers to virtual robots.txt.
		 *
		 * @param mixed $output Existing robots.txt content.
		 * @param mixed $public Whether the site is public.
		 * @return string
		 */
		public static function filter_robots_txt( $output = '', $public = true ) {
			$output = (string) $output;
			if ( ! $public || ! (bool) get_option( 'webmcp_gateway_robots_enabled', 1 ) ) {
				return $output;
			}

			$lines   = array();
			$lines[] = '';
			$lines[] = '# WebMCP Gateway - AI Answer Engine & Per-Bot Crawler Policy';

			$signal = self::get_content_signal();
			if ( '' !== $signal ) {
				$lines[] = 'Content-Signal: ' . $signal;
			}

			$matrix = self::get_bot_matrix_definitions();
			foreach ( $matrix as $opt_key => $bot ) {
				$policy  = (string) get_option( $opt_key, 'allow' );
				$lines[] = 'User-agent: ' . $bot['ua'];
				if ( 'disallow' === $policy ) {
					$lines[] = 'Disallow: /';
				} else {
					$lines[] = 'Allow: /';
				}
			}

			if ( (bool) get_option( 'webmcp_gateway_llmstxt_enabled', 1 ) ) {
				$lines[] = 'LLMs-Txt: ' . esc_url_raw( home_url( '/llms.txt' ) );
			}
			$lines[] = 'MCP-Manifest: ' . esc_url_raw( home_url( '/.well-known/mcp.json' ) );
			$lines[] = 'Agentmap: ' . esc_url_raw( home_url( '/.well-known/ai-catalog.json' ) );

			return rtrim( $output ) . "\n" . implode( "\n", $lines ) . "\n";
		}

		/**
		 * Ensure rich snippet directives (`max-snippet:-1`, `max-image-preview:large`) are active.
		 *
		 * @param mixed $robots WordPress robots meta directives.
		 * @return array
		 */
		public static function filter_wp_robots( $robots = array() ) {
			if ( ! is_array( $robots ) ) {
				$robots = array();
			}
			if ( ! WebMCP_Gateway_Frontend::is_enabled() ) {
				return $robots;
			}
			if ( ! empty( $robots['noindex'] ) ) {
				return $robots;
			}

			$robots['max-snippet']       = '-1';
			$robots['max-image-preview'] = 'large';
			return $robots;
		}
	}
}
