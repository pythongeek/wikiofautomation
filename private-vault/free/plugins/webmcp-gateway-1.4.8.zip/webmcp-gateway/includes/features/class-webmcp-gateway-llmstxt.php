<?php
/**
 * /llms.txt & /llms-full.txt Discovery Handler - WebMCP Gateway.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WebMCP_Gateway_LlmsTxt' ) ) {
	/**
	 * Generates and serves /llms.txt and /llms-full.txt.
	 */
	final class WebMCP_Gateway_LlmsTxt {

		/**
		 * Register rewrite rules, query vars, and template redirect handler.
		 *
		 * @return void
		 */
		public static function init() {
			WebMCP_Gateway_Loader::register_action( 'init', array( __CLASS__, 'add_rewrite_rules' ) );
			WebMCP_Gateway_Loader::register_filter( 'query_vars', array( __CLASS__, 'add_query_vars' ) );
			WebMCP_Gateway_Loader::register_action( 'template_redirect', array( __CLASS__, 'serve' ), 1 );
			WebMCP_Gateway_Loader::register_action( 'save_post', array( __CLASS__, 'bump_rev' ) );
			WebMCP_Gateway_Loader::register_action( 'deleted_post', array( __CLASS__, 'bump_rev' ) );
			WebMCP_Gateway_Loader::register_action( 'updated_option', array( __CLASS__, 'bump_rev_on_option' ) );
		}

		/**
		 * Register rewrite rules for /llms.txt and /llms-full.txt.
		 *
		 * @return void
		 */
		public static function add_rewrite_rules() {
			add_rewrite_rule( '^llms\.txt$', 'index.php?webmcp_gateway_llmstxt=summary', 'top' );
			add_rewrite_rule( '^llms-full\.txt$', 'index.php?webmcp_gateway_llmstxt=full', 'top' );
		}

		/**
		 * Register custom query variable.
		 *
		 * @param mixed $vars Public query vars.
		 * @return array
		 */
		public static function add_query_vars( $vars = array() ) {
			if ( ! is_array( $vars ) ) {
				$vars = array();
			}
			$vars[] = 'webmcp_gateway_llmstxt';
			return $vars;
		}

		/**
		 * Serve /llms.txt or /llms-full.txt if matched by query var or request path.
		 *
		 * @return void
		 */
		public static function serve() {
			if ( ! (bool) get_option( 'webmcp_gateway_llmstxt_enabled', 1 ) ) {
				return;
			}

			$qv   = (string) get_query_var( 'webmcp_gateway_llmstxt' );
			$uri  = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
			$path = trim( (string) wp_parse_url( $uri, PHP_URL_PATH ), '/' );

			$is_full    = ( 'full' === $qv || 'llms-full.txt' === $path || (bool) preg_match( '/(^|\/)llms-full\.txt$/i', $path ) );
			$is_summary = ( 'summary' === $qv || '1' === $qv || 'llms.txt' === $path || (bool) preg_match( '/(^|\/)llms\.txt$/i', $path ) );

			if ( ! $is_full && ! $is_summary ) {
				return;
			}

			if ( $is_full && ! (bool) get_option( 'webmcp_gateway_llmsfull_enabled', 1 ) ) {
				return;
			}

			WebMCP_Gateway_Activity_Log::record_event(
				'llmstxt',
				$is_full ? '/llms-full.txt' : '/llms.txt',
				home_url( $is_full ? '/llms-full.txt' : '/llms.txt' ),
				__( 'Served AI corpus index to requester', 'webmcp-gateway' )
			);

			$text = self::cached_text( $is_full ? 'full' : 'summary' );

			if ( ! headers_sent() ) {
				status_header( 200 );
				header( 'Content-Type: text/plain; charset=utf-8' );
				header( 'X-Content-Type-Options: nosniff' );
				header( 'Access-Control-Allow-Origin: *' );
				header( 'x-litespeed-cache-control: no-cache' );
				WebMCP_Gateway_Frontend::send_hardening_headers();
			}

			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo $text;
			exit;
		}

		/**
		 * Build the /llms.txt summary index.
		 *
		 * @return string
		 */
		/**
		 * Bump the llms.txt revision whenever published content changes.
		 *
		 * @return void
		 */
		public static function bump_rev() {
			update_option( 'webmcp_gateway_llmstxt_rev', (int) get_option( 'webmcp_gateway_llmstxt_rev', 0 ) + 1, false );
		}

		/**
		 * Hook: same revision bump when a plugin setting changes.
		 *
		 * @param mixed $option Option name.
		 * @return void
		 */
		public static function bump_rev_on_option( $option = '' ) {
			// Skip internal keys (including both revs) — bumping a rev here would
			// re-trigger this hook and recurse infinitely.
			if ( ! is_string( $option ) || 0 !== strpos( $option, 'webmcp_gateway_' ) ) {
				return;
			}
			$internal = array(
				'webmcp_gateway_llmstxt_rev',
				'webmcp_gateway_llmstxt_cache',
				'webmcp_gateway_schema_rev',
				'webmcp_gateway_api_keys',
				'webmcp_gateway_activity_events',
				'webmcp_gateway_activity_counters',
				'webmcp_gateway_installed_version',
			);
			foreach ( $internal as $skip ) {
				if ( $option === $skip || 0 === strpos( $option, $skip . '_' ) ) {
					return;
				}
			}
			self::bump_rev();
		}

		/**
		 * Return the generated llms.txt variant, cached until content/settings change.
		 *
		 * @param string $variant 'summary' or 'full'.
		 * @return string
		 */
		public static function cached_text( $variant ) {
			$rev     = (int) get_option( 'webmcp_gateway_llmstxt_rev', 0 );
			$version = WEBMCP_CORE_VERSION;
			$entry   = get_option( 'webmcp_gateway_llmstxt_cache', array() );

			if ( is_array( $entry ) && isset( $entry['rev'], $entry['version'], $entry[ $variant ] )
				&& (int) $entry['rev'] === $rev && (string) $entry['version'] === $version ) {
				return (string) $entry[ $variant ];
			}

			$text      = ( 'full' === $variant ) ? self::generate_full_content() : self::generate_summary_content();
			$has_entry = is_array( $entry ) && isset( $entry['rev'], $entry['version'] )
				&& (int) $entry['rev'] === $rev && (string) $entry['version'] === $version;

			if ( ! $has_entry ) {
				// Rebuild both variants together so one regeneration serves either path.
				$entry = array(
					'rev'     => $rev,
					'version' => $version,
					'summary' => ( 'summary' === $variant ) ? $text : self::generate_summary_content(),
					'full'    => ( 'full' === $variant ) ? $text : self::generate_full_content(),
				);
			} else {
				$entry[ $variant ] = $text;
			}

			update_option( 'webmcp_gateway_llmstxt_cache', $entry, false );
			return $text;
		}

		public static function generate_summary_content() {
			$limit_pages    = (int) apply_filters( 'webmcp_gateway_llmstxt_page_limit', 10 );
			$limit_posts    = (int) apply_filters( 'webmcp_gateway_llmstxt_post_limit', 15 );
			$limit_products = (int) apply_filters( 'webmcp_gateway_llmstxt_product_limit', 10 );
			$site_name = wp_strip_all_tags( (string) get_bloginfo( 'name' ) );
			$site_desc = wp_strip_all_tags( (string) get_bloginfo( 'description' ) );

			$lines   = array();
			$lines[] = '# ' . ( '' !== $site_name ? $site_name : 'WordPress Site' );
			if ( '' !== $site_desc ) {
				$lines[] = '';
				$lines[] = '> ' . $site_desc;
			}
			$lines[] = '';
			$lines[] = 'This site supports the Model Context Protocol (WebMCP) and clean Markdown content negotiation for AI agents and answer engines. Append `?format=markdown` to any article URL to retrieve clean semantic Markdown.';
			$lines[] = '';
			$lines[] = '## Model Context Protocol (MCP) Endpoints';
			$lines[] = '- [Well-Known MCP Server](' . home_url( '/.well-known/mcp.json' ) . '): Discovery metadata and server endpoints';
			$lines[] = '- [MCP Manifest](' . rest_url( 'webmcp-gateway/v1/manifest' ) . '): Full JSON Schema tool definitions';
			$lines[] = '- [Callable Read Tools](' . rest_url( 'webmcp-gateway/v1/tools' ) . '): `getSiteInfo`, `searchSite`, `getFeaturedContent`, `getPostContent`, `getSiteTaxonomies`, `getCatalogItems`';
			if ( (bool) get_option( 'webmcp_gateway_llmsfull_enabled', 1 ) ) {
				$lines[] = '- [Full Corpus Index](' . home_url( '/llms-full.txt' ) . '): Extended Markdown summaries of published content';
			}

			$pages = get_posts(
				array(
					'post_type'      => 'page',
					'post_status'    => 'publish',
					'posts_per_page' => $limit_pages,
					'no_found_rows'  => true,
					'orderby'        => 'menu_order',
					'order'          => 'ASC',
				)
			);
			if ( ! empty( $pages ) ) {
				$lines[] = '';
				$lines[] = '## Key Pages';
				foreach ( $pages as $page ) {
					$title   = wp_strip_all_tags( get_the_title( $page ) );
					$url     = get_permalink( $page );
					$sum     = WebMCP_Gateway_Activity_Log::get_effective_ai_summary( $page );
					$lines[] = sprintf( '- [%s](%s): %s', $title, $url, $sum );
				}
			}

			$posts = get_posts(
				array(
					'post_type'      => 'post',
					'post_status'    => 'publish',
					'posts_per_page' => $limit_posts,
					'no_found_rows'  => true,
				)
			);
			if ( ! empty( $posts ) ) {
				$lines[] = '';
				$lines[] = '## Recent Articles';
				foreach ( $posts as $post ) {
					$title   = wp_strip_all_tags( get_the_title( $post ) );
					$url     = get_permalink( $post );
					$sum     = WebMCP_Gateway_Activity_Log::get_effective_ai_summary( $post );
					$lines[] = sprintf( '- [%s](%s): %s ([Markdown](%s))', $title, $url, $sum, add_query_arg( 'format', 'markdown', $url ) );
				}
			}

			if ( post_type_exists( 'product' ) ) {
				$products = get_posts(
					array(
						'post_type'      => 'product',
						'post_status'    => 'publish',
						'posts_per_page' => $limit_products,
						'no_found_rows'  => true,
					)
				);
				if ( ! empty( $products ) ) {
					$lines[] = '';
					$lines[] = '## Products & Catalog';
					foreach ( $products as $prod ) {
						$title   = wp_strip_all_tags( get_the_title( $prod ) );
						$url     = get_permalink( $prod );
						$sum     = WebMCP_Gateway_Activity_Log::get_effective_ai_summary( $prod );
						$lines[] = sprintf( '- [%s](%s): %s', $title, $url, $sum );
					}
				}
			}

			return implode( "\n", $lines ) . "\n";
		}

		/**
		 * Build the /llms-full.txt comprehensive corpus digest.
		 *
		 * @return string
		 */
		public static function generate_full_content() {
			$limit_full = (int) apply_filters( 'webmcp_gateway_llmstxt_full_limit', 20 );
			$lines   = array();
			$lines[] = self::generate_summary_content();
			$lines[] = '## Full Article Summaries & Structured Digest';
			$lines[] = '';

			$posts = get_posts(
				array(
					'post_type'      => array( 'post', 'page' ),
					'post_status'    => 'publish',
					'posts_per_page' => $limit_full,
					'no_found_rows'  => true,
				)
			);

			foreach ( $posts as $post ) {
				if ( ! empty( $post->post_password ) ) {
					continue;
				}
				$lines[] = '### ' . wp_strip_all_tags( get_the_title( $post ) );
				$lines[] = '- URL: ' . get_permalink( $post );
				$lines[] = '- Published: ' . get_the_date( 'Y-m-d', $post );
				$sum     = WebMCP_Gateway_Activity_Log::get_effective_ai_summary( $post );
				if ( '' !== $sum ) {
					$lines[] = '- AI Summary: ' . $sum;
				}
				$lines[] = '';
				$lines[] = wp_trim_words( WebMCP_Gateway_Markdown::convert_html_to_markdown( $post->post_content ), 120 );
				$lines[] = '';
			}

			return implode( "\n", $lines ) . "\n";
		}
	}
}
