<?php
/**
 * Semantic Markdown Content Negotiation - WebMCP Gateway.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WebMCP_Gateway_Markdown' ) ) {
	/**
	 * Converts WordPress posts, pages, and products into LLM-optimized Markdown documents.
	 */
	final class WebMCP_Gateway_Markdown {

		/**
		 * Register template_redirect hook.
		 *
		 * @return void
		 */
		public static function init() {
			WebMCP_Gateway_Loader::register_action( 'template_redirect', array( __CLASS__, 'serve_if_requested' ), 2 );
			// HTML responses must advertise Vary: Accept so CDNs/LiteSpeed never
			// reuse a previously cached text/markdown body for browser traffic.
			WebMCP_Gateway_Loader::register_action( 'send_headers', array( __CLASS__, 'send_vary_accept' ), 20 );
		}

		/**
		 * Tell shared caches that HTML and Markdown are different representations.
		 *
		 * @return void
		 */
		public static function send_vary_accept() {
			if ( ! (bool) get_option( 'webmcp_gateway_markdown_enabled', 1 ) || headers_sent() ) {
				return;
			}
			header( 'Vary: Accept', false );
		}

		/**
		 * Whether the client explicitly prefers text/markdown over text/html.
		 *
		 * A bare substring match is unsafe: shared caches without Vary: Accept can
		 * poison the HTML URL. We only negotiate when markdown has a higher (or
		 * equal, with no html) q-value than text/html / application/xhtml+xml.
		 *
		 * @param string $accept Raw Accept header.
		 * @return bool
		 */
		public static function client_prefers_markdown( $accept ) {
			$accept = strtolower( (string) $accept );
			if ( '' === $accept || false === strpos( $accept, 'text/markdown' ) ) {
				return false;
			}

			$md_q   = self::accept_q( $accept, 'text/markdown' );
			$html_q = max(
				self::accept_q( $accept, 'text/html' ),
				self::accept_q( $accept, 'application/xhtml+xml' )
			);

			// Agents typically send "text/markdown, text/plain, */*" (md_q=1, html_q=0).
			// Browsers send "text/html,...;q=0.9,*/*;q=0.8" with no text/markdown.
			return $md_q > 0 && $md_q >= $html_q;
		}

		/**
		 * Extract the q-value for a media type from an Accept header.
		 *
		 * @param string $accept Lowercased Accept header.
		 * @param string $type   Media type to look up.
		 * @return float
		 */
		private static function accept_q( $accept, $type ) {
			$parts = array_map( 'trim', explode( ',', $accept ) );
			foreach ( $parts as $part ) {
				if ( 0 !== strpos( $part, $type ) ) {
					continue;
				}
				if ( preg_match( '/;\s*q=([0-9]*\.?[0-9]+)/', $part, $m ) ) {
					return (float) $m[1];
				}
				return 1.0;
			}
			return 0.0;
		}

		/**
		 * Intercept request and output clean Markdown if requested.
		 *
		 * @return void
		 */
		public static function serve_if_requested() {
			if ( ! (bool) get_option( 'webmcp_gateway_markdown_enabled', 1 ) ) {
				return;
			}

			// Public content negotiation parameter (`?format=markdown`) does not mutate state.
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$format = isset( $_GET['format'] ) ? sanitize_key( wp_unslash( $_GET['format'] ) ) : '';
			$accept = isset( $_SERVER['HTTP_ACCEPT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_ACCEPT'] ) ) : '';

			$is_md_param  = in_array( $format, array( 'markdown', 'md' ), true );
			$is_md_accept = self::client_prefers_markdown( $accept );

			if ( ! $is_md_param && ! $is_md_accept ) {
				return;
			}

			$post = get_queried_object();
			if ( $post instanceof WP_Post ) {
				if ( 'publish' !== $post->post_status || ! empty( $post->post_password ) ) {
					return;
				}
				$markdown_doc = self::build_post_markdown_document( $post );
				$log_target   = get_the_title( $post );
				$log_summary  = __( 'Served clean ?format=markdown with YAML frontmatter', 'webmcp-gateway' );
			} else {
				// Site-level Markdown for the homepage/archives — the industry
				// "Markdown for Agents" check negotiates against the site root.
				$markdown_doc = self::build_site_markdown_document();
				$log_target   = home_url( '/' );
				$log_summary  = __( 'Served site-level Markdown index', 'webmcp-gateway' );
			}

			WebMCP_Gateway_Activity_Log::record_event(
				'markdown',
				'Markdown Content Stream',
				$log_target,
				$log_summary
			);

			if ( ! headers_sent() ) {
				status_header( 200 );
				header( 'Content-Type: text/markdown; charset=utf-8' );
				header( 'Vary: Accept' );
				header( 'X-Robots-Tag: all, follow' );
				header( 'X-Content-Type-Options: nosniff' );
				header( 'Access-Control-Allow-Origin: *' );
				// Prevent shared caches (LiteSpeed/CDN) from storing Accept-negotiated
				// markdown under the same URL key as HTML. Query ?format=markdown is
				// a distinct URL and may still be cached by the edge.
				if ( ! $is_md_param ) {
					header( 'Cache-Control: private, no-store, must-revalidate, max-age=0' );
				}
				// LiteSpeed: prefer its public PHP API when present (avoids a non-prefixed do_action
				// that Plugin Check flags). Always emit the LiteSpeed no-cache response header.
				header( 'x-litespeed-cache-control: no-cache' );
				if ( class_exists( 'LiteSpeed_Cache_API' ) && method_exists( 'LiteSpeed_Cache_API', 'set_nocache' ) ) {
					LiteSpeed_Cache_API::set_nocache( 'webmcp markdown accept' );
				}
				WebMCP_Gateway_Frontend::send_hardening_headers();
			}

			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo $markdown_doc;
			exit;
		}

		/**
		 * Build a site-level Markdown document (homepage/archive negotiation).
		 *
		 * @return string
		 */
		public static function build_site_markdown_document() {
			$site_name = wp_strip_all_tags( (string) get_bloginfo( 'name' ) );
			$site_desc = wp_strip_all_tags( (string) get_bloginfo( 'description' ) );

			$output   = array();
			$output[] = '---';
			$output[] = 'title: ' . wp_json_encode( '' !== $site_name ? $site_name : home_url(), JSON_UNESCAPED_UNICODE );
			$output[] = 'url: ' . wp_json_encode( home_url( '/' ), JSON_UNESCAPED_SLASHES );
			$output[] = 'type: "site-index"';
			$output[] = 'mcp_manifest: ' . wp_json_encode( rest_url( 'webmcp-gateway/v1/manifest' ), JSON_UNESCAPED_SLASHES );
			$output[] = '---';
			$output[] = '';
			$output[] = '# ' . ( '' !== $site_name ? $site_name : 'WordPress Site' );
			$output[] = '';
			if ( '' !== $site_desc ) {
				$output[] = '> ' . $site_desc;
				$output[] = '';
			}
			$output[] = 'This site is agent-ready. Append `?format=markdown` to any article URL, or call the MCP tools listed in `/.well-known/mcp.json`.';
			$output[] = '';

			$pages = get_posts(
				array(
					'post_type'              => 'page',
					'post_status'            => 'publish',
					'posts_per_page'         => 10,
					'orderby'                => 'menu_order',
					'order'                  => 'ASC',
					'no_found_rows'          => true,
					'update_post_meta_cache' => false,
					'update_post_term_cache' => false,
				)
			);
			if ( ! empty( $pages ) ) {
				$output[] = '## Key Pages';
				$output[] = '';
				foreach ( $pages as $page ) {
					$output[] = '- [' . wp_strip_all_tags( get_the_title( $page ) ) . '](' . get_permalink( $page ) . ')';
				}
				$output[] = '';
			}

			$posts = get_posts(
				array(
					'post_type'              => array( 'post' ),
					'post_status'            => 'publish',
					'posts_per_page'         => 15,
					'no_found_rows'          => true,
					'update_post_meta_cache' => false,
					'update_post_term_cache' => false,
				)
			);
			if ( ! empty( $posts ) ) {
				$output[] = '## Recent Articles';
				$output[] = '';
				foreach ( $posts as $post ) {
					$summary   = WebMCP_Gateway_Activity_Log::get_effective_ai_summary( $post );
					$output[]  = '- [' . wp_strip_all_tags( get_the_title( $post ) ) . '](' . get_permalink( $post ) . ')' . ( '' !== $summary ? ' — ' . wp_trim_words( $summary, 24 ) : '' );
				}
				$output[] = '';
			}

			$output[] = '## Tools for agents';
			$output[] = '- POST ' . rest_url( 'webmcp-gateway/v1/call/getSiteInfo' );
			$output[] = '- POST ' . rest_url( 'webmcp-gateway/v1/call/searchSite' ) . ' with {"query": "keywords"}';
			$output[] = '- POST ' . rest_url( 'webmcp-gateway/v1/call/getPostContent' ) . ' with {"slug": "post-slug"}';
			$output[] = '';

			return implode( "\n", $output ) . "\n";
		}

		/**
		 * Assemble a complete Markdown document with YAML frontmatter for a WP_Post.
		 *
		 * @param WP_Post $post Target post object.
		 * @return string
		 */
		public static function build_post_markdown_document( $post ) {
			if ( ! ( $post instanceof WP_Post ) ) {
				return '';
			}
			$title      = wp_strip_all_tags( get_the_title( $post ) );
			$author     = (string) get_the_author_meta( 'display_name', $post->post_author );
			$date       = (string) get_the_date( 'Y-m-d', $post );
			$modified   = (string) get_the_modified_date( 'Y-m-d', $post );
			$permalink  = (string) get_permalink( $post );
			$ai_summary = WebMCP_Gateway_Activity_Log::get_effective_ai_summary( $post );
			$faqs       = get_post_meta( $post->ID, '_webmcp_gateway_faq_items', true );
			if ( ( ! is_array( $faqs ) || empty( $faqs ) ) && (bool) get_option( 'webmcp_gateway_auto_faq_enabled', 1 ) ) {
				$faqs = WebMCP_Gateway_Activity_Log::extract_auto_faqs_from_html( $post->post_content );
			}
			$body_md    = self::convert_html_to_markdown( $post->post_content );
			$word_count = webmcp_gateway_word_count( wp_strip_all_tags( $post->post_content ) );

			$cats      = get_the_category( $post->ID );
			$cat_names = array();
			if ( is_array( $cats ) ) {
				foreach ( $cats as $c ) {
					$cat_names[] = $c->name;
				}
			}

			$output   = array();
			$output[] = '---';
			$output[] = 'title: ' . wp_json_encode( $title, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
			$output[] = 'url: ' . wp_json_encode( $permalink, JSON_UNESCAPED_SLASHES );
			$output[] = 'type: ' . wp_json_encode( (string) $post->post_type );
			$output[] = 'author: ' . wp_json_encode( $author, JSON_UNESCAPED_UNICODE );
			$output[] = 'date: ' . wp_json_encode( $date );
			$output[] = 'modified: ' . wp_json_encode( $modified );
			$output[] = 'word_count: ' . (int) $word_count;
			if ( ! empty( $cat_names ) ) {
				$output[] = 'categories: ' . wp_json_encode( $cat_names, JSON_UNESCAPED_UNICODE );
			}
			if ( 'product' === $post->post_type ) {
				$price = (string) get_post_meta( $post->ID, '_price', true );
				$sku   = (string) get_post_meta( $post->ID, '_sku', true );
				if ( '' !== $price ) {
					$output[] = 'price: ' . wp_json_encode( $price );
				}
				if ( '' !== $sku ) {
					$output[] = 'sku: ' . wp_json_encode( $sku );
				}
			}
			if ( '' !== $ai_summary ) {
				$output[] = 'summary: ' . wp_json_encode( $ai_summary, JSON_UNESCAPED_UNICODE );
			}
			$output[] = 'mcp_manifest: ' . wp_json_encode( rest_url( 'webmcp-gateway/v1/manifest' ), JSON_UNESCAPED_SLASHES );
			$output[] = '---';
			$output[] = '';
			$output[] = '# ' . $title;
			$output[] = '';

			if ( '' !== $ai_summary ) {
				$output[] = '> **Summary:** ' . $ai_summary;
				$output[] = '';
			}

			$output[] = $body_md;

			if ( is_array( $faqs ) && ! empty( $faqs ) ) {
				$output[] = '';
				$output[] = '## Frequently Asked Questions';
				$output[] = '';
				foreach ( $faqs as $item ) {
					$q = isset( $item['q'] ) ? trim( (string) $item['q'] ) : '';
					$a = isset( $item['a'] ) ? trim( (string) $item['a'] ) : '';
					if ( '' !== $q && WebMCP_Gateway_Schema_Graph::is_publishable_faq_answer( $a ) ) {
						$output[] = '### ' . $q;
						$output[] = $a;
						$output[] = '';
					}
				}
			}

			return implode( "\n", $output ) . "\n";
		}

		/**
		 * Lightweight semantic HTML-to-Markdown converter.
		 *
		 * @param string $html Raw post HTML content.
		 * @return string
		 */
		public static function convert_html_to_markdown( $html ) {
			// Guard against runaway conversion cost on huge posts (filterable, bytes).
			$max_bytes = (int) apply_filters( 'webmcp_gateway_markdown_max_bytes', 100 * 1024 );
			$html      = (string) $html;
			if ( strlen( $html ) > $max_bytes ) {
				$html = (string) substr( $html, 0, $max_bytes );
				$GLOBALS['webmcp_markdown_truncated'] = true;
			}

			$text = strip_shortcodes( $html );
			$text = (string) preg_replace( '/<!--(.|\s)*?-->/', '', $text );

			for ( $i = 6; $i >= 1; $i-- ) {
				$hashes = str_repeat( '#', $i );
				$text   = (string) preg_replace_callback(
					'/<h' . $i . '[^>]*>(.*?)<\/h' . $i . '>/is',
					static function ( $matches ) use ( $hashes ) {
						return "\n\n" . $hashes . ' ' . trim( wp_strip_all_tags( $matches[1] ) ) . "\n\n";
					},
					$text
				);
			}

			$text = (string) preg_replace_callback(
				'/<pre[^>]*><code[^>]*>(.*?)<\/code><\/pre>/is',
				static function ( $matches ) {
					return "\n\n```\n" . html_entity_decode( wp_strip_all_tags( $matches[1] ), ENT_QUOTES, 'UTF-8' ) . "\n```\n\n";
				},
				$text
			);

			$text = (string) preg_replace_callback(
				'/<code[^>]*>(.*?)<\/code>/is',
				static function ( $matches ) {
					return '`' . trim( wp_strip_all_tags( $matches[1] ) ) . '`';
				},
				$text
			);

			$text = (string) preg_replace_callback(
				'/<blockquote[^>]*>(.*?)<\/blockquote>/is',
				static function ( $matches ) {
					$inner = trim( wp_strip_all_tags( $matches[1] ) );
					return "\n\n> " . str_replace( "\n", "\n> ", $inner ) . "\n\n";
				},
				$text
			);

			$text = (string) preg_replace_callback(
				'/<a\s+[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/is',
				static function ( $matches ) {
					$url   = esc_url_raw( $matches[1] );
					$label = trim( wp_strip_all_tags( $matches[2] ) );
					if ( '' === $label ) {
						return $url;
					}
					return '[' . $label . '](' . $url . ')';
				},
				$text
			);

			$text = (string) preg_replace( '/<(strong|b)\b[^>]*>(.*?)<\/\1>/is', '**$2**', $text );
			$text = (string) preg_replace( '/<(em|i)\b[^>]*>(.*?)<\/\1>/is', '*$2*', $text );

			$text = (string) preg_replace_callback(
				'/<li[^>]*>(.*?)<\/li>/is',
				static function ( $matches ) {
					return "\n- " . trim( wp_strip_all_tags( $matches[1] ) );
				},
				$text
			);

			$text = (string) preg_replace( '/<\/p>/i', "\n\n", $text );
			$text = (string) preg_replace( '/<br\s*\/?>/i', "\n", $text );

			$text = wp_strip_all_tags( $text );
			$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
			$text = (string) preg_replace( "/\n{3,}/", "\n\n", $text );

			$text = trim( $text );
			if ( ! empty( $GLOBALS['webmcp_markdown_truncated'] ) ) {
				$text .= "

---

" . __( '*[Content truncated — the full article is available as HTML on the original page.]*', 'webmcp-gateway' );
				unset( $GLOBALS['webmcp_markdown_truncated'] );
			}

			return $text;
		}
	}
}
