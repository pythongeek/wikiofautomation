<?php
/**
 * .well-known Discovery Router - WebMCP Gateway.
 *
 * Serves the MCP Server Card plus the emerging agent-discovery standards:
 * RFC 9727 API Catalog, Agent Skills index, ARD manifest, and auth.md.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WebMCP_Gateway_Well_Known' ) ) {
	/**
	 * Serves agent discovery documents under /.well-known/ and /auth.md.
	 */
	final class WebMCP_Gateway_Well_Known {

		/**
		 * Register rewrite rules, query vars, and template redirect handler.
		 *
		 * @return void
		 */
		public static function init() {
			WebMCP_Gateway_Loader::register_action( 'init', array( __CLASS__, 'add_rewrite_rules' ) );
			WebMCP_Gateway_Loader::register_filter( 'query_vars', array( __CLASS__, 'add_query_vars' ) );
			WebMCP_Gateway_Loader::register_action( 'template_redirect', array( __CLASS__, 'serve' ), 1 );
			// Discovery documents must never be cached: agents and industry scanners
			// always need the current policy and manifests.
			WebMCP_Gateway_Loader::register_action( 'do_robots', array( __CLASS__, 'send_no_cache_headers' ), 0 );
		}

		/**
		 * Send no-cache headers for the current discovery/robots response.
		 *
		 * @return void
		 */
		public static function send_no_cache_headers() {
			if ( headers_sent() ) {
				return;
			}
			header( 'Cache-Control: no-cache, no-store, must-revalidate, max-age=0' );
			header( 'x-litespeed-cache-control: no-cache' );
		WebMCP_Gateway_Frontend::send_hardening_headers();
		}

		/**
		 * Register rewrite rules.
		 *
		 * @return void
		 */
		public static function add_rewrite_rules() {
			add_rewrite_rule( '^\.well-known/mcp\.json$', 'index.php?webmcp_gateway_wellknown=mcp', 'top' );
			add_rewrite_rule( '^\.well-known/model-context-protocol\.json$', 'index.php?webmcp_gateway_wellknown=mcp', 'top' );
			add_rewrite_rule( '^\.well-known/api-catalog$', 'index.php?webmcp_gateway_wellknown=api_catalog', 'top' );
			add_rewrite_rule( '^\.well-known/api-catalog\.json$', 'index.php?webmcp_gateway_wellknown=api_catalog', 'top' );
			add_rewrite_rule( '^\.well-known/agent-skills/index\.json$', 'index.php?webmcp_gateway_wellknown=agent_skills', 'top' );
			add_rewrite_rule( '^\.well-known/agent-skills\.json$', 'index.php?webmcp_gateway_wellknown=agent_skills', 'top' );
			add_rewrite_rule( '^\.well-known/agent-skills/webmcp-gateway/SKILL\.md$', 'index.php?webmcp_gateway_wellknown=agent_skill_md', 'top' );
			add_rewrite_rule( '^\.well-known/ai-catalog\.json$', 'index.php?webmcp_gateway_wellknown=ard', 'top' );
			add_rewrite_rule( '^\.well-known/ard-manifest\.json$', 'index.php?webmcp_gateway_wellknown=ard', 'top' );
			add_rewrite_rule( '^auth\.md$', 'index.php?webmcp_gateway_wellknown=auth_md', 'top' );
			add_rewrite_rule( '^\.well-known/auth\.md$', 'index.php?webmcp_gateway_wellknown=auth_md', 'top' );
		}

		/**
		 * Register query variable.
		 *
		 * @param mixed $vars Public query vars.
		 * @return array
		 */
		public static function add_query_vars( $vars = array() ) {
			if ( ! is_array( $vars ) ) {
				$vars = array();
			}
			$vars[] = 'webmcp_gateway_wellknown';
			return $vars;
		}

		/**
		 * Serve a discovery document when requested.
		 *
		 * @return void
		 */
		public static function serve() {
			if ( ! WebMCP_Gateway_Frontend::is_enabled() ) {
				return;
			}

			$qv   = (string) get_query_var( 'webmcp_gateway_wellknown' );
			$uri  = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
			$path = trim( (string) wp_parse_url( $uri, PHP_URL_PATH ), '/' );

			$routes = array(
				'mcp'            => array( '.well-known/mcp.json', '.well-known/model-context-protocol.json' ),
				'api_catalog'    => array( '.well-known/api-catalog', '.well-known/api-catalog.json' ),
				'agent_skills'   => array( '.well-known/agent-skills/index.json', '.well-known/agent-skills.json' ),
				'agent_skill_md' => array( '.well-known/agent-skills/webmcp-gateway/SKILL.md' ),
				'ard'            => array( '.well-known/ai-catalog.json', '.well-known/ard-manifest.json' ),
				'auth_md'        => array( 'auth.md', '.well-known/auth.md' ),
			);

			$route = $qv;
			if ( '' === $route ) {
				foreach ( $routes as $key => $paths ) {
					foreach ( $paths as $known_path ) {
						if ( 0 === strcasecmp( $path, $known_path ) ) {
							$route = $key;
							break 2;
						}
					}
				}
			}

			switch ( $route ) {
				case 'mcp':
					self::serve_mcp();
					return;
				case 'api_catalog':
					self::serve_api_catalog();
					return;
				case 'agent_skills':
					self::serve_agent_skills();
					return;
				case 'agent_skill_md':
					self::serve_agent_skill_md();
					return;
				case 'ard':
					self::serve_ard();
					return;
				case 'auth_md':
					self::serve_auth_md();
					return;
			}
		}

		/**
		 * Serve the .well-known MCP discovery JSON payload.
		 *
		 * @return void
		 */
		private static function serve_mcp() {
			WebMCP_Gateway_Activity_Log::record_event(
				'wellknown',
				'/.well-known/mcp.json',
				home_url( '/.well-known/mcp.json' ),
				__( 'Served Model Context Protocol discovery manifest', 'webmcp-gateway' )
			);

			$tools   = WebMCP_Gateway_Schema_Builder::get_core_tools( 0 );
			$payload = array(
				'schema_version'   => '1.0',
				'protocol_version' => '2025-03-26',
				'name'             => (string) get_bloginfo( 'name' ),
				'description'      => (string) get_bloginfo( 'description' ),
				'url'              => home_url( '/' ),
				'mcp_server'       => array(
					'protocol'   => 'model-context-protocol',
					'version'    => '1.0',
					'transport'  => 'http-rest',
					'manifest'   => rest_url( 'webmcp-gateway/v1/manifest' ),
					'tools_list' => rest_url( 'webmcp-gateway/v1/tools' ),
					'call_url'   => rest_url( 'webmcp-gateway/v1/call/{tool}' ),
					'llms_txt'   => home_url( '/llms.txt' ),
				),
				'capabilities'     => array(
					'tools'            => true,
					'markdown_stream'  => (bool) get_option( 'webmcp_gateway_markdown_enabled', 1 ),
					'schema_org_graph' => (bool) get_option( 'webmcp_gateway_schema_enabled', 1 ),
					'speakable_aeo'    => (bool) get_option( 'webmcp_gateway_speakable_enabled', 1 ),
					'auto_faq_schema'  => (bool) get_option( 'webmcp_gateway_auto_faq_enabled', 1 ),
				),
				'tools'            => $tools,
			);

			if ( ! headers_sent() ) {
				header( 'Access-Control-Allow-Origin: *' );
				WebMCP_Gateway_Frontend::send_hardening_headers();
			}

			wp_send_json( $payload, 200, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		}

		/**
		 * Serve the RFC 9727 API Catalog as application/linkset+json.
		 *
		 * @return void
		 */
		private static function serve_api_catalog() {
			$home = trailingslashit( home_url() );

			$items = array(
				array(
					'href' => rest_url( 'webmcp-gateway/v1/manifest' ),
					'rel'  => 'service-desc',
				),
				array(
					'href' => rest_url( 'webmcp-gateway/v1/tools' ),
					'rel'  => 'describedby',
				),
				array(
					'href' => home_url( '/.well-known/mcp.json' ),
					'rel'  => 'service-doc',
				),
				array(
					'href' => home_url( '/llms.txt' ),
					'rel'  => 'service-doc',
				),
				array(
					'href' => rest_url( 'webmcp-gateway/v1/call/getSiteInfo' ),
					'rel'  => 'service-invocation',
				),
				array(
					'href' => rest_url( 'webmcp-gateway/v1/call/searchSite' ),
					'rel'  => 'service-invocation',
				),
				array(
					'href' => rest_url( 'webmcp-gateway/v1/call/getFeaturedContent' ),
					'rel'  => 'service-invocation',
				),
				array(
					'href' => rest_url( 'webmcp-gateway/v1/call/getPostContent' ),
					'rel'  => 'service-invocation',
				),
				array(
					'href' => rest_url( 'webmcp-gateway/v1/call/getSiteTaxonomies' ),
					'rel'  => 'service-invocation',
				),
				array(
					'href' => rest_url( 'webmcp-gateway/v1/call/getCatalogItems' ),
					'rel'  => 'service-invocation',
				),
			);

			$payload = array(
				'linkset' => array(
					array(
						'anchor' => $home,
						'item'   => $items,
					),
				),
			);

			WebMCP_Gateway_Activity_Log::record_event(
				'wellknown',
				'/.well-known/api-catalog',
				home_url( '/.well-known/api-catalog' ),
				__( 'Served RFC 9727 API Catalog', 'webmcp-gateway' )
			);

			if ( ! headers_sent() ) {
				header( 'Content-Type: application/linkset+json; charset=utf-8' );
				header( 'Access-Control-Allow-Origin: *' );
				WebMCP_Gateway_Frontend::send_hardening_headers();
				header( 'Cache-Control: no-cache, no-store, must-revalidate, max-age=0' );
				header( 'x-litespeed-cache-control: no-cache' );
			}
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON payload.
			echo wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
			exit;
		}

		/**
		 * Serve the Agent Skills index.
		 *
		 * @return void
		 */
		private static function serve_agent_skills() {
			$payload = array(
				'skills' => array(
					array(
						'name'         => 'webmcp-gateway',
						'display_name' => (string) get_bloginfo( 'name' ),
						'description'  => sprintf(
							/* translators: %s: site name */
							__( 'Query and read content from %s: site info, keyword search, latest articles, full post content as Markdown, taxonomies, and catalog items.', 'webmcp-gateway' ),
							wp_strip_all_tags( (string) get_bloginfo( 'name' ) )
						),
						'url'          => home_url( '/.well-known/agent-skills/webmcp-gateway/SKILL.md' ),
						'version'      => WEBMCP_CORE_VERSION,
					),
				),
			);

			WebMCP_Gateway_Activity_Log::record_event(
				'wellknown',
				'/.well-known/agent-skills/index.json',
				home_url( '/.well-known/agent-skills/index.json' ),
				__( 'Served Agent Skills index', 'webmcp-gateway' )
			);

			if ( ! headers_sent() ) {
				header( 'Content-Type: application/json; charset=utf-8' );
				header( 'Access-Control-Allow-Origin: *' );
				WebMCP_Gateway_Frontend::send_hardening_headers();
			}
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON payload.
			echo wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
			exit;
		}

		/**
		 * Serve the SKILL.md document describing this site's agent skill.
		 *
		 * @return void
		 */
		private static function serve_agent_skill_md() {
			$site_name = wp_strip_all_tags( (string) get_bloginfo( 'name' ) );
			$lines     = array();
			$lines[]   = '# ' . ( '' !== $site_name ? $site_name : 'WordPress Site' ) . ' — webmcp-gateway skill';
			$lines[]   = '';
			$lines[]   = '## When to use this skill';
			$lines[]   = 'Use this skill whenever you need to read or cite content from ' . $site_name . ': site metadata, keyword search, latest articles, full article text, topic structure, or product catalog data.';
			$lines[]   = '';
			$lines[]   = '## How to call';
			$lines[]   = 'All tools are HTTP POST endpoints that accept JSON and return JSON. No authentication is required for read access.';
			$lines[]   = '';
			$lines[]   = '```';
			$lines[]   = 'POST ' . rest_url( 'webmcp-gateway/v1/call/searchSite' );
			$lines[]   = '{"query": "your keywords", "limit": 5}';
			$lines[]   = '';
			$lines[]   = 'POST ' . rest_url( 'webmcp-gateway/v1/call/getPostContent' );
			$lines[]   = '{"slug": "hello-world"}';
			$lines[]   = '```';
			$lines[]   = '';
			$lines[]   = '## Tools';
			$lines[]   = '- getSiteInfo — site title, language, theme, content counts, top categories.';
			$lines[]   = '- searchSite — keyword search across posts, pages, and products.';
			$lines[]   = '- getFeaturedContent — latest articles with summaries and reading time.';
			$lines[]   = '- getPostContent — clean Markdown of any post/page by id, slug, or URL.';
			$lines[]   = '- getSiteTaxonomies — categories and tags with counts.';
			$lines[]   = '- getCatalogItems — WooCommerce products with price, SKU, and stock status.';
			$lines[]   = '';
			$lines[]   = '## Notes';
			$lines[]   = '- Append ?format=markdown to any post URL for clean Markdown.';
			$lines[]   = '- Discovery: /.well-known/mcp.json, /.well-known/api-catalog, /llms.txt.';

			self::serve_text( implode( "\n", $lines ) . "\n", 'text/markdown; charset=utf-8', '/.well-known/agent-skills/webmcp-gateway/SKILL.md', __( 'Served Agent SKILL.md', 'webmcp-gateway' ) );
		}

		/**
		 * Serve the ARD (Agentic Resource Discovery) manifest.
		 *
		 * @return void
		 */
		private static function serve_ard() {
			$site_name = wp_strip_all_tags( (string) get_bloginfo( 'name' ) );
			$payload   = array(
				'specVersion' => '1.0',
				'name'        => '' !== $site_name ? $site_name : home_url(),
				'description' => (string) get_bloginfo( 'description' ),
				'url'         => home_url( '/' ),
				'resources'   => array(
					array(
						'type'        => 'mcp-server',
						'url'         => home_url( '/.well-known/mcp.json' ),
						'description' => __( 'Model Context Protocol server card with callable read tools', 'webmcp-gateway' ),
					),
					array(
						'type'        => 'api-catalog',
						'url'         => home_url( '/.well-known/api-catalog' ),
						'description' => __( 'RFC 9727 API Catalog of agent endpoints', 'webmcp-gateway' ),
					),
					array(
						'type'        => 'corpus-index',
						'url'         => home_url( '/llms.txt' ),
						'description' => __( 'Markdown corpus index for AI agents', 'webmcp-gateway' ),
					),
					array(
						'type'        => 'agent-skills',
						'url'         => home_url( '/.well-known/agent-skills/index.json' ),
						'description' => __( 'Agent Skills offered by this site', 'webmcp-gateway' ),
					),
				),
				// ARD spec: every advertised capability is also listed as a flat entry
				// so scanners validating for an "entries" array (isitagentready, etc.)
				// find the complete capability set.
				'entries'     => array(
					array(
						'type'     => 'mcp-server',
						'name'     => 'WebMCP Gateway MCP Server',
						'url'      => home_url( '/.well-known/mcp.json' ),
					),
					array(
						'type'     => 'api',
						'name'     => 'MCP REST API (6 read tools)',
						'url'      => rest_url( 'webmcp-gateway/v1' ),
					),
					array(
						'type'     => 'corpus',
						'name'     => 'llms.txt corpus index',
						'url'      => home_url( '/llms.txt' ),
					),
					array(
						'type'     => 'corpus',
						'name'     => 'llms-full.txt extended corpus',
						'url'      => home_url( '/llms-full.txt' ),
					),
					array(
						'type'     => 'documentation',
						'name'     => 'Agent authentication model',
						'url'      => home_url( '/auth.md' ),
					),
					array(
						'type'     => 'skills',
						'name'     => 'Agent Skills index',
						'url'      => home_url( '/.well-known/agent-skills/index.json' ),
					),
				),
			);

			WebMCP_Gateway_Activity_Log::record_event(
				'wellknown',
				'/.well-known/ai-catalog.json',
				home_url( '/.well-known/ai-catalog.json' ),
				__( 'Served ARD capability manifest', 'webmcp-gateway' )
			);

			if ( ! headers_sent() ) {
				header( 'Content-Type: application/json; charset=utf-8' );
				header( 'Access-Control-Allow-Origin: *' );
				WebMCP_Gateway_Frontend::send_hardening_headers();
			}
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON payload.
			echo wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
			exit;
		}

		/**
		 * Serve auth.md describing the agent authentication model.
		 *
		 * @return void
		 */
		private static function serve_auth_md() {
			$limit   = max( 10, absint( get_option( 'webmcp_gateway_rate_limit', 60 ) ) );
			$site    = wp_strip_all_tags( (string) get_bloginfo( 'name' ) );
			$lines   = array();
			$lines[] = '# auth.md — ' . ( '' !== $site ? $site : 'WordPress Site' ) . ' agent authentication';
			$lines[] = '';
			$lines[] = '## Agent API access';
			$lines[] = 'All Model Context Protocol tools exposed by this site are **public, read-only**, and require **no authentication**.';
			$lines[] = '';
			$lines[] = '## Rate limiting';
			$lines[] = sprintf(
				/* translators: %d: requests per minute */
				__( 'Anonymous agents may make up to %d tool calls per minute per IP address. HTTP 429 is returned when exceeded; wait one minute and retry.', 'webmcp-gateway' ),
				$limit
			);
			$lines[] = '';
			$lines[] = '## Endpoints';
			$lines[] = '- MCP Server Card: ' . home_url( '/.well-known/mcp.json' );
			$lines[] = '- API Catalog: ' . home_url( '/.well-known/api-catalog' );
			$lines[] = '- Tool call base: ' . rest_url( 'webmcp-gateway/v1/call/' );
			$lines[] = '';
			$lines[] = '## Write access';
			$lines[] = 'No write, payment, or user-data endpoints are exposed to agents.';

			self::serve_text( implode( "\n", $lines ) . "\n", 'text/markdown; charset=utf-8', '/auth.md', __( 'Served auth.md', 'webmcp-gateway' ) );
		}

		/**
		 * Emit a plain text response and stop.
		 *
		 * @param string $text        Body.
		 * @param string $content_type Content-Type header.
		 * @param string $target      Log target.
		 * @param string $log_summary Log summary.
		 * @return void
		 */
		private static function serve_text( $text, $content_type, $target, $log_summary ) {
			WebMCP_Gateway_Activity_Log::record_event( 'wellknown', $target, home_url( $target ), $log_summary );

			if ( ! headers_sent() ) {
				header( 'Content-Type: ' . $content_type );
				header( 'X-Content-Type-Options: nosniff' );
				header( 'Access-Control-Allow-Origin: *' );
				WebMCP_Gateway_Frontend::send_hardening_headers();
				header( 'Cache-Control: no-cache, no-store, must-revalidate, max-age=0' );
				header( 'x-litespeed-cache-control: no-cache' );
			}
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- intentional plain text document.
			echo $text;
			exit;
		}
	}
}
