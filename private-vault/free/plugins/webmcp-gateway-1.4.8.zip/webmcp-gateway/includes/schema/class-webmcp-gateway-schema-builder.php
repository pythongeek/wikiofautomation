<?php
/**
 * Schema Builder - Manifest orchestrator for the 6 unlocked Model Context Protocol tools.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WebMCP_Gateway_Schema_Builder' ) ) {
	/**
	 * Builds the WebMCP manifest and declares all 6 built-in read tools.
	 */
	final class WebMCP_Gateway_Schema_Builder {

		/**
		 * Build the full WebMCP manifest payload for the current page context.
		 *
		 * @param string $context Current page context.
		 * @param int    $post_id Optional queried post ID.
		 * @return array
		 */
		public static function build( $context = 'homepage', $post_id = 0 ) {
			$context = (string) $context;
			$post_id = (int) $post_id;
			$tools   = self::get_core_tools( $post_id );

			$tools = (array) apply_filters( 'webmcp_gateway_register_tools', $tools, $context, $post_id );

			$tools = array_map(
				static function ( $tool ) {
					$tool = (array) $tool;
					if ( ! isset( $tool['annotations'] ) ) {
						$tool['annotations'] = array(
							'readOnlyHint'         => true,
							'idempotentHint'       => true,
							'openWorldHint'        => false,
							'untrustedContentHint' => in_array( (string) ( isset( $tool['name'] ) ? $tool['name'] : '' ), array( 'searchSite', 'getPostContent' ), true ),
						);
					}
					if ( ! isset( $tool['exposedTo'] ) ) {
						$tool['exposedTo'] = array( '*' );
					}
					return $tool;
				},
				$tools
			);

			$manifest = array(
				'schema_version'   => '1.0',
				'protocol_version' => '2025-03-26',
				'version'          => WEBMCP_CORE_VERSION,
				'site'             => array(
					'name'        => (string) get_bloginfo( 'name' ),
					'description' => (string) get_bloginfo( 'description' ),
					'url'         => home_url( '/' ),
					'language'    => get_bloginfo( 'language' ),
					'llms_txt'    => home_url( '/llms.txt' ),
				),
				'endpoints'        => array(
					'manifest'  => rest_url( 'webmcp-gateway/v1/manifest' ),
					'tools'     => rest_url( 'webmcp-gateway/v1/tools' ),
					'call_base' => rest_url( 'webmcp-gateway/v1/call/' ),
					'wellknown' => home_url( '/.well-known/mcp.json' ),
				),
				'tools'            => array_values( $tools ),
			);

			return (array) apply_filters( 'webmcp_gateway_manifest', $manifest, $context, $post_id );
		}

		/**
		 * Return the 6 built-in, 100% unlocked MCP tools.
		 *
		 * @param int $post_id Optional queried post ID.
		 * @return array
		 */
		public static function get_core_tools( $post_id = 0 ) {
			$post_id   = (int) $post_id;
			$site_name = (string) get_bloginfo( 'name' );
			$label     = '' !== $site_name ? $site_name : 'this WordPress site';

			$live_title = '';
			if ( $post_id > 0 ) {
				$post_obj = get_post( $post_id );
				if ( $post_obj instanceof WP_Post && 'publish' === $post_obj->post_status ) {
					$live_title = sprintf( ' Current page: "%s" (post_id: %d).', (string) $post_obj->post_title, (int) $post_obj->ID );
				}
			}

			return array(
				array(
					'name'           => 'getSiteInfo',
					'description'    => sprintf(
						'Get structured metadata about %s. Returns site title, tagline, homepage URL, language, active theme, published content counts, top categories, and available AEO/MCP endpoints.',
						$label
					),
					'inputSchema'    => array(
						'type'       => 'object',
						'properties' => new stdClass(),
					),
					'x-webmcp-type'  => 'read',
					'x-webmcp-scope' => 'global',
				),
				array(
					'name'           => 'searchSite',
					'description'    => sprintf(
						'Search public posts, pages, and products across %s by keyword query. Returns matching items with titles, URLs, publication dates, AI summaries, and Markdown links.',
						$label
					),
					'inputSchema'    => array(
						'type'       => 'object',
						'properties' => array(
							'query'     => array(
								'type'        => 'string',
								'description' => 'The search query or keywords to look for.',
								'minLength'   => 1,
								'maxLength'   => 200,
							),
							'limit'     => array(
								'type'        => 'integer',
								'description' => 'Maximum results to return (1-10). Default is 5.',
								'minimum'     => 1,
								'maximum'     => 10,
								'default'     => 5,
							),
							'post_type' => array(
								'type'        => 'string',
								'description' => 'Optional post type filter: "any", "post", "page", or "product".',
								'default'     => 'any',
							),
						),
						'required'   => array( 'query' ),
					),
					'x-webmcp-type'  => 'read',
					'x-webmcp-scope' => 'global',
				),
				array(
					'name'           => 'getFeaturedContent',
					'description'    => sprintf(
						'Retrieve the most recent or sticky featured articles published on %s, including summaries, categories, and reading time estimates.',
						$label
					),
					'inputSchema'    => array(
						'type'       => 'object',
						'properties' => array(
							'limit'    => array(
								'type'        => 'integer',
								'description' => 'Maximum entries to return (1-10). Default is 5.',
								'minimum'     => 1,
								'maximum'     => 10,
								'default'     => 5,
							),
							'category' => array(
								'type'        => 'string',
								'description' => 'Optional category slug to filter featured articles.',
							),
						),
					),
					'x-webmcp-type'  => 'read',
					'x-webmcp-scope' => 'homepage',
				),
				array(
					'name'           => 'getPostContent',
					'description'    => sprintf(
						'Retrieve the clean semantic Markdown content, AI summary, FAQ items, author metadata, and canonical URL of any published post or page by post_id, slug, or URL.%s',
						$live_title
					),
					'inputSchema'    => array(
						'type'       => 'object',
						'properties' => array(
							'post_id' => array(
								'type'        => 'integer',
								'description' => 'WordPress post ID to retrieve.',
								'minimum'     => 1,
							),
							'slug'    => array(
								'type'        => 'string',
								'description' => 'Optional post or page slug if post_id is omitted.',
							),
							'url'     => array(
								'type'        => 'string',
								'description' => 'Optional full permalink URL to resolve into a post ID.',
							),
						),
					),
					'x-webmcp-type'  => 'read',
					'x-webmcp-scope' => 'single',
				),
				array(
					'name'           => 'getSiteTaxonomies',
					'description'    => sprintf(
						'Retrieve the topical architecture (categories, tags, and post counts) of %s so AI agents can navigate topic clusters.',
						$label
					),
					'inputSchema'    => array(
						'type'       => 'object',
						'properties' => array(
							'limit' => array(
								'type'        => 'integer',
								'description' => 'Maximum terms per taxonomy (1-25). Default is 10.',
								'default'     => 10,
							),
						),
					),
					'x-webmcp-type'  => 'read',
					'x-webmcp-scope' => 'global',
				),
				array(
					'name'           => 'getCatalogItems',
					'description'    => sprintf(
						'Query published WooCommerce products (including price, currency, SKU, and live stock availability) or custom post type items on %s.',
						$label
					),
					'inputSchema'    => array(
						'type'       => 'object',
						'properties' => array(
							'query' => array(
								'type'        => 'string',
								'description' => 'Optional keyword to filter products or catalog items.',
							),
							'limit' => array(
								'type'        => 'integer',
								'description' => 'Maximum items to return (1-10). Default is 5.',
								'default'     => 5,
							),
						),
					),
					'x-webmcp-type'  => 'read',
					'x-webmcp-scope' => 'global',
				),
			);
		}
	}
}
