<?php
/**
 * AEO Schema.org Graph & SpeakableSpecification Generator - WebMCP Gateway.
 *
 * Emits a connected Schema.org @graph featuring Organization/Person, WebSite,
 * BreadcrumbList, WebPage, Article/BlogPosting/NewsArticle/TechArticle,
 * WooCommerce Product & Offer (unlocked out of the box), SpeakableSpecification,
 * and automatic + manual FAQPage nodes.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WebMCP_Gateway_Schema_Graph' ) ) {
	/**
	 * Generates the interconnected Schema.org @graph JSON-LD payload.
	 */
	final class WebMCP_Gateway_Schema_Graph {

		/**
		 * Generate the full @graph array for a given post ID and context.
		 *
		 * The expensive build is cached per post (post ID + last modified + settings
		 * revision + version) for a filterable 12h TTL; editors previewing are never
		 * served cache. The `webmcp_gateway_schema_graph` filter still runs on every
		 * return — cache stores the pre-filter graph so developer filters stay live.
		 *
		 * @param int    $post_id Target post ID.
		 * @param string $context Request context.
		 * @return array
		 */
		public static function generate( $post_id = 0, $context = 'homepage' ) {
			$post_id = (int) $post_id;
			$context = (string) $context;

			if ( ! (bool) get_option( 'webmcp_gateway_schema_enabled', 1 ) ) {
				return array();
			}

			if ( $post_id <= 0 ) {
				$post_id = (int) get_queried_object_id();
				if ( $post_id <= 0 ) {
					$post_id = (int) get_the_ID();
				}
			}

			$skip_cache = function_exists( 'is_user_logged_in' ) && is_user_logged_in() && current_user_can( 'edit_posts' );
			$cache_key  = self::graph_cache_key( $post_id, $context );

			if ( ! $skip_cache ) {
				$cached = self::graph_cache_get( $post_id, $context, $cache_key );
				if ( is_array( $cached ) ) {
					return (array) apply_filters( 'webmcp_gateway_schema_graph', $cached, $post_id, $context );
				}
			}

			$canonical_url = self::get_canonical_url( $post_id );
			$nodes         = array();

			$nodes[] = self::prune_empty( self::build_publisher_node() );
			$nodes[] = self::prune_empty( self::build_website_node() );

			$breadcrumbs = self::build_breadcrumb_node( $post_id, $canonical_url, $context );
			$has_crumbs  = ! empty( $breadcrumbs );
			if ( $has_crumbs ) {
				$nodes[] = self::prune_empty( $breadcrumbs );
			}

			$webpage = self::build_webpage_node( $post_id, $canonical_url, $context, $has_crumbs );
			$article = null;
			$product = null;
			$faq     = null;

			if ( $post_id > 0 && ( 'single' === $context || is_singular() ) ) {
				$post_obj = get_post( $post_id );
				if ( $post_obj instanceof WP_Post && 'product' === $post_obj->post_type && (bool) get_option( 'webmcp_gateway_woo_schema_on', 1 ) ) {
					$product = self::build_product_node( $post_id, $canonical_url );
				} else {
					$article = self::build_article_node( $post_id, $canonical_url );
				}

				// When the page itself is typed as FAQPage, fold Q&As into the WebPage
				// instead of emitting a second FAQPage node (schema.org duplicate-type clash).
				$page_is_faq = isset( $webpage['@type'] ) && 'FAQPage' === $webpage['@type'];
				$faq         = self::build_faq_node( $post_id, $canonical_url );
				if ( $page_is_faq && ! empty( $faq ) && ! empty( $faq['mainEntity'] ) ) {
					$webpage['mainEntity'] = $faq['mainEntity'];
					$faq                   = null;
				}
			}

			if ( ! empty( $article ) ) {
				$webpage['mainEntity'] = array( '@id' => $canonical_url . '#article' );
				if ( ! empty( $article['image'] ) && is_array( $article['image'] ) && ! empty( $article['image']['@id'] ) ) {
					$webpage['primaryImageOfPage'] = array( '@id' => $article['image']['@id'] );
				}
			} elseif ( ! empty( $product ) ) {
				$webpage['mainEntity'] = array( '@id' => $canonical_url . '#product' );
			}

			if ( ! empty( $faq ) ) {
				$webpage['hasPart'] = array( '@id' => $canonical_url . '#faq' );
			}

			$nodes[] = self::prune_empty( $webpage );
			if ( ! empty( $article ) ) {
				$nodes[] = self::prune_empty( $article );
			}
			if ( ! empty( $product ) ) {
				$nodes[] = self::prune_empty( $product );
			}
			if ( ! empty( $faq ) ) {
				$nodes[] = self::prune_empty( $faq );
			}

			$graph = array(
				'@context' => 'https://schema.org',
				'@graph'   => array_values( array_filter( $nodes ) ),
			);

			if ( ! $skip_cache ) {
				self::graph_cache_set( $post_id, $context, $cache_key, $graph );
			}

			return (array) apply_filters( 'webmcp_gateway_schema_graph', $graph, $post_id, $context );
		}

		/**
		 * Composite cache key: post ID + context + modified time + settings revision + version.
		 *
		 * @param int    $post_id Target post ID.
		 * @param string $context Request context.
		 * @return string
		 */
		private static function graph_cache_key( $post_id, $context ) {
			$modified = $post_id > 0 ? (string) get_post_modified_time( 'U', true, $post_id ) : '';
			return md5(
				serialize(
					array( $post_id, $context, $modified, (int) get_option( 'webmcp_gateway_schema_rev', 0 ), WEBMCP_CORE_VERSION )
				)
			);
		}

		/**
		 * Fetch a cached graph when the key matches and the TTL has not expired.
		 *
		 * @param int    $post_id Target post ID.
		 * @param string $context Request context.
		 * @param string $key     Composite cache key.
		 * @return array|null Cached graph or null on miss.
		 */
		private static function graph_cache_get( $post_id, $context, $key ) {
			$ttl   = max( 60, (int) apply_filters( 'webmcp_gateway_graph_cache_ttl', 12 * HOUR_IN_SECONDS ) );
			$entry = $post_id > 0
				? get_post_meta( $post_id, '_webmcp_graph_cache', true )
				: get_option( 'webmcp_gateway_graph_cache_' . sanitize_key( $context ), array() );

			if ( ! is_array( $entry ) || ! isset( $entry['key'], $entry['graph'], $entry['ts'] ) ) {
				return null;
			}
			if ( ! hash_equals( (string) $entry['key'], $key ) ) {
				return null;
			}
			if ( time() - (int) $entry['ts'] > $ttl ) {
				return null;
			}
			return is_array( $entry['graph'] ) ? $entry['graph'] : null;
		}

		/**
		 * Persist a built graph against its cache key.
		 *
		 * @param int    $post_id Target post ID.
		 * @param string $context Request context.
		 * @param string $key     Composite cache key.
		 * @param array  $graph   Built graph.
		 * @return void
		 */
		private static function graph_cache_set( $post_id, $context, $key, $graph ) {
			$entry = array(
				'key'   => $key,
				'graph' => $graph,
				'ts'    => time(),
			);
			if ( $post_id > 0 ) {
				update_post_meta( $post_id, '_webmcp_graph_cache', $entry );
				return;
			}
			update_option( 'webmcp_gateway_graph_cache_' . sanitize_key( $context ), $entry, false );
		}

		/**
		 * Hook: drop a post's cached graph when the post changes.
		 *
		 * @param mixed $post_id Post ID.
		 * @return void
		 */
		public static function purge_graph_cache( $post_id = 0 ) {
			$post_id = (int) $post_id;
			if ( $post_id > 0 ) {
				delete_post_meta( $post_id, '_webmcp_graph_cache' );
			}
		}

		/**
		 * Hook: bump the global settings revision whenever any plugin option changes,
		 * invalidating every cached graph at once.
		 *
		 * @param mixed $option Option name.
		 * @return void
		 */
		public static function maybe_bump_graph_rev( $option = '' ) {
			// Only real settings invalidate graphs. Internal log/counter/cache keys
			// are excluded — several of them are written on every served request,
			// and bumping a rev here would re-trigger this very hook (infinite loop).
			if ( ! is_string( $option ) || 0 !== strpos( $option, 'webmcp_gateway_' ) ) {
				return;
			}
			$internal = array(
				'webmcp_gateway_schema_rev',
				'webmcp_gateway_llmstxt_rev',
				'webmcp_gateway_llmstxt_cache',
				'webmcp_gateway_api_keys',
				'webmcp_gateway_activity_events',
				'webmcp_gateway_activity_counters',
				'webmcp_gateway_installed_version',
			);
			foreach ( $internal as $skip ) {
				if ( $option === $skip || 0 === strpos( $option, $skip . '_' ) ) {
					return;
				}
			}
			update_option( 'webmcp_gateway_schema_rev', (int) get_option( 'webmcp_gateway_schema_rev', 0 ) + 1, false );
		}

		/**
		 * Recursively drop null / empty-string / empty-array values so schema.org
		 * validators never see blank properties.
		 *
		 * @param mixed $data Node or scalar.
		 * @return mixed
		 */
		public static function prune_empty( $data ) {
			if ( ! is_array( $data ) ) {
				return $data;
			}
			$out = array();
			foreach ( $data as $key => $value ) {
				if ( null === $value ) {
					continue;
				}
				if ( is_string( $value ) && '' === trim( $value ) ) {
					continue;
				}
				if ( is_array( $value ) ) {
					$value = self::prune_empty( $value );
					if ( array() === $value ) {
						continue;
					}
				}
				$out[ $key ] = $value;
			}
			return $out;
		}

		/**
		 * Whether an FAQ answer is substantive enough for FAQPage JSON-LD.
		 * Rejects Answer-Gap instructional placeholders that fail schema.org / Google checks.
		 *
		 * @param string $answer Candidate answer text.
		 * @return bool
		 */
		public static function is_publishable_faq_answer( $answer ) {
			$answer = trim( wp_strip_all_tags( (string) $answer ) );
			if ( strlen( $answer ) < 40 ) {
				return false;
			}
			$patterns = array(
				'/^Explain the\b/i',
				'/^Summarize the\b/i',
				'/^Highlight the\b/i',
				'/^Describe the\b/i',
				'/^List the\b/i',
				'/^Provide (a|an|the)\b/i',
				'/^Write (a|an|the)\b/i',
				'/is a key topic covered in this guide\.?$/i',
			);
			foreach ( $patterns as $pattern ) {
				if ( preg_match( $pattern, $answer ) ) {
					return false;
				}
			}
			return true;
		}

		/**
		 * Resolve the best available publisher logo / site image URL + ImageObject.
		 *
		 * @param string $site_name Caption fallback.
		 * @return array|null ImageObject or null.
		 */
		private static function resolve_logo_object( $site_name ) {
			$home_url       = trailingslashit( home_url() );
			$site_name      = (string) $site_name;
			$custom_logo_id = (int) get_theme_mod( 'custom_logo' );

			if ( $custom_logo_id > 0 ) {
				$logo_src = wp_get_attachment_image_src( $custom_logo_id, 'full' );
				if ( is_array( $logo_src ) && ! empty( $logo_src[0] ) ) {
					$logo_object = array(
						'@type'      => 'ImageObject',
						'@id'        => $home_url . '#logo',
						'url'        => $logo_src[0],
						'contentUrl' => $logo_src[0],
						'caption'    => $site_name,
					);
					if ( ! empty( $logo_src[1] ) ) {
						$logo_object['width'] = (int) $logo_src[1];
					}
					if ( ! empty( $logo_src[2] ) ) {
						$logo_object['height'] = (int) $logo_src[2];
					}
					return $logo_object;
				}
			}

			$fallback_logo = trim( (string) get_option( 'webmcp_gateway_logo_url', '' ) );
			if ( '' === $fallback_logo && function_exists( 'get_site_icon_url' ) ) {
				$site_icon_url = get_site_icon_url( 512 );
				if ( ! empty( $site_icon_url ) ) {
					$fallback_logo = $site_icon_url;
				}
			}
			if ( '' === $fallback_logo ) {
				return null;
			}

			return array(
				'@type'      => 'ImageObject',
				'@id'        => $home_url . '#logo',
				'url'        => $fallback_logo,
				'contentUrl' => $fallback_logo,
				'caption'    => $site_name,
			);
		}

		/**
		 * Build the Publisher node (Organization or Person).
		 *
		 * @return array
		 */
		public static function build_publisher_node() {
			$home_url    = trailingslashit( home_url() );
			$entity_type = (string) get_option( 'webmcp_gateway_entity_type', 'Organization' );
			if ( ! in_array( $entity_type, array( 'Organization', 'Person' ), true ) ) {
				$entity_type = 'Organization';
			}

			$custom_name = trim( (string) get_option( 'webmcp_gateway_entity_name', '' ) );
			$site_name   = '' !== $custom_name ? $custom_name : (string) get_bloginfo( 'name' );

			$node = array(
				'@type' => $entity_type,
				'@id'   => $home_url . '#organization',
				'name'  => $site_name,
				'url'   => $home_url,
			);

			$desc = trim( (string) get_bloginfo( 'description' ) );
			if ( '' !== $desc ) {
				$node['description'] = $desc;
			}

			$logo_object = self::resolve_logo_object( $site_name );
			if ( null !== $logo_object ) {
				if ( 'Organization' === $entity_type ) {
					$node['logo']  = $logo_object;
					$node['image'] = array( '@id' => $home_url . '#logo' );
				} else {
					$node['image'] = $logo_object;
				}
			}

			$same_as_raw = (string) get_option( 'webmcp_gateway_same_as', '' );
			if ( '' !== trim( $same_as_raw ) ) {
				$lines   = preg_split( '/[\r\n,]+/', $same_as_raw );
				$same_as = array();
				if ( is_array( $lines ) ) {
					foreach ( $lines as $line ) {
						$clean_url = esc_url_raw( trim( $line ) );
						if ( '' !== $clean_url ) {
							$same_as[] = $clean_url;
						}
					}
				}
				if ( ! empty( $same_as ) ) {
					$node['sameAs'] = array_values( array_unique( $same_as ) );
				}
			}

			return $node;
		}

		/**
		 * Build the WebSite node with a single Google-compatible SearchAction.
		 *
		 * @return array
		 */
		public static function build_website_node() {
			$home_url  = trailingslashit( home_url() );
			$site_name = (string) get_bloginfo( 'name' );
			$desc      = trim( (string) get_bloginfo( 'description' ) );

			$node = array(
				'@type'           => 'WebSite',
				'@id'             => $home_url . '#website',
				'url'             => $home_url,
				'name'            => $site_name,
				'publisher'       => array( '@id' => $home_url . '#organization' ),
				'inLanguage'      => get_bloginfo( 'language' ),
				'potentialAction' => array(
					'@type'       => 'SearchAction',
					'target'      => array(
						'@type'       => 'EntryPoint',
						'urlTemplate' => $home_url . '?s={search_term_string}',
					),
					'query-input' => 'required name=search_term_string',
				),
			);

			if ( '' !== $desc ) {
				$node['description'] = $desc;
			}

			return $node;
		}

		/**
		 * Build the WebPage node with SpeakableSpecification (no non-standard actions).
		 *
		 * @param int    $post_id       Current post ID.
		 * @param string $canonical_url Canonical URL.
		 * @param string $context       Request context.
		 * @param bool   $has_crumbs    Whether a BreadcrumbList node is present.
		 * @return array
		 */
		public static function build_webpage_node( $post_id, $canonical_url, $context, $has_crumbs = true ) {
			$post_id       = (int) $post_id;
			$canonical_url = (string) $canonical_url;
			$context       = (string) $context;
			$home_url      = trailingslashit( home_url() );
			$page_type     = 'WebPage';
			$page_name     = (string) get_bloginfo( 'name' );
			$desc          = trim( (string) get_bloginfo( 'description' ) );

			if ( 'search' === $context ) {
				$page_type = 'SearchResultsPage';
				/* translators: %s: Search query string */
				$page_name = sprintf( __( 'Search Results for: %s', 'webmcp-gateway' ), get_search_query() );
				$desc      = '';
			} elseif ( 'archive' === $context ) {
				$page_type = 'CollectionPage';
				$page_name = wp_strip_all_tags( get_the_archive_title() );
				$desc      = '';
			} elseif ( '404' === $context ) {
				$page_type = 'ItemPage';
				$page_name = __( 'Page Not Found', 'webmcp-gateway' );
				$desc      = '';
			} elseif ( $post_id > 0 ) {
				$post = get_post( $post_id );
				if ( $post instanceof WP_Post ) {
					$page_name   = get_the_title( $post );
					$desc        = trim( (string) WebMCP_Gateway_Activity_Log::get_effective_ai_summary( $post ) );
					$custom_type = (string) get_post_meta( $post->ID, '_webmcp_gateway_schema_type', true );
					if ( in_array( $custom_type, array( 'AboutPage', 'ContactPage', 'FAQPage', 'ItemPage' ), true ) ) {
						$page_type = $custom_type;
					}
				}
			}

			$node = array(
				'@type'      => $page_type,
				'@id'        => $canonical_url . '#webpage',
				'url'        => $canonical_url,
				'name'       => $page_name,
				'isPartOf'   => array( '@id' => $home_url . '#website' ),
				'about'      => array( '@id' => $home_url . '#organization' ),
				'inLanguage' => get_bloginfo( 'language' ),
			);

			if ( '' !== $desc ) {
				$node['description'] = $desc;
			}

			if ( $has_crumbs ) {
				$node['breadcrumb'] = array( '@id' => $canonical_url . '#breadcrumb' );
			}

			if ( $post_id > 0 ) {
				$post = get_post( $post_id );
				if ( $post instanceof WP_Post ) {
					$node['datePublished'] = get_the_date( 'c', $post );
					$node['dateModified']  = get_the_modified_date( 'c', $post );
				}
			}

			// Speakable lives on WebPage only (avoid duplicate warnings on Article).
			$speakable = self::get_speakable_spec( $post_id );
			if ( ! empty( $speakable ) ) {
				$node['speakable'] = $speakable;
			}

			return $node;
		}

		/**
		 * Build hierarchical BreadcrumbList node.
		 *
		 * @param int    $post_id       Current post ID.
		 * @param string $canonical_url Canonical URL.
		 * @param string $context       Request context.
		 * @return array
		 */
		public static function build_breadcrumb_node( $post_id, $canonical_url, $context ) {
			$post_id       = (int) $post_id;
			$canonical_url = (string) $canonical_url;
			$context       = (string) $context;
			$home_url      = trailingslashit( home_url() );
			$items         = array(
				array(
					'@type'    => 'ListItem',
					'position' => 1,
					'name'     => __( 'Home', 'webmcp-gateway' ),
					'item'     => $home_url,
				),
			);

			if ( 'homepage' === $context ) {
				return array(
					'@type'           => 'BreadcrumbList',
					'@id'             => $canonical_url . '#breadcrumb',
					'itemListElement' => $items,
				);
			}

			$pos = 2;
			if ( $post_id > 0 ) {
				$post = get_post( $post_id );
				if ( $post instanceof WP_Post ) {
					if ( 'post' === $post->post_type ) {
						$cats = get_the_category( $post->ID );
						if ( ! empty( $cats ) && isset( $cats[0] ) ) {
							$cat_link = get_category_link( $cats[0]->term_id );
							if ( ! is_wp_error( $cat_link ) ) {
								$items[] = array(
									'@type'    => 'ListItem',
									'position' => $pos++,
									'name'     => $cats[0]->name,
									'item'     => $cat_link,
								);
							}
						}
					} elseif ( 'page' === $post->post_type && $post->post_parent > 0 ) {
						$ancestors = array_reverse( get_post_ancestors( $post->ID ) );
						foreach ( $ancestors as $ancestor_id ) {
							$anc_url = get_permalink( $ancestor_id );
							if ( $anc_url ) {
								$items[] = array(
									'@type'    => 'ListItem',
									'position' => $pos++,
									'name'     => get_the_title( $ancestor_id ),
									'item'     => $anc_url,
								);
							}
						}
					}
				}
			}

			$items[] = array(
				'@type'    => 'ListItem',
				'position' => $pos,
				'name'     => $post_id > 0 ? get_the_title( $post_id ) : __( 'Current Page', 'webmcp-gateway' ),
				'item'     => $canonical_url,
			);

			return array(
				'@type'           => 'BreadcrumbList',
				'@id'             => $canonical_url . '#breadcrumb',
				'itemListElement' => $items,
			);
		}

		/**
		 * Build the Article / BlogPosting / NewsArticle / TechArticle node.
		 *
		 * @param int    $post_id       Current post ID.
		 * @param string $canonical_url Canonical URL.
		 * @return array|null
		 */
		public static function build_article_node( $post_id, $canonical_url ) {
			$post_id       = (int) $post_id;
			$canonical_url = (string) $canonical_url;
			$post          = get_post( $post_id );
			if ( ! ( $post instanceof WP_Post ) ) {
				return null;
			}

			$custom_type = (string) get_post_meta( $post->ID, '_webmcp_gateway_schema_type', true );
			if ( in_array( $custom_type, array( 'WebPage', 'AboutPage', 'ContactPage', 'None' ), true ) ) {
				return null;
			}

			$default_type = (string) get_option( 'webmcp_gateway_default_schema', 'BlogPosting' );
			$schema_type  = 'Article';
			if ( in_array( $custom_type, array( 'Article', 'BlogPosting', 'NewsArticle', 'TechArticle' ), true ) ) {
				$schema_type = $custom_type;
			} elseif ( 'post' === $post->post_type && in_array( $default_type, array( 'Article', 'BlogPosting', 'NewsArticle', 'TechArticle' ), true ) ) {
				$schema_type = $default_type;
			}

			$home_url    = trailingslashit( home_url() );
			$author_id   = (int) $post->post_author;
			$author_name = trim( (string) get_the_author_meta( 'display_name', $author_id ) );
			$author_desc = (string) get_the_author_meta( 'description', $author_id );
			$author_url  = get_author_posts_url( $author_id );

			// Never emit a bare email as Person.name — validators and Google both flag it.
			if ( '' === $author_name || false !== strpos( $author_name, '@' ) ) {
				$nicename = trim( (string) get_the_author_meta( 'nickname', $author_id ) );
				if ( '' !== $nicename && false === strpos( $nicename, '@' ) ) {
					$author_name = $nicename;
				} else {
					$login = trim( (string) get_the_author_meta( 'user_login', $author_id ) );
					if ( '' !== $login && false === strpos( $login, '@' ) ) {
						$author_name = $login;
					} else {
						$author_name = (string) get_bloginfo( 'name' );
					}
				}
			}

			$description = trim( (string) WebMCP_Gateway_Activity_Log::get_effective_ai_summary( $post ) );
			$plain_text  = wp_strip_all_tags( strip_shortcodes( $post->post_content ) );
			$word_count  = webmcp_gateway_word_count( $plain_text );

			$author_node = array(
				'@type' => 'Person',
				'@id'   => $home_url . '#/schema/person/' . $author_id,
				'name'  => $author_name,
				'url'   => $author_url,
			);
			if ( '' !== trim( $author_desc ) ) {
				$author_node['description'] = wp_strip_all_tags( $author_desc );
			}
			$avatar_url = get_avatar_url( $author_id, array( 'size' => 256 ) );
			if ( ! empty( $avatar_url ) ) {
				$author_node['image'] = array(
					'@type' => 'ImageObject',
					'url'   => $avatar_url,
				);
			}

			$entity = array(
				'@type'            => $schema_type,
				'@id'              => $canonical_url . '#article',
				'url'              => $canonical_url,
				'isPartOf'         => array( '@id' => $canonical_url . '#webpage' ),
				'headline'         => get_the_title( $post ),
				'datePublished'    => get_the_date( 'c', $post ),
				'dateModified'     => get_the_modified_date( 'c', $post ),
				'mainEntityOfPage' => array(
					'@type' => 'WebPage',
					'@id'   => $canonical_url . '#webpage',
				),
				'inLanguage'       => get_bloginfo( 'language' ),
				'wordCount'        => max( 1, $word_count ),
				'author'           => $author_node,
				'publisher'        => array( '@id' => $home_url . '#organization' ),
			);

			if ( '' !== $description ) {
				$entity['description'] = $description;
			}

			$cats = get_the_category( $post->ID );
			if ( ! empty( $cats ) && is_array( $cats ) && isset( $cats[0]->name ) ) {
				// Google Article expects Text; use the primary category only.
				$entity['articleSection'] = (string) $cats[0]->name;
			}

			$tags = get_the_tags( $post->ID );
			if ( is_array( $tags ) && ! empty( $tags ) ) {
				$keywords = array();
				foreach ( $tags as $tag ) {
					$keywords[] = $tag->name;
				}
				$entity['keywords'] = implode( ', ', $keywords );
			}

			$img_node = null;
			$thumb_id = (int) get_post_thumbnail_id( $post->ID );
			if ( $thumb_id > 0 ) {
				$img_src = wp_get_attachment_image_src( $thumb_id, 'full' );
				if ( is_array( $img_src ) && ! empty( $img_src[0] ) ) {
					$img_node = array(
						'@type'      => 'ImageObject',
						'@id'        => $canonical_url . '#primaryimage',
						'url'        => $img_src[0],
						'contentUrl' => $img_src[0],
					);
					if ( ! empty( $img_src[1] ) ) {
						$img_node['width'] = (int) $img_src[1];
					}
					if ( ! empty( $img_src[2] ) ) {
						$img_node['height'] = (int) $img_src[2];
					}
				}
			}
			// Article / BlogPosting require image for rich results — fall back to publisher logo.
			if ( null === $img_node ) {
				$logo = self::resolve_logo_object( (string) get_bloginfo( 'name' ) );
				if ( null !== $logo && ! empty( $logo['url'] ) ) {
					$img_node = array(
						'@type'      => 'ImageObject',
						'@id'        => $canonical_url . '#primaryimage',
						'url'        => $logo['url'],
						'contentUrl' => $logo['url'],
					);
					if ( ! empty( $logo['width'] ) ) {
						$img_node['width'] = (int) $logo['width'];
					}
					if ( ! empty( $logo['height'] ) ) {
						$img_node['height'] = (int) $logo['height'];
					}
				}
			}
			if ( null !== $img_node ) {
				$entity['image'] = $img_node;
			}

			return $entity;
		}

		/**
		 * Build unlocked WooCommerce Product & Offer Schema.org node on singular `product` pages.
		 *
		 * @param int    $post_id       Product post ID.
		 * @param string $canonical_url Canonical URL.
		 * @return array|null
		 */
		public static function build_product_node( $post_id, $canonical_url ) {
			$post_id       = (int) $post_id;
			$canonical_url = (string) $canonical_url;
			$post          = get_post( $post_id );
			if ( ! ( $post instanceof WP_Post ) ) {
				return null;
			}

			$home_url    = trailingslashit( home_url() );
			$description = trim( (string) WebMCP_Gateway_Activity_Log::get_effective_ai_summary( $post ) );
			$sku         = (string) get_post_meta( $post_id, '_sku', true );
			$price       = (string) get_post_meta( $post_id, '_price', true );
			$stock_stat  = (string) get_post_meta( $post_id, '_stock_status', true );
			$currency    = function_exists( 'get_woocommerce_currency' ) ? (string) get_woocommerce_currency() : 'USD';

			$product = array(
				'@type' => 'Product',
				'@id'   => $canonical_url . '#product',
				'name'  => get_the_title( $post ),
				'url'   => $canonical_url,
				'brand' => array(
					'@type' => 'Brand',
					'name'  => (string) get_bloginfo( 'name' ),
				),
			);

			if ( '' !== $description ) {
				$product['description'] = $description;
			}

			if ( '' !== $sku ) {
				$product['sku'] = $sku;
			}

			$thumb_id = (int) get_post_thumbnail_id( $post->ID );
			if ( $thumb_id > 0 ) {
				$img_src = wp_get_attachment_image_src( $thumb_id, 'full' );
				if ( is_array( $img_src ) && ! empty( $img_src[0] ) ) {
					$product['image'] = $img_src[0];
				}
			}
			if ( empty( $product['image'] ) ) {
				$logo = self::resolve_logo_object( (string) get_bloginfo( 'name' ) );
				if ( null !== $logo && ! empty( $logo['url'] ) ) {
					$product['image'] = $logo['url'];
				}
			}

			if ( '' !== $price && is_numeric( $price ) ) {
				$product['offers'] = array(
					'@type'         => 'Offer',
					'url'           => $canonical_url,
					'price'         => number_format( (float) $price, 2, '.', '' ),
					'priceCurrency' => $currency,
					'availability'  => ( 'outofstock' === $stock_stat )
						? 'https://schema.org/OutOfStock'
						: 'https://schema.org/InStock',
					'seller'        => array( '@id' => $home_url . '#organization' ),
				);
			}

			return $product;
		}

		/**
		 * Build FAQPage schema node from manual metabox FAQs or Auto-Extracted `?` headings.
		 * Placeholder Answer-Gap hints are excluded so schema.org stays clean.
		 *
		 * @param int    $post_id       Current post ID.
		 * @param string $canonical_url Canonical URL.
		 * @return array|null
		 */
		public static function build_faq_node( $post_id, $canonical_url ) {
			$post_id       = (int) $post_id;
			$canonical_url = (string) $canonical_url;
			if ( $post_id <= 0 ) {
				return null;
			}

			$faqs = get_post_meta( $post_id, '_webmcp_gateway_faq_items', true );
			if ( ( ! is_array( $faqs ) || empty( $faqs ) ) && (bool) get_option( 'webmcp_gateway_auto_faq_enabled', 1 ) ) {
				$post_obj = get_post( $post_id );
				if ( $post_obj instanceof WP_Post ) {
					$faqs = WebMCP_Gateway_Activity_Log::extract_auto_faqs_from_html( $post_obj->post_content );
				}
			}
			if ( ! is_array( $faqs ) || empty( $faqs ) ) {
				return null;
			}

			$questions = array();
			foreach ( $faqs as $item ) {
				$q = isset( $item['q'] ) ? trim( (string) $item['q'] ) : '';
				$a = isset( $item['a'] ) ? trim( (string) $item['a'] ) : '';
				if ( '' === $q || ! self::is_publishable_faq_answer( $a ) ) {
					continue;
				}
				$questions[] = array(
					'@type'          => 'Question',
					'name'           => $q,
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => $a,
					),
				);
			}

			if ( empty( $questions ) ) {
				return null;
			}

			$page_title = $post_id > 0 ? get_the_title( $post_id ) : '';
			if ( '' !== $page_title ) {
				/* translators: %s: Post title */
				$faq_about = __( 'Frequently asked questions about %s', 'webmcp-gateway' );
				$faq_name  = sprintf( $faq_about, $page_title );
			} else {
				$faq_name = __( 'Frequently asked questions', 'webmcp-gateway' );
			}

			return array(
				'@type'      => 'FAQPage',
				'@id'        => $canonical_url . '#faq',
				'url'        => $canonical_url,
				'name'       => $faq_name,
				'isPartOf'   => array( '@id' => $canonical_url . '#webpage' ),
				'inLanguage' => get_bloginfo( 'language' ),
				'mainEntity' => $questions,
			);
		}

		/**
		 * Build SpeakableSpecification array if enabled globally and not disabled on the post.
		 *
		 * @param int $post_id Optional post ID.
		 * @return array
		 */
		public static function get_speakable_spec( $post_id = 0 ) {
			$post_id = (int) $post_id;
			if ( ! (bool) get_option( 'webmcp_gateway_speakable_enabled', 1 ) ) {
				return array();
			}

			if ( $post_id > 0 && (bool) get_post_meta( $post_id, '_webmcp_gateway_speakable_disable', true ) ) {
				return array();
			}

			$raw_css   = (string) get_option(
				'webmcp_gateway_speakable_css',
				'h1.entry-title, .entry-title, .entry-content > p:first-of-type, .wp-block-post-content > p:first-of-type, .webmcp-ai-summary'
			);
			$parts     = array_filter( array_map( 'trim', explode( ',', $raw_css ) ) );
			$selectors = ! empty( $parts ) ? array_values( $parts ) : array( 'h1.entry-title', '.entry-content > p:first-of-type' );

			return array(
				'@type'       => 'SpeakableSpecification',
				'cssSelector' => $selectors,
			);
		}

		/**
		 * Resolve canonical URL for the current request or post ID.
		 *
		 * @param int $post_id Optional post ID.
		 * @return string
		 */
		public static function get_canonical_url( $post_id = 0 ) {
			$post_id = (int) $post_id;
			if ( $post_id > 0 ) {
				$permalink = get_permalink( $post_id );
				if ( is_string( $permalink ) && '' !== $permalink ) {
					return $permalink;
				}
			}
			if ( is_search() ) {
				return home_url( '/?s=' . rawurlencode( get_search_query() ) );
			}
			return home_url( '/' );
		}

		/**
		 * Validate a generated @graph against core Schema.org requirements —
		 * fully local (no external API calls), usable from CLI and admin.
		 *
		 * @param mixed $graph Graph array as produced by generate().
		 * @return array{valid: bool, errors: array<int, string>, warnings: array<int, string>, node_count: int}
		 */
		public static function validate_graph( $graph = array() ) {
			$errors   = array();
			$warnings = array();

			if ( ! is_array( $graph ) || empty( $graph ) ) {
				return array(
					'valid'     => false,
					'errors'    => array( __( 'The @graph payload is empty.', 'webmcp-gateway' ) ),
					'warnings'  => array(),
					'node_count' => 0,
				);
			}

			if ( empty( $graph['@context'] ) || 'https://schema.org' !== (string) $graph['@context'] ) {
				$errors[] = __( "@context must be exactly https://schema.org", 'webmcp-gateway' );
			}

			if ( empty( $graph['@graph'] ) || ! is_array( $graph['@graph'] ) ) {
				$errors[] = __( '@graph is missing or empty.', 'webmcp-gateway' );
				return array(
					'valid'      => false,
					'errors'     => $errors,
					'warnings'   => $warnings,
					'node_count' => 0,
				);
			}

			$id_usage = array();
			$required = array(
				'Organization'      => array( 'name', 'url' ),
				'Person'            => array( 'name' ),
				'WebSite'           => array( 'name', 'url' ),
				'WebPage'           => array( 'name', 'url' ),
				'AboutPage'         => array( 'name', 'url' ),
				'ContactPage'       => array( 'name', 'url' ),
				'CollectionPage'    => array( 'name', 'url' ),
				'SearchResultsPage' => array( 'name', 'url' ),
				'ItemPage'          => array( 'name', 'url' ),
				'Article'           => array( 'headline', 'datePublished', 'author', 'url', 'image' ),
				'BlogPosting'       => array( 'headline', 'datePublished', 'author', 'url', 'image' ),
				'NewsArticle'       => array( 'headline', 'datePublished', 'author', 'url', 'image' ),
				'TechArticle'       => array( 'headline', 'datePublished', 'author', 'url', 'image' ),
				'Product'           => array( 'name', 'image', 'offers' ),
				'BreadcrumbList'    => array( 'itemListElement' ),
				'ImageObject'       => array( 'url' ),
				'FAQPage'           => array( 'mainEntity', 'url' ),
			);

			foreach ( $graph['@graph'] as $index => $node ) {
				if ( ! is_array( $node ) || empty( $node['@type'] ) ) {
					/* translators: %d: Node position in the graph */
					$errors[] = sprintf( __( 'Node #%d has no @type.', 'webmcp-gateway' ), $index );
					continue;
				}
				$type = is_array( $node['@type'] ) ? implode( ', ', $node['@type'] ) : (string) $node['@type'];

				if ( ! empty( $node['@id'] ) ) {
					$id_usage[ (string) $node['@id'] ][] = $type;
				}

				foreach ( $node as $prop => $val ) {
					if ( is_string( $val ) && '' === trim( $val ) ) {
						$errors[] = sprintf(
							/* translators: 1: Schema type, 2: Property name */
							__( '%1$s has an empty "%2$s" property — omit empty fields.', 'webmcp-gateway' ),
							$type,
							$prop
						);
					}
				}

				$types_to_check = is_array( $node['@type'] ) ? $node['@type'] : array( $node['@type'] );
				$missing        = array();
				foreach ( $types_to_check as $single_type ) {
					foreach ( isset( $required[ $single_type ] ) ? $required[ $single_type ] : array() as $prop ) {
						if ( empty( $node[ $prop ] ) ) {
							$missing[] = $prop;
						}
					}
				}
				if ( ! empty( $missing ) ) {
					$errors[] = sprintf(
						/* translators: 1: Schema type, 2: Comma-separated property list */
						__( '%1$s node is missing required properties: %2$s', 'webmcp-gateway' ),
						$type,
						implode( ', ', array_unique( $missing ) )
					);
				}

				if ( 'Organization' === $type && empty( $node['logo'] ) ) {
					$warnings[] = __( 'Organization is missing logo — set a Custom Logo, Site Icon, or WebMCP logo URL for Google Article rich results.', 'webmcp-gateway' );
				}

				if ( 'WebSite' === $type && ! empty( $node['potentialAction'] ) ) {
					$actions = isset( $node['potentialAction'][0] ) ? $node['potentialAction'] : array( $node['potentialAction'] );
					foreach ( $actions as $action ) {
						if ( ! is_array( $action ) ) {
							continue;
						}
						$target = isset( $action['target'] ) ? $action['target'] : array();
						if ( is_array( $target ) && isset( $target['httpMethod'] ) && 'POST' === strtoupper( (string) $target['httpMethod'] ) ) {
							$errors[] = __( 'WebSite SearchAction must use GET urlTemplate with {search_term_string}, not a POST MCP endpoint.', 'webmcp-gateway' );
						}
					}
				}

				if ( 'FAQPage' === $type && ! empty( $node['mainEntity'] ) && is_array( $node['mainEntity'] ) ) {
					foreach ( $node['mainEntity'] as $qi => $question ) {
						$text = '';
						if ( is_array( $question ) && isset( $question['acceptedAnswer']['text'] ) ) {
							$text = (string) $question['acceptedAnswer']['text'];
						}
						if ( ! self::is_publishable_faq_answer( $text ) ) {
							$errors[] = sprintf(
								/* translators: %d: Question index */
								__( 'FAQPage question #%d has a placeholder or too-short answer — write a real factual answer.', 'webmcp-gateway' ),
								(int) $qi + 1
							);
						}
					}
				}
			}

			foreach ( $id_usage as $id => $types ) {
				if ( count( $types ) > 1 ) {
					$errors[] = sprintf(
						/* translators: %s: Duplicated @id value */
						__( 'Duplicate @id used by multiple nodes: %s', 'webmcp-gateway' ),
						$id
					);
				}
			}

			return array(
				'valid'      => empty( $errors ),
				'errors'     => $errors,
				'warnings'   => $warnings,
				'node_count' => count( $graph['@graph'] ),
			);
		}
	}
}
