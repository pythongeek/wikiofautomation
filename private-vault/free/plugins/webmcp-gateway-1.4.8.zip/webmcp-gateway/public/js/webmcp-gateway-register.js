/**
 * WebMCP Client Runner — W3C document.modelContext & Chrome navigator.modelContext Bridge.
 *
 * @package WebMCP_Gateway
 * @license GPL-2.0-or-later
 */
(function () {
	'use strict';
	// Issue 20: silent failures stay page-safe but become debuggable on demand.
	function wmDebugLog(context, err) {
		if (window.webmcpDebug === true) {
			console.warn('[WebMCP] ' + context, err);
		}
	}
	'use strict';
	if (typeof window === 'undefined') {
		return;
	}

	var config = window.WebMCPGatewayConfig || {};

	function parseInlineManifest() {
		var el = document.getElementById('webmcp-manifest');
		if (!el || !el.textContent) {
			return null;
		}
		try {
			return JSON.parse(el.textContent);
		} catch (err) {
			wmDebugLog('config parse failed', err);
			return null;
		}
	}

	function callTool(toolName, args) {
		var baseUrl = config.restUrl || '/wp-json/webmcp-gateway/v1/call/';
		return window.fetch(baseUrl + encodeURIComponent(toolName), {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json'
			},
			body: JSON.stringify(args || {})
		}).then(function (res) {
			return res.json();
		});
	}

	var api = {
		version: config.version || '1.3.0',
		isReady: true,
		getConfig: function () {
			return config;
		},
		getManifest: function () {
			return parseInlineManifest();
		},
		listTools: function () {
			var manifest = parseInlineManifest();
			return (manifest && Array.isArray(manifest.tools)) ? manifest.tools : [];
		},
		callTool: callTool
	};

	window.WebMCP = window.WebMCP || api;

	var mcTarget = (typeof document !== 'undefined' && document.modelContext)
		? document.modelContext
		: ((typeof navigator !== 'undefined' && navigator.modelContext) ? navigator.modelContext : null);

	if (mcTarget && typeof mcTarget.registerTool === 'function') {
		api.listTools().forEach(function (tool) {
			try {
				mcTarget.registerTool({
					name: tool.name,
					description: tool.description,
					inputSchema: tool.inputSchema,
					execute: function (params) {
						return callTool(tool.name, params);
					}
				});
			} catch (e) {
				// Browser implementation differences are expected, not errors.
				wmDebugLog('modelContext registration skipped', e);
			}
		});
	}
})();
