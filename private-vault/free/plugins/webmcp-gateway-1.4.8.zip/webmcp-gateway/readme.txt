=== WebMCP Gateway ===
Contributors: n4nion
Donate link: https://webmcp-nexus.wikiofautomation.com/
Tags: mcp, aeo, schema, llmstxt, structured-data
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.4.8
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Answer Engine Optimization for WordPress: Model Context Protocol (MCP) tools, /llms.txt, Schema.org JSON-LD, Markdown for agents, and a local agent-readiness audit.

== Description ==

WebMCP Gateway helps WordPress sites become discoverable and usable by AI answer engines and autonomous agents. It combines Answer Engine Optimization (AEO), Generative Engine Optimization (GEO)–friendly structured data, Model Context Protocol (MCP) tools, `/llms.txt`, Schema.org JSON-LD, Markdown content streams, and a local agent-readiness audit—fully unlocked, GPL-licensed, and running on your own server.

When ChatGPT Search, Perplexity, Claude, Google AI Overviews, and WebMCP-style browser agents visit a site, they look for discovery manifests, clean semantic content, entity graphs, and callable tools. WebMCP Gateway ships those layers in one privacy-first package with no remote executable code and no trialware.

= Why publishers and SEOs install it =

* Make posts and products citeable by answer engines with Speakable-ready copy, FAQPage schema, and Markdown negotiation.
* Publish an `llms.txt` / `llms-full.txt` index agents can crawl (llmstxt.org-style).
* Expose six read-only MCP tools so agents can search your site, fetch posts, and read catalog data.
* Control AI crawlers in `robots.txt` (search bots vs training bots) and Content Signals preferences.
* Score agent readiness locally (and optionally compare with Cloudflare’s public isitagentready.com scanner).

= Complete feature set (100% unlocked) =

* **Page AEO X-Ray & Answer-Gap Scanner** — Scan any post, page, or product in wp-admin for a 0–100 Page AEO score and letter grade (A+–C), Speakable sentences answer engines may quote, high-intent Answer-Gap questions, and one-click `FAQPage` schema injection.
* **Auto-FAQPage from question headings** — `H2`/`H3` headings that end with `?` plus the following answer paragraph become Schema.org/FAQPage JSON-LD and appear in the AI Markdown stream.
* **WooCommerce Product & Offer schema** — When WooCommerce is active, product pages emit Product/Offer JSON-LD (SKU, price, currency, stock).
* **AI crawler access matrix** — Allow or Disallow `OAI-SearchBot`, `ChatGPT-User`, `PerplexityBot`, `ClaudeBot`, `Google-Extended`, `GPTBot`, and `CCBot` in WordPress’s virtual `robots.txt`, plus Content Signals (ai-train / search / ai-input).
* **Local AI activity log** — Privacy-safe log of crawler hits, MCP tool calls, `/llms.txt` reads, and Markdown fetches (capped; clear or disable anytime).
* **Ask AI / Cite This Page bar** — Optional frontend callout with Key Summary (TL;DR) and buttons for ChatGPT, Perplexity, Claude, and “View AI Markdown,” plus the `[webmcp_ai_summary]` shortcode.
* **Six MCP read tools** —
  1. `getSiteInfo` — site title, language, theme, counts, AEO endpoint metadata.
  2. `searchSite` — keyword search across posts, pages, products, and public CPTs.
  3. `getFeaturedContent` — recent articles with reading time, categories, AI summaries.
  4. `getPostContent` — Markdown, summaries, and FAQs by ID, slug, or URL.
  5. `getSiteTaxonomies` — categories/tags with counts for topical hierarchy.
  6. `getCatalogItems` — WooCommerce products (price, SKU, stock) or fallback catalog items.
* **Markdown for agents** — HTML→Markdown with YAML frontmatter via `?format=markdown` or `Accept: text/markdown` (including homepage index).
* **Dynamic `/llms.txt` & `/llms-full.txt`** — Spec-oriented generators with an in-dashboard live preview.
* **Agent discovery documents** — `/.well-known/mcp.json`, API Catalog (RFC 9727), Agent Skills, ARD/ai-catalog, `/auth.md`, and related Link headers agents and scanners expect.
* **Agent-Ready Audit** — Local self-audit aligned with common industry checks (robots, sitemap, Link headers, Markdown negotiation, bot rules, MCP card, skills, ARD, WebMCP), scored 0–100 with exportable JSON.
* **Optional API key on MCP REST** — Open by default for discovery; optionally require `X-WebMCP-Key` on `/wp-json/webmcp-gateway/v1/*`.
* **WP-CLI** — `wp webmcp status|audit|tools|flush-cache|clear-log`.

= Privacy & data disclosure =

* **No telemetry** — Nothing is sent to the plugin author’s servers. The activity log stays in your WordPress database.
* **No remote scripts/CDNs** — JS and CSS are bundled locally (Guideline 8).
* **One optional external service** — If an administrator enables “Allow external Cloudflare scan,” clicking “Verify via Cloudflare” sends only your site URL to isitagentready.com (Cloudflare’s free public agent-readiness scanner). The feature is off by default and can be disabled anytime.
* Terms/privacy for that optional scanner: follow Cloudflare / isitagentready.com public documentation when you enable it.

= Built for search, answers, and agents (SEO + AEO + GEO) =

* **SEO** — Valid Schema.org `@graph` (Article/WebPage, FAQPage, Product/Offer, Organization/WebSite) helps rich results and clear entity signals.
* **AEO** — Speakable extraction, Answer-Gap FAQs, and cite-this-page flows target how answer engines select quotable passages.
* **GEO** — Stable entity IDs, Markdown + llms.txt surfaces, and MCP tools give generative systems structured, citable source material instead of scraped HTML alone.

This plugin does not insert arbitrary executable code, download remote plugins, or lock features behind licenses or trials.

Project / donate: https://webmcp-nexus.wikiofautomation.com/

== Installation ==

1. Upload the `webmcp-gateway` folder to `/wp-content/plugins/` (or install the zip via **Plugins → Add New → Upload Plugin**).
2. Activate **WebMCP Gateway** through the **Plugins** menu in WordPress (deactivate any conflicting duplicate MCP/AEO plugin first).
3. Open **WebMCP Gateway → Overview** and click **Run audit** to score agent readiness (llms.txt, MCP card, robots, Link headers, and more).
4. Open **X-Ray Scanner**, pick a high-traffic post, review the AEO grade, and fix Answer-Gaps.
5. Review **Settings**: schema toggles, per-bot crawler matrix, optional MCP API key, and optional Cloudflare verification.

== Frequently Asked Questions ==

= What is WebMCP Gateway? =

WebMCP Gateway is a free WordPress plugin that makes your site easier for AI answer engines and MCP-compatible agents to discover and use. It adds `/llms.txt`, Schema.org JSON-LD, Markdown streams, six MCP read tools, crawler policy controls, and a local agent-readiness audit.

= What is Answer Engine Optimization (AEO)? =

AEO is the practice of structuring content so AI answer engines (ChatGPT Search, Perplexity, Google AI Overviews, Claude, and similar) can find, trust, and quote accurate passages. WebMCP Gateway scores pages, surfaces Speakable sentences, finds Answer-Gap questions, and injects FAQPage schema to support that.

= How does this help Generative Engine Optimization (GEO)? =

GEO focuses on being cited as a source inside generative answers. Stable Schema.org entities, clean Markdown, `/llms.txt`, and MCP tools give models machine-readable facts (title, summary, FAQs, products) instead of noisy HTML—improving the chance your site is selected as a citation.

= What is Model Context Protocol (MCP) in this plugin? =

MCP is an open protocol for connecting AI clients to tools and data. WebMCP Gateway exposes a WordPress REST MCP surface (`/wp-json/webmcp-gateway/v1/`) and a `/.well-known/mcp.json` card so agents can call read tools like `searchSite` and `getPostContent` against your published content.

= How do I check if the plugin is working on my site? =

Open **WebMCP Gateway** in your WordPress sidebar. On the **Overview** screen, click **Run audit** to run the local Agent-Ready checks, then use the **Endpoint Inspector** to view your live `/llms.txt` and `/.well-known/mcp.json` without leaving WordPress. Open the **X-Ray Scanner** to audit any specific post, page, or product.

= Are any features locked behind a paywall or pro gate? =

No. Every tool, schema entity (including `FAQPage` and WooCommerce `Product`/`Offer`), crawler rule, and scanner feature included in WebMCP Gateway is 100% unlocked in full compliance with WordPress.org Guideline 5.

= Does the plugin require WooCommerce? =

No. WooCommerce support is entirely optional. When WooCommerce is active, the `getCatalogItems` MCP tool returns products with SKU, price, currency, and stock status, and the schema graph gains Product/Offer nodes. Without it, the tool still works — it returns pages and posts as catalog items and reports `"catalog_available": false, "reason": "woocommerce-not-active"` so agents know product data is not in play.

= Can I require an API key for the MCP REST endpoints? =

Yes — optionally. Public agent access is open by default because that is how AI engines discover your content. Only published, non-password-protected posts/pages are returned. If you want to lock the REST API (`/wp-json/webmcp-gateway/v1/*`) down, open **WebMCP Gateway → Settings → MCP API access**, generate a key, and enable **Require API key on MCP REST endpoints**. Clients then send the key via the `X-WebMCP-Key` header (or `api_key` parameter). Keys are stored as SHA-256 hashes and shown only once; logged-in administrators always retain access. Rate limits are per client IP (behind CDNs/proxies, configure your edge to pass the real visitor IP).

= Does the plugin send any data off my site? =

By default, no. Activity logging stays in your WordPress database. The only optional outbound call is the Cloudflare Agent-Ready scanner (`isitagentready.com`): it is off by default, requires an admin opt-in toggle, and then sends only your public site URL when you press Verify. Documented under Privacy & data disclosure in the Description.

= Will this replace my SEO plugin (Yoast, Rank Math, AIOSEO)? =

No. It complements classic SEO plugins. WebMCP Gateway focuses on AI/agent discovery layers (MCP, llms.txt, Markdown, agent audit, AI crawler matrix). Keep your SEO plugin for sitemaps, classic meta, and search console workflows; avoid duplicate FAQ/Product schema if both plugins emit the same types—disable the overlap you do not need.

= Is the code GPL and human-readable? =

Yes. Licensed GPLv2 or later, shipped as readable PHP/JS/CSS with no obfuscation and no remote executable downloads.

= Where can I get support or donate? =

Use the WordPress.org support forum for the plugin after it is listed, or visit https://webmcp-nexus.wikiofautomation.com/ for project information and donations.

== Screenshots ==

1. Overview dashboard with agent-readiness gauge, health checklist, and live activity feed.
2. Agent Audit screen running industry-standard readiness checks with optional Cloudflare verification.
3. Page AEO X-Ray Scanner with score, speakable citations, and Answer-Gap FAQ injector.
4. Agent Sandbox running the six MCP tools and inspecting live JSON responses.
5. Settings — schema engine, per-bot crawler policy, frontend widgets, and MCP API keys.
6. Frontend Ask AI bar — Cite-this-page actions for ChatGPT, Perplexity, and Claude.

== Changelog ==

= 1.4.8 =
* Settings toggles now clear correctly when unchecked (hidden `0` companions for `options.php`).
* Plugin Check: removed non-prefixed LiteSpeed `do_action`; use LiteSpeed_Cache_API when available.
* Shortened plugin display name and description for directory clarity.
* Admin dashboard UI: mobile nav toggle, improved responsive layout for tablets and phones.
* readme: Screenshots section, clearer public REST / API-key FAQ, activity log copy updated.
* Donate / project URI updated to https://webmcp-nexus.wikiofautomation.com/
* readme expanded for AEO / GEO / MCP discoverability on WordPress.org and Google.

= 1.4.7 =
* **Schema.org-clean JSON-LD**: empty properties pruned; single Google-compatible WebSite SearchAction; BlogPosting/Article always include `url` + `image`; FAQPage drops instructional Answer-Gap placeholders; Organization/Person logo handling tightened; non-standard MCP/markdown EntryPoints removed from the public graph.
* Answer-Gap inject and metabox save reject placeholder answers so FAQPage never fails schema.org validation.

= 1.4.6 =
* Submission hardening: GPLv2 license declaration + license.txt, prepared uninstall SQL, removed duplicate AJAX hooks, fixed stale Simulate AI Visit docs, moved directory banners out of the plugin zip.
* Critical fix: Markdown content negotiation now requires a real markdown preference (q-value) and always sends Vary: Accept + no-store for Accept-negotiated responses so LiteSpeed/CDN cannot poison HTML URLs with cached Markdown.

= 1.4.5 =
* **Audit engine rewritten for honesty**: removed the local-evidence fallback that could convert unverified checks into passes. Checks that cannot be verified live are now reported as UNVERIFIED (never counted as passing), and scoring uses the industry-strict method — every check counts, exactly like external scanners.
* **Deeper validation**: the ARD manifest check now requires the spec's "entries" array (the served manifest now includes it), auth.md must actually describe agent registration/credentials to pass, and DNS-AID performs a real DNS lookup.
* **New "Public Bot Access (edge reality)" check group**: probes robots.txt, the MCP card, llms.txt and Agent Skills with a real AI-crawler user agent — if your host/CDN blocks AI crawlers at the edge (HTTP 429/403), the audit reports it with fix instructions instead of hiding it.
* **Deep-scan experience**: running the audit shows a live radar-sweep animation with a staged checklist while 24 checks execute.
* **Detailed report export**: download the full audit report as JSON from the Agent Audit screen.
* Fixed: corrected the Agent Audit include path, the Link-header parser now reads every pair of multi-pair Link headers, and the crawler-policy bot labels no longer trigger early translation loading.

= 1.4.4 =
* **Fix**: translations are now loaded at the correct time (explicit `init`-hooked `load_plugin_textdomain`), and the crawler-policy bot labels are translated lazily — removing the WP 6.7+ "_load_textdomain_just_in_time called incorrectly" notice on fresh installs.
* **Fix**: corrected an include path on the Agent Audit screen that could emit a PHP warning for a doubled `partials/partials/` directory on sites with error display enabled.

= 1.4.3 =
* **Critical fix: infinite recursion on event logging** — the settings-revision hooks added in 1.4.2 reacted to their own revision writes (and to the activity log), causing a stack-overflow 500 on any request that recorded an event (all `.well-known/*` discovery documents, `auth.md`, and activity logging). Revision hooks now ignore internal log/counter/cache keys. All discovery endpoints verified 200 after the fix.
* **Audit accuracy fixes**: every audit HTTP check now retries with a browser user agent (hosts whose WAF rejects the WordPress UA no longer produce false failures); homepage checks use a cache-buster so page-cache copies never mask live behavior; the Link-header parser now reads every `<url>; rel="…"` pair in multi-pair Link headers (previously only the first pair was parsed, guaranteeing a false fail); and the "Run audit now" button on the Overview screen shows a scanning state and refreshes the gauge when done. Live-verified: 12/12 checks passing, "Fully Agent-Ready".
* **Public bot-access reality check**: the audit now verifies robots.txt, the MCP card, llms.txt and the Agent Skills index **as an AI crawler sees them** (GPTBot user agent). If a host/CDN edge blocks AI-crawler user agents (HTTP 429/403) before WordPress loads, the audit reports an honest, actionable failure instead of a passing grade that external scanners would contradict.
* **Deep-scan experience**: running the audit now shows a live scanning animation — radar sweep, ping rings, and a staged checklist of every probe as it executes.
* **No stale audit reports, ever**: the audit now stamps every report and views only display reports less than 5 minutes old — an older cached report is ignored (never shown) and the Agent Audit screen automatically runs a fresh, real scan on load. The Overview gauge uses the same freshness gate, so both screens always show the same live numbers with a "live report, X ago" stamp.
* **One honest score everywhere**: the Overview gauge now shows the exact same Agent-Ready audit score, level, and pass/fail counts as the Agent Audit screen (single cached report). No second, inflated number. Until an audit has run, the gauge shows "No audit yet" with a one-click "Run audit now" button instead of a placeholder value.
* **Audit checks survive blocked loopbacks**: many hosts block a server's own HTTP requests. The audit now retries with a browser user agent, falls back to query-string routes when `/.well-known/` is intercepted by server config, and — only when the gateway is provably active — reports feature checks as locally verified with an explicit note recommending external confirmation via the optional Cloudflare scan. Nothing is invented; honest failures stay failures.
* **Removed the "Simulate AI Visit" demo**: no more simulated agent events in the activity feed. The activity log records only real requests your server receives. The top-bar action is now "Run audit", and the onboarding checklist starts with the real audit.
* Link-header audit check now reads homepage response headers (it previously inspected the robots.txt response).
* Sandbox prompt runner relabeled "Run as agent" — it executes real MCP tool calls.

= 1.4.2 =
* New optional **API key enforcement** for the MCP REST API (Settings → MCP API access): generate keys (stored as SHA-256 hashes, shown once), revoke them any time, and — only if you choose — require a valid `X-WebMCP-Key` header on every `/webmcp-gateway/v1/` call. Anonymous agent reads remain open by default.
* **Hardened rate limiting**: the per-minute limiter now counts on persistent storage with atomic single-statement increments (SQL upsert, or object-cache increments on sites running Redis/Memcached) instead of transient-based counting — counts survive cache-plugin purges, stay accurate across load-balanced servers, and cannot be overrun by parallel requests. Adds a second per-hour burst cap (filterable via `webmcp_gateway_hourly_rate_limit`) so floods straddling a window boundary still get stopped, plus a 429 reply with retry seconds and automatic cleanup of expired counters.
* **Per-tool input validation on the MCP call endpoint**: every built-in tool now accepts only its documented parameters (allowlist with per-parameter sanitization, length caps, and integer clamps) — unknown, nested, or wrongly-typed values are dropped and oversized payloads over 4 KB are rejected with HTTP 413. Custom tools registered via the `webmcp_gateway_call_tool` filter keep receiving raw (size-capped) parameters.
* **Admin AJAX throttling**: the expensive admin endpoints (Agent Sandbox, X-Ray scan, Answer-Gap injection, AI-visit simulation, endpoint inspector, Agent-Ready audit, Cloudflare scan, API-key management) are now throttled per user with atomic persistent counters — 10 to 30 calls per minute depending on the handler — returning HTTP 429 with a friendly message when a button is hammered. Nonces and capability checks are unchanged.
* **Underscore namespace alias**: all MCP REST routes are now also served under the conventional WordPress-style `webmcp_gateway/v1` namespace alongside the canonical `webmcp-gateway/v1` (which remains the namespace advertised in docs, Link headers, and mcp.json). Both namespaces expose identical routes and behavior.
* **Short-lived sandbox execution tokens**: sandbox tool calls now require a one-time token fetched fresh per run (60s expiry, single use) on top of the standard nonce — replaying a captured request fails even inside the window.
* **Schema graph caching**: the JSON-LD `@graph` is built once per post and cached (12h, filterable) against post-modified time + a settings revision; editors always see fresh output, and the `webmcp_gateway_schema_graph` filter still runs on every request.
* **llms.txt caching**: `/llms.txt` and `/llms-full.txt` are generated once and cached until content or settings change, with `no_found_rows` queries and filterable post limits for very large sites.
* **Markdown conversion size cap**: conversion is capped at 100KB (filterable via `webmcp_gateway_markdown_max_bytes`); larger posts truncate with a clear note instead of risking timeouts.
* **Custom post type support**: `searchSite` now covers every public CPT registered as searchable (filterable via `webmcp_gateway_supported_post_types`), and CPT singles already emit Article/WebPage schema.
* **WP-CLI commands**: `wp webmcp clear-log`, `wp webmcp audit`, `wp webmcp flush-cache`, `wp webmcp tools`, and `wp webmcp status` for server-side operations.
* **JavaScript i18n + debug logging**: admin UI strings are translatable via `wp_localize_script`, and silent `catch` blocks now log to `console.warn` when `window.webmcpDebug` is enabled (page behavior unchanged).
* **Local Schema.org validation**: a new **Validate** button on Settings checks the live `@graph` (required properties per type, duplicate `@id`s, context) entirely offline, with results per context.
* **Hardened settings URL validation**: `logo_url` and the `same_as` list accept only `http(s)` URLs — `file://`, `phar://`, `javascript:`, and other schemes are dropped at save.
* **Multisite-safe uninstall**: the uninstaller now also removes schema caches, API keys, rate-limit/throttle counters, one-time tokens, and per-site data across the whole network.
* **Hardening headers on plugin-served responses**: markdown streams, `/llms.txt`, `/llms-full.txt`, robots policy, and every `/.well-known/*` discovery document now send `X-Content-Type-Options: nosniff`, a strict `Content-Security-Policy: default-src 'none'; sandbox`, and `Referrer-Policy: no-referrer` — defense-in-depth scoped strictly to the plugin's own plain-text/JSON responses (never site-wide, so themes and other plugins are unaffected).

= 1.4.1 =
* Discovery endpoints now answer on every commonly scanned path: **/.well-known/api-catalog.json** (in addition to the RFC 9727 path), **/.well-known/agent-skills.json** (in addition to index.json), **/.well-known/ard-manifest.json** (in addition to ai-catalog.json), and **/.well-known/auth.md** (in addition to /auth.md at the root).
* Plugin updates now flush rewrite rules automatically so newly added discovery endpoints route without a manual deactivation/reactivation.

= 1.4.0 =
* New **Agent-Ready Audit** screen: a local self-audit that replicates the industry-standard checks published by Cloudflare's isitagentready.com — robots.txt validity, sitemap, agent Link headers, Markdown negotiation, AI bot rules, Content Signals, API Catalog, MCP Server Card, auth.md, Agent Skills, ARD manifest, and WebMCP — scored 0–100 with readiness levels, run entirely from your own server.
* Generates the emerging agent-discovery standards automatically: **/.well-known/api-catalog** (RFC 9727 linkset), **/.well-known/agent-skills/index.json** with a SKILL.md, **/.well-known/ai-catalog.json** (Agentic Resource Discovery), and **/auth.md** documenting your agent authentication model.
* **Content Signals** policy (contentsignals.org): declare ai-train / search / ai-input preferences via the Content-Signal line in robots.txt — the requirement for "Bot-Aware" readiness.
* **Markdown for Agents** now negotiates on the homepage too, not only on posts and pages, serving a site-level Markdown index.
* Adds **rel="api-catalog"** and **rel="service-desc"** Link headers so industry scanners recognize your agent endpoints.
* Optional, off-by-default **Cloudflare verification**: relay a scan through isitagentready.com's free public API (only your site URL is sent) and read the verdict inside the dashboard, plus a deep link to your public report.
* Admin asset versions now use file timestamps so cached dashboards always load current scripts and styles.

= 1.3.0 =
* Fully redesigned admin interface ("AEO Cockpit"): new app shell with left navigation, animated AEO readiness gauge, KPI tiles, live activity feed with filters & 30-second polling, searchable post picker, expandable fix-list, AI quote card, and a two-pane Agent Sandbox with a terminal-style console.
* X-Ray Answer-Gap Finder: select and edit answers before injecting; duplicate questions are now skipped automatically so FAQPage schema never gets polluted twice.
* Added searchable AJAX post picker — sites with more than 30 posts can now scan any published content.
* Settings rebuilt into five focused sections with toggle switches, a grouped per-bot policy matrix with Allow-all / Block-training presets, a rate-limit slider, and an unsaved-changes bar.
* Post editor metabox redesigned with AEO status chips, a numbered layout, and a full FAQ repeater (drag to reorder, remove, auto-numbering).
* Frontend AI Summary / "Ask AI" bar restyled with a light/dark/auto theme and CSS variable overrides; new `webmcp_gateway_ai_box_html` filter for developers.
* Hardening & compliance: REST API namespace moved to the plugin-owned `webmcp-gateway/v1`, plugin translations now loaded via `load_plugin_textdomain()`, duplicate Link headers fixed, REST nonce no longer exposed to anonymous visitors, multibyte-safe word counts, and all assets carry explicit GPL headers.

= 1.2.0 =
* Removed all Pro gates and locked tool placeholders for 100% WordPress.org Guideline 5 compliance.
* Added 2 new unlocked MCP tools (`getSiteTaxonomies` and `getCatalogItems` for WooCommerce/catalog queries) for 6 total tools.
* Added unlocked WooCommerce `Product` & `Offer` Schema.org JSON-LD generation.
* Added **AI Answer-Gap Question Finder & 1-Click FAQ Schema Injector** inside the Page AEO X-Ray Scanner.
* Added **Per-Bot AI Crawler Access Matrix** (`OAI-SearchBot`, `ChatGPT-User`, `PerplexityBot`, `ClaudeBot`, `Google-Extended`, `GPTBot`, `CCBot`) in `robots.txt`.
* Hardened activation & file loading with `__DIR__` paths, guarded `WEBMCP_CORE_*` constants, and hook-safe PHP signatures to eliminate fatal errors across all PHP 7.4–8.4 setups.

== Upgrade Notice ==

= 1.4.8 =
Fully unlocked free AEO/MCP gateway: llms.txt, Schema.org, Markdown for agents, six MCP tools, crawler matrix, and local agent-readiness audit. Project & donate: https://webmcp-nexus.wikiofautomation.com/
