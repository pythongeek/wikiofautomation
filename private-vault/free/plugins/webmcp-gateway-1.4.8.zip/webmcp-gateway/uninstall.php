<?php
/**
 * Uninstall Handler - cleans up all plugin options, activity logs, and post meta upon deletion.
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Clean up plugin data for a single site.
 */
function webmcp_gateway_uninstall_site_data() {
	$webmcp_gateway_option_keys = array(
		'webmcp_gateway_enabled',
		'webmcp_gateway_schema_enabled',
		'webmcp_gateway_speakable_enabled',
		'webmcp_gateway_auto_faq_enabled',
		'webmcp_gateway_woo_schema_on',
		'webmcp_gateway_markdown_enabled',
		'webmcp_gateway_llmstxt_enabled',
		'webmcp_gateway_llmsfull_enabled',
		'webmcp_gateway_robots_enabled',
		'webmcp_gateway_bot_oai_search',
		'webmcp_gateway_bot_chatgpt_user',
		'webmcp_gateway_bot_perplexity',
		'webmcp_gateway_bot_claude',
		'webmcp_gateway_bot_google_ext',
		'webmcp_gateway_bot_gptbot',
		'webmcp_gateway_bot_ccbot',
		'webmcp_gateway_activity_log_on',
		'webmcp_gateway_activity_events',
		'webmcp_gateway_activity_counters',
		'webmcp_gateway_rate_limit',
		'webmcp_gateway_entity_type',
		'webmcp_gateway_entity_name',
		'webmcp_gateway_logo_url',
		'webmcp_gateway_same_as',
		'webmcp_gateway_speakable_css',
		'webmcp_gateway_default_schema',
		'webmcp_gateway_ai_summary_render',
		'webmcp_gateway_cite_bar_render',
		'webmcp_gateway_ai_box_theme',
		'webmcp_gateway_content_signal',
		'webmcp_gateway_cloudflare_scan',
		'webmcp_gateway_require_api_key',
		'webmcp_gateway_api_keys',
		'webmcp_gateway_schema_rev',
		'webmcp_gateway_llmstxt_rev',
		'webmcp_gateway_llmstxt_cache',
		'webmcp_gateway_installed_version',
	);

	foreach ( $webmcp_gateway_option_keys as $webmcp_gateway_key ) {
		delete_option( $webmcp_gateway_key );
	}

	delete_post_meta_by_key( '_webmcp_gateway_ai_summary' );
	delete_post_meta_by_key( '_webmcp_gateway_schema_type' );
	delete_post_meta_by_key( '_webmcp_gateway_speakable_disable' );
	delete_post_meta_by_key( '_webmcp_gateway_faq_items' );
	delete_post_meta_by_key( '_webmcp_graph_cache' );

	// Dynamic (prefixed) rows: schema graph caches, rate-limit + throttle counters,
	// and any leftover one-time sandbox execution tokens.
	global $wpdb;
	$like_patterns = array(
		$wpdb->esc_like( 'webmcp_gateway_graph_cache_' ) . '%',
		$wpdb->esc_like( 'webmcp_rl_' ) . '%',
		$wpdb->esc_like( 'webmcp_throttle_' ) . '%',
		$wpdb->esc_like( '_transient_webmcp_exec_' ) . '%',
		$wpdb->esc_like( '_transient_timeout_webmcp_exec_' ) . '%',
	);
	foreach ( $like_patterns as $like ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time uninstall cleanup; caching is pointless here.
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $like ) );
	}
}

if ( is_multisite() ) {
	$webmcp_gateway_sites = get_sites( array( 'fields' => 'ids', 'number' => 0 ) );
	if ( ! empty( $webmcp_gateway_sites ) ) {
		foreach ( $webmcp_gateway_sites as $webmcp_gateway_blog_id ) {
			switch_to_blog( $webmcp_gateway_blog_id );
			webmcp_gateway_uninstall_site_data();
			restore_current_blog();
		}
	}
} else {
	webmcp_gateway_uninstall_site_data();
}
