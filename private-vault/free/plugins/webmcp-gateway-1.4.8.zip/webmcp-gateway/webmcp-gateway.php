<?php
/**
 * Plugin Name:       WebMCP Gateway
 * Plugin URI:        https://webmcp-nexus.wikiofautomation.com/
 * Description:       Answer Engine Optimization for WordPress: MCP tools, /llms.txt, Schema.org JSON-LD, Markdown for agents, and a local agent-readiness audit.
 * Version:           1.4.8
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            n4nion
 * Author URI:        https://profiles.wordpress.org/n4nion
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       webmcp-gateway
 * Domain Path:       /languages
 *
 * @package WebMCP_Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Minimum PHP guard: must stay first and use pre-7.4 syntax so old runtimes
// can parse this file, deactivate the plugin, and show a clear notice instead
// of fatalling somewhere deep in 7.4+ code.
if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
	if ( is_admin() ) {
		add_action( 'admin_notices', 'webmcp_gateway_php_version_notice' );
		if ( function_exists( 'deactivate_plugins' ) && current_user_can( 'activate_plugins' ) ) {
			deactivate_plugins( plugin_basename( __FILE__ ) );
		}
	}
	return;
}

if ( ! function_exists( 'webmcp_gateway_php_version_notice' ) ) {
	/**
	 * Admin notice shown when the host runs PHP below the required 7.4.
	 *
	 * @return void
	 */
	function webmcp_gateway_php_version_notice() {
		echo '<div class="notice notice-error"><p>';
		echo esc_html__( 'WebMCP Gateway requires PHP 7.4 or newer. The plugin has been deactivated. Please ask your host to upgrade PHP, then reactivate it.', 'webmcp-gateway' );
		echo '</p></div>';
	}
}

if ( ! defined( 'WEBMCP_CORE_VERSION' ) ) {
	define( 'WEBMCP_CORE_VERSION', '1.4.8' );
}
if ( ! defined( 'WEBMCP_CORE_PATH' ) ) {
	define( 'WEBMCP_CORE_PATH', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'WEBMCP_CORE_URL' ) ) {
	define( 'WEBMCP_CORE_URL', plugin_dir_url( __FILE__ ) );
}
if ( ! defined( 'WEBMCP_CORE_BASENAME' ) ) {
	define( 'WEBMCP_CORE_BASENAME', plugin_basename( __FILE__ ) );
}

require_once __DIR__ . '/includes/class-webmcp-gateway-core.php';

// Guarantee that all modular classes are loaded immediately into PHP memory.
WebMCP_Gateway_Core::load_dependencies();

if ( ! function_exists( 'webmcp_gateway_default_options' ) ) {
	/**
	 * Default plugin settings helper.
	 *
	 * @return array
	 */
	function webmcp_gateway_default_options() {
		return array(
			'webmcp_gateway_enabled'           => 1,
			'webmcp_gateway_schema_enabled'    => 1,
			'webmcp_gateway_speakable_enabled' => 1,
			'webmcp_gateway_auto_faq_enabled'  => 1,
			'webmcp_gateway_woo_schema_on'     => 1,
			'webmcp_gateway_markdown_enabled'  => 1,
			'webmcp_gateway_llmstxt_enabled'   => 1,
			'webmcp_gateway_llmsfull_enabled'  => 1,
			'webmcp_gateway_robots_enabled'    => 1,
			'webmcp_gateway_bot_oai_search'    => 'allow',
			'webmcp_gateway_bot_chatgpt_user'  => 'allow',
			'webmcp_gateway_bot_perplexity'    => 'allow',
			'webmcp_gateway_bot_claude'        => 'allow',
			'webmcp_gateway_bot_google_ext'    => 'allow',
			'webmcp_gateway_bot_gptbot'        => 'allow',
			'webmcp_gateway_bot_ccbot'         => 'allow',
			'webmcp_gateway_activity_log_on'   => 1,
			'webmcp_gateway_rate_limit'        => 60,
			'webmcp_gateway_entity_type'       => 'Organization',
			'webmcp_gateway_entity_name'       => '',
			'webmcp_gateway_logo_url'          => '',
			'webmcp_gateway_same_as'           => '',
			'webmcp_gateway_speakable_css'     => 'h1.entry-title, .entry-title, .entry-content > p:first-of-type, .wp-block-post-content > p:first-of-type, .webmcp-ai-summary',
			'webmcp_gateway_default_schema'    => 'BlogPosting',
			'webmcp_gateway_ai_summary_render' => 0,
			'webmcp_gateway_cite_bar_render'   => 0,
			'webmcp_gateway_ai_box_theme'      => 'auto',
			'webmcp_gateway_content_signal'    => 'allow_all',
			'webmcp_gateway_cloudflare_scan'   => 0,
		);
	}
}

if ( ! function_exists( 'webmcp_gateway_word_count' ) ) {
	/**
	 * Multibyte-safe word counter (str_word_count is ASCII-only).
	 *
	 * @param string $text Plain text to count.
	 * @return int
	 */
	function webmcp_gateway_word_count( $text ) {
		$text = (string) $text;
		if ( '' === $text ) {
			return 0;
		}
		if ( function_exists( 'preg_match_all' ) ) {
			preg_match_all( '/[\p{L}\p{N}]+/u', $text, $matches );
			return isset( $matches[0] ) ? count( $matches[0] ) : 0;
		}
		return count( preg_split( '/\s+/', trim( $text ) ) );
	}
}

if ( ! function_exists( 'webmcp_gateway_bootstrap' ) ) {
	/**
	 * Bootstrap the WebMCP Gateway plugin safely on plugins_loaded.
	 *
	 * @return void
	 */
	function webmcp_gateway_bootstrap() {
		WebMCP_Gateway_Core::instance()->run();
	}
	add_action( 'plugins_loaded', 'webmcp_gateway_bootstrap', 20 );
}

if ( ! function_exists( 'webmcp_gateway_maybe_upgrade' ) ) {
	/**
	 * Flush rewrite rules once after a plugin update so newly added discovery
	 * endpoints (e.g. /.well-known aliases) route without a manual re-activation.
	 *
	 * @return void
	 */
	function webmcp_gateway_maybe_upgrade() {
		$installed = (string) get_option( 'webmcp_gateway_installed_version', '' );
		if ( WEBMCP_CORE_VERSION === $installed ) {
			return;
		}

		// Any version change invalidates the previous audit report: views must
		// never display numbers produced by an older build.
		delete_transient( 'webmcp_gateway_audit_cache' );

		if ( class_exists( 'WebMCP_Gateway_LlmsTxt' ) ) {
			WebMCP_Gateway_LlmsTxt::add_rewrite_rules();
		}
		if ( class_exists( 'WebMCP_Gateway_Well_Known' ) ) {
			WebMCP_Gateway_Well_Known::add_rewrite_rules();
		}
		flush_rewrite_rules();
		update_option( 'webmcp_gateway_installed_version', WEBMCP_CORE_VERSION, false );
	}
	add_action( 'admin_init', 'webmcp_gateway_maybe_upgrade', 5 );
}

if ( ! function_exists( 'webmcp_gateway_activate' ) ) {
	/**
	 * Activation hook: seed default options and register rewrite endpoints safely.
	 *
	 * @return void
	 */
	function webmcp_gateway_activate() {
		WebMCP_Gateway_Core::load_dependencies();

		$defaults = webmcp_gateway_default_options();
		foreach ( $defaults as $key => $val ) {
			if ( false === get_option( $key, false ) ) {
				add_option( $key, $val );
			}
		}

		if ( class_exists( 'WebMCP_Gateway_LlmsTxt' ) ) {
			WebMCP_Gateway_LlmsTxt::add_rewrite_rules();
		}
		if ( class_exists( 'WebMCP_Gateway_Well_Known' ) ) {
			WebMCP_Gateway_Well_Known::add_rewrite_rules();
		}
		flush_rewrite_rules();
	}
	register_activation_hook( __FILE__, 'webmcp_gateway_activate' );
}

if ( ! function_exists( 'webmcp_gateway_deactivate' ) ) {
	/**
	 * Deactivation hook: flush rewrite rules cleanly.
	 *
	 * @return void
	 */
	function webmcp_gateway_deactivate() {
		flush_rewrite_rules();
	}
	register_deactivation_hook( __FILE__, 'webmcp_gateway_deactivate' );
}

// Translations for the webmcp-gateway text domain are loaded automatically by
// WordPress.org (since WP 4.6). Do not call load_plugin_textdomain() here.
