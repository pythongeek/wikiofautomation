(function ($) {
    'use strict';

    window.DirectRelay = window.DirectRelay || {};

    $(function () {

        // Safety check to ensure the localization script loaded
        if (!window.directrelayAdmin || !window.directrelayAdmin.ajaxUrl) {
            console.warn('DirectRelay: Localization object is missing or incomplete.');
        }

        function escapeHtml(str) {
            if (!str) return '';
            return String(str)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        /* —— Toast ————————————————————————————————————————————————————— */
        $('head').append('<style>.directrelay-toast{position:fixed;bottom:24px;right:24px;padding:11px 18px;border-radius:8px;font-size:13px;font-weight:600;opacity:0;z-index:999999;max-width:340px;box-shadow:0 8px 30px rgba(0,0,0,.4);transition:opacity .3s;pointer-events:none}.directrelay-toast.show{opacity:1}.directrelay-toast-success{background:#22c55e;color:#fff}.directrelay-toast-error{background:#ef4444;color:#fff}.directrelay-toast-info{background:#28CCCD;color:#0f1117}</style>');
        function toast(msg, type) {
            type = type || 'success';
            var el = $('<div class="directrelay-toast directrelay-toast-' + type + '"></div>').text(msg).appendTo('body');
            setTimeout(function(){ el.addClass('show'); }, 10);
            setTimeout(function(){ el.removeClass('show'); setTimeout(function(){ el.remove(); }, 300); }, 3200);
        }

        /* —— Scope Presets ————————————————————————————————————————————— */
        $(document).on('click', '.directrelay-preset-btn', function (e) {
            e.preventDefault();
            $('.directrelay-preset-btn').removeClass('active');
            $(this).addClass('active');
            var preset = $(this).data('preset');
            var $checks = $('[name="scopes[]"]');
            if (preset === 'full_access') {
                $checks.prop('checked', true);
                return;
            }
            var scopes = (directrelayAdmin.presets && directrelayAdmin.presets[preset]) ? directrelayAdmin.presets[preset] : [];
            $checks.prop('checked', false);
            $checks.each(function () {
                if (scopes.indexOf($(this).val()) !== -1) {
                    $(this).prop('checked', true);
                }
            });
        });

        // Deactivate presets if user customizes checkboxes
        $(document).on('change', '[name="scopes[]"]', function () {
            $('.directrelay-preset-btn').removeClass('active');
        });

        /* ── API Key Setup Wizard Navigation ────────────────────────── */
        var currentStep = 1;
        
        function updateWizard() {
            // Panels
            $('.directrelay-wizard-step-panel').removeClass('active');
            $('#directrelay-step-panel-' + currentStep).addClass('active');
            
            // Step Indicators
            $('.directrelay-wizard-step-item').each(function() {
                var step = parseInt($(this).data('step'), 10);
                if (step < currentStep) {
                    $(this).addClass('completed').removeClass('active');
                } else if (step === currentStep) {
                    $(this).addClass('active').removeClass('completed');
                } else {
                    $(this).removeClass('active completed');
                }
            });
            
            // Buttons
            if (currentStep === 1) {
                $('#directrelay-wizard-prev').hide();
                $('#directrelay-wizard-next').show();
                $('#directrelay-create-key-btn').hide();
            } else if (currentStep === 2) {
                $('#directrelay-wizard-prev').show();
                $('#directrelay-wizard-next').show();
                $('#directrelay-create-key-btn').hide();
            } else if (currentStep === 3) {
                $('#directrelay-wizard-prev').show();
                $('#directrelay-wizard-next').hide();
                $('#directrelay-create-key-btn').show();
            }
        }
        
        $(document).on('click', '#directrelay-wizard-next', function(e) {
            e.preventDefault();
            if (currentStep === 1) {
                var labelInput = document.getElementById('directrelay-key-label');
                if (labelInput && !labelInput.checkValidity()) {
                    labelInput.reportValidity();
                    return;
                }
            }
            if (currentStep < 3) {
                currentStep++;
                updateWizard();
            }
        });
        
        $(document).on('click', '#directrelay-wizard-prev', function(e) {
            e.preventDefault();
            if (currentStep > 1) {
                currentStep--;
                updateWizard();
            }
        });
        
        /* ── Environment Selector ─────────────────────────────────── */
        $(document).on('click', '.directrelay-env-card', function(e) {
            e.preventDefault();
            var env = $(this).data('env');
            $('#directrelay-key-env').val(env);
            $('.directrelay-env-card').removeClass('active');
            $(this).addClass('active');
        });
        
        /* ── Toggle All Category Permissions ─────────────────────── */
        $(document).on('click', '.directrelay-toggle-all-group', function(e) {
            e.preventDefault();
            var $card = $(this).closest('.directrelay-scope-category-card');
            var $checks = $card.find('input[type="checkbox"]');
            var total = $checks.length;
            var checked = $checks.filter(':checked').length;
            
            if (checked < total) {
                $checks.prop('checked', true);
            } else {
                $checks.prop('checked', false);
            }
            // Deactivate presets since the checkboxes changed
            $('.directrelay-preset-btn').removeClass('active');
        });

        /* —— Create Key ———————————————————————————————————————————————— */
        $(document).on('submit', '#directrelay-create-key-form', function (e) {
            e.preventDefault(); 
            var $form = $(this);
            var $btn  = $('#directrelay-create-key-btn').prop('disabled', true).text('Generating…');
            var scopes = $('[name="scopes[]"]:checked').map(function () { return $(this).val(); }).get();
            
            var payload = {
                action: 'directrelay_create_key',
                nonce: directrelayAdmin.nonce,
                label: $('[name=label]').val(),
                description: $('[name=description]').val(),
                environment: $('#directrelay-key-env').val(),
                agent_role: $('[name=agent_role]').val() || 'full_access',
                daily_limit: $('[name=daily_limit]').val() || '0',
                require_approval: $('[name=require_approval]').is(':checked') ? 1 : 0,
                restrict_own_posts: $('[name=restrict_own_posts]').is(':checked') ? 1 : 0,
                expires_at: $('[name=expires_at]').val(),
                ip_whitelist: $('[name=ip_whitelist]').val(),
                scopes: scopes,
                preset: $('.directrelay-preset-btn.active').data('preset') || '',
            };

            $.post(directrelayAdmin.ajaxUrl, payload)
            .done(function (res) {
                if (res.success) {
                    var raw = res.data.raw_key;
                    $('#directrelay-raw-key').text(raw);
                    $('#directrelay-n8n-val').text('Bearer ' + raw);
                    $('#directrelay-confirm-saved').prop('checked', false);
                    $('#directrelay-dismiss-key').prop('disabled', true);
                    $('#directrelay-new-key-result').slideDown(250);
                    $form[0].reset();
                    $('[name="scopes[]"]').prop('checked', false);
                    
                    // Reset wizard to step 1
                    currentStep = 1;
                    updateWizard();
                    $('.directrelay-env-card').removeClass('active');
                    $('.directrelay-env-card[data-env="production"]').addClass('active');
                    $('#directrelay-key-env').val('production');

                    toast('API key created.', 'success');
                    $('html,body').animate({ scrollTop: $('#directrelay-new-key-result').offset().top - 80 }, 400);
                } else { 
                    toast((res.data && res.data.message) || 'Error', 'error'); 
                }
            }).fail(function () { 
                toast('Request failed.', 'error');
            }).always(function () { 
                $btn.prop('disabled', false).text('Generate API Key'); 
            });
        });

        /* —— Dismiss new key ———————————————————————————————————————————— */
        $(document).on('change', '#directrelay-confirm-saved', function () {
            $('#directrelay-dismiss-key').prop('disabled', !this.checked);
        });
        $(document).on('click', '#directrelay-dismiss-key', function (e) {
            e.preventDefault();
            $('#directrelay-new-key-result').slideUp();
            setTimeout(function () { location.reload(); }, 200);
        });

        /* —— Collapsible Create Key Card ————————————————————————————————— */
        $(document).on('click', '.directrelay-create-key-toggle', function (e) {
            e.preventDefault();
            var $wrap = $('#directrelay-create-key-form-wrap');
            var expanded = $(this).attr('aria-expanded') === 'true';
            $(this).attr('aria-expanded', !expanded);
            $wrap.slideToggle(250);
        });

        /* —— Advanced Settings Toggle ——————————————————————————————————— */
        $(document).on('click', '.directrelay-advanced-toggle', function (e) {
            e.preventDefault();
            var $body = $('#directrelay-advanced-fields');
            var expanded = $(this).attr('aria-expanded') === 'true';
            $(this).attr('aria-expanded', !expanded);
            $body.slideToggle(200);
        });

        /* —— Copy buttons —————————————————————————————————————————————— */
        $(document).on('click', '.directrelay-copy-btn', function (e) {
            e.preventDefault();
            var target = $(this).data('target');
            var $el = $('#' + target);
            var text = ($el.is('textarea, input') ? $el.val() : $el.text()).trim();
            var $btn = $(this);
            if (navigator.clipboard) {
                navigator.clipboard.writeText(text).then(function () {
                    var orig = $btn.text();
                    $btn.text('✅ Copied!');
                    setTimeout(function () { $btn.text(orig); }, 2000);
                }).catch(function () { prompt('Copy:', text); });
            } else { prompt('Copy:', text); }
        });

        /* —— Revoke key ———————————————————————————————————————————————— */
        $(document).on('click', '.directrelay-revoke-btn', function (e) {
            e.preventDefault();
            var $btn = $(this), id = $btn.data('id'), label = $btn.data('label');
            if (!confirm('Revoke "' + label + '"? This cannot be undone.')) return;
            $btn.prop('disabled', true).text('Revoking…');
            $.post(directrelayAdmin.ajaxUrl, { action: 'directrelay_revoke_key', nonce: directrelayAdmin.nonce, key_id: id })
                .done(function (res) {
                    if (res.success) {
                        $btn.closest('.directrelay-key-row').addClass('directrelay-row-revoked');
                        $btn.closest('td').html('<span class="directrelay-badge directrelay-badge-revoked">Revoked</span>');
                        toast('Key revoked.', 'info');
                    } else { toast('Failed.', 'error'); $btn.prop('disabled', false).text('Revoke'); }
                }).fail(function () { toast('Failed.', 'error'); $btn.prop('disabled', false).text('Revoke'); });
        });

        /* —— Show revoked toggle ———————————————————————————————————————— */
        $(document).on('change', '#directrelay-show-revoked', function () {
            this.checked ? $('.directrelay-row-revoked').show() : $('.directrelay-row-revoked').hide();
        });

        /* —— Search API Keys ————————————————————————————————————————————— */
        $(document).on('input', '#directrelay-key-search', function () {
            var q = $(this).val().toLowerCase();
            $('.directrelay-key-row').each(function () {
                var label = $(this).data('label') || '';
                $(this).toggle(label.indexOf(q) !== -1);
            });
        });

        /* —— Search Webhooks ———————————————————————————————————————————— */
        $(document).on('input', '#directrelay-wh-search', function () {
            var q = $(this).val().toLowerCase();
            $('[data-id]').each(function () {
                var label = $(this).data('label') || '';
                var row = $(this).closest('tr').length ? $(this).closest('tr') : $(this);
                row.toggle(label.indexOf(q) !== -1);
            });
        });

        /* —— Settings form —————————————————————————————————————————————— */
        $(document).on('submit', '#directrelay-settings-form', function (e) {
            e.preventDefault();
            var $btn = $(this).find('[type=submit]').prop('disabled', true).text('Saving…');
            var $st  = $('#directrelay-save-status');
            var formData = $(this).serializeArray();
            var data = { action: 'directrelay_save_settings', nonce: directrelayAdmin.nonce };
            $.each(formData, function(i, field){
                data[field.name] = field.value;
            });
            // Checkboxes
            $(this).find('input[type=checkbox]').each(function(){
                data[this.name] = this.checked ? 1 : 0;
            });

            $.post(directrelayAdmin.ajaxUrl, data).done(function (res) {
                if (res.success) { $st.html('<span style="color:var(--directrelay-green);font-weight:600">✓ Saved</span>'); toast('Settings saved.', 'success'); }
                else { $st.html('<span style="color:var(--directrelay-red)">Error</span>'); }
            }).fail(function () { $st.html('<span style="color:var(--directrelay-red)">Failed</span>'); }
            ).always(function () { $btn.prop('disabled', false).text('Save Settings'); setTimeout(function(){ $st.html(''); }, 3000); });
        });

        /* —— Load Webhook Preset —————————————————————————————————————— */
        $(document).on('click', '.directrelay-load-preset', function (e) {
            e.preventDefault();
            var $btn   = $(this);
            var isPro  = $btn.data('ispro') === 1 || $btn.data('ispro') === '1';
            var label  = $btn.data('label');
            var events = $btn.data('events') || [];
            var types  = $btn.data('types') || [];

            if (!isPro) {
                toast('This preset requires DirectRelay Pro. Activate your license to unlock full multi-event pipelines.', 'error');
                return;
            }

            $('#directrelay-wh-label-input').val(label);

            // Set events
            $('[name="events[]"]').prop('checked', false);
            $.each(events, function (i, ev) {
                $('[name="events[]"][value="' + ev + '"]').prop('checked', true);
            });

            // Set post types
            $('[name="post_types[]"]').prop('checked', false);
            $.each(types, function (i, pt) {
                $('[name="post_types[]"][value="' + pt + '"]').prop('checked', true);
            });

            toast('Preset "' + label + '" loaded into form!', 'success');
            if ($('#directrelay-webhook-form-card').length) {
                $('html, body').animate({ scrollTop: $('#directrelay-webhook-form-card').offset().top - 80 }, 400);
                $('#directrelay-wh-url-input').focus();
            }
        });

        /* —— Create Webhook ———————————————————————————————————————————— */
        $(document).on('submit', '#directrelay-create-webhook-form', function (e) {
            e.preventDefault();
            var $btn = $(this).find('[type=submit]').prop('disabled', true).text('Registering…');
            var events = $('[name="events[]"]:checked').map(function () { return $(this).val(); }).get();
            var types  = $('[name="post_types[]"]:checked').map(function () { return $(this).val(); }).get();
            $.post(directrelayAdmin.ajaxUrl, {
                action: 'directrelay_create_webhook', nonce: directrelayAdmin.nonce,
                label: $('[name=label]').val(), target_url: $('[name=target_url]').val(),
                secret: $('[name=secret]').val(), events: events, post_types: types,
            }).done(function (res) {
                if (res.success) { toast('Webhook registered.', 'success'); setTimeout(function(){ location.reload(); }, 600); }
                else { toast((res.data && res.data.message) || 'Error', 'error'); $btn.prop('disabled', false).text('Register Webhook'); }
            }).fail(function () { toast('Failed.', 'error'); $btn.prop('disabled', false).text('Register Webhook'); });
        });

        /* —— Toggle webhook active —————————————————————————————————————— */
        $(document).on('click', '.directrelay-toggle-wh', function (e) {
            e.preventDefault();
            var $btn = $(this).prop('disabled', true), next = $btn.data('active') ? 1 : 0;
            $.post(directrelayAdmin.ajaxUrl, { action: 'directrelay_toggle_webhook', nonce: directrelayAdmin.nonce, id: $btn.data('id'), active: next })
                .done(function (res) {
                    if (res.success) { toast(next ? 'Webhook enabled.' : 'Webhook disabled.', 'info'); setTimeout(function () { location.reload(); }, 500); }
                    else { toast((res.data && res.data.message) || 'Error', 'error'); $btn.prop('disabled', false); }
                })
                .fail(function () { toast('Failed.', 'error'); $btn.prop('disabled', false); });
        });

        /* —— Delete webhook ———————————————————————————————————————————— */
        $(document).on('click', '.directrelay-delete-wh', function (e) {
            e.preventDefault();
            var id = $(this).data('id');
            if (!confirm('Delete this webhook?')) return;
            $.post(directrelayAdmin.ajaxUrl, { action: 'directrelay_delete_webhook', nonce: directrelayAdmin.nonce, id: id })
                .done(function (res) {
                    if (res.success) { $('[data-id=' + id + ']').closest('tr').fadeOut(300, function(){ $(this).remove(); }); toast('Deleted.', 'info'); }
                });
        });

        /* —— Test webhook —————————————————————————————————————————————— */
        $(document).on('click', '.directrelay-test-wh', function (e) {
            e.preventDefault();
            var id = $(this).data('id'), $mo = $('#directrelay-test-modal'), $res = $('#directrelay-test-result');
            $res.css('color', 'var(--directrelay-muted)').text('Sending test…');
            $mo.show();
            $.post(directrelayAdmin.ajaxUrl, { action: 'directrelay_test_webhook', nonce: directrelayAdmin.nonce, id: id })
                .done(function (res) {
                    if (res.success) {
                        var ok = res.data.success;
                        $res.css('color', ok ? 'var(--directrelay-green)' : 'var(--directrelay-red)').text(JSON.stringify(res.data, null, 2));
                        toast(ok ? 'Test delivered (HTTP ' + res.data.status + ')' : 'Test failed.', ok ? 'success' : 'error');
                    } else { $res.css('color', 'var(--directrelay-red)').text(JSON.stringify(res.data, null, 2)); }
                }).fail(function () { $res.css('color', 'var(--directrelay-red)').text('AJAX request failed.'); });
        });

        /* —— Modal close ———————————————————————————————————————————————— */
        $(document).on('click', '.directrelay-modal-close', function (e) { e.preventDefault(); $(this).closest('.directrelay-modal-overlay').hide(); });
        $(document).on('keydown', function (e) { if (e.key === 'Escape') $('.directrelay-modal-overlay').hide(); });
        $(document).on('click', '.directrelay-modal-overlay', function (e) { if ($(e.target).is(this)) $(this).hide(); });

        /* —— Run System Diagnostic ————————————————————————————————————— */
        $(document).on('click', '#directrelay-run-diag-btn', function (e) {
            e.preventDefault();
            var $btn = $(this).prop('disabled', true).text('Running Diagnostics…');
            $('#directrelay-diag-placeholder').hide();
            $('#directrelay-diag-results').show();
            $('#directrelay-diag-grid').html('<div style="grid-column:1/-1;text-align:center;padding:24px;color:var(--directrelay-muted)">⏳ Running 5 live diagnostic checks…</div>');

            $.post(directrelayAdmin.ajaxUrl, { action: 'directrelay_run_diagnostics', nonce: directrelayAdmin.nonce })
                .done(function (res) {
                    $btn.prop('disabled', false).html('⚡ Run System Diagnostic');
                    if (res.success && res.data) {
                        var html = '';
                        $.each(res.data, function (key, item) {
                            var icon = item.status === 'pass' ? '✅' : (item.status === 'warn' ? '⚠️' : '❌');
                            var badgeClass = item.status === 'pass' ? 'directrelay-badge-active' : (item.status === 'warn' ? 'directrelay-badge-warn' : 'directrelay-badge-revoked');
                            var badgeText = item.status === 'pass' ? 'PASS' : (item.status === 'warn' ? 'WARNING' : 'FAIL');
                            
                            html += '<div style="background:var(--directrelay-card2);border:1px solid var(--directrelay-border);border-radius:8px;padding:14px;">';
                            html += '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">';
                            html += '<strong style="font-size:13px;color:var(--directrelay-text);display:flex;align-items:center;gap:6px">' + icon + ' ' + item.title + '</strong>';
                            html += '<span class="directrelay-badge ' + badgeClass + '">' + badgeText + '</span>';
                            html += '</div>';
                            html += '<div style="font-size:12px;color:var(--directrelay-muted);line-height:1.4">' + item.message + '</div>';
                            html += '</div>';
                        });
                        $('#directrelay-diag-grid').html(html);
                        toast('System diagnostics complete.', 'success');
                    } else {
                        $('#directrelay-diag-grid').html('<div style="grid-column:1/-1;color:var(--directrelay-red);padding:16px">Failed to execute diagnostics.</div>');
                    }
                })
                .fail(function () {
                    $btn.prop('disabled', false).html('⚡ Run System Diagnostic');
                    $('#directrelay-diag-grid').html('<div style="grid-column:1/-1;color:var(--directrelay-red);padding:16px">Diagnostic request failed.</div>');
                });
        });

        /* —— Rotate Key ———————————————————————————————————————————————— */
        $(document).on('click', '.directrelay-rotate-btn', function (e) {
            e.preventDefault();
            var $btn = $(this), id = $btn.data('id'), label = $btn.data('label');
            if (!confirm('Rotate key "' + label + '"?\n\nThe old key stops working immediately. A new key will be shown once — save it before dismissing.')) return;
            $btn.prop('disabled', true).text('Rotating…');
            $.post(directrelayAdmin.ajaxUrl, { action: 'directrelay_rotate_key', nonce: directrelayAdmin.nonce, key_id: id })
                .done(function (res) {
                    if (res.success) {
                        var raw = res.data.raw_key;
                        var $box = $('<div class="directrelay-new-key-box" style="margin-top:12px"></div>');
                        $box.append('<div class="directrelay-new-key-header">✅ Key Rotated — New Key:</div>');
                        
                        var $row1 = $('<div class="directrelay-key-display-row"></div>');
                        var $code1 = $('<code id="directrelay-rotated-key-' + id + '"></code>').text(raw);
                        var $btnCopy1 = $('<button class="directrelay-btn directrelay-btn-ghost directrelay-copy-btn">📋 Copy</button>').attr('data-target', 'directrelay-rotated-key-' + id);
                        $row1.append($code1).append($btnCopy1);
                        
                        var $row2 = $('<div class="directrelay-key-display-row" style="margin-top:8px"></div>');
                        $row2.append('<span style="font-size:12px;color:var(--directrelay-muted)">n8n value:</span>');
                        var $code2 = $('<code id="directrelay-rotated-n8n-' + id + '"></code>').text('Bearer ' + raw);
                        var $btnCopy2 = $('<button class="directrelay-btn directrelay-btn-ghost directrelay-copy-btn">📋 Copy</button>').attr('data-target', 'directrelay-rotated-n8n-' + id);
                        $row2.append($code2).append($btnCopy2);
                        
                        $box.append($row1).append($row2);
                        $box.append('<p style="font-size:12px;color:var(--directrelay-yellow);margin-top:8px">⚠️ Update your n8n credential immediately.</p>');
                        
                        var $tr = $btn.closest('tr');
                        $tr.find('td:last').prepend($box);
                        $tr.find('.directrelay-key-prefix').text(res.data.prefix + '…');
                        $btn.remove();
                    } else {
                        alert('Rotate failed: ' + (res.data && res.data.message ? res.data.message : 'Unknown error'));
                        $btn.prop('disabled', false).text('Rotate');
                    }
                }).fail(function () {
                    alert('Request failed.');
                    $btn.prop('disabled', false).text('Rotate');
                });
        });

        /* —— Clear Logs ———————————————————————————————————————————————— */
        $(document).on('click', '#directrelay-clear-logs-btn', function (e) {
            e.preventDefault();
            if (!confirm('Are you sure you want to delete ALL activity and delivery logs? This cannot be undone.')) return;
            var $btn = $(this).prop('disabled', true).text('Clearing...');
            $.post(directrelayAdmin.ajaxUrl, { action: 'directrelay_clear_logs', nonce: directrelayAdmin.nonce })
                .done(function (res) {
                    if (res.success) { toast('Logs cleared.', 'info'); setTimeout(function(){ location.reload(); }, 600); }
                    else { toast('Clear failed.', 'error'); $btn.prop('disabled', false).text('Clear All Logs'); }
                }).fail(function () { toast('Failed.', 'error'); $btn.prop('disabled', false).text('Clear All Logs'); });
        });

        /* —— Unblock IP (Settings) —————————————————————————————————————— */
        $(document).on('click', '.directrelay-unblock', function() {
            var ip = $(this).data('ip');
            if (!ip) return;
            if (!confirm('Unblock ' + ip + '?')) return;
            var $btn = $(this).prop('disabled', true);
            $.post(directrelayAdmin.ajaxUrl, { action: 'directrelay_unblock_ip', nonce: directrelayAdmin.nonce, ip: ip }).done(function(r) {
                if (r && r.success) { toast('IP unblocked.', 'success'); setTimeout(function() { location.reload(); }, 600); }
                else { toast('Unblock failed.', 'error'); $btn.prop('disabled', false); }
            }).fail(function() { toast('Unblock failed.', 'error'); $btn.prop('disabled', false); });
        });

        /* —— Manually Block IP (Settings) ——————————————————————————————————— */
        $(document).on('click', '#directrelay-block-ip-btn', function() {
            var $input = $('#directrelay-block-ip-input');
            var $btn   = $(this);
            var ip     = ($input.val() || '').trim();
            if (!ip) { toast('Enter an IP address or CIDR first.', 'error'); $input.focus(); return; }
            $btn.prop('disabled', true);
            $.post(directrelayAdmin.ajaxUrl, {
                action: 'directrelay_block_ip',
                nonce:  directrelayAdmin.nonce,
                ip:     ip
            }).done(function(r) {
                if (r && r.success) {
                    toast('IP blocked.', 'success');
                    setTimeout(function() { location.reload(); }, 600);
                } else {
                    toast((r && r.data && r.data.message) || 'Block failed.', 'error');
                    $btn.prop('disabled', false);
                }
            }).fail(function() { toast('Block failed.', 'error'); $btn.prop('disabled', false); });
        });

        /* —— n8n Download ————————————————————————————————————————————— */
        $(document).on('click', '#directrelay-download-n8n', function (e) {
            e.preventDefault();
            var config = {
                name: 'DirectRelay @ ' + window.location.hostname,
                api_url: directrelayAdmin.apiBase,
                site_url: window.location.origin,
                instructions: 'Add this to your n8n Global Variables or use in HTTP Request nodes.',
                timestamp: new Date().toISOString()
            };
            var blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
            var url  = window.URL.createObjectURL(blob);
            var a    = document.createElement('a');
            a.href     = url;
            a.download = 'directrelay-config.json';
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
            toast('Config downloaded.', 'success');
        });

        /* —— Charts (Dashboard) ————————————————————————————————————————
         * Chart.js rendering moved to the directrelay-pro plugin. The free
         * plugin dashboard now shows a plain text status summary.
         */
        if (typeof window.Chart !== 'undefined' && directrelayAdmin.chart) {
            $(document).on('directrelay_pro_render_charts', function(e, cData) {
                if (typeof window.Chart === 'undefined' || !cData) return;
                var cOpts = {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: { intersect: false, mode: 'index' },
                    plugins: {
                        legend: { labels: { color: 'rgba(255,255,255,.7)', font: { size: 11 } } },
                        tooltip: { backgroundColor: '#1a1f36', titleColor: '#fff', bodyColor: 'rgba(255,255,255,.8)', borderColor: 'rgba(40,204,205,.3)', borderWidth: 1 }
                    },
                    scales: {
                        x: { ticks: { color: 'rgba(255,255,255,.5)', font: { size: 10 }, maxTicksLimit: 12 }, grid: { color: 'rgba(255,255,255,.05)' } },
                        y: { ticks: { color: 'rgba(255,255,255,.5)', font: { size: 11 } }, grid: { color: 'rgba(255,255,255,.05)' }, beginAtZero: true }
                    }
                };
                var labs = cData.hourly.map(function(r) { return r.bucket_hour.slice(11, 16); });
                var rc = document.getElementById('directrelay-req-chart');
                if (rc) {
                    window.ampReqChart = new Chart(rc, {
                        type: 'bar',
                        data: { labels: labs, datasets: [
                            { label: 'Requests', data: cData.hits, backgroundColor: 'rgba(40,204,205,.6)', borderColor: '#28CCCD', borderWidth: 1, borderRadius: 3 },
                            { label: 'Errors', data: cData.errs, backgroundColor: 'rgba(239,68,68,.5)', borderColor: '#ef4444', borderWidth: 1, borderRadius: 3 }
                        ] },
                        options: cOpts
                    });
                }
                var mc = document.getElementById('directrelay-ms-chart');
                if (mc) {
                    window.ampMsChart = new Chart(mc, {
                        type: 'line',
                        data: { labels: labs, datasets: [
                            { label: 'Avg ms', data: cData.ms, fill: true, backgroundColor: 'rgba(199,125,255,.15)', borderColor: '#c77dff', borderWidth: 2, pointBackgroundColor: '#c77dff', pointRadius: 2, tension: .4 }
                        ] },
                        options: cOpts
                    });
                }
                $(document).on('click', '.directrelay-chart-btn', function() {
                    $('.directrelay-chart-btn').removeClass('active');
                    $(this).addClass('active');
                });
            });
            // Trigger Pro-side chart rendering if the plugin is active.
            $(document).trigger('directrelay_pro_render_charts', [directrelayAdmin.chart]);
        }

        /* —— Realtime Live Stats & Widget Polling (Dashboard) ————————— */
        function initDashboardRealtime() {
            var $indicator = $('#directrelay-live-indicator');
            if (!$indicator.length) return;

            var isPolling = false;
            var pollInterval = 10000; // 10 seconds

            function updateStat(id, newVal) {
                var $el = $('#' + id);
                if ($el.length && $el.text().trim() !== String(newVal).trim()) {
                    $el.css({ transition: 'color .3s, transform .2s', transform: 'scale(1.08)', color: 'var(--directrelay-primary)' });
                    $el.text(newVal);
                    setTimeout(function() {
                        $el.css({ transform: 'scale(1)', color: '' });
                    }, 400);
                }
            }

            function fetchLiveStats() {
                if (isPolling || document.hidden) return;
                isPolling = true;

                $.post(directrelayAdmin.ajaxUrl, {
                    action: 'directrelay_get_dashboard_realtime_stats',
                    nonce: directrelayAdmin.nonce
                }).done(function(res) {
                    if (!res.success || !res.data) return;
                    var d = res.data;

                    // 1. Update top summary stat cards
                    if (d.summary) {
                        updateStat('stat-val-requests_today', d.summary.requests_today);
                        updateStat('stat-val-requests_week', d.summary.requests_week);
                        updateStat('stat-val-errors_24h', d.summary.errors_24h);
                        updateStat('stat-val-avg_response_ms', d.summary.avg_response_ms);
                        updateStat('stat-val-active_keys', d.summary.active_keys);
                    }

                    // 2. Update free tier stats
                    if (d.free_usage) {
                        updateStat('free-stat-used', (d.free_usage.used || 0).toLocaleString() + ' / 5,000');
                        updateStat('free-stat-remaining', (d.free_usage.remaining || 0).toLocaleString());
                        if (d.summary) {
                            updateStat('free-stat-keys', d.summary.active_keys + ' / 1');
                        }
                    }

                    // 3. Update Active API Keys table
                    if (d.keys && d.keys.length) {
                        var $tbody = $('#directrelay-dashboard-keys-body');
                        var $table = $('#directrelay-dashboard-keys-table');
                        var $empty = $('#directrelay-keys-empty');

                        if ($empty.length) $empty.hide();
                        if ($table.length) $table.show();

                        if ($tbody.length) {
                            var rowsHtml = '';
                            $.each(d.keys, function(i, k) {
                                rowsHtml += '<tr data-key-id="' + escapeHtml(k.id) + '">';
                                rowsHtml += '<td><code class="directrelay-key-prefix">' + escapeHtml(k.key_prefix) + '</code></td>';
                                rowsHtml += '<td><span class="directrelay-env-dot directrelay-env-' + escapeHtml(k.environment) + '"></span><span class="key-label">' + escapeHtml(k.label) + '</span></td>';
                                rowsHtml += '<td class="key-col-requests"><strong>' + Number(k.total_requests || 0).toLocaleString() + '</strong></td>';
                                rowsHtml += '<td class="key-col-lastused"><small>' + escapeHtml(k.last_used_human || 'Never') + '</small></td>';
                                rowsHtml += '</tr>';
                            });
                            $tbody.html(rowsHtml);
                        }
                    }

                    // 4. Update Top Endpoints table
                    if (d.top_endpoints && d.top_endpoints.length) {
                        var $epTbody = $('#directrelay-dashboard-top-endpoints-body');
                        var $epTable = $('#directrelay-dashboard-top-endpoints-table');
                        var $epEmpty = $('#directrelay-top-endpoints-empty');

                        if ($epEmpty.length) $epEmpty.hide();
                        if ($epTable.length) $epTable.show();

                        if ($epTbody.length) {
                            var epRowsHtml = '';
                            $.each(d.top_endpoints, function(i, ep) {
                                var methodCls = (ep.method || 'get').toLowerCase();
                                epRowsHtml += '<tr>';
                                epRowsHtml += '<td><code>' + escapeHtml(ep.endpoint) + '</code></td>';
                                epRowsHtml += '<td><span class="directrelay-method directrelay-method-' + escapeHtml(methodCls) + '">' + escapeHtml(ep.method) + '</span></td>';
                                epRowsHtml += '<td><strong>' + Number(ep.hits || 0).toLocaleString() + '</strong></td>';
                                epRowsHtml += '<td>' + escapeHtml(ep.avg_ms || '') + '</td>';
                                epRowsHtml += '</tr>';
                            });
                            $epTbody.html(epRowsHtml);
                        }
                    }

                    // 5. Update Charts (Pro only)
                    if (d.hourly && window.ampReqChart && window.ampMsChart) {
                        var labs = d.hourly.map(function(r) { return r.bucket_hour.slice(11, 16); });
                        window.ampReqChart.data.labels = labs;
                        window.ampReqChart.data.datasets[0].data = d.hits;
                        window.ampReqChart.data.datasets[1].data = d.errs;
                        window.ampReqChart.update('none');
                        window.ampMsChart.data.labels = labs;
                        window.ampMsChart.data.datasets[0].data = d.ms;
                        window.ampMsChart.update('none');
                    }
                }).always(function() {
                    isPolling = false;
                });
            }

            // Start auto polling
            setInterval(fetchLiveStats, pollInterval);

            // Fetch on tab visibility change
            document.addEventListener('visibilitychange', function() {
                if (!document.hidden) {
                    fetchLiveStats();
                }
            });
        }

        initDashboardRealtime();

        /* —— Webhook Deliveries (Webhooks) —————————————————————————————— */
        $(document).on('click', '.directrelay-view-log', function() {
            var id = $(this).data('id'), label = $(this).data('label');
            $('#directrelay-deliveries-modal .directrelay-modal-title').text('Deliveries — ' + label);
            $('#directrelay-delivery-count').text('');
            $('#directrelay-deliveries-modal').show();
            $('#directrelay-delivery-log').html('<p class="directrelay-empty">Loading...</p>');
            $.ajax({
                url: directrelayAdmin.apiBase + '/webhooks/' + id + '/deliveries',
                headers: { 'X-WP-Nonce': directrelayAdmin.restNonce },
                success: function(r) {
                    var rows = r.data ? r.data.deliveries : r.deliveries;
                    if (!rows || !rows.length) { $('#directrelay-delivery-log').html('<p class="directrelay-empty">No deliveries yet for ' + $('<b>').text(label).prop('outerHTML') + '.</p>'); return; }
                    $('#directrelay-delivery-count').text(rows.length);
                    var html = '<table class="directrelay-table widefat"><thead><tr><th>Time</th><th>Event</th><th>Attempt</th><th>Status</th><th>Duration</th><th>Error</th></tr></thead><tbody>';
                    rows.forEach(function(row) {
                        var ok = row.http_status >= 200 && row.http_status < 300;
                        html += '<tr><td><small>' + escapeHtml(row.created_at.slice(0, 19)) + '</small></td>';
                        html += '<td><code style="font-size:11px">' + escapeHtml(row.event) + '</code></td>';
                        html += '<td style="text-align:center">' + escapeHtml(row.attempt) + '</td>';
                        html += '<td><span class="directrelay-http-status ' + (ok ? 'directrelay-2xx' : 'directrelay-4xx') + '">' + escapeHtml(row.http_status || '') + '</span></td>';
                        html += '<td><small>' + escapeHtml(row.duration_ms ? row.duration_ms + 'ms' : '') + '</small></td>';
                        html += '<td><small style="color:var(--directrelay-red)">' + escapeHtml(row.error_message || '') + '</small></td></tr>';
                    });
                    html += '</tbody></table>';
                    $('#directrelay-delivery-log').html(html);
                },
                error: function() { $('#directrelay-delivery-log').html('<p class="directrelay-empty">Could not load delivery log.</p>'); }
            });
        });

        /* UI mode toggle removed. The free plugin ships light mode only;
           the directrelay-pro plugin re-attaches a dark-mode handler. */

        /* —— Test Connection (Settings) ————————————————————————————————— */
        $(document).on('click', '#directrelay-test-conn-btn', function() {
            var $btn = $(this).prop('disabled', true).text('Testing...');
            var key = $('#directrelay-test-key').val();
            var $res = $('#directrelay-conn-result, #directrelay-test-result');
            $res.hide().text('');
            $.ajax({
                url: directrelayAdmin.apiBase + '/ping',
                headers: { 'Authorization': 'Bearer ' + key },
                success: function(r) {
                    $res.css('color', 'var(--directrelay-green)').text('✅ Connection Successful!\n' + JSON.stringify(r, null, 2)).fadeIn();
                    toast('Connection successful.', 'success');
                },
                error: function(r) {
                    var msg = r.responseJSON && r.responseJSON.message ? r.responseJSON.message : 'Unauthorized';
                    $res.css('color', 'var(--directrelay-red)').text('❌ Failed: ' + msg).fadeIn();
                    toast('Connection failed.', 'error');
                },
                complete: function() { $btn.prop('disabled', false).text('Test'); }
            });
        });

        /* —— Copy Workflow (n8n Templates) —————————————————————————————— */
        $(document).on('click', '.directrelay-copy-wf', function(e) {
            e.preventDefault();
            var target = $(this).data('target'), text = $('#' + target).text().trim(), $btn = $(this);
            if (navigator.clipboard) {
                navigator.clipboard.writeText(text).then(function() {
                    var orig = $btn.text();
                    $btn.text('✅ Copied JSON');
                    setTimeout(function() { $btn.text(orig); }, 2000);
                });
            }
        });

        /* —— Export Settings ———————————————————————————————————————————— */
        $(document).on('click', '#directrelay-export-settings', function(e) {
            e.preventDefault();
            var $btn = $(this).prop('disabled', true).text('Exporting…');
            $.post(directrelayAdmin.ajaxUrl, { action: 'directrelay_export_settings', nonce: directrelayAdmin.nonce }, function() {
                $btn.prop('disabled', false).text('Export Settings');
            }).fail(function() {
                $btn.prop('disabled', false).text('Export Settings');
                toast('Export failed.', 'error');
            });
        });

        /* —— Import Settings ———————————————————————————————————————————— */
        $(document).on('change', '#directrelay-import-settings-file', function() {
            var file = this.files[0];
            if (!file) return;
            var $status = $('#directrelay-import-status');
            var formData = new FormData();
            formData.append('action', 'directrelay_import_settings');
            formData.append('nonce', directrelayAdmin.nonce);
            formData.append('settings_file', file);
            $status.show().css('color', 'var(--directrelay-dim)').text('Importing…');
            $.ajax({
                url: directrelayAdmin.ajaxUrl,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(res) {
                    if (res.success) {
                        $status.css('color', 'var(--directrelay-green)').text('Imported ' + res.data.imported + ' setting(s). Reloading…');
                        setTimeout(function() { location.reload(); }, 1500);
                    } else {
                        $status.css('color', 'var(--directrelay-red)').text((res.data && res.data.message) || 'Import failed.');
                    }
                },
                error: function() {
                    $status.css('color', 'var(--directrelay-red)').text('Upload failed.');
                }
            });
        });

        /* License activation and deactivation handlers were removed
         * in DirectRelay 5.1.0. License management is provided by the
         * directrelay-pro add-on plugin. See
         * https://directrelay.wikiofautomation.com/directrelay-pro.
         */

        /* —— Approvals Gateway Actions ————————————————————————————————— */
        $(document).on('click', '.directrelay-btn-approve-ticket', function (e) {
            e.preventDefault();
            var $btn = $(this), uuid = $btn.data('uuid');
            if (!confirm('Approve and publish this post immediately?')) return;
            $btn.prop('disabled', true).text('Approving…');
            $.post(directrelayAdmin.ajaxUrl, { action: 'directrelay_approve_ticket', nonce: directrelayAdmin.nonce, uuid: uuid })
                .done(function (res) {
                    if (res.success) {
                        toast('Post approved and published live!', 'success');
                        setTimeout(function(){ location.reload(); }, 800);
                    } else {
                        toast((res.data && res.data.message) || 'Approval failed', 'error');
                        $btn.prop('disabled', false).text('Approve');
                    }
                }).fail(function () {
                    toast('Approval request failed.', 'error');
                    $btn.prop('disabled', false).text('Approve');
                });
        });

        $(document).on('click', '.directrelay-btn-reject-ticket', function (e) {
            e.preventDefault();
            var $btn = $(this), uuid = $btn.data('uuid');
            var feedback = prompt('Provide rejection feedback (optional, sent back to AI automation workflow):', '');
            if (feedback === null) return;
            $btn.prop('disabled', true).text('Rejecting…');
            $.post(directrelayAdmin.ajaxUrl, { action: 'directrelay_reject_ticket', nonce: directrelayAdmin.nonce, uuid: uuid, feedback: feedback })
                .done(function (res) {
                    if (res.success) {
                        toast('Ticket rejected.', 'info');
                        setTimeout(function(){ location.reload(); }, 800);
                    } else {
                        toast((res.data && res.data.message) || 'Rejection failed', 'error');
                        $btn.prop('disabled', false).text('Reject');
                    }
                }).fail(function () {
                    toast('Rejection request failed.', 'error');
                    $btn.prop('disabled', false).text('Reject');
                });
        });

        /* —— Debugger & Replay Engine —————————————————————————————————— */
        $(document).on('click', '.directrelay-btn-replay', function (e) {
            e.preventDefault();
            var $btn = $(this), id = $btn.data('id'), isDry = !!$btn.data('dry');
            var label = isDry ? 'Simulating Dry-Run…' : 'Replaying…';
            $btn.prop('disabled', true).text(label);
            $.post(directrelayAdmin.ajaxUrl, { action: 'directrelay_replay_request', nonce: directrelayAdmin.nonce, id: id, dry_run: isDry ? 1 : 0 })
                .done(function (res) {
                    $btn.prop('disabled', false).text(isDry ? 'Dry Run' : '⚡ Replay');
                    if (res.success) {
                        if (isDry) {
                            alert('Dry-Run Simulation Result:\n\n' + JSON.stringify(res.data, null, 2));
                        } else {
                            toast('Request successfully replayed (HTTP ' + res.data.replayed_status + ')', 'success');
                            setTimeout(function(){ location.reload(); }, 1200);
                        }
                    } else {
                        alert('Replay Error:\n' + ((res.data && res.data.message) || 'Unknown error'));
                    }
                }).fail(function () {
                    $btn.prop('disabled', false).text(isDry ? 'Dry Run' : '⚡ Replay');
                    toast('Replay network error.', 'error');
                });
        });

        /* —— Save Guardrails Settings —————————————————————————————————— */
        $(document).on('click', '#directrelay-save-guardrails', function (e) {
            e.preventDefault();
            var $btn = $(this).prop('disabled', true).text('Saving…');
            var $spin = $('#guardrails-spinner').addClass('is-active');
            var data = $('#directrelay-guardrails-form').serialize() + '&action=directrelay_save_guardrails&nonce=' + encodeURIComponent(directrelayAdmin.nonce);
            $.post(directrelayAdmin.ajaxUrl, data)
                .done(function (res) {
                    if (res.success) {
                        toast(res.data.message || 'Guardrails updated.', 'success');
                    } else {
                        toast((res.data && res.data.message) || 'Failed to save', 'error');
                    }
                }).fail(function () {
                    toast('Save request failed.', 'error');
                }).always(function () {
                    $btn.prop('disabled', false).text('Save Guardrail Settings');
                    $spin.removeClass('is-active');
                });
        });

    });
})(jQuery);