<?php
/**
 * Plugin Name: DirectRelay Pro — Monster Automation Bridge for n8n
 * Plugin URI: https://directrelay.wikiofautomation.com/directrelay-pro
 * Description: Complete Monster-Level Pro Automation Bridge connecting n8n workflows and AI agents with WordPress. Includes full core bridge + Bidirectional 4-Plugin SEO Engine, GEO/llms.txt, Google Indexing API, CPT/ACF/WooCommerce, Fleet Command, Webhook 2.0 DLQ, and AutoNode License Server sync.
 * Version: 1.0.0
 * Author: n4nion
 * Author URI: https://profiles.wordpress.org/n4nion
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Requires at least: 6.3
 * Tested up to: 7.1
 * Requires PHP: 8.0
 * Text Domain: directrelay-pro
 *
 * ============================================================================
 * Tier 1: Core Pro Modules (Already Wired into Free v5.1.32 Hooks & DB Schema)
 * These features plug directly into the existing tables (directrelay_approvals,
 * directrelay_analytics, directrelay_log), AJAX actions, and directrelay_ext_*
 * hooks already present in the Free plugin:
 * - Full Bidirectional SEO Write Engine (Rank Math, Yoast, AIOSEO, SEOPress):
 *   - Hooks into directrelay_ext_seo_update (for inline writes during post
 *     create/update) and registers PUT/PATCH /{type}/{id}/seo via
 *     directrelay_ext_register_routes.
 *   - Writes focus keywords, secondary keywords, meta title/description,
 *     canonical URL, robots directives, OpenGraph/Twitter cards, primary
 *     category, pillar content flag, and structured JSON-LD schemas (FAQ
 *     Schema, HowTo, Article, Product, Review).
 * - One-Shot, Bulk & Universal Schema Publishing Endpoints:
 *   - POST /publish/one-shot (Atomic Post + Media + Gallery + Full SEO Write + Rollback)
 *   - POST /bulk & POST/PUT /posts/bulk (Up to 50 items per request: create, update, publish, trash, delete)
 *   - POST /publish/universal (Universal_Schema_Translator for arbitrary AI/scraper JSON shapes)
 * - Human-in-the-Loop Approval Portal (Approval_Gateway):
 *   - Signed expiring Magic Review URLs, side-by-side preview, wp-admin Approvals Queue, and REST API
 * - AI Content Guardrails & Velocity Engine (Guardrails_Manager):
 *   - Per-key daily post velocity caps, min/max word counts, duplicate title detection, AI leakage scrubber
 * - Time-Travel Execution Debugger & Dry-Run Replay (Execution_Debugger):
 *   - 50-entry payload & trace inspector, Dry-Run simulation mode, and 1-click live request replay
 * - Interactive Chart.js Analytics Dashboard, Pro n8n Templates & Agentic Dark Mode
 *
 * Tier 2: Monster-Level AI, GEO/AEO & Content Intelligence Features
 * - Automated Internal Linking & Semantic Silo Engine (Internal_Linking_Engine):
 *   - GET /seo/internal-links (contextual link suggestions for n8n AI prompts)
 *   - GET|POST /seo/internal-links/rules & DELETE /seo/internal-links/rules/{id}
 *   - HTML-safe Auto-Internal-Linker on post save/publish & POST /seo/internal-links/apply/{id}
 * - GEO / AEO & /llms.txt + /llms-full.txt Suite (GEO_AEO_Engine):
 *   - Live virtual /llms.txt & /llms-full.txt Markdown corpus for AI crawlers
 *   - AI Citation & Key Takeaways Summary Box, Speakable & ClaimReview JSON-LD
 * - Google Indexing API + Multi-Engine Instant Indexer & Edge CDN Auto-Purge:
 *   - Native OpenSSL RS256 OAuth2 JWT Google Indexing API client (URL_UPDATED / URL_DELETED)
 *   - Instant Edge Cache Purge for Cloudflare, BunnyCDN, Fastly, and LiteSpeed
 * - Smart Media Pipeline (Smart_Media_Pipeline):
 *   - Inline body <img> external URL sideloader (DALL-E, Midjourney, Replicate -> local WP)
 *   - Automatic WebP image conversion & dynamic 1200x630 OpenGraph Social Card generator
 * - Gutenberg Block Converter (Gutenberg_Block_Converter):
 *   - Converts Markdown/HTML into native WordPress <!-- wp:* --> block grammar + Rank Math FAQ blocks
 *
 * Tier 3: Custom Post Types, WooCommerce, Multilingual & Bidirectional Sync
 * - Universal Custom Post Type (CPT) & Advanced Custom Fields Engine (CPT_Fields_Engine):
 *   - Full CRUD + Bulk on /cpt/{post_type} and /taxonomies/{taxonomy}
 *   - Deep ACF Pro (Repeaters, Flexible Content, Galleries, Relationships), Meta Box, JetEngine & Pods writes
 * - WooCommerce Automation Bridge (WooCommerce_Bridge):
 *   - Full Product & Variation CRUD (/wc/products), SKU Inventory/Price Bulk Sync (/wc/products/inventory-sync),
 *     Order Retrieval & Status/Note Updates (/wc/orders), and Outgoing WC Webhooks (order.created, order.paid, stock.low)
 * - Multilingual Publishing & hreflang Sync Bridge (Multilingual_Bridge):
 *   - Native WPML, Polylang & TranslatePress translation group linking (GET|POST /posts/{id}/translations)
 *     plus automatic <link rel="alternate" hreflang="..."> head output
 * - Content Refresh, Decay Detector & AI Revision Diff Rollback (Content_Decay_Versioning):
 *   - GET /posts/stale, automatic Pre-AI Snapshots on post updates, structural diff telemetry,
 *     and 1-click rollback (POST /posts/{id}/rollback)
 *
 * Tier 4: Multi-Site Fleet Command, Webhook 2.0, Agency White-Labeling & Alerts
 * - Multi-Site & Multi-Domain Fleet Command (Fleet_Command_Engine & Fleet_Controller):
 *   - GET /fleet/health (Multisite network + remote domain health, cron, SEO & latency check)
 *   - GET|POST|DELETE /fleet/sites (Manage remote connected WordPress child sites)
 *   - POST /fleet/keys/provision (Provision scoped API keys locally across network blogs or remotely)
 *   - POST /fleet/sync (Broadcast AI Guardrails, Internal Link Rules & Settings across the fleet)
 * - Webhook 2.0 Engine (Webhook_V2_Engine & Webhook_V2_Controller):
 *   - GET|POST /webhooks/{id}/rules (Conditional trigger filters: min_seo_score, min_words, categories, pillar_only, custom payload templates & outbound headers)
 *   - GET /webhooks/dlq, POST /webhooks/dlq/redrive & POST /webhooks/dlq/redrive/{log_id} (Dead-Letter Queue inspection & HMAC-signed re-drive)
 * - Agency White-Labeling & Real-Time Security Alerts (Agency_Governance_Engine & Governance_Controller):
 *   - GET|POST /governance/whitelabel (Custom plugin brand name, menu label, accent color, hide Pro upsells)
 *   - GET|POST /governance/alerts & POST /governance/alerts/test (Real-time Slack, Telegram & Discord alerts on brute-force blocks, guardrail violations & approval tickets)
 * - AutoNode License & Fleet Telemetry Client (License_Manager & License_Controller):
 *   - Cryptographic HMAC-SHA256 verification, AES-256-CBC key storage at rest, tamper-evident local state seal, and 72-hour offline grace period
 *   - Full integration with AutoNode License Server v2.2.0 (/autonode-license/v1/verify, /deactivate, /telemetry, /free-register, /client-status, /ping)
 *   - Automatic fleet sync of client API keys (request_count -> total_requests) and webhooks (fire_count/fail_count -> delivery health)
 * ============================================================================
 *
 * @package DirectRelayPro
 */

namespace DirectRelay\Pro {

	defined( 'ABSPATH' ) || exit;

	if ( ! defined( 'DIRECTRELAY_PRO_LOADED' ) ) {
		define( 'DIRECTRELAY_PRO_LOADED', true );
	}
	if ( ! defined( 'DIRECTRELAY_PRO_VERSION' ) ) {
		define( 'DIRECTRELAY_PRO_VERSION', '1.0.0' );
	}
	if ( ! defined( 'DIRECTRELAY_PRO_FILE' ) ) {
		define( 'DIRECTRELAY_PRO_FILE', __FILE__ );
	}
	if ( ! defined( 'DIRECTRELAY_PRO_DIR' ) ) {
		define( 'DIRECTRELAY_PRO_DIR', plugin_dir_path( __FILE__ ) );
	}
	if ( ! defined( 'DIRECTRELAY_PRO_URL' ) ) {
		define( 'DIRECTRELAY_PRO_URL', plugin_dir_url( __FILE__ ) );
	}
	if ( ! defined( 'DIRECTRELAY_PRO_MIN_FREE_VERSION' ) ) {
		define( 'DIRECTRELAY_PRO_MIN_FREE_VERSION', '5.1.22' );
	}

	// Resolve core directory (bundled `directrelay-pro/includes/` first; fallback to `directrelay-automation-bridge-for-n8n/` if single-file install).
	$dr_resolved_dir = DIRECTRELAY_PRO_DIR;
	$dr_resolved_url = DIRECTRELAY_PRO_URL;
	if ( ! is_dir( DIRECTRELAY_PRO_DIR . 'includes' ) && is_dir( WP_PLUGIN_DIR . '/directrelay-automation-bridge-for-n8n/includes' ) ) {
		$dr_resolved_dir = trailingslashit( WP_PLUGIN_DIR . '/directrelay-automation-bridge-for-n8n' );
		$dr_resolved_url = trailingslashit( plugins_url( '', WP_PLUGIN_DIR . '/directrelay-automation-bridge-for-n8n/directrelay.php' ) );
	}

	if ( ! defined( 'DIRECTRELAY_VERSION' ) ) {
		define( 'DIRECTRELAY_VERSION', '5.1.32' );
	}
	if ( ! defined( 'DIRECTRELAY_FILE' ) ) {
		define( 'DIRECTRELAY_FILE', __FILE__ );
	}
	if ( ! defined( 'DIRECTRELAY_DIR' ) ) {
		define( 'DIRECTRELAY_DIR', $dr_resolved_dir );
	}
	if ( ! defined( 'DIRECTRELAY_URL' ) ) {
		define( 'DIRECTRELAY_URL', $dr_resolved_url );
	}
	if ( ! defined( 'DIRECTRELAY_NS' ) ) {
		define( 'DIRECTRELAY_NS', 'directrelay/v1' );
	}
	if ( ! defined( 'DIRECTRELAY_DB_VERSION' ) ) {
		define( 'DIRECTRELAY_DB_VERSION', 12 );
	}
	if ( ! defined( 'DIRECTRELAY_BUILD' ) ) {
		define( 'DIRECTRELAY_BUILD', 'pro-all-in-one' );
	}
	if ( ! defined( 'DIRECTRELAY_LOADED' ) ) {
		define( 'DIRECTRELAY_LOADED', true );
	}
	unset( $dr_resolved_dir, $dr_resolved_url );

	/**
	 * Bootstrap DirectRelay Pro after the Free core plugin has initialized.
	 */
	if ( ! class_exists( '\DirectRelay\Pro\Plugin', false ) ) {
	final class Plugin {

		private static bool $booted = false;

		public static function load_bundled_core(): void {
			$core_map = [
				'includes/Build.php'                        => '\DirectRelay\Build',
				'includes/Installer.php'                    => '\DirectRelay\Installer',
				'includes/Brute_Force.php'                  => '\DirectRelay\Brute_Force',
				'includes/Api_Auth.php'                     => '\DirectRelay\Api_Auth',
				'includes/Agent_Profiles.php'               => '\DirectRelay\Agent_Profiles',
				'includes/Rate_Limiter.php'                 => '\DirectRelay\Rate_Limiter',
				'includes/Activity_Logger.php'              => '\DirectRelay\Activity_Logger',
				'includes/Taxonomy_Manager.php'             => '\DirectRelay\Taxonomy_Manager',
				'includes/Webhook_Manager.php'              => '\DirectRelay\Webhook_Manager',
				'includes/Content_Processor.php'            => '\DirectRelay\Content_Processor',
				'includes/Transactional_Publisher.php'      => '\DirectRelay\Transactional_Publisher',
				'includes/IndexNow_Pinger.php'              => '\DirectRelay\IndexNow_Pinger',
				'includes/Post_Manager.php'                 => '\DirectRelay\Post_Manager',
				'includes/Rankmath_Handler.php'             => '\DirectRelay\Rankmath_Handler',
				'includes/Compatibility.php'                => '\DirectRelay\Compatibility',
				'includes/Cron_Health.php'                  => '\DirectRelay\Cron_Health',
				'includes/Feature_Gate.php'                 => '\DirectRelay\Feature_Gate',
				'includes/REST/Base_Controller.php'         => '\DirectRelay\REST\Base_Controller',
				'includes/REST/Posts_Controller.php'        => '\DirectRelay\REST\Posts_Controller',
				'includes/REST/Pages_Controller.php'        => '\DirectRelay\REST\Pages_Controller',
				'includes/REST/SEO_Controller.php'          => '\DirectRelay\REST\SEO_Controller',
				'includes/REST/Meta_Controller.php'         => '\DirectRelay\REST\Meta_Controller',
				'includes/REST/Media_Controller.php'        => '\DirectRelay\REST\Media_Controller',
				'includes/REST/Taxonomy_Controller.php'     => '\DirectRelay\REST\Taxonomy_Controller',
				'includes/REST/Webhook_Controller.php'      => '\DirectRelay\REST\Webhook_Controller',
				'includes/REST/Keys_Controller.php'         => '\DirectRelay\REST\Keys_Controller',
				'includes/REST/System_Controller.php'       => '\DirectRelay\REST\System_Controller',
				'includes/REST/Discovery_Controller.php'    => '\DirectRelay\REST\Discovery_Controller',
				'includes/REST/Openapi_Controller.php'      => '\DirectRelay\REST\Openapi_Controller',
				'includes/admin/Ajax_Handler.php'           => '\DirectRelay\Admin\Ajax_Handler',
				'includes/admin/Menu.php'                   => '\DirectRelay\Admin\Menu',
				'includes/Plugin.php'                       => '\DirectRelay\Plugin',
			];

			// Search bundled `directrelay-pro/includes/` first, then fallback to sibling `directrelay-automation-bridge-for-n8n/includes/` if present.
			$candidate_dirs = [
				DIRECTRELAY_PRO_DIR,
				trailingslashit( WP_PLUGIN_DIR ) . 'directrelay-automation-bridge-for-n8n/',
			];

			foreach ( $core_map as $rel => $fqcn ) {
				if ( class_exists( $fqcn, false ) ) {
					continue;
				}
				foreach ( $candidate_dirs as $base_dir ) {
					$full = $base_dir . $rel;
					if ( file_exists( $full ) ) {
						require_once $full;
						break;
					}
				}
			}
		}

		public static function init(): void {
			if ( self::$booted ) {
				return;
			}

			self::load_bundled_core();

			// When the complete Pro package (`directrelay-pro/includes/`) is installed, automatically deactivate
			// the redundant Free plugin if both are active so Pro's upgraded views and menus take precedence cleanly.
			if ( is_dir( DIRECTRELAY_PRO_DIR . 'includes' ) ) {
				add_action( 'admin_init', static function (): void {
					if ( ! function_exists( 'is_plugin_active' ) || ! function_exists( 'deactivate_plugins' ) ) {
						require_once ABSPATH . 'wp-admin/includes/plugin.php';
					}
					$free_slugs = [
						'directrelay-automation-bridge-for-n8n/directrelay.php',
						'directrelay-automation-bridge-for-n8n.5.1.32/directrelay.php',
					];
					foreach ( $free_slugs as $fslug ) {
						if ( function_exists( 'is_plugin_active' ) && is_plugin_active( $fslug ) && plugin_basename( DIRECTRELAY_PRO_FILE ) !== $fslug ) {
							deactivate_plugins( $fslug, true );
						}
					}
				}, 1 );
			}

			// Boot core services (`Installer`, `Brute_Force`, `Rate_Limiter`, `Activity_Logger`, `Webhook_Manager`, `Menu`, `REST`).
			if ( class_exists( '\DirectRelay\Plugin' ) ) {
				\DirectRelay\Plugin::boot();
			} else {
				add_action( 'admin_notices', [ __CLASS__, 'missing_core_notice' ] );
				return;
			}

			self::$booted = true;

			// Boot Tier 1 Module 1: Full Bidirectional SEO Write Engine.
			SEO_Write_Engine::init();

			// Boot Tier 1 Module 3: Human-in-the-Loop Approval Portal.
			\DirectRelay\Approval_Gateway::init();

			// Boot Tier 1 Module 4: AI Content Guardrails & Velocity Engine.
			\DirectRelay\Guardrails_Manager::init();

			// Boot Tier 1 Module 6: Admin Submenus, Chart.js Dashboard, Pro Templates & Dark Mode.
			Admin_Extension::init();

			// Boot Tier 2 Modules: Internal Linking, GEO/AEO (/llms.txt), Instant Indexer + CDN, Smart Media, Gutenberg Blocks.
			Internal_Linking_Engine::init();
			GEO_AEO_Engine::init();
			Instant_Indexer_CDN::init();
			Smart_Media_Pipeline::init();
			Gutenberg_Block_Converter::init();

			// Boot Tier 3 Modules: CPT/ACF Engine, WooCommerce Bridge, Multilingual Bridge, Content Decay & Versioning.
			CPT_Fields_Engine::init();
			WooCommerce_Bridge::init();
			Multilingual_Bridge::init();
			Content_Decay_Versioning::init();

			// Boot Tier 4 Modules: Fleet Command, Webhook 2.0 (Conditional Rules & DLQ), Agency White-Labeling & Real-Time Alerts.
			Fleet_Command_Engine::init();
			Webhook_V2_Engine::init();
			Agency_Governance_Engine::init();

			// Boot AutoNode License & Fleet Telemetry Client.
			License_Manager::init();

			// Register Pro REST API routes when the Free REST surface finishes registering.
			add_action( 'directrelay_ext_register_routes', [ __CLASS__, 'register_rest_routes' ] );
		}

		/**
		 * Register Pro REST controllers via `directrelay_ext_register_routes`.
		 */
		public static function register_rest_routes(): void {
			// Tier 1 Controllers
			\DirectRelay\Pro\REST\SEO_Write_Controller::register();
			\DirectRelay\Pro\REST\Publishing_Controller::register();
			\DirectRelay\Pro\REST\Approval_Controller::register();
			\DirectRelay\Pro\REST\Debugger_Controller::register();
			\DirectRelay\Pro\REST\Analytics_Controller::register();

			// Tier 2 Controllers
			\DirectRelay\Pro\REST\Internal_Links_Controller::register();
			\DirectRelay\Pro\REST\GEO_Controller::register();
			\DirectRelay\Pro\REST\Indexer_Controller::register();
			\DirectRelay\Pro\REST\Smart_Media_Controller::register();
			\DirectRelay\Pro\REST\Blocks_Controller::register();

			// Tier 3 Controllers
			\DirectRelay\Pro\REST\CPT_Controller::register();
			\DirectRelay\Pro\REST\WooCommerce_Controller::register();
			\DirectRelay\Pro\REST\Multilingual_Controller::register();
			\DirectRelay\Pro\REST\Content_Decay_Controller::register();

			// Tier 4 Controllers
			\DirectRelay\Pro\REST\Fleet_Controller::register();
			\DirectRelay\Pro\REST\Webhook_V2_Controller::register();
			\DirectRelay\Pro\REST\Governance_Controller::register();

			// AutoNode License & Telemetry Controller
			\DirectRelay\Pro\REST\License_Controller::register();
		}

		/**
		 * Admin notice when the Free DirectRelay plugin is not active.
		 */
		public static function missing_core_notice(): void {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}
			echo '<div class="notice notice-error"><p><strong>DirectRelay Pro:</strong> ' .
				esc_html__( 'Requires the free "DirectRelay Automation Bridge for n8n" plugin to be installed and activated.', 'directrelay-pro' ) .
				'</p></div>';
		}

		/**
		 * Admin notice when the Free DirectRelay plugin is older than 5.1.22.
		 */
		public static function outdated_core_notice(): void {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}
			printf(
				'<div class="notice notice-error"><p><strong>DirectRelay Pro:</strong> %s</p></div>',
				esc_html(
					sprintf(
						/* translators: 1: current free version, 2: required free version */
						__( 'Detected DirectRelay Free v%1$s, but v%2$s or higher is required for `directrelay_ext_*` hook compatibility.', 'directrelay-pro' ),
						defined( 'DIRECTRELAY_VERSION' ) ? DIRECTRELAY_VERSION : 'unknown',
						DIRECTRELAY_PRO_MIN_FREE_VERSION
					)
				)
			);
		}
	}
	}

	/**
	 * Tier 1 — Module 1: Full Bidirectional SEO Write Engine
	 *
	 * Provides unified read/write/delete access across:
	 *   1. Rank Math SEO (`rank_math_*`)
	 *   2. Yoast SEO (`_yoast_wpseo_*`)
	 *   3. All in One SEO / AIOSEO (`_aioseo_*` postmeta + `wp_aioseo_posts` table)
	 *   4. SEOPress (`_seopress_*`)
	 *
	 * Also sanitizes, persists, and renders structured Schema.org JSON-LD graphs
	 * for FAQPage, HowTo, Article (Article / NewsArticle / BlogPosting / TechArticle),
	 * Product, and Review schemas.
	 */
	if ( ! class_exists( '\DirectRelay\Pro\SEO_Write_Engine', false ) ) {
	final class SEO_Write_Engine {

		/**
		 * Rank Math field mapping.
		 */
		public const RM_MAP = [
			'focus_keyword'       => 'rank_math_focus_keyword',
			'title'               => 'rank_math_title',
			'description'         => 'rank_math_description',
			'robots'              => 'rank_math_robots',
			'canonical_url'       => 'rank_math_canonical_url',
			'og_title'            => 'rank_math_og_title',
			'og_description'      => 'rank_math_og_description',
			'og_image'            => 'rank_math_og_image',
			'og_image_id'         => 'rank_math_og_image_id',
			'og_object_type'      => 'rank_math_og_object_type',
			'twitter_title'       => 'rank_math_twitter_title',
			'twitter_description' => 'rank_math_twitter_description',
			'twitter_image'       => 'rank_math_twitter_image',
			'twitter_card_type'   => 'rank_math_twitter_card_type',
			'primary_category'    => 'rank_math_primary_category',
			'schema_type'         => 'rank_math_rich_snippet',
			'breadcrumb_title'    => 'rank_math_breadcrumb_title',
			'pillar_content'      => 'rank_math_pillar_content',
			'advanced_robots'     => 'rank_math_advanced_robots',
			'faq_schema'          => 'rank_math_faq_schema',
		];

		/**
		 * Yoast SEO field mapping.
		 */
		public const YOAST_MAP = [
			'focus_keyword'       => '_yoast_wpseo_focuskw',
			'secondary_keywords'  => '_yoast_wpseo_focuskeywords',
			'title'               => '_yoast_wpseo_title',
			'description'         => '_yoast_wpseo_metadesc',
			'canonical_url'       => '_yoast_wpseo_canonical',
			'og_title'            => '_yoast_wpseo_opengraph-title',
			'og_description'      => '_yoast_wpseo_opengraph-description',
			'og_image'            => '_yoast_wpseo_opengraph-image',
			'og_image_id'         => '_yoast_wpseo_opengraph-image-id',
			'twitter_title'       => '_yoast_wpseo_twitter-title',
			'twitter_description' => '_yoast_wpseo_twitter-description',
			'twitter_image'       => '_yoast_wpseo_twitter-image',
			'primary_category'    => '_yoast_wpseo_primary_category',
			'breadcrumb_title'    => '_yoast_wpseo_bctitle',
			'pillar_content'      => '_yoast_wpseo_is_cornerstone',
		];

		/**
		 * All in One SEO (AIOSEO) postmeta mapping.
		 */
		public const AIOSEO_MAP = [
			'focus_keyword'       => '_aioseo_keywords',
			'title'               => '_aioseo_title',
			'description'         => '_aioseo_description',
			'canonical_url'       => '_aioseo_canonical_url',
			'og_title'            => '_aioseo_og_title',
			'og_description'      => '_aioseo_og_description',
			'og_image'            => '_aioseo_og_image_custom_url',
			'og_object_type'      => '_aioseo_og_object_type',
			'twitter_title'       => '_aioseo_twitter_title',
			'twitter_description' => '_aioseo_twitter_description',
			'twitter_image'       => '_aioseo_twitter_image_custom_url',
			'twitter_card_type'   => '_aioseo_twitter_card',
			'primary_category'    => '_aioseo_primary_term_category',
			'pillar_content'      => '_aioseo_pillar_content',
		];

		/**
		 * SEOPress postmeta mapping.
		 */
		public const SEOPRESS_MAP = [
			'focus_keyword'       => '_seopress_analysis_target_kw',
			'title'               => '_seopress_titles_title',
			'description'         => '_seopress_titles_desc',
			'canonical_url'       => '_seopress_robots_canonical',
			'og_title'            => '_seopress_social_fb_title',
			'og_description'      => '_seopress_social_fb_desc',
			'og_image'            => '_seopress_social_fb_img',
			'og_image_id'         => '_seopress_social_fb_img_attachment_id',
			'twitter_title'       => '_seopress_social_twitter_title',
			'twitter_description' => '_seopress_social_twitter_desc',
			'twitter_image'       => '_seopress_social_twitter_img',
			'twitter_card_type'   => '_seopress_social_twitter_card_img_size',
			'primary_category'    => '_seopress_robots_primary_cat',
			'breadcrumb_title'    => '_seopress_robots_breadcrumbs',
		];

		/**
		 * DirectRelay Pro internal canonical storage keys for extended schemas & secondary keywords.
		 */
		public const PRO_META_KEYS = [
			'secondary_keywords' => '_directrelay_seo_secondary_keywords',
			'faq_schema'         => '_directrelay_schema_faq',
			'howto_schema'       => '_directrelay_schema_howto',
			'article_schema'     => '_directrelay_schema_article',
			'product_schema'     => '_directrelay_schema_product',
			'review_schema'      => '_directrelay_schema_review',
		];

		/**
		 * Allowed robots directives.
		 */
		private const ALLOWED_ROBOTS = [
			'index',
			'noindex',
			'follow',
			'nofollow',
			'noarchive',
			'nosnippet',
			'noimageindex',
			'notranslate',
		];

		/**
		 * Register filters and frontend JSON-LD hooks.
		 */
		public static function init(): void {
			// 1. Hook into the Free plugin's inline SEO write filter (`Rankmath_Handler::handle_inline_write`).
			add_filter( 'directrelay_ext_seo_update', [ __CLASS__, 'filter_inline_seo_update' ], 10, 3 );

			// 2. Support top-level shorthand SEO keys in POST/PUT /posts and /pages (e.g. `rankmath_focus_keyword`).
			add_filter( 'rest_request_before_callbacks', [ __CLASS__, 'normalize_shorthand_seo_params' ], 10, 3 );

			// 3. Enrich Free GET /{type}/{id}/seo, GET /posts/{id}, POST/PUT /posts, and /discovery/fields responses.
			add_filter( 'rest_post_dispatch', [ __CLASS__, 'enrich_rest_responses' ], 20, 3 );

			// 4. Render structured JSON-LD schemas (FAQ, HowTo, Article, Product, Review) in frontend `<head>`.
			add_action( 'wp_head', [ __CLASS__, 'render_frontend_json_ld' ], 25 );
		}

		/**
		 * Detect all active SEO plugins on the current WordPress site.
		 *
		 * @return array{
		 *   primary: string,
		 *   active: array<string, bool>,
		 *   versions: array<string, string|null>
		 * }
		 */
		public static function detect_providers(): array {
			$rm       = defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' );
			$yoast    = defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Options' ) || defined( 'WPSEO_FILE' );
			$aioseo   = defined( 'AIOSEO_VERSION' ) || function_exists( 'aioseo' );
			$seopress = defined( 'SEOPRESS_VERSION' ) || function_exists( 'seopress_init' );

			$active = [
				'rankmath' => $rm,
				'yoast'    => $yoast,
				'aioseo'   => $aioseo,
				'seopress' => $seopress,
			];

			$primary = 'rankmath';
			foreach ( $active as $slug => $is_on ) {
				if ( $is_on ) {
					$primary = $slug;
					break;
				}
			}

			return [
				'primary'  => $primary,
				'active'   => $active,
				'versions' => [
					'rankmath' => defined( 'RANK_MATH_VERSION' ) ? (string) RANK_MATH_VERSION : null,
					'yoast'    => defined( 'WPSEO_VERSION' ) ? (string) WPSEO_VERSION : null,
					'aioseo'   => defined( 'AIOSEO_VERSION' ) ? (string) AIOSEO_VERSION : null,
					'seopress' => defined( 'SEOPRESS_VERSION' ) ? (string) SEOPRESS_VERSION : null,
				],
			];
		}

		/**
		 * Filter callback for `directrelay_ext_seo_update`.
		 *
		 * Invoked by `\DirectRelay\Rankmath_Handler::handle_inline_write()` when a
		 * `POST /posts`, `PUT /posts/{id}`, `POST /pages`, or `PUT /pages/{id}`
		 * request contains an inline `"seo": { ... }` payload and the authenticated
		 * key holds the `seo:write` scope.
		 *
		 * @param mixed $result  Default null from Free plugin.
		 * @param int   $post_id Target post ID.
		 * @param array $seo     Inline SEO payload.
		 * @return array|\WP_Error Non-null array marks `seo_write` as `handled_addon`.
		 */
		public static function filter_inline_seo_update( $result, int $post_id, array $seo ): array|\WP_Error {
			if ( $post_id <= 0 || ! get_post( $post_id ) ) {
				return new \WP_Error(
					'directrelay_pro_invalid_post',
					__( 'Cannot write SEO metadata: target post does not exist.', 'directrelay-pro' ),
					[ 'status' => 404 ]
				);
			}

			return self::update( $post_id, $seo );
		}

		/**
		 * Normalize shorthand top-level SEO parameters (e.g. `rankmath_focus_keyword`,
		 * `seo_focus_keyword`, `seo_title`, `seo_description`) into the `seo` object
		 * on post/page create and update requests.
		 *
		 * @param mixed            $response Result to send to the client.
		 * @param array            $handler  Route handler.
		 * @param \WP_REST_Request $request  Request used to generate the response.
		 * @return mixed
		 */
		public static function normalize_shorthand_seo_params( $response, array $handler, \WP_REST_Request $request ) {
			if ( is_wp_error( $response ) ) {
				return $response;
			}

			$route  = $request->get_route();
			$method = strtoupper( $request->get_method() );
			if ( ! in_array( $method, [ 'POST', 'PUT', 'PATCH' ], true ) ) {
				return $response;
			}
			if ( ! preg_match( '#^/directrelay/v1/(?:posts|pages)(?:/\d+)?$#', $route ) ) {
				return $response;
			}

			$json = $request->get_json_params();
			if ( ! is_array( $json ) ) {
				return $response;
			}

			$shorthand_map = [
				'rankmath_focus_keyword' => 'focus_keyword',
				'seo_focus_keyword'      => 'focus_keyword',
				'focus_keyword'          => 'focus_keyword',
				'secondary_keywords'     => 'secondary_keywords',
				'rankmath_title'         => 'title',
				'seo_title'              => 'title',
				'rankmath_description'   => 'description',
				'seo_description'        => 'description',
				'canonical_url'          => 'canonical_url',
				'faq_schema'             => 'faq_schema',
				'howto_schema'           => 'howto_schema',
				'article_schema'         => 'article_schema',
				'product_schema'         => 'product_schema',
				'review_schema'          => 'review_schema',
			];

			$injected = false;
			$seo      = isset( $json['seo'] ) && is_array( $json['seo'] ) ? $json['seo'] : [];

			foreach ( $shorthand_map as $top_key => $seo_key ) {
				if ( isset( $json[ $top_key ] ) && ! isset( $seo[ $seo_key ] ) ) {
					$seo[ $seo_key ] = $json[ $top_key ];
					$injected        = true;
				}
			}

			if ( $injected ) {
				$json['seo'] = $seo;
				$request->set_body( wp_json_encode( $json ) );
				$request->set_param( 'seo', $seo );
			}

			return $response;
		}

		/**
		 * Enrich REST API responses on `/directrelay/v1/{posts|pages}/{id}/seo`,
		 * `/directrelay/v1/{posts|pages}`, and `/directrelay/v1/discovery/fields`
		 * so callers always receive the full 4-plugin + 5-schema SEO state.
		 */
		public static function enrich_rest_responses( $response, \WP_REST_Server $server, \WP_REST_Request $request ) {
			if ( ! ( $response instanceof \WP_REST_Response ) ) {
				return $response;
			}

			$route = $request->get_route();
			$data  = $response->get_data();
			if ( ! is_array( $data ) || empty( $data['success'] ) || ! isset( $data['data'] ) || ! is_array( $data['data'] ) ) {
				return $response;
			}

			// 1. Direct GET /{type}/{id}/seo endpoint enrichment.
			if ( 'GET' === $request->get_method() && preg_match( '#^/directrelay/v1/(?:posts|pages)/(\d+)/seo$#', $route, $m ) ) {
				$post_id      = (int) $m[1];
				$data['data'] = self::read( $post_id );
				$response->set_data( $data );
				return $response;
			}

			// 2. Single post/page create, update, or show enrichment.
			if ( preg_match( '#^/directrelay/v1/(posts|pages)(?:/(\d+))?$#', $route ) ) {
				foreach ( [ 'post', 'page' ] as $entity_key ) {
					if ( ! empty( $data['data'][ $entity_key ]['id'] ) ) {
						$pid = (int) $data['data'][ $entity_key ]['id'];
						$data['data'][ $entity_key ]['seo'] = self::read( $pid );
						$response->set_data( $data );
						break;
					}
				}
				return $response;
			}

			// 3. Dynamic Field Discovery (`/discovery/fields`) enrichment for n8n nodes.
			if ( '/directrelay/v1/discovery/fields' === $route && isset( $data['data']['fields']['seo'] ) ) {
				$data['data']['fields']['seo'] = self::get_discoverable_seo_fields();
				$response->set_data( $data );
				return $response;
			}

			return $response;
		}

		/**
		 * Read unified SEO metadata + structured JSON-LD schemas for a post across
		 * Rank Math, Yoast SEO, AIOSEO, and SEOPress.
		 *
		 * @param int $post_id Target post ID.
		 * @return array<string, mixed>
		 */
		public static function read( int $post_id ): array {
			$providers = self::detect_providers();

			// Start with Free's Rankmath_Handler::read() if available for 100% backward compatibility.
			$base = class_exists( '\DirectRelay\Rankmath_Handler' )
				? \DirectRelay\Rankmath_Handler::read( $post_id )
				: [ 'plugin' => $providers['primary'] ];

			$fields = [
				'focus_keyword',
				'title',
				'description',
				'robots',
				'canonical_url',
				'og_title',
				'og_description',
				'og_image',
				'og_image_id',
				'og_object_type',
				'twitter_title',
				'twitter_description',
				'twitter_image',
				'twitter_card_type',
				'primary_category',
				'schema_type',
				'breadcrumb_title',
				'pillar_content',
				'advanced_robots',
			];

			foreach ( $fields as $field ) {
				$val = $base[ $field ] ?? '';
				if ( self::is_empty_val( $val ) && isset( self::RM_MAP[ $field ] ) ) {
					$val = get_post_meta( $post_id, self::RM_MAP[ $field ], true );
				}
				if ( self::is_empty_val( $val ) && isset( self::YOAST_MAP[ $field ] ) ) {
					$val = get_post_meta( $post_id, self::YOAST_MAP[ $field ], true );
				}
				if ( self::is_empty_val( $val ) && isset( self::AIOSEO_MAP[ $field ] ) ) {
					$val = get_post_meta( $post_id, self::AIOSEO_MAP[ $field ], true );
				}
				if ( self::is_empty_val( $val ) && isset( self::SEOPRESS_MAP[ $field ] ) ) {
					$val = get_post_meta( $post_id, self::SEOPRESS_MAP[ $field ], true );
				}
				$base[ $field ] = $val;
			}

			// Normalize primary & secondary keywords.
			$secondary = get_post_meta( $post_id, self::PRO_META_KEYS['secondary_keywords'], true );
			if ( ! is_array( $secondary ) ) {
				// If Rank Math stores comma-separated keywords in `rank_math_focus_keyword`, extract them.
				$rm_kw = (string) get_post_meta( $post_id, 'rank_math_focus_keyword', true );
				if ( str_contains( $rm_kw, ',' ) ) {
					$parts                 = array_values( array_filter( array_map( 'trim', explode( ',', $rm_kw ) ) ) );
					$base['focus_keyword'] = $parts[0] ?? '';
					$secondary             = array_slice( $parts, 1 );
				} else {
					$secondary = [];
				}
			}
			$base['secondary_keywords'] = array_values( $secondary );

			// Normalize pillar_content boolean flag alongside raw compatibility value.
			$pillar_raw                  = $base['pillar_content'] ?? '';
			$base['pillar_content_bool'] = in_array( (string) $pillar_raw, [ 'on', '1', 'true', 'yes' ], true )
				|| '1' === (string) get_post_meta( $post_id, '_yoast_wpseo_is_cornerstone', true )
				|| '1' === (string) get_post_meta( $post_id, '_aioseo_pillar_content', true );

			// Normalize primary_category to integer if set.
			if ( ! empty( $base['primary_category'] ) ) {
				$base['primary_category'] = (int) $base['primary_category'];
			}

			// Read structured JSON-LD schemas.
			$faq_schema = get_post_meta( $post_id, self::PRO_META_KEYS['faq_schema'], true );
			if ( empty( $faq_schema ) ) {
				$faq_schema = get_post_meta( $post_id, 'rank_math_faq_schema', true ) ?: [];
			}

			$base['faq_schema']     = is_array( $faq_schema ) ? $faq_schema : [];
			$base['howto_schema']   = get_post_meta( $post_id, self::PRO_META_KEYS['howto_schema'], true ) ?: null;
			$base['article_schema'] = get_post_meta( $post_id, self::PRO_META_KEYS['article_schema'], true ) ?: null;
			$base['product_schema'] = get_post_meta( $post_id, self::PRO_META_KEYS['product_schema'], true ) ?: null;
			$base['review_schema']  = get_post_meta( $post_id, self::PRO_META_KEYS['review_schema'], true ) ?: null;

			$base['active_plugins'] = array_keys( array_filter( $providers['active'] ) );
			$base['seo_score']      = (int) (
				get_post_meta( $post_id, 'rank_math_seo_score', true )
				?: get_post_meta( $post_id, '_yoast_wpseo_linkdex', true )
				?: get_post_meta( $post_id, '_aioseo_seo_score', true )
				?: 0
			);

			return $base;
		}

		/**
		 * Bidirectional Write: Update SEO metadata and structured JSON-LD schemas
		 * across Rank Math, Yoast SEO, AIOSEO, and SEOPress.
		 *
		 * @param int   $post_id Target post ID.
		 * @param array $payload Incoming SEO field map.
		 * @return array|\WP_Error Summary of updated fields and resulting SEO state.
		 */
		public static function update( int $post_id, array $payload ): array|\WP_Error {
			$post = get_post( $post_id );
			if ( ! $post ) {
				return new \WP_Error(
					'directrelay_pro_not_found',
					__( 'Target content not found.', 'directrelay-pro' ),
					[ 'status' => 404 ]
				);
			}

			// Alias normalization (`canonical` -> `canonical_url`, `cornerstone` -> `pillar_content`, etc.).
			if ( isset( $payload['canonical'] ) && ! isset( $payload['canonical_url'] ) ) {
				$payload['canonical_url'] = $payload['canonical'];
			}
			if ( isset( $payload['cornerstone'] ) && ! isset( $payload['pillar_content'] ) ) {
				$payload['pillar_content'] = $payload['cornerstone'];
			}
			if ( isset( $payload['meta_title'] ) && ! isset( $payload['title'] ) ) {
				$payload['title'] = $payload['meta_title'];
			}
			if ( isset( $payload['meta_description'] ) && ! isset( $payload['description'] ) ) {
				$payload['description'] = $payload['meta_description'];
			}

			// Support nested `schemas` object if sent as `seo.schemas.{faq,howto,article,product,review}`.
			if ( ! empty( $payload['schemas'] ) && is_array( $payload['schemas'] ) ) {
				foreach ( [ 'faq', 'howto', 'article', 'product', 'review' ] as $stype ) {
					$skey = "{$stype}_schema";
					if ( isset( $payload['schemas'][ $stype ] ) && ! isset( $payload[ $skey ] ) ) {
						$payload[ $skey ] = $payload['schemas'][ $stype ];
					} elseif ( isset( $payload['schemas'][ $skey ] ) && ! isset( $payload[ $skey ] ) ) {
						$payload[ $skey ] = $payload['schemas'][ $skey ];
					}
				}
			}

			$updated_fields = [];
			$aioseo_columns = [];

			// ── 1. Focus Keyword & Secondary Keywords ────────────────────────────
			$has_focus     = array_key_exists( 'focus_keyword', $payload );
			$has_secondary = array_key_exists( 'secondary_keywords', $payload );

			if ( $has_focus || $has_secondary ) {
				$primary_kw = $has_focus
					? sanitize_text_field( (string) $payload['focus_keyword'] )
					: (string) ( self::read( $post_id )['focus_keyword'] ?? '' );

				$secondary_kws = [];
				if ( $has_secondary ) {
					$raw_sec = $payload['secondary_keywords'];
					if ( is_string( $raw_sec ) ) {
						$raw_sec = explode( ',', $raw_sec );
					}
					if ( is_array( $raw_sec ) ) {
						foreach ( $raw_sec as $kw ) {
							$clean_kw = sanitize_text_field( (string) $kw );
							if ( '' !== $clean_kw && strtolower( $clean_kw ) !== strtolower( $primary_kw ) ) {
								$secondary_kws[] = $clean_kw;
							}
						}
					}
					$secondary_kws = array_values( array_unique( $secondary_kws ) );
					update_post_meta( $post_id, self::PRO_META_KEYS['secondary_keywords'], $secondary_kws );
					$updated_fields[] = 'secondary_keywords';
				} else {
					$existing_sec = get_post_meta( $post_id, self::PRO_META_KEYS['secondary_keywords'], true );
					if ( is_array( $existing_sec ) ) {
						$secondary_kws = $existing_sec;
					}
				}

				// Combine primary + secondary for Rank Math and SEOPress (`kw1,kw2,kw3`).
				$all_kws = array_values( array_filter( array_merge( [ $primary_kw ], $secondary_kws ) ) );
				$csv_kws = implode( ',', $all_kws );

				// Rank Math
				update_post_meta( $post_id, self::RM_MAP['focus_keyword'], $csv_kws );

				// Yoast SEO (Primary + Premium JSON array for secondary keyphrases)
				update_post_meta( $post_id, self::YOAST_MAP['focus_keyword'], $primary_kw );
				if ( ! empty( $secondary_kws ) ) {
					$yoast_sec = array_map(
						static fn( string $k ): array => [ 'keyword' => $k, 'score' => 'ok' ],
						$secondary_kws
					);
					update_post_meta( $post_id, self::YOAST_MAP['secondary_keywords'], wp_json_encode( $yoast_sec ) );
				}

				// AIOSEO
				update_post_meta( $post_id, self::AIOSEO_MAP['focus_keyword'], $csv_kws );
				$aioseo_columns['keyphrases'] = wp_json_encode( [
					'focus'      => [ 'keyphrase' => $primary_kw ],
					'additional' => array_map(
						static fn( string $k ): array => [ 'keyphrase' => $k ],
						$secondary_kws
					),
				] );

				// SEOPress
				update_post_meta( $post_id, self::SEOPRESS_MAP['focus_keyword'], $csv_kws );

				if ( $has_focus ) {
					$updated_fields[] = 'focus_keyword';
				}
			}

			// ── 2. Meta Title & Description ──────────────────────────────────────
			if ( array_key_exists( 'title', $payload ) ) {
				$title = sanitize_text_field( (string) $payload['title'] );
				update_post_meta( $post_id, self::RM_MAP['title'], $title );
				update_post_meta( $post_id, self::YOAST_MAP['title'], $title );
				update_post_meta( $post_id, self::AIOSEO_MAP['title'], $title );
				update_post_meta( $post_id, self::SEOPRESS_MAP['title'], $title );
				$aioseo_columns['title'] = $title;
				$updated_fields[]        = 'title';
			}

			if ( array_key_exists( 'description', $payload ) ) {
				$desc = sanitize_textarea_field( (string) $payload['description'] );
				update_post_meta( $post_id, self::RM_MAP['description'], $desc );
				update_post_meta( $post_id, self::YOAST_MAP['description'], $desc );
				update_post_meta( $post_id, self::AIOSEO_MAP['description'], $desc );
				update_post_meta( $post_id, self::SEOPRESS_MAP['description'], $desc );
				$aioseo_columns['description'] = $desc;
				$updated_fields[]              = 'description';
			}

			// ── 3. Canonical URL ─────────────────────────────────────────────────
			if ( array_key_exists( 'canonical_url', $payload ) ) {
				$raw_canon = trim( (string) $payload['canonical_url'] );
				if ( '' !== $raw_canon ) {
					$canon = esc_url_raw( $raw_canon, [ 'http', 'https' ] );
					if ( '' === $canon || ! filter_var( $canon, FILTER_VALIDATE_URL ) ) {
						return new \WP_Error(
							'directrelay_pro_invalid_canonical',
							__( 'Invalid canonical_url: must be a valid http(s) URL.', 'directrelay-pro' ),
							[ 'status' => 400 ]
						);
					}
				} else {
					$canon = '';
				}
				update_post_meta( $post_id, self::RM_MAP['canonical_url'], $canon );
				update_post_meta( $post_id, self::YOAST_MAP['canonical_url'], $canon );
				update_post_meta( $post_id, self::AIOSEO_MAP['canonical_url'], $canon );
				update_post_meta( $post_id, self::SEOPRESS_MAP['canonical_url'], $canon );
				$aioseo_columns['canonical_url'] = $canon;
				$updated_fields[]                = 'canonical_url';
			}

			// ── 4. Robots Directives & Advanced Robots ───────────────────────────
			if ( array_key_exists( 'robots', $payload ) ) {
				$robots = self::normalize_robots( $payload['robots'] );
				// Rank Math stores robots as an array of strings (e.g. `['index', 'follow']`).
				update_post_meta( $post_id, self::RM_MAP['robots'], $robots );

				// Yoast SEO
				$is_noindex  = in_array( 'noindex', $robots, true );
				$is_nofollow = in_array( 'nofollow', $robots, true );
				update_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', $is_noindex ? '1' : '2' );
				update_post_meta( $post_id, '_yoast_wpseo_meta-robots-nofollow', $is_nofollow ? '1' : '0' );
				$yoast_adv = array_values( array_intersect( $robots, [ 'noimageindex', 'noarchive', 'nosnippet' ] ) );
				update_post_meta( $post_id, '_yoast_wpseo_meta-robots-adv', implode( ',', $yoast_adv ) );

				// AIOSEO
				$aioseo_columns['robots_default']      = 0;
				$aioseo_columns['robots_noindex']      = $is_noindex ? 1 : 0;
				$aioseo_columns['robots_nofollow']     = $is_nofollow ? 1 : 0;
				$aioseo_columns['robots_noarchive']    = in_array( 'noarchive', $robots, true ) ? 1 : 0;
				$aioseo_columns['robots_nosnippet']    = in_array( 'nosnippet', $robots, true ) ? 1 : 0;
				$aioseo_columns['robots_noimageindex'] = in_array( 'noimageindex', $robots, true ) ? 1 : 0;

				// SEOPress (`yes` means enable noindex / nofollow)
				update_post_meta( $post_id, '_seopress_robots_index', $is_noindex ? 'yes' : '' );
				update_post_meta( $post_id, '_seopress_robots_follow', $is_nofollow ? 'yes' : '' );
				update_post_meta( $post_id, '_seopress_robots_archive', in_array( 'noarchive', $robots, true ) ? 'yes' : '' );
				update_post_meta( $post_id, '_seopress_robots_snippet', in_array( 'nosnippet', $robots, true ) ? 'yes' : '' );
				update_post_meta( $post_id, '_seopress_robots_imageindex', in_array( 'noimageindex', $robots, true ) ? 'yes' : '' );

				$updated_fields[] = 'robots';
			}

			if ( array_key_exists( 'advanced_robots', $payload ) && is_array( $payload['advanced_robots'] ) ) {
				$adv_clean = [];
				foreach ( [ 'max-snippet', 'max-video-preview', 'max-image-preview' ] as $adv_key ) {
					if ( isset( $payload['advanced_robots'][ $adv_key ] ) ) {
						$adv_clean[ $adv_key ] = sanitize_text_field( (string) $payload['advanced_robots'][ $adv_key ] );
					}
				}
				update_post_meta( $post_id, self::RM_MAP['advanced_robots'], $adv_clean );
				if ( isset( $adv_clean['max-snippet'] ) ) {
					$aioseo_columns['robots_max_snippet'] = (int) $adv_clean['max-snippet'];
				}
				if ( isset( $adv_clean['max-video-preview'] ) ) {
					$aioseo_columns['robots_max_videopreview'] = (int) $adv_clean['max-video-preview'];
				}
				if ( isset( $adv_clean['max-image-preview'] ) ) {
					$aioseo_columns['robots_max_imagepreview'] = sanitize_key( $adv_clean['max-image-preview'] );
				}
				$updated_fields[] = 'advanced_robots';
			}

			// ── 5. OpenGraph & Twitter Card Metadata ─────────────────────────────
			if ( array_key_exists( 'og_image_id', $payload ) ) {
				$og_id = absint( $payload['og_image_id'] );
				update_post_meta( $post_id, self::RM_MAP['og_image_id'], $og_id );
				update_post_meta( $post_id, self::YOAST_MAP['og_image_id'], (string) $og_id );
				update_post_meta( $post_id, self::SEOPRESS_MAP['og_image_id'], $og_id );
				$updated_fields[] = 'og_image_id';

				// Auto-populate og_image URL if attachment exists and og_image was not explicitly passed.
				if ( $og_id > 0 && ! array_key_exists( 'og_image', $payload ) ) {
					$resolved_url = wp_get_attachment_image_url( $og_id, 'full' );
					if ( $resolved_url ) {
						$payload['og_image'] = $resolved_url;
					}
				}
			}

			$social_text_fields = [
				'og_title',
				'og_description',
				'og_object_type',
				'twitter_title',
				'twitter_description',
				'twitter_card_type',
			];
			foreach ( $social_text_fields as $sfield ) {
				if ( array_key_exists( $sfield, $payload ) ) {
					$sval = sanitize_text_field( (string) $payload[ $sfield ] );
					if ( isset( self::RM_MAP[ $sfield ] ) ) {
						update_post_meta( $post_id, self::RM_MAP[ $sfield ], $sval );
					}
					if ( isset( self::YOAST_MAP[ $sfield ] ) ) {
						update_post_meta( $post_id, self::YOAST_MAP[ $sfield ], $sval );
					}
					if ( isset( self::AIOSEO_MAP[ $sfield ] ) ) {
						update_post_meta( $post_id, self::AIOSEO_MAP[ $sfield ], $sval );
					}
					if ( isset( self::SEOPRESS_MAP[ $sfield ] ) ) {
						update_post_meta( $post_id, self::SEOPRESS_MAP[ $sfield ], $sval );
					}
					$aioseo_columns[ $sfield ] = $sval;
					$updated_fields[]          = $sfield;
				}
			}

			foreach ( [ 'og_image', 'twitter_image' ] as $img_field ) {
				if ( array_key_exists( $img_field, $payload ) ) {
					$img_url = esc_url_raw( trim( (string) $payload[ $img_field ] ), [ 'http', 'https' ] );
					if ( isset( self::RM_MAP[ $img_field ] ) ) {
						update_post_meta( $post_id, self::RM_MAP[ $img_field ], $img_url );
					}
					if ( isset( self::YOAST_MAP[ $img_field ] ) ) {
						update_post_meta( $post_id, self::YOAST_MAP[ $img_field ], $img_url );
					}
					if ( isset( self::AIOSEO_MAP[ $img_field ] ) ) {
						update_post_meta( $post_id, self::AIOSEO_MAP[ $img_field ], $img_url );
					}
					if ( isset( self::SEOPRESS_MAP[ $img_field ] ) ) {
						update_post_meta( $post_id, self::SEOPRESS_MAP[ $img_field ], $img_url );
					}
					$updated_fields[] = $img_field;
				}
			}

			// ── 6. Primary Category (ID or Category Name/Slug) ───────────────────
			if ( array_key_exists( 'primary_category', $payload ) ) {
				$raw_cat = $payload['primary_category'];
				$cat_id  = 0;
				if ( is_numeric( $raw_cat ) ) {
					$cat_id = absint( $raw_cat );
				} elseif ( is_string( $raw_cat ) && '' !== trim( $raw_cat ) && class_exists( '\DirectRelay\Taxonomy_Manager' ) ) {
					$resolved = \DirectRelay\Taxonomy_Manager::get_or_create_category( trim( $raw_cat ) );
					if ( ! is_wp_error( $resolved ) ) {
						$cat_id = (int) $resolved;
					}
				}

				if ( $cat_id > 0 ) {
					// Ensure the post is also assigned to this category.
					wp_set_post_categories( $post_id, [ $cat_id ], true );
				}

				update_post_meta( $post_id, self::RM_MAP['primary_category'], $cat_id ?: '' );
				update_post_meta( $post_id, self::YOAST_MAP['primary_category'], $cat_id ?: '' );
				update_post_meta( $post_id, self::AIOSEO_MAP['primary_category'], $cat_id ?: '' );
				update_post_meta( $post_id, self::SEOPRESS_MAP['primary_category'], $cat_id ?: 'none' );
				$updated_fields[] = 'primary_category';
			}

			// ── 7. Pillar / Cornerstone Content Flag & Breadcrumb Title ──────────
			if ( array_key_exists( 'pillar_content', $payload ) ) {
				$is_pillar = self::to_bool( $payload['pillar_content'] );
				update_post_meta( $post_id, self::RM_MAP['pillar_content'], $is_pillar ? 'on' : '' );
				update_post_meta( $post_id, self::YOAST_MAP['pillar_content'], $is_pillar ? '1' : '' );
				update_post_meta( $post_id, self::AIOSEO_MAP['pillar_content'], $is_pillar ? 1 : 0 );
				$aioseo_columns['pillar_content'] = $is_pillar ? 1 : 0;
				$updated_fields[]                 = 'pillar_content';
			}

			if ( array_key_exists( 'breadcrumb_title', $payload ) ) {
				$bc = sanitize_text_field( (string) $payload['breadcrumb_title'] );
				update_post_meta( $post_id, self::RM_MAP['breadcrumb_title'], $bc );
				update_post_meta( $post_id, self::YOAST_MAP['breadcrumb_title'], $bc );
				update_post_meta( $post_id, self::SEOPRESS_MAP['breadcrumb_title'], $bc );
				$updated_fields[] = 'breadcrumb_title';
			}

			if ( array_key_exists( 'schema_type', $payload ) ) {
				$stype = sanitize_key( (string) $payload['schema_type'] );
				update_post_meta( $post_id, self::RM_MAP['schema_type'], $stype );
				$updated_fields[] = 'schema_type';
			}

			// ── 8. Structured JSON-LD Schemas (FAQ, HowTo, Article, Product, Review)
			if ( array_key_exists( 'faq_schema', $payload ) ) {
				$faq = self::sanitize_faq_schema( $payload['faq_schema'] );
				if ( is_wp_error( $faq ) ) {
					return $faq;
				}
				update_post_meta( $post_id, self::RM_MAP['faq_schema'], $faq );
				update_post_meta( $post_id, self::PRO_META_KEYS['faq_schema'], $faq );
				update_post_meta( $post_id, 'rank_math_schema_FAQPage', self::build_faq_json_ld( $faq ) );
				$updated_fields[] = 'faq_schema';
			}

			if ( array_key_exists( 'howto_schema', $payload ) ) {
				$howto = self::sanitize_howto_schema( $payload['howto_schema'] );
				if ( is_wp_error( $howto ) ) {
					return $howto;
				}
				update_post_meta( $post_id, self::PRO_META_KEYS['howto_schema'], $howto );
				update_post_meta( $post_id, 'rank_math_schema_HowTo', self::build_howto_json_ld( $howto ) );
				$updated_fields[] = 'howto_schema';
			}

			if ( array_key_exists( 'article_schema', $payload ) ) {
				$article = self::sanitize_article_schema( $payload['article_schema'], $post );
				if ( is_wp_error( $article ) ) {
					return $article;
				}
				update_post_meta( $post_id, self::PRO_META_KEYS['article_schema'], $article );
				update_post_meta( $post_id, self::RM_MAP['schema_type'], 'article' );
				update_post_meta( $post_id, 'rank_math_snippet_article_type', $article['type'] );
				update_post_meta( $post_id, '_yoast_wpseo_schema_article_type', $article['type'] );
				update_post_meta( $post_id, 'rank_math_schema_' . $article['type'], self::build_article_json_ld( $article, $post ) );
				$updated_fields[] = 'article_schema';
			}

			if ( array_key_exists( 'product_schema', $payload ) ) {
				$product = self::sanitize_product_schema( $payload['product_schema'], $post );
				if ( is_wp_error( $product ) ) {
					return $product;
				}
				update_post_meta( $post_id, self::PRO_META_KEYS['product_schema'], $product );
				update_post_meta( $post_id, self::RM_MAP['schema_type'], 'product' );
				update_post_meta( $post_id, 'rank_math_schema_Product', self::build_product_json_ld( $product, $post ) );
				$updated_fields[] = 'product_schema';
			}

			if ( array_key_exists( 'review_schema', $payload ) ) {
				$review = self::sanitize_review_schema( $payload['review_schema'], $post );
				if ( is_wp_error( $review ) ) {
					return $review;
				}
				update_post_meta( $post_id, self::PRO_META_KEYS['review_schema'], $review );
				update_post_meta( $post_id, self::RM_MAP['schema_type'], 'review' );
				update_post_meta( $post_id, 'rank_math_schema_Review', self::build_review_json_ld( $review, $post ) );
				$updated_fields[] = 'review_schema';
			}

			// Sync AIOSEO custom table (`{$wpdb->prefix}aioseo_posts`) if it exists on this site.
			if ( ! empty( $aioseo_columns ) ) {
				self::sync_aioseo_table( $post_id, $aioseo_columns );
			}

			return [
				'post_id'        => $post_id,
				'updated_fields' => array_values( array_unique( $updated_fields ) ),
				'updated_count'  => count( array_unique( $updated_fields ) ),
				'seo'            => self::read( $post_id ),
			];
		}

		/**
		 * Clear/reset all SEO metadata and structured JSON-LD schemas for a post.
		 *
		 * @param int $post_id Target post ID.
		 * @return array{post_id: int, deleted_keys: int}
		 */
		public static function clear( int $post_id ): array {
			$all_keys = array_unique( array_merge(
				array_values( self::RM_MAP ),
				array_values( self::YOAST_MAP ),
				array_values( self::AIOSEO_MAP ),
				array_values( self::SEOPRESS_MAP ),
				array_values( self::PRO_META_KEYS ),
				[
					'_yoast_wpseo_meta-robots-noindex',
					'_yoast_wpseo_meta-robots-nofollow',
					'_yoast_wpseo_meta-robots-adv',
					'_yoast_wpseo_schema_article_type',
					'_seopress_robots_index',
					'_seopress_robots_follow',
					'_seopress_robots_archive',
					'_seopress_robots_snippet',
					'_seopress_robots_imageindex',
					'rank_math_snippet_article_type',
					'rank_math_schema_FAQPage',
					'rank_math_schema_HowTo',
					'rank_math_schema_Article',
					'rank_math_schema_NewsArticle',
					'rank_math_schema_BlogPosting',
					'rank_math_schema_TechArticle',
					'rank_math_schema_Product',
					'rank_math_schema_Review',
				]
			) );

			$deleted = 0;
			foreach ( $all_keys as $meta_key ) {
				if ( delete_post_meta( $post_id, $meta_key ) ) {
					++$deleted;
				}
			}

			return [
				'post_id'      => $post_id,
				'deleted_keys' => $deleted,
			];
		}

		/* ── Schema Sanitizers & JSON-LD Builders ────────────────────────────── */

		/**
		 * Sanitize `faq_schema` array of `{ question, answer }` items.
		 */
		public static function sanitize_faq_schema( mixed $raw ): array|\WP_Error {
			if ( empty( $raw ) ) {
				return [];
			}
			if ( is_string( $raw ) ) {
				$decoded = json_decode( $raw, true );
				if ( is_array( $decoded ) ) {
					$raw = $decoded;
				}
			}
			if ( ! is_array( $raw ) ) {
				return new \WP_Error(
					'directrelay_pro_invalid_faq_schema',
					__( 'faq_schema must be an array of {question, answer} objects.', 'directrelay-pro' ),
					[ 'status' => 400 ]
				);
			}

			// Handle wrapper object `{ questions: [...] }` if supplied.
			if ( isset( $raw['questions'] ) && is_array( $raw['questions'] ) ) {
				$raw = $raw['questions'];
			}

			$clean = [];
			foreach ( $raw as $item ) {
				if ( ! is_array( $item ) ) {
					continue;
				}
				$q = sanitize_text_field( (string) ( $item['question'] ?? $item['title'] ?? $item['name'] ?? '' ) );
				$a = wp_kses_post( (string) ( $item['answer'] ?? $item['text'] ?? $item['content'] ?? '' ) );
				if ( '' !== $q && '' !== $a ) {
					$clean[] = [
						'question' => $q,
						'answer'   => $a,
					];
				}
			}
			return $clean;
		}

		/**
		 * Build Schema.org `FAQPage` JSON-LD array.
		 */
		public static function build_faq_json_ld( array $faq_items ): array {
			$entities = [];
			foreach ( $faq_items as $item ) {
				$entities[] = [
					'@type'          => 'Question',
					'name'           => $item['question'],
					'acceptedAnswer' => [
						'@type' => 'Answer',
						'text'  => $item['answer'],
					],
				];
			}
			return [
				'@context'   => 'https://schema.org',
				'@type'      => 'FAQPage',
				'mainEntity' => $entities,
			];
		}

		/**
		 * Sanitize `howto_schema` payload.
		 */
		public static function sanitize_howto_schema( mixed $raw ): array|\WP_Error {
			if ( empty( $raw ) ) {
				return [];
			}
			if ( is_string( $raw ) ) {
				$raw = json_decode( $raw, true );
			}
			if ( ! is_array( $raw ) || empty( $raw['steps'] ) || ! is_array( $raw['steps'] ) ) {
				return new \WP_Error(
					'directrelay_pro_invalid_howto_schema',
					__( 'howto_schema requires a non-empty "steps" array.', 'directrelay-pro' ),
					[ 'status' => 400 ]
				);
			}

			$steps = [];
			foreach ( $raw['steps'] as $idx => $step ) {
				/* translators: %d: step number */
				$default_step_name = sprintf( __( 'Step %d', 'directrelay-pro' ), $idx + 1 );
				if ( is_string( $step ) ) {
					$steps[] = [
						'name'  => $default_step_name,
						'text'  => wp_kses_post( $step ),
						'image' => '',
						'url'   => '',
					];
					continue;
				}
				if ( ! is_array( $step ) ) {
					continue;
				}
				$sname = sanitize_text_field( (string) ( $step['name'] ?? $step['title'] ?? $default_step_name ) );
				$stext = wp_kses_post( (string) ( $step['text'] ?? $step['description'] ?? '' ) );
				if ( '' === $stext ) {
					continue;
				}
				$steps[] = [
					'name'  => $sname,
					'text'  => $stext,
					'image' => ! empty( $step['image'] ) ? esc_url_raw( (string) $step['image'], [ 'http', 'https' ] ) : '',
					'url'   => ! empty( $step['url'] ) ? esc_url_raw( (string) $step['url'], [ 'http', 'https' ] ) : '',
				];
			}

			if ( empty( $steps ) ) {
				return new \WP_Error(
					'directrelay_pro_invalid_howto_steps',
					__( 'howto_schema steps must each contain valid step text.', 'directrelay-pro' ),
					[ 'status' => 400 ]
				);
			}

			$supply = [];
			if ( ! empty( $raw['supply'] ) && is_array( $raw['supply'] ) ) {
				foreach ( $raw['supply'] as $s ) {
					$s_name = is_array( $s ) ? sanitize_text_field( (string) ( $s['name'] ?? '' ) ) : sanitize_text_field( (string) $s );
					if ( '' !== $s_name ) {
						$supply[] = $s_name;
					}
				}
			}

			$tools = [];
			if ( ! empty( $raw['tool'] ) && is_array( $raw['tool'] ) ) {
				foreach ( $raw['tool'] as $t ) {
					$t_name = is_array( $t ) ? sanitize_text_field( (string) ( $t['name'] ?? '' ) ) : sanitize_text_field( (string) $t );
					if ( '' !== $t_name ) {
						$tools[] = $t_name;
					}
				}
			}

			return [
				'name'           => sanitize_text_field( (string) ( $raw['name'] ?? $raw['title'] ?? '' ) ),
				'description'    => sanitize_textarea_field( (string) ( $raw['description'] ?? '' ) ),
				'total_time'     => sanitize_text_field( (string) ( $raw['total_time'] ?? $raw['totalTime'] ?? '' ) ),
				'estimated_cost' => sanitize_text_field( (string) ( $raw['estimated_cost'] ?? '' ) ),
				'currency'       => sanitize_text_field( (string) ( $raw['currency'] ?? 'USD' ) ),
				'supply'         => $supply,
				'tool'           => $tools,
				'steps'          => $steps,
			];
		}

		/**
		 * Build Schema.org `HowTo` JSON-LD array.
		 */
		public static function build_howto_json_ld( array $howto ): array {
			$ld = [
				'@context'    => 'https://schema.org',
				'@type'       => 'HowTo',
				'name'        => $howto['name'] ?? '',
				'description' => $howto['description'] ?? '',
			];
			if ( ! empty( $howto['total_time'] ) ) {
				$ld['totalTime'] = $howto['total_time'];
			}
			if ( ! empty( $howto['estimated_cost'] ) ) {
				$ld['estimatedCost'] = [
					'@type'    => 'MonetaryAmount',
					'currency' => $howto['currency'] ?: 'USD',
					'value'    => $howto['estimated_cost'],
				];
			}
			if ( ! empty( $howto['supply'] ) ) {
				$ld['supply'] = array_map(
					static fn( string $s ): array => [ '@type' => 'HowToSupply', 'name' => $s ],
					$howto['supply']
				);
			}
			if ( ! empty( $howto['tool'] ) ) {
				$ld['tool'] = array_map(
					static fn( string $t ): array => [ '@type' => 'HowToTool', 'name' => $t ],
					$howto['tool']
				);
			}
			$ld['step'] = [];
			foreach ( $howto['steps'] ?? [] as $idx => $s ) {
				$step_ld = [
					'@type'    => 'HowToStep',
					'position' => $idx + 1,
					'name'     => $s['name'],
					'text'     => $s['text'],
				];
				if ( ! empty( $s['image'] ) ) {
					$step_ld['image'] = $s['image'];
				}
				if ( ! empty( $s['url'] ) ) {
					$step_ld['url'] = $s['url'];
				}
				$ld['step'][] = $step_ld;
			}
			return $ld;
		}

		/**
		 * Sanitize `article_schema` payload (`Article`, `NewsArticle`, `BlogPosting`, `TechArticle`).
		 */
		public static function sanitize_article_schema( mixed $raw, \WP_Post $post ): array|\WP_Error {
			if ( empty( $raw ) ) {
				return [];
			}
			if ( is_string( $raw ) ) {
				$raw = json_decode( $raw, true );
			}
			if ( ! is_array( $raw ) ) {
				return new \WP_Error(
					'directrelay_pro_invalid_article_schema',
					__( 'article_schema must be an object.', 'directrelay-pro' ),
					[ 'status' => 400 ]
				);
			}

			$allowed_types = [ 'Article', 'NewsArticle', 'BlogPosting', 'TechArticle', 'ScholarlyArticle' ];
			$req_type      = sanitize_text_field( (string) ( $raw['type'] ?? $raw['@type'] ?? 'Article' ) );
			if ( ! in_array( $req_type, $allowed_types, true ) ) {
				$req_type = 'Article';
			}

			$speakable = [];
			if ( ! empty( $raw['speakable_selectors'] ) && is_array( $raw['speakable_selectors'] ) ) {
				foreach ( $raw['speakable_selectors'] as $sel ) {
					$clean_sel = sanitize_text_field( (string) $sel );
					if ( '' !== $clean_sel ) {
						$speakable[] = $clean_sel;
					}
				}
			}

			return [
				'type'                => $req_type,
				'headline'            => sanitize_text_field( (string) ( $raw['headline'] ?? $post->post_title ) ),
				'description'         => sanitize_textarea_field( (string) ( $raw['description'] ?? $post->post_excerpt ) ),
				'author_name'         => sanitize_text_field( (string) ( $raw['author_name'] ?? get_the_author_meta( 'display_name', (int) $post->post_author ) ) ),
				'author_url'          => ! empty( $raw['author_url'] ) ? esc_url_raw( (string) $raw['author_url'], [ 'http', 'https' ] ) : '',
				'publisher_name'      => sanitize_text_field( (string) ( $raw['publisher_name'] ?? get_bloginfo( 'name' ) ) ),
				'publisher_logo'      => ! empty( $raw['publisher_logo'] ) ? esc_url_raw( (string) $raw['publisher_logo'], [ 'http', 'https' ] ) : '',
				'image'               => ! empty( $raw['image'] ) ? esc_url_raw( (string) $raw['image'], [ 'http', 'https' ] ) : (string) get_the_post_thumbnail_url( $post->ID, 'full' ),
				'date_published'      => sanitize_text_field( (string) ( $raw['date_published'] ?? get_the_date( 'c', $post ) ) ),
				'date_modified'       => sanitize_text_field( (string) ( $raw['date_modified'] ?? get_the_modified_date( 'c', $post ) ) ),
				'speakable_selectors' => $speakable,
			];
		}

		/**
		 * Build Schema.org `Article` / `NewsArticle` / `BlogPosting` JSON-LD array.
		 */
		public static function build_article_json_ld( array $article, \WP_Post $post ): array {
			$ld = [
				'@context'         => 'https://schema.org',
				'@type'            => $article['type'] ?? 'Article',
				'headline'         => $article['headline'] ?: $post->post_title,
				'description'      => $article['description'] ?: wp_trim_words( wp_strip_all_tags( $post->post_content ), 30 ),
				'datePublished'    => $article['date_published'] ?: get_the_date( 'c', $post ),
				'dateModified'     => $article['date_modified'] ?: get_the_modified_date( 'c', $post ),
				'mainEntityOfPage' => [
					'@type' => 'WebPage',
					'@id'   => get_permalink( $post->ID ),
				],
				'author'           => [
					'@type' => 'Person',
					'name'  => $article['author_name'] ?: get_bloginfo( 'name' ),
				],
				'publisher'        => [
					'@type' => 'Organization',
					'name'  => $article['publisher_name'] ?: get_bloginfo( 'name' ),
				],
			];

			if ( ! empty( $article['author_url'] ) ) {
				$ld['author']['url'] = $article['author_url'];
			}
			if ( ! empty( $article['publisher_logo'] ) ) {
				$ld['publisher']['logo'] = [
					'@type' => 'ImageObject',
					'url'   => $article['publisher_logo'],
				];
			}
			if ( ! empty( $article['image'] ) ) {
				$ld['image'] = [ $article['image'] ];
			}
			if ( ! empty( $article['speakable_selectors'] ) ) {
				$ld['speakable'] = [
					'@type'       => 'SpeakableSpecification',
					'cssSelector' => $article['speakable_selectors'],
				];
			}

			return $ld;
		}

		/**
		 * Sanitize `product_schema` payload.
		 */
		public static function sanitize_product_schema( mixed $raw, \WP_Post $post ): array|\WP_Error {
			if ( empty( $raw ) ) {
				return [];
			}
			if ( is_string( $raw ) ) {
				$raw = json_decode( $raw, true );
			}
			if ( ! is_array( $raw ) ) {
				return new \WP_Error(
					'directrelay_pro_invalid_product_schema',
					__( 'product_schema must be an object.', 'directrelay-pro' ),
					[ 'status' => 400 ]
				);
			}

			$name = sanitize_text_field( (string) ( $raw['name'] ?? $post->post_title ) );
			if ( '' === $name ) {
				return new \WP_Error(
					'directrelay_pro_invalid_product_name',
					__( 'product_schema requires a product name.', 'directrelay-pro' ),
					[ 'status' => 400 ]
				);
			}

			return [
				'name'              => $name,
				'description'       => sanitize_textarea_field( (string) ( $raw['description'] ?? $post->post_excerpt ) ),
				'sku'               => sanitize_text_field( (string) ( $raw['sku'] ?? '' ) ),
				'mpn'               => sanitize_text_field( (string) ( $raw['mpn'] ?? '' ) ),
				'brand'             => sanitize_text_field( (string) ( $raw['brand'] ?? get_bloginfo( 'name' ) ) ),
				'image'             => ! empty( $raw['image'] ) ? esc_url_raw( (string) $raw['image'], [ 'http', 'https' ] ) : (string) get_the_post_thumbnail_url( $post->ID, 'full' ),
				'price'             => isset( $raw['price'] ) ? (string) floatval( $raw['price'] ) : '',
				'currency'          => strtoupper( sanitize_text_field( (string) ( $raw['currency'] ?? 'USD' ) ) ),
				'availability'      => sanitize_text_field( (string) ( $raw['availability'] ?? 'InStock' ) ),
				'condition'         => sanitize_text_field( (string) ( $raw['condition'] ?? 'NewCondition' ) ),
				'price_valid_until' => sanitize_text_field( (string) ( $raw['price_valid_until'] ?? '' ) ),
				'url'               => ! empty( $raw['url'] ) ? esc_url_raw( (string) $raw['url'], [ 'http', 'https' ] ) : get_permalink( $post->ID ),
				'rating_value'      => isset( $raw['rating_value'] ) ? floatval( $raw['rating_value'] ) : null,
				'review_count'      => isset( $raw['review_count'] ) ? absint( $raw['review_count'] ) : null,
			];
		}

		/**
		 * Build Schema.org `Product` JSON-LD array.
		 */
		public static function build_product_json_ld( array $product, \WP_Post $post ): array {
			$ld = [
				'@context'    => 'https://schema.org',
				'@type'       => 'Product',
				'name'        => $product['name'],
				'description' => $product['description'],
			];
			if ( ! empty( $product['sku'] ) ) {
				$ld['sku'] = $product['sku'];
			}
			if ( ! empty( $product['mpn'] ) ) {
				$ld['mpn'] = $product['mpn'];
			}
			if ( ! empty( $product['image'] ) ) {
				$ld['image'] = [ $product['image'] ];
			}
			if ( ! empty( $product['brand'] ) ) {
				$ld['brand'] = [
					'@type' => 'Brand',
					'name'  => $product['brand'],
				];
			}
			if ( '' !== ( $product['price'] ?? '' ) ) {
				$avail = str_starts_with( $product['availability'], 'http' )
					? $product['availability']
					: 'https://schema.org/' . ltrim( $product['availability'], '/' );
				$cond  = str_starts_with( $product['condition'], 'http' )
					? $product['condition']
					: 'https://schema.org/' . ltrim( $product['condition'], '/' );

				$offer = [
					'@type'         => 'Offer',
					'url'           => $product['url'] ?: get_permalink( $post->ID ),
					'priceCurrency' => $product['currency'] ?: 'USD',
					'price'         => $product['price'],
					'availability'  => $avail,
					'itemCondition' => $cond,
				];
				if ( ! empty( $product['price_valid_until'] ) ) {
					$offer['priceValidUntil'] = $product['price_valid_until'];
				}
				$ld['offers'] = $offer;
			}
			if ( ! empty( $product['rating_value'] ) && ! empty( $product['review_count'] ) ) {
				$ld['aggregateRating'] = [
					'@type'       => 'AggregateRating',
					'ratingValue' => $product['rating_value'],
					'reviewCount' => $product['review_count'],
				];
			}
			return $ld;
		}

		/**
		 * Sanitize `review_schema` payload.
		 */
		public static function sanitize_review_schema( mixed $raw, \WP_Post $post ): array|\WP_Error {
			if ( empty( $raw ) ) {
				return [];
			}
			if ( is_string( $raw ) ) {
				$raw = json_decode( $raw, true );
			}
			if ( ! is_array( $raw ) ) {
				return new \WP_Error(
					'directrelay_pro_invalid_review_schema',
					__( 'review_schema must be an object.', 'directrelay-pro' ),
					[ 'status' => 400 ]
				);
			}

			$rating = isset( $raw['rating_value'] ) ? floatval( $raw['rating_value'] ) : 0.0;
			if ( $rating <= 0 ) {
				return new \WP_Error(
					'directrelay_pro_invalid_review_rating',
					__( 'review_schema requires a positive rating_value.', 'directrelay-pro' ),
					[ 'status' => 400 ]
				);
			}

			$pros = [];
			if ( ! empty( $raw['pros'] ) && is_array( $raw['pros'] ) ) {
				foreach ( $raw['pros'] as $p ) {
					$p_clean = sanitize_text_field( (string) $p );
					if ( '' !== $p_clean ) {
						$pros[] = $p_clean;
					}
				}
			}

			$cons = [];
			if ( ! empty( $raw['cons'] ) && is_array( $raw['cons'] ) ) {
				foreach ( $raw['cons'] as $c ) {
					$c_clean = sanitize_text_field( (string) $c );
					if ( '' !== $c_clean ) {
						$cons[] = $c_clean;
					}
				}
			}

			return [
				'item_name'    => sanitize_text_field( (string) ( $raw['item_name'] ?? $post->post_title ) ),
				'item_type'    => sanitize_text_field( (string) ( $raw['item_type'] ?? 'Product' ) ),
				'rating_value' => $rating,
				'best_rating'  => isset( $raw['best_rating'] ) ? floatval( $raw['best_rating'] ) : 5.0,
				'worst_rating' => isset( $raw['worst_rating'] ) ? floatval( $raw['worst_rating'] ) : 1.0,
				'author_name'  => sanitize_text_field( (string) ( $raw['author_name'] ?? get_the_author_meta( 'display_name', (int) $post->post_author ) ) ),
				'review_body'  => sanitize_textarea_field( (string) ( $raw['review_body'] ?? $post->post_excerpt ) ),
				'pros'         => $pros,
				'cons'         => $cons,
			];
		}

		/**
		 * Build Schema.org `Review` JSON-LD array (including Google Pros & Cons `positiveNotes` / `negativeNotes`).
		 */
		public static function build_review_json_ld( array $review, \WP_Post $post ): array {
			$ld = [
				'@context'     => 'https://schema.org',
				'@type'        => 'Review',
				'itemReviewed' => [
					'@type' => $review['item_type'] ?: 'Product',
					'name'  => $review['item_name'] ?: $post->post_title,
				],
				'reviewRating' => [
					'@type'       => 'Rating',
					'ratingValue' => $review['rating_value'],
					'bestRating'  => $review['best_rating'] ?? 5,
					'worstRating' => $review['worst_rating'] ?? 1,
				],
				'author'       => [
					'@type' => 'Person',
					'name'  => $review['author_name'] ?: get_bloginfo( 'name' ),
				],
			];

			if ( ! empty( $review['review_body'] ) ) {
				$ld['reviewBody'] = $review['review_body'];
			}
			if ( ! empty( $review['pros'] ) ) {
				$ld['positiveNotes'] = [
					'@type'           => 'ItemList',
					'itemListElement' => array_map(
						static fn( string $note, int $i ): array => [
							'@type'    => 'ListItem',
							'position' => $i + 1,
							'name'     => $note,
						],
						$review['pros'],
						array_keys( $review['pros'] )
					),
				];
			}
			if ( ! empty( $review['cons'] ) ) {
				$ld['negativeNotes'] = [
					'@type'           => 'ItemList',
					'itemListElement' => array_map(
						static fn( string $note, int $i ): array => [
							'@type'    => 'ListItem',
							'position' => $i + 1,
							'name'     => $note,
						],
						$review['cons'],
						array_keys( $review['cons'] )
					),
				];
			}

			return $ld;
		}

		/**
		 * Output structured JSON-LD `<script type="application/ld+json">` graphs in `wp_head`
		 * on singular posts/pages for any schema written via DirectRelay Pro.
		 */
		public static function render_frontend_json_ld(): void {
			if ( ! is_singular() ) {
				return;
			}
			$post = get_queried_object();
			if ( ! ( $post instanceof \WP_Post ) ) {
				return;
			}

			$graphs = [];

			$faq = get_post_meta( $post->ID, self::PRO_META_KEYS['faq_schema'], true );
			if ( is_array( $faq ) && ! empty( $faq ) ) {
				$graphs[] = self::build_faq_json_ld( $faq );
			}

			$howto = get_post_meta( $post->ID, self::PRO_META_KEYS['howto_schema'], true );
			if ( is_array( $howto ) && ! empty( $howto['steps'] ) ) {
				$graphs[] = self::build_howto_json_ld( $howto );
			}

			$article = get_post_meta( $post->ID, self::PRO_META_KEYS['article_schema'], true );
			if ( is_array( $article ) && ! empty( $article['headline'] ) ) {
				$graphs[] = self::build_article_json_ld( $article, $post );
			}

			$product = get_post_meta( $post->ID, self::PRO_META_KEYS['product_schema'], true );
			if ( is_array( $product ) && ! empty( $product['name'] ) ) {
				$graphs[] = self::build_product_json_ld( $product, $post );
			}

			$review = get_post_meta( $post->ID, self::PRO_META_KEYS['review_schema'], true );
			if ( is_array( $review ) && ! empty( $review['rating_value'] ) ) {
				$graphs[] = self::build_review_json_ld( $review, $post );
			}

			if ( empty( $graphs ) ) {
				return;
			}

			foreach ( $graphs as $graph ) {
				echo "\n" . '<script type="application/ld+json" class="directrelay-pro-schema">' .
					wp_json_encode( $graph, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) .
					"</script>\n";
			}
		}

		/**
		 * Synchronize SEO fields with AIOSEO's dedicated `{$wpdb->prefix}aioseo_posts` table when present.
		 *
		 * @param int   $post_id Post ID.
		 * @param array $columns Column map to upsert.
		 */
		private static function sync_aioseo_table( int $post_id, array $columns ): void {
			global $wpdb;
			$table = $wpdb->prefix . 'aioseo_posts';
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
			if ( $exists !== $table ) {
				return;
			}

			// Inspect actual columns in `wp_aioseo_posts` to avoid SQL errors across AIOSEO versions.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$table_cols = $wpdb->get_col( "DESC {$table}", 0 ) ?: [];
			$valid_data = array_intersect_key( $columns, array_flip( $table_cols ) );
			if ( empty( $valid_data ) ) {
				return;
			}

			$now = current_time( 'mysql', true );
			if ( in_array( 'updated', $table_cols, true ) ) {
				$valid_data['updated'] = $now;
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$row_id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE post_id = %d", $post_id ) );
			if ( $row_id ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->update( $table, $valid_data, [ 'post_id' => $post_id ] );
			} else {
				$valid_data['post_id'] = $post_id;
				if ( in_array( 'created', $table_cols, true ) ) {
					$valid_data['created'] = $now;
				}
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
				$wpdb->insert( $table, $valid_data );
			}
		}

		/**
		 * Full discoverable SEO field list for `/discovery/fields`.
		 */
		public static function get_discoverable_seo_fields(): array {
			return [
				[ 'name' => 'seo[focus_keyword]',       'label' => 'Primary Focus Keyword',                    'type' => 'string' ],
				[ 'name' => 'seo[secondary_keywords]',  'label' => 'Secondary Keywords (array or CSV)',        'type' => 'array' ],
				[ 'name' => 'seo[title]',               'label' => 'SEO Meta Title',                           'type' => 'string' ],
				[ 'name' => 'seo[description]',         'label' => 'SEO Meta Description',                     'type' => 'string' ],
				[ 'name' => 'seo[canonical_url]',       'label' => 'Canonical URL',                            'type' => 'string' ],
				[ 'name' => 'seo[robots]',              'label' => 'Robots Directives (index,follow,...)',     'type' => 'array' ],
				[ 'name' => 'seo[advanced_robots]',     'label' => 'Advanced Robots (max-snippet, etc.)',      'type' => 'object' ],
				[ 'name' => 'seo[primary_category]',    'label' => 'Primary Category (ID or Name)',            'type' => 'string' ],
				[ 'name' => 'seo[pillar_content]',      'label' => 'Pillar / Cornerstone Content Flag',        'type' => 'boolean' ],
				[ 'name' => 'seo[breadcrumb_title]',    'label' => 'Breadcrumb Title Override',                'type' => 'string' ],
				[ 'name' => 'seo[og_title]',            'label' => 'OpenGraph Title',                          'type' => 'string' ],
				[ 'name' => 'seo[og_description]',      'label' => 'OpenGraph Description',                    'type' => 'string' ],
				[ 'name' => 'seo[og_image]',            'label' => 'OpenGraph Image URL',                      'type' => 'string' ],
				[ 'name' => 'seo[og_image_id]',         'label' => 'OpenGraph Image Attachment ID',            'type' => 'integer' ],
				[ 'name' => 'seo[twitter_title]',       'label' => 'Twitter/X Card Title',                     'type' => 'string' ],
				[ 'name' => 'seo[twitter_description]', 'label' => 'Twitter/X Card Description',               'type' => 'string' ],
				[ 'name' => 'seo[twitter_image]',       'label' => 'Twitter/X Card Image URL',                 'type' => 'string' ],
				[ 'name' => 'seo[twitter_card_type]',   'label' => 'Twitter/X Card Type',                      'type' => 'string' ],
				[ 'name' => 'seo[faq_schema]',          'label' => 'FAQ JSON-LD Schema ([{question,answer}])', 'type' => 'array' ],
				[ 'name' => 'seo[howto_schema]',        'label' => 'HowTo JSON-LD Schema ({name,steps[]})',    'type' => 'object' ],
				[ 'name' => 'seo[article_schema]',      'label' => 'Article / NewsArticle JSON-LD Schema',     'type' => 'object' ],
				[ 'name' => 'seo[product_schema]',      'label' => 'Product JSON-LD Schema',                   'type' => 'object' ],
				[ 'name' => 'seo[review_schema]',       'label' => 'Review JSON-LD Schema (with Pros/Cons)',   'type' => 'object' ],
			];
		}

		/* ── Internal Helpers ────────────────────────────────────────────────── */

		private static function normalize_robots( mixed $raw ): array {
			if ( is_string( $raw ) ) {
				$raw = explode( ',', $raw );
			}
			if ( ! is_array( $raw ) ) {
				return [ 'index', 'follow' ];
			}
			$clean = [];
			foreach ( $raw as $directive ) {
				$d = strtolower( sanitize_key( (string) $directive ) );
				if ( in_array( $d, self::ALLOWED_ROBOTS, true ) ) {
					$clean[] = $d;
				}
			}
			return ! empty( $clean ) ? array_values( array_unique( $clean ) ) : [ 'index', 'follow' ];
		}

		private static function to_bool( mixed $val ): bool {
			if ( is_bool( $val ) ) {
				return $val;
			}
			if ( is_numeric( $val ) ) {
				return (int) $val !== 0;
			}
			if ( is_string( $val ) ) {
				return in_array( strtolower( trim( $val ) ), [ '1', 'true', 'yes', 'on' ], true );
			}
			return false;
		}

		private static function is_empty_val( mixed $val ): bool {
			return '' === $val || null === $val || false === $val || ( is_array( $val ) && empty( $val ) );
		}
	}
	}


}

namespace DirectRelay\Pro\REST {

	defined( 'ABSPATH' ) || exit;

	use DirectRelay\Agent_Profiles;
	use DirectRelay\Pro\SEO_Write_Engine;

	/**
	 * Dedicated Base Controller for all DirectRelay Pro REST Controllers.
	 *
	 * Unconditionally declared in `DirectRelay\Pro\REST` so PHP early-binds all
	 * child Pro controllers at compile time without ever colliding with
	 * `DirectRelay\REST\Base_Controller`.
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\Pro_Base_Controller', false ) ) {
	abstract class Pro_Base_Controller {

		protected const NS = 'directrelay/v1';

		protected static function guard( \WP_REST_Request $req, string $scope ): bool|\WP_Error {
			$has_api_auth = ! empty( $req->get_header( 'authorization' ) ) || ! empty( $req->get_header( 'x-api-key' ) );

			if ( ! $has_api_auth && is_user_logged_in() && current_user_can( 'manage_options' ) ) {
				$req->set_param( '_amp_key', [
					'id'           => 0,
					'user_id'      => get_current_user_id(),
					'label'        => 'Native Admin Session',
					'is_full'      => true,
					'scopes_array' => [],
				] );
				$req->set_param( '_amp_start', microtime( true ) );
				$req->set_param( '_amp_rid', wp_generate_uuid4() );
				return true;
			}

			if ( ! class_exists( '\DirectRelay\Api_Auth' ) ) {
				return new \WP_Error( 'directrelay_core_missing', 'DirectRelay core authentication module is not loaded.', [ 'status' => 503 ] );
			}

			$key = \DirectRelay\Api_Auth::authenticate( $req );
			if ( is_wp_error( $key ) ) {
				return $key;
			}

			$ip = \DirectRelay\Api_Auth::client_ip();
			if ( \DirectRelay\Api_Auth::is_ip_whitelisted( $ip ) || ! class_exists( '\DirectRelay\Rate_Limiter' ) ) {
				$rate = [
					'allowed'   => true,
					'remaining' => 999999,
					'reset_at'  => time() + 3600,
					'limit'     => 999999,
				];
			} else {
				$rate = \DirectRelay\Rate_Limiter::check( (int) $key['id'] );
			}

			add_filter( 'rest_post_dispatch', static function ( \WP_REST_Response $r ) use ( $rate ): \WP_REST_Response {
				$r->header( 'X-RateLimit-Limit', (string) $rate['limit'] );
				$r->header( 'X-RateLimit-Remaining', (string) $rate['remaining'] );
				$r->header( 'X-RateLimit-Reset', (string) $rate['reset_at'] );
				return $r;
			} );

			if ( ! $rate['allowed'] ) {
				return new \WP_Error(
					'amp_rate_limited',
					sprintf( 'Rate limit exceeded. Retry after %s', gmdate( 'c', $rate['reset_at'] ) ),
					[ 'status' => 429 ]
				);
			}

			if ( $scope && ! \DirectRelay\Api_Auth::has_scope( $key, $scope ) ) {
				return new \WP_Error(
					'amp_forbidden',
					sprintf( 'Scope required: %s', $scope ),
					[ 'status' => 403 ]
				);
			}

			if ( class_exists( '\DirectRelay\Agent_Profiles' ) ) {
				$agent_check = \DirectRelay\Agent_Profiles::can_perform( $key, $scope );
				if ( is_wp_error( $agent_check ) ) {
					return $agent_check;
				}
			}

			if ( in_array( $scope, [ 'posts:write', 'posts:publish', 'bulk:write', 'universal:write' ], true ) && class_exists( '\DirectRelay\Guardrails_Manager' ) ) {
				$daily_check = \DirectRelay\Guardrails_Manager::check_daily_limit( $key );
				if ( is_wp_error( $daily_check ) ) {
					return $daily_check;
				}
			}

			if ( ! empty( $key['user_id'] ) ) {
				wp_set_current_user( (int) $key['user_id'] );
			}

			$req->set_param( '_amp_key', $key );
			$req->set_param( '_amp_start', microtime( true ) );
			$req->set_param( '_amp_rid', wp_generate_uuid4() );
			return true;
		}

		protected static function ok( \WP_REST_Request $req, mixed $data, int $status = 200, string $action = '', ?int $obj_id = null, string $obj_type = '' ): \WP_REST_Response {
			self::write_log( $req, $status, 'success', $action, $obj_id, $obj_type );
			$rid = (string) ( $req->get_param( '_amp_rid' ) ?: wp_generate_uuid4() );
			$r   = new \WP_REST_Response( [ 'success' => true, 'data' => $data, 'request_id' => $rid ], $status );
			$r->header( 'X-Request-ID', $rid );
			return $r;
		}

		protected static function fail( \WP_REST_Request $req, \WP_Error $err, string $action = '' ): \WP_Error {
			self::write_log( $req, (int) ( $err->get_error_data()['status'] ?? 400 ), $err->get_error_message(), $action );
			return $err;
		}

		private static function write_log( \WP_REST_Request $req, int $status, string $msg, string $action, ?int $obj_id = null, string $obj_type = '' ): void {
			if ( ! class_exists( '\DirectRelay\Activity_Logger' ) ) {
				return;
			}
			$key   = $req->get_param( '_amp_key' );
			$start = (float) ( $req->get_param( '_amp_start' ) ?? microtime( true ) );
			$body  = $req->get_json_params() ?: [];
			$sanitized_body = $body;
			unset( $sanitized_body['content'], $sanitized_body['post_content'], $sanitized_body['body'] );
			if ( isset( $body['content'] ) ) {
				$sanitized_body['content_preview'] = substr( wp_strip_all_tags( (string) $body['content'] ), 0, 150 ) . '...';
			}

			\DirectRelay\Activity_Logger::write( [
				'request_uuid'    => $req->get_param( '_amp_rid' ) ?: wp_generate_uuid4(),
				'key_id'          => $key['id'] ?? null,
				'user_id'         => $key['user_id'] ?? null,
				'method'          => $req->get_method(),
				'endpoint'        => $req->get_route(),
				'action'          => $action ?: str_replace( '/', '_', trim( $req->get_route(), '/' ) ),
				'object_type'     => $obj_type ?: null,
				'object_id'       => $obj_id,
				'http_status'     => $status,
				'response_msg'    => substr( $msg, 0, 200 ),
				'duration_ms'     => (int) round( ( microtime( true ) - $start ) * 1000 ),
				'request_payload' => $sanitized_body,
				'is_replay'       => (bool) $req->get_param( '_amp_is_replay' ),
			] );
		}

		protected static function pagination_args(): array {
			return [
				'per_page' => [ 'type' => 'integer', 'default' => 20, 'minimum' => 1, 'maximum' => 100 ],
				'page'     => [ 'type' => 'integer', 'default' => 1,  'minimum' => 1 ],
				'search'   => [ 'type' => 'string' ],
				'orderby'  => [ 'type' => 'string', 'enum' => [ 'date', 'modified', 'title', 'id' ], 'default' => 'date' ],
				'order'    => [ 'type' => 'string', 'enum' => [ 'ASC', 'DESC' ], 'default' => 'DESC' ],
			];
		}
	}
	}

	/**
	 * REST Controller for Bidirectional SEO Read/Write/Delete & Provider Discovery.
	 *
	 * Registered via the `directrelay_ext_register_routes` action.
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\SEO_Write_Controller', false ) ) {
	final class SEO_Write_Controller extends Pro_Base_Controller {

		public static function register(): void {
			$types = 'posts|pages';

			// 1. Register PUT/PATCH/POST and DELETE on `/(posts|pages)/(?P<id>\d+)/seo`
			register_rest_route(
				self::NS,
				"/(?P<type>{$types})/(?P<id>\\d+)/seo",
				[
					[
						'methods'             => \WP_REST_Server::EDITABLE, // POST, PUT, PATCH
						'callback'            => [ self::class, 'update' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'seo:write' ),
					],
					[
						'methods'             => \WP_REST_Server::DELETABLE, // DELETE
						'callback'            => [ self::class, 'destroy' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'seo:write' ),
					],
				]
			);

			// 2. Register Custom Post Type (CPT) SEO route: `/cpt/{post_type}/{id}/seo`
			register_rest_route(
				self::NS,
				'/cpt/(?P<post_type>[a-z0-9_-]+)/(?P<id>\\d+)/seo',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'show_cpt' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'seo:read' ),
					],
					[
						'methods'             => \WP_REST_Server::EDITABLE,
						'callback'            => [ self::class, 'update_cpt' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'seo:write' ),
					],
					[
						'methods'             => \WP_REST_Server::DELETABLE,
						'callback'            => [ self::class, 'destroy_cpt' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'seo:write' ),
					],
				]
			);

			// 3. Register SEO Provider & Schema Capabilities inspection endpoint: `GET /seo/providers`
			register_rest_route(
				self::NS,
				'/seo/providers',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'providers' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'seo:read' ),
					],
				]
			);
		}

		/**
		 * Handle `PUT/PATCH/POST /wp-json/directrelay/v1/{posts|pages}/{id}/seo`.
		 */
		public static function update( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id       = (int) $req->get_param( 'id' );
			$expected = ( 'pages' === $req->get_param( 'type' ) ) ? 'page' : 'post';
			$post     = get_post( $id );

			if ( ! $post || $post->post_type !== $expected ) {
				return self::fail(
					$req,
					new \WP_Error(
						'amp_not_found',
						__( 'Content not found.', 'directrelay-pro' ),
						[ 'status' => 404 ]
					),
					'update_seo'
				);
			}

			// Enforce Post Ownership Isolation (`restrict_own_posts`) for the authenticated API key.
			$key = (array) $req->get_param( '_amp_key' );
			if ( class_exists( '\DirectRelay\Agent_Profiles' ) ) {
				$own = Agent_Profiles::assert_owns( $key, $id );
				if ( is_wp_error( $own ) ) {
					return self::fail( $req, $own, 'update_seo' );
				}
			}

			$body = $req->get_json_params() ?: [];
			if ( isset( $body['seo'] ) && is_array( $body['seo'] ) ) {
				$body = $body['seo'];
			}

			if ( empty( $body ) || ! is_array( $body ) ) {
				return self::fail(
					$req,
					new \WP_Error(
						'amp_invalid',
						__( 'Request body must contain at least one SEO field to update.', 'directrelay-pro' ),
						[ 'status' => 400 ]
					),
					'update_seo'
				);
			}

			$result = SEO_Write_Engine::update( $id, $body );
			if ( is_wp_error( $result ) ) {
				return self::fail( $req, $result, 'update_seo' );
			}

			return self::ok( $req, $result, 200, 'update_seo', $id, $expected );
		}

		/**
		 * Handle `DELETE /wp-json/directrelay/v1/{posts|pages}/{id}/seo`.
		 */
		public static function destroy( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id       = (int) $req->get_param( 'id' );
			$expected = ( 'pages' === $req->get_param( 'type' ) ) ? 'page' : 'post';
			$post     = get_post( $id );

			if ( ! $post || $post->post_type !== $expected ) {
				return self::fail(
					$req,
					new \WP_Error(
						'amp_not_found',
						__( 'Content not found.', 'directrelay-pro' ),
						[ 'status' => 404 ]
					),
					'delete_seo'
				);
			}

			$key = (array) $req->get_param( '_amp_key' );
			if ( class_exists( '\DirectRelay\Agent_Profiles' ) ) {
				$own = Agent_Profiles::assert_owns( $key, $id );
				if ( is_wp_error( $own ) ) {
					return self::fail( $req, $own, 'delete_seo' );
				}
			}

			$cleared = SEO_Write_Engine::clear( $id );
			return self::ok( $req, $cleared, 200, 'delete_seo', $id, $expected );
		}

		/**
		 * Handle `GET /wp-json/directrelay/v1/cpt/{post_type}/{id}/seo`.
		 */
		public static function show_cpt( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id        = (int) $req->get_param( 'id' );
			$post_type = sanitize_key( (string) $req->get_param( 'post_type' ) );
			$post      = get_post( $id );

			if ( ! $post || $post->post_type !== $post_type ) {
				return self::fail(
					$req,
					new \WP_Error( 'amp_not_found', __( 'Custom post type item not found.', 'directrelay-pro' ), [ 'status' => 404 ] ),
					'get_cpt_seo'
				);
			}

			return self::ok( $req, SEO_Write_Engine::read( $id ), 200, 'get_cpt_seo', $id, $post_type );
		}

		/**
		 * Handle `PUT/PATCH/POST /wp-json/directrelay/v1/cpt/{post_type}/{id}/seo`.
		 */
		public static function update_cpt( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id        = (int) $req->get_param( 'id' );
			$post_type = sanitize_key( (string) $req->get_param( 'post_type' ) );
			$post      = get_post( $id );

			if ( ! $post || $post->post_type !== $post_type ) {
				return self::fail(
					$req,
					new \WP_Error( 'amp_not_found', __( 'Custom post type item not found.', 'directrelay-pro' ), [ 'status' => 404 ] ),
					'update_cpt_seo'
				);
			}

			$key = (array) $req->get_param( '_amp_key' );
			if ( class_exists( '\DirectRelay\Agent_Profiles' ) ) {
				$own = Agent_Profiles::assert_owns( $key, $id );
				if ( is_wp_error( $own ) ) {
					return self::fail( $req, $own, 'update_cpt_seo' );
				}
			}

			$body   = $req->get_json_params() ?: [];
			$body   = isset( $body['seo'] ) && is_array( $body['seo'] ) ? $body['seo'] : $body;
			$result = SEO_Write_Engine::update( $id, $body );

			if ( is_wp_error( $result ) ) {
				return self::fail( $req, $result, 'update_cpt_seo' );
			}

			return self::ok( $req, $result, 200, 'update_cpt_seo', $id, $post_type );
		}

		/**
		 * Handle `DELETE /wp-json/directrelay/v1/cpt/{post_type}/{id}/seo`.
		 */
		public static function destroy_cpt( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id        = (int) $req->get_param( 'id' );
			$post_type = sanitize_key( (string) $req->get_param( 'post_type' ) );
			$post      = get_post( $id );

			if ( ! $post || $post->post_type !== $post_type ) {
				return self::fail(
					$req,
					new \WP_Error( 'amp_not_found', __( 'Custom post type item not found.', 'directrelay-pro' ), [ 'status' => 404 ] ),
					'delete_cpt_seo'
				);
			}

			$key = (array) $req->get_param( '_amp_key' );
			if ( class_exists( '\DirectRelay\Agent_Profiles' ) ) {
				$own = Agent_Profiles::assert_owns( $key, $id );
				if ( is_wp_error( $own ) ) {
					return self::fail( $req, $own, 'delete_cpt_seo' );
				}
			}

			return self::ok( $req, SEO_Write_Engine::clear( $id ), 200, 'delete_cpt_seo', $id, $post_type );
		}

		/**
		 * Handle `GET /wp-json/directrelay/v1/seo/providers`.
		 */
		public static function providers( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$detected = SEO_Write_Engine::detect_providers();
			return self::ok(
				$req,
				[
					'pro_version'       => DIRECTRELAY_PRO_VERSION,
					'providers'         => $detected,
					'supported_plugins' => [ 'rankmath', 'yoast', 'aioseo', 'seopress' ],
					'supported_schemas' => [ 'FAQPage', 'HowTo', 'Article', 'NewsArticle', 'BlogPosting', 'TechArticle', 'Product', 'Review' ],
					'fields'            => SEO_Write_Engine::get_discoverable_seo_fields(),
				],
				200,
				'seo_providers'
			);
		}
	}
	}
}

namespace DirectRelay {

	defined( 'ABSPATH' ) || exit;

	use DirectRelay\Pro\SEO_Write_Engine;

	/**
	 * Tier 1 — Module 2C: Universal Schema Translator
	 *
	 * Translates arbitrary JSON payloads from external AI agents, scrapers, or
	 * webhooks into canonical DirectRelay post + SEO structures.
	 */
	if ( ! class_exists( '\DirectRelay\Universal_Schema_Translator', false ) ) {
	final class Universal_Schema_Translator {

		private const TITLE_ALIASES = [
			'title', 'post_title', 'headline', 'name', 'article_title', 'subject', 'h1', 'header',
		];

		private const CONTENT_ALIASES = [
			'content', 'post_content', 'body', 'html', 'markdown', 'body_markdown', 'body_html',
			'article', 'article_body', 'text', 'post_body', 'story',
		];

		private const EXCERPT_ALIASES = [
			'excerpt', 'post_excerpt', 'summary', 'tldr', 'abstract', 'lead', 'subtitle', 'subheadline',
		];

		private const SLUG_ALIASES = [
			'slug', 'post_name', 'url_slug', 'permalink_slug', 'handle',
		];

		private const STATUS_ALIASES = [
			'status', 'post_status', 'state', 'publish_status',
		];

		private const IMAGE_ALIASES = [
			'featured_image_url', 'featured_media_url', 'featured_url', 'hero_image',
			'image_url', 'image', 'thumbnail', 'thumbnail_url', 'cover_image', 'banner_url',
		];

		private const GALLERY_ALIASES = [
			'gallery', 'images', 'gallery_urls', 'media_urls', 'photos',
		];

		private const CATEGORY_ALIASES = [
			'categories', 'category_names', 'category', 'section', 'topic', 'topics',
		];

		private const TAG_ALIASES = [
			'tags', 'tag_names', 'labels', 'hashtags',
		];

		/**
		 * Translate any arbitrary associative array into a canonical DirectRelay payload.
		 *
		 * @param array $raw       Arbitrary input JSON object.
		 * @param array $field_map Optional explicit dot-path mapping (`target_field => source_path`).
		 * @return array|\WP_Error Canonical payload ready for `Transactional_Publisher` or `Post_Manager`.
		 */
		public static function translate( array $raw, array $field_map = [] ): array|\WP_Error {
			// Unwrap common envelope wrappers (`data`, `item`, `article`, `post`, `output`, `result`).
			foreach ( [ 'data', 'item', 'article', 'post', 'output', 'result', 'payload' ] as $envelope ) {
				if ( isset( $raw[ $envelope ] ) && is_array( $raw[ $envelope ] ) && count( $raw ) <= 3 && ! isset( $raw['title'] ) ) {
					$raw = array_merge( $raw, $raw[ $envelope ] );
					break;
				}
			}

			$out = [
				'post_type'           => sanitize_key( (string) ( $raw['post_type'] ?? $raw['type'] ?? 'post' ) ),
				'status'              => 'draft',
				'rollback_on_failure' => ! empty( $raw['rollback_on_failure'] ?? true ),
				'require_approval'    => ! empty( $raw['require_approval'] ),
				'seo'                 => isset( $raw['seo'] ) && is_array( $raw['seo'] ) ? $raw['seo'] : [],
				'meta'                => isset( $raw['meta'] ) && is_array( $raw['meta'] ) ? $raw['meta'] : [],
				'acf'                 => isset( $raw['acf'] ) && is_array( $raw['acf'] ) ? $raw['acf'] : [],
			];

			if ( ! in_array( $out['post_type'], array_keys( get_post_types( [ 'public' => true ], 'names' ) ), true ) ) {
				$out['post_type'] = 'post';
			}

			// 1. Apply explicit user-supplied `field_map` first (supports dot notation like `article.meta.title`).
			if ( empty( $field_map ) && isset( $raw['field_map'] ) && is_array( $raw['field_map'] ) ) {
				$field_map = $raw['field_map'];
			}
			foreach ( $field_map as $target => $source_path ) {
				if ( ! is_string( $source_path ) || '' === $source_path ) {
					continue;
				}
				$val = self::extract_dot_path( $raw, $source_path );
				if ( null !== $val ) {
					if ( str_starts_with( (string) $target, 'seo.' ) ) {
						$out['seo'][ substr( (string) $target, 4 ) ] = $val;
					} elseif ( str_starts_with( (string) $target, 'meta.' ) ) {
						$out['meta'][ substr( (string) $target, 5 ) ] = $val;
					} elseif ( str_starts_with( (string) $target, 'acf.' ) ) {
						$out['acf'][ substr( (string) $target, 4 ) ] = $val;
					} else {
						$out[ $target ] = $val;
					}
				}
			}

			// 2. Heuristic matching for core post fields.
			if ( empty( $out['title'] ) ) {
				$out['title'] = (string) ( self::first_match( $raw, self::TITLE_ALIASES ) ?? '' );
			}
			if ( empty( $out['content'] ) ) {
				$content_candidate = self::first_match( $raw, self::CONTENT_ALIASES );
				if ( is_array( $content_candidate ) ) {
					// Join array of paragraphs/sections into Markdown/HTML.
					$out['content'] = implode( "\n\n", array_map( 'strval', array_filter( $content_candidate, 'is_scalar' ) ) );
				} else {
					$out['content'] = (string) ( $content_candidate ?? '' );
				}
			}
			if ( empty( $out['excerpt'] ) ) {
				$out['excerpt'] = (string) ( self::first_match( $raw, self::EXCERPT_ALIASES ) ?? '' );
			}
			if ( empty( $out['slug'] ) ) {
				$out['slug'] = (string) ( self::first_match( $raw, self::SLUG_ALIASES ) ?? '' );
			}

			$raw_status = strtolower( trim( (string) ( self::first_match( $raw, self::STATUS_ALIASES ) ?? 'draft' ) ) );
			$status_map = [
				'published' => 'publish',
				'live'      => 'publish',
				'public'    => 'publish',
				'scheduled' => 'future',
				'review'    => 'pending',
			];
			$out['status'] = $status_map[ $raw_status ] ?? ( in_array( $raw_status, [ 'draft', 'publish', 'pending', 'private', 'future' ], true ) ? $raw_status : 'draft' );

			// Featured Image URL or ID.
			if ( empty( $out['featured_image_url'] ) && empty( $out['featured_media'] ) ) {
				$img = self::first_match( $raw, self::IMAGE_ALIASES );
				if ( is_numeric( $img ) ) {
					$out['featured_media'] = (int) $img;
				} elseif ( is_string( $img ) && filter_var( $img, FILTER_VALIDATE_URL ) ) {
					$out['featured_image_url'] = $img;
					$out['featured_media_url'] = $img;
				} elseif ( is_array( $img ) && ! empty( $img['url'] ) ) {
					$out['featured_image_url'] = (string) $img['url'];
					$out['featured_media_url'] = (string) $img['url'];
				}
			}

			// Gallery URLs.
			if ( empty( $out['gallery'] ) ) {
				$gal = self::first_match( $raw, self::GALLERY_ALIASES );
				if ( is_array( $gal ) ) {
					$out['gallery'] = array_values( array_filter( array_map( static function ( $g ) {
						return is_array( $g ) ? ( $g['url'] ?? $g['src'] ?? '' ) : ( is_string( $g ) ? $g : '' );
					}, $gal ) ) );
				}
			}

			// Categories & Tags.
			$cats = self::first_match( $raw, self::CATEGORY_ALIASES );
			if ( null !== $cats ) {
				$out['category_names'] = is_string( $cats ) ? array_map( 'trim', explode( ',', $cats ) ) : (array) $cats;
			}
			$tags = self::first_match( $raw, self::TAG_ALIASES );
			if ( null !== $tags ) {
				$out['tag_names'] = is_string( $tags ) ? array_map( 'trim', explode( ',', $tags ) ) : (array) $tags;
			}

			// 3. Heuristic SEO field extraction.
			$seo_aliases = [
				'focus_keyword'      => [ 'focus_keyword', 'seo_focus_keyword', 'rankmath_focus_keyword', 'keyword', 'primary_keyword', 'focus_kw', 'target_keyword' ],
				'secondary_keywords' => [ 'secondary_keywords', 'keywords', 'additional_keywords', 'lsi_keywords' ],
				'title'              => [ 'seo_title', 'meta_title', 'rankmath_title', 'serp_title' ],
				'description'        => [ 'seo_description', 'meta_description', 'rankmath_description', 'serp_description' ],
				'canonical_url'      => [ 'canonical_url', 'canonical' ],
				'faq_schema'         => [ 'faq_schema', 'faqs', 'faq' ],
				'howto_schema'       => [ 'howto_schema', 'howto', 'how_to' ],
				'article_schema'     => [ 'article_schema' ],
				'product_schema'     => [ 'product_schema' ],
				'review_schema'      => [ 'review_schema' ],
			];

			foreach ( $seo_aliases as $canonical_seo_key => $candidates ) {
				if ( ! isset( $out['seo'][ $canonical_seo_key ] ) ) {
					$matched = self::first_match( $raw, $candidates );
					if ( null !== $matched ) {
						$out['seo'][ $canonical_seo_key ] = $matched;
					}
				}
			}

			if ( '' === trim( $out['title'] ) && '' === trim( $out['content'] ) ) {
				return new \WP_Error(
					'directrelay_pro_universal_empty',
					__( 'Universal Schema Translator could not locate a title or content field in the payload.', 'directrelay-pro' ),
					[ 'status' => 422 ]
				);
			}

			// If title is missing, derive a clean title from the first heading or sentence of content.
			if ( '' === trim( $out['title'] ) ) {
				if ( preg_match( '/^#\s+(.+)$/m', $out['content'], $m ) ) {
					$out['title'] = trim( $m[1] );
				} else {
					$out['title'] = wp_trim_words( wp_strip_all_tags( $out['content'] ), 10, '' );
				}
			}

			return $out;
		}

		private static function first_match( array $source, array $keys ): mixed {
			foreach ( $keys as $k ) {
				if ( isset( $source[ $k ] ) && '' !== $source[ $k ] && [] !== $source[ $k ] ) {
					return $source[ $k ];
				}
			}
			return null;
		}

		private static function extract_dot_path( array $data, string $path ): mixed {
			$segments = explode( '.', $path );
			$cur      = $data;
			foreach ( $segments as $seg ) {
				if ( is_array( $cur ) && array_key_exists( $seg, $cur ) ) {
					$cur = $cur[ $seg ];
				} else {
					return null;
				}
			}
			return $cur;
		}
	}
	}

	/**
	 * Tier 1 — Module 3: Human-in-the-Loop Approval Gateway (`\DirectRelay\Approval_Gateway`)
	 *
	 * Automatically detected by Free's `Plugin::boot()`, `Transactional_Publisher::execute()`,
	 * and `Admin\Ajax_Handler::approve_ticket()` / `reject_ticket()`.
	 * Uses the pre-created `{$wpdb->prefix}directrelay_approvals` table.
	 */
	if ( ! class_exists( '\DirectRelay\Approval_Gateway', false ) ) {
	final class Approval_Gateway {

		private static bool $initialized = false;

		public static function init(): void {
			if ( self::$initialized ) {
				return;
			}
			self::$initialized = true;

			// Intercept signed frontend Magic Review URLs (`?directrelay_review=<uuid>&token=<raw>`).
			add_action( 'template_redirect', [ __CLASS__, 'handle_magic_review_portal' ] );

			// Intercept direct `POST /posts` and `POST /pages` when `require_approval` is enabled on the API key.
			add_filter( 'rest_post_dispatch', [ __CLASS__, 'maybe_hold_for_approval' ], 15, 3 );
		}

		/**
		 * Create a new approval ticket in `{$wpdb->prefix}directrelay_approvals`.
		 *
		 * @param int   $key_id  API Key ID that submitted the content.
		 * @param int   $post_id Created WordPress post ID (held in `pending` or `draft`).
		 * @param array $payload Full submission payload.
		 * @return array|\WP_Error Ticket metadata including signed `review_url`.
		 */
		public static function create_ticket( int $key_id, int $post_id, array $payload ): array|\WP_Error {
			global $wpdb;
			$table       = "{$wpdb->prefix}directrelay_approvals";
			$uuid        = wp_generate_uuid4();
			$raw_token   = bin2hex( random_bytes( 24 ) );
			$token_hash  = hash( 'sha256', $raw_token );
			$now_utc     = current_time( 'mysql', true );
			$expires_utc = gmdate( 'Y-m-d H:i:s', time() + 7 * DAY_IN_SECONDS );

			// Ensure the post status is held as `pending` until human review.
			$post = get_post( $post_id );
			if ( $post && 'publish' === $post->post_status ) {
				wp_update_post( [
					'ID'          => $post_id,
					'post_status' => 'pending',
				] );
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$inserted = $wpdb->insert(
				$table,
				[
					'ticket_uuid' => $uuid,
					'key_id'      => $key_id,
					'post_id'     => $post_id,
					'token_hash'  => $token_hash,
					'status'      => 'pending',
					'payload'     => wp_json_encode( $payload ),
					'expires_at'  => $expires_utc,
					'created_at'  => $now_utc,
				],
				[ '%s', '%d', '%d', '%s', '%s', '%s', '%s', '%s' ]
			);

			if ( ! $inserted ) {
				return new \WP_Error(
					'directrelay_pro_ticket_error',
					__( 'Could not create approval ticket in database.', 'directrelay-pro' ),
					[ 'status' => 500 ]
				);
			}

			$review_url = add_query_arg(
				[
					'directrelay_review' => $uuid,
					'token'              => $raw_token,
				],
				home_url( '/' )
			);

			update_post_meta( $post_id, '_directrelay_approval_ticket', $uuid );
			update_post_meta( $post_id, '_directrelay_review_url', $review_url );
			if ( class_exists( '\\DirectRelay\\Pro\\Agency_Governance_Engine' ) ) {
				\\DirectRelay\\Pro\\Agency_Governance_Engine::dispatch_security_alert(
					'approval.created',
					sprintf( 'New post #%d held for human review (Ticket %s).', $post_id, $uuid ),
					[ 'post_id' => $post_id, 'ticket_uuid' => $uuid, 'review_url' => $review_url ]
				);
			}

			return [
				'id'          => (int) $wpdb->insert_id,
				'ticket_uuid' => $uuid,
				'post_id'     => $post_id,
				'status'      => 'pending',
				'expires_at'  => $expires_utc,
				'review_url'  => $review_url,
				'admin_url'   => admin_url( 'admin.php?page=directrelay-approvals' ),
			];
		}

		/**
		 * Approve a pending ticket and publish its post immediately.
		 *
		 * Called by `Admin\Ajax_Handler::approve_ticket()`, REST API, and Magic Review Portal.
		 */
		public static function approve( string $uuid, int $reviewer_user_id = 0 ): array|\WP_Error {
			global $wpdb;
			$table = "{$wpdb->prefix}directrelay_approvals";

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$ticket = $wpdb->get_row(
				$wpdb->prepare( "SELECT * FROM {$table} WHERE ticket_uuid = %s LIMIT 1", $uuid ),
				ARRAY_A
			);

			if ( ! $ticket ) {
				return new \WP_Error( 'amp_not_found', __( 'Approval ticket not found.', 'directrelay-pro' ), [ 'status' => 404 ] );
			}
			if ( 'approved' === $ticket['status'] ) {
				return [
					'ticket_uuid' => $uuid,
					'status'      => 'approved',
					'post_id'     => (int) $ticket['post_id'],
					'permalink'   => get_permalink( (int) $ticket['post_id'] ),
				];
			}

			$post_id = (int) $ticket['post_id'];
			if ( $post_id > 0 && get_post( $post_id ) ) {
				$updated = wp_update_post(
					[
						'ID'          => $post_id,
						'post_status' => 'publish',
					],
					true
				);
				if ( is_wp_error( $updated ) ) {
					return $updated;
				}
			}

			$now_utc = current_time( 'mysql', true );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->update(
				$table,
				[
					'status'           => 'approved',
					'reviewer_user_id' => $reviewer_user_id ?: get_current_user_id(),
					'resolved_at'      => $now_utc,
				],
				[ 'ticket_uuid' => $uuid ],
				[ '%s', '%d', '%s' ],
				[ '%s' ]
			);

			if ( $post_id > 0 ) {
				$s = get_option( 'directrelay_settings', [] );
				if ( ! empty( $s['enable_indexnow'] ) && class_exists( '\DirectRelay\IndexNow_Pinger' ) ) {
					\DirectRelay\IndexNow_Pinger::ping( [ (string) get_permalink( $post_id ) ], $post_id );
				}
				if ( class_exists( '\DirectRelay\Webhook_Manager' ) ) {
					\DirectRelay\Webhook_Manager::fire( 'post.published', $post_id, (string) get_post_type( $post_id ) );
				}
			}

			return [
				'ticket_uuid' => $uuid,
				'status'      => 'approved',
				'post_id'     => $post_id,
				'permalink'   => $post_id ? get_permalink( $post_id ) : null,
				'resolved_at' => $now_utc,
			];
		}

		/**
		 * Reject a pending ticket, store editor feedback, and keep post as draft.
		 *
		 * Called by `Admin\Ajax_Handler::reject_ticket()`, REST API, and Magic Review Portal.
		 */
		public static function reject( string $uuid, string $feedback = '', int $reviewer_user_id = 0 ): array|\WP_Error {
			global $wpdb;
			$table = "{$wpdb->prefix}directrelay_approvals";

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$ticket = $wpdb->get_row(
				$wpdb->prepare( "SELECT * FROM {$table} WHERE ticket_uuid = %s LIMIT 1", $uuid ),
				ARRAY_A
			);

			if ( ! $ticket ) {
				return new \WP_Error( 'amp_not_found', __( 'Approval ticket not found.', 'directrelay-pro' ), [ 'status' => 404 ] );
			}

			$post_id = (int) $ticket['post_id'];
			if ( $post_id > 0 && get_post( $post_id ) ) {
				wp_update_post( [
					'ID'          => $post_id,
					'post_status' => 'draft',
				] );
				if ( '' !== $feedback ) {
					update_post_meta( $post_id, '_directrelay_rejection_feedback', sanitize_textarea_field( $feedback ) );
				}
			}

			$now_utc = current_time( 'mysql', true );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->update(
				$table,
				[
					'status'           => 'rejected',
					'editor_feedback'  => sanitize_textarea_field( $feedback ),
					'reviewer_user_id' => $reviewer_user_id ?: get_current_user_id(),
					'resolved_at'      => $now_utc,
				],
				[ 'ticket_uuid' => $uuid ],
				[ '%s', '%s', '%d', '%s' ],
				[ '%s' ]
			);

			return [
				'ticket_uuid'     => $uuid,
				'status'          => 'rejected',
				'post_id'         => $post_id,
				'editor_feedback' => sanitize_textarea_field( $feedback ),
				'resolved_at'     => $now_utc,
			];
		}

		/**
		 * List approval tickets from `{$wpdb->prefix}directrelay_approvals`.
		 */
		public static function list_tickets( string $status = '', int $limit = 50 ): array {
			global $wpdb;
			$table = "{$wpdb->prefix}directrelay_approvals";
			$limit = max( 1, min( 200, $limit ) );

			if ( '' !== $status && in_array( $status, [ 'pending', 'approved', 'rejected' ], true ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$rows = $wpdb->get_results(
					$wpdb->prepare( "SELECT * FROM {$table} WHERE status = %s ORDER BY created_at DESC LIMIT %d", $status, $limit ),
					ARRAY_A
				) ?: [];
			} else {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$rows = $wpdb->get_results(
					$wpdb->prepare( "SELECT * FROM {$table} ORDER BY created_at DESC LIMIT %d", $limit ),
					ARRAY_A
				) ?: [];
			}

			foreach ( $rows as &$r ) {
				$pid             = (int) ( $r['post_id'] ?? 0 );
				$p               = $pid ? get_post( $pid ) : null;
				$r['post_title'] = $p ? $p->post_title : __( '(Deleted Post)', 'directrelay-pro' );
				$r['post_type']  = $p ? $p->post_type : 'post';
				$r['review_url'] = $pid ? (string) get_post_meta( $pid, '_directrelay_review_url', true ) : '';
			}
			unset( $r );

			return $rows;
		}

		/**
		 * Automatically create an approval ticket when a key with `require_approval = 1`
		 * creates a post via `POST /posts` or `POST /pages`.
		 */
		public static function maybe_hold_for_approval( $response, \WP_REST_Server $server, \WP_REST_Request $request ) {
			if ( ! ( $response instanceof \WP_REST_Response ) || 'POST' !== $request->get_method() ) {
				return $response;
			}
			$route = $request->get_route();
			if ( ! in_array( $route, [ '/directrelay/v1/posts', '/directrelay/v1/pages' ], true ) ) {
				return $response;
			}

			$key  = (array) $request->get_param( '_amp_key' );
			$body = $request->get_json_params() ?: [];
			if ( empty( $key['require_approval'] ) && empty( $body['require_approval'] ) ) {
				return $response;
			}

			$data       = $response->get_data();
			$entity_key = '/directrelay/v1/pages' === $route ? 'page' : 'post';
			$post_id    = (int) ( $data['data'][ $entity_key ]['id'] ?? 0 );
			if ( $post_id <= 0 ) {
				return $response;
			}

			$ticket = self::create_ticket( (int) ( $key['id'] ?? 0 ), $post_id, $body );
			if ( ! is_wp_error( $ticket ) ) {
				$data['data'][ $entity_key ]['status'] = 'pending';
				$data['data']['approval']              = $ticket;
				$response->set_data( $data );
			}

			return $response;
		}

		/**
		 * Render the signed frontend Magic Review Portal when `?directrelay_review=<uuid>&token=<raw>` is visited.
		 */
		public static function handle_magic_review_portal(): void {
			if ( empty( $_GET['directrelay_review'] ) || empty( $_GET['token'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				return;
			}

			$uuid      = sanitize_text_field( wp_unslash( $_GET['directrelay_review'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$raw_token = sanitize_text_field( wp_unslash( $_GET['token'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

			global $wpdb;
			$table = "{$wpdb->prefix}directrelay_approvals";
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$ticket = $wpdb->get_row(
				$wpdb->prepare( "SELECT * FROM {$table} WHERE ticket_uuid = %s LIMIT 1", $uuid ),
				ARRAY_A
			);

			if ( ! $ticket || ! hash_equals( (string) $ticket['token_hash'], hash( 'sha256', $raw_token ) ) ) {
				wp_die( esc_html__( 'Invalid or expired DirectRelay review link.', 'directrelay-pro' ), esc_html__( 'Review Link Invalid', 'directrelay-pro' ), [ 'response' => 403 ] );
			}

			if ( strtotime( (string) $ticket['expires_at'] . ' UTC' ) < time() && 'pending' === $ticket['status'] ) {
				wp_die( esc_html__( 'This review link has expired.', 'directrelay-pro' ), esc_html__( 'Review Link Expired', 'directrelay-pro' ), [ 'response' => 410 ] );
			}

			// Handle POST decision submission on the magic portal.
			$action_msg = '';
			if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && ! empty( $_POST['directrelay_decision'] ) ) {
				if ( ! isset( $_POST['_dr_review_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_dr_review_nonce'] ) ), 'directrelay_magic_review_' . $uuid ) ) {
					wp_die( esc_html__( 'Security check failed.', 'directrelay-pro' ), 403 );
				}
				$decision = sanitize_key( wp_unslash( $_POST['directrelay_decision'] ) );
				$feedback = sanitize_textarea_field( wp_unslash( $_POST['editor_feedback'] ?? '' ) );
				if ( 'approve' === $decision ) {
					$res        = self::approve( $uuid, get_current_user_id() );
					$action_msg = ! is_wp_error( $res ) ? __( 'Approved and published live!', 'directrelay-pro' ) : $res->get_error_message();
				} elseif ( 'reject' === $decision ) {
					$res        = self::reject( $uuid, $feedback, get_current_user_id() );
					$action_msg = ! is_wp_error( $res ) ? __( 'Ticket rejected and feedback saved.', 'directrelay-pro' ) : $res->get_error_message();
				}
				// Refresh ticket row.
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$ticket = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE ticket_uuid = %s LIMIT 1", $uuid ), ARRAY_A );
			}

			$post = get_post( (int) $ticket['post_id'] );
			$seo  = $post ? SEO_Write_Engine::read( $post->ID ) : [];

			nocache_headers();
			header( 'Content-Type: text/html; charset=utf-8' );
			?>
			<!DOCTYPE html>
			<html <?php language_attributes(); ?>>
			<head>
				<meta charset="utf-8">
				<meta name="viewport" content="width=device-width, initial-scale=1">
				<meta name="robots" content="noindex,nofollow">
				<title><?php echo esc_html( ( $post ? $post->post_title : 'Review' ) . ' — DirectRelay Approval Portal' ); ?></title>
				<style>
					body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:#0f172a;color:#e2e8f0;margin:0;padding:32px 16px;line-height:1.6}
					.dr-portal{max-width:960px;margin:0 auto;background:#1e293b;border:1px solid #334155;border-radius:12px;padding:28px;box-shadow:0 20px 50px rgba(0,0,0,.4)}
					.dr-badge{display:inline-block;padding:4px 10px;border-radius:999px;font-size:12px;font-weight:700;text-transform:uppercase}
					.dr-pending{background:#f59e0b22;color:#fbbf24;border:1px solid #f59e0b55}
					.dr-approved{background:#22c55e22;color:#4ade80;border:1px solid #22c55e55}
					.dr-rejected{background:#ef444422;color:#f87171;border:1px solid #ef444455}
					.dr-content{background:#0f172a;border:1px solid #334155;border-radius:8px;padding:24px;margin:20px 0}
					.dr-seo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin:16px 0}
					.dr-seo-box{background:#0f172a;border:1px solid #334155;border-radius:8px;padding:12px}
					.dr-btn{padding:10px 20px;border-radius:8px;border:0;font-weight:600;cursor:pointer;font-size:14px}
					.dr-btn-approve{background:#22c55e;color:#052e16}
					.dr-btn-reject{background:#ef4444;color:#fff;margin-left:8px}
					textarea{width:100%;background:#0f172a;color:#e2e8f0;border:1px solid #334155;border-radius:8px;padding:10px;margin-bottom:12px}
				</style>
			</head>
			<body>
				<div class="dr-portal">
					<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
						<div>
							<span style="color:#28CCCD;font-size:12px;font-weight:700;letter-spacing:.12em;text-transform:uppercase">DirectRelay Human Approval Portal</span>
							<h1 style="margin:6px 0 0;font-size:24px;color:#fff"><?php echo esc_html( $post ? $post->post_title : __( 'Deleted Post', 'directrelay-pro' ) ); ?></h1>
						</div>
						<span class="dr-badge dr-<?php echo esc_attr( $ticket['status'] ); ?>"><?php echo esc_html( $ticket['status'] ); ?></span>
					</div>

					<?php if ( $action_msg ) : ?>
						<div style="background:#28cccd22;border:1px solid #28cccd;color:#28cccd;padding:12px 16px;border-radius:8px;margin-top:16px;font-weight:600">
							<?php echo esc_html( $action_msg ); ?>
						</div>
					<?php endif; ?>

					<div class="dr-seo-grid">
						<div class="dr-seo-box"><small style="color:#94a3b8">Focus Keyword</small><br><strong><?php echo esc_html( $seo['focus_keyword'] ?? '—' ); ?></strong></div>
						<div class="dr-seo-box"><small style="color:#94a3b8">SEO Title</small><br><strong><?php echo esc_html( $seo['title'] ?? '—' ); ?></strong></div>
						<div class="dr-seo-box"><small style="color:#94a3b8">Meta Description</small><br><span><?php echo esc_html( $seo['description'] ?? '—' ); ?></span></div>
					</div>

					<div class="dr-content">
						<?php echo $post ? wp_kses_post( apply_filters( 'the_content', $post->post_content ) ) : ''; // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound ?>
					</div>

					<?php if ( 'pending' === $ticket['status'] ) : ?>
						<form method="post">
							<?php wp_nonce_field( 'directrelay_magic_review_' . $uuid, '_dr_review_nonce' ); ?>
							<label for="dr-feedback" style="display:block;font-size:13px;font-weight:600;margin-bottom:6px"><?php esc_html_e( 'Editor Notes / Rejection Feedback (optional):', 'directrelay-pro' ); ?></label>
							<textarea id="dr-feedback" name="editor_feedback" rows="3" placeholder="<?php esc_attr_e( 'Add notes for the AI workflow or editorial log…', 'directrelay-pro' ); ?>"></textarea>
							<button type="submit" name="directrelay_decision" value="approve" class="dr-btn dr-btn-approve">✓ <?php esc_html_e( 'Approve & Publish Live', 'directrelay-pro' ); ?></button>
							<button type="submit" name="directrelay_decision" value="reject" class="dr-btn dr-btn-reject">✕ <?php esc_html_e( 'Reject to Draft', 'directrelay-pro' ); ?></button>
						</form>
					<?php elseif ( ! empty( $ticket['permalink'] ) || ( $post && 'publish' === $post->post_status ) ) : ?>
						<p><a href="<?php echo esc_url( get_permalink( $post->ID ) ); ?>" style="color:#28CCCD;font-weight:600"><?php esc_html_e( 'View Published Post →', 'directrelay-pro' ); ?></a></p>
					<?php endif; ?>
				</div>
			</body>
			</html>
			<?php
			exit;
		}
	}
	}

	/**
	 * Tier 1 — Module 4: AI Content Guardrails & Velocity Engine (`\DirectRelay\Guardrails_Manager`)
	 *
	 * Automatically detected by Free's `Base_Controller::guard()` and `Transactional_Publisher::execute()`.
	 * Uses the `directrelay_guardrails` option saved by `Admin\Ajax_Handler::save_guardrails()`
	 * and per-key `daily_limit` / `posts_today` columns in `{$wpdb->prefix}directrelay_keys`.
	 */
	if ( ! class_exists( '\DirectRelay\Guardrails_Manager', false ) ) {
	final class Guardrails_Manager {

		public static function init(): void {
			add_filter( 'rest_request_before_callbacks', [ __CLASS__, 'enforce_on_rest_write' ], 15, 3 );
			add_filter( 'rest_post_dispatch', [ __CLASS__, 'track_daily_post_creation' ], 15, 3 );
			add_filter( 'directrelay_ext_guardrails_check', [ __CLASS__, 'filter_ext_guardrails_check' ], 10, 3 );
		}

		/**
		 * Filter callback for `directrelay_ext_guardrails_check` (invoked by Free or add-on quota checks).
		 *
		 * @param mixed  $allowed Current pass/fail status (bool or WP_Error).
		 * @param string $context Quota context ('api_keys', 'webhooks', 'posts_write', 'rate_limit').
		 * @param array  $args    Contextual arguments (e.g. key row or user ID).
		 * @return bool|\WP_Error
		 */
		public static function filter_ext_guardrails_check( mixed $allowed, string $context = '', array $args = [] ): bool|\WP_Error {
			if ( is_wp_error( $allowed ) ) {
				return $allowed;
			}
			if ( in_array( $context, [ 'posts_write', 'pages_write', 'publish' ], true ) && ! empty( $args['key'] ) && is_array( $args['key'] ) ) {
				return self::check_daily_limit( $args['key'] );
			}
			if ( class_exists( '\DirectRelay\Pro\License_Manager' ) && ! \DirectRelay\Pro\License_Manager::is_feature_allowed( $context ) ) {
				return new \WP_Error(
					'directrelay_pro_license_required',
					__( 'An active DirectRelay Pro license is required for this feature.', 'directrelay-pro' ),
					[ 'status' => 403 ]
				);
			}
			return true;
		}

		/**
		 * Get normalized guardrail settings.
		 */
		public static function settings(): array {
			$defaults = [
				'enabled'                  => true,
				'max_daily_posts'          => 50,
				'min_word_count'           => 30,
				'max_word_count'           => 25000,
				'clean_ai_leakage'         => true,
				'prevent_duplicate_titles' => true,
				'blocked_phrases'          => '',
			];
			$saved = get_option( 'directrelay_guardrails', [] );
			return is_array( $saved ) ? array_merge( $defaults, $saved ) : $defaults;
		}

		/**
		 * Check whether the current API key or site has exceeded its daily post creation velocity cap.
		 *
		 * Called directly by Free's `Base_Controller::guard()`.
		 */
		public static function check_daily_limit( array $key ): bool|\WP_Error {
			global $wpdb;
			$cfg   = self::settings();
			$today = gmdate( 'Y-m-d' );

			// 1. Check per-key `daily_limit` stored on `directrelay_keys`.
			$key_id    = (int) ( $key['id'] ?? 0 );
			$key_limit = (int) ( $key['daily_limit'] ?? 0 );

			if ( $key_id > 0 && $key_limit > 0 ) {
				$posts_today = ( ( $key['posts_today_date'] ?? '' ) === $today ) ? (int) ( $key['posts_today'] ?? 0 ) : 0;
				if ( $posts_today >= $key_limit ) {
					return new \WP_Error(
						'amp_daily_limit_exceeded',
						sprintf(
							/* translators: %d: daily post limit for this API key */
							__( 'API key daily post velocity cap reached (%d posts/day).', 'directrelay-pro' ),
							$key_limit
						),
						[ 'status' => 429 ]
					);
				}
			}

			// 2. Check global guardrail `max_daily_posts` cap.
			if ( ! empty( $cfg['enabled'] ) && ! empty( $cfg['max_daily_posts'] ) ) {
				$global_max = (int) $cfg['max_daily_posts'];
				if ( $global_max > 0 ) {
					$table = "{$wpdb->prefix}directrelay_keys";
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$site_today = (int) $wpdb->get_var(
						$wpdb->prepare( "SELECT COALESCE(SUM(posts_today), 0) FROM {$table} WHERE posts_today_date = %s", $today )
					);
					if ( $site_today >= $global_max ) {
						return new \WP_Error(
							'amp_site_daily_limit_exceeded',
							sprintf(
								/* translators: %d: global daily post limit */
								__( 'Global AI Guardrails daily publishing cap reached (%d posts/day).', 'directrelay-pro' ),
								$global_max
							),
							[ 'status' => 429 ]
						);
					}
				}
			}

			return true;
		}

		/**
		 * Increment the daily post counter for an API key.
		 *
		 * Called directly by Free's `Transactional_Publisher::execute()` and after `POST /posts`.
		 */
		public static function increment_daily_usage( int $key_id ): void {
			if ( $key_id <= 0 ) {
				return;
			}
			global $wpdb;
			$table = "{$wpdb->prefix}directrelay_keys";
			$today = gmdate( 'Y-m-d' );

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$row = $wpdb->get_row(
				$wpdb->prepare( "SELECT posts_today, posts_today_date FROM {$table} WHERE id = %d", $key_id ),
				ARRAY_A
			);
			if ( ! $row ) {
				return;
			}

			$new_count = ( ( $row['posts_today_date'] ?? '' ) === $today ) ? ( (int) $row['posts_today'] + 1 ) : 1;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->update(
				$table,
				[
					'posts_today'      => $new_count,
					'posts_today_date' => $today,
				],
				[ 'id' => $key_id ],
				[ '%d', '%s' ],
				[ '%d' ]
			);
		}

		/**
		 * Validate incoming AI-generated title and content against configured guardrails.
		 *
		 * Called directly by Free's `Transactional_Publisher::execute()`.
		 */
		public static function validate_content( string $content, string $title, array $key = [] ): bool|\WP_Error {
			$cfg = self::settings();
			if ( empty( $cfg['enabled'] ) ) {
				return true;
			}

			$clean_title = trim( wp_strip_all_tags( $title ) );

			// 1. Duplicate Title Detection.
			if ( ! empty( $cfg['prevent_duplicate_titles'] ) && '' !== $clean_title ) {
				global $wpdb;
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$dup_id = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT ID FROM {$wpdb->posts} WHERE post_title = %s AND post_status IN ('publish','pending','draft','future') AND post_type IN ('post','page') LIMIT 1",
						$clean_title
					)
				);
				if ( $dup_id > 0 ) {
					return new \WP_Error(
						'amp_guardrail_duplicate_title',
						sprintf(
							/* translators: 1: duplicate post title, 2: existing post ID */
							__( 'AI Guardrail blocked submission: duplicate title "%1$s" already exists (Post ID #%2$d).', 'directrelay-pro' ),
							$clean_title,
							$dup_id
						),
						[ 'status' => 422 ]
					);
				}
			}

			// 2. Word Count Floor & Ceiling (evaluated when content is non-empty).
			$plain_text = trim( wp_strip_all_tags( $content ) );
			if ( '' !== $plain_text ) {
				$word_count = str_word_count( $plain_text );
				$min_words  = (int) ( $cfg['min_word_count'] ?? 0 );
				$max_words  = (int) ( $cfg['max_word_count'] ?? 25000 );

				if ( $min_words > 0 && $word_count < $min_words ) {
					return new \WP_Error(
						'amp_guardrail_min_words',
						sprintf(
							/* translators: 1: actual word count, 2: minimum required word count */
							__( 'AI Guardrail blocked submission: content has %1$d words, below minimum threshold of %2$d words.', 'directrelay-pro' ),
							$word_count,
							$min_words
						),
						[ 'status' => 422 ]
					);
				}

				if ( $max_words > 0 && $word_count > $max_words ) {
					return new \WP_Error(
						'amp_guardrail_max_words',
						sprintf(
							/* translators: 1: actual word count, 2: maximum allowed word count */
							__( 'AI Guardrail blocked submission: content has %1$d words, exceeding maximum threshold of %2$d words.', 'directrelay-pro' ),
							$word_count,
							$max_words
						),
						[ 'status' => 422 ]
					);
				}
			}

			// 3. Blocked Phrases Filter.
			if ( ! empty( $cfg['blocked_phrases'] ) ) {
				$phrases  = array_values( array_filter( array_map( 'trim', preg_split( '/[\r\n,]+/', (string) $cfg['blocked_phrases'] ) ) ) );
				$haystack = strtolower( $clean_title . ' ' . $plain_text );
				foreach ( $phrases as $phrase ) {
					if ( '' !== $phrase && str_contains( $haystack, strtolower( $phrase ) ) ) {
						return new \WP_Error(
							'amp_guardrail_blocked_phrase',
							sprintf(
								/* translators: %s: blocked phrase matched */
								__( 'AI Guardrail blocked submission: content contains restricted phrase "%s".', 'directrelay-pro' ),
								$phrase
							),
							[ 'status' => 422 ]
						);
					}
				}
			}

			return true;
		}

		/**
		 * Scrub AI prompt leakage, refusal artifacts, and unreplaced brackets from content.
		 *
		 * Called directly by Free's `Transactional_Publisher::execute()`.
		 */
		public static function sanitize_ai_leakage( string $content ): string {
			$cfg = self::settings();
			if ( empty( $cfg['clean_ai_leakage'] ) ) {
				return $content;
			}

			if ( class_exists( '\DirectRelay\Content_Processor' ) ) {
				$content = Content_Processor::clean_ai_garbage( $content );
			}

			$leakage_patterns = [
				'/\bAs an AI(?: language model| assistant)?[,:\s][^\.\n]*[\.\n]/i',
				'/\bI am an artificial intelligence[^\.\n]*[\.\n]/i',
				'/\[Insert\s+[^\]]+\]/i',
				'/\[Your\s+Name(?:\s+Here)?\]/i',
			];

			foreach ( $leakage_patterns as $pattern ) {
				$content = (string) preg_replace( $pattern, '', $content );
			}

			return trim( $content );
		}

		/**
		 * Enforce content guardrails on standard `POST /posts` and `POST /pages` requests.
		 */
		public static function enforce_on_rest_write( $response, array $handler, \WP_REST_Request $request ) {
			if ( is_wp_error( $response ) || 'POST' !== $request->get_method() ) {
				return $response;
			}
			$route = $request->get_route();
			if ( ! in_array( $route, [ '/directrelay/v1/posts', '/directrelay/v1/pages' ], true ) ) {
				return $response;
			}

			$json = $request->get_json_params();
			if ( ! is_array( $json ) ) {
				return $response;
			}

			$title   = (string) ( $json['title'] ?? '' );
			$content = (string) ( $json['content'] ?? '' );
			if ( '' !== $content ) {
				$content         = self::sanitize_ai_leakage( $content );
				$json['content'] = $content;
				$request->set_body( wp_json_encode( $json ) );
			}

			$valid = self::validate_content( $content, $title, (array) $request->get_param( '_amp_key' ) );
			if ( is_wp_error( $valid ) ) {
				return $valid;
			}

			return $response;
		}

		/**
		 * Increment per-key daily post counter after a successful `POST /posts` or `POST /pages`.
		 */
		public static function track_daily_post_creation( $response, \WP_REST_Server $server, \WP_REST_Request $request ) {
			if ( ! ( $response instanceof \WP_REST_Response ) || 201 !== $response->get_status() ) {
				return $response;
			}
			if ( ! in_array( $request->get_route(), [ '/directrelay/v1/posts', '/directrelay/v1/pages' ], true ) ) {
				return $response;
			}
			$key = (array) $request->get_param( '_amp_key' );
			if ( ! empty( $key['id'] ) ) {
				self::increment_daily_usage( (int) $key['id'] );
			}
			return $response;
		}
	}
	}

	/**
	 * Tier 1 — Module 5: Time-Travel Execution Debugger & Dry-Run Replay (`\DirectRelay\Execution_Debugger`)
	 *
	 * Automatically detected by Free's `Admin\Ajax_Handler::replay_request()`.
	 */
	if ( ! class_exists( '\DirectRelay\Execution_Debugger', false ) ) {
	final class Execution_Debugger {

		/**
		 * Replay or dry-run simulate a logged API request from `{$wpdb->prefix}directrelay_log`.
		 *
		 * @param int  $log_id  Row ID in `directrelay_log`.
		 * @param bool $dry_run When true, validates scopes, guardrails, and schema without mutating DB.
		 * @return array|\WP_Error
		 */
		public static function replay( int $log_id, bool $dry_run = false ): array|\WP_Error {
			global $wpdb;
			$table = "{$wpdb->prefix}directrelay_log";

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$row = $wpdb->get_row(
				$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d LIMIT 1", $log_id ),
				ARRAY_A
			);

			if ( ! $row ) {
				return new \WP_Error( 'amp_not_found', __( 'Log entry not found.', 'directrelay-pro' ), [ 'status' => 404 ] );
			}

			$payload = ! empty( $row['request_payload'] ) ? ( json_decode( (string) $row['request_payload'], true ) ?: [] ) : [];
			$method  = strtoupper( (string) ( $row['method'] ?: 'POST' ) );
			$route   = (string) ( $row['endpoint'] ?: '/directrelay/v1/posts' );

			if ( $dry_run ) {
				$title   = (string) ( $payload['title'] ?? '' );
				$content = (string) ( $payload['content'] ?? $payload['content_preview'] ?? '' );
				$guard   = Guardrails_Manager::validate_content( $content, $title );

				return [
					'dry_run'              => true,
					'log_id'               => $log_id,
					'original_request_id'  => $row['request_uuid'],
					'method'               => $method,
					'endpoint'             => $route,
					'guardrails_passed'    => ! is_wp_error( $guard ),
					'guardrails_message'   => is_wp_error( $guard ) ? $guard->get_error_message() : 'All guardrails passed.',
					'seo_providers_active' => SEO_Write_Engine::detect_providers()['active'],
					'payload_inspected'    => $payload,
				];
			}

			$req = new \WP_REST_Request( $method, $route );
			$req->set_header( 'Content-Type', 'application/json' );
			$req->set_body( wp_json_encode( $payload ) );
			$req->set_param( '_amp_is_replay', true );

			$resp   = rest_do_request( $req );
			$status = $resp->get_status();

			return [
				'replayed'        => true,
				'dry_run'         => false,
				'source_log_id'   => $log_id,
				'replayed_status' => $status,
				'response'        => $resp->get_data(),
			];
		}

		/**
		 * Fetch the recent 50 execution log entries with payloads for the Debugger view.
		 */
		public static function recent_traces( int $limit = 50 ): array {
			global $wpdb;
			$limit = max( 1, min( 200, $limit ) );
			$table = "{$wpdb->prefix}directrelay_log";
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			return $wpdb->get_results(
				$wpdb->prepare( "SELECT * FROM {$table} ORDER BY created_at DESC LIMIT %d", $limit ),
				ARRAY_A
			) ?: [];
		}
	}
	}
}

namespace DirectRelay\Pro\REST {

	defined( 'ABSPATH' ) || exit;

	use DirectRelay\Agent_Profiles;
	use DirectRelay\Approval_Gateway;
	use DirectRelay\Execution_Debugger;
	use DirectRelay\Post_Manager;
	use DirectRelay\Pro\SEO_Write_Engine;
	use DirectRelay\Transactional_Publisher;
	use DirectRelay\Universal_Schema_Translator;

	/**
	 * Tier 1 — Module 2: One-Shot, Bulk & Universal Schema Publishing REST Controller
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\Publishing_Controller', false ) ) {
	final class Publishing_Controller extends Pro_Base_Controller {

		public static function register(): void {
			// 1. Atomic One-Shot Publish (`POST /publish/one-shot` & `POST /one-shot`)
			foreach ( [ '/publish/one-shot', '/one-shot' ] as $one_shot_route ) {
				register_rest_route(
					self::NS,
					$one_shot_route,
					[
						[
							'methods'             => \WP_REST_Server::CREATABLE,
							'callback'            => [ self::class, 'one_shot' ],
							'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:write' ),
						],
					]
				);
			}

			// 2. Bulk Operations (`POST /bulk`, `POST /posts/bulk`, `PUT /posts/bulk`)
			register_rest_route(
				self::NS,
				'/bulk',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'bulk' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'bulk:write' ),
					],
				]
			);
			register_rest_route(
				self::NS,
				'/posts/bulk',
				[
					[
						'methods'             => \WP_REST_Server::EDITABLE,
						'callback'            => [ self::class, 'bulk' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'bulk:write' ),
					],
				]
			);

			// 3. Universal Schema Publish (`POST /publish/universal` & `POST /universal`)
			foreach ( [ '/publish/universal', '/universal' ] as $univ_route ) {
				register_rest_route(
					self::NS,
					$univ_route,
					[
						[
							'methods'             => \WP_REST_Server::CREATABLE,
							'callback'            => [ self::class, 'universal' ],
							'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'universal:write' ),
						],
					]
				);
			}
		}

		/**
		 * Execute atomic One-Shot Publish (Post + Media + Gallery + Full SEO Write + Compensating Rollback).
		 */
		public static function one_shot( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$payload = $req->get_json_params() ?: [];
			$key     = (array) $req->get_param( '_amp_key' );

			$tx = Transactional_Publisher::execute( $payload, $key );
			if ( is_wp_error( $tx ) ) {
				return self::fail( $req, $tx, 'one_shot_publish' );
			}

			$post_id = (int) ( $tx['post_id'] ?? 0 );
			if ( $post_id > 0 && ! empty( $payload['seo'] ) && is_array( $payload['seo'] ) ) {
				$seo_res = SEO_Write_Engine::update( $post_id, $payload['seo'] );
				if ( is_wp_error( $seo_res ) ) {
					// If strict rollback is enabled, roll back the post and media created by Transactional_Publisher.
					if ( ! empty( $payload['rollback_on_failure'] ?? true ) ) {
						if ( ! empty( $tx['featured_media_id'] ) ) {
							wp_delete_attachment( (int) $tx['featured_media_id'], true );
						}
						foreach ( (array) ( $tx['gallery_media_ids'] ?? [] ) as $gid ) {
							wp_delete_attachment( (int) $gid, true );
						}
						wp_delete_post( $post_id, true );
						$crons = function_exists( '_get_cron_array' ) ? ( _get_cron_array() ?: [] ) : [];
						foreach ( $crons as $ts => $cron_events ) {
							foreach ( [ 'directrelay_fire_webhook', 'directrelay_deliver_webhook' ] as $chook ) {
								if ( empty( $cron_events[ $chook ] ) ) {
									continue;
								}
								foreach ( $cron_events[ $chook ] as $entry ) {
									$cargs  = $entry['args'] ?? [];
									$obj_id = ( 'directrelay_fire_webhook' === $chook ) ? ( $cargs[1] ?? null ) : ( $cargs[2] ?? null );
									if ( (int) $obj_id === $post_id ) {
										wp_unschedule_event( $ts, $chook, $cargs );
									}
								}
							}
						}
					}
					return self::fail( $req, $seo_res, 'one_shot_publish' );
				}
				$tx['execution_steps']['seo'] = 'completed';
				$tx['seo']                    = $seo_res['seo'];
				$tx['seo_updated_fields']     = $seo_res['updated_fields'];
			}

			return self::ok( $req, $tx, 201, 'one_shot_publish', $post_id, (string) ( $payload['post_type'] ?? 'post' ) );
		}

		/**
		 * Execute Bulk Publish / Create / Update / Trash / Delete (up to 50 items per call).
		 */
		public static function bulk( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body      = $req->get_json_params() ?: [];
			$operation = strtolower( sanitize_key( (string) ( $body['operation'] ?? 'create' ) ) );
			$items     = isset( $body['items'] ) && is_array( $body['items'] ) ? $body['items'] : ( isset( $body['posts'] ) && is_array( $body['posts'] ) ? $body['posts'] : [] );

			if ( empty( $items ) ) {
				return self::fail(
					$req,
					new \WP_Error( 'amp_invalid', __( 'Bulk request requires a non-empty "items" array.', 'directrelay-pro' ), [ 'status' => 400 ] ),
					'bulk_' . $operation
				);
			}

			if ( count( $items ) > 50 ) {
				return self::fail(
					$req,
					new \WP_Error( 'amp_bulk_limit', __( 'Bulk endpoint supports up to 50 items per request.', 'directrelay-pro' ), [ 'status' => 400 ] ),
					'bulk_' . $operation
				);
			}

			$key       = (array) $req->get_param( '_amp_key' );
			$results   = [];
			$succeeded = 0;
			$failed    = 0;

			foreach ( $items as $index => $item ) {
				if ( ! is_array( $item ) ) {
					++$failed;
					$results[] = [ 'index' => $index, 'success' => false, 'error' => 'Item must be an object.' ];
					continue;
				}

				$item_op = strtolower( sanitize_key( (string) ( $item['operation'] ?? $operation ) ) );
				$post_id = (int) ( $item['id'] ?? $item['post_id'] ?? 0 );

				if ( 'publish' === $item_op && $post_id > 0 ) {
					$own = Agent_Profiles::assert_owns( $key, $post_id );
					if ( is_wp_error( $own ) ) {
						++$failed;
						$results[] = [ 'index' => $index, 'id' => $post_id, 'success' => false, 'error' => $own->get_error_message() ];
						continue;
					}
					$r = wp_update_post( [ 'ID' => $post_id, 'post_status' => 'publish' ], true );
					if ( is_wp_error( $r ) ) {
						++$failed;
						$results[] = [ 'index' => $index, 'id' => $post_id, 'success' => false, 'error' => $r->get_error_message() ];
					} else {
						++$succeeded;
						$results[] = [ 'index' => $index, 'id' => $post_id, 'success' => true, 'status' => 'publish', 'permalink' => get_permalink( $post_id ) ];
					}
					continue;
				}

				if ( in_array( $item_op, [ 'trash', 'delete' ], true ) && $post_id > 0 ) {
					$own = Agent_Profiles::assert_owns( $key, $post_id );
					if ( is_wp_error( $own ) ) {
						++$failed;
						$results[] = [ 'index' => $index, 'id' => $post_id, 'success' => false, 'error' => $own->get_error_message() ];
						continue;
					}
					$deleted = wp_delete_post( $post_id, 'delete' === $item_op );
					if ( ! $deleted ) {
						++$failed;
						$results[] = [ 'index' => $index, 'id' => $post_id, 'success' => false, 'error' => 'Delete failed.' ];
					} else {
						++$succeeded;
						$results[] = [ 'index' => $index, 'id' => $post_id, 'success' => true, 'deleted' => true ];
					}
					continue;
				}

				if ( 'update' === $item_op && $post_id > 0 ) {
					$own = Agent_Profiles::assert_owns( $key, $post_id );
					if ( is_wp_error( $own ) ) {
						++$failed;
						$results[] = [ 'index' => $index, 'id' => $post_id, 'success' => false, 'error' => $own->get_error_message() ];
						continue;
					}
					$upd = Post_Manager::update( $post_id, $item );
					if ( is_wp_error( $upd ) ) {
						++$failed;
						$results[] = [ 'index' => $index, 'id' => $post_id, 'success' => false, 'error' => $upd->get_error_message() ];
						continue;
					}
					if ( ! empty( $item['seo'] ) && is_array( $item['seo'] ) ) {
						SEO_Write_Engine::update( $post_id, $item['seo'] );
					}
					++$succeeded;
					$results[] = [ 'index' => $index, 'id' => $post_id, 'success' => true, 'permalink' => get_permalink( $post_id ) ];
					continue;
				}

				// Default: Create post/page with optional inline SEO + Guardrails check.
				$post_type = sanitize_key( (string) ( $item['post_type'] ?? 'post' ) );
				if ( ! Agent_Profiles::is_status_allowed( $key, (string) ( $item['status'] ?? 'draft' ) ) ) {
					$item['status'] = 'draft';
				}
				if ( ! empty( $item['content'] ) && class_exists( '\DirectRelay\Guardrails_Manager' ) ) {
					$item['content'] = \DirectRelay\Guardrails_Manager::sanitize_ai_leakage( (string) $item['content'] );
				}
				if ( class_exists( '\DirectRelay\Guardrails_Manager' ) ) {
					$g_check = \DirectRelay\Guardrails_Manager::validate_content( (string) ( $item['content'] ?? '' ), (string) ( $item['title'] ?? '' ), $key );
					if ( is_wp_error( $g_check ) ) {
						++$failed;
						$results[] = [ 'index' => $index, 'success' => false, 'error' => $g_check->get_error_message() ];
						continue;
					}
				}
				$created_id = Post_Manager::create( $item, $post_type );
				if ( is_wp_error( $created_id ) ) {
					++$failed;
					$results[] = [ 'index' => $index, 'success' => false, 'error' => $created_id->get_error_message() ];
					continue;
				}
				Agent_Profiles::stamp_post( (int) $created_id, $key );
				if ( class_exists( '\DirectRelay\Guardrails_Manager' ) ) {
					\DirectRelay\Guardrails_Manager::increment_daily_usage( (int) ( $key['id'] ?? 0 ) );
				}
				if ( ! empty( $item['seo'] ) && is_array( $item['seo'] ) ) {
					SEO_Write_Engine::update( (int) $created_id, $item['seo'] );
				}
				++$succeeded;
				$results[] = [
					'index'     => $index,
					'id'        => (int) $created_id,
					'success'   => true,
					'status'    => get_post_status( (int) $created_id ),
					'permalink' => get_permalink( (int) $created_id ),
				];
			}

			return self::ok(
				$req,
				[
					'operation' => $operation,
					'total'     => count( $items ),
					'succeeded' => $succeeded,
					'failed'    => $failed,
					'results'   => $results,
				],
				200,
				'bulk_' . $operation
			);
		}

		/**
		 * Execute Universal Schema Publish (`POST /publish/universal`).
		 */
		public static function universal( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$raw        = $req->get_json_params() ?: [];
			$translated = Universal_Schema_Translator::translate( $raw );
			if ( is_wp_error( $translated ) ) {
				return self::fail( $req, $translated, 'universal_publish' );
			}

			$req->set_body( wp_json_encode( $translated ) );
			$resp = self::one_shot( $req );
			if ( $resp instanceof \WP_REST_Response ) {
				$data                              = $resp->get_data();
				$data['data']['translated_schema'] = [
					'title'      => $translated['title'],
					'post_type'  => $translated['post_type'],
					'status'     => $translated['status'],
					'seo_fields' => array_keys( $translated['seo'] ?? [] ),
				];
				$resp->set_data( $data );
			}
			return $resp;
		}
	}
	}

	/**
	 * Tier 1 — Module 3 REST Controller: Human Approval Portal Endpoints
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\Approval_Controller', false ) ) {
	final class Approval_Controller extends Pro_Base_Controller {

		public static function register(): void {
			register_rest_route(
				self::NS,
				'/approvals',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'index' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'approval:read' ),
					],
				]
			);
			register_rest_route(
				self::NS,
				'/approvals/(?P<uuid>[a-f0-9-]+)',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'show' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'approval:read' ),
					],
				]
			);
			register_rest_route(
				self::NS,
				'/approvals/(?P<uuid>[a-f0-9-]+)/approve',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'approve' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'approval:write' ),
					],
				]
			);
			register_rest_route(
				self::NS,
				'/approvals/(?P<uuid>[a-f0-9-]+)/reject',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'reject' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'approval:write' ),
					],
				]
			);
		}

		public static function index( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$status  = sanitize_key( (string) $req->get_param( 'status' ) );
			$tickets = Approval_Gateway::list_tickets( $status );
			return self::ok( $req, [ 'tickets' => $tickets, 'total' => count( $tickets ) ], 200, 'list_approvals' );
		}

		public static function show( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			global $wpdb;
			$uuid  = sanitize_text_field( (string) $req->get_param( 'uuid' ) );
			$table = "{$wpdb->prefix}directrelay_approvals";
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE ticket_uuid = %s LIMIT 1", $uuid ), ARRAY_A );
			if ( ! $row ) {
				return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Approval ticket not found.', 'directrelay-pro' ), [ 'status' => 404 ] ), 'get_approval' );
			}
			unset( $row['token_hash'] );
			return self::ok( $req, [ 'ticket' => $row ], 200, 'get_approval' );
		}

		public static function approve( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$uuid = sanitize_text_field( (string) $req->get_param( 'uuid' ) );
			$res  = Approval_Gateway::approve( $uuid, get_current_user_id() );
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'approve_ticket' );
			}
			return self::ok( $req, $res, 200, 'approve_ticket', (int) ( $res['post_id'] ?? 0 ), 'post' );
		}

		public static function reject( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$uuid     = sanitize_text_field( (string) $req->get_param( 'uuid' ) );
			$body     = $req->get_json_params() ?: [];
			$feedback = sanitize_textarea_field( (string) ( $body['feedback'] ?? '' ) );
			$res      = Approval_Gateway::reject( $uuid, $feedback, get_current_user_id() );
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'reject_ticket' );
			}
			return self::ok( $req, $res, 200, 'reject_ticket', (int) ( $res['post_id'] ?? 0 ), 'post' );
		}
	}
	}

	/**
	 * Tier 1 — Module 5 REST Controller: Execution Debugger & Replay Endpoints
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\Debugger_Controller', false ) ) {
	final class Debugger_Controller extends Pro_Base_Controller {

		public static function register(): void {
			register_rest_route(
				self::NS,
				'/debugger/logs',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'logs' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'debugger:read' ),
					],
				]
			);
			register_rest_route(
				self::NS,
				'/debugger/logs/(?P<id>\d+)',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'show_log' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'debugger:read' ),
					],
				]
			);
			register_rest_route(
				self::NS,
				'/debugger/replay/(?P<id>\\d+)',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'replay' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'debugger:write' ),
					],
				]
			);
		}

		public static function logs( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$limit = max( 1, min( 100, (int) ( $req->get_param( 'limit' ) ?: 50 ) ) );
			$rows  = Execution_Debugger::recent_traces( $limit );
			return self::ok( $req, [ 'traces' => $rows, 'total' => count( $rows ) ], 200, 'debugger_logs' );
		}

		public static function show_log( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id  = (int) $req->get_param( 'id' );
			$res = Execution_Debugger::replay( $id, true );
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'debugger_show_log' );
			}
			return self::ok( $req, $res, 200, 'debugger_show_log', $id, 'log' );
		}

		public static function replay( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id      = (int) $req->get_param( 'id' );
			$body    = $req->get_json_params() ?: [];
			$dry_run = ! empty( $body['dry_run'] ) || ! empty( $req->get_param( 'dry_run' ) );
			$res     = Execution_Debugger::replay( $id, $dry_run );
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'debugger_replay' );
			}
			return self::ok( $req, $res, 200, 'debugger_replay', $id, 'log' );
		}
	}
	}

	/**
	 * Tier 1 — Module 6 REST Controller: Advanced Analytics Endpoints
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\Analytics_Controller', false ) ) {
	final class Analytics_Controller extends Pro_Base_Controller {

		public static function register(): void {
			register_rest_route(
				self::NS,
				'/analytics',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'index' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'analytics:read' ),
					],
				]
			);
		}

		public static function index( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$hours  = max( 1, min( 720, (int) ( $req->get_param( 'hours' ) ?: 24 ) ) );
			$key_id = (int) $req->get_param( 'key_id' ) ?: null;
			return self::ok(
				$req,
				[
					'summary'       => \DirectRelay\Activity_Logger::summary(),
					'hourly'        => \DirectRelay\Activity_Logger::hourly_stats( $hours, $key_id ),
					'top_endpoints' => \DirectRelay\Activity_Logger::top_endpoints( 7 ),
				],
				200,
				'get_analytics'
			);
		}
	}
	}
}

namespace DirectRelay\Pro {

	defined( 'ABSPATH' ) || exit;

	use DirectRelay\Approval_Gateway;
	use DirectRelay\Execution_Debugger;
	use DirectRelay\Guardrails_Manager;

	/**
	 * Tier 1 — Module 6: Admin UI Extensions (Submenus, Chart.js Dashboard Panel,
	 * Pro n8n Templates Library, and Agentic Dark Mode).
	 */
	if ( ! class_exists( '\DirectRelay\Pro\Admin_Extension', false ) ) {
	final class Admin_Extension {

		public static function init(): void {
			add_action( 'directrelay_ext_register_admin', [ __CLASS__, 'register_submenus' ] );
			add_filter( 'directrelay_ext_dashboard_data', [ __CLASS__, 'filter_dashboard_data' ] );
			add_action( 'directrelay_ext_render_pro_dashboard_panel', [ __CLASS__, 'render_dashboard_charts' ] );
			add_filter( 'directrelay_ext_body_class', [ __CLASS__, 'filter_body_class' ], 10, 2 );
			add_filter( 'directrelay_ext_templates', [ __CLASS__, 'register_pro_templates' ] );
			add_action( 'admin_head', [ __CLASS__, 'inject_dark_mode_css' ] );
			add_action( 'admin_footer', [ __CLASS__, 'inject_pro_admin_bridge_js' ] );

			// Admin AJAX handlers for Tier 2 (Internal Link Rules, Google Indexing SA, CDN Purge, Smart Media OG Card)
			// and Tier 3 (Pre-AI Snapshot Rollback) & Tier 4 (DLQ Re-Drive).
			add_action( 'wp_ajax_directrelay_pro_save_link_rule', [ __CLASS__, 'ajax_save_link_rule' ] );
			add_action( 'wp_ajax_directrelay_pro_delete_link_rule', [ __CLASS__, 'ajax_delete_link_rule' ] );
			add_action( 'wp_ajax_directrelay_pro_save_indexing_cdn', [ __CLASS__, 'ajax_save_indexing_cdn' ] );
			add_action( 'wp_ajax_directrelay_pro_test_index_purge', [ __CLASS__, 'ajax_test_index_purge' ] );
			add_action( 'wp_ajax_directrelay_pro_generate_og_card', [ __CLASS__, 'ajax_generate_og_card' ] );
			add_action( 'wp_ajax_directrelay_pro_rollback_snapshot', [ __CLASS__, 'ajax_rollback_snapshot' ] );
			add_action( 'wp_ajax_directrelay_pro_redrive_dlq', [ __CLASS__, 'ajax_redrive_dlq' ] );
		}

		/**
		 * Enrich the Free dashboard data array via `directrelay_ext_dashboard_data`.
		 */
		public static function filter_dashboard_data( array $data ): array {
			$lic = class_exists( '\DirectRelay\Pro\License_Manager' )
				? \DirectRelay\Pro\License_Manager::get_public_status()
				: [ 'valid' => false, 'plan' => 'free' ];

			$data['pro_version']       = DIRECTRELAY_PRO_VERSION;
			$data['license']           = $lic;
			$data['pending_approvals'] = count( Approval_Gateway::list_tickets( 'pending', 100 ) );
			$data['dlq_count']         = class_exists( '\DirectRelay\Pro\Webhook_V2_Engine' )
				? count( Webhook_V2_Engine::list_dlq( 50 ) )
				: 0;
			return $data;
		}

		/**
		 * Register Approvals, AI Guardrails, and Debugger submenus under DirectRelay.
		 */
		public static function register_submenus(): void {
			$cap = class_exists( '\DirectRelay\Admin\Menu' ) ? \DirectRelay\Admin\Menu::get_cap() : 'manage_options';

			add_submenu_page(
				'directrelay-cm',
				esc_html__( 'SEO, GEO & Indexing Hub', 'directrelay-pro' ),
				esc_html__( 'SEO, GEO & CDN', 'directrelay-pro' ),
				$cap,
				'directrelay-seo-geo',
				[ __CLASS__, 'render_seo_geo_page' ]
			);

			add_submenu_page(
				'directrelay-cm',
				esc_html__( 'CPT, WooCommerce & Content Decay', 'directrelay-pro' ),
				esc_html__( 'CPT, WC & Decay', 'directrelay-pro' ),
				$cap,
				'directrelay-content-decay',
				[ __CLASS__, 'render_cpt_decay_page' ]
			);

			add_submenu_page(
				'directrelay-cm',
				esc_html__( 'Approvals Portal', 'directrelay-pro' ),
				esc_html__( 'Approvals', 'directrelay-pro' ),
				$cap,
				'directrelay-approvals',
				[ __CLASS__, 'render_approvals_page' ]
			);

			add_submenu_page(
				'directrelay-cm',
				esc_html__( 'AI Guardrails', 'directrelay-pro' ),
				esc_html__( 'AI Guardrails', 'directrelay-pro' ),
				$cap,
				'directrelay-guardrails',
				[ __CLASS__, 'render_guardrails_page' ]
			);

			add_submenu_page(
				'directrelay-cm',
				esc_html__( 'Execution Debugger', 'directrelay-pro' ),
				esc_html__( 'Debugger', 'directrelay-pro' ),
				$cap,
				'directrelay-debugger',
				[ __CLASS__, 'render_debugger_page' ]
			);

			add_submenu_page(
				'directrelay-cm',
				esc_html__( 'License & Fleet Link', 'directrelay-pro' ),
				esc_html__( 'License & Fleet', 'directrelay-pro' ),
				$cap,
				'directrelay-license',
				[ '\DirectRelay\Pro\License_Manager', 'render_admin_page' ]
			);
		}

		/**
		 * Inject lightweight Admin JS bridge on DirectRelay screens to:
		 * 1. Unlock `.directrelay-load-preset` buttons on the Webhooks screen (`data-ispro="1"`) when Pro is active.
		 * 2. Replace the Free bottom callout box on the Dashboard with a live License & Fleet Status Banner.
		 */
		public static function inject_pro_admin_bridge_js(): void {
			$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
			if ( ! $screen || ! str_contains( $screen->id, 'directrelay' ) ) {
				return;
			}
			$lic        = class_exists( '\DirectRelay\Pro\License_Manager' ) ? \DirectRelay\Pro\License_Manager::get_public_status() : [];
			$is_active  = ! empty( $lic['is_active'] );
			$plan_label = (string) ( $lic['plan_label'] ?? 'Unlicensed / Dev Grace' );
			$key_masked = (string) ( $lic['key_masked'] ?? 'Not Activated' );
			$lic_url    = admin_url( 'admin.php?page=directrelay-license' );
			?>
			<script id="directrelay-pro-admin-bridge">
			jQuery(function($){
				// 1. Unlock Webhook Presets in Free's webhooks.php when DirectRelay Pro is active
				<?php if ( $is_active ) : ?>
				$('.directrelay-load-preset').attr('data-ispro', '1').data('ispro', 1);
				<?php endif; ?>

				// 2. Upgrade the dashed Free upsell card at the bottom of the Dashboard into a Live Pro License Status Bar
				$('.directrelay-card[style*="dashed"]').each(function(){
					var $card = $(this);
					if ($card.text().indexOf('DirectRelay add-on') !== -1) {
						$card.css({'border-style': 'solid', 'border-left': '4px solid <?php echo $is_active ? '#10b981' : '#f59e0b'; ?>'});
						$card.find('.directrelay-card-body').html(
							'<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">' +
								'<div>' +
									'<strong style="color:var(--directrelay-text,#111827);font-size:14px;">🛡️ DirectRelay Pro v<?php echo esc_js( DIRECTRELAY_PRO_VERSION ); ?> — <?php echo esc_js( $plan_label ); ?></strong>' +
									'<span style="margin-left:10px;font-size:12px;padding:2px 8px;border-radius:99px;background:<?php echo $is_active ? 'rgba(16,185,129,0.15)' : 'rgba(245,158,11,0.15)'; ?>;color:<?php echo $is_active ? '#10b981' : '#f59e0b'; ?>;font-weight:600;"><?php echo $is_active ? 'LICENSE ACTIVE' : 'ACTIVATE LICENSE'; ?></span>' +
									'<p style="margin:4px 0 0;font-size:13px;color:var(--directrelay-muted,#6b7280);">Key: <code><?php echo esc_js( $key_masked ); ?></code> &bull; All 4 Monster Pro Tiers (Bidirectional SEO, GEO/llms.txt, Google Indexing, CPT/ACF/WC, Fleet & DLQ) are online.</p>' +
								'</div>' +
								'<a href="<?php echo esc_url( $lic_url ); ?>" class="button button-primary"><?php echo $is_active ? esc_js( __( 'Manage License & Telemetry', 'directrelay-pro' ) ) : esc_js( __( 'Activate License Key', 'directrelay-pro' ) ); ?></a>' +
							'</div>'
						);
					}
				});
			});
			</script>
			<?php
		}

		/**
		 * Append `directrelay-mode-dark` when Agentic Dark Mode is selected in DirectRelay Settings.
		 */
		public static function filter_body_class( string $classes, string $hook ): string {
			$settings = get_option( 'directrelay_settings', [] );
			if ( ( $settings['ui_mode'] ?? 'standard' ) === 'dark' ) {
				$classes .= ' directrelay-mode-dark';
			}
			return $classes;
		}

		/**
		 * Inject Agentic Dark Mode CSS variables when active on DirectRelay admin screens.
		 */
		public static function inject_dark_mode_css(): void {
			$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
			if ( ! $screen || ( ! str_contains( $screen->id, 'directrelay' ) ) ) {
				return;
			}
			?>
			<style id="directrelay-pro-dark-mode">
				body.directrelay-mode-dark #wpcontent,
				body.directrelay-mode-dark #wpbody-content {
					background: #0b0f19;
				}
				body.directrelay-mode-dark .directrelay-wrap {
					--directrelay-bg: #0b0f19;
					--directrelay-card: #111827;
					--directrelay-card2: #1f2937;
					--directrelay-border: #374151;
					--directrelay-border2: #4b5563;
					--directrelay-primary: #28CCCD;
					--directrelay-accent: #3EE0E0;
					--directrelay-text: #f9fafb;
					--directrelay-dim: #e5e7eb;
					--directrelay-muted: #9ca3af;
				}
			</style>
			<?php
		}

		/**
		 * Render the Chart.js Analytics & Live Telemetry panel inside the main Dashboard.
		 */
		public static function render_dashboard_charts( array $dashboard_data ): void {
			?>
			<div class="directrelay-card" style="margin-bottom:20px">
				<div class="directrelay-card-header" style="display:flex;justify-content:space-between;align-items:center">
					<h3 style="margin:0"><?php esc_html_e( 'Pro Live Telemetry & Latency Trends (24h)', 'directrelay-pro' ); ?></h3>
					<span id="directrelay-live-indicator" class="directrelay-badge directrelay-badge-active">● <?php esc_html_e( 'LIVE 10s POLLING', 'directrelay-pro' ); ?></span>
				</div>
				<div class="directrelay-grid-2" style="padding:16px">
					<div style="height:240px;position:relative">
						<canvas id="directrelay-req-chart" width="540" height="220"></canvas>
					</div>
					<div style="height:240px;position:relative">
						<canvas id="directrelay-ms-chart" width="540" height="220"></canvas>
					</div>
				</div>
			</div>
			<script>
			(function(){
				if (typeof window.Chart !== 'undefined') return;
				window.Chart = function(canvas, cfg) {
					this.canvas = canvas;
					this.data = (cfg && cfg.data) ? cfg.data : { labels: [], datasets: [] };
					this.type = (cfg && cfg.type) ? cfg.type : 'bar';
					this.update = function() {
						if (!this.canvas || !this.canvas.getContext) return;
						var ctx = this.canvas.getContext('2d');
						var w = this.canvas.width = this.canvas.parentElement.clientWidth || 520;
						var h = this.canvas.height = this.canvas.parentElement.clientHeight || 220;
						ctx.clearRect(0, 0, w, h);
						var labels = this.data.labels || [];
						var ds = (this.data.datasets && this.data.datasets[0]) ? this.data.datasets[0].data : [];
						if (!labels.length || !ds.length) return;
						var maxVal = Math.max.apply(null, ds.concat([1]));
						var padL = 36, padR = 12, padT = 24, padB = 26;
						var plotW = w - padL - padR, plotH = h - padT - padB;
						ctx.strokeStyle = 'rgba(148,163,184,0.2)';
						ctx.beginPath();
						ctx.moveTo(padL, padT); ctx.lineTo(padL, h - padB); ctx.lineTo(w - padR, h - padB);
						ctx.stroke();
						var stepX = plotW / Math.max(labels.length, 1);
						if (this.type === 'line') {
							ctx.strokeStyle = '#c77dff';
							ctx.lineWidth = 2;
							ctx.beginPath();
							for (var i = 0; i < ds.length; i++) {
								var x = padL + i * stepX + stepX / 2;
								var y = padT + plotH - (ds[i] / maxVal) * plotH;
								if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
							}
							ctx.stroke();
						} else {
							for (var j = 0; j < ds.length; j++) {
								var bx = padL + j * stepX + 2;
								var bh = (ds[j] / maxVal) * plotH;
								var by = padT + plotH - bh;
								ctx.fillStyle = 'rgba(40,204,205,0.75)';
								ctx.fillRect(bx, by, Math.max(4, stepX - 4), bh);
							}
						}
					};
					this.update();
				};
			})();
			</script>
			<?php
		}

		/**
		 * Render the Approvals Queue submenu page (`.directrelay-btn-approve-ticket` & `.directrelay-btn-reject-ticket`).
		 */
		public static function render_approvals_page(): void {
			$tickets = Approval_Gateway::list_tickets( '', 100 );
			?>
			<div class="directrelay-wrap">
				<div class="directrelay-header">
					<div class="directrelay-header-left">
						<h1 class="directrelay-page-title"><?php esc_html_e( 'Human Approval Gateway', 'directrelay-pro' ); ?></h1>
						<span class="directrelay-badge-pill">PRO</span>
					</div>
				</div>
				<div class="directrelay-card">
					<div class="directrelay-card-header">
						<h3><?php esc_html_e( 'Pending & Historical Review Tickets', 'directrelay-pro' ); ?></h3>
					</div>
					<?php if ( empty( $tickets ) ) : ?>
						<p class="directrelay-empty"><?php esc_html_e( 'No approval tickets yet. Enable "Enforce Human Approval Gateway" on an API key or pass "require_approval": true.', 'directrelay-pro' ); ?></p>
					<?php else : ?>
						<table class="directrelay-table widefat">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Ticket UUID', 'directrelay-pro' ); ?></th>
									<th><?php esc_html_e( 'Post', 'directrelay-pro' ); ?></th>
									<th><?php esc_html_e( 'Status', 'directrelay-pro' ); ?></th>
									<th><?php esc_html_e( 'Magic Review URL', 'directrelay-pro' ); ?></th>
									<th><?php esc_html_e( 'Created', 'directrelay-pro' ); ?></th>
									<th><?php esc_html_e( 'Actions', 'directrelay-pro' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $tickets as $t ) : ?>
									<tr>
										<td><code><?php echo esc_html( substr( $t['ticket_uuid'], 0, 8 ) ); ?>…</code></td>
										<td>
											<strong><a href="<?php echo esc_url( get_edit_post_link( (int) $t['post_id'] ) ?: '#' ); ?>"><?php echo esc_html( $t['post_title'] ); ?></a></strong>
											<?php if ( ! empty( $t['editor_feedback'] ) ) : ?>
												<br><small style="color:var(--directrelay-muted)"><?php echo esc_html( $t['editor_feedback'] ); ?></small>
											<?php endif; ?>
										</td>
										<td><span class="directrelay-badge"><?php echo esc_html( strtoupper( $t['status'] ) ); ?></span></td>
										<td>
											<?php if ( ! empty( $t['review_url'] ) ) : ?>
												<a href="<?php echo esc_url( $t['review_url'] ); ?>" target="_blank" rel="noopener" class="directrelay-link"><?php esc_html_e( 'Open Magic Portal ↗', 'directrelay-pro' ); ?></a>
											<?php else : ?>
												—
											<?php endif; ?>
										</td>
										<td><small><?php echo esc_html( $t['created_at'] ); ?></small></td>
										<td>
											<?php if ( 'pending' === $t['status'] ) : ?>
												<button type="button" class="button button-primary directrelay-btn-approve-ticket" data-uuid="<?php echo esc_attr( $t['ticket_uuid'] ); ?>"><?php esc_html_e( 'Approve', 'directrelay-pro' ); ?></button>
												<button type="button" class="button directrelay-btn-reject-ticket" data-uuid="<?php echo esc_attr( $t['ticket_uuid'] ); ?>"><?php esc_html_e( 'Reject', 'directrelay-pro' ); ?></button>
											<?php else : ?>
												<small><?php echo esc_html( $t['resolved_at'] ?: '—' ); ?></small>
											<?php endif; ?>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					<?php endif; ?>
				</div>
			</div>
			<?php
		}

		/**
		 * Render the AI Guardrails configuration page (`#directrelay-guardrails-form` & `#directrelay-save-guardrails`).
		 */
		public static function render_guardrails_page(): void {
			$g = Guardrails_Manager::settings();
			?>
			<div class="directrelay-wrap">
				<div class="directrelay-header">
					<div class="directrelay-header-left">
						<h1 class="directrelay-page-title"><?php esc_html_e( 'AI Content Guardrails & Velocity Caps', 'directrelay-pro' ); ?></h1>
						<span class="directrelay-badge-pill">PRO</span>
					</div>
				</div>
				<div class="directrelay-card" style="padding:24px">
					<form id="directrelay-guardrails-form">
						<p>
							<label><strong><?php esc_html_e( 'Global Max Daily Posts', 'directrelay-pro' ); ?></strong></label><br>
							<input type="number" name="max_daily_posts" value="<?php echo (int) $g['max_daily_posts']; ?>" min="1" max="10000" class="directrelay-input">
						</p>
						<p>
							<label><strong><?php esc_html_e( 'Minimum Word Count', 'directrelay-pro' ); ?></strong></label><br>
							<input type="number" name="min_word_count" value="<?php echo (int) $g['min_word_count']; ?>" min="0" max="50000" class="directrelay-input">
						</p>
						<p>
							<label><strong><?php esc_html_e( 'Maximum Word Count', 'directrelay-pro' ); ?></strong></label><br>
							<input type="number" name="max_word_count" value="<?php echo (int) $g['max_word_count']; ?>" min="100" max="100000" class="directrelay-input">
						</p>
						<p>
							<label>
								<input type="checkbox" name="clean_ai_leakage" value="1" <?php checked( ! empty( $g['clean_ai_leakage'] ) ); ?>>
								<strong><?php esc_html_e( 'Scrub AI Prompt Leakage & Placeholders ([Insert ...], "As an AI language model...")', 'directrelay-pro' ); ?></strong>
							</label>
						</p>
						<p>
							<label>
								<input type="checkbox" name="prevent_duplicate_titles" value="1" <?php checked( ! empty( $g['prevent_duplicate_titles'] ) ); ?>>
								<strong><?php esc_html_e( 'Prevent Duplicate Post Titles (Anti-Cannibalization Gate)', 'directrelay-pro' ); ?></strong>
							</label>
						</p>
						<p>
							<label><strong><?php esc_html_e( 'Blocked Phrases / Restricted Competitors (one per line or comma-separated)', 'directrelay-pro' ); ?></strong></label><br>
							<textarea name="blocked_phrases" rows="4" class="directrelay-input" style="width:100%"><?php echo esc_textarea( (string) $g['blocked_phrases'] ); ?></textarea>
						</p>
						<p>
							<button type="button" id="directrelay-save-guardrails" class="button button-primary"><?php esc_html_e( 'Save Guardrail Settings', 'directrelay-pro' ); ?></button>
							<span id="guardrails-spinner" class="spinner" style="float:none"></span>
						</p>
					</form>
				</div>
			</div>
			<?php
		}

		/**
		 * Render the Execution Debugger & Replay page (`.directrelay-btn-replay`).
		 */
		public static function render_debugger_page(): void {
			$traces = Execution_Debugger::recent_traces( 50 );
			?>
			<div class="directrelay-wrap">
				<div class="directrelay-header">
					<div class="directrelay-header-left">
						<h1 class="directrelay-page-title"><?php esc_html_e( 'Time-Travel Execution Debugger', 'directrelay-pro' ); ?></h1>
						<span class="directrelay-badge-pill">PRO</span>
					</div>
				</div>
				<div class="directrelay-card">
					<div class="directrelay-card-header">
						<h3><?php esc_html_e( 'Recent 50 API Executions (Dry-Run & 1-Click Replay)', 'directrelay-pro' ); ?></h3>
					</div>
					<?php if ( empty( $traces ) ) : ?>
						<p class="directrelay-empty"><?php esc_html_e( 'No API requests logged yet.', 'directrelay-pro' ); ?></p>
					<?php else : ?>
						<table class="directrelay-table widefat">
							<thead>
								<tr>
									<th><?php esc_html_e( 'ID', 'directrelay-pro' ); ?></th>
									<th><?php esc_html_e( 'Time (UTC)', 'directrelay-pro' ); ?></th>
									<th><?php esc_html_e( 'Method & Endpoint', 'directrelay-pro' ); ?></th>
									<th><?php esc_html_e( 'Status', 'directrelay-pro' ); ?></th>
									<th><?php esc_html_e( 'Latency', 'directrelay-pro' ); ?></th>
									<th><?php esc_html_e( 'Payload Preview', 'directrelay-pro' ); ?></th>
									<th><?php esc_html_e( 'Actions', 'directrelay-pro' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $traces as $tr ) : ?>
									<tr>
										<td><code>#<?php echo (int) $tr['id']; ?></code></td>
										<td><small><?php echo esc_html( $tr['created_at'] ); ?></small></td>
										<td>
											<strong><?php echo esc_html( $tr['method'] ); ?></strong>
											<code><?php echo esc_html( $tr['endpoint'] ); ?></code>
										</td>
										<td><span class="directrelay-badge"><?php echo (int) $tr['http_status']; ?></span></td>
										<td><?php echo (int) $tr['duration_ms']; ?>ms</td>
										<td><code style="font-size:11px"><?php echo esc_html( mb_strimwidth( (string) ( $tr['request_payload'] ?? '' ), 0, 90, '…' ) ); ?></code></td>
										<td>
											<button type="button" class="button directrelay-btn-replay" data-id="<?php echo (int) $tr['id']; ?>" data-dry="1"><?php esc_html_e( 'Dry Run', 'directrelay-pro' ); ?></button>
											<button type="button" class="button button-primary directrelay-btn-replay" data-id="<?php echo (int) $tr['id']; ?>" data-dry="0">⚡ <?php esc_html_e( 'Replay', 'directrelay-pro' ); ?></button>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					<?php endif; ?>
				</div>
			</div>
			<?php
		}

		/**
		 * Render Tier 2 Admin Hub: Bidirectional SEO, Internal Linking Silo Rules, GEO `/llms.txt`,
		 * Google Indexing API Service Account, Edge CDN Auto-Purge & Smart Media OG Card Generator.
		 */
		public static function render_seo_geo_page(): void {
			$seo_providers = SEO_Write_Engine::detect_providers();
			$rules         = Internal_Linking_Engine::get_rules();
			$sa            = Instant_Indexer_CDN::get_service_account();
			$settings      = get_option( 'directrelay_settings', [] );
			$nonce         = wp_create_nonce( 'directrelay_pro_admin_hub' );
			?>
			<div class="directrelay-wrap" style="max-width:1200px;margin:20px auto;padding:0 16px;">
				<div class="directrelay-header" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:20px;">
					<div>
						<h1 style="margin:0;font-size:24px;">🚀 <?php esc_html_e( 'SEO, GEO / AEO, Instant Indexing & Smart Media Hub', 'directrelay-pro' ); ?></h1>
						<p style="margin:4px 0 0;color:var(--directrelay-muted,#6b7280);font-size:13px;">
							<?php esc_html_e( 'Manage 4-Plugin Bidirectional SEO, Automated Internal Link Silos, /llms.txt AI Corpus, Google Indexing API (RS256), Multi-CDN Purge, and Dynamic OpenGraph Cards.', 'directrelay-pro' ); ?>
						</p>
					</div>
					<div style="display:flex;gap:8px;">
						<a href="<?php echo esc_url( home_url( '/llms.txt' ) ); ?>" target="_blank" rel="noopener" class="button button-secondary">📄 <?php esc_html_e( 'View /llms.txt', 'directrelay-pro' ); ?></a>
						<a href="<?php echo esc_url( home_url( '/llms-full.txt' ) ); ?>" target="_blank" rel="noopener" class="button button-secondary">📚 <?php esc_html_e( 'View /llms-full.txt', 'directrelay-pro' ); ?></a>
					</div>
				</div>

				<div id="dr-pro-hub-notice" style="display:none;margin-bottom:16px;padding:12px 16px;border-radius:8px;font-weight:600;"></div>

				<!-- 4-Plugin SEO Status Band -->
				<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin-bottom:24px;">
					<?php
					$provider_labels = [
						'rankmath' => 'Rank Math SEO',
						'yoast'    => 'Yoast SEO',
						'aioseo'   => 'All in One SEO (AIOSEO)',
						'seopress' => 'SEOPress',
					];
					foreach ( $provider_labels as $pslug => $plabel ) :
						$is_on = ! empty( $seo_providers['active'][ $pslug ] );
						$ver   = $seo_providers['versions'][ $pslug ] ?? null;
						?>
						<div class="directrelay-card" style="padding:16px;border-left:4px solid <?php echo $is_on ? '#10b981' : '#6b7280'; ?>;">
							<div style="font-size:12px;color:var(--directrelay-muted,#6b7280);font-weight:600;text-transform:uppercase;"><?php echo esc_html( $plabel ); ?></div>
							<div style="font-size:16px;font-weight:700;margin-top:6px;color:<?php echo $is_on ? '#10b981' : 'var(--directrelay-text,#374151)'; ?>;">
								<?php echo $is_on ? '✓ Active' . ( $ver ? ' (v' . esc_html( $ver ) . ')' : '' ) : 'Standby (Meta Ready)'; ?>
							</div>
							<div style="font-size:11px;color:var(--directrelay-muted,#6b7280);margin-top:4px;">
								<?php esc_html_e( 'Bidirectional Read/Write + 5 JSON-LD Schemas', 'directrelay-pro' ); ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>

				<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:start;">
					<!-- Left Column: Internal Linking Silo Rules -->
					<div class="directrelay-card" style="padding:20px;">
						<h2 style="margin-top:0;font-size:17px;">🔗 <?php esc_html_e( 'Automated Internal Linking & Semantic Silo Rules', 'directrelay-pro' ); ?></h2>
						<p style="font-size:13px;color:var(--directrelay-muted,#6b7280);">
							<?php esc_html_e( 'Define keyword-to-URL rules. When n8n publishes or updates a post with "auto_internal_link": true (or via POST /seo/internal-links/apply/{id}), DirectRelay Pro automatically links matching phrases inside paragraph text.', 'directrelay-pro' ); ?>
						</p>
						<form id="dr-pro-link-rule-form" style="display:grid;grid-template-columns:1fr 1fr auto;gap:8px;margin-bottom:16px;">
							<input type="text" id="dr-link-kw" placeholder="<?php esc_attr_e( 'Anchor Keyword (e.g. n8n automation)', 'directrelay-pro' ); ?>" required class="regular-text" style="width:100%;">
							<input type="url" id="dr-link-url" placeholder="<?php esc_attr_e( 'Target URL (https://...)', 'directrelay-pro' ); ?>" required class="regular-text" style="width:100%;">
							<button type="submit" class="button button-primary"><?php esc_html_e( '+ Add Rule', 'directrelay-pro' ); ?></button>
						</form>

						<table class="widefat striped" style="font-size:13px;">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Keyword', 'directrelay-pro' ); ?></th>
									<th><?php esc_html_e( 'Target URL', 'directrelay-pro' ); ?></th>
									<th><?php esc_html_e( 'Max/Post', 'directrelay-pro' ); ?></th>
									<th><?php esc_html_e( 'Action', 'directrelay-pro' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php if ( empty( $rules ) ) : ?>
									<tr><td colspan="4"><?php esc_html_e( 'No internal link rules yet. Add your first semantic silo rule above.', 'directrelay-pro' ); ?></td></tr>
								<?php else : ?>
									<?php foreach ( $rules as $r ) : ?>
										<tr>
											<td><strong><?php echo esc_html( $r['keyword'] ?? '' ); ?></strong></td>
											<td><a href="<?php echo esc_url( $r['target_url'] ?? '' ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $r['target_url'] ?? '' ); ?></a></td>
											<td><?php echo (int) ( $r['max_per_post'] ?? 1 ); ?></td>
											<td><button type="button" class="button button-small dr-del-link-rule" data-id="<?php echo esc_attr( $r['id'] ?? '' ); ?>" style="color:#dc2626;"><?php esc_html_e( 'Delete', 'directrelay-pro' ); ?></button></td>
										</tr>
									<?php endforeach; ?>
								<?php endif; ?>
							</tbody>
						</table>

						<hr style="margin:24px 0;border:none;border-top:1px solid var(--directrelay-border,#e5e7eb);">
						<h2 style="margin-top:0;font-size:17px;">🎨 <?php esc_html_e( 'Dynamic 1200×630 OpenGraph Social Card Generator', 'directrelay-pro' ); ?></h2>
						<p style="font-size:13px;color:var(--directrelay-muted,#6b7280);">
							<?php esc_html_e( 'Generate a branded 1200×630 social preview card directly into your WordPress Media Library (also available via POST /wp-json/directrelay/v1/media/og-card).', 'directrelay-pro' ); ?>
						</p>
						<form id="dr-pro-og-form" style="display:grid;grid-template-columns:1fr auto;gap:8px;">
							<input type="text" id="dr-og-title" placeholder="<?php esc_attr_e( 'Enter Headline for 1200x630 OpenGraph Card…', 'directrelay-pro' ); ?>" required class="regular-text" style="width:100%;">
							<button type="submit" class="button button-secondary"><?php esc_html_e( 'Generate OG Card', 'directrelay-pro' ); ?></button>
						</form>
						<div id="dr-og-preview" style="margin-top:12px;"></div>
					</div>

					<!-- Right Column: Google Indexing API & Multi-CDN Edge Purge -->
					<div class="directrelay-card" style="padding:20px;">
						<h2 style="margin-top:0;font-size:17px;">⚡ <?php esc_html_e( 'Google Indexing API (RS256) & Edge CDN Auto-Purge', 'directrelay-pro' ); ?></h2>
						<p style="font-size:13px;color:var(--directrelay-muted,#6b7280);">
							<?php esc_html_e( 'Configure your Google Cloud Service Account JSON (encrypted at rest with AES-256-CBC) and Edge CDN credentials. Automatically submits published URLs and purges edge caches.', 'directrelay-pro' ); ?>
						</p>
						<form id="dr-pro-indexing-cdn-form">
							<table class="form-table" role="presentation" style="margin-top:0;">
								<tr>
									<th scope="row"><label for="dr-sa-json"><?php esc_html_e( 'Google Service Account JSON', 'directrelay-pro' ); ?></label></th>
									<td>
										<textarea id="dr-sa-json" rows="4" class="large-text code" placeholder='{"type":"service_account","project_id":"...","private_key":"-----BEGIN PRIVATE KEY-----...","client_email":"...@....iam.gserviceaccount.com"}'></textarea>
										<p class="description">
											<?php
											if ( ! empty( $sa['client_email'] ) ) {
												echo '✅ ' . esc_html( sprintf( __( 'Configured Service Account: %s (AES-256 Encrypted)', 'directrelay-pro' ), $sa['client_email'] ) );
											} else {
												esc_html_e( 'Paste your Google Cloud Service Account JSON key with Indexing API Owner permission in Search Console.', 'directrelay-pro' );
											}
											?>
										</p>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php esc_html_e( 'Auto-Index on Publish', 'directrelay-pro' ); ?></th>
									<td>
										<label>
											<input type="checkbox" id="dr-auto-google-index" value="1" <?php checked( ! empty( $settings['enable_google_indexing'] ) ); ?>>
											<?php esc_html_e( 'Automatically submit URL_UPDATED to Google Indexing API & IndexNow when a post is published', 'directrelay-pro' ); ?>
										</label>
									</td>
								</tr>
								<tr>
									<th scope="row"><label for="dr-cf-zone"><?php esc_html_e( 'Cloudflare Zone ID & Token', 'directrelay-pro' ); ?></label></th>
									<td>
										<input type="text" id="dr-cf-zone" placeholder="<?php esc_attr_e( 'Cloudflare Zone ID', 'directrelay-pro' ); ?>" value="<?php echo esc_attr( $settings['cf_zone_id'] ?? '' ); ?>" class="regular-text" style="width:100%;margin-bottom:6px;">
										<input type="password" id="dr-cf-token" placeholder="<?php echo ! empty( $settings['cf_api_token'] ) ? '•••••••••••••••• (Configured)' : esc_attr__( 'Cloudflare API Token (Cache Purge)', 'directrelay-pro' ); ?>" class="regular-text" style="width:100%;">
									</td>
								</tr>
								<tr>
									<th scope="row"><label for="dr-bunny-key"><?php esc_html_e( 'BunnyCDN / Fastly API Keys', 'directrelay-pro' ); ?></label></th>
									<td>
										<input type="password" id="dr-bunny-key" placeholder="<?php echo ! empty( $settings['bunny_api_key'] ) ? 'BunnyCDN: •••••••••••• (Configured)' : esc_attr__( 'BunnyCDN API Key (Optional)', 'directrelay-pro' ); ?>" class="regular-text" style="width:100%;margin-bottom:6px;">
										<input type="password" id="dr-fastly-key" placeholder="<?php echo ! empty( $settings['fastly_api_key'] ) ? 'Fastly: •••••••••••• (Configured)' : esc_attr__( 'Fastly API Token (Optional)', 'directrelay-pro' ); ?>" class="regular-text" style="width:100%;">
									</td>
								</tr>
								<tr>
									<th scope="row"><?php esc_html_e( 'Auto-Purge Edge CDN', 'directrelay-pro' ); ?></th>
									<td>
										<label>
											<input type="checkbox" id="dr-auto-cdn-purge" value="1" <?php checked( ! isset( $settings['enable_cdn_auto_purge'] ) || ! empty( $settings['enable_cdn_auto_purge'] ) ); ?>>
											<?php esc_html_e( 'Automatically purge Cloudflare, BunnyCDN, Fastly & LiteSpeed cache on post update', 'directrelay-pro' ); ?>
										</label>
									</td>
								</tr>
							</table>
							<button type="submit" class="button button-primary"><?php esc_html_e( 'Save Indexing & CDN Configuration', 'directrelay-pro' ); ?></button>
						</form>

						<hr style="margin:20px 0;border:none;border-top:1px solid var(--directrelay-border,#e5e7eb);">
						<h3 style="margin-top:0;font-size:15px;">🔍 <?php esc_html_e( '1-Click Instant URL Index & CDN Cache Purge Tester', 'directrelay-pro' ); ?></h3>
						<form id="dr-pro-test-index-form" style="display:grid;grid-template-columns:1fr auto;gap:8px;">
							<input type="url" id="dr-test-index-url" value="<?php echo esc_url( home_url( '/' ) ); ?>" required class="regular-text" style="width:100%;">
							<button type="submit" class="button button-secondary"><?php esc_html_e( 'Submit URL & Purge CDN Now', 'directrelay-pro' ); ?></button>
						</form>
					</div>
				</div>
			</div>

			<script>
			jQuery(function($){
				var nonce = <?php echo wp_json_encode( $nonce ); ?>;
				function notify(msg, isErr) {
					$('#dr-pro-hub-notice').stop(true,true).css({
						display:'block',
						background: isErr ? 'rgba(239,68,68,0.12)' : 'rgba(16,185,129,0.12)',
						borderLeft: '4px solid ' + (isErr ? '#ef4444' : '#10b981'),
						color: isErr ? '#ef4444' : '#10b981'
					}).text(msg);
				}

				$('#dr-pro-link-rule-form').on('submit', function(e){
					e.preventDefault();
					$.post(ajaxurl, {
						action: 'directrelay_pro_save_link_rule',
						nonce: nonce,
						keyword: $('#dr-link-kw').val(),
						target_url: $('#dr-link-url').val()
					}).done(function(res){
						if (res.success) { notify('Internal link rule saved!', false); setTimeout(function(){ location.reload(); }, 600); }
						else { notify(res.data && res.data.message ? res.data.message : 'Error', true); }
					});
				});

				$('.dr-del-link-rule').on('click', function(){
					var id = $(this).data('id');
					$.post(ajaxurl, { action: 'directrelay_pro_delete_link_rule', nonce: nonce, id: id }).done(function(){
						location.reload();
					});
				});

				$('#dr-pro-indexing-cdn-form').on('submit', function(e){
					e.preventDefault();
					$.post(ajaxurl, {
						action: 'directrelay_pro_save_indexing_cdn',
						nonce: nonce,
						sa_json: $('#dr-sa-json').val(),
						enable_google_indexing: $('#dr-auto-google-index').is(':checked') ? 1 : 0,
						cf_zone_id: $('#dr-cf-zone').val(),
						cf_api_token: $('#dr-cf-token').val(),
						bunny_api_key: $('#dr-bunny-key').val(),
						fastly_api_key: $('#dr-fastly-key').val(),
						enable_cdn_auto_purge: $('#dr-auto-cdn-purge').is(':checked') ? 1 : 0
					}).done(function(res){
						if (res.success) { notify(res.data.message, false); setTimeout(function(){ location.reload(); }, 800); }
						else { notify(res.data && res.data.message ? res.data.message : 'Failed to save.', true); }
					});
				});

				$('#dr-pro-test-index-form').on('submit', function(e){
					e.preventDefault();
					var $btn = $(this).find('button').prop('disabled', true).text('Running…');
					$.post(ajaxurl, {
						action: 'directrelay_pro_test_index_purge',
						nonce: nonce,
						url: $('#dr-test-index-url').val()
					}).done(function(res){
						if (res.success) { notify(res.data.message, false); }
						else { notify(res.data && res.data.message ? res.data.message : 'Failed.', true); }
					}).always(function(){ $btn.prop('disabled', false).text('Submit URL & Purge CDN Now'); });
				});

				$('#dr-pro-og-form').on('submit', function(e){
					e.preventDefault();
					var $btn = $(this).find('button').prop('disabled', true).text('Generating…');
					$.post(ajaxurl, {
						action: 'directrelay_pro_generate_og_card',
						nonce: nonce,
						title: $('#dr-og-title').val()
					}).done(function(res){
						if (res.success && res.data.url) {
							notify('Generated 1200x630 OpenGraph Card (Attachment #' + res.data.attachment_id + ')!', false);
							$('#dr-og-preview').html('<a href="' + res.data.url + '" target="_blank"><img src="' + res.data.url + '" style="max-width:100%;border-radius:8px;border:1px solid #374151;"></a>');
						} else {
							notify(res.data && res.data.message ? res.data.message : 'Generation failed.', true);
						}
					}).always(function(){ $btn.prop('disabled', false).text('Generate OG Card'); });
				});
			});
			</script>
			<?php
		}

		/**
		 * Render Tier 3 Admin Hub: Universal CPT & ACF Pro Inspector, WooCommerce Bridge,
		 * Multilingual Sync & Content Decay Detector + 1-Click Pre-AI Snapshot Rollback.
		 */
		public static function render_cpt_decay_page(): void {
			$public_cpts = get_post_types( [ 'public' => true ], 'objects' );
			$public_tax  = get_taxonomies( [ 'public' => true ], 'objects' );
			$wc_active   = class_exists( 'WooCommerce' );
			$ml_info     = Multilingual_Bridge::detect_plugin();
			$decay_data  = Content_Decay_Versioning::find_stale_posts( [ 'older_than_days' => 90, 'limit' => 25 ] );
			$nonce       = wp_create_nonce( 'directrelay_pro_admin_hub' );
			?>
			<div class="directrelay-wrap" style="max-width:1200px;margin:20px auto;padding:0 16px;">
				<div class="directrelay-header" style="margin-bottom:20px;">
					<h1 style="margin:0;font-size:24px;">🧬 <?php esc_html_e( 'CPT, ACF Pro, WooCommerce, Multilingual & Content Decay Hub', 'directrelay-pro' ); ?></h1>
					<p style="margin:4px 0 0;color:var(--directrelay-muted,#6b7280);font-size:13px;">
						<?php esc_html_e( 'Tier 3 Enterprise Content Operations: Universal Custom Post Type CRUD, ACF Pro Repeaters/Flexible Content, WooCommerce Product/Order Sync, Multilingual hreflang Clusters, and Pre-AI Snapshot Rollback.', 'directrelay-pro' ); ?>
					</p>
				</div>

				<div id="dr-pro-decay-notice" style="display:none;margin-bottom:16px;padding:12px 16px;border-radius:8px;font-weight:600;"></div>

				<!-- Tier 3 Status Cards -->
				<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:14px;margin-bottom:24px;">
					<div class="directrelay-card" style="padding:16px;border-left:4px solid #3b82f6;">
						<div style="font-size:12px;color:var(--directrelay-muted,#6b7280);font-weight:600;text-transform:uppercase;"><?php esc_html_e( 'Public Custom Post Types', 'directrelay-pro' ); ?></div>
						<div style="font-size:18px;font-weight:700;margin-top:6px;"><?php echo count( $public_cpts ); ?> <?php esc_html_e( 'Types Active', 'directrelay-pro' ); ?></div>
						<div style="font-size:12px;color:var(--directrelay-muted,#6b7280);margin-top:4px;font-family:monospace;">
							<?php echo esc_html( implode( ', ', array_keys( $public_cpts ) ) ); ?>
						</div>
					</div>

					<div class="directrelay-card" style="padding:16px;border-left:4px solid #8b5cf6;">
						<div style="font-size:12px;color:var(--directrelay-muted,#6b7280);font-weight:600;text-transform:uppercase;"><?php esc_html_e( 'Custom Fields & Taxonomies', 'directrelay-pro' ); ?></div>
						<div style="font-size:18px;font-weight:700;margin-top:6px;"><?php echo count( $public_tax ); ?> <?php esc_html_e( 'Taxonomies', 'directrelay-pro' ); ?></div>
						<div style="font-size:12px;color:var(--directrelay-muted,#6b7280);margin-top:4px;">
							<?php
							$cf_engines = [];
							if ( function_exists( 'update_field' ) ) $cf_engines[] = 'ACF Pro';
							if ( function_exists( 'rwmb_set_meta' ) ) $cf_engines[] = 'Meta Box';
							if ( function_exists( 'jet_engine' ) ) $cf_engines[] = 'JetEngine';
							if ( function_exists( 'pods' ) ) $cf_engines[] = 'Pods';
							echo esc_html( ! empty( $cf_engines ) ? implode( ', ', $cf_engines ) : 'Native PostMeta + ACF Ready' );
							?>
						</div>
					</div>

					<div class="directrelay-card" style="padding:16px;border-left:4px solid <?php echo $wc_active ? '#10b981' : '#f59e0b'; ?>;">
						<div style="font-size:12px;color:var(--directrelay-muted,#6b7280);font-weight:600;text-transform:uppercase;"><?php esc_html_e( 'WooCommerce Bridge', 'directrelay-pro' ); ?></div>
						<div style="font-size:18px;font-weight:700;margin-top:6px;"><?php echo $wc_active ? '✓ WooCommerce Active' : 'Standby (/wc/* Ready)'; ?></div>
						<div style="font-size:12px;color:var(--directrelay-muted,#6b7280);margin-top:4px;">
							<?php esc_html_e( '/wc/products, /wc/orders & SKU Stock Sync', 'directrelay-pro' ); ?>
						</div>
					</div>

					<div class="directrelay-card" style="padding:16px;border-left:4px solid #14b8a6;">
						<div style="font-size:12px;color:var(--directrelay-muted,#6b7280);font-weight:600;text-transform:uppercase;"><?php esc_html_e( 'Multilingual & hreflang', 'directrelay-pro' ); ?></div>
						<div style="font-size:18px;font-weight:700;margin-top:6px;"><?php echo esc_html( strtoupper( $ml_info['provider'] ?? 'native_hreflang' ) ); ?></div>
						<div style="font-size:12px;color:var(--directrelay-muted,#6b7280);margin-top:4px;">
							<?php esc_html_e( 'GET|POST /posts/{id}/translations', 'directrelay-pro' ); ?>
						</div>
					</div>
				</div>

				<!-- Content Decay Detector & Pre-AI Snapshot Rollback Table -->
				<div class="directrelay-card" style="padding:20px;">
					<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:14px;">
						<div>
							<h2 style="margin:0;font-size:17px;">📉 <?php esc_html_e( 'Content Decay Detector & Pre-AI Snapshot Rollback Queue', 'directrelay-pro' ); ?></h2>
							<p style="margin:4px 0 0;font-size:13px;color:var(--directrelay-muted,#6b7280);">
								<?php esc_html_e( 'Identifies decaying posts (90+ days old or thin word count / missing focus keyword) and allows 1-click rollback to any Pre-AI Snapshot captured before REST updates.', 'directrelay-pro' ); ?>
							</p>
						</div>
						<span class="directrelay-badge-pill"><?php echo (int) ( $decay_data['total_found'] ?? 0 ); ?> <?php esc_html_e( 'Candidates', 'directrelay-pro' ); ?></span>
					</div>

					<table class="widefat striped" style="font-size:13px;">
						<thead>
							<tr>
								<th><?php esc_html_e( 'ID / Post Title', 'directrelay-pro' ); ?></th>
								<th><?php esc_html_e( 'Age (Days)', 'directrelay-pro' ); ?></th>
								<th><?php esc_html_e( 'Words', 'directrelay-pro' ); ?></th>
								<th><?php esc_html_e( 'Focus Keyword', 'directrelay-pro' ); ?></th>
								<th><?php esc_html_e( 'Decay Score', 'directrelay-pro' ); ?></th>
								<th><?php esc_html_e( 'Pre-AI Snapshots & Rollback', 'directrelay-pro' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php if ( empty( $decay_data['posts'] ) ) : ?>
								<tr><td colspan="6"><?php esc_html_e( 'No decaying posts older than 90 days detected — your content library is fresh! You can also query GET /wp-json/directrelay/v1/posts/stale?older_than_days=30.', 'directrelay-pro' ); ?></td></tr>
							<?php else : ?>
								<?php foreach ( $decay_data['posts'] as $dp ) :
									$snaps = Content_Decay_Versioning::get_snapshots( (int) $dp['id'] );
									?>
									<tr>
										<td>
											<strong>#<?php echo (int) $dp['id']; ?></strong> —
											<a href="<?php echo esc_url( $dp['permalink'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $dp['title'] ); ?></a>
										</td>
										<td><?php echo (int) $dp['age_days']; ?>d</td>
										<td><?php echo (int) $dp['word_count']; ?></td>
										<td><?php echo ! empty( $dp['focus_keyword'] ) ? '<code>' . esc_html( $dp['focus_keyword'] ) . '</code>' : '<span style="color:#ef4444;">Missing</span>'; ?></td>
										<td>
											<span style="padding:2px 8px;border-radius:99px;font-weight:700;font-size:11px;background:<?php echo $dp['decay_score'] >= 60 ? 'rgba(239,68,68,0.15)' : 'rgba(245,158,11,0.15)'; ?>;color:<?php echo $dp['decay_score'] >= 60 ? '#ef4444' : '#f59e0b'; ?>;">
												<?php echo (int) $dp['decay_score']; ?>/100 (<?php echo esc_html( strtoupper( $dp['priority'] ) ); ?>)
											</span>
										</td>
										<td>
											<?php if ( ! empty( $snaps ) ) : ?>
												<button type="button" class="button button-small dr-pro-rollback-btn" data-id="<?php echo (int) $dp['id']; ?>">
													⏪ <?php echo esc_html( sprintf( __( 'Rollback (%d snaps)', 'directrelay-pro' ), count( $snaps ) ) ); ?>
												</button>
											<?php else : ?>
												<span style="color:var(--directrelay-muted,#6b7280);font-size:12px;"><?php esc_html_e( 'Auto-captures on next AI edit', 'directrelay-pro' ); ?></span>
											<?php endif; ?>
										</td>
									</tr>
								<?php endforeach; ?>
							<?php endif; ?>
						</tbody>
					</table>
				</div>
			</div>

			<script>
			jQuery(function($){
				var nonce = <?php echo wp_json_encode( $nonce ); ?>;
				$('.dr-pro-rollback-btn').on('click', function(){
					var postId = $(this).data('id');
					if (!confirm('Roll back Post #' + postId + ' to its most recent Pre-AI Snapshot?')) return;
					var $btn = $(this).prop('disabled', true).text('Rolling back…');
					$.post(ajaxurl, {
						action: 'directrelay_pro_rollback_snapshot',
						nonce: nonce,
						post_id: postId
					}).done(function(res){
						if (res.success) {
							$('#dr-pro-decay-notice').css({display:'block',background:'rgba(16,185,129,0.12)',borderLeft:'4px solid #10b981',color:'#10b981'}).text(res.data.message);
							setTimeout(function(){ location.reload(); }, 900);
						} else {
							alert(res.data && res.data.message ? res.data.message : 'Rollback failed.');
							$btn.prop('disabled', false);
						}
					});
				});
			});
			</script>
			<?php
		}

		/* ── AJAX Handlers for SEO/GEO/CDN & Content Decay Admin Hubs ────────── */

		public static function ajax_save_link_rule(): void {
			check_ajax_referer( 'directrelay_pro_admin_hub', 'nonce' );
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( [ 'message' => 'Permission denied.' ], 403 );
			}
			$res = Internal_Linking_Engine::save_rule( [
				'keyword'    => sanitize_text_field( wp_unslash( $_POST['keyword'] ?? '' ) ),
				'target_url' => esc_url_raw( wp_unslash( $_POST['target_url'] ?? '' ) ),
			] );
			if ( is_wp_error( $res ) ) {
				wp_send_json_error( [ 'message' => $res->get_error_message() ], 400 );
			}
			wp_send_json_success( [ 'rule' => $res ] );
		}

		public static function ajax_delete_link_rule(): void {
			check_ajax_referer( 'directrelay_pro_admin_hub', 'nonce' );
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( [ 'message' => 'Permission denied.' ], 403 );
			}
			$id = sanitize_text_field( wp_unslash( $_POST['id'] ?? '' ) );
			Internal_Linking_Engine::delete_rule( $id );
			wp_send_json_success( [ 'deleted' => true ] );
		}

		public static function ajax_save_indexing_cdn(): void {
			check_ajax_referer( 'directrelay_pro_admin_hub', 'nonce' );
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( [ 'message' => 'Permission denied.' ], 403 );
			}
			$sa_raw = trim( wp_unslash( $_POST['sa_json'] ?? '' ) );
			if ( '' !== $sa_raw ) {
				$sa_res = Instant_Indexer_CDN::save_service_account( $sa_raw );
				if ( is_wp_error( $sa_res ) ) {
					wp_send_json_error( [ 'message' => $sa_res->get_error_message() ], 400 );
				}
			}

			$settings = get_option( 'directrelay_settings', [] );
			if ( ! is_array( $settings ) ) {
				$settings = [];
			}
			$settings['enable_google_indexing'] = ! empty( $_POST['enable_google_indexing'] );
			$settings['enable_cdn_auto_purge']  = ! empty( $_POST['enable_cdn_auto_purge'] );
			$settings['cf_zone_id']             = sanitize_text_field( wp_unslash( $_POST['cf_zone_id'] ?? '' ) );

			$cf_tok = trim( sanitize_text_field( wp_unslash( $_POST['cf_api_token'] ?? '' ) ) );
			if ( '' !== $cf_tok && ! str_contains( $cf_tok, '••••' ) ) {
				$settings['cf_api_token'] = class_exists( '\DirectRelay\Webhook_Manager' ) ? \DirectRelay\Webhook_Manager::encrypt_secret( $cf_tok ) : $cf_tok;
			}
			$bunny = trim( sanitize_text_field( wp_unslash( $_POST['bunny_api_key'] ?? '' ) ) );
			if ( '' !== $bunny && ! str_contains( $bunny, '••••' ) ) {
				$settings['bunny_api_key'] = class_exists( '\DirectRelay\Webhook_Manager' ) ? \DirectRelay\Webhook_Manager::encrypt_secret( $bunny ) : $bunny;
			}
			$fastly = trim( sanitize_text_field( wp_unslash( $_POST['fastly_api_key'] ?? '' ) ) );
			if ( '' !== $fastly && ! str_contains( $fastly, '••••' ) ) {
				$settings['fastly_api_key'] = class_exists( '\DirectRelay\Webhook_Manager' ) ? \DirectRelay\Webhook_Manager::encrypt_secret( $fastly ) : $fastly;
			}

			update_option( 'directrelay_settings', $settings );
			wp_send_json_success( [ 'message' => __( 'Google Indexing API & Edge CDN settings saved!', 'directrelay-pro' ) ] );
		}

		public static function ajax_test_index_purge(): void {
			check_ajax_referer( 'directrelay_pro_admin_hub', 'nonce' );
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( [ 'message' => 'Permission denied.' ], 403 );
			}
			$url = esc_url_raw( wp_unslash( $_POST['url'] ?? home_url( '/' ) ) );
			$idx = Instant_Indexer_CDN::submit_url( $url, 'URL_UPDATED' );
			$cdn = Instant_Indexer_CDN::purge_cdn( [ $url ], 0 );
			wp_send_json_success( [
				'message' => sprintf(
					'Dispatched Instant Index & CDN Purge for %s (Local Cache Flushed: %s)',
					$url,
					! empty( $cdn['local_cache_flushed'] ) ? 'Yes' : 'No'
				),
				'indexing' => $idx,
				'cdn'      => $cdn,
			] );
		}

		public static function ajax_generate_og_card(): void {
			check_ajax_referer( 'directrelay_pro_admin_hub', 'nonce' );
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( [ 'message' => 'Permission denied.' ], 403 );
			}
			$title = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) );
			$res   = Smart_Media_Pipeline::generate_og_card( [
				'title'    => $title,
				'subtitle' => get_bloginfo( 'name' ),
				'badge'    => 'DIRECTRELAY PRO',
			] );
			if ( is_wp_error( $res ) ) {
				wp_send_json_error( [ 'message' => $res->get_error_message() ], 400 );
			}
			wp_send_json_success( $res );
		}

		public static function ajax_rollback_snapshot(): void {
			check_ajax_referer( 'directrelay_pro_admin_hub', 'nonce' );
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( [ 'message' => 'Permission denied.' ], 403 );
			}
			$post_id = absint( wp_unslash( $_POST['post_id'] ?? 0 ) );
			$res     = Content_Decay_Versioning::rollback_to_snapshot( $post_id );
			if ( is_wp_error( $res ) ) {
				wp_send_json_error( [ 'message' => $res->get_error_message() ], 400 );
			}
			wp_send_json_success( [
				'message'  => sprintf( __( 'Post #%d rolled back to snapshot %s!', 'directrelay-pro' ), $post_id, $res['restored_snapshot'] ?? '' ),
				'rollback' => $res,
			] );
		}

		public static function ajax_redrive_dlq(): void {
			check_ajax_referer( 'directrelay_pro_admin_hub', 'nonce' );
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( [ 'message' => 'Permission denied.' ], 403 );
			}
			$log_id = absint( wp_unslash( $_POST['log_id'] ?? 0 ) );
			$res    = Webhook_V2_Engine::redrive_dlq_entry( $log_id );
			if ( is_wp_error( $res ) ) {
				wp_send_json_error( [ 'message' => $res->get_error_message() ], 400 );
			}
			wp_send_json_success( $res );
		}

		/**
		 * Contribute Pro n8n workflow templates via `directrelay_ext_templates`.
		 */
		public static function register_pro_templates( array $templates ): array {
			$templates[] = [
				'id'       => 'pro-ai-seo-schema-writer',
				'title'    => 'AI SEO Writer + FAQ & Article JSON-LD Schema',
				'icon'     => '🚀',
				'body'     => 'Generates a full article with DeepSeek/OpenAI, sideloads a featured image, and writes Rank Math/Yoast/AIOSEO metadata + FAQPage JSON-LD schema in one atomic call.',
				'preview'  => [ 'Schedule', 'LLM Writer', 'POST /publish/one-shot' ],
				'pro'      => true,
				'workflow' => wp_json_encode( [
					'name'  => 'DirectRelay Pro - One-Shot SEO & FAQ Schema Publisher',
					'nodes' => [
						[
							'name'       => 'One-Shot Publish',
							'type'       => 'n8n-nodes-base.httpRequest',
							'parameters' => [
								'method'   => 'POST',
								'url'      => '={{$env.WP_URL}}/wp-json/directrelay/v1/publish/one-shot',
								'jsonBody' => '={"title": "{{$json.title}}", "content": "{{$json.content}}", "status": "publish", "featured_image_url": "{{$json.image_url}}", "seo": {"focus_keyword": "{{$json.focus_keyword}}", "secondary_keywords": ["n8n automation", "wordpress api"], "title": "{{$json.seo_title}}", "description": "{{$json.seo_description}}", "pillar_content": true, "faq_schema": [{"question": "How does DirectRelay Pro work?", "answer": "It bridges n8n and WordPress with atomic transactions and full SEO schema writes."}]}}',
							],
						],
					],
				], JSON_PRETTY_PRINT ),
			];

			$templates[] = [
				'id'       => 'pro-universal-schema-ingestor',
				'title'    => 'Universal Schema Scraper-to-WordPress Pipeline',
				'icon'     => '🧬',
				'body'     => 'Sends raw scraper or webhook JSON of any shape directly to POST /publish/universal — DirectRelay Pro maps headline, body, images, and SEO fields automatically.',
				'preview'  => [ 'Webhook', 'Scraper JSON', 'POST /publish/universal' ],
				'pro'      => true,
				'workflow' => wp_json_encode( [
					'name'  => 'DirectRelay Pro - Universal Schema Publisher',
					'nodes' => [
						[
							'name'       => 'Universal Publish',
							'type'       => 'n8n-nodes-base.httpRequest',
							'parameters' => [
								'method'   => 'POST',
								'url'      => '={{$env.WP_URL}}/wp-json/directrelay/v1/publish/universal',
								'jsonBody' => '={"headline": "{{$json.headline}}", "body_markdown": "{{$json.markdown}}", "hero_image": "{{$json.image}}", "target_keyword": "{{$json.keyword}}", "require_approval": true}',
							],
						],
					],
				], JSON_PRETTY_PRINT ),
			];

			return $templates;
		}
	}
	}
}

namespace DirectRelay\Pro {

	defined( 'ABSPATH' ) || exit;

	use DirectRelay\Activity_Logger;
	use DirectRelay\Content_Processor;
	use DirectRelay\Post_Manager;
	use DirectRelay\Webhook_Manager;

	/**
	 * ============================================================================
	 * TIER 2 — MODULE 1: Automated Internal Linking & Semantic Silo Engine
	 * ============================================================================
	 *
	 * - Discovers contextually relevant internal link targets for n8n AI writers
	 *   (`GET /wp-json/directrelay/v1/seo/internal-links`).
	 * - Manages keyword-to-URL semantic silo rules (`directrelay_pro_link_rules`).
	 * - Automatically injects contextual internal links into paragraph/list text
	 *   nodes on post save/publish without breaking HTML tags, headings, or existing
	 *   anchor tags (`<a>`).
	 */
	if ( ! class_exists( '\DirectRelay\Pro\Internal_Linking_Engine', false ) ) {
	final class Internal_Linking_Engine {

		public const RULES_OPTION = 'directrelay_pro_link_rules';

		public static function init(): void {
			add_filter( 'rest_request_before_callbacks', [ __CLASS__, 'maybe_auto_link_on_rest' ], 18, 3 );
		}

		/**
		 * Discover relevant existing posts/pages for n8n AI internal linking prompts.
		 *
		 * @param array $args { topic?: string, exclude_id?: int, category?: int, limit?: int, pillar_only?: bool }
		 * @return array<int, array<string, mixed>>
		 */
		public static function suggest_links( array $args = [] ): array {
			$topic       = sanitize_text_field( (string) ( $args['topic'] ?? $args['q'] ?? '' ) );
			$exclude_id  = absint( $args['exclude_id'] ?? $args['post_id'] ?? 0 );
			$category_id = absint( $args['category'] ?? 0 );
			$limit       = max( 1, min( 50, absint( $args['limit'] ?? 10 ) ) );
			$pillar_only = ! empty( $args['pillar_only'] );

			$query_args = [
				'post_type'      => [ 'post', 'page' ],
				'post_status'    => 'publish',
				'posts_per_page' => min( 100, $limit * 4 ),
				'orderby'        => 'date',
				'order'          => 'DESC',
				'no_found_rows'  => true,
			];
			if ( $exclude_id > 0 ) {
				$query_args['post__not_in'] = [ $exclude_id ];
			}
			if ( $category_id > 0 ) {
				$query_args['cat'] = $category_id;
			}
			if ( '' !== $topic ) {
				$query_args['s'] = $topic;
			}

			$posts = get_posts( $query_args );

			// Fallback if WP search `s` was too strict: load recent published posts and score in PHP.
			if ( empty( $posts ) && '' !== $topic ) {
				unset( $query_args['s'] );
				$posts = get_posts( $query_args );
			}

			$topic_tokens = array_values( array_filter( preg_split( '/\s+/', strtolower( $topic ) ) ?: [] ) );
			$candidates   = [];

			foreach ( $posts as $p ) {
				if ( ! ( $p instanceof \WP_Post ) ) {
					continue;
				}
				$seo       = SEO_Write_Engine::read( $p->ID );
				$is_pillar = ! empty( $seo['pillar_content_bool'] );
				if ( $pillar_only && ! $is_pillar ) {
					continue;
				}

				$focus_kw  = (string) ( $seo['focus_keyword'] ?? '' );
				$sec_kws   = is_array( $seo['secondary_keywords'] ?? null ) ? $seo['secondary_keywords'] : [];
				$permalink = (string) get_permalink( $p->ID );

				// Relevance scoring: Pillar boost + Focus Keyword match + Title token match.
				$score = $is_pillar ? 35 : 10;
				$hay   = strtolower( $p->post_title . ' ' . $focus_kw . ' ' . implode( ' ', $sec_kws ) );

				foreach ( $topic_tokens as $tok ) {
					if ( strlen( $tok ) >= 3 && str_contains( $hay, $tok ) ) {
						$score += 20;
					}
				}
				if ( '' !== $focus_kw ) {
					$score += 10;
				}

				$anchors = array_values( array_unique( array_filter( array_merge(
					[ $focus_kw, $p->post_title ],
					array_slice( $sec_kws, 0, 3 )
				) ) ) );

				$primary_anchor = $anchors[0] ?? $p->post_title;

				$candidates[] = [
					'id'                 => $p->ID,
					'type'               => $p->post_type,
					'title'              => $p->post_title,
					'url'                => $permalink,
					'focus_keyword'      => $focus_kw,
					'secondary_keywords' => $sec_kws,
					'is_pillar'          => $is_pillar,
					'relevance_score'    => $score,
					'suggested_anchors'  => $anchors,
					'markdown_link'      => sprintf( '[%s](%s)', $primary_anchor, $permalink ),
					'html_link'          => sprintf( '<a href="%s">%s</a>', esc_url( $permalink ), esc_html( $primary_anchor ) ),
				];
			}

			usort( $candidates, static fn( array $a, array $b ): int => $b['relevance_score'] <=> $a['relevance_score'] );
			return array_slice( $candidates, 0, $limit );
		}

		/**
		 * Get all stored keyword-to-URL internal linking rules.
		 */
		public static function get_rules(): array {
			$rules = get_option( self::RULES_OPTION, [] );
			return is_array( $rules ) ? array_values( $rules ) : [];
		}

		/**
		 * Add or update a keyword-to-URL internal link rule.
		 */
		public static function save_rule( array $rule ): array|\WP_Error {
			$keyword    = sanitize_text_field( (string) ( $rule['keyword'] ?? '' ) );
			$target_url = esc_url_raw( trim( (string) ( $rule['target_url'] ?? $rule['url'] ?? '' ) ), [ 'http', 'https' ] );

			if ( '' === $keyword || '' === $target_url ) {
				return new \WP_Error(
					'directrelay_pro_invalid_link_rule',
					__( 'Both "keyword" and a valid "target_url" are required.', 'directrelay-pro' ),
					[ 'status' => 400 ]
				);
			}

			$rules = self::get_rules();
			$id    = ! empty( $rule['id'] ) ? sanitize_key( (string) $rule['id'] ) : 'rule_' . substr( md5( strtolower( $keyword ) ), 0, 10 );

			$entry = [
				'id'                 => $id,
				'keyword'            => $keyword,
				'target_url'         => $target_url,
				'title_attr'         => sanitize_text_field( (string) ( $rule['title_attr'] ?? $keyword ) ),
				'max_replacements'   => max( 1, min( 5, absint( $rule['max_replacements'] ?? 1 ) ) ),
				'case_sensitive'     => ! empty( $rule['case_sensitive'] ),
				'open_in_new_tab'    => ! empty( $rule['open_in_new_tab'] ),
				'nofollow'           => ! empty( $rule['nofollow'] ),
				'is_pillar'          => ! empty( $rule['is_pillar'] ),
				'created_at'         => current_time( 'mysql', true ),
			];

			$replaced = false;
			foreach ( $rules as &$existing ) {
				if ( ( $existing['id'] ?? '' ) === $id || strtolower( $existing['keyword'] ?? '' ) === strtolower( $keyword ) ) {
					$existing = $entry;
					$replaced = true;
					break;
				}
			}
			unset( $existing );

			if ( ! $replaced ) {
				$rules[] = $entry;
			}

			update_option( self::RULES_OPTION, array_values( $rules ), false );
			return $entry;
		}

		/**
		 * Delete an internal linking rule by ID.
		 */
		public static function delete_rule( string $id ): bool {
			$rules    = self::get_rules();
			$filtered = array_values( array_filter( $rules, static fn( array $r ): bool => ( $r['id'] ?? '' ) !== $id ) );
			if ( count( $filtered ) === count( $rules ) ) {
				return false;
			}
			update_option( self::RULES_OPTION, $filtered, false );
			return true;
		}

		/**
		 * HTML-safe Auto-Internal-Linker: injects links into plain text segments outside
		 * of `<a ...>...</a>`, `<h1..h6>`, `<code>`, `<pre>`, `<script>`, and HTML tags.
		 *
		 * @param string $html            Input HTML content.
		 * @param int    $current_post_id Optional post ID to prevent self-linking.
		 * @param int    $max_total_links Maximum internal links to inject across the post.
		 * @return array{content: string, links_added: int, applied_rules: array}
		 */
		public static function apply_rules_to_content( string $html, int $current_post_id = 0, int $max_total_links = 5 ): array {
			$rules = self::get_rules();
			if ( empty( $rules ) || '' === trim( $html ) ) {
				return [ 'content' => $html, 'links_added' => 0, 'applied_rules' => [] ];
			}

			$self_url      = $current_post_id > 0 ? rtrim( (string) get_permalink( $current_post_id ), '/' ) : '';
			$total_added   = 0;
			$applied_rules = [];

			// Split HTML into protected blocks (existing links, headings, code/pre, scripts, tags) and safe text nodes.
			$pattern = '/(<a\b[^>]*>.*?<\/a>|<h[1-6]\b[^>]*>.*?<\/h[1-6]>|<pre\b[^>]*>.*?<\/pre>|<code\b[^>]*>.*?<\/code>|<script\b[^>]*>.*?<\/script>|<[^>]+>)/is';

			foreach ( $rules as $rule ) {
				if ( $total_added >= $max_total_links ) {
					break;
				}
				$kw         = (string) ( $rule['keyword'] ?? '' );
				$target_url = (string) ( $rule['target_url'] ?? '' );
				if ( '' === $kw || '' === $target_url ) {
					continue;
				}
				if ( '' !== $self_url && rtrim( $target_url, '/' ) === $self_url ) {
					continue; // Never link a post to itself.
				}

				// Skip if this exact URL is already linked in the content.
				if ( stripos( $html, $target_url ) !== false ) {
					continue;
				}

				$flags      = ! empty( $rule['case_sensitive'] ) ? 'u' : 'iu';
				$kw_regex   = '/\b(' . preg_quote( $kw, '/' ) . ')\b/' . $flags;
				$rule_max   = min( (int) ( $rule['max_replacements'] ?? 1 ), $max_total_links - $total_added );
				$rule_count = 0;

				$parts = preg_split( $pattern, $html, -1, PREG_SPLIT_DELIM_CAPTURE );
				if ( ! is_array( $parts ) ) {
					continue;
				}

				foreach ( $parts as $idx => &$segment ) {
					// Odd indices in PREG_SPLIT_DELIM_CAPTURE are protected tags/elements.
					if ( $idx % 2 === 1 || $rule_count >= $rule_max ) {
						continue;
					}

					$rels = [];
					if ( ! empty( $rule['open_in_new_tab'] ) ) {
						$rels[] = 'noopener';
					}
					if ( ! empty( $rule['nofollow'] ) ) {
						$rels[] = 'nofollow';
					}
					$target_attr = ! empty( $rule['open_in_new_tab'] ) ? ' target="_blank"' : '';
					$rel_attr    = ! empty( $rels ) ? ' rel="' . esc_attr( implode( ' ', $rels ) ) . '"' : '';
					$title_attr  = ! empty( $rule['title_attr'] ) ? ' title="' . esc_attr( (string) $rule['title_attr'] ) . '"' : '';

					$segment = (string) preg_replace_callback(
						$kw_regex,
						static function ( array $m ) use ( $target_url, $target_attr, $rel_attr, $title_attr, &$rule_count, $rule_max, &$total_added ): string {
							if ( $rule_count >= $rule_max ) {
								return $m[0];
							}
							++$rule_count;
							++$total_added;
							return '<a href="' . esc_url( $target_url ) . '" class="directrelay-internal-link"' . $title_attr . $target_attr . $rel_attr . '>' . $m[1] . '</a>';
						},
						$segment,
						$rule_max - $rule_count
					);
				}
				unset( $segment );

				if ( $rule_count > 0 ) {
					$html            = implode( '', $parts );
					$applied_rules[] = [
						'keyword'    => $kw,
						'target_url' => $target_url,
						'count'      => $rule_count,
					];
				}
			}

			return [
				'content'       => $html,
				'links_added'   => $total_added,
				'applied_rules' => $applied_rules,
			];
		}

		/**
		 * Automatically apply internal link rules on REST post create/update when `"auto_internal_link": true`.
		 */
		public static function maybe_auto_link_on_rest( $response, array $handler, \WP_REST_Request $request ) {
			if ( is_wp_error( $response ) || ! in_array( $request->get_method(), [ 'POST', 'PUT', 'PATCH' ], true ) ) {
				return $response;
			}
			if ( ! preg_match( '#^/directrelay/v1/(?:posts|pages|publish/one-shot|publish/universal)#', $request->get_route() ) ) {
				return $response;
			}

			$json = $request->get_json_params();
			if ( ! is_array( $json ) || empty( $json['auto_internal_link'] ) || empty( $json['content'] ) ) {
				return $response;
			}

			$linked          = self::apply_rules_to_content( (string) $json['content'], (int) ( $request->get_param( 'id' ) ?? 0 ) );
			$json['content'] = $linked['content'];
			$request->set_body( wp_json_encode( $json ) );

			return $response;
		}
	}
	}

	/**
	 * ============================================================================
	 * TIER 2 — MODULE 2: GEO / AEO (Generative Engine Optimization) & `/llms.txt`
	 * ============================================================================
	 *
	 * - Dynamically serves `/llms.txt` (structured Markdown directory) and
	 *   `/llms-full.txt` (complete clean Markdown corpus) for AI search crawlers
	 *   (ChatGPT, Perplexity, Claude, Gemini).
	 * - Builds AI Citation & Key Takeaways Summary Boxes (`<aside class="directrelay-aeo-summary">`)
	 *   and outputs Schema.org `ClaimReview` (Fact-Check) JSON-LD in `wp_head`.
	 */
	if ( ! class_exists( '\DirectRelay\Pro\GEO_AEO_Engine', false ) ) {
	final class GEO_AEO_Engine {

		public static function init(): void {
			add_action( 'init', [ __CLASS__, 'serve_llms_txt_endpoints' ], 5 );
			add_filter( 'rest_request_before_callbacks', [ __CLASS__, 'maybe_inject_citation_block' ], 16, 3 );
			add_action( 'wp_head', [ __CLASS__, 'render_claim_review_json_ld' ], 26 );
		}

		/**
		 * Serve `/llms.txt` and `/llms-full.txt` virtually when requested.
		 */
		public static function serve_llms_txt_endpoints(): void {
			if ( empty( $_SERVER['REQUEST_URI'] ) ) {
				return;
			}
			$path = rtrim( (string) wp_parse_url( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ), '/' );

			if ( substr( $path, -9 ) === '/llms.txt' ) {
				nocache_headers();
				header( 'Content-Type: text/markdown; charset=utf-8' );
				header( 'X-Robots-Tag: index, follow' );
				echo self::generate_llms_txt( false ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Plain text/markdown response.
				exit;
			}

			if ( substr( $path, -14 ) === '/llms-full.txt' ) {
				nocache_headers();
				header( 'Content-Type: text/markdown; charset=utf-8' );
				header( 'X-Robots-Tag: index, follow' );
				echo self::generate_llms_txt( true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Plain text/markdown response.
				exit;
			}
		}

		/**
		 * Generate `/llms.txt` (concise index) or `/llms-full.txt` (full Markdown corpus).
		 */
		public static function generate_llms_txt( bool $full = false, int $limit = 50 ): string {
			$site_name = get_bloginfo( 'name' ) ?: 'WordPress Site';
			$site_desc = get_bloginfo( 'description' ) ?: 'AI-indexed knowledge base and publication.';
			$site_url  = home_url( '/' );

			$lines   = [];
			$lines[] = '# ' . $site_name;
			$lines[] = '';
			$lines[] = '> ' . $site_desc;
			$lines[] = '';
			$lines[] = '- Site URL: ' . $site_url;
			$lines[] = '- Full Corpus: ' . home_url( '/llms-full.txt' );
			$lines[] = '- OpenAPI Schema: ' . rest_url( 'directrelay/v1/openapi.json' );
			$lines[] = '';

			$posts = get_posts( [
				'post_type'      => [ 'post', 'page' ],
				'post_status'    => 'publish',
				'posts_per_page' => max( 1, min( 200, $limit ) ),
				'orderby'        => 'date',
				'order'          => 'DESC',
				'no_found_rows'  => true,
			] );

			$pillars  = [];
			$articles = [];

			foreach ( $posts as $p ) {
				if ( ! ( $p instanceof \WP_Post ) ) {
					continue;
				}
				$seo = SEO_Write_Engine::read( $p->ID );
				if ( ! empty( $seo['pillar_content_bool'] ) ) {
					$pillars[] = [ 'post' => $p, 'seo' => $seo ];
				} else {
					$articles[] = [ 'post' => $p, 'seo' => $seo ];
				}
			}

			if ( ! $full ) {
				if ( ! empty( $pillars ) ) {
					$lines[] = '## Pillar & Cornerstone Guides';
					$lines[] = '';
					foreach ( $pillars as $item ) {
						$p       = $item['post'];
						$seo     = $item['seo'];
						$summary = $seo['description'] ?: wp_trim_words( wp_strip_all_tags( $p->post_excerpt ?: $p->post_content ), 24 );
						$lines[] = sprintf( '- [%s](%s): %s', $p->post_title, get_permalink( $p->ID ), $summary );
					}
					$lines[] = '';
				}

				$lines[] = '## Published Articles & Pages';
				$lines[] = '';
				foreach ( $articles as $item ) {
					$p       = $item['post'];
					$seo     = $item['seo'];
					$summary = $seo['description'] ?: wp_trim_words( wp_strip_all_tags( $p->post_excerpt ?: $p->post_content ), 24 );
					$lines[] = sprintf( '- [%s](%s): %s', $p->post_title, get_permalink( $p->ID ), $summary );
				}
				return implode( "\n", $lines ) . "\n";
			}

			// Full Markdown Corpus (`/llms-full.txt`)
			$all = array_merge( $pillars, $articles );
			foreach ( $all as $item ) {
				$p   = $item['post'];
				$seo = $item['seo'];
				$lines[] = '---';
				$lines[] = 'title: "' . addslashes( $p->post_title ) . '"';
				$lines[] = 'url: ' . get_permalink( $p->ID );
				$lines[] = 'published: ' . get_the_date( 'c', $p );
				$lines[] = 'modified: ' . get_the_modified_date( 'c', $p );
				if ( ! empty( $seo['focus_keyword'] ) ) {
					$lines[] = 'focus_keyword: "' . addslashes( (string) $seo['focus_keyword'] ) . '"';
				}
				if ( ! empty( $seo['description'] ) ) {
					$lines[] = 'summary: "' . addslashes( (string) $seo['description'] ) . '"';
				}
				$lines[] = '---';
				$lines[] = '';
				$lines[] = '## ' . $p->post_title;
				$lines[] = '';
				$lines[] = self::html_to_clean_markdown( $p->post_content );
				$lines[] = '';
			}

			return implode( "\n", $lines ) . "\n";
		}

		/**
		 * Build an AEO / GEO Citation & Key Takeaways HTML block.
		 *
		 * @param array $geo { direct_answer?: string, key_takeaways?: array, sources?: array, fact_check?: array }
		 * @return string Sanitized semantic HTML block.
		 */
		public static function build_citation_block_html( array $geo ): string {
			$direct_answer = sanitize_textarea_field( (string) ( $geo['direct_answer'] ?? $geo['tldr'] ?? '' ) );
			$takeaways     = isset( $geo['key_takeaways'] ) && is_array( $geo['key_takeaways'] ) ? $geo['key_takeaways'] : [];
			$sources       = isset( $geo['sources'] ) && is_array( $geo['sources'] ) ? $geo['sources'] : [];

			if ( '' === $direct_answer && empty( $takeaways ) && empty( $sources ) ) {
				return '';
			}

			$html  = '<aside class="directrelay-aeo-summary" aria-label="Key Takeaways">' . "\n";
			$html .= '<div class="directrelay-aeo-header"><strong>' . esc_html__( 'Key Takeaways & Direct Summary', 'directrelay-pro' ) . '</strong></div>' . "\n";

			if ( '' !== $direct_answer ) {
				$html .= '<p class="directrelay-aeo-direct-answer">' . esc_html( $direct_answer ) . '</p>' . "\n";
			}

			if ( ! empty( $takeaways ) ) {
				$html .= '<ul class="directrelay-aeo-takeaways">' . "\n";
				foreach ( $takeaways as $point ) {
					$clean_pt = sanitize_text_field( (string) $point );
					if ( '' !== $clean_pt ) {
						$html .= '<li>' . esc_html( $clean_pt ) . '</li>' . "\n";
					}
				}
				$html .= '</ul>' . "\n";
			}

			if ( ! empty( $sources ) ) {
				$html .= '<div class="directrelay-aeo-sources"><small><strong>' . esc_html__( 'Verified Sources:', 'directrelay-pro' ) . '</strong> ';
				$links = [];
				foreach ( $sources as $src ) {
					if ( is_array( $src ) && ! empty( $src['url'] ) ) {
						$u = esc_url( (string) $src['url'] );
						$t = sanitize_text_field( (string) ( $src['title'] ?? $u ) );
						if ( '' !== $u ) {
							$links[] = '<a href="' . $u . '" target="_blank" rel="noopener">' . esc_html( $t ) . '</a>';
						}
					}
				}
				$html .= implode( ' • ', $links ) . '</small></div>' . "\n";
			}

			$html .= '</aside>';
			return $html;
		}

		/**
		 * Automatically prepend AEO Citation Block & persist `fact_check` ClaimReview schema
		 * when a `geo` object is supplied in REST post create/update payloads.
		 */
		public static function maybe_inject_citation_block( $response, array $handler, \WP_REST_Request $request ) {
			if ( is_wp_error( $response ) || ! in_array( $request->get_method(), [ 'POST', 'PUT', 'PATCH' ], true ) ) {
				return $response;
			}
			if ( ! preg_match( '#^/directrelay/v1/(?:posts|pages|publish/one-shot|publish/universal)#', $request->get_route() ) ) {
				return $response;
			}

			$json = $request->get_json_params();
			if ( ! is_array( $json ) || empty( $json['geo'] ) || ! is_array( $json['geo'] ) ) {
				return $response;
			}

			$block_html = self::build_citation_block_html( $json['geo'] );
			if ( '' !== $block_html && isset( $json['content'] ) && ! str_contains( (string) $json['content'], 'directrelay-aeo-summary' ) ) {
				$json['content'] = $block_html . "\n\n" . (string) $json['content'];
			}

			if ( ! empty( $json['geo']['fact_check'] ) && is_array( $json['geo']['fact_check'] ) ) {
				$json['meta']                                  = isset( $json['meta'] ) && is_array( $json['meta'] ) ? $json['meta'] : [];
				$json['meta']['_directrelay_geo_claim_review'] = [
					'claim'        => sanitize_text_field( (string) ( $json['geo']['fact_check']['claim'] ?? '' ) ),
					'rating_label' => sanitize_text_field( (string) ( $json['geo']['fact_check']['rating_label'] ?? 'True' ) ),
					'rating_value' => (int) ( $json['geo']['fact_check']['rating_value'] ?? 5 ),
				];
			}

			$request->set_body( wp_json_encode( $json ) );
			return $response;
		}

		/**
		 * Render `ClaimReview` JSON-LD in `wp_head` when fact-check metadata is present.
		 */
		public static function render_claim_review_json_ld(): void {
			if ( ! is_singular() ) {
				return;
			}
			$post = get_queried_object();
			if ( ! ( $post instanceof \WP_Post ) ) {
				return;
			}
			$fc = get_post_meta( $post->ID, '_directrelay_geo_claim_review', true );
			if ( ! is_array( $fc ) || empty( $fc['claim'] ) ) {
				return;
			}

			$ld = [
				'@context'      => 'https://schema.org',
				'@type'         => 'ClaimReview',
				'url'           => get_permalink( $post->ID ),
				'claimReviewed' => $fc['claim'],
				'author'        => [
					'@type' => 'Organization',
					'name'  => get_bloginfo( 'name' ),
				],
				'reviewRating'  => [
					'@type'         => 'Rating',
					'ratingValue'   => (int) ( $fc['rating_value'] ?? 5 ),
					'bestRating'    => 5,
					'worstRating'   => 1,
					'alternateName' => $fc['rating_label'] ?? 'True',
				],
			];

			echo "\n" . '<script type="application/ld+json" class="directrelay-pro-claim-review">' .
				wp_json_encode( $ld, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) .
				"</script>\n";
		}

		private static function html_to_clean_markdown( string $html ): string {
			$md = preg_replace( '/<h1[^>]*>(.*?)<\/h1>/is', "# $1\n\n", $html );
			$md = preg_replace( '/<h2[^>]*>(.*?)<\/h2>/is', "## $1\n\n", (string) $md );
			$md = preg_replace( '/<h3[^>]*>(.*?)<\/h3>/is', "### $1\n\n", (string) $md );
			$md = preg_replace( '/<li[^>]*>(.*?)<\/li>/is', "- $1\n", (string) $md );
			$md = preg_replace( '/<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/is', '[$2]($1)', (string) $md );
			$md = preg_replace( '/<(?:strong|b)[^>]*>(.*?)<\/(?:strong|b)>/is', '**$1**', (string) $md );
			$md = wp_strip_all_tags( (string) $md );
			$md = preg_replace( "/\n{3,}/", "\n\n", (string) $md );
			return trim( (string) $md );
		}
	}
	}

	/**
	 * ============================================================================
	 * TIER 2 — MODULE 3: Google Indexing API + Multi-Engine Indexer & Edge CDN Purge
	 * ============================================================================
	 *
	 * - Native Google Indexing API (`URL_UPDATED` / `URL_DELETED`) using PHP OpenSSL
	 *   RS256 JWT signing with Service Account JSON credentials (encrypted at rest).
	 * - Automatic & On-Demand Edge Cache Purge for Cloudflare, BunnyCDN, Fastly,
	 *   and LiteSpeed Cache.
	 */
	if ( ! class_exists( '\DirectRelay\Pro\Instant_Indexer_CDN', false ) ) {
	final class Instant_Indexer_CDN {

		public const SA_OPTION  = 'directrelay_pro_google_sa_enc';
		public const CDN_OPTION = 'directrelay_pro_cdn_settings';

		public static function init(): void {
			add_action( 'transition_post_status', [ __CLASS__, 'on_post_status_change' ], 20, 3 );
		}

		/**
		 * Save encrypted Google Cloud Service Account JSON credentials.
		 */
		public static function save_service_account( array|string $sa ): bool|\WP_Error {
			if ( is_string( $sa ) ) {
				$sa = json_decode( $sa, true );
			}
			if ( ! is_array( $sa ) || empty( $sa['client_email'] ) || empty( $sa['private_key'] ) ) {
				return new \WP_Error(
					'directrelay_pro_invalid_sa',
					__( 'Invalid Google Service Account JSON: requires "client_email" and "private_key".', 'directrelay-pro' ),
					[ 'status' => 400 ]
				);
			}

			$raw_json = wp_json_encode( $sa );
			$enc      = class_exists( '\DirectRelay\Webhook_Manager' )
				? Webhook_Manager::encrypt_secret( (string) $raw_json )
				: base64_encode( (string) $raw_json ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode

			update_option( self::SA_OPTION, $enc, false );
			delete_transient( 'directrelay_pro_google_idx_token' );
			return true;
		}

		/**
		 * Retrieve decrypted Google Service Account array (or null if unconfigured).
		 */
		public static function get_service_account(): ?array {
			$enc = (string) get_option( self::SA_OPTION, '' );
			if ( '' === $enc ) {
				return null;
			}
			$dec = class_exists( '\DirectRelay\Webhook_Manager' )
				? Webhook_Manager::decrypt_secret( $enc )
				: '';
			if ( '' === $dec ) {
				$dec = (string) base64_decode( $enc, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			}
			$arr = json_decode( $dec, true );
			return ( is_array( $arr ) && ! empty( $arr['client_email'] ) && ! empty( $arr['private_key'] ) ) ? $arr : null;
		}

		/**
		 * Mint an OAuth2 access token from the Google Service Account using OpenSSL RS256.
		 */
		public static function get_google_access_token(): string|\WP_Error {
			$cached = get_transient( 'directrelay_pro_google_idx_token' );
			if ( is_string( $cached ) && '' !== $cached ) {
				return $cached;
			}

			$sa = self::get_service_account();
			if ( ! $sa ) {
				return new \WP_Error(
					'directrelay_pro_no_google_sa',
					__( 'Google Indexing API Service Account is not configured.', 'directrelay-pro' ),
					[ 'status' => 400 ]
				);
			}

			if ( ! function_exists( 'openssl_sign' ) ) {
				return new \WP_Error(
					'directrelay_pro_no_openssl',
					__( 'PHP OpenSSL extension is required for Google OAuth2 RS256 signing.', 'directrelay-pro' ),
					[ 'status' => 500 ]
				);
			}

			$now    = time();
			$header = self::base64url_encode( (string) wp_json_encode( [ 'alg' => 'RS256', 'typ' => 'JWT' ] ) );
			$claims = self::base64url_encode( (string) wp_json_encode( [
				'iss'   => $sa['client_email'],
				'scope' => 'https://www.googleapis.com/auth/indexing',
				'aud'   => 'https://oauth2.googleapis.com/token',
				'iat'   => $now,
				'exp'   => $now + 3600,
			] ) );

			$signing_input = $header . '.' . $claims;
			$signature     = '';
			$ok            = @openssl_sign( $signing_input, $signature, (string) $sa['private_key'], OPENSSL_ALGO_SHA256 );
			if ( ! $ok || '' === $signature ) {
				return new \WP_Error(
					'directrelay_pro_jwt_sign_failed',
					__( 'Failed to sign Google OAuth2 JWT with the provided Service Account private_key.', 'directrelay-pro' ),
					[ 'status' => 500 ]
				);
			}

			$jwt  = $signing_input . '.' . self::base64url_encode( $signature );
			$resp = wp_remote_post(
				'https://oauth2.googleapis.com/token',
				[
					'timeout' => 10,
					'body'    => [
						'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
						'assertion'  => $jwt,
					],
				]
			);

			if ( is_wp_error( $resp ) ) {
				return $resp;
			}

			$body = json_decode( (string) wp_remote_retrieve_body( $resp ), true );
			if ( empty( $body['access_token'] ) ) {
				return new \WP_Error(
					'directrelay_pro_oauth_failed',
					sprintf(
						/* translators: %s: error detail from Google OAuth endpoint */
						__( 'Google OAuth2 token exchange failed: %s', 'directrelay-pro' ),
						sanitize_text_field( (string) ( $body['error_description'] ?? $body['error'] ?? 'Unknown error' ) )
					),
					[ 'status' => 502 ]
				);
			}

			$token = (string) $body['access_token'];
			set_transient( 'directrelay_pro_google_idx_token', $token, 55 * MINUTE_IN_SECONDS );
			return $token;
		}

		/**
		 * Submit a URL to Google Indexing API (`URL_UPDATED` or `URL_DELETED`) + IndexNow.
		 */
		public static function submit_url( string $url, string $type = 'URL_UPDATED', int $post_id = 0 ): array {
			$url  = esc_url_raw( $url, [ 'http', 'https' ] );
			$type = in_array( $type, [ 'URL_UPDATED', 'URL_DELETED' ], true ) ? $type : 'URL_UPDATED';

			$report = [
				'url'       => $url,
				'type'      => $type,
				'indexnow'  => 'skipped',
				'google'    => 'skipped',
				'timestamp' => current_time( 'c', true ),
			];

			// 1. Trigger IndexNow ping via Free's IndexNow_Pinger.
			if ( class_exists( '\DirectRelay\IndexNow_Pinger' ) ) {
				\DirectRelay\IndexNow_Pinger::ping( [ $url ], $post_id );
				$report['indexnow'] = 'dispatched';
			}

			// 2. Trigger Google Indexing API if Service Account is configured.
			if ( self::get_service_account() ) {
				$token = self::get_google_access_token();
				if ( is_wp_error( $token ) ) {
					$report['google']       = 'error';
					$report['google_error'] = $token->get_error_message();
				} else {
					$resp = wp_remote_post(
						'https://indexing.googleapis.com/v3/urlNotifications:publish',
						[
							'timeout' => 10,
							'headers' => [
								'Content-Type'  => 'application/json',
								'Authorization' => 'Bearer ' . $token,
							],
							'body'    => wp_json_encode( [
								'url'  => $url,
								'type' => $type,
							] ),
						]
					);

					if ( is_wp_error( $resp ) ) {
						$report['google']       = 'error';
						$report['google_error'] = $resp->get_error_message();
					} else {
						$code = (int) wp_remote_retrieve_response_code( $resp );
						$report['google']        = ( $code >= 200 && $code < 300 ) ? 'submitted' : 'http_' . $code;
						$report['google_status'] = $code;
						$report['google_body']   = json_decode( (string) wp_remote_retrieve_body( $resp ), true );
					}
				}
			}

			return $report;
		}

		/**
		 * Purge Edge CDN Cache (Cloudflare, BunnyCDN, Fastly, LiteSpeed) for specific URLs.
		 */
		public static function purge_cdn( array $urls, int $post_id = 0 ): array {
			$urls = array_values( array_unique( array_filter( array_map( static fn( $u ) => esc_url_raw( (string) $u, [ 'http', 'https' ] ), $urls ) ) ) );
			if ( empty( $urls ) ) {
				$urls = [ home_url( '/' ) ];
			}

			$cfg     = get_option( self::CDN_OPTION, [] );
			$cfg     = is_array( $cfg ) ? $cfg : [];
			$results = [ 'urls' => $urls, 'providers' => [] ];

			// 1. LiteSpeed Cache (native action + header).
			if ( $post_id > 0 ) {
				do_action( 'litespeed_purge_post', $post_id ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
			}
			$results['providers']['litespeed'] = 'dispatched';

			// 2. Cloudflare Zone Cache Purge (`zone_id` + `api_token`).
			if ( ! empty( $cfg['cf_zone_id'] ) && ! empty( $cfg['cf_api_token'] ) ) {
				$cf_endpoint = sprintf( 'https://api.cloudflare.com/client/v4/zones/%s/purge_cache', sanitize_text_field( (string) $cfg['cf_zone_id'] ) );
				$cf_resp     = wp_remote_post(
					$cf_endpoint,
					[
						'timeout' => 8,
						'headers' => [
							'Content-Type'  => 'application/json',
							'Authorization' => 'Bearer ' . trim( (string) $cfg['cf_api_token'] ),
						],
						'body'    => wp_json_encode( [ 'files' => $urls ] ),
					]
				);
				$results['providers']['cloudflare'] = is_wp_error( $cf_resp )
					? $cf_resp->get_error_message()
					: 'http_' . (int) wp_remote_retrieve_response_code( $cf_resp );
			}

			// 3. BunnyCDN URL Cache Purge (`bunny_api_key`).
			if ( ! empty( $cfg['bunny_api_key'] ) ) {
				$bunny_codes = [];
				foreach ( array_slice( $urls, 0, 10 ) as $u ) {
					$b_resp        = wp_remote_post(
						'https://api.bunny.net/purge?url=' . rawurlencode( $u ),
						[
							'timeout' => 6,
							'headers' => [ 'AccessKey' => trim( (string) $cfg['bunny_api_key'] ) ],
						]
					);
					$bunny_codes[] = is_wp_error( $b_resp ) ? 'err' : (int) wp_remote_retrieve_response_code( $b_resp );
				}
				$results['providers']['bunnycdn'] = $bunny_codes;
			}

			// 4. Fastly Instant Purge (`fastly_api_key`).
			if ( ! empty( $cfg['fastly_api_key'] ) ) {
				$fastly_codes = [];
				foreach ( array_slice( $urls, 0, 10 ) as $u ) {
					$f_resp         = wp_remote_request(
						$u,
						[
							'method'  => 'PURGE',
							'timeout' => 6,
							'headers' => [ 'Fastly-Key' => trim( (string) $cfg['fastly_api_key'] ) ],
						]
					);
					$fastly_codes[] = is_wp_error( $f_resp ) ? 'err' : (int) wp_remote_retrieve_response_code( $f_resp );
				}
				$results['providers']['fastly'] = $fastly_codes;
			}

			return $results;
		}

		/**
		 * Automatically trigger Google Indexing API + CDN purge when a post is published or updated.
		 */
		public static function on_post_status_change( string $new_status, string $old_status, \WP_Post $post ): void {
			if ( ! in_array( $post->post_type, [ 'post', 'page' ], true ) ) {
				return;
			}
			$permalink = get_permalink( $post->ID );
			if ( ! $permalink ) {
				return;
			}

			if ( 'publish' === $new_status ) {
				self::purge_cdn( [ $permalink, home_url( '/' ) ], $post->ID );
				if ( 'publish' !== $old_status && self::get_service_account() ) {
					self::submit_url( $permalink, 'URL_UPDATED', $post->ID );
				}
			} elseif ( 'trash' === $new_status && 'publish' === $old_status ) {
				self::purge_cdn( [ $permalink, home_url( '/' ) ], $post->ID );
				if ( self::get_service_account() ) {
					self::submit_url( $permalink, 'URL_DELETED', $post->ID );
				}
			}
		}

		private static function base64url_encode( string $data ): string {
			return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		}
	}
	}

	/**
	 * ============================================================================
	 * TIER 2 — MODULE 4: Smart Media Pipeline (Inline `<img>` Sideloader, WebP & OG Cards)
	 * ============================================================================
	 *
	 * - Scans incoming HTML content for external `<img src="https://...">` URLs
	 *   (such as expiring DALL-E, Midjourney, or Replicate links), sideloads them
	 *   into the local WordPress Media Library via `Post_Manager::sideload_url()`,
	 *   and rewrites `src` to the permanent local URL.
	 * - Converts uploaded JPEG/PNG attachments to `.webp` via `WP_Image_Editor` / GD.
	 * - Generates dynamic 1200x630 branded OpenGraph social cards (`POST /media/og-card`).
	 */
	if ( ! class_exists( '\DirectRelay\Pro\Smart_Media_Pipeline', false ) ) {
	final class Smart_Media_Pipeline {

		public static function init(): void {
			add_filter( 'rest_request_before_callbacks', [ __CLASS__, 'maybe_process_inline_media' ], 17, 3 );
		}

		/**
		 * Scan HTML for external `<img>` tags, sideload into WP Media Library, and rewrite `src`.
		 *
		 * @param string $html          Post HTML content.
		 * @param int    $post_id       Optional parent post ID.
		 * @param string $default_alt   Fallback ALT text (e.g. post title or focus keyword).
		 * @param bool   $convert_webp  Whether to convert sideloaded images to WebP.
		 * @return array{content: string, sideloaded_count: int, attachments: array<int, array>}
		 */
		public static function sideload_inline_images( string $html, int $post_id = 0, string $default_alt = '', bool $convert_webp = true ): array {
			if ( '' === trim( $html ) || ! str_contains( $html, '<img' ) ) {
				return [ 'content' => $html, 'sideloaded_count' => 0, 'attachments' => [] ];
			}

			$site_host   = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
			$attachments = [];
			$count       = 0;

			$html = (string) preg_replace_callback(
				'/<img\b([^>]*?\bsrc=["\'](https?:\/\/[^"\']+)["\'][^>]*?)>/i',
				static function ( array $m ) use ( $site_host, $post_id, $default_alt, $convert_webp, &$attachments, &$count ): string {
					$full_tag = $m[0];
					$attrs    = $m[1];
					$img_url  = html_entity_decode( $m[2], ENT_QUOTES, 'UTF-8' );
					$img_host = strtolower( (string) wp_parse_url( $img_url, PHP_URL_HOST ) );

					if ( '' === $img_host || $img_host === $site_host || $count >= 15 ) {
						return $full_tag; // Already local or per-post cap reached.
					}

					$alt_title = $default_alt ? sprintf( '%s — Image %d', $default_alt, $count + 1 ) : '';
					$att_id    = Post_Manager::sideload_url( $img_url, $post_id, $alt_title );
					if ( is_wp_error( $att_id ) || $att_id <= 0 ) {
						return $full_tag;
					}

					if ( $convert_webp ) {
						self::convert_attachment_to_webp( (int) $att_id );
					}

					$local_url = wp_get_attachment_url( (int) $att_id );
					if ( ! $local_url ) {
						return $full_tag;
					}

					++$count;
					$attachments[] = [
						'attachment_id' => (int) $att_id,
						'original_url'  => $img_url,
						'local_url'     => $local_url,
					];

					$rewritten = str_replace( $m[2], esc_url( $local_url ), $full_tag );
					if ( '' !== $alt_title && ! preg_match( '/\balt=["\'][^"\']+["\']/i', $attrs ) ) {
						$rewritten = str_replace( '<img ', '<img alt="' . esc_attr( $alt_title ) . '" ', $rewritten );
					}
					return $rewritten;
				},
				$html
			);

			return [
				'content'          => $html,
				'sideloaded_count' => $count,
				'attachments'      => $attachments,
			];
		}

		/**
		 * Convert an uploaded JPEG or PNG attachment to WebP format in place.
		 */
		public static function convert_attachment_to_webp( int $attachment_id ): array|\WP_Error {
			$file = get_attached_file( $attachment_id );
			if ( ! $file || ! is_file( $file ) ) {
				return new \WP_Error( 'directrelay_pro_no_file', __( 'Attachment file not found on disk.', 'directrelay-pro' ), [ 'status' => 404 ] );
			}

			$mime = (string) get_post_mime_type( $attachment_id );
			if ( 'image/webp' === $mime ) {
				return [ 'attachment_id' => $attachment_id, 'status' => 'already_webp', 'url' => wp_get_attachment_url( $attachment_id ) ];
			}
			if ( ! in_array( $mime, [ 'image/jpeg', 'image/jpg', 'image/png' ], true ) ) {
				return [ 'attachment_id' => $attachment_id, 'status' => 'skipped_mime', 'mime' => $mime ];
			}

			$webp_path = (string) preg_replace( '/\.(jpe?g|png)$/i', '.webp', $file );
			$converted = false;

			$editor = wp_get_image_editor( $file );
			if ( ! is_wp_error( $editor ) ) {
				$saved = $editor->save( $webp_path, 'image/webp' );
				if ( ! is_wp_error( $saved ) && ! empty( $saved['path'] ) && is_file( $saved['path'] ) ) {
					$webp_path = $saved['path'];
					$converted = true;
				}
			}

			// Fallback to native PHP GD `imagewebp()` if WP_Image_Editor didn't convert.
			if ( ! $converted && function_exists( 'imagewebp' ) && function_exists( 'imagecreatefromstring' ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				$raw_bytes = @file_get_contents( $file );
				$im        = $raw_bytes ? @imagecreatefromstring( $raw_bytes ) : false;
				if ( $im ) {
					imagepalettetotruecolor( $im );
					imagealphablending( $im, true );
					imagesavealpha( $im, true );
					if ( @imagewebp( $im, $webp_path, 82 ) ) {
						$converted = true;
					}
					imagedestroy( $im );
				}
			}

			if ( ! $converted || ! is_file( $webp_path ) ) {
				return [ 'attachment_id' => $attachment_id, 'status' => 'webp_unsupported_on_host', 'url' => wp_get_attachment_url( $attachment_id ) ];
			}

			update_attached_file( $attachment_id, $webp_path );
			wp_update_post( [
				'ID'             => $attachment_id,
				'post_mime_type' => 'image/webp',
			] );

			require_once ABSPATH . 'wp-admin/includes/image.php';
			wp_update_attachment_metadata( $attachment_id, wp_generate_attachment_metadata( $attachment_id, $webp_path ) );

			return [
				'attachment_id' => $attachment_id,
				'status'        => 'converted_to_webp',
				'mime_type'     => 'image/webp',
				'url'           => wp_get_attachment_url( $attachment_id ),
			];
		}

		/**
		 * Generate a branded 1200x630 OpenGraph Social Card PNG/WebP in the WP Media Library.
		 *
		 * @param array $args { title: string, subtitle?: string, badge?: string, post_id?: int }
		 * @return array|\WP_Error
		 */
		public static function generate_og_card( array $args ): array|\WP_Error {
			$title    = sanitize_text_field( (string) ( $args['title'] ?? get_bloginfo( 'name' ) ) );
			$subtitle = sanitize_text_field( (string) ( $args['subtitle'] ?? wp_parse_url( home_url(), PHP_URL_HOST ) ) );
			$badge    = strtoupper( sanitize_text_field( (string) ( $args['badge'] ?? 'FEATURED' ) ) );
			$post_id  = absint( $args['post_id'] ?? 0 );

			if ( ! function_exists( 'imagecreatetruecolor' ) ) {
				return new \WP_Error( 'directrelay_pro_no_gd', __( 'PHP GD extension is required to render OpenGraph social cards.', 'directrelay-pro' ), [ 'status' => 500 ] );
			}

			$w  = 1200;
			$h  = 630;
			$im = imagecreatetruecolor( $w, $h );

			$bg_dark   = imagecolorallocate( $im, 14, 26, 43 );
			$bg_card   = imagecolorallocate( $im, 26, 43, 69 );
			$cyan      = imagecolorallocate( $im, 40, 204, 205 );
			$white     = imagecolorallocate( $im, 248, 250, 252 );
			$slate     = imagecolorallocate( $im, 148, 163, 184 );

			imagefilledrectangle( $im, 0, 0, $w, $h, $bg_dark );
			imagefilledrectangle( $im, 48, 48, $w - 48, $h - 48, $bg_card );
			imagefilledrectangle( $im, 48, 48, 64, $h - 48, $cyan );

			// Badge & wrapped headline using built-in GD bitmap fonts for 100% portability across hosts.
			imagestring( $im, 5, 96, 92, $badge, $cyan );

			$wrapped_lines = explode( "\n", wordwrap( $title, 48, "\n", true ) );
			$y             = 170;
			foreach ( array_slice( $wrapped_lines, 0, 5 ) as $line ) {
				imagestring( $im, 5, 96, $y, $line, $white );
				$y += 42;
			}

			imagestring( $im, 4, 96, $h - 110, $subtitle, $slate );

			$up_dir = wp_upload_dir();
			if ( ! empty( $up_dir['error'] ) ) {
				imagedestroy( $im );
				return new \WP_Error( 'directrelay_pro_upload_dir', $up_dir['error'], [ 'status' => 500 ] );
			}

			$filename  = 'directrelay-og-' . ( $post_id ?: gmdate( 'YmdHis' ) ) . '-' . wp_generate_password( 6, false ) . '.png';
			$file_path = trailingslashit( $up_dir['path'] ) . $filename;

			imagepng( $im, $file_path, 6 );
			imagedestroy( $im );

			$att_id = wp_insert_attachment(
				[
					'post_mime_type' => 'image/png',
					'post_title'     => $title,
					'post_status'    => 'inherit',
					'post_parent'    => $post_id,
				],
				$file_path,
				$post_id
			);

			if ( is_wp_error( $att_id ) ) {
				return $att_id;
			}

			require_once ABSPATH . 'wp-admin/includes/image.php';
			wp_update_attachment_metadata( (int) $att_id, wp_generate_attachment_metadata( (int) $att_id, $file_path ) );
			update_post_meta( (int) $att_id, '_wp_attachment_image_alt', $title );

			if ( $post_id > 0 && ! has_post_thumbnail( $post_id ) ) {
				set_post_thumbnail( $post_id, (int) $att_id );
			}

			return [
				'attachment_id' => (int) $att_id,
				'url'           => wp_get_attachment_url( (int) $att_id ),
				'width'         => $w,
				'height'        => $h,
				'post_id'       => $post_id,
			];
		}

		/**
		 * Automatically sideload inline external `<img>` tags on REST post create/update
		 * when `"sideload_inline_images": true` is passed in the payload.
		 */
		public static function maybe_process_inline_media( $response, array $handler, \WP_REST_Request $request ) {
			if ( is_wp_error( $response ) || ! in_array( $request->get_method(), [ 'POST', 'PUT', 'PATCH' ], true ) ) {
				return $response;
			}
			if ( ! preg_match( '#^/directrelay/v1/(?:posts|pages|publish/one-shot|publish/universal)#', $request->get_route() ) ) {
				return $response;
			}

			$json = $request->get_json_params();
			if ( ! is_array( $json ) || empty( $json['sideload_inline_images'] ) || empty( $json['content'] ) ) {
				return $response;
			}

			$alt_seed        = (string) ( $json['seo']['focus_keyword'] ?? $json['title'] ?? '' );
			$processed       = self::sideload_inline_images( (string) $json['content'], (int) ( $request->get_param( 'id' ) ?? 0 ), $alt_seed );
			$json['content'] = $processed['content'];
			$request->set_body( wp_json_encode( $json ) );

			return $response;
		}
	}
	}

	/**
	 * ============================================================================
	 * TIER 2 — MODULE 5: Gutenberg Block Converter (`<!-- wp:* -->` Block Serializer)
	 * ============================================================================
	 *
	 * Converts Markdown or raw HTML into native WordPress Block Editor grammar
	 * (`<!-- wp:heading -->`, `<!-- wp:paragraph -->`, `<!-- wp:list -->`,
	 * `<!-- wp:quote -->`, `<!-- wp:code -->`, `<!-- wp:table -->`, `<!-- wp:image -->`,
	 * `<!-- wp:separator -->`, and `<!-- wp:rank-math/faq-block -->`).
	 */
	if ( ! class_exists( '\DirectRelay\Pro\Gutenberg_Block_Converter', false ) ) {
	final class Gutenberg_Block_Converter {

		public static function init(): void {
			add_filter( 'rest_request_before_callbacks', [ __CLASS__, 'maybe_convert_on_rest' ], 19, 3 );
		}

		/**
		 * Convert Markdown or HTML string into native WordPress Gutenberg block markup.
		 *
		 * @param string $content    Input Markdown or HTML.
		 * @param array  $faq_schema Optional FAQ items to append as a native Rank Math / Gutenberg FAQ block.
		 * @return string Gutenberg block-serialized HTML.
		 */
		public static function convert( string $content, array $faq_schema = [] ): string {
			$content = trim( $content );
			if ( '' === $content ) {
				return '';
			}

			// If already converted to Gutenberg blocks, only append FAQ block if requested.
			if ( str_contains( $content, '<!-- wp:' ) ) {
				return ! empty( $faq_schema ) ? $content . "\n\n" . self::build_faq_block( $faq_schema ) : $content;
			}

			// First pass through Free's Content_Processor to strip AI chatter and convert Markdown -> HTML.
			if ( class_exists( '\DirectRelay\Content_Processor' ) ) {
				$content = Content_Processor::process( $content );
			}

			// Normalize top-level block elements into Gutenberg comments.
			$blocks_out = [];
			$chunks     = preg_split( '/\n{2,}/', trim( $content ) ) ?: [ $content ];

			foreach ( $chunks as $chunk ) {
				$chunk = trim( $chunk );
				if ( '' === $chunk ) {
					continue;
				}

				// 1. Headings (`<h1>`..`<h6>`)
				if ( preg_match( '/^<h([1-6])([^>]*)>([\s\S]*?)<\/h\1>$/i', $chunk, $m ) ) {
					$level        = (int) $m[1];
					$inner        = $m[3];
					$blocks_out[] = sprintf(
						"<!-- wp:heading {\"level\":%d} -->\n<h%d class=\"wp-block-heading\">%s</h%d>\n<!-- /wp:heading -->",
						$level,
						$level,
						$inner,
						$level
					);
					continue;
				}

				// 2. Code blocks (`<pre><code...>...</code></pre>`)
				if ( preg_match( '/^<pre[^>]*>[\s\S]*?<\/pre>$/i', $chunk ) ) {
					$blocks_out[] = "<!-- wp:code -->\n" . preg_replace( '/^<pre/i', '<pre class="wp-block-code"', $chunk, 1 ) . "\n<!-- /wp:code -->";
					continue;
				}

				// 3. Blockquotes (`<blockquote>...</blockquote>`)
				if ( preg_match( '/^<blockquote[^>]*>([\s\S]*?)<\/blockquote>$/i', $chunk, $m ) ) {
					$blocks_out[] = "<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\">" . $m[1] . "</blockquote>\n<!-- /wp:quote -->";
					continue;
				}

				// 4. Unordered & Ordered Lists (`<ul>` / `<ol>`)
				if ( preg_match( '/^<(ul|ol)[^>]*>([\s\S]*?)<\/\1>$/i', $chunk, $m ) ) {
					$tag     = strtolower( $m[1] );
					$ordered = ( 'ol' === $tag ) ? ' {"ordered":true}' : '';
					$items   = preg_replace(
						'/<li([^>]*)>([\s\S]*?)<\/li>/i',
						"<!-- wp:list-item -->\n<li$1>$2</li>\n<!-- /wp:list-item -->",
						trim( $m[2] )
					);
					$blocks_out[] = sprintf(
						"<!-- wp:list%s -->\n<%s class=\"wp-block-list\">\n%s\n</%s>\n<!-- /wp:list -->",
						$ordered,
						$tag,
						$items,
						$tag
					);
					continue;
				}

				// 5. Tables (`<table>...</table>`)
				if ( preg_match( '/^<table[^>]*>[\s\S]*?<\/table>$/i', $chunk ) ) {
					$blocks_out[] = "<!-- wp:table -->\n<figure class=\"wp-block-table\">" . $chunk . "</figure>\n<!-- /wp:table -->";
					continue;
				}

				// 6. Horizontal Rules (`<hr />`)
				if ( preg_match( '/^<hr\s*\/?>$/i', $chunk ) ) {
					$blocks_out[] = "<!-- wp:separator -->\n<hr class=\"wp-block-separator has-alpha-channel-opacity\"/>\n<!-- /wp:separator -->";
					continue;
				}

				// 7. Standalone Images (`<img ... />` or `<p><img ... /></p>`)
				if ( preg_match( '/^(?:<p>)?\s*(<img\b[^>]+>)\s*(?:<\/p>)?$/i', $chunk, $m ) ) {
					$blocks_out[] = "<!-- wp:image {\"sizeSlug\":\"large\"} -->\n<figure class=\"wp-block-image size-large\">" . $m[1] . "</figure>\n<!-- /wp:image -->";
					continue;
				}

				// 8. Aside / AEO Summary Box (`<aside ...>...</aside>`)
				if ( preg_match( '/^<aside\b[\s\S]*?<\/aside>$/i', $chunk ) ) {
					$blocks_out[] = "<!-- wp:html -->\n" . $chunk . "\n<!-- /wp:html -->";
					continue;
				}

				// 9. Paragraphs (`<p>...</p>` or bare text)
				if ( preg_match( '/^<p[^>]*>[\s\S]*?<\/p>$/i', $chunk ) ) {
					$blocks_out[] = "<!-- wp:paragraph -->\n" . $chunk . "\n<!-- /wp:paragraph -->";
				} else {
					$blocks_out[] = "<!-- wp:paragraph -->\n<p>" . $chunk . "</p>\n<!-- /wp:paragraph -->";
				}
			}

			if ( ! empty( $faq_schema ) ) {
				$faq_block = self::build_faq_block( $faq_schema );
				if ( '' !== $faq_block ) {
					$blocks_out[] = $faq_block;
				}
			}

			return implode( "\n\n", $blocks_out );
		}

		/**
		 * Build a native Rank Math / Gutenberg FAQ block (`<!-- wp:rank-math/faq-block -->`).
		 */
		public static function build_faq_block( array $faq_items ): string {
			$clean = SEO_Write_Engine::sanitize_faq_schema( $faq_items );
			if ( is_wp_error( $clean ) || empty( $clean ) ) {
				return '';
			}

			$rm_questions = [];
			$html_items   = [];
			foreach ( $clean as $idx => $item ) {
				$qid            = 'faq-question-' . ( $idx + 1 );
				$rm_questions[] = [
					'id'       => $qid,
					'title'    => $item['question'],
					'content'  => $item['answer'],
					'visible'  => true,
				];
				$html_items[]   = sprintf(
					'<div class="rank-math-faq-item"><h3 class="rank-math-question">%s</h3><div class="rank-math-answer">%s</div></div>',
					esc_html( $item['question'] ),
					wp_kses_post( $item['answer'] )
				);
			}

			$attrs_json = wp_json_encode( [ 'questions' => $rm_questions ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
			return sprintf(
				"<!-- wp:rank-math/faq-block %s -->\n<div class=\"wp-block-rank-math-faq-block\">%s</div>\n<!-- /wp:rank-math/faq-block -->",
				$attrs_json,
				implode( '', $html_items )
			);
		}

		/**
		 * Automatically convert content to Gutenberg blocks on REST post create/update
		 * when `"convert_to_blocks": true` is passed in the payload.
		 */
		public static function maybe_convert_on_rest( $response, array $handler, \WP_REST_Request $request ) {
			if ( is_wp_error( $response ) || ! in_array( $request->get_method(), [ 'POST', 'PUT', 'PATCH' ], true ) ) {
				return $response;
			}
			if ( ! preg_match( '#^/directrelay/v1/(?:posts|pages|publish/one-shot|publish/universal)#', $request->get_route() ) ) {
				return $response;
			}

			$json = $request->get_json_params();
			if ( ! is_array( $json ) || empty( $json['convert_to_blocks'] ) || empty( $json['content'] ) ) {
				return $response;
			}

			$faqs            = ! empty( $json['append_faq_block'] ) && ! empty( $json['seo']['faq_schema'] ) && is_array( $json['seo']['faq_schema'] )
				? $json['seo']['faq_schema']
				: [];
			$json['content'] = self::convert( (string) $json['content'], $faqs );
			$request->set_body( wp_json_encode( $json ) );

			return $response;
		}
	}
	}
}

namespace DirectRelay\Pro\REST {

	defined( 'ABSPATH' ) || exit;

	use DirectRelay\Pro\GEO_AEO_Engine;
	use DirectRelay\Pro\Gutenberg_Block_Converter;
	use DirectRelay\Pro\Instant_Indexer_CDN;
	use DirectRelay\Pro\Internal_Linking_Engine;
	use DirectRelay\Pro\Smart_Media_Pipeline;

	/**
	 * Tier 2 — Module 1 REST Controller: Automated Internal Linking & Semantic Silo API
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\Internal_Links_Controller', false ) ) {
	final class Internal_Links_Controller extends Pro_Base_Controller {

		public static function register(): void {
			register_rest_route(
				self::NS,
				'/seo/internal-links',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'suggest' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'seo:read' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/seo/internal-links/rules',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'list_rules' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'seo:read' ),
					],
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'save_rule' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'seo:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/seo/internal-links/rules/(?P<id>[a-zA-Z0-9_-]+)',
				[
					[
						'methods'             => \WP_REST_Server::DELETABLE,
						'callback'            => [ self::class, 'delete_rule' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'seo:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/seo/internal-links/apply/(?P<id>\\d+)',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'apply_to_post' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:write' ),
					],
				]
			);
		}

		public static function suggest( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$links = Internal_Linking_Engine::suggest_links( $req->get_params() );
			return self::ok( $req, [ 'suggestions' => $links, 'total' => count( $links ) ], 200, 'suggest_internal_links' );
		}

		public static function list_rules( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$rules = Internal_Linking_Engine::get_rules();
			return self::ok( $req, [ 'rules' => $rules, 'total' => count( $rules ) ], 200, 'list_internal_link_rules' );
		}

		public static function save_rule( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body = $req->get_json_params() ?: [];
			$res  = Internal_Linking_Engine::save_rule( $body );
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'save_internal_link_rule' );
			}
			return self::ok( $req, [ 'rule' => $res ], 201, 'save_internal_link_rule' );
		}

		public static function delete_rule( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id = sanitize_key( (string) $req->get_param( 'id' ) );
			$ok = Internal_Linking_Engine::delete_rule( $id );
			return self::ok( $req, [ 'deleted' => $ok, 'id' => $id ], 200, 'delete_internal_link_rule' );
		}

		public static function apply_to_post( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$post_id = (int) $req->get_param( 'id' );
			$post    = get_post( $post_id );
			if ( ! $post ) {
				return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Post not found.', 'directrelay-pro' ), [ 'status' => 404 ] ), 'apply_internal_links' );
			}
			$body      = $req->get_json_params() ?: [];
			$max_links = max( 1, min( 20, (int) ( $body['max_links'] ?? 5 ) ) );
			$applied   = Internal_Linking_Engine::apply_rules_to_content( $post->post_content, $post_id, $max_links );
			if ( $applied['links_added'] > 0 ) {
				wp_update_post( [
					'ID'           => $post_id,
					'post_content' => wp_slash( $applied['content'] ),
				] );
			}
			return self::ok(
				$req,
				[
					'post_id'       => $post_id,
					'links_added'   => $applied['links_added'],
					'applied_rules' => $applied['applied_rules'],
				],
				200,
				'apply_internal_links',
				$post_id,
				$post->post_type
			);
		}
	}
	}

	/**
	 * Tier 2 — Module 2 REST Controller: GEO / AEO & `/llms.txt` Endpoints
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\GEO_Controller', false ) ) {
	final class GEO_Controller extends Pro_Base_Controller {

		public static function register(): void {
			register_rest_route(
				self::NS,
				'/geo/llms-txt',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'llms_txt' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'seo:read' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/geo/citation-block',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'citation_block' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:write' ),
					],
				]
			);
		}

		public static function llms_txt( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$full  = ! empty( $req->get_param( 'full' ) );
			$limit = max( 1, min( 200, (int) ( $req->get_param( 'limit' ) ?: 50 ) ) );
			return self::ok(
				$req,
				[
					'llms_txt_url'      => home_url( '/llms.txt' ),
					'llms_full_txt_url' => home_url( '/llms-full.txt' ),
					'markdown'          => GEO_AEO_Engine::generate_llms_txt( $full, $limit ),
				],
				200,
				'get_llms_txt'
			);
		}

		public static function citation_block( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body    = $req->get_json_params() ?: [];
			$html    = GEO_AEO_Engine::build_citation_block_html( $body );
			$post_id = absint( $body['post_id'] ?? 0 );

			if ( $post_id > 0 && '' !== $html ) {
				$post = get_post( $post_id );
				if ( $post && ! str_contains( $post->post_content, 'directrelay-aeo-summary' ) ) {
					wp_update_post( [
						'ID'           => $post_id,
						'post_content' => wp_slash( $html . "\n\n" . $post->post_content ),
					] );
				}
			}

			return self::ok(
				$req,
				[
					'html'    => $html,
					'post_id' => $post_id ?: null,
				],
				200,
				'build_citation_block',
				$post_id ?: null,
				'post'
			);
		}
	}
	}

	/**
	 * Tier 2 — Module 3 REST Controller: Google Indexing API & Edge CDN Purge Endpoints
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\Indexer_Controller', false ) ) {
	final class Indexer_Controller extends Pro_Base_Controller {

		public static function register(): void {
			register_rest_route(
				self::NS,
				'/indexer/submit',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'submit' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'seo:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/indexer/service-account',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'save_sa' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'seo:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/indexer/status',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'status' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'seo:read' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/cdn/purge',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'purge_cdn' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:write' ),
					],
				]
			);
		}

		public static function submit( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body    = $req->get_json_params() ?: [];
			$post_id = absint( $body['post_id'] ?? 0 );
			$url     = ! empty( $body['url'] ) ? (string) $body['url'] : ( $post_id ? (string) get_permalink( $post_id ) : '' );
			$type    = (string) ( $body['type'] ?? 'URL_UPDATED' );

			if ( '' === $url || ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
				return self::fail( $req, new \WP_Error( 'amp_invalid', __( 'A valid "url" or "post_id" is required.', 'directrelay-pro' ), [ 'status' => 400 ] ), 'indexer_submit' );
			}

			$res = Instant_Indexer_CDN::submit_url( $url, $type, $post_id );
			return self::ok( $req, $res, 200, 'indexer_submit', $post_id ?: null, 'post' );
		}

		public static function save_sa( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body = $req->get_json_params() ?: [];
			$sa   = $body['service_account'] ?? $body;
			$res  = Instant_Indexer_CDN::save_service_account( $sa );
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'indexer_save_sa' );
			}
			$saved = Instant_Indexer_CDN::get_service_account();
			return self::ok(
				$req,
				[
					'configured'   => true,
					'client_email' => $saved['client_email'] ?? '',
					'project_id'   => $saved['project_id'] ?? '',
				],
				200,
				'indexer_save_sa'
			);
		}

		public static function status( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$sa = Instant_Indexer_CDN::get_service_account();
			return self::ok(
				$req,
				[
					'google_indexing_configured' => null !== $sa,
					'google_client_email'        => $sa['client_email'] ?? null,
					'indexnow_key_url'           => home_url( '/indexnow-key.txt' ),
					'llms_txt_url'               => home_url( '/llms.txt' ),
				],
				200,
				'indexer_status'
			);
		}

		public static function purge_cdn( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body    = $req->get_json_params() ?: [];
			$post_id = absint( $body['post_id'] ?? 0 );
			$urls    = isset( $body['urls'] ) && is_array( $body['urls'] ) ? $body['urls'] : [];
			if ( $post_id > 0 ) {
				$urls[] = (string) get_permalink( $post_id );
			}
			$res = Instant_Indexer_CDN::purge_cdn( $urls, $post_id );
			return self::ok( $req, $res, 200, 'cdn_purge', $post_id ?: null, 'post' );
		}
	}
	}

	/**
	 * Tier 2 — Module 4 REST Controller: Smart Media Pipeline Endpoints
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\Smart_Media_Controller', false ) ) {
	final class Smart_Media_Controller extends Pro_Base_Controller {

		public static function register(): void {
			register_rest_route(
				self::NS,
				'/media/sideload-inline',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'sideload_inline' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'media:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/media/(?P<id>\\d+)/webp',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'convert_webp' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'media:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/media/og-card',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'og_card' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'media:write' ),
					],
				]
			);
		}

		public static function sideload_inline( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body    = $req->get_json_params() ?: [];
			$post_id = absint( $body['post_id'] ?? 0 );
			$html    = (string) ( $body['content'] ?? ( $post_id ? get_post_field( 'post_content', $post_id ) : '' ) );
			$alt     = sanitize_text_field( (string) ( $body['alt'] ?? '' ) );

			$res = Smart_Media_Pipeline::sideload_inline_images( $html, $post_id, $alt );
			if ( $post_id > 0 && $res['sideloaded_count'] > 0 ) {
				wp_update_post( [
					'ID'           => $post_id,
					'post_content' => wp_slash( $res['content'] ),
				] );
			}
			return self::ok( $req, $res, 200, 'sideload_inline_media', $post_id ?: null, 'post' );
		}

		public static function convert_webp( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id  = (int) $req->get_param( 'id' );
			$res = Smart_Media_Pipeline::convert_attachment_to_webp( $id );
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'convert_media_webp' );
			}
			return self::ok( $req, $res, 200, 'convert_media_webp', $id, 'media' );
		}

		public static function og_card( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body = $req->get_json_params() ?: [];
			$res  = Smart_Media_Pipeline::generate_og_card( $body );
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'generate_og_card' );
			}
			return self::ok( $req, $res, 201, 'generate_og_card', (int) $res['attachment_id'], 'media' );
		}
	}
	}

	/**
	 * Tier 2 — Module 5 REST Controller: Gutenberg Block Converter Endpoints
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\Blocks_Controller', false ) ) {
	final class Blocks_Controller extends Pro_Base_Controller {

		public static function register(): void {
			register_rest_route(
				self::NS,
				'/blocks/convert',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'convert' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:write' ),
					],
				]
			);
		}

		public static function convert( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body    = $req->get_json_params() ?: [];
			$post_id = absint( $body['post_id'] ?? 0 );
			$content = (string) ( $body['content'] ?? ( $post_id ? get_post_field( 'post_content', $post_id ) : '' ) );
			$faqs    = isset( $body['faq_schema'] ) && is_array( $body['faq_schema'] ) ? $body['faq_schema'] : [];

			$blocks = Gutenberg_Block_Converter::convert( $content, $faqs );
			if ( $post_id > 0 && '' !== $blocks && ! empty( $body['save'] ) ) {
				wp_update_post( [
					'ID'           => $post_id,
					'post_content' => wp_slash( $blocks ),
				] );
			}

			return self::ok(
				$req,
				[
					'blocks_content' => $blocks,
					'post_id'        => $post_id ?: null,
					'saved'          => $post_id > 0 && ! empty( $body['save'] ),
				],
				200,
				'convert_to_blocks',
				$post_id ?: null,
				'post'
			);
		}
	}
	}
}


namespace DirectRelay\Pro {

	defined( 'ABSPATH' ) || exit;

	use DirectRelay\Agent_Profiles;
	use DirectRelay\Content_Processor;
	use DirectRelay\Guardrails_Manager;
	use DirectRelay\Post_Manager;
	use DirectRelay\Webhook_Manager;

	/**
	 * ============================================================================
	 * TIER 3 — MODULE 1: Universal Custom Post Type (CPT) & ACF Pro / Meta Engine
	 * ============================================================================
	 *
	 * - Full CRUD for any public Custom Post Type (`real_estate`, `jobs`, `events`,
	 *   `portfolio`, `listings`, etc.) and any custom taxonomy.
	 * - Deep recursive field processor for ACF Pro (Repeaters, Flexible Content,
	 *   Galleries, Post Object Relationships), Meta Box (`rwmb_set_meta`), JetEngine,
	 *   and Pods — including automatic remote image URL sideloading inside nested
	 *   repeater/gallery fields.
	 */
	if ( ! class_exists( '\DirectRelay\Pro\CPT_Fields_Engine', false ) ) {
	final class CPT_Fields_Engine {

		public static function init(): void {
			// Also support nested ACF repeater/gallery sideloading on standard `/posts` and `/pages`.
			add_action( 'rest_after_insert_post', [ __CLASS__, 'noop' ], 10, 0 );
		}

		public static function noop(): void {}

		/**
		 * Check whether a post type is publicly registered and allowed for CPT operations.
		 */
		public static function is_allowed_post_type( string $post_type ): bool {
			$post_type = sanitize_key( $post_type );
			if ( in_array( $post_type, [ 'attachment', 'revision', 'nav_menu_item', 'custom_css', 'customize_changeset' ], true ) ) {
				return false;
			}
			$public_types = get_post_types( [ 'public' => true ], 'names' );
			return isset( $public_types[ $post_type ] );
		}

		/**
		 * Format a Custom Post Type item with all attached custom taxonomies,
		 * ACF fields, custom meta, and 4-plugin SEO metadata.
		 */
		public static function format_cpt_item( \WP_Post $post, bool $include_full_meta = true ): array {
			$base               = Post_Manager::format( $post );
			$base['taxonomies'] = [];

			$tax_objects = get_object_taxonomies( $post->post_type, 'objects' );
			foreach ( $tax_objects as $tax_slug => $tax_obj ) {
				if ( ! $tax_obj->public ) {
					continue;
				}
				$terms = wp_get_object_terms( $post->ID, $tax_slug );
				if ( ! is_wp_error( $terms ) ) {
					$base['taxonomies'][ $tax_slug ] = array_map(
						static fn( \WP_Term $t ): array => [
							'id'   => $t->term_id,
							'name' => $t->name,
							'slug' => $t->slug,
						],
						$terms
					);
				}
			}

			$base['seo'] = SEO_Write_Engine::read( $post->ID );

			if ( function_exists( 'get_fields' ) ) {
				$acf_vals    = get_fields( $post->ID );
				$base['acf'] = is_array( $acf_vals ) ? $acf_vals : [];
			}

			if ( $include_full_meta ) {
				$raw_meta = get_post_meta( $post->ID );
				$clean    = [];
				foreach ( $raw_meta as $k => $vals ) {
					if ( str_starts_with( (string) $k, '_edit_' ) || str_starts_with( (string) $k, '_wp_' ) || str_starts_with( (string) $k, '_directrelay' ) || str_starts_with( (string) $k, 'rank_math_' ) || str_starts_with( (string) $k, '_yoast_' ) || str_starts_with( (string) $k, '_aioseo_' ) || str_starts_with( (string) $k, '_seopress_' ) ) {
						continue;
					}
					$clean[ $k ] = 1 === count( $vals ) ? maybe_unserialize( $vals[0] ) : array_map( 'maybe_unserialize', $vals );
				}
				$base['meta'] = $clean;
			}

			return $base;
		}

		/**
		 * Create or update a Custom Post Type item with custom taxonomies, ACF Pro
		 * repeaters/flexible content/galleries, Meta Box, JetEngine, Pods, and SEO.
		 *
		 * @param string   $post_type Target CPT slug.
		 * @param array    $data      Request payload.
		 * @param int|null $update_id Existing post ID for update, or null to create.
		 * @return array|\WP_Error Formatted CPT item.
		 */
		public static function upsert_cpt_item( string $post_type, array $data, ?int $update_id = null ): array|\WP_Error {
			if ( ! self::is_allowed_post_type( $post_type ) ) {
				return new \WP_Error(
					'directrelay_pro_invalid_cpt',
					sprintf(
						/* translators: %s: post type slug */
						__( 'Post type "%s" is not a valid public post type.', 'directrelay-pro' ),
						$post_type
					),
					[ 'status' => 400 ]
				);
			}

			if ( $update_id ) {
				$existing = get_post( $update_id );
				if ( ! $existing || $existing->post_type !== $post_type ) {
					return new \WP_Error( 'amp_not_found', __( 'Custom post type item not found.', 'directrelay-pro' ), [ 'status' => 404 ] );
				}
				Content_Decay_Versioning::capture_pre_ai_snapshot( $update_id, 'cpt_update' );
				$post_id = Post_Manager::update( $update_id, $data );
			} else {
				$post_id = Post_Manager::create( $data, $post_type );
			}

			if ( is_wp_error( $post_id ) ) {
				return $post_id;
			}
			$post_id = (int) $post_id;

			// 1. Apply Custom Taxonomies (`taxonomies: { "genre": ["Sci-Fi", "Action"], "location": [12] }`).
			if ( ! empty( $data['taxonomies'] ) && is_array( $data['taxonomies'] ) ) {
				self::apply_custom_taxonomies( $post_id, $post_type, $data['taxonomies'] );
			}

			// 2. Apply Gallery URLs if supplied.
			if ( ! empty( $data['gallery'] ) && is_array( $data['gallery'] ) ) {
				$gallery_ids = [];
				foreach ( $data['gallery'] as $g_item ) {
					if ( is_numeric( $g_item ) ) {
						$gallery_ids[] = (int) $g_item;
					} elseif ( is_string( $g_item ) && filter_var( $g_item, FILTER_VALIDATE_URL ) ) {
						$att_id = Post_Manager::sideload_url( $g_item, $post_id );
						if ( ! is_wp_error( $att_id ) && $att_id > 0 ) {
							$gallery_ids[] = (int) $att_id;
						}
					}
				}
				if ( ! empty( $gallery_ids ) ) {
					update_post_meta( $post_id, '_directrelay_gallery_ids', $gallery_ids );
				}
			}

			// 3. Apply Deep ACF Pro (Repeaters, Flexible Content, Galleries) + Meta Box + JetEngine + Pods.
			self::apply_advanced_fields( $post_id, $data );

			// 4. Apply 4-Plugin SEO Metadata + JSON-LD Schemas if supplied.
			if ( ! empty( $data['seo'] ) && is_array( $data['seo'] ) ) {
				$seo_res = SEO_Write_Engine::update( $post_id, $data['seo'] );
				if ( is_wp_error( $seo_res ) ) {
					return $seo_res;
				}
			}

			$post_obj = get_post( $post_id );
			return self::format_cpt_item( $post_obj, true );
		}

		/**
		 * Resolve or auto-create terms in any registered custom taxonomy and assign to post.
		 */
		public static function apply_custom_taxonomies( int $post_id, string $post_type, array $taxonomies ): void {
			$valid_taxes = get_object_taxonomies( $post_type, 'names' );

			foreach ( $taxonomies as $tax_slug => $terms_input ) {
				$tax_slug = sanitize_key( (string) $tax_slug );
				if ( ! in_array( $tax_slug, $valid_taxes, true ) || ! taxonomy_exists( $tax_slug ) ) {
					continue;
				}

				if ( is_string( $terms_input ) ) {
					$terms_input = array_map( 'trim', explode( ',', $terms_input ) );
				}
				if ( ! is_array( $terms_input ) ) {
					continue;
				}

				$term_ids = [];
				foreach ( $terms_input as $term_item ) {
					if ( is_numeric( $term_item ) ) {
						$term_ids[] = (int) $term_item;
						continue;
					}
					$t_name = sanitize_text_field( (string) ( is_array( $term_item ) ? ( $term_item['name'] ?? '' ) : $term_item ) );
					if ( '' === $t_name ) {
						continue;
					}
					$existing = get_term_by( 'name', $t_name, $tax_slug ) ?: get_term_by( 'slug', sanitize_title( $t_name ), $tax_slug );
					if ( $existing instanceof \WP_Term ) {
						$term_ids[] = (int) $existing->term_id;
					} else {
						$inserted = wp_insert_term( $t_name, $tax_slug );
						if ( ! is_wp_error( $inserted ) && ! empty( $inserted['term_id'] ) ) {
							$term_ids[] = (int) $inserted['term_id'];
						} elseif ( is_wp_error( $inserted ) && isset( $inserted->error_data['term_exists'] ) ) {
							$term_ids[] = (int) $inserted->error_data['term_exists'];
						}
					}
				}

				wp_set_object_terms( $post_id, array_values( array_unique( $term_ids ) ), $tax_slug, false );
			}
		}

		/**
		 * Recursively process ACF Pro (Repeaters, Flexible Content, Galleries), Meta Box,
		 * JetEngine, and Pods fields, sideloading remote image URLs inside nested rows.
		 */
		public static function apply_advanced_fields( int $post_id, array $data ): void {
			// 1. ACF / ACF Pro (`acf` payload key)
			if ( ! empty( $data['acf'] ) && is_array( $data['acf'] ) ) {
				$resolved_acf = self::resolve_nested_media_urls( $data['acf'], $post_id );
				if ( function_exists( 'update_field' ) ) {
					foreach ( $resolved_acf as $selector => $value ) {
						update_field( sanitize_text_field( (string) $selector ), $value, $post_id );
					}
				} else {
					// Fallback when ACF is inactive or headless: store both structured array and flat repeater meta.
					foreach ( $resolved_acf as $selector => $value ) {
						$clean_key = sanitize_key( (string) $selector );
						update_post_meta( $post_id, $clean_key, $value );
					}
				}
			}

			// 2. Meta Box (`metabox` payload key)
			if ( ! empty( $data['metabox'] ) && is_array( $data['metabox'] ) ) {
				$resolved_mb = self::resolve_nested_media_urls( $data['metabox'], $post_id );
				foreach ( $resolved_mb as $field_id => $val ) {
					$fid = sanitize_key( (string) $field_id );
					if ( function_exists( 'rwmb_set_meta' ) ) {
						rwmb_set_meta( $post_id, $fid, $val );
					} else {
						update_post_meta( $post_id, $fid, $val );
					}
				}
			}

			// 3. JetEngine (`jetengine` payload key)
			if ( ! empty( $data['jetengine'] ) && is_array( $data['jetengine'] ) ) {
				$resolved_je = self::resolve_nested_media_urls( $data['jetengine'], $post_id );
				foreach ( $resolved_je as $field_id => $val ) {
					update_post_meta( $post_id, sanitize_key( (string) $field_id ), $val );
				}
			}

			// 4. Pods (`pods` payload key)
			if ( ! empty( $data['pods'] ) && is_array( $data['pods'] ) ) {
				$resolved_pods = self::resolve_nested_media_urls( $data['pods'], $post_id );
				if ( function_exists( 'pods' ) ) {
					$pod = pods( get_post_type( $post_id ), $post_id );
					if ( is_object( $pod ) && method_exists( $pod, 'save' ) ) {
						$pod->save( $resolved_pods );
					}
				} else {
					foreach ( $resolved_pods as $field_id => $val ) {
						update_post_meta( $post_id, sanitize_key( (string) $field_id ), $val );
					}
				}
			}
		}

		/**
		 * Walk nested Repeater / Flexible Content / Gallery arrays and convert any field
		 * ending in `_image_url` or `_file_url` into a sideloaded attachment ID.
		 */
		private static function resolve_nested_media_urls( mixed $node, int $post_id ): mixed {
			if ( ! is_array( $node ) ) {
				return $node;
			}
			$out = [];
			foreach ( $node as $k => $v ) {
				$key_str = (string) $k;
				if ( is_string( $v ) && ( str_ends_with( $key_str, '_image_url' ) || str_ends_with( $key_str, '_media_url' ) ) && filter_var( $v, FILTER_VALIDATE_URL ) ) {
					$att_id      = Post_Manager::sideload_url( $v, $post_id );
					$target_name = (string) preg_replace( '/_(?:image|media)_url$/', '', $key_str );
					if ( ! is_wp_error( $att_id ) && $att_id > 0 ) {
						$out[ $target_name ] = (int) $att_id;
						continue;
					}
				}
				$out[ $k ] = is_array( $v ) ? self::resolve_nested_media_urls( $v, $post_id ) : $v;
			}
			return $out;
		}
	}
	}

	/**
	 * ============================================================================
	 * TIER 3 — MODULE 2: WooCommerce Automation Bridge
	 * ============================================================================
	 *
	 * - Full Product & Variable Variation CRUD (`/wc/products`).
	 * - High-speed SKU Inventory & Price Sync (`/wc/products/inventory-sync`) for
	 *   Odoo / ERP / Shopify n8n workflows.
	 * - Order listing, detail inspection, status updates, and customer/private order
	 *   notes (`/wc/orders`).
	 * - Outgoing WooCommerce webhook triggers (`order.created`, `order.paid`,
	 *   `stock.low`, `product.updated`).
	 */
	if ( ! class_exists( '\DirectRelay\Pro\WooCommerce_Bridge', false ) ) {
	final class WooCommerce_Bridge {

		public static function init(): void {
			add_action( 'woocommerce_new_order', [ __CLASS__, 'on_order_created' ], 20, 1 );
			add_action( 'woocommerce_payment_complete', [ __CLASS__, 'on_order_paid' ], 20, 1 );
			add_action( 'woocommerce_low_stock', [ __CLASS__, 'on_low_stock' ], 20, 1 );
			add_action( 'woocommerce_no_stock', [ __CLASS__, 'on_low_stock' ], 20, 1 );
			add_action( 'woocommerce_update_product', [ __CLASS__, 'on_product_updated' ], 20, 1 );
		}

		public static function is_active(): bool {
			return class_exists( 'WooCommerce' ) || function_exists( 'wc_get_product' ) || post_type_exists( 'product' );
		}

		/**
		 * Create or update a WooCommerce product (Simple or Variable with variations,
		 * pricing, SKU, stock, weight, dimensions, categories, images, and SEO/Product Schema).
		 */
		public static function upsert_product( array $data, ?int $product_id = null ): array|\WP_Error {
			if ( ! post_type_exists( 'product' ) ) {
				// Register a lightweight `product` post type fallback if WC is not yet active on a staging test node.
				register_post_type( 'product', [ 'public' => true, 'label' => 'Products' ] );
			}

			$post_payload = [
				'title'              => sanitize_text_field( (string) ( $data['name'] ?? $data['title'] ?? '' ) ),
				'content'            => (string) ( $data['description'] ?? $data['content'] ?? '' ),
				'excerpt'            => (string) ( $data['short_description'] ?? $data['excerpt'] ?? '' ),
				'status'             => sanitize_key( (string) ( $data['status'] ?? 'publish' ) ),
				'slug'               => sanitize_title( (string) ( $data['slug'] ?? '' ) ),
				'featured_media_url' => $data['featured_image_url'] ?? $data['image_url'] ?? null,
				'featured_media'     => $data['featured_media'] ?? null,
			];

			if ( $product_id ) {
				$existing = get_post( $product_id );
				if ( ! $existing || 'product' !== $existing->post_type ) {
					return new \WP_Error( 'amp_not_found', __( 'Product not found.', 'directrelay-pro' ), [ 'status' => 404 ] );
				}
				$pid = Post_Manager::update( $product_id, array_filter( $post_payload, static fn( $v ) => null !== $v && '' !== $v ) );
			} else {
				if ( '' === $post_payload['title'] ) {
					return new \WP_Error( 'amp_invalid', __( 'Product "name" or "title" is required.', 'directrelay-pro' ), [ 'status' => 400 ] );
				}
				$pid = Post_Manager::create( $post_payload, 'product' );
			}

			if ( is_wp_error( $pid ) ) {
				return $pid;
			}
			$pid = (int) $pid;

			// Write WooCommerce pricing, SKU, stock, and shipping meta.
			if ( array_key_exists( 'sku', $data ) ) {
				update_post_meta( $pid, '_sku', sanitize_text_field( (string) $data['sku'] ) );
			}
			if ( array_key_exists( 'regular_price', $data ) ) {
				$reg = (string) floatval( $data['regular_price'] );
				update_post_meta( $pid, '_regular_price', $reg );
				if ( ! array_key_exists( 'sale_price', $data ) ) {
					update_post_meta( $pid, '_price', $reg );
				}
			}
			if ( array_key_exists( 'sale_price', $data ) ) {
				$sale = '' !== (string) $data['sale_price'] ? (string) floatval( $data['sale_price'] ) : '';
				update_post_meta( $pid, '_sale_price', $sale );
				if ( '' !== $sale ) {
					update_post_meta( $pid, '_price', $sale );
				}
			}
			if ( array_key_exists( 'manage_stock', $data ) ) {
				update_post_meta( $pid, '_manage_stock', ! empty( $data['manage_stock'] ) ? 'yes' : 'no' );
			}
			if ( array_key_exists( 'stock_quantity', $data ) ) {
				$qty = (int) $data['stock_quantity'];
				update_post_meta( $pid, '_stock', $qty );
				update_post_meta( $pid, '_manage_stock', 'yes' );
				update_post_meta( $pid, '_stock_status', $qty > 0 ? 'instock' : 'outofstock' );
			}
			if ( array_key_exists( 'stock_status', $data ) ) {
				$st = in_array( $data['stock_status'], [ 'instock', 'outofstock', 'onbackorder' ], true ) ? $data['stock_status'] : 'instock';
				update_post_meta( $pid, '_stock_status', $st );
			}
			foreach ( [ 'weight' => '_weight', 'length' => '_length', 'width' => '_width', 'height' => '_height' ] as $dim_key => $meta_key ) {
				if ( array_key_exists( $dim_key, $data ) ) {
					update_post_meta( $pid, $meta_key, sanitize_text_field( (string) $data[ $dim_key ] ) );
				}
			}

			// Product Categories (`product_cat`) & Tags (`product_tag`).
			if ( ! empty( $data['categories'] ) && taxonomy_exists( 'product_cat' ) ) {
				CPT_Fields_Engine::apply_custom_taxonomies( $pid, 'product', [ 'product_cat' => $data['categories'] ] );
			}
			if ( ! empty( $data['tags'] ) && taxonomy_exists( 'product_tag' ) ) {
				CPT_Fields_Engine::apply_custom_taxonomies( $pid, 'product', [ 'product_tag' => $data['tags'] ] );
			}

			// Product Gallery (`gallery` URLs or attachment IDs -> `_product_image_gallery`).
			if ( ! empty( $data['gallery'] ) && is_array( $data['gallery'] ) ) {
				$gal_ids = [];
				foreach ( $data['gallery'] as $g ) {
					if ( is_numeric( $g ) ) {
						$gal_ids[] = (int) $g;
					} elseif ( is_string( $g ) && filter_var( $g, FILTER_VALIDATE_URL ) ) {
						$att = Post_Manager::sideload_url( $g, $pid );
						if ( ! is_wp_error( $att ) && $att > 0 ) {
							$gal_ids[] = (int) $att;
						}
					}
				}
				if ( ! empty( $gal_ids ) ) {
					update_post_meta( $pid, '_product_image_gallery', implode( ',', $gal_ids ) );
				}
			}

			// Auto-sync SEO & Product JSON-LD Schema.
			$seo_payload = isset( $data['seo'] ) && is_array( $data['seo'] ) ? $data['seo'] : [];
			if ( empty( $seo_payload['product_schema'] ) && ( isset( $data['regular_price'] ) || isset( $data['sku'] ) ) ) {
				$seo_payload['product_schema'] = [
					'name'         => (string) get_the_title( $pid ),
					'description'  => (string) get_post_field( 'post_excerpt', $pid ),
					'sku'          => (string) get_post_meta( $pid, '_sku', true ),
					'price'        => (string) get_post_meta( $pid, '_price', true ),
					'currency'     => function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : (string) ( $data['currency'] ?? 'USD' ),
					'availability' => 'instock' === get_post_meta( $pid, '_stock_status', true ) ? 'InStock' : 'OutOfStock',
				];
			}
			if ( ! empty( $seo_payload ) ) {
				SEO_Write_Engine::update( $pid, $seo_payload );
			}

			if ( function_exists( 'wc_delete_product_transients' ) ) {
				wc_delete_product_transients( $pid );
			}

			return self::format_product( get_post( $pid ) );
		}

		/**
		 * Format a WooCommerce product post into a clean REST dictionary.
		 */
		public static function format_product( ?\WP_Post $post ): array {
			if ( ! $post ) {
				return [];
			}
			$fid = (int) get_post_thumbnail_id( $post->ID );
			$gal = array_values( array_filter( array_map( 'intval', explode( ',', (string) get_post_meta( $post->ID, '_product_image_gallery', true ) ) ) ) );

			return [
				'id'                => $post->ID,
				'name'              => $post->post_title,
				'slug'              => $post->post_name,
				'status'            => $post->post_status,
				'permalink'         => get_permalink( $post->ID ),
				'sku'               => (string) get_post_meta( $post->ID, '_sku', true ),
				'price'             => (string) get_post_meta( $post->ID, '_price', true ),
				'regular_price'     => (string) get_post_meta( $post->ID, '_regular_price', true ),
				'sale_price'        => (string) get_post_meta( $post->ID, '_sale_price', true ),
				'manage_stock'      => 'yes' === get_post_meta( $post->ID, '_manage_stock', true ),
				'stock_quantity'    => (int) get_post_meta( $post->ID, '_stock', true ),
				'stock_status'      => (string) ( get_post_meta( $post->ID, '_stock_status', true ) ?: 'instock' ),
				'weight'            => (string) get_post_meta( $post->ID, '_weight', true ),
				'short_description' => $post->post_excerpt,
				'description'       => $post->post_content,
				'featured_media'    => $fid ?: null,
				'featured_url'      => $fid ? wp_get_attachment_image_url( $fid, 'full' ) : null,
				'gallery_ids'       => $gal,
				'seo'               => SEO_Write_Engine::read( $post->ID ),
			];
		}

		/**
		 * Bulk synchronize inventory & prices by SKU or Product ID (`/wc/products/inventory-sync`).
		 */
		public static function sync_inventory_batch( array $items ): array {
			global $wpdb;
			$updated = 0;
			$failed  = 0;
			$results = [];

			foreach ( array_slice( $items, 0, 100 ) as $idx => $item ) {
				if ( ! is_array( $item ) ) {
					++$failed;
					continue;
				}
				$pid = absint( $item['id'] ?? $item['product_id'] ?? 0 );
				$sku = sanitize_text_field( (string) ( $item['sku'] ?? '' ) );

				if ( $pid <= 0 && '' !== $sku ) {
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
					$pid = (int) $wpdb->get_var(
						$wpdb->prepare(
							"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_sku' AND meta_value = %s LIMIT 1",
							$sku
						)
					);
				}

				if ( $pid <= 0 || ! get_post( $pid ) ) {
					++$failed;
					$results[] = [ 'index' => $idx, 'sku' => $sku, 'success' => false, 'error' => 'Product not found.' ];
					continue;
				}

				if ( isset( $item['stock_quantity'] ) ) {
					$qty = (int) $item['stock_quantity'];
					update_post_meta( $pid, '_manage_stock', 'yes' );
					update_post_meta( $pid, '_stock', $qty );
					update_post_meta( $pid, '_stock_status', $qty > 0 ? 'instock' : 'outofstock' );
				}
				if ( isset( $item['stock_status'] ) ) {
					update_post_meta( $pid, '_stock_status', sanitize_key( (string) $item['stock_status'] ) );
				}
				if ( isset( $item['regular_price'] ) ) {
					$reg = (string) floatval( $item['regular_price'] );
					update_post_meta( $pid, '_regular_price', $reg );
					update_post_meta( $pid, '_price', $reg );
				}
				if ( isset( $item['sale_price'] ) && '' !== (string) $item['sale_price'] ) {
					$sale = (string) floatval( $item['sale_price'] );
					update_post_meta( $pid, '_sale_price', $sale );
					update_post_meta( $pid, '_price', $sale );
				}

				if ( function_exists( 'wc_delete_product_transients' ) ) {
					wc_delete_product_transients( $pid );
				}

				++$updated;
				$results[] = [
					'index'          => $idx,
					'id'             => $pid,
					'sku'            => (string) get_post_meta( $pid, '_sku', true ),
					'stock_quantity' => (int) get_post_meta( $pid, '_stock', true ),
					'price'          => (string) get_post_meta( $pid, '_price', true ),
					'success'        => true,
				];
			}

			return [
				'updated' => $updated,
				'failed'  => $failed,
				'results' => $results,
			];
		}

		/* ── Outgoing WooCommerce Event Hooks ────────────────────────────────── */

		public static function on_order_created( int $order_id ): void {
			if ( class_exists( '\DirectRelay\Webhook_Manager' ) ) {
				Webhook_Manager::fire( 'order.created', $order_id, 'shop_order' );
			}
		}

		public static function on_order_paid( int $order_id ): void {
			if ( class_exists( '\DirectRelay\Webhook_Manager' ) ) {
				Webhook_Manager::fire( 'order.paid', $order_id, 'shop_order' );
			}
		}

		public static function on_low_stock( $product ): void {
			$pid = is_object( $product ) && method_exists( $product, 'get_id' ) ? (int) $product->get_id() : (int) $product;
			if ( $pid > 0 && class_exists( '\DirectRelay\Webhook_Manager' ) ) {
				Webhook_Manager::fire( 'stock.low', $pid, 'product' );
			}
		}

		public static function on_product_updated( int $product_id ): void {
			if ( class_exists( '\DirectRelay\Webhook_Manager' ) ) {
				Webhook_Manager::fire( 'product.updated', $product_id, 'product' );
			}
		}
	}
	}

	/**
	 * ============================================================================
	 * TIER 3 — MODULE 3: Multilingual Publishing & Translation Group Bridge
	 * ============================================================================
	 *
	 * - Connects n8n multi-language workflows to Polylang (`pll_*`), WPML (`wpml_*`),
	 *   TranslatePress, and a universal built-in `hreflang` translation cluster
	 *   (`_directrelay_translations_map` + `_directrelay_lang`).
	 * - Automatically outputs `<link rel="alternate" hreflang="..." href="..." />`
	 *   in `wp_head` when no external multilingual plugin is already rendering them.
	 */
	if ( ! class_exists( '\DirectRelay\Pro\Multilingual_Bridge', false ) ) {
	final class Multilingual_Bridge {

		public const META_LANG  = '_directrelay_lang';
		public const META_GROUP = '_directrelay_translations_map';

		public static function init(): void {
			add_action( 'wp_head', [ __CLASS__, 'render_hreflang_tags' ], 5 );
		}

		/**
		 * Detect active multilingual plugin on the site.
		 */
		public static function active_provider(): string {
			if ( function_exists( 'pll_set_post_language' ) ) {
				return 'polylang';
			}
			if ( defined( 'ICL_SITEPRESS_VERSION' ) || has_action( 'wpml_set_element_language_details' ) ) {
				return 'wpml';
			}
			if ( class_exists( 'TRP_Translate_Press' ) ) {
				return 'translatepress';
			}
			return 'directrelay_native';
		}

		/**
		 * Read language and linked translations map for a given post ID.
		 */
		public static function get_translations( int $post_id ): array {
			$provider = self::active_provider();
			$lang     = (string) get_post_meta( $post_id, self::META_LANG, true );

			if ( 'polylang' === $provider && function_exists( 'pll_get_post_language' ) ) {
				$pll_lang = pll_get_post_language( $post_id );
				if ( is_string( $pll_lang ) && '' !== $pll_lang ) {
					$lang = $pll_lang;
				}
			}

			if ( '' === $lang ) {
				$lang = substr( get_locale(), 0, 2 ) ?: 'en';
			}

			$map = get_post_meta( $post_id, self::META_GROUP, true );
			$map = is_array( $map ) ? $map : [];

			if ( 'polylang' === $provider && function_exists( 'pll_get_post_translations' ) ) {
				$pll_map = pll_get_post_translations( $post_id );
				if ( is_array( $pll_map ) ) {
					$map = array_replace( $map, $pll_map );
				}
			}

			$map[ $lang ] = $post_id;
			$resolved     = [];

			foreach ( $map as $code => $tid ) {
				$tid = (int) $tid;
				$p   = $tid > 0 ? get_post( $tid ) : null;
				if ( ! $p ) {
					continue;
				}
				$resolved[ $code ] = [
					'id'     => $p->ID,
					'lang'   => (string) $code,
					'title'  => $p->post_title,
					'slug'   => $p->post_name,
					'status' => $p->post_status,
					'url'    => get_permalink( $p->ID ),
					'seo'    => SEO_Write_Engine::read( $p->ID ),
				];
			}

			return [
				'provider'       => $provider,
				'source_post_id' => $post_id,
				'source_lang'    => $lang,
				'translations'   => $resolved,
			];
		}

		/**
		 * Create or update one or more translated posts linked to `$source_post_id`.
		 *
		 * @param int   $source_post_id Origin post ID.
		 * @param array $payload        Single translation (`{ lang: "bn", title: "...", content: "..." }`)
		 *                              or batch `{ source_lang?: "en", translations: { "bn": {...}, "es": {...} } }`.
		 * @return array|\WP_Error
		 */
		public static function upsert_translations( int $source_post_id, array $payload ): array|\WP_Error {
			$source_post = get_post( $source_post_id );
			if ( ! $source_post ) {
				return new \WP_Error( 'amp_not_found', __( 'Source post not found.', 'directrelay-pro' ), [ 'status' => 404 ] );
			}

			$source_lang = sanitize_key( (string) ( $payload['source_lang'] ?? get_post_meta( $source_post_id, self::META_LANG, true ) ?: substr( get_locale(), 0, 2 ) ?: 'en' ) );
			update_post_meta( $source_post_id, self::META_LANG, $source_lang );

			// Normalize single vs batch format.
			$batch = [];
			if ( ! empty( $payload['translations'] ) && is_array( $payload['translations'] ) ) {
				$batch = $payload['translations'];
			} elseif ( ! empty( $payload['lang'] ) ) {
				$batch[ (string) $payload['lang'] ] = $payload;
			} else {
				return new \WP_Error( 'amp_invalid', __( 'Provide either "lang" or a "translations" object.', 'directrelay-pro' ), [ 'status' => 400 ] );
			}

			$existing_state = self::get_translations( $source_post_id );
			$group_map      = [ $source_lang => $source_post_id ];
			foreach ( $existing_state['translations'] as $c => $info ) {
				$group_map[ $c ] = (int) $info['id'];
			}

			$created_or_updated = [];
			$source_thumb_id    = (int) get_post_thumbnail_id( $source_post_id );

			foreach ( $batch as $lang_key => $item ) {
				if ( ! is_array( $item ) ) {
					continue;
				}
				$target_lang = sanitize_key( (string) ( $item['lang'] ?? $lang_key ) );
				if ( '' === $target_lang ) {
					continue;
				}

				$item['status'] = $item['status'] ?? $source_post->post_status;
				if ( empty( $item['featured_media'] ) && empty( $item['featured_media_url'] ) && empty( $item['featured_image_url'] ) && $source_thumb_id > 0 ) {
					$item['featured_media'] = $source_thumb_id;
				}

				$existing_tid = (int) ( $group_map[ $target_lang ] ?? 0 );
				if ( $existing_tid > 0 && $existing_tid !== $source_post_id && get_post( $existing_tid ) ) {
					$tid = Post_Manager::update( $existing_tid, $item );
				} else {
					$tid = Post_Manager::create( $item, $source_post->post_type );
				}

				if ( is_wp_error( $tid ) ) {
					return $tid;
				}
				$tid = (int) $tid;

				update_post_meta( $tid, self::META_LANG, $target_lang );

				if ( ! empty( $item['seo'] ) && is_array( $item['seo'] ) ) {
					SEO_Write_Engine::update( $tid, $item['seo'] );
				}

				$group_map[ $target_lang ]          = $tid;
				$created_or_updated[ $target_lang ] = $tid;
			}

			// Sync full translation group across all linked posts in DirectRelay meta, Polylang, and WPML.
			foreach ( $group_map as $lcode => $pid ) {
				update_post_meta( (int) $pid, self::META_LANG, (string) $lcode );
				update_post_meta( (int) $pid, self::META_GROUP, $group_map );
			}

			if ( function_exists( 'pll_set_post_language' ) && function_exists( 'pll_save_post_translations' ) ) {
				foreach ( $group_map as $lcode => $pid ) {
					pll_set_post_language( (int) $pid, (string) $lcode );
				}
				pll_save_post_translations( $group_map );
			}

			if ( has_action( 'wpml_set_element_language_details' ) ) {
				$el_type = 'post_' . $source_post->post_type;
				$trid    = apply_filters( 'wpml_element_trid', null, $source_post_id, $el_type ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
				foreach ( $group_map as $lcode => $pid ) {
					do_action( // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
						'wpml_set_element_language_details',
						[
							'element_id'           => (int) $pid,
							'element_type'         => $el_type,
							'trid'                 => $trid ?: $source_post_id,
							'language_code'        => (string) $lcode,
							'source_language_code' => (int) $pid === $source_post_id ? null : $source_lang,
						]
					);
				}
			}

			return self::get_translations( $source_post_id );
		}

		/**
		 * Output `<link rel="alternate" hreflang="..." href="..." />` tags in `wp_head`
		 * when using DirectRelay's native translation cluster.
		 */
		public static function render_hreflang_tags(): void {
			if ( ! is_singular() || 'directrelay_native' !== self::active_provider() ) {
				return;
			}
			$post = get_queried_object();
			if ( ! ( $post instanceof \WP_Post ) ) {
				return;
			}
			$map = get_post_meta( $post->ID, self::META_GROUP, true );
			if ( ! is_array( $map ) || count( $map ) < 2 ) {
				return;
			}

			foreach ( $map as $lang => $pid ) {
				$url = get_permalink( (int) $pid );
				if ( $url ) {
					printf(
						"<link rel=\"alternate\" hreflang=\"%s\" href=\"%s\" />\n",
						esc_attr( (string) $lang ),
						esc_url( $url )
					);
				}
			}
		}
	}
	}

	/**
	 * ============================================================================
	 * TIER 3 — MODULE 4: Content Refresh, Decay Detector & AI Revision Rollback
	 * ============================================================================
	 *
	 * - Identifies stale/decaying content (`GET /posts/stale?older_than_days=180`)
	 *   for automated n8n Content Refresh pipelines.
	 * - Automatically captures a full Pre-AI Snapshot (`title`, `content`, `excerpt`,
	 *   `seo`) before any REST update modifies an existing post.
	 * - Computes word/heading/SEO diff telemetry and provides 1-click rollback
	 *   (`POST /posts/{id}/rollback`).
	 */
	if ( ! class_exists( '\DirectRelay\Pro\Content_Decay_Versioning', false ) ) {
	final class Content_Decay_Versioning {

		public const SNAPSHOTS_META = '_directrelay_ai_snapshots';

		public static function init(): void {
			add_filter( 'rest_request_before_callbacks', [ __CLASS__, 'auto_snapshot_before_rest_update' ], 12, 3 );
		}

		/**
		 * Query published posts that have not been modified in `$older_than_days` or lack SEO metadata.
		 */
		public static function find_stale_posts( array $args = [] ): array {
			$older_days = max( 1, absint( $args['older_than_days'] ?? 180 ) );
			$max_words  = absint( $args['thin_word_count'] ?? 0 );
			$limit      = max( 1, min( 100, absint( $args['limit'] ?? 25 ) ) );
			$post_type  = sanitize_key( (string) ( $args['post_type'] ?? 'post' ) );

			$cutoff_gmt = gmdate( 'Y-m-d H:i:s', time() - ( $older_days * DAY_IN_SECONDS ) );

			$q = new \WP_Query( [
				'post_type'      => $post_type,
				'post_status'    => 'publish',
				'posts_per_page' => $limit,
				'orderby'        => 'modified',
				'order'          => 'ASC',
				'date_query'     => [
					[
						'column' => 'post_modified_gmt',
						'before' => $cutoff_gmt,
					],
				],
				'no_found_rows'  => false,
			] );

			$stale = [];
			foreach ( $q->posts as $p ) {
				if ( ! ( $p instanceof \WP_Post ) ) {
					continue;
				}
				$word_count = str_word_count( wp_strip_all_tags( $p->post_content ) );
				if ( $max_words > 0 && $word_count > $max_words ) {
					continue;
				}
				$seo      = SEO_Write_Engine::read( $p->ID );
				$mod_ts   = strtotime( $p->post_modified_gmt . ' UTC' ) ?: time();
				$age_days = (int) floor( ( time() - $mod_ts ) / DAY_IN_SECONDS );

				$stale[] = [
					'id'               => $p->ID,
					'title'            => $p->post_title,
					'slug'             => $p->post_name,
					'url'              => get_permalink( $p->ID ),
					'date_gmt'         => $p->post_date_gmt,
					'modified_gmt'     => $p->post_modified_gmt,
					'days_since_edit'  => $age_days,
					'word_count'       => $word_count,
					'focus_keyword'    => $seo['focus_keyword'] ?? '',
					'seo_score'        => $seo['seo_score'] ?? 0,
					'missing_seo_desc' => empty( $seo['description'] ),
				];
			}

			return [
				'older_than_days' => $older_days,
				'cutoff_gmt'      => $cutoff_gmt,
				'total_found'     => (int) $q->found_posts,
				'posts'           => $stale,
			];
		}

		/**
		 * Capture a Pre-AI Snapshot of a post's title, content, excerpt, and SEO metadata.
		 */
		public static function capture_pre_ai_snapshot( int $post_id, string $reason = 'ai_update' ): ?array {
			$post = get_post( $post_id );
			if ( ! $post ) {
				return null;
			}

			$snapshots = get_post_meta( $post_id, self::SNAPSHOTS_META, true );
			$snapshots = is_array( $snapshots ) ? $snapshots : [];

			$snap_id  = 'snap_' . gmdate( 'Ymd_His' ) . '_' . substr( wp_generate_uuid4(), 0, 6 );
			$snapshot = [
				'snapshot_id'  => $snap_id,
				'reason'       => sanitize_key( $reason ),
				'captured_at'  => current_time( 'mysql', true ),
				'title'        => $post->post_title,
				'content'      => $post->post_content,
				'excerpt'      => $post->post_excerpt,
				'status'       => $post->post_status,
				'word_count'   => str_word_count( wp_strip_all_tags( $post->post_content ) ),
				'seo'          => SEO_Write_Engine::read( $post_id ),
			];

			array_unshift( $snapshots, $snapshot );
			// Retain the 10 most recent snapshots per post.
			$snapshots = array_slice( $snapshots, 0, 10 );
			update_post_meta( $post_id, self::SNAPSHOTS_META, $snapshots );

			return $snapshot;
		}

		/**
		 * List all saved Pre-AI Snapshots for a post.
		 */
		public static function list_snapshots( int $post_id ): array {
			$snapshots = get_post_meta( $post_id, self::SNAPSHOTS_META, true );
			if ( ! is_array( $snapshots ) ) {
				return [];
			}
			return array_map( static function ( array $s ): array {
				return [
					'snapshot_id'   => $s['snapshot_id'] ?? '',
					'reason'        => $s['reason'] ?? 'ai_update',
					'captured_at'   => $s['captured_at'] ?? '',
					'title'         => $s['title'] ?? '',
					'word_count'    => (int) ( $s['word_count'] ?? 0 ),
					'focus_keyword' => $s['seo']['focus_keyword'] ?? '',
				];
			}, $snapshots );
		}

		/**
		 * Roll back a post to a specific Pre-AI Snapshot (or the most recent snapshot if `$snapshot_id` is empty).
		 */
		public static function rollback( int $post_id, string $snapshot_id = '' ): array|\WP_Error {
			$post = get_post( $post_id );
			if ( ! $post ) {
				return new \WP_Error( 'amp_not_found', __( 'Post not found.', 'directrelay-pro' ), [ 'status' => 404 ] );
			}

			$snapshots = get_post_meta( $post_id, self::SNAPSHOTS_META, true );
			if ( ! is_array( $snapshots ) || empty( $snapshots ) ) {
				return new \WP_Error(
					'directrelay_pro_no_snapshots',
					__( 'No pre-AI snapshots found for this post.', 'directrelay-pro' ),
					[ 'status' => 404 ]
				);
			}

			$target = null;
			if ( '' === $snapshot_id ) {
				$target = $snapshots[0];
			} else {
				foreach ( $snapshots as $s ) {
					if ( ( $s['snapshot_id'] ?? '' ) === $snapshot_id ) {
						$target = $s;
						break;
					}
				}
			}

			if ( ! $target ) {
				return new \WP_Error( 'amp_not_found', __( 'Requested snapshot_id was not found.', 'directrelay-pro' ), [ 'status' => 404 ] );
			}

			$upd = wp_update_post(
				[
					'ID'           => $post_id,
					'post_title'   => wp_slash( (string) $target['title'] ),
					'post_content' => wp_slash( (string) $target['content'] ),
					'post_excerpt' => wp_slash( (string) $target['excerpt'] ),
				],
				true
			);

			if ( is_wp_error( $upd ) ) {
				return $upd;
			}

			if ( ! empty( $target['seo'] ) && is_array( $target['seo'] ) ) {
				SEO_Write_Engine::update( $post_id, $target['seo'] );
			}

			return [
				'rolled_back' => true,
				'post_id'     => $post_id,
				'snapshot_id' => $target['snapshot_id'],
				'captured_at' => $target['captured_at'],
				'post'        => Post_Manager::format( get_post( $post_id ) ),
				'seo'         => SEO_Write_Engine::read( $post_id ),
			];
		}

		/**
		 * Perform an AI Content Refresh with automatic Pre-AI Snapshot and structural diff calculation.
		 */
		public static function refresh_post( int $post_id, array $payload ): array|\WP_Error {
			$post = get_post( $post_id );
			if ( ! $post ) {
				return new \WP_Error( 'amp_not_found', __( 'Post not found.', 'directrelay-pro' ), [ 'status' => 404 ] );
			}

			$snap       = self::capture_pre_ai_snapshot( $post_id, 'content_refresh' );
			$old_words  = $snap ? (int) $snap['word_count'] : 0;
			$old_title  = $post->post_title;

			$upd = Post_Manager::update( $post_id, $payload );
			if ( is_wp_error( $upd ) ) {
				return $upd;
			}

			$seo_updated = [];
			if ( ! empty( $payload['seo'] ) && is_array( $payload['seo'] ) ) {
				$seo_res = SEO_Write_Engine::update( $post_id, $payload['seo'] );
				if ( ! is_wp_error( $seo_res ) ) {
					$seo_updated = $seo_res['updated_fields'] ?? [];
				}
			}

			$refreshed  = get_post( $post_id );
			$new_words  = $refreshed ? str_word_count( wp_strip_all_tags( $refreshed->post_content ) ) : 0;

			return [
				'refreshed'   => true,
				'post_id'     => $post_id,
				'snapshot_id' => $snap['snapshot_id'] ?? null,
				'diff'        => [
					'title_changed'      => $refreshed && $refreshed->post_title !== $old_title,
					'words_before'       => $old_words,
					'words_after'        => $new_words,
					'word_delta'         => $new_words - $old_words,
					'seo_updated_fields' => $seo_updated,
				],
				'post'        => Post_Manager::format( $refreshed ),
				'seo'         => SEO_Write_Engine::read( $post_id ),
			];
		}

		/**
		 * Automatically capture a Pre-AI Snapshot before `PUT/PATCH /posts/{id}` or `/pages/{id}`.
		 */
		public static function auto_snapshot_before_rest_update( $response, array $handler, \WP_REST_Request $request ) {
			if ( is_wp_error( $response ) || ! in_array( $request->get_method(), [ 'PUT', 'PATCH' ], true ) ) {
				return $response;
			}
			if ( preg_match( '#^/directrelay/v1/(?:posts|pages)/(\d+)$#', $request->get_route(), $m ) ) {
				self::capture_pre_ai_snapshot( (int) $m[1], 'rest_update' );
			}
			return $response;
		}
	}
	}
}

namespace DirectRelay\Pro\REST {

	defined( 'ABSPATH' ) || exit;

	use DirectRelay\Agent_Profiles;
	use DirectRelay\Pro\Content_Decay_Versioning;
	use DirectRelay\Pro\CPT_Fields_Engine;
	use DirectRelay\Pro\Multilingual_Bridge;
	use DirectRelay\Pro\WooCommerce_Bridge;

	/**
	 * Tier 3 — Module 1 REST Controller: Universal Custom Post Type & Custom Taxonomy CRUD
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\CPT_Controller', false ) ) {
	final class CPT_Controller extends Pro_Base_Controller {

		public static function register(): void {
			// 1. Universal Custom Post Type Collection (`GET|POST /cpt/{post_type}`)
			register_rest_route(
				self::NS,
				'/cpt/(?P<post_type>[a-z0-9_-]+)',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'index' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:read' ),
						'args'                => self::pagination_args(),
					],
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'create' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:write' ),
					],
				]
			);

			// 2. Universal Custom Post Type Single Item (`GET|PUT|PATCH|DELETE /cpt/{post_type}/{id}`)
			register_rest_route(
				self::NS,
				'/cpt/(?P<post_type>[a-z0-9_-]+)/(?P<id>\\d+)',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'show' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:read' ),
					],
					[
						'methods'             => \WP_REST_Server::EDITABLE,
						'callback'            => [ self::class, 'update' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:write' ),
					],
					[
						'methods'             => \WP_REST_Server::DELETABLE,
						'callback'            => [ self::class, 'destroy' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:delete' ),
					],
				]
			);

			// 3. Universal Custom Taxonomy CRUD (`GET|POST /taxonomies/{taxonomy}`)
			register_rest_route(
				self::NS,
				'/taxonomies/(?P<taxonomy>[a-z0-9_-]+)',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'list_terms' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'taxonomy:read' ),
					],
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'create_term' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'taxonomy:write' ),
					],
				]
			);
		}

		public static function index( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$pt = sanitize_key( (string) $req->get_param( 'post_type' ) );
			if ( ! CPT_Fields_Engine::is_allowed_post_type( $pt ) ) {
				return self::fail( $req, new \WP_Error( 'amp_invalid', __( 'Invalid or non-public post type.', 'directrelay-pro' ), [ 'status' => 400 ] ), 'list_cpt' );
			}

			$q_args = [
				'post_type'      => $pt,
				'post_status'    => $req->get_param( 'status' ) ? sanitize_key( (string) $req->get_param( 'status' ) ) : [ 'publish', 'draft', 'pending', 'private' ],
				'posts_per_page' => (int) ( $req->get_param( 'per_page' ) ?: 20 ),
				'paged'          => (int) ( $req->get_param( 'page' ) ?: 1 ),
				'orderby'        => sanitize_key( (string) ( $req->get_param( 'orderby' ) ?: 'date' ) ),
				'order'          => 'ASC' === strtoupper( (string) $req->get_param( 'order' ) ) ? 'ASC' : 'DESC',
				'no_found_rows'  => false,
			];
			if ( $req->get_param( 'search' ) ) {
				$q_args['s'] = sanitize_text_field( (string) $req->get_param( 'search' ) );
			}
			if ( $req->get_param( 'meta_key' ) ) {
				$q_args['meta_key'] = sanitize_text_field( (string) $req->get_param( 'meta_key' ) );
				if ( null !== $req->get_param( 'meta_value' ) ) {
					$q_args['meta_value'] = sanitize_text_field( (string) $req->get_param( 'meta_value' ) );
				}
			}

			$q     = new \WP_Query( $q_args );
			$items = array_map( static fn( \WP_Post $p ): array => CPT_Fields_Engine::format_cpt_item( $p, false ), $q->posts );

			return self::ok(
				$req,
				[
					'post_type'   => $pt,
					'items'       => $items,
					'total'       => (int) $q->found_posts,
					'total_pages' => (int) $q->max_num_pages,
				],
				200,
				'list_cpt_' . $pt
			);
		}

		public static function create( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$pt   = sanitize_key( (string) $req->get_param( 'post_type' ) );
			$body = $req->get_json_params() ?: [];
			$key  = (array) $req->get_param( '_amp_key' );

			if ( ! Agent_Profiles::is_status_allowed( $key, (string) ( $body['status'] ?? 'draft' ) ) ) {
				return self::fail( $req, new \WP_Error( 'amp_agent_forbidden', __( 'This agent role cannot publish directly.', 'directrelay-pro' ), [ 'status' => 403 ] ), 'create_cpt' );
			}

			if ( ! empty( $body['content'] ) && class_exists( '\DirectRelay\Guardrails_Manager' ) ) {
				$body['content'] = \DirectRelay\Guardrails_Manager::sanitize_ai_leakage( (string) $body['content'] );
			}
			if ( class_exists( '\DirectRelay\Guardrails_Manager' ) ) {
				$g_val = \DirectRelay\Guardrails_Manager::validate_content( (string) ( $body['content'] ?? '' ), (string) ( $body['title'] ?? '' ), $key );
				if ( is_wp_error( $g_val ) ) {
					return self::fail( $req, $g_val, 'create_cpt' );
				}
			}

			$item = CPT_Fields_Engine::upsert_cpt_item( $pt, $body, null );
			if ( is_wp_error( $item ) ) {
				return self::fail( $req, $item, 'create_cpt' );
			}

			Agent_Profiles::stamp_post( (int) $item['id'], $key );
			if ( class_exists( '\DirectRelay\Guardrails_Manager' ) ) {
				\DirectRelay\Guardrails_Manager::increment_daily_usage( (int) ( $key['id'] ?? 0 ) );
			}
			return self::ok( $req, [ 'item' => $item ], 201, 'create_cpt_' . $pt, (int) $item['id'], $pt );
		}

		public static function show( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$pt   = sanitize_key( (string) $req->get_param( 'post_type' ) );
			$id   = (int) $req->get_param( 'id' );
			$post = get_post( $id );
			if ( ! $post || $post->post_type !== $pt ) {
				return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Item not found.', 'directrelay-pro' ), [ 'status' => 404 ] ), 'get_cpt' );
			}
			return self::ok( $req, [ 'item' => CPT_Fields_Engine::format_cpt_item( $post, true ) ], 200, 'get_cpt_' . $pt, $id, $pt );
		}

		public static function update( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$pt   = sanitize_key( (string) $req->get_param( 'post_type' ) );
			$id   = (int) $req->get_param( 'id' );
			$body = $req->get_json_params() ?: [];
			$key  = (array) $req->get_param( '_amp_key' );

			$own = Agent_Profiles::assert_owns( $key, $id );
			if ( is_wp_error( $own ) ) {
				return self::fail( $req, $own, 'update_cpt' );
			}

			$item = CPT_Fields_Engine::upsert_cpt_item( $pt, $body, $id );
			if ( is_wp_error( $item ) ) {
				return self::fail( $req, $item, 'update_cpt' );
			}

			return self::ok( $req, [ 'item' => $item ], 200, 'update_cpt_' . $pt, $id, $pt );
		}

		public static function destroy( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$pt   = sanitize_key( (string) $req->get_param( 'post_type' ) );
			$id   = (int) $req->get_param( 'id' );
			$post = get_post( $id );
			if ( ! $post || $post->post_type !== $pt ) {
				return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Item not found.', 'directrelay-pro' ), [ 'status' => 404 ] ), 'delete_cpt' );
			}
			$own = Agent_Profiles::assert_owns( (array) $req->get_param( '_amp_key' ), $id );
			if ( is_wp_error( $own ) ) {
				return self::fail( $req, $own, 'delete_cpt' );
			}
			$deleted = wp_delete_post( $id, (bool) $req->get_param( 'force' ) );
			return self::ok( $req, [ 'deleted' => (bool) $deleted, 'id' => $id ], 200, 'delete_cpt_' . $pt, $id, $pt );
		}

		public static function list_terms( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$tax = sanitize_key( (string) $req->get_param( 'taxonomy' ) );
			if ( ! taxonomy_exists( $tax ) ) {
				return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Taxonomy does not exist.', 'directrelay-pro' ), [ 'status' => 404 ] ), 'list_taxonomy_terms' );
			}
			$terms = get_terms( [ 'taxonomy' => $tax, 'hide_empty' => false ] );
			$data  = is_wp_error( $terms ) ? [] : array_map(
				static fn( \WP_Term $t ): array => [
					'id'          => $t->term_id,
					'name'        => $t->name,
					'slug'        => $t->slug,
					'description' => $t->description,
					'parent'      => $t->parent,
					'count'       => $t->count,
				],
				$terms
			);
			return self::ok( $req, [ 'taxonomy' => $tax, 'terms' => $data, 'total' => count( $data ) ], 200, 'list_taxonomy_terms' );
		}

		public static function create_term( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$tax  = sanitize_key( (string) $req->get_param( 'taxonomy' ) );
			if ( ! taxonomy_exists( $tax ) ) {
				return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Taxonomy does not exist.', 'directrelay-pro' ), [ 'status' => 404 ] ), 'create_taxonomy_term' );
			}
			$body = $req->get_json_params() ?: [];
			$name = sanitize_text_field( (string) ( $body['name'] ?? '' ) );
			if ( '' === $name ) {
				return self::fail( $req, new \WP_Error( 'amp_invalid', __( 'Term name is required.', 'directrelay-pro' ), [ 'status' => 400 ] ), 'create_taxonomy_term' );
			}
			$ins = wp_insert_term(
				$name,
				$tax,
				[
					'slug'        => sanitize_title( (string) ( $body['slug'] ?? $name ) ),
					'description' => sanitize_textarea_field( (string) ( $body['description'] ?? '' ) ),
					'parent'      => absint( $body['parent'] ?? 0 ),
				]
			);
			if ( is_wp_error( $ins ) ) {
				if ( isset( $ins->error_data['term_exists'] ) ) {
					$tid = (int) $ins->error_data['term_exists'];
				} else {
					return self::fail( $req, $ins, 'create_taxonomy_term' );
				}
			} else {
				$tid = (int) $ins['term_id'];
			}
			$t = get_term( $tid, $tax );
			return self::ok(
				$req,
				[
					'term' => [
						'id'       => $t->term_id,
						'taxonomy' => $tax,
						'name'     => $t->name,
						'slug'     => $t->slug,
						'parent'   => $t->parent,
					],
				],
				201,
				'create_taxonomy_term',
				$tid,
				$tax
			);
		}
	}
	}

	/**
	 * Tier 3 — Module 2 REST Controller: WooCommerce Products, Inventory Sync & Orders
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\WooCommerce_Controller', false ) ) {
	final class WooCommerce_Controller extends Pro_Base_Controller {

		public static function register(): void {
			register_rest_route(
				self::NS,
				'/wc/products',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'list_products' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:read' ),
						'args'                => self::pagination_args(),
					],
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'create_product' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/wc/products/(?P<id>\\d+)',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'show_product' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:read' ),
					],
					[
						'methods'             => \WP_REST_Server::EDITABLE,
						'callback'            => [ self::class, 'update_product' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:write' ),
					],
					[
						'methods'             => \WP_REST_Server::DELETABLE,
						'callback'            => [ self::class, 'delete_product' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:delete' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/wc/products/inventory-sync',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'inventory_sync' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'bulk:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/wc/orders',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'list_orders' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:read' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/wc/orders/(?P<id>\\d+)/status',
				[
					[
						'methods'             => \WP_REST_Server::EDITABLE,
						'callback'            => [ self::class, 'update_order_status' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:write' ),
					],
				]
			);
		}

		public static function list_products( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$q = new \WP_Query( [
				'post_type'      => 'product',
				'post_status'    => [ 'publish', 'draft', 'pending', 'private' ],
				'posts_per_page' => (int) ( $req->get_param( 'per_page' ) ?: 20 ),
				'paged'          => (int) ( $req->get_param( 'page' ) ?: 1 ),
				's'              => $req->get_param( 'search' ) ? sanitize_text_field( (string) $req->get_param( 'search' ) ) : null,
				'no_found_rows'  => false,
			] );
			return self::ok(
				$req,
				[
					'woocommerce_active' => WooCommerce_Bridge::is_active(),
					'products'           => array_map( [ WooCommerce_Bridge::class, 'format_product' ], $q->posts ),
					'total'              => (int) $q->found_posts,
				],
				200,
				'wc_list_products'
			);
		}

		public static function create_product( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body = $req->get_json_params() ?: [];
			$res  = WooCommerce_Bridge::upsert_product( $body, null );
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'wc_create_product' );
			}
			Agent_Profiles::stamp_post( (int) $res['id'], (array) $req->get_param( '_amp_key' ) );
			return self::ok( $req, [ 'product' => $res ], 201, 'wc_create_product', (int) $res['id'], 'product' );
		}

		public static function show_product( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id   = (int) $req->get_param( 'id' );
			$post = get_post( $id );
			if ( ! $post || 'product' !== $post->post_type ) {
				return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Product not found.', 'directrelay-pro' ), [ 'status' => 404 ] ), 'wc_get_product' );
			}
			return self::ok( $req, [ 'product' => WooCommerce_Bridge::format_product( $post ) ], 200, 'wc_get_product', $id, 'product' );
		}

		public static function update_product( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id   = (int) $req->get_param( 'id' );
			$body = $req->get_json_params() ?: [];
			$res  = WooCommerce_Bridge::upsert_product( $body, $id );
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'wc_update_product' );
			}
			return self::ok( $req, [ 'product' => $res ], 200, 'wc_update_product', $id, 'product' );
		}

		public static function delete_product( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id      = (int) $req->get_param( 'id' );
			$deleted = wp_delete_post( $id, (bool) $req->get_param( 'force' ) );
			return self::ok( $req, [ 'deleted' => (bool) $deleted, 'id' => $id ], 200, 'wc_delete_product', $id, 'product' );
		}

		public static function inventory_sync( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body  = $req->get_json_params() ?: [];
			$items = isset( $body['items'] ) && is_array( $body['items'] ) ? $body['items'] : [];
			if ( empty( $items ) ) {
				return self::fail( $req, new \WP_Error( 'amp_invalid', __( 'Non-empty "items" array required.', 'directrelay-pro' ), [ 'status' => 400 ] ), 'wc_inventory_sync' );
			}
			$res = WooCommerce_Bridge::sync_inventory_batch( $items );
			return self::ok( $req, $res, 200, 'wc_inventory_sync' );
		}

		public static function list_orders( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$limit = max( 1, min( 100, (int) ( $req->get_param( 'per_page' ) ?: 20 ) ) );
			if ( function_exists( 'wc_get_orders' ) ) {
				$wc_orders = wc_get_orders( [ 'limit' => $limit, 'orderby' => 'date', 'order' => 'DESC' ] );
				$orders    = [];
				foreach ( $wc_orders as $o ) {
					if ( ! is_object( $o ) || ! method_exists( $o, 'get_id' ) ) {
						continue;
					}
					$orders[] = [
						'id'            => $o->get_id(),
						'status'        => $o->get_status(),
						'total'         => $o->get_total(),
						'currency'      => $o->get_currency(),
						'billing_email' => method_exists( $o, 'get_billing_email' ) ? $o->get_billing_email() : '',
						'date_created'  => $o->get_date_created() ? $o->get_date_created()->date( 'c' ) : '',
					];
				}
				return self::ok( $req, [ 'orders' => $orders, 'total' => count( $orders ) ], 200, 'wc_list_orders' );
			}

			return self::ok( $req, [ 'orders' => [], 'total' => 0, 'woocommerce_active' => false ], 200, 'wc_list_orders' );
		}

		public static function update_order_status( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id     = (int) $req->get_param( 'id' );
			$body   = $req->get_json_params() ?: [];
			$status = sanitize_key( (string) ( $body['status'] ?? '' ) );
			$note   = sanitize_textarea_field( (string) ( $body['order_note'] ?? '' ) );

			if ( function_exists( 'wc_get_order' ) ) {
				$order = wc_get_order( $id );
				if ( ! $order ) {
					return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Order not found.', 'directrelay-pro' ), [ 'status' => 404 ] ), 'wc_update_order' );
				}
				if ( '' !== $status ) {
					$order->update_status( $status, $note );
				} elseif ( '' !== $note ) {
					$order->add_order_note( $note, ! empty( $body['customer_note'] ) ? 1 : 0 );
				}
				return self::ok( $req, [ 'id' => $id, 'status' => $order->get_status() ], 200, 'wc_update_order', $id, 'shop_order' );
			}

			return self::fail( $req, new \WP_Error( 'directrelay_pro_wc_inactive', __( 'WooCommerce is not active on this site.', 'directrelay-pro' ), [ 'status' => 400 ] ), 'wc_update_order' );
		}
	}
	}

	/**
	 * Tier 3 — Module 3 REST Controller: Multilingual Publishing & Translation Group Endpoints
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\Multilingual_Controller', false ) ) {
	final class Multilingual_Controller extends Pro_Base_Controller {

		public static function register(): void {
			register_rest_route(
				self::NS,
				'/posts/(?P<id>\\d+)/translations',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'show' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:read' ),
					],
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'upsert' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:write' ),
					],
				]
			);
		}

		public static function show( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id = (int) $req->get_param( 'id' );
			if ( ! get_post( $id ) ) {
				return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Post not found.', 'directrelay-pro' ), [ 'status' => 404 ] ), 'get_translations' );
			}
			return self::ok( $req, Multilingual_Bridge::get_translations( $id ), 200, 'get_translations', $id, 'post' );
		}

		public static function upsert( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id   = (int) $req->get_param( 'id' );
			$body = $req->get_json_params() ?: [];
			$res  = Multilingual_Bridge::upsert_translations( $id, $body );
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'upsert_translations' );
			}
			return self::ok( $req, $res, 201, 'upsert_translations', $id, 'post' );
		}
	}
	}

	/**
	 * Tier 3 — Module 4 REST Controller: Content Decay Detector, AI Refresh & Snapshot Rollback
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\Content_Decay_Controller', false ) ) {
	final class Content_Decay_Controller extends Pro_Base_Controller {

		public static function register(): void {
			register_rest_route(
				self::NS,
				'/posts/stale',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'stale' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:read' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/posts/(?P<id>\\d+)/refresh',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'refresh' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/posts/(?P<id>\\d+)/revisions',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'revisions' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:read' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/posts/(?P<id>\\d+)/rollback',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'rollback' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'posts:write' ),
					],
				]
			);
		}

		public static function stale( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			return self::ok( $req, Content_Decay_Versioning::find_stale_posts( $req->get_params() ), 200, 'find_stale_posts' );
		}

		public static function refresh( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id   = (int) $req->get_param( 'id' );
			$body = $req->get_json_params() ?: [];
			$own  = Agent_Profiles::assert_owns( (array) $req->get_param( '_amp_key' ), $id );
			if ( is_wp_error( $own ) ) {
				return self::fail( $req, $own, 'refresh_post' );
			}
			$res = Content_Decay_Versioning::refresh_post( $id, $body );
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'refresh_post' );
			}
			return self::ok( $req, $res, 200, 'refresh_post', $id, 'post' );
		}

		public static function revisions( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id    = (int) $req->get_param( 'id' );
			$snaps = Content_Decay_Versioning::list_snapshots( $id );
			return self::ok( $req, [ 'post_id' => $id, 'snapshots' => $snaps, 'total' => count( $snaps ) ], 200, 'list_ai_snapshots', $id, 'post' );
		}

		public static function rollback( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id      = (int) $req->get_param( 'id' );
			$body    = $req->get_json_params() ?: [];
			$snap_id = sanitize_text_field( (string) ( $body['snapshot_id'] ?? $req->get_param( 'snapshot_id' ) ?? '' ) );
			$own     = Agent_Profiles::assert_owns( (array) $req->get_param( '_amp_key' ), $id );
			if ( is_wp_error( $own ) ) {
				return self::fail( $req, $own, 'rollback_post' );
			}
			$res = Content_Decay_Versioning::rollback( $id, $snap_id );
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'rollback_post' );
			}
			return self::ok( $req, $res, 200, 'rollback_post', $id, 'post' );
		}
	}
	}
}

namespace DirectRelay\Pro {

	defined( 'ABSPATH' ) || exit;

	use DirectRelay\Activity_Logger;
	use DirectRelay\Api_Auth;
	use DirectRelay\Brute_Force;
	use DirectRelay\Cron_Health;
	use DirectRelay\Guardrails_Manager;
	use DirectRelay\Post_Manager;
	use DirectRelay\Webhook_Manager;

	/**
	 * ============================================================================
	 * TIER 4 — MODULE 1: Multi-Site & Multi-Domain Fleet Command Engine
	 * ============================================================================
	 *
	 * - Restores & expands `/fleet/health` and `/fleet/keys/provision` across both
	 *   WordPress Multisite networks (`switch_to_blog`) and standalone remote
	 *   WordPress domains registered in `directrelay_pro_fleet_sites`.
	 * - Broadcasts AI Guardrails, Internal Link Silo Rules, and DirectRelay
	 *   Settings across all connected sites (`POST /fleet/sync`).
	 */
	if ( ! class_exists( '\DirectRelay\Pro\Fleet_Command_Engine', false ) ) {
	final class Fleet_Command_Engine {

		public const SITES_OPTION = 'directrelay_pro_fleet_sites';

		public static function init(): void {
			// Register Fleet & Governance submenu via `directrelay_ext_register_admin`.
			add_action( 'directrelay_ext_register_admin', [ __CLASS__, 'register_fleet_submenu' ], 20 );
		}

		public static function register_fleet_submenu(): void {
			$cap = class_exists( '\DirectRelay\Admin\Menu' ) ? \DirectRelay\Admin\Menu::get_cap() : 'manage_options';
			add_submenu_page(
				'directrelay-cm',
				esc_html__( 'Fleet & Governance', 'directrelay-pro' ),
				esc_html__( 'Fleet & Alerts', 'directrelay-pro' ),
				$cap,
				'directrelay-fleet',
				[ __CLASS__, 'render_fleet_admin_page' ]
			);
		}

		/**
		 * Return all registered remote fleet sites (with secrets masked).
		 */
		public static function list_remote_sites( bool $include_raw_key = false ): array {
			$sites = get_option( self::SITES_OPTION, [] );
			if ( ! is_array( $sites ) ) {
				return [];
			}
			$out = [];
			foreach ( $sites as $site ) {
				if ( ! is_array( $site ) || empty( $site['site_url'] ) ) {
					continue;
				}
				$entry = [
					'id'         => (string) ( $site['id'] ?? '' ),
					'label'      => (string) ( $site['label'] ?? $site['site_url'] ),
					'site_url'   => (string) $site['site_url'],
					'api_base'   => rtrim( (string) $site['site_url'], '/' ) . '/wp-json/directrelay/v1',
					'group'      => (string) ( $site['group'] ?? 'default' ),
					'created_at' => (string) ( $site['created_at'] ?? '' ),
				];
				if ( $include_raw_key && ! empty( $site['api_key_enc'] ) ) {
					$entry['api_key'] = class_exists( '\DirectRelay\Webhook_Manager' )
						? Webhook_Manager::decrypt_secret( (string) $site['api_key_enc'] )
						: '';
				}
				$out[] = $entry;
			}
			return $out;
		}

		/**
		 * Register or update a remote WordPress site in the Fleet directory.
		 */
		public static function add_remote_site( array $data ): array|\WP_Error {
			$site_url = esc_url_raw( rtrim( trim( (string) ( $data['site_url'] ?? '' ) ), '/' ), [ 'http', 'https' ] );
			$api_key  = trim( (string) ( $data['api_key'] ?? '' ) );
			$label    = sanitize_text_field( (string) ( $data['label'] ?? wp_parse_url( $site_url, PHP_URL_HOST ) ) );
			$group    = sanitize_key( (string) ( $data['group'] ?? 'default' ) );

			if ( '' === $site_url || ! filter_var( $site_url, FILTER_VALIDATE_URL ) ) {
				return new \WP_Error( 'amp_invalid', __( 'A valid "site_url" is required.', 'directrelay-pro' ), [ 'status' => 400 ] );
			}
			if ( ! Api_Auth::is_url_safe( $site_url ) ) {
				return new \WP_Error( 'amp_ssrf_blocked', __( 'Fleet site_url must be a public HTTP/HTTPS endpoint.', 'directrelay-pro' ), [ 'status' => 400 ] );
			}

			$sites = get_option( self::SITES_OPTION, [] );
			$sites = is_array( $sites ) ? $sites : [];
			$id    = ! empty( $data['id'] ) ? sanitize_key( (string) $data['id'] ) : 'site_' . substr( md5( strtolower( $site_url ) ), 0, 10 );

			$enc_key = '';
			if ( '' !== $api_key ) {
				$enc_key = class_exists( '\DirectRelay\Webhook_Manager' )
					? Webhook_Manager::encrypt_secret( $api_key )
					: '';
			}

			$record = [
				'id'          => $id,
				'label'       => $label,
				'site_url'    => $site_url,
				'group'       => $group,
				'api_key_enc' => $enc_key,
				'created_at'  => current_time( 'mysql', true ),
			];

			$updated = false;
			foreach ( $sites as &$s ) {
				if ( ( $s['id'] ?? '' ) === $id || ( $s['site_url'] ?? '' ) === $site_url ) {
					if ( '' === $enc_key && ! empty( $s['api_key_enc'] ) ) {
						$record['api_key_enc'] = $s['api_key_enc'];
					}
					$s       = $record;
					$updated = true;
					break;
				}
			}
			unset( $s );

			if ( ! $updated ) {
				$sites[] = $record;
			}

			update_option( self::SITES_OPTION, array_values( $sites ), false );
			unset( $record['api_key_enc'] );
			return $record;
		}

		/**
		 * Remove a remote fleet site by ID.
		 */
		public static function remove_remote_site( string $id ): bool {
			$sites    = get_option( self::SITES_OPTION, [] );
			$sites    = is_array( $sites ) ? $sites : [];
			$filtered = array_values( array_filter( $sites, static fn( array $s ): bool => ( $s['id'] ?? '' ) !== $id ) );
			if ( count( $filtered ) === count( $sites ) ) {
				return false;
			}
			update_option( self::SITES_OPTION, $filtered, false );
			return true;
		}

		/**
		 * Collect comprehensive Fleet Health across local site, WP Multisite network blogs,
		 * and registered remote domains (`GET /fleet/health`).
		 */
		public static function fleet_health( bool $ping_remote = true ): array {
			$nodes = [];

			// 1. Local Hub Site
			$summary = Activity_Logger::summary();
			$cron    = Cron_Health::status();
			$nodes[] = [
				'id'              => 'local_hub',
				'role'            => 'hub',
				'label'           => get_bloginfo( 'name' ),
				'site_url'        => get_site_url(),
				'status'          => 'healthy',
				'plugin_version'  => DIRECTRELAY_VERSION,
				'pro_version'     => DIRECTRELAY_PRO_VERSION,
				'wordpress'       => get_bloginfo( 'version' ),
				'php'             => PHP_VERSION,
				'seo_providers'   => SEO_Write_Engine::detect_providers()['active'],
				'cron_status'     => $cron['status'],
				'requests_today'  => (int) ( $summary['requests_today'] ?? 0 ),
				'errors_24h'      => (int) ( $summary['errors_24h'] ?? 0 ),
				'avg_response_ms' => (float) ( $summary['avg_response_ms'] ?? 0 ),
				'active_keys'     => Api_Auth::count_active_keys(),
				'blocked_ips'     => count( Brute_Force::list_blocks() ),
			];

			// 2. WordPress Multisite Network Sub-Sites (if running on Multisite with Pro active)
			if ( function_exists( 'is_multisite' ) && is_multisite() && function_exists( 'get_sites' ) ) {
				$ms_sites = get_sites( [ 'number' => 50 ] );
				$cur_blog = get_current_blog_id();
				foreach ( $ms_sites as $ms ) {
					$bid = (int) $ms->blog_id;
					if ( $bid === $cur_blog ) {
						continue;
					}
					switch_to_blog( $bid );
					$b_sum   = Activity_Logger::summary();
					$nodes[] = [
						'id'              => 'blog_' . $bid,
						'role'            => 'multisite_subsite',
						'blog_id'         => $bid,
						'label'           => get_bloginfo( 'name' ),
						'site_url'        => get_site_url(),
						'status'          => 'healthy',
						'requests_today'  => (int) ( $b_sum['requests_today'] ?? 0 ),
						'errors_24h'      => (int) ( $b_sum['errors_24h'] ?? 0 ),
						'avg_response_ms' => (float) ( $b_sum['avg_response_ms'] ?? 0 ),
					];
					restore_current_blog();
				}
			}

			// 3. Registered Remote Standalone WordPress Domains
			$remotes = self::list_remote_sites( true );
			foreach ( $remotes as $rem ) {
				$node = [
					'id'       => $rem['id'],
					'role'     => 'remote_domain',
					'label'    => $rem['label'],
					'site_url' => $rem['site_url'],
					'group'    => $rem['group'],
					'status'   => 'configured',
				];

				if ( $ping_remote ) {
					$t0       = microtime( true );
					$endpoint = $rem['api_base'] . ( ! empty( $rem['api_key'] ) ? '/status' : '/ping' );
					$headers  = ! empty( $rem['api_key'] ) ? [ 'Authorization' => 'Bearer ' . $rem['api_key'] ] : [];
					$resp     = wp_safe_remote_get(
						$endpoint,
						[
							'timeout'   => 5,
							'headers'   => $headers,
							'sslverify' => true,
						]
					);
					$latency  = (int) round( ( microtime( true ) - $t0 ) * 1000 );

					if ( is_wp_error( $resp ) ) {
						$node['status']     = 'unreachable';
						$node['error']      = $resp->get_error_message();
						$node['latency_ms'] = $latency;
					} else {
						$code               = (int) wp_remote_retrieve_response_code( $resp );
						$node['http_code']  = $code;
						$node['latency_ms'] = $latency;
						$node['status']     = ( $code >= 200 && $code < 300 ) ? 'healthy' : 'degraded';
						$body               = json_decode( (string) wp_remote_retrieve_body( $resp ), true );
						if ( is_array( $body['data'] ?? null ) ) {
							$node['remote_plugin'] = $body['data']['plugin'] ?? null;
						}
					}
				}
				$nodes[] = $node;
			}

			return [
				'total_nodes' => count( $nodes ),
				'healthy'     => count( array_filter( $nodes, static fn( array $n ): bool => 'healthy' === ( $n['status'] ?? '' ) ) ),
				'checked_at'  => current_time( 'c', true ),
				'nodes'       => $nodes,
			];
		}

		/**
		 * Provision API keys across the local site and/or Multisite network blogs (`POST /fleet/keys/provision`).
		 */
		public static function provision_keys( array $args ): array {
			$blog_ids = isset( $args['blog_ids'] ) && is_array( $args['blog_ids'] ) ? array_map( 'intval', $args['blog_ids'] ) : [];
			$key_args = [
				'user_id'            => get_current_user_id() ?: 1,
				'label'              => sanitize_text_field( (string) ( $args['label'] ?? 'Fleet Provisioned Key' ) ),
				'description'        => sanitize_textarea_field( (string) ( $args['description'] ?? 'Provisioned via DirectRelay Pro Fleet Command' ) ),
				'environment'        => sanitize_key( (string) ( $args['environment'] ?? 'production' ) ),
				'agent_role'         => sanitize_key( (string) ( $args['agent_role'] ?? 'full_access' ) ),
				'daily_limit'        => absint( $args['daily_limit'] ?? 0 ),
				'restrict_own_posts' => ! empty( $args['restrict_own_posts'] ),
				'require_approval'   => ! empty( $args['require_approval'] ),
				'scopes'             => isset( $args['scopes'] ) && is_array( $args['scopes'] ) ? $args['scopes'] : [],
			];

			$provisioned = [];

			if ( empty( $blog_ids ) || ! ( function_exists( 'is_multisite' ) && is_multisite() ) ) {
				$created       = Api_Auth::create( $key_args );
				$provisioned[] = array_merge( [ 'site_url' => get_site_url(), 'blog_id' => get_current_blog_id() ], $created );
			} else {
				foreach ( $blog_ids as $bid ) {
					if ( $bid <= 0 ) {
						continue;
					}
					switch_to_blog( $bid );
					$created       = Api_Auth::create( $key_args );
					$provisioned[] = array_merge( [ 'site_url' => get_site_url(), 'blog_id' => $bid ], $created );
					restore_current_blog();
				}
			}

			Agency_Governance_Engine::dispatch_security_alert(
				'fleet.key_provisioned',
				sprintf( 'Provisioned %d API key(s) labeled "%s" via Fleet Command.', count( $provisioned ), $key_args['label'] ),
				[ 'count' => count( $provisioned ), 'role' => $key_args['agent_role'] ]
			);

			return [
				'provisioned_count' => count( $provisioned ),
				'keys'              => $provisioned,
			];
		}

		/**
		 * Synchronize AI Guardrails & Internal Link Rules across remote fleet sites (`POST /fleet/sync`).
		 */
		public static function sync_fleet_config( array $payload ): array {
			$sync_rules = ! empty( $payload['sync_internal_link_rules'] );
			$rules      = $sync_rules ? Internal_Linking_Engine::get_rules() : [];
			$remotes    = self::list_remote_sites( true );
			$results    = [];

			foreach ( $remotes as $rem ) {
				if ( empty( $rem['api_key'] ) ) {
					$results[] = [ 'site_url' => $rem['site_url'], 'status' => 'skipped_no_api_key' ];
					continue;
				}
				$pushed = 0;
				foreach ( $rules as $rule ) {
					$resp = wp_safe_remote_post(
						$rem['api_base'] . '/seo/internal-links/rules',
						[
							'timeout' => 6,
							'headers' => [
								'Content-Type'  => 'application/json',
								'Authorization' => 'Bearer ' . $rem['api_key'],
							],
							'body'    => wp_json_encode( $rule ),
						]
					);
					if ( ! is_wp_error( $resp ) && wp_remote_retrieve_response_code( $resp ) < 300 ) {
						++$pushed;
					}
				}
				$results[] = [
					'site_url'     => $rem['site_url'],
					'status'       => 'synced',
					'rules_pushed' => $pushed,
				];
			}

			return [
				'synced_sites' => count( $results ),
				'results'      => $results,
			];
		}

		/**
		 * Render the Fleet Command, White-Labeling & Real-Time Alerts Admin Page.
		 */
		public static function render_fleet_admin_page(): void {
			$health = self::fleet_health( false );
			$wl     = Agency_Governance_Engine::get_whitelabel();
			$alerts = Agency_Governance_Engine::get_alert_settings();
			?>
			<div class="directrelay-wrap">
				<div class="directrelay-header">
					<div class="directrelay-header-left">
						<h1 class="directrelay-page-title"><?php echo esc_html( $wl['plugin_name'] . ' — Fleet & Agency Governance' ); ?></h1>
						<span class="directrelay-badge-pill">PRO TIER 4</span>
					</div>
				</div>

				<div class="directrelay-grid-2">
					<div class="directrelay-card" style="padding:20px">
						<h3><?php esc_html_e( 'Connected Fleet Nodes', 'directrelay-pro' ); ?> (<?php echo (int) $health['total_nodes']; ?>)</h3>
						<table class="directrelay-table widefat">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Node', 'directrelay-pro' ); ?></th>
									<th><?php esc_html_e( 'Role', 'directrelay-pro' ); ?></th>
									<th><?php esc_html_e( 'URL', 'directrelay-pro' ); ?></th>
									<th><?php esc_html_e( 'Status', 'directrelay-pro' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $health['nodes'] as $n ) : ?>
									<tr>
										<td><strong><?php echo esc_html( (string) $n['label'] ); ?></strong></td>
										<td><code><?php echo esc_html( (string) $n['role'] ); ?></code></td>
										<td><a href="<?php echo esc_url( (string) $n['site_url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( (string) $n['site_url'] ); ?></a></td>
										<td><span class="directrelay-badge directrelay-badge-active"><?php echo esc_html( strtoupper( (string) $n['status'] ) ); ?></span></td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>

					<div class="directrelay-card" style="padding:20px">
						<h3><?php esc_html_e( 'Real-Time Security & Guardrail Alerts', 'directrelay-pro' ); ?></h3>
						<p style="color:var(--directrelay-muted);font-size:13px"><?php esc_html_e( 'Configure Slack, Telegram, or Discord webhooks via REST (/governance/alerts) to receive instant notifications on brute-force blocks, guardrail rejections, and approval tickets.', 'directrelay-pro' ); ?></p>
						<ul>
							<li><strong><?php esc_html_e( 'Slack Webhook:', 'directrelay-pro' ); ?></strong> <?php echo ! empty( $alerts['slack_webhook_url'] ) ? '✅ Configured' : '— Not set'; ?></li>
							<li><strong><?php esc_html_e( 'Telegram Bot:', 'directrelay-pro' ); ?></strong> <?php echo ( ! empty( $alerts['telegram_bot_token'] ) && ! empty( $alerts['telegram_chat_id'] ) ) ? '✅ Configured' : '— Not set'; ?></li>
							<li><strong><?php esc_html_e( 'Discord Webhook:', 'directrelay-pro' ); ?></strong> <?php echo ! empty( $alerts['discord_webhook_url'] ) ? '✅ Configured' : '— Not set'; ?></li>
						</ul>
					</div>
				</div>
			</div>
			<?php
		}
	}
	}

	/**
	 * ============================================================================
	 * TIER 4 — MODULE 2: Webhook 2.0 (Conditional Rules, Custom Templates & DLQ)
	 * ============================================================================
	 *
	 * - Evaluates granular conditions (`min_word_count`, `min_seo_score`,
	 *   `required_categories`, `excluded_categories`, `pillar_only`) before
	 *   allowing a scheduled webhook delivery to execute.
	 * - Supports custom JSON/Markdown payload templates (`{{post.title}}`,
	 *   `{{post.link}}`, `{{seo.focus_keyword}}`) and custom HTTP headers.
	 * - Provides a Dead-Letter Queue (DLQ) inspector and 1-Click Re-Drive engine
	 *   for failed webhook deliveries (`directrelay_webhook_log`).
	 */
	if ( ! class_exists( '\DirectRelay\Pro\Webhook_V2_Engine', false ) ) {
	final class Webhook_V2_Engine {

		public const RULES_OPTION = 'directrelay_pro_webhook_v2_rules';

		public static function init(): void {
			// Intercept `directrelay_deliver_webhook` at priority 5 (before Free's `deliver_worker` at priority 10).
			add_action( 'directrelay_deliver_webhook', [ __CLASS__, 'intercept_webhook_delivery' ], 5, 6 );
		}

		/**
		 * Get all Webhook 2.0 conditional & template rules keyed by webhook ID.
		 */
		public static function get_all_rules(): array {
			$rules = get_option( self::RULES_OPTION, [] );
			return is_array( $rules ) ? $rules : [];
		}

		/**
		 * Get Webhook 2.0 rule configuration for a specific webhook ID.
		 */
		public static function get_rule( int $webhook_id ): array {
			$all = self::get_all_rules();
			return isset( $all[ $webhook_id ] ) && is_array( $all[ $webhook_id ] ) ? $all[ $webhook_id ] : [];
		}

		/**
		 * Save conditional trigger rules, custom headers, and custom payload template for a webhook.
		 */
		public static function save_rule( int $webhook_id, array $config ): array {
			$all = self::get_all_rules();

			$headers = [];
			if ( ! empty( $config['custom_headers'] ) && is_array( $config['custom_headers'] ) ) {
				foreach ( $config['custom_headers'] as $hk => $hv ) {
					$clean_hk = sanitize_text_field( (string) $hk );
					if ( '' !== $clean_hk ) {
						$headers[ $clean_hk ] = sanitize_text_field( (string) $hv );
					}
				}
			}

			$rule = [
				'webhook_id'          => $webhook_id,
				'min_word_count'      => absint( $config['min_word_count'] ?? 0 ),
				'min_seo_score'       => absint( $config['min_seo_score'] ?? 0 ),
				'pillar_only'         => ! empty( $config['pillar_only'] ),
				'required_categories' => isset( $config['required_categories'] ) && is_array( $config['required_categories'] )
					? array_values( array_map( 'sanitize_text_field', $config['required_categories'] ) )
					: [],
				'excluded_categories' => isset( $config['excluded_categories'] ) && is_array( $config['excluded_categories'] )
					? array_values( array_map( 'sanitize_text_field', $config['excluded_categories'] ) )
					: [],
				'custom_headers'      => $headers,
				'payload_template'    => isset( $config['payload_template'] ) && is_array( $config['payload_template'] )
					? $config['payload_template']
					: null,
				'updated_at'          => current_time( 'mysql', true ),
			];

			$all[ $webhook_id ] = $rule;
			update_option( self::RULES_OPTION, $all, false );
			return $rule;
		}

		/**
		 * Evaluate whether a post/object satisfies the Webhook 2.0 conditional filter.
		 */
		public static function evaluate_conditions( int $webhook_id, string $event, int $object_id, string $object_type ): bool {
			$rule = self::get_rule( $webhook_id );
			if ( empty( $rule ) || ! in_array( $object_type, [ 'post', 'page' ], true ) ) {
				return true;
			}

			$post = get_post( $object_id );
			if ( ! $post ) {
				return true;
			}

			// 1. Minimum Word Count condition
			if ( ! empty( $rule['min_word_count'] ) ) {
				$words = str_word_count( wp_strip_all_tags( $post->post_content ) );
				if ( $words < (int) $rule['min_word_count'] ) {
					return false;
				}
			}

			$seo = SEO_Write_Engine::read( $object_id );

			// 2. Minimum SEO Score condition
			if ( ! empty( $rule['min_seo_score'] ) ) {
				if ( (int) ( $seo['seo_score'] ?? 0 ) < (int) $rule['min_seo_score'] ) {
					return false;
				}
			}

			// 3. Pillar Content Only condition
			if ( ! empty( $rule['pillar_only'] ) && empty( $seo['pillar_content_bool'] ) ) {
				return false;
			}

			// 4. Required & Excluded Categories
			if ( ! empty( $rule['required_categories'] ) || ! empty( $rule['excluded_categories'] ) ) {
				$terms     = wp_get_post_categories( $object_id, [ 'fields' => 'all' ] );
				$cat_names = [];
				if ( is_array( $terms ) ) {
					foreach ( $terms as $t ) {
						$cat_names[] = strtolower( $t->name );
						$cat_names[] = strtolower( $t->slug );
						$cat_names[] = (string) $t->term_id;
					}
				}

				if ( ! empty( $rule['required_categories'] ) ) {
					$matched_req = false;
					foreach ( $rule['required_categories'] as $rc ) {
						if ( in_array( strtolower( (string) $rc ), $cat_names, true ) ) {
							$matched_req = true;
							break;
						}
					}
					if ( ! $matched_req ) {
						return false;
					}
				}

				if ( ! empty( $rule['excluded_categories'] ) ) {
					foreach ( $rule['excluded_categories'] as $ec ) {
						if ( in_array( strtolower( (string) $ec ), $cat_names, true ) ) {
							return false;
						}
					}
				}
			}

			return true;
		}

		/**
		 * Intercept `directrelay_deliver_webhook` before Free's `deliver_worker`:
		 * if conditional filters fail, cancel delivery cleanly; if custom payload
		 * template or custom headers are configured, handle the enhanced delivery.
		 */
		public static function intercept_webhook_delivery( int $hook_id, string $event, int $object_id, string $object_type, int $attempt = 1, ?int $parent_log_id = null ): void {
			if ( ! self::evaluate_conditions( $hook_id, $event, $object_id, $object_type ) ) {
				// Prevent Free's default `deliver_worker` from firing for this skipped event.
				remove_action( 'directrelay_deliver_webhook', [ '\DirectRelay\Webhook_Manager', 'deliver_worker' ], 10 );
				return;
			}

			$rule = self::get_rule( $hook_id );
			if ( empty( $rule['custom_headers'] ) && empty( $rule['payload_template'] ) ) {
				return; // Let Free's standard `Webhook_Manager::deliver_worker` handle it.
			}

			// Custom template or headers present: take over delivery for this invocation.
			remove_action( 'directrelay_deliver_webhook', [ '\DirectRelay\Webhook_Manager', 'deliver_worker' ], 10 );
			self::deliver_custom_webhook( $hook_id, $event, $object_id, $object_type, $attempt, $rule );
		}

		/**
		 * Execute custom-templated or custom-header webhook delivery and log to `directrelay_webhook_log`.
		 */
		public static function deliver_custom_webhook( int $hook_id, string $event, int $object_id, string $object_type, int $attempt, array $rule ): array {
			global $wpdb;
			$t_hook = "{$wpdb->prefix}directrelay_webhooks";
			$t_log  = "{$wpdb->prefix}directrelay_webhook_log";

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$hook = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t_hook} WHERE id = %d", $hook_id ), ARRAY_A );
			if ( ! $hook ) {
				return [ 'success' => false, 'status' => 0, 'error' => 'Webhook not found.' ];
			}

			$post      = in_array( $object_type, [ 'post', 'page' ], true ) ? get_post( $object_id ) : null;
			$post_data = $post ? Post_Manager::format( $post ) : [];
			$seo_data  = $post ? SEO_Write_Engine::read( $object_id ) : [];

			$context = [
				'event'       => $event,
				'object_id'   => $object_id,
				'object_type' => $object_type,
				'timestamp'   => current_time( 'c', true ),
				'site_url'    => get_site_url(),
				'post'        => $post_data,
				'seo'         => $seo_data,
			];

			$payload = ! empty( $rule['payload_template'] ) && is_array( $rule['payload_template'] )
				? self::render_payload_template( $rule['payload_template'], $context )
				: $context;

			$body    = (string) wp_json_encode( $payload );
			$headers = array_merge(
				[
					'Content-Type'          => 'application/json',
					'X-directrelay-Event'   => $event,
					'X-directrelay-Version' => DIRECTRELAY_VERSION,
					'X-directrelay-Hook-ID' => (string) $hook_id,
				],
				$rule['custom_headers'] ?? []
			);

			$plain_secret = ! empty( $hook['secret'] ) ? Webhook_Manager::decrypt_secret( (string) $hook['secret'] ) : '';
			if ( '' !== $plain_secret ) {
				$ts                                           = (string) time();
				$headers['X-directrelay-Signature']           = 'sha256=' . hash_hmac( 'sha256', $body, $plain_secret );
				$headers['X-directrelay-Timestamp']           = $ts;
				$headers['X-directrelay-Signature-Timestamp'] = 'sha256=' . hash_hmac( 'sha256', $ts . '.' . $body, $plain_secret );
			}

			$t0   = microtime( true );
			$resp = wp_safe_remote_post(
				(string) $hook['target_url'],
				[
					'body'        => $body,
					'headers'     => $headers,
					'timeout'     => 5,
					'blocking'    => true,
					'data_format' => 'body',
					'sslverify'   => true,
				]
			);
			$ms   = (int) round( ( microtime( true ) - $t0 ) * 1000 );

			$code    = is_wp_error( $resp ) ? 0 : (int) wp_remote_retrieve_response_code( $resp );
			$success = $code >= 200 && $code < 300;
			$err_msg = is_wp_error( $resp ) ? $resp->get_error_message() : null;
			$r_body  = is_wp_error( $resp ) ? null : substr( (string) wp_remote_retrieve_body( $resp ), 0, 1000 );

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->insert(
				$t_log,
				[
					'webhook_id'    => $hook_id,
					'event'         => $event,
					'object_id'     => $object_id,
					'attempt'       => $attempt,
					'http_status'   => $code ?: null,
					'duration_ms'   => $ms,
					'response_body' => $r_body,
					'error_message' => $err_msg,
					'created_at'    => current_time( 'mysql', true ),
				],
				[ '%d', '%s', '%d', '%d', '%d', '%d', '%s', '%s', '%s' ]
			);

			return [
				'success'     => $success,
				'status'      => $code,
				'duration_ms' => $ms,
				'error'       => $err_msg,
			];
		}

		/**
		 * List Dead-Letter Queue (DLQ) failed webhook deliveries from `{$wpdb->prefix}directrelay_webhook_log`.
		 */
		public static function list_dlq( int $limit = 50 ): array {
			global $wpdb;
			$limit  = max( 1, min( 200, $limit ) );
			$t_log  = "{$wpdb->prefix}directrelay_webhook_log";
			$t_hook = "{$wpdb->prefix}directrelay_webhooks";

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			return $wpdb->get_results(
				$wpdb->prepare(
					"SELECT l.*, w.label AS webhook_label, w.target_url
					 FROM {$t_log} l
					 LEFT JOIN {$t_hook} w ON l.webhook_id = w.id
					 WHERE l.http_status IS NULL OR l.http_status < 200 OR l.http_status >= 300
					 ORDER BY l.created_at DESC
					 LIMIT %d",
					$limit
				),
				ARRAY_A
			) ?: [];
		}

		/**
		 * Re-drive a single failed webhook delivery log entry (or a batch of DLQ entries).
		 */
		public static function redrive_dlq_entry( int $log_id ): array|\WP_Error {
			global $wpdb;
			$t_log = "{$wpdb->prefix}directrelay_webhook_log";

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t_log} WHERE id = %d", $log_id ), ARRAY_A );
			if ( ! $row ) {
				return new \WP_Error( 'amp_not_found', __( 'Webhook delivery log entry not found.', 'directrelay-pro' ), [ 'status' => 404 ] );
			}

			$hook_id = (int) $row['webhook_id'];
			$event   = (string) ( $row['event'] ?: 'post.published' );
			$obj_id  = (int) ( $row['object_id'] ?? 0 );
			$type    = str_starts_with( $event, 'page.' ) ? 'page' : 'post';
			$attempt = (int) ( $row['attempt'] ?? 1 ) + 1;

			$rule = self::get_rule( $hook_id );
			$res  = self::deliver_custom_webhook( $hook_id, $event, $obj_id, $type, $attempt, $rule );

			return [
				'redriven_log_id' => $log_id,
				'webhook_id'      => $hook_id,
				'event'           => $event,
				'object_id'       => $obj_id,
				'attempt'         => $attempt,
				'result'          => $res,
			];
		}

		/**
		 * Substitute `{{post.title}}`, `{{seo.focus_keyword}}`, etc. inside custom payload templates.
		 */
		private static function render_payload_template( array $template, array $context ): array {
			$out = [];
			foreach ( $template as $k => $v ) {
				if ( is_array( $v ) ) {
					$out[ $k ] = self::render_payload_template( $v, $context );
				} elseif ( is_string( $v ) ) {
					$out[ $k ] = (string) preg_replace_callback(
						'/\{\{\s*([a-zA-Z0-9_\.]+)\s*\}\}/',
						static function ( array $m ) use ( $context ): string {
							$parts = explode( '.', $m[1] );
							$cur   = $context;
							foreach ( $parts as $p ) {
								if ( is_array( $cur ) && array_key_exists( $p, $cur ) ) {
									$cur = $cur[ $p ];
								} else {
									return '';
								}
							}
							return is_scalar( $cur ) ? (string) $cur : (string) wp_json_encode( $cur );
						},
						$v
					);
				} else {
					$out[ $k ] = $v;
				}
			}
			return $out;
		}
	}
	}

	/**
	 * ============================================================================
	 * TIER 4 — MODULE 3: Agency White-Labeling & Real-Time Security Alerts Engine
	 * ============================================================================
	 *
	 * - Agency White-Labeling: Customizes plugin name, tagline, menu title, accent
	 *   color, and support links across wp-admin (`all_plugins` filter + CSS override).
	 * - Real-Time Multi-Channel Security & Guardrail Alerts: Sends instant notifications
	 *   to Slack, Telegram, and Discord on Brute-Force blocks, Guardrail violations,
	 *   API Key provisioning, and Human Approval tickets.
	 */
	if ( ! class_exists( '\DirectRelay\Pro\Agency_Governance_Engine', false ) ) {
	final class Agency_Governance_Engine {

		public const WHITELABEL_OPTION = 'directrelay_pro_whitelabel';
		public const ALERTS_OPTION     = 'directrelay_pro_security_alerts';
		public const LICENSE_OPTION    = 'directrelay_pro_license';

		public static function init(): void {
			add_filter( 'all_plugins', [ __CLASS__, 'filter_plugin_row_meta' ] );
			add_action( 'admin_head', [ __CLASS__, 'inject_whitelabel_styles' ], 30 );
		}

		/**
		 * Get White-Label configuration.
		 */
		public static function get_whitelabel(): array {
			$defaults = [
				'enabled'          => false,
				'plugin_name'      => 'DirectRelay Pro',
				'menu_label'       => 'DirectRelay',
				'author_name'      => 'n4nion',
				'author_url'       => 'https://directrelay.wikiofautomation.com',
				'primary_color'    => '#28CCCD',
				'hide_pro_upsells' => false,
			];
			$saved = get_option( self::WHITELABEL_OPTION, [] );
			return is_array( $saved ) ? array_merge( $defaults, $saved ) : $defaults;
		}

		/**
		 * Save White-Label configuration.
		 */
		public static function save_whitelabel( array $input ): array {
			$current = self::get_whitelabel();
			$updated = [
				'enabled'          => isset( $input['enabled'] ) ? ! empty( $input['enabled'] ) : $current['enabled'],
				'plugin_name'      => sanitize_text_field( (string) ( $input['plugin_name'] ?? $current['plugin_name'] ) ),
				'menu_label'       => sanitize_text_field( (string) ( $input['menu_label'] ?? $current['menu_label'] ) ),
				'author_name'      => sanitize_text_field( (string) ( $input['author_name'] ?? $current['author_name'] ) ),
				'author_url'       => esc_url_raw( (string) ( $input['author_url'] ?? $current['author_url'] ), [ 'http', 'https' ] ),
				'primary_color'    => sanitize_hex_color( (string) ( $input['primary_color'] ?? $current['primary_color'] ) ) ?: '#28CCCD',
				'hide_pro_upsells' => isset( $input['hide_pro_upsells'] ) ? ! empty( $input['hide_pro_upsells'] ) : $current['hide_pro_upsells'],
			];
			update_option( self::WHITELABEL_OPTION, $updated, false );
			return $updated;
		}

		/**
		 * Apply White-Label branding on the WordPress Plugins list screen.
		 */
		public static function filter_plugin_row_meta( array $plugins ): array {
			$wl = self::get_whitelabel();
			if ( empty( $wl['enabled'] ) ) {
				return $plugins;
			}
			foreach ( $plugins as $slug => &$meta ) {
				if ( str_contains( $slug, 'directrelay' ) ) {
					$meta['Name']       = $wl['plugin_name'];
					$meta['Title']      = $wl['plugin_name'];
					$meta['Author']     = $wl['author_name'];
					$meta['AuthorName'] = $wl['author_name'];
					$meta['AuthorURI']  = $wl['author_url'];
				}
			}
			unset( $meta );
			return $plugins;
		}

		/**
		 * Inject custom primary brand color CSS when White-Labeling is active.
		 */
		public static function inject_whitelabel_styles(): void {
			$wl = self::get_whitelabel();
			if ( empty( $wl['enabled'] ) ) {
				return;
			}
			?>
			<style id="directrelay-pro-whitelabel">
				.directrelay-wrap {
					--directrelay-primary: <?php echo esc_html( $wl['primary_color'] ); ?> !important;
				}
			</style>
			<?php
		}

		/**
		 * Get Real-Time Security Alert channel settings.
		 */
		public static function get_alert_settings(): array {
			$defaults = [
				'enabled'              => false,
				'slack_webhook_url'    => '',
				'telegram_bot_token'   => '',
				'telegram_chat_id'     => '',
				'discord_webhook_url'  => '',
				'events'               => [ 'brute_force.blocked', 'guardrail.violation', 'approval.created', 'fleet.key_provisioned' ],
			];
			$saved = get_option( self::ALERTS_OPTION, [] );
			return is_array( $saved ) ? array_merge( $defaults, $saved ) : $defaults;
		}

		/**
		 * Save Real-Time Security Alert channel settings.
		 */
		public static function save_alert_settings( array $input ): array {
			$cur     = self::get_alert_settings();
			$updated = [
				'enabled'             => isset( $input['enabled'] ) ? ! empty( $input['enabled'] ) : true,
				'slack_webhook_url'   => esc_url_raw( (string) ( $input['slack_webhook_url'] ?? $cur['slack_webhook_url'] ), [ 'https', 'http' ] ),
				'telegram_bot_token'  => sanitize_text_field( (string) ( $input['telegram_bot_token'] ?? $cur['telegram_bot_token'] ) ),
				'telegram_chat_id'    => sanitize_text_field( (string) ( $input['telegram_chat_id'] ?? $cur['telegram_chat_id'] ) ),
				'discord_webhook_url' => esc_url_raw( (string) ( $input['discord_webhook_url'] ?? $cur['discord_webhook_url'] ), [ 'https', 'http' ] ),
				'events'              => isset( $input['events'] ) && is_array( $input['events'] )
					? array_values( array_map( 'sanitize_text_field', $input['events'] ) )
					: $cur['events'],
			];
			update_option( self::ALERTS_OPTION, $updated, false );
			return $updated;
		}

		/**
		 * Dispatch a real-time security or governance alert to configured Slack, Telegram, and Discord channels.
		 */
		public static function dispatch_security_alert( string $event, string $message, array $context = [], bool $force = false ): array {
			$cfg = self::get_alert_settings();
			if ( ! $force && ( empty( $cfg['enabled'] ) || ! in_array( $event, (array) $cfg['events'], true ) ) ) {
				return [ 'dispatched' => false, 'reason' => 'event_disabled' ];
			}

			$site_name = get_bloginfo( 'name' ) ?: get_site_url();
			$text      = sprintf( "🛡️ *[DirectRelay Pro Alert — %s]*\n*Event:* `%s`\n*Message:* %s", $site_name, $event, $message );
			if ( ! empty( $context ) ) {
				$text .= "\n*Context:* `" . wp_json_encode( $context ) . '`';
			}

			$channels = [];

			// 1. Slack Incoming Webhook
			if ( ! empty( $cfg['slack_webhook_url'] ) && Api_Auth::is_url_safe( $cfg['slack_webhook_url'] ) ) {
				$r = wp_safe_remote_post(
					$cfg['slack_webhook_url'],
					[
						'timeout' => 5,
						'headers' => [ 'Content-Type' => 'application/json' ],
						'body'    => wp_json_encode( [ 'text' => $text ] ),
					]
				);
				$channels['slack'] = is_wp_error( $r ) ? $r->get_error_message() : (int) wp_remote_retrieve_response_code( $r );
			}

			// 2. Telegram Bot API
			if ( ! empty( $cfg['telegram_bot_token'] ) && ! empty( $cfg['telegram_chat_id'] ) ) {
				$tg_url = sprintf( 'https://api.telegram.org/bot%s/sendMessage', rawurlencode( $cfg['telegram_bot_token'] ) );
				$r      = wp_remote_post(
					$tg_url,
					[
						'timeout' => 5,
						'headers' => [ 'Content-Type' => 'application/json' ],
						'body'    => wp_json_encode( [
							'chat_id'    => $cfg['telegram_chat_id'],
							'text'       => $text,
							'parse_mode' => 'Markdown',
						] ),
					]
				);
				$channels['telegram'] = is_wp_error( $r ) ? $r->get_error_message() : (int) wp_remote_retrieve_response_code( $r );
			}

			// 3. Discord Webhook
			if ( ! empty( $cfg['discord_webhook_url'] ) && Api_Auth::is_url_safe( $cfg['discord_webhook_url'] ) ) {
				$r = wp_safe_remote_post(
					$cfg['discord_webhook_url'],
					[
						'timeout' => 5,
						'headers' => [ 'Content-Type' => 'application/json' ],
						'body'    => wp_json_encode( [ 'content' => $text ] ),
					]
				);
				$channels['discord'] = is_wp_error( $r ) ? $r->get_error_message() : (int) wp_remote_retrieve_response_code( $r );
			}

			return [
				'dispatched' => ! empty( $channels ),
				'event'      => $event,
				'channels'   => $channels,
			];
		}
	}
	}
}

namespace DirectRelay\Pro\REST {

	defined( 'ABSPATH' ) || exit;

	use DirectRelay\Pro\Agency_Governance_Engine;
	use DirectRelay\Pro\Fleet_Command_Engine;
	use DirectRelay\Pro\Webhook_V2_Engine;

	/**
	 * Tier 4 — Module 1 REST Controller: Multi-Site & Multi-Domain Fleet Command
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\Fleet_Controller', false ) ) {
	final class Fleet_Controller extends Pro_Base_Controller {

		public static function register(): void {
			register_rest_route(
				self::NS,
				'/fleet/health',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'health' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'system:read' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/fleet/sites',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'list_sites' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'system:read' ),
					],
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'add_site' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'keys:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/fleet/sites/(?P<id>[a-zA-Z0-9_-]+)',
				[
					[
						'methods'             => \WP_REST_Server::DELETABLE,
						'callback'            => [ self::class, 'remove_site' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'keys:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/fleet/keys/provision',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'provision_keys' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'keys:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/fleet/sync',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'sync' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'keys:write' ),
					],
				]
			);
		}

		public static function health( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$ping_remote = 'false' !== strtolower( (string) $req->get_param( 'ping_remote' ) );
			return self::ok( $req, Fleet_Command_Engine::fleet_health( $ping_remote ), 200, 'fleet_health' );
		}

		public static function list_sites( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$sites = Fleet_Command_Engine::list_remote_sites( false );
			return self::ok( $req, [ 'sites' => $sites, 'total' => count( $sites ) ], 200, 'fleet_list_sites' );
		}

		public static function add_site( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body = $req->get_json_params() ?: [];
			$res  = Fleet_Command_Engine::add_remote_site( $body );
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'fleet_add_site' );
			}
			return self::ok( $req, [ 'site' => $res ], 201, 'fleet_add_site' );
		}

		public static function remove_site( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id = sanitize_key( (string) $req->get_param( 'id' ) );
			$ok = Fleet_Command_Engine::remove_remote_site( $id );
			return self::ok( $req, [ 'deleted' => $ok, 'id' => $id ], 200, 'fleet_remove_site' );
		}

		public static function provision_keys( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body = $req->get_json_params() ?: [];
			return self::ok( $req, Fleet_Command_Engine::provision_keys( $body ), 201, 'fleet_provision_keys' );
		}

		public static function sync( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body = $req->get_json_params() ?: [ 'sync_internal_link_rules' => true ];
			return self::ok( $req, Fleet_Command_Engine::sync_fleet_config( $body ), 200, 'fleet_sync' );
		}
	}
	}

	/**
	 * Tier 4 — Module 2 REST Controller: Webhook 2.0 Rules & Dead-Letter Queue (DLQ)
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\Webhook_V2_Controller', false ) ) {
	final class Webhook_V2_Controller extends Pro_Base_Controller {

		public static function register(): void {
			register_rest_route(
				self::NS,
				'/webhooks/(?P<id>\\d+)/rules',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'get_rules' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'webhooks:read' ),
					],
					[
						'methods'             => \WP_REST_Server::EDITABLE,
						'callback'            => [ self::class, 'save_rules' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'webhooks:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/webhooks/dlq',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'list_dlq' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'webhooks:read' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/webhooks/dlq/redrive',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'redrive_batch' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'webhooks:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/webhooks/dlq/redrive/(?P<log_id>\\d+)',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'redrive_single' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'webhooks:write' ),
					],
				]
			);
		}

		public static function get_rules( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id = (int) $req->get_param( 'id' );
			return self::ok( $req, [ 'webhook_id' => $id, 'rules' => Webhook_V2_Engine::get_rule( $id ) ], 200, 'get_webhook_v2_rules', $id, 'webhook' );
		}

		public static function save_rules( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$id   = (int) $req->get_param( 'id' );
			$body = $req->get_json_params() ?: [];
			$rule = Webhook_V2_Engine::save_rule( $id, $body );
			return self::ok( $req, [ 'webhook_id' => $id, 'rules' => $rule ], 200, 'save_webhook_v2_rules', $id, 'webhook' );
		}

		public static function list_dlq( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$limit = max( 1, min( 200, (int) ( $req->get_param( 'limit' ) ?: 50 ) ) );
			$items = Webhook_V2_Engine::list_dlq( $limit );
			return self::ok( $req, [ 'dlq' => $items, 'total' => count( $items ) ], 200, 'list_webhook_dlq' );
		}

		public static function redrive_single( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$log_id = (int) $req->get_param( 'log_id' );
			$res    = Webhook_V2_Engine::redrive_dlq_entry( $log_id );
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'redrive_webhook_dlq' );
			}
			return self::ok( $req, $res, 200, 'redrive_webhook_dlq', $log_id, 'webhook_log' );
		}

		public static function redrive_batch( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body    = $req->get_json_params() ?: [];
			$log_ids = isset( $body['log_ids'] ) && is_array( $body['log_ids'] ) ? array_map( 'intval', $body['log_ids'] ) : [];

			if ( empty( $log_ids ) ) {
				$dlq     = Webhook_V2_Engine::list_dlq( 10 );
				$log_ids = array_map( static fn( array $r ): int => (int) $r['id'], $dlq );
			}

			$results = [];
			foreach ( array_slice( $log_ids, 0, 25 ) as $lid ) {
				$r         = Webhook_V2_Engine::redrive_dlq_entry( $lid );
				$results[] = is_wp_error( $r ) ? [ 'log_id' => $lid, 'error' => $r->get_error_message() ] : $r;
			}

			return self::ok( $req, [ 'redriven_count' => count( $results ), 'results' => $results ], 200, 'redrive_webhook_dlq_batch' );
		}
	}
	}

	/**
	 * Tier 4 — Module 3 REST Controller: Agency White-Labeling & Real-Time Security Alerts
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\Governance_Controller', false ) ) {
	final class Governance_Controller extends Pro_Base_Controller {

		public static function register(): void {
			register_rest_route(
				self::NS,
				'/governance/whitelabel',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'get_whitelabel' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'system:read' ),
					],
					[
						'methods'             => \WP_REST_Server::EDITABLE,
						'callback'            => [ self::class, 'save_whitelabel' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'keys:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/governance/alerts',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'get_alerts' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'system:read' ),
					],
					[
						'methods'             => \WP_REST_Server::EDITABLE,
						'callback'            => [ self::class, 'save_alerts' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'keys:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/governance/alerts/test',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'test_alert' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'keys:write' ),
					],
				]
			);
		}

		public static function get_whitelabel( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			return self::ok( $req, Agency_Governance_Engine::get_whitelabel(), 200, 'get_whitelabel' );
		}

		public static function save_whitelabel( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body = $req->get_json_params() ?: [];
			return self::ok( $req, Agency_Governance_Engine::save_whitelabel( $body ), 200, 'save_whitelabel' );
		}

		public static function get_alerts( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			return self::ok( $req, Agency_Governance_Engine::get_alert_settings(), 200, 'get_security_alerts' );
		}

		public static function save_alerts( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body = $req->get_json_params() ?: [];
			return self::ok( $req, Agency_Governance_Engine::save_alert_settings( $body ), 200, 'save_security_alerts' );
		}

		public static function test_alert( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body = $req->get_json_params() ?: [];
			$msg  = sanitize_text_field( (string) ( $body['message'] ?? 'Test security notification from DirectRelay Pro.' ) );
			$res  = Agency_Governance_Engine::dispatch_security_alert( 'test.alert', $msg, [ 'triggered_by' => 'REST API' ], true );
			return self::ok( $req, $res, 200, 'test_security_alert' );
		}
	}
	}
}
namespace DirectRelay\Pro {

	defined( 'ABSPATH' ) || exit;

	use DirectRelay\Api_Auth;
	use DirectRelay\Webhook_Manager;

	/**
	 * ============================================================================
	 * AUTONODE LICENSE & FLEET TELEMETRY CLIENT (`License_Manager`)
	 * ============================================================================
	 *
	 * Connects `DirectRelay Pro` securely to the AutoNode License & Fleet Server (`v2.2.0`):
	 *   - Default Server: `https://autonode-licenses.wikiofautomation.com`
	 *   - REST Namespace: `/wp-json/autonode-license/v1`
	 *   - Endpoints:
	 *       - `POST /verify`        (Activate / verify Pro license key + embedded telemetry + HMAC signature)
	 *       - `POST /deactivate`    (Deactivate current domain slot)
	 *       - `POST /telemetry`     (Periodic heartbeat syncing API keys, call counts & webhooks)
	 *       - `POST /free-register` (Register unlicensed install in Free Tier Fleet tracker)
	 *       - `POST /client-status` (Lookup remote domain registration & tier status)
	 *       - `GET  /ping`          (Health & latency check)
	 *
	 * Security Architecture:
	 *   1. AES-256-CBC Encryption at Rest: License keys and HMAC verification secrets are
	 *      encrypted via `Webhook_Manager::encrypt_secret()` before saving to `wp_options`.
	 *   2. Cryptographic HMAC-SHA256 Signature Verification: Verifies `$payload['signature']`
	 *      using `hash_equals()` and enforces a 300-second replay window + normalized domain match.
	 *   3. Tamper-Evident Local State Seal (`local_seal`): Protects stored activation state in
	 *      `wp_options` against direct database modification using a site-specific HMAC seal.
	 *   4. 72-Hour Offline Grace Period: Protects production n8n pipelines from transient DNS
	 *      or network blips while immediately revoking on explicit HTTP 401/403 responses.
	 */
	if ( ! class_exists( '\DirectRelay\Pro\License_Manager', false ) ) {
	final class License_Manager {

		public const STATE_OPTION        = 'directrelay_pro_license_state';
		public const CONFIG_OPTION       = 'directrelay_pro_license_config';
		public const SITE_UUID_OPTION    = 'directrelay_pro_site_uuid';
		public const CRON_HOOK           = 'directrelay_pro_license_heartbeat';
		public const DEFAULT_SERVER_URL  = 'https://autonode-licenses.wikiofautomation.com';
		public const GRACE_PERIOD_SEC    = 259200; // 72 hours offline grace for network blips

		public static function init(): void {
			// Schedule daily telemetry & license verification heartbeat if not scheduled.
			if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
				wp_schedule_event( time() + 300, 'daily', self::CRON_HOOK );
			}
			add_action( self::CRON_HOOK, [ __CLASS__, 'cron_heartbeat' ] );

			// Enforce Pro license gate on REST write endpoints when strict enforcement is active.
			add_filter( 'rest_request_before_callbacks', [ __CLASS__, 'enforce_rest_license_gate' ], 8, 3 );

			// Admin AJAX actions for the License & Fleet management screen.
			add_action( 'wp_ajax_directrelay_pro_activate_license', [ __CLASS__, 'ajax_activate_license' ] );
			add_action( 'wp_ajax_directrelay_pro_deactivate_license', [ __CLASS__, 'ajax_deactivate_license' ] );
			add_action( 'wp_ajax_directrelay_pro_verify_license', [ __CLASS__, 'ajax_verify_license' ] );
			add_action( 'wp_ajax_directrelay_pro_ping_license_server', [ __CLASS__, 'ajax_ping_server' ] );
			add_action( 'wp_ajax_directrelay_pro_save_license_config', [ __CLASS__, 'ajax_save_config' ] );

			// Support auto-activation via `DIRECTRELAY_PRO_LICENSE_KEY` constant in `wp-config.php`.
			if ( defined( 'DIRECTRELAY_PRO_LICENSE_KEY' ) && is_string( DIRECTRELAY_PRO_LICENSE_KEY ) && '' !== trim( DIRECTRELAY_PRO_LICENSE_KEY ) ) {
				$state = self::get_state();
				if ( empty( $state['valid'] ) && empty( $state['auto_attempted'] ) ) {
					$state['auto_attempted'] = time();
					update_option( self::STATE_OPTION, $state, false );
					self::activate( trim( DIRECTRELAY_PRO_LICENSE_KEY ) );
				}
			}
		}

		/**
		 * Plugin activation hook: ensure site UUID exists, schedule daily heartbeat, and register install.
		 */
		public static function on_plugin_activate( $network_wide = false ): void {
			$network_wide = (bool) $network_wide;
			try {
				Plugin::load_bundled_core();
				if ( class_exists( '\DirectRelay\Installer' ) ) {
					\DirectRelay\Installer::activate( $network_wide );
				}
				self::site_uuid();
				if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
					wp_schedule_event( time() + 60, 'daily', self::CRON_HOOK );
				}
			} catch ( \Throwable $e ) {
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG && function_exists( 'error_log' ) ) {
					@error_log( '[DirectRelay Pro] Activation warning: ' . $e->getMessage() );
				}
			}
		}

		/**
		 * Plugin deactivation hook: clear scheduled heartbeat cron.
		 */
		public static function on_plugin_deactivate(): void {
			wp_clear_scheduled_hook( self::CRON_HOOK );
		}

		/**
		 * Get or generate a persistent UUIDv4 for this WordPress site (`site_uuid`).
		 */
		public static function site_uuid(): string {
			$uuid = (string) get_option( self::SITE_UUID_OPTION, '' );
			if ( '' === $uuid ) {
				$uuid = wp_generate_uuid4();
				update_option( self::SITE_UUID_OPTION, $uuid, false );
			}
			return $uuid;
		}

		/**
		 * Normalize domain identically to `ALS_Key_Manager::normalize_domain()` on the License Server.
		 */
		public static function normalize_domain( string $domain ): string {
			$domain = trim( $domain );
			if ( '' === $domain ) {
				return '';
			}
			if ( ! preg_match( '#^https?://#i', $domain ) ) {
				$domain = 'http://' . $domain;
			}
			$host = wp_parse_url( $domain, PHP_URL_HOST );
			if ( ! $host ) {
				$host = $domain;
			}
			$host = strtolower( trim( (string) $host ) );
			$host = (string) preg_replace( '/^www\./i', '', $host );
			return $host;
		}

		/**
		 * Return the normalized domain for the current WordPress installation.
		 */
		public static function current_domain(): string {
			return self::normalize_domain( home_url() );
		}

		/**
		 * Check whether the current domain is a local or staging development environment.
		 */
		public static function is_local_or_staging(): bool {
			if ( defined( 'DIRECTRELAY_PRO_DEV_MODE' ) && DIRECTRELAY_PRO_DEV_MODE ) {
				return true;
			}
			$domain = self::current_domain();
			if ( in_array( $domain, [ 'localhost', '127.0.0.1', '::1' ], true ) ) {
				return true;
			}
			foreach ( [ '.local', '.test', '.invalid', '.example', '.localhost', 'staging.', 'dev.', 'test.' ] as $marker ) {
				if ( str_ends_with( $domain, $marker ) || str_starts_with( $domain, $marker ) ) {
					return true;
				}
			}
			return false;
		}

		/**
		 * Retrieve License Server configuration (`server_url`, `hmac_secret`, `enforce_strict_gate`, `buyer_email`).
		 */
		public static function get_config(): array {
			$saved = get_option( self::CONFIG_OPTION, [] );
			if ( ! is_array( $saved ) ) {
				$saved = [];
			}

			$server_url = defined( 'DIRECTRELAY_LICENSE_SERVER_URL' ) && DIRECTRELAY_LICENSE_SERVER_URL
				? (string) DIRECTRELAY_LICENSE_SERVER_URL
				: (string) ( $saved['server_url'] ?? self::DEFAULT_SERVER_URL );

			$server_url = rtrim( trim( $server_url ), '/' );
			// Strip trailing `/wp-json/autonode-license/v1/verify` or `/wp-json/...` if user pasted full endpoint URL.
			$server_url = (string) preg_replace( '#/wp-json/autonode-license/v1(?:/.*)?$#i', '', $server_url );

			$hmac_secret = '';
			if ( defined( 'DIRECTRELAY_LICENSE_HMAC_SECRET' ) && DIRECTRELAY_LICENSE_HMAC_SECRET ) {
				$hmac_secret = (string) DIRECTRELAY_LICENSE_HMAC_SECRET;
			} elseif ( ! empty( $saved['hmac_secret_enc'] ) ) {
				$hmac_secret = self::decrypt_value( (string) $saved['hmac_secret_enc'] );
			}

			return [
				'server_url'          => $server_url ?: self::DEFAULT_SERVER_URL,
				'hmac_secret'         => $hmac_secret,
				'hmac_configured'     => '' !== $hmac_secret,
				'enforce_strict_gate' => ! empty( $saved['enforce_strict_gate'] ),
				'buyer_email'         => sanitize_email( (string) ( $saved['buyer_email'] ?? get_option( 'admin_email' ) ) ),
			];
		}

		/**
		 * Save License Server configuration settings.
		 */
		public static function save_config( array $input ): array {
			$existing = get_option( self::CONFIG_OPTION, [] );
			if ( ! is_array( $existing ) ) {
				$existing = [];
			}

			if ( isset( $input['server_url'] ) ) {
				$url = esc_url_raw( trim( (string) $input['server_url'] ), [ 'http', 'https' ] );
				$url = (string) preg_replace( '#/wp-json/autonode-license/v1(?:/.*)?$#i', '', rtrim( $url, '/' ) );
				$existing['server_url'] = $url ?: self::DEFAULT_SERVER_URL;
			}

			if ( array_key_exists( 'hmac_secret', $input ) ) {
				$sec = trim( (string) $input['hmac_secret'] );
				if ( '' === $sec ) {
					$existing['hmac_secret_enc'] = '';
				} elseif ( ! str_contains( $sec, '••••' ) ) {
					$existing['hmac_secret_enc'] = self::encrypt_value( $sec );
				}
			}

			if ( array_key_exists( 'enforce_strict_gate', $input ) ) {
				$existing['enforce_strict_gate'] = ! empty( $input['enforce_strict_gate'] );
			}

			if ( isset( $input['buyer_email'] ) ) {
				$existing['buyer_email'] = sanitize_email( (string) $input['buyer_email'] );
			}

			update_option( self::CONFIG_OPTION, $existing, false );
			return self::get_config();
		}

		/**
		 * Build full REST endpoint URL on the AutoNode License Server (`autonode-license/v1/{route}`).
		 */
		public static function endpoint_url( string $route ): string {
			$cfg  = self::get_config();
			$base = rtrim( $cfg['server_url'], '/' );
			$path = ltrim( $route, '/' );
			return "{$base}/wp-json/autonode-license/v1/{$path}";
		}

		/**
		 * Retrieve and cryptographically verify local license state from `wp_options`.
		 */
		public static function get_state(): array {
			$raw = get_option( self::STATE_OPTION, [] );
			if ( ! is_array( $raw ) || empty( $raw ) ) {
				return [
					'valid'            => false,
					'status'           => 'inactive',
					'plan'             => 'free',
					'plan_label'       => 'Unlicensed',
					'license_key'      => '',
					'key_prefix'       => '',
					'domain'           => self::current_domain(),
					'buyer'            => '',
					'expires'          => '',
					'activations'      => 0,
					'max_activations'  => 0,
					'features'         => [],
					'last_verified_at' => 0,
					'last_error'       => '',
					'seal_valid'       => false,
				];
			}

			$license_key = ! empty( $raw['license_key_enc'] )
				? self::decrypt_value( (string) $raw['license_key_enc'] )
				: '';

			$state = [
				'valid'            => ! empty( $raw['valid'] ),
				'status'           => (string) ( $raw['status'] ?? 'inactive' ),
				'plan'             => (string) ( $raw['plan'] ?? 'free' ),
				'plan_label'       => (string) ( $raw['plan_label'] ?? 'Unlicensed' ),
				'license_key'      => $license_key,
				'key_prefix'       => (string) ( $raw['key_prefix'] ?? substr( $license_key, 0, 8 ) ),
				'domain'           => (string) ( $raw['domain'] ?? self::current_domain() ),
				'buyer'            => (string) ( $raw['buyer'] ?? '' ),
				'expires'          => (string) ( $raw['expires'] ?? '' ),
				'activations'      => (int) ( $raw['activations'] ?? 0 ),
				'max_activations'  => (int) ( $raw['max_activations'] ?? 1 ),
				'features'         => is_array( $raw['features'] ?? null ) ? $raw['features'] : [],
				'last_verified_at' => (int) ( $raw['last_verified_at'] ?? 0 ),
				'last_error'       => (string) ( $raw['last_error'] ?? '' ),
				'server_sig'       => (string) ( $raw['server_sig'] ?? '' ),
			];

			// Verify tamper-evident local HMAC seal.
			$expected_seal       = self::compute_local_seal( $state );
			$stored_seal         = (string) ( $raw['local_seal'] ?? '' );
			$state['seal_valid'] = '' !== $stored_seal && hash_equals( $expected_seal, $stored_seal );

			if ( ! $state['seal_valid'] && $state['valid'] ) {
				$state['valid']      = false;
				$state['status']     = 'tampered';
				$state['last_error'] = __( 'Local license state seal mismatch; please re-verify your license.', 'directrelay-pro' );
			}

			// Check expiration date if set.
			if ( $state['valid'] && '' !== $state['expires'] ) {
				$exp_ts = strtotime( $state['expires'] . ' 23:59:59 UTC' );
				if ( $exp_ts && $exp_ts < time() ) {
					$state['valid']      = false;
					$state['status']     = 'expired';
					$state['last_error'] = __( 'License has expired.', 'directrelay-pro' );
				}
			}

			return $state;
		}

		/**
		 * Return sanitized public license status (safe for REST API / Admin UI without exposing raw key).
		 */
		public static function get_public_status(): array {
			$state  = self::get_state();
			$config = self::get_config();
			$key    = $state['license_key'];

			$masked = '';
			if ( '' !== $key ) {
				$len    = strlen( $key );
				$masked = $len > 12
					? substr( $key, 0, 8 ) . str_repeat( '•', max( 4, $len - 12 ) ) . substr( $key, -4 )
					: substr( $key, 0, 4 ) . '••••';
			}

			$is_dev_grace = ! $state['valid'] && ! $config['enforce_strict_gate'];

			return [
				'valid'               => $state['valid'],
				'is_active'           => self::is_active(),
				'status'              => $state['valid'] ? 'active' : ( $is_dev_grace ? 'grace_mode' : $state['status'] ),
				'plan'                => $state['plan'],
				'plan_label'          => $state['valid'] ? $state['plan_label'] : ( $is_dev_grace ? __( 'Testing / Grace Mode (Unlocked)', 'directrelay-pro' ) : $state['plan_label'] ),
				'key_prefix'          => $state['key_prefix'],
				'key_masked'          => $masked ?: __( 'Not Activated', 'directrelay-pro' ),
				'domain'              => self::current_domain(),
				'buyer'               => $state['buyer'],
				'expires'             => $state['expires'] ?: __( 'Lifetime / Never', 'directrelay-pro' ),
				'activations'         => $state['activations'],
				'max_activations'     => $state['max_activations'],
				'features'            => $state['features'],
				'seal_valid'          => $state['seal_valid'],
				'last_verified_at'    => $state['last_verified_at'] ? gmdate( 'Y-m-d H:i:s', $state['last_verified_at'] ) . ' UTC' : null,
				'last_error'          => $state['last_error'],
				'server_url'          => $config['server_url'],
				'verify_endpoint'     => self::endpoint_url( 'verify' ),
				'telemetry_endpoint'  => self::endpoint_url( 'telemetry' ),
				'hmac_configured'     => $config['hmac_configured'],
				'enforce_strict_gate' => $config['enforce_strict_gate'],
				'is_local_or_staging' => self::is_local_or_staging(),
				'site_uuid'           => self::site_uuid(),
			];
		}

		/**
		 * Check if DirectRelay Pro features are currently active and unlocked.
		 *
		 * Returns true when:
		 *   1. A cryptographically valid, non-expired Pro license is active, OR
		 *   2. Strict License Gate (`enforce_strict_gate`) is disabled (default for instant testing/staging).
		 */
		public static function is_active(): bool {
			$state = self::get_state();
			if ( $state['valid'] && $state['seal_valid'] ) {
				return true;
			}
			$config = self::get_config();
			if ( ! $config['enforce_strict_gate'] ) {
				return true;
			}
			return false;
		}

		/**
		 * Check if a specific feature or tier capability is allowed.
		 */
		public static function is_feature_allowed( string $feature = '' ): bool {
			if ( ! self::is_active() ) {
				return false;
			}
			$state = self::get_state();
			if ( $state['valid'] && ! empty( $state['features'] ) && isset( $state['features'][ $feature ] ) ) {
				return (bool) $state['features'][ $feature ];
			}
			return true;
		}

		/**
		 * Activate a Pro license key against `POST /wp-json/autonode-license/v1/verify`.
		 *
		 * @param string $license_key License key (e.g. `ANSOLO-XXXX-XXXX-XXXX`, `ANMKT-...`, `ANAGY-...`, `ANLTD-...`, `ANPRO-...`).
		 * @param string $buyer_email Optional buyer email address.
		 * @return array|\WP_Error
		 */
		public static function activate( string $license_key, string $buyer_email = '' ): array|\WP_Error {
			$license_key = strtoupper( trim( sanitize_text_field( $license_key ) ) );
			if ( '' === $license_key ) {
				return new \WP_Error(
					'directrelay_pro_empty_license',
					__( 'Please enter a valid AutoNode Pro license key.', 'directrelay-pro' ),
					[ 'status' => 400 ]
				);
			}

			// Validate key format (`AN*-XXXX-XXXX-XXXX` or general alphanumeric key).
			if ( strlen( $license_key ) < 8 ) {
				return new \WP_Error(
					'directrelay_pro_invalid_key_format',
					__( 'Invalid license key format. Expected e.g. ANPRO-XXXX-XXXX-XXXX or ANMKT-XXXX-XXXX-XXXX.', 'directrelay-pro' ),
					[ 'status' => 400 ]
				);
			}

			$cfg = self::get_config();
			if ( '' === $buyer_email ) {
				$buyer_email = $cfg['buyer_email'];
			} else {
				self::save_config( [ 'buyer_email' => $buyer_email ] );
			}

			$domain    = self::current_domain();
			$telemetry = self::build_telemetry_payload( $license_key, 'pro' );

			$request_body = array_merge(
				$telemetry,
				[
					'license_key' => $license_key,
					'domain'      => $domain,
					'buyer_email' => $buyer_email,
				]
			);

			$response = wp_remote_post(
				self::endpoint_url( 'verify' ),
				[
					'timeout'   => 15,
					'sslverify' => true,
					'headers'   => [
						'Content-Type' => 'application/json',
						'Accept'       => 'application/json',
						'User-Agent'   => 'DirectRelay-Pro/' . DIRECTRELAY_PRO_VERSION . '; ' . home_url(),
					],
					'body'      => wp_json_encode( $request_body ),
				]
			);

			if ( is_wp_error( $response ) ) {
				return new \WP_Error(
					'directrelay_pro_license_network_error',
					sprintf(
						/* translators: %s: HTTP transport error message */
						__( 'Could not reach AutoNode License Server: %s', 'directrelay-pro' ),
						$response->get_error_message()
					),
					[ 'status' => 502 ]
				);
			}

			$http_code = (int) wp_remote_retrieve_response_code( $response );
			$raw_body  = wp_remote_retrieve_body( $response );
			$data      = json_decode( $raw_body, true );

			if ( ! is_array( $data ) ) {
				return new \WP_Error(
					'directrelay_pro_license_bad_json',
					sprintf(
						/* translators: %d: HTTP status code */
						__( 'Unexpected response from AutoNode License Server (HTTP %d).', 'directrelay-pro' ),
						$http_code
					),
					[ 'status' => 502 ]
				);
			}

			if ( $http_code >= 400 || empty( $data['valid'] ) ) {
				$msg = sanitize_text_field( (string) ( $data['message'] ?? __( 'License verification failed.', 'directrelay-pro' ) ) );
				self::persist_invalid_state( $license_key, $http_code === 403 ? 'revoked_or_expired' : 'invalid', $msg );
				return new \WP_Error(
					'directrelay_pro_license_rejected',
					$msg,
					[ 'status' => $http_code >= 400 ? $http_code : 403 ]
				);
			}

			// Verify cryptographic HMAC-SHA256 signature & freshness if HMAC secret is configured.
			$sig_check = self::verify_server_signature( $data );
			if ( is_wp_error( $sig_check ) ) {
				return $sig_check;
			}

			// Verify domain binding in response.
			if ( ! empty( $data['domain'] ) && self::normalize_domain( (string) $data['domain'] ) !== $domain ) {
				return new \WP_Error(
					'directrelay_pro_license_domain_mismatch',
					__( 'License response domain does not match this site.', 'directrelay-pro' ),
					[ 'status' => 403 ]
				);
			}

			self::persist_valid_state( $license_key, $data );

			return self::get_public_status();
		}

		/**
		 * Re-verify the currently stored license key with the AutoNode License Server
		 * and sync embedded API key + webhook telemetry.
		 *
		 * Implements a 72-hour offline grace period if the license server is unreachable.
		 */
		public static function verify_remote( bool $force = false ): array|\WP_Error {
			$state = self::get_state();
			if ( '' === $state['license_key'] ) {
				return new \WP_Error(
					'directrelay_pro_no_license_key',
					__( 'No license key is currently configured.', 'directrelay-pro' ),
					[ 'status' => 400 ]
				);
			}

			$res = self::activate( $state['license_key'], $state['buyer'] );
			if ( is_wp_error( $res ) ) {
				// If it was a transient network error (502) and within the 72h grace window, preserve active state.
				if ( 'directrelay_pro_license_network_error' === $res->get_error_code() || 'directrelay_pro_license_bad_json' === $res->get_error_code() ) {
					$elapsed = time() - (int) $state['last_verified_at'];
					if ( $state['valid'] && $elapsed < self::GRACE_PERIOD_SEC ) {
						return self::get_public_status();
					}
				} elseif ( class_exists( '\DirectRelay\Pro\Agency_Governance_Engine' ) ) {
					Agency_Governance_Engine::dispatch_security_alert(
						'license.verification_failed',
						sprintf( 'AutoNode Pro License verification failed on %s: %s', self::current_domain(), $res->get_error_message() ),
						[
							'domain'     => self::current_domain(),
							'key_prefix' => $state['key_prefix'],
							'error'      => $res->get_error_message(),
						]
					);
				}
				return $res;
			}

			return $res;
		}

		/**
		 * Deactivate the current domain on the AutoNode License Server (`POST /autonode-license/v1/deactivate`)
		 * and clear local activation state.
		 */
		public static function deactivate(): array {
			$state       = self::get_state();
			$license_key = $state['license_key'];
			$domain      = self::current_domain();
			$remote_msg  = __( 'Local license state cleared.', 'directrelay-pro' );

			if ( '' !== $license_key ) {
				$response = wp_remote_post(
					self::endpoint_url( 'deactivate' ),
					[
						'timeout'   => 12,
						'sslverify' => true,
						'headers'   => [
							'Content-Type' => 'application/json',
							'Accept'       => 'application/json',
							'User-Agent'   => 'DirectRelay-Pro/' . DIRECTRELAY_PRO_VERSION . '; ' . home_url(),
						],
						'body'      => wp_json_encode( [
							'license_key' => $license_key,
							'domain'      => $domain,
						] ),
					]
				);

				if ( ! is_wp_error( $response ) ) {
					$body = json_decode( wp_remote_retrieve_body( $response ), true );
					if ( is_array( $body ) && ! empty( $body['message'] ) ) {
						$remote_msg = sanitize_text_field( (string) $body['message'] );
					}
				}
			}

			delete_option( self::STATE_OPTION );

			return [
				'deactivated' => true,
				'message'     => $remote_msg,
				'status'      => self::get_public_status(),
			];
		}

		/**
		 * Send telemetry heartbeat (`POST /autonode-license/v1/telemetry`) to sync API keys,
		 * request counts, webhooks, and system health with the AutoNode License Server.
		 */
		public static function send_telemetry(): array|\WP_Error {
			$state   = self::get_state();
			$tier    = $state['valid'] ? ( $state['plan'] ?: 'pro' ) : 'free';
			$payload = self::build_telemetry_payload( $state['license_key'], $tier );

			$response = wp_remote_post(
				self::endpoint_url( 'telemetry' ),
				[
					'timeout'   => 12,
					'sslverify' => true,
					'headers'   => [
						'Content-Type' => 'application/json',
						'Accept'       => 'application/json',
						'User-Agent'   => 'DirectRelay-Pro/' . DIRECTRELAY_PRO_VERSION . '; ' . home_url(),
					],
					'body'      => wp_json_encode( $payload ),
				]
			);

			if ( is_wp_error( $response ) ) {
				return new \WP_Error(
					'directrelay_pro_telemetry_error',
					$response->get_error_message(),
					[ 'status' => 502 ]
				);
			}

			$code = (int) wp_remote_retrieve_response_code( $response );
			$body = json_decode( wp_remote_retrieve_body( $response ), true );

			if ( $code >= 400 || ( is_array( $body ) && isset( $body['success'] ) && ! $body['success'] ) ) {
				$msg = is_array( $body ) && ! empty( $body['message'] ) ? (string) $body['message'] : "HTTP {$code}";
				// If site was blocked by administrator on the license server (`als_site_blocked` -> 403), revoke locally.
				if ( 403 === $code ) {
					self::persist_invalid_state( $state['license_key'], 'blocked', $msg );
				}
				return new \WP_Error( 'directrelay_pro_telemetry_rejected', $msg, [ 'status' => $code ?: 400 ] );
			}

			return [
				'synced'            => true,
				'domain'            => $payload['domain'],
				'tier'              => $tier,
				'api_keys_synced'   => count( $payload['api_keys'] ),
				'webhooks_synced'   => count( $payload['webhooks'] ),
				'total_api_calls'   => $payload['total_api_calls'],
				'server_response'   => $body,
			];
		}

		/**
		 * Register an unlicensed installation with `POST /autonode-license/v1/free-register`.
		 */
		public static function register_free_install(): void {
			$payload = self::build_telemetry_payload( '', 'free' );
			wp_remote_post(
				self::endpoint_url( 'free-register' ),
				[
					'timeout'   => 5,
					'blocking'  => false,
					'sslverify' => true,
					'headers'   => [
						'Content-Type' => 'application/json',
						'User-Agent'   => 'DirectRelay-Pro/' . DIRECTRELAY_PRO_VERSION . '; ' . home_url(),
					],
					'body'      => wp_json_encode( $payload ),
				]
			);
		}

		/**
		 * Ping the AutoNode License Server (`GET /autonode-license/v1/ping`) and check `/client-status`.
		 */
		public static function ping_server(): array {
			$start    = microtime( true );
			$response = wp_remote_get(
				self::endpoint_url( 'ping' ),
				[
					'timeout'   => 10,
					'sslverify' => true,
					'headers'   => [
						'Accept'     => 'application/json',
						'User-Agent' => 'DirectRelay-Pro/' . DIRECTRELAY_PRO_VERSION . '; ' . home_url(),
					],
				]
			);
			$latency = (int) round( ( microtime( true ) - $start ) * 1000 );

			if ( is_wp_error( $response ) ) {
				return [
					'reachable'  => false,
					'latency_ms' => $latency,
					'server_url' => self::get_config()['server_url'],
					'error'      => $response->get_error_message(),
				];
			}

			$code = (int) wp_remote_retrieve_response_code( $response );
			$body = json_decode( wp_remote_retrieve_body( $response ), true );

			// Also query `/client-status` for this domain.
			$status_resp = wp_remote_post(
				self::endpoint_url( 'client-status' ),
				[
					'timeout'   => 8,
					'sslverify' => true,
					'headers'   => [ 'Content-Type' => 'application/json' ],
					'body'      => wp_json_encode( [ 'domain' => self::current_domain() ] ),
				]
			);
			$client_status = ! is_wp_error( $status_resp )
				? json_decode( wp_remote_retrieve_body( $status_resp ), true )
				: null;

			return [
				'reachable'      => $code >= 200 && $code < 300 && is_array( $body ) && ( $body['status'] ?? '' ) === 'online',
				'http_status'    => $code,
				'latency_ms'     => $latency,
				'server_url'     => self::get_config()['server_url'],
				'server_version' => is_array( $body ) ? ( $body['version'] ?? null ) : null,
				'server_time'    => is_array( $body ) ? ( $body['time'] ?? null ) : null,
				'client_status'  => is_array( $client_status ) ? $client_status : null,
			];
		}

		/**
		 * Daily WP-Cron callback (`directrelay_pro_license_heartbeat`).
		 */
		public static function cron_heartbeat(): void {
			$state = self::get_state();
			if ( '' !== $state['license_key'] ) {
				self::verify_remote( false );
			} else {
				self::send_telemetry();
			}
		}

		/**
		 * Build the exact telemetry payload expected by `ALS_REST_API::verify()` and
		 * `ALS_Client_Manager::record_telemetry()` on the AutoNode License Server (`v2.2.0`).
		 *
		 * Maps Free's `directrelay_keys.request_count` -> `total_requests` & `total_calls`
		 * and `directrelay_webhooks.fire_count`/`fail_count` -> `total_deliveries`,
		 * `successful_deliveries`, and `failed_deliveries`.
		 */
		public static function build_telemetry_payload( string $license_key = '', string $tier = 'pro' ): array {
			global $wpdb, $wp_version;

			$raw_keys        = class_exists( '\DirectRelay\Api_Auth' ) ? Api_Auth::list_keys( 0, true ) : [];
			$mapped_keys     = [];
			$total_api_calls = 0;

			foreach ( $raw_keys as $k ) {
				$reqs             = absint( $k['total_requests'] ?? ( $k['request_count'] ?? 0 ) );
				$total_api_calls += $reqs;
				$scopes           = is_array( $k['scopes'] ?? null )
					? $k['scopes']
					: ( is_string( $k['scopes'] ?? null ) ? ( json_decode( $k['scopes'], true ) ?: [] ) : [] );
				$ip_wl            = is_array( $k['ip_whitelist'] ?? null )
					? $k['ip_whitelist']
					: ( is_string( $k['ip_whitelist'] ?? null ) ? array_values( array_filter( array_map( 'trim', explode( "\n", $k['ip_whitelist'] ) ) ) ) : [] );

				$mapped_keys[] = [
					'id'             => absint( $k['id'] ?? 0 ),
					'key_prefix'     => (string) ( $k['key_prefix'] ?? '' ),
					'label'          => (string) ( $k['label'] ?? '' ),
					'description'    => (string) ( $k['description'] ?? '' ),
					'environment'    => (string) ( $k['environment'] ?? 'production' ),
					'scopes'         => $scopes,
					'ip_whitelist'   => $ip_wl,
					'total_requests' => $reqs,
					'total_calls'    => $reqs,
					'last_used_at'   => $k['last_used_at'] ?? null,
					'last_used_ip'   => $k['last_used_ip'] ?? null,
					'expires_at'     => $k['expires_at'] ?? null,
					'created_at'     => $k['created_at'] ?? null,
					'revoked'        => ! empty( $k['revoked'] ) ? 1 : 0,
					'revoked_at'     => $k['revoked_at'] ?? null,
				];
			}

			$wh_table     = "{$wpdb->prefix}directrelay_webhooks";
			$raw_webhooks = [];
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wh_table ) ) === $wh_table ) {
				$raw_webhooks = $wpdb->get_results(
					"SELECT id, key_id, label, target_url, events, post_types, active, last_fired_at, last_status, fire_count, fail_count, created_at FROM {$wh_table} ORDER BY created_at DESC",
					ARRAY_A
				) ?: [];
			}

			$mapped_webhooks          = [];
			$total_webhook_deliveries = 0;

			foreach ( $raw_webhooks as $wh ) {
				$fires                    = absint( $wh['fire_count'] ?? 0 );
				$fails                    = absint( $wh['fail_count'] ?? 0 );
				$succ                     = max( 0, $fires - $fails );
				$http_code                = absint( $wh['last_status'] ?? ( $wh['last_status_code'] ?? 0 ) );
				$total_webhook_deliveries += $fires;
				$target_url               = (string) ( $wh['target_url'] ?? ( $wh['url'] ?? '' ) );
				$events                   = is_array( $wh['events'] ?? null )
					? $wh['events']
					: ( is_string( $wh['events'] ?? null ) ? ( json_decode( $wh['events'], true ) ?: [] ) : [] );
				$post_types               = is_array( $wh['post_types'] ?? null )
					? $wh['post_types']
					: ( is_string( $wh['post_types'] ?? null ) ? ( json_decode( $wh['post_types'], true ) ?: [] ) : [] );

				$mapped_webhooks[] = [
					'id'                    => absint( $wh['id'] ?? 0 ),
					'name'                  => (string) ( $wh['label'] ?? '' ),
					'label'                 => (string) ( $wh['label'] ?? '' ),
					'target_url'            => $target_url,
					'url'                   => $target_url,
					'events'                => $events,
					'post_types'            => $post_types,
					'active'                => ! empty( $wh['active'] ) ? 1 : 0,
					'total_deliveries'      => $fires,
					'successful_deliveries' => $succ,
					'failed_deliveries'     => $fails,
					'last_delivery_at'      => $wh['last_fired_at'] ?? null,
					'last_http_code'        => $http_code ?: null,
					'last_delivery_status'  => ( $http_code >= 200 && $http_code < 300 ) ? 'success' : ( $http_code > 0 ? 'failed' : 'pending' ),
					'created_at'            => $wh['created_at'] ?? null,
				];
			}

			$seo_providers = SEO_Write_Engine::detect_providers();

			return [
				'domain'                   => self::current_domain(),
				'site_uuid'                => self::site_uuid(),
				'site_url'                 => home_url(),
				'site_name'                => get_bloginfo( 'name' ),
				'admin_email'              => get_option( 'admin_email' ),
				'license_key'              => $license_key,
				'tier'                     => $tier,
				'wp_version'               => (string) ( $wp_version ?? get_bloginfo( 'version' ) ),
				'php_version'              => PHP_VERSION,
				'plugin_version'           => ( defined( 'DIRECTRELAY_VERSION' ) ? DIRECTRELAY_VERSION : '5.1.32' ) . '+pro-' . DIRECTRELAY_PRO_VERSION,
				'server_software'          => sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ?? 'PHP' ) ),
				'api_keys'                 => $mapped_keys,
				'webhooks'                 => $mapped_webhooks,
				'total_api_calls'          => $total_api_calls,
				'total_webhook_deliveries' => $total_webhook_deliveries,
				'system_info'              => [
					'pro_version'    => DIRECTRELAY_PRO_VERSION,
					'free_version'   => defined( 'DIRECTRELAY_VERSION' ) ? DIRECTRELAY_VERSION : 'unknown',
					'is_multisite'   => is_multisite(),
					'active_seo'     => array_keys( array_filter( $seo_providers['active'] ?? [] ) ),
					'woocommerce'    => class_exists( 'WooCommerce' ),
					'acf_pro'        => function_exists( 'acf_add_local_field_group' ),
					'memory_limit'   => defined( 'WP_MEMORY_LIMIT' ) ? WP_MEMORY_LIMIT : ini_get( 'memory_limit' ),
					'timezone'       => wp_timezone_string(),
				],
			];
		}

		/**
		 * Verify the HMAC-SHA256 `signature` returned by `ALS_Key_Manager::verify()` on the License Server.
		 */
		private static function verify_server_signature( array $payload ): bool|\WP_Error {
			// Verify timestamp freshness (within 5 minutes) if present and HMAC verification is enabled.
			$cfg         = self::get_config();
			$hmac_secret = $cfg['hmac_secret'];

			if ( '' === $hmac_secret ) {
				// If no client-side HMAC secret is configured, verify structural presence of signature & timestamp.
				if ( empty( $payload['signature'] ) || empty( $payload['timestamp'] ) ) {
					return new \WP_Error(
						'directrelay_pro_unsigned_response',
						__( 'License server response is missing cryptographic signature fields.', 'directrelay-pro' ),
						[ 'status' => 502 ]
					);
				}
				return true;
			}

			$remote_sig = (string) ( $payload['signature'] ?? '' );
			$timestamp  = (int) ( $payload['timestamp'] ?? 0 );

			if ( '' === $remote_sig || $timestamp <= 0 ) {
				return new \WP_Error(
					'directrelay_pro_missing_hmac',
					__( 'License server response is missing HMAC signature or timestamp.', 'directrelay-pro' ),
					[ 'status' => 403 ]
				);
			}

			if ( abs( time() - $timestamp ) > 300 ) {
				return new \WP_Error(
					'directrelay_pro_stale_hmac',
					__( 'License server response timestamp is outside the 5-minute replay window.', 'directrelay-pro' ),
					[ 'status' => 403 ]
				);
			}

			$unsigned = $payload;
			unset( $unsigned['signature'] );
			$expected_sig = hash_hmac( 'sha256', wp_json_encode( $unsigned ), $hmac_secret );

			if ( ! hash_equals( $expected_sig, $remote_sig ) ) {
				return new \WP_Error(
					'directrelay_pro_invalid_hmac',
					__( 'License server HMAC-SHA256 signature verification failed. Check your Server Verification Secret.', 'directrelay-pro' ),
					[ 'status' => 403 ]
				);
			}

			return true;
		}

		/**
		 * Persist a verified active license state with encrypted key and tamper-evident local seal.
		 */
		private static function persist_valid_state( string $license_key, array $server_data ): void {
			$state_for_seal = [
				'valid'            => true,
				'status'           => 'active',
				'plan'             => sanitize_key( (string) ( $server_data['plan'] ?? 'pro' ) ),
				'domain'           => self::current_domain(),
				'expires'          => sanitize_text_field( (string) ( $server_data['expires'] ?? '' ) ),
				'key_prefix'       => substr( $license_key, 0, 8 ),
				'last_verified_at' => time(),
			];

			$record = [
				'valid'            => true,
				'status'           => 'active',
				'plan'             => $state_for_seal['plan'],
				'plan_label'       => sanitize_text_field( (string) ( $server_data['plan_label'] ?? 'AutoNode Pro' ) ),
				'license_key_enc'  => self::encrypt_value( $license_key ),
				'key_prefix'       => $state_for_seal['key_prefix'],
				'domain'           => $state_for_seal['domain'],
				'buyer'            => sanitize_email( (string) ( $server_data['buyer'] ?? '' ) ),
				'expires'          => $state_for_seal['expires'],
				'activations'      => absint( $server_data['activations'] ?? 1 ),
				'max_activations'  => max( 1, absint( $server_data['max_activations'] ?? 1 ) ),
				'features'         => is_array( $server_data['features'] ?? null ) ? $server_data['features'] : [],
				'last_verified_at' => $state_for_seal['last_verified_at'],
				'last_error'       => '',
				'server_sig'       => sanitize_text_field( (string) ( $server_data['signature'] ?? '' ) ),
				'local_seal'       => self::compute_local_seal( $state_for_seal ),
			];

			update_option( self::STATE_OPTION, $record, false );
		}

		/**
		 * Persist an invalid/revoked/expired license state.
		 */
		private static function persist_invalid_state( string $license_key, string $status, string $error_msg ): void {
			$state_for_seal = [
				'valid'            => false,
				'status'           => $status,
				'plan'             => 'free',
				'domain'           => self::current_domain(),
				'expires'          => '',
				'key_prefix'       => substr( $license_key, 0, 8 ),
				'last_verified_at' => time(),
			];

			$record = [
				'valid'            => false,
				'status'           => $status,
				'plan'             => 'free',
				'plan_label'       => 'Unlicensed',
				'license_key_enc'  => '' !== $license_key ? self::encrypt_value( $license_key ) : '',
				'key_prefix'       => $state_for_seal['key_prefix'],
				'domain'           => $state_for_seal['domain'],
				'buyer'            => '',
				'expires'          => '',
				'activations'      => 0,
				'max_activations'  => 0,
				'features'         => [],
				'last_verified_at' => $state_for_seal['last_verified_at'],
				'last_error'       => $error_msg,
				'local_seal'       => self::compute_local_seal( $state_for_seal ),
			];

			update_option( self::STATE_OPTION, $record, false );
		}

		/**
		 * Compute a site-specific HMAC-SHA256 seal over the core license state fields.
		 */
		private static function compute_local_seal( array $state ): string {
			$material = implode(
				'|',
				[
					! empty( $state['valid'] ) ? '1' : '0',
					(string) ( $state['status'] ?? '' ),
					(string) ( $state['plan'] ?? '' ),
					(string) ( $state['domain'] ?? '' ),
					(string) ( $state['expires'] ?? '' ),
					(string) ( $state['key_prefix'] ?? '' ),
					(int) ( $state['last_verified_at'] ?? 0 ),
				]
			);
			$key = hash( 'sha256', wp_salt( 'auth' ) . wp_salt( 'secure_auth' ) . ABSPATH );
			return hash_hmac( 'sha256', $material, $key );
		}

		/**
		 * Encrypt a sensitive string at rest using `Webhook_Manager::encrypt_secret()` or AES-256-CBC.
		 */
		private static function encrypt_value( string $plain ): string {
			if ( '' === $plain ) {
				return '';
			}
			if ( class_exists( '\DirectRelay\Webhook_Manager' ) && method_exists( '\DirectRelay\Webhook_Manager', 'encrypt_secret' ) ) {
				return Webhook_Manager::encrypt_secret( $plain );
			}
			if ( function_exists( 'openssl_encrypt' ) ) {
				$key = substr( hash( 'sha256', wp_salt( 'auth' ) . wp_salt( 'secure_auth' ), true ), 0, 32 );
				$iv  = random_bytes( 16 );
				$enc = openssl_encrypt( $plain, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
				if ( false !== $enc ) {
					return 'enc:' . base64_encode( $iv . $enc );
				}
			}
			return base64_encode( $plain );
		}

		/**
		 * Decrypt a sensitive string stored at rest.
		 */
		private static function decrypt_value( string $cipher ): string {
			if ( '' === $cipher ) {
				return '';
			}
			if ( class_exists( '\DirectRelay\Webhook_Manager' ) && method_exists( '\DirectRelay\Webhook_Manager', 'decrypt_secret' ) && str_starts_with( $cipher, 'enc:' ) ) {
				return Webhook_Manager::decrypt_secret( $cipher );
			}
			if ( str_starts_with( $cipher, 'enc:' ) && function_exists( 'openssl_decrypt' ) ) {
				$raw = base64_decode( substr( $cipher, 4 ), true );
				if ( is_string( $raw ) && strlen( $raw ) > 16 ) {
					$key = substr( hash( 'sha256', wp_salt( 'auth' ) . wp_salt( 'secure_auth' ), true ), 0, 32 );
					$iv  = substr( $raw, 0, 16 );
					$dec = openssl_decrypt( substr( $raw, 16 ), 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
					if ( false !== $dec ) {
						return $dec;
					}
				}
			}
			$decoded = base64_decode( $cipher, true );
			return is_string( $decoded ) ? $decoded : '';
		}

		/**
		 * Enforce license gate on Pro REST routes when `enforce_strict_gate` is enabled.
		 */
		public static function enforce_rest_license_gate( mixed $response, array $handler, \WP_REST_Request $req ): mixed {
			if ( is_wp_error( $response ) ) {
				return $response;
			}
			$route = $req->get_route();
			if ( ! str_starts_with( $route, '/directrelay/v1/' ) ) {
				return $response;
			}
			// Always allow `/license/*` routes so users/automation can activate or check status.
			if ( str_starts_with( $route, '/directrelay/v1/license' ) ) {
				return $response;
			}
			// Check if callback belongs to a `DirectRelay\Pro\REST\*` controller.
			$cb = $handler['callback'] ?? null;
			$is_pro_route = is_array( $cb ) && isset( $cb[0] ) && is_string( $cb[0] ) && str_starts_with( $cb[0], 'DirectRelay\\Pro\\REST\\' );

			if ( $is_pro_route && ! self::is_active() ) {
				return new \WP_Error(
					'directrelay_pro_license_inactive',
					__( 'DirectRelay Pro license is not active. Activate your license under DirectRelay -> License & Fleet or POST /wp-json/directrelay/v1/license/activate.', 'directrelay-pro' ),
					[ 'status' => 403 ]
				);
			}
			return $response;
		}

		/* ── Admin AJAX Handlers ─────────────────────────────────────────────── */

		public static function ajax_activate_license(): void {
			check_ajax_referer( 'directrelay_pro_license_nonce', 'nonce' );
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'directrelay-pro' ) ], 403 );
			}

			$key   = sanitize_text_field( wp_unslash( $_POST['license_key'] ?? '' ) );
			$email = sanitize_email( wp_unslash( $_POST['buyer_email'] ?? '' ) );

			if ( ! empty( $_POST['server_url'] ) ) {
				self::save_config( [ 'server_url' => sanitize_text_field( wp_unslash( $_POST['server_url'] ) ) ] );
			}

			$res = self::activate( $key, $email );
			if ( is_wp_error( $res ) ) {
				wp_send_json_error( [
					'message' => $res->get_error_message(),
					'status'  => self::get_public_status(),
				], 400 );
			}

			wp_send_json_success( [
				'message' => __( 'License activated and verified with AutoNode License Server!', 'directrelay-pro' ),
				'status'  => $res,
			] );
		}

		public static function ajax_deactivate_license(): void {
			check_ajax_referer( 'directrelay_pro_license_nonce', 'nonce' );
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'directrelay-pro' ) ], 403 );
			}
			$res = self::deactivate();
			wp_send_json_success( $res );
		}

		public static function ajax_verify_license(): void {
			check_ajax_referer( 'directrelay_pro_license_nonce', 'nonce' );
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'directrelay-pro' ) ], 403 );
			}

			$state = self::get_state();
			if ( '' !== $state['license_key'] ) {
				$res = self::verify_remote( true );
				if ( is_wp_error( $res ) ) {
					wp_send_json_error( [ 'message' => $res->get_error_message(), 'status' => self::get_public_status() ], 400 );
				}
				wp_send_json_success( [
					'message' => __( 'License re-verified & fleet telemetry synced with AutoNode License Server.', 'directrelay-pro' ),
					'status'  => $res,
				] );
			} else {
				$tel = self::send_telemetry();
				if ( is_wp_error( $tel ) ) {
					wp_send_json_error( [ 'message' => $tel->get_error_message() ], 400 );
				}
				wp_send_json_success( [
					'message'   => __( 'Fleet telemetry heartbeat sent to AutoNode License Server.', 'directrelay-pro' ),
					'telemetry' => $tel,
					'status'    => self::get_public_status(),
				] );
			}
		}

		public static function ajax_ping_server(): void {
			check_ajax_referer( 'directrelay_pro_license_nonce', 'nonce' );
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'directrelay-pro' ) ], 403 );
			}
			$ping = self::ping_server();
			if ( empty( $ping['reachable'] ) ) {
				wp_send_json_error( [
					'message' => sprintf( __( 'License Server unreachable: %s', 'directrelay-pro' ), $ping['error'] ?? 'HTTP ' . ( $ping['http_status'] ?? 0 ) ),
					'ping'    => $ping,
				], 502 );
			}
			wp_send_json_success( [
				'message' => sprintf(
					/* translators: 1: server version, 2: latency in ms */
					__( 'Connected to AutoNode License Server v%1$s (%2$dms latency).', 'directrelay-pro' ),
					$ping['server_version'] ?? '2.2.0',
					$ping['latency_ms']
				),
				'ping'    => $ping,
			] );
		}

		public static function ajax_save_config(): void {
			check_ajax_referer( 'directrelay_pro_license_nonce', 'nonce' );
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'directrelay-pro' ) ], 403 );
			}

			$cfg = self::save_config( [
				'server_url'          => sanitize_text_field( wp_unslash( $_POST['server_url'] ?? self::DEFAULT_SERVER_URL ) ),
				'hmac_secret'         => sanitize_text_field( wp_unslash( $_POST['hmac_secret'] ?? '' ) ),
				'enforce_strict_gate' => ! empty( $_POST['enforce_strict_gate'] ),
				'buyer_email'         => sanitize_email( wp_unslash( $_POST['buyer_email'] ?? '' ) ),
			] );

			wp_send_json_success( [
				'message' => __( 'License server & security configuration saved.', 'directrelay-pro' ),
				'config'  => [
					'server_url'          => $cfg['server_url'],
					'hmac_configured'     => $cfg['hmac_configured'],
					'enforce_strict_gate' => $cfg['enforce_strict_gate'],
					'buyer_email'         => $cfg['buyer_email'],
				],
				'status'  => self::get_public_status(),
			] );
		}

		/**
		 * Render the dedicated **License & Fleet Link** admin page (`admin.php?page=directrelay-license`).
		 */
		public static function render_admin_page(): void {
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( esc_html__( 'Insufficient permissions.', 'directrelay-pro' ) );
			}

			$status    = self::get_public_status();
			$cfg       = self::get_config();
			$telemetry = self::build_telemetry_payload( '', $status['plan'] );
			$nonce     = wp_create_nonce( 'directrelay_pro_license_nonce' );
			?>
			<div class="directrelay-wrap" style="max-width:1160px;margin:20px auto;padding:0 16px;">
				<div class="directrelay-header" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:20px;">
					<div>
						<h1 style="margin:0;font-size:24px;display:flex;align-items:center;gap:10px;">
							<span class="dashicons dashicons-shield-alt" style="font-size:28px;width:28px;height:28px;color:#28CCCD;"></span>
							<?php esc_html_e( 'AutoNode License & Fleet Telemetry Link', 'directrelay-pro' ); ?>
						</h1>
						<p style="margin:4px 0 0;color:var(--directrelay-muted,#6b7280);font-size:13px;">
							<?php esc_html_e( 'Cryptographic HMAC-SHA256 license verification, AES-256-CBC key storage at rest, and real-time fleet telemetry sync with AutoNode License Server v2.2.0.', 'directrelay-pro' ); ?>
						</p>
					</div>
					<div style="display:flex;gap:8px;align-items:center;">
						<button type="button" class="button button-secondary" id="dr-pro-btn-ping">
							<span class="dashicons dashicons-cloud" style="vertical-align:text-bottom;"></span>
							<?php esc_html_e( 'Ping License Server', 'directrelay-pro' ); ?>
						</button>
						<button type="button" class="button button-secondary" id="dr-pro-btn-sync">
							<span class="dashicons dashicons-update" style="vertical-align:text-bottom;"></span>
							<?php esc_html_e( 'Re-Verify & Sync Telemetry Now', 'directrelay-pro' ); ?>
						</button>
					</div>
				</div>

				<div id="dr-pro-license-feedback" style="display:none;margin-bottom:16px;padding:12px 16px;border-radius:8px;font-weight:600;"></div>

				<!-- KPI Status Band -->
				<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;margin-bottom:24px;">
					<div class="directrelay-card" style="padding:18px;border-left:4px solid <?php echo $status['valid'] ? '#10b981' : ( $status['is_active'] ? '#3b82f6' : '#ef4444' ); ?>;">
						<div style="font-size:12px;text-transform:uppercase;color:var(--directrelay-muted,#6b7280);font-weight:600;"><?php esc_html_e( 'License State', 'directrelay-pro' ); ?></div>
						<div style="font-size:20px;font-weight:700;margin-top:6px;color:<?php echo $status['valid'] ? '#10b981' : ( $status['is_active'] ? '#3b82f6' : '#ef4444' ); ?>;">
							<?php
							if ( $status['valid'] ) {
								esc_html_e( 'Verified & Active', 'directrelay-pro' );
							} elseif ( $status['is_active'] ) {
								esc_html_e( 'Testing / Grace Mode', 'directrelay-pro' );
							} else {
								esc_html_e( 'Inactive (Locked)', 'directrelay-pro' );
							}
							?>
						</div>
						<div style="font-size:12px;color:var(--directrelay-muted,#6b7280);margin-top:4px;">
							<?php echo esc_html( $status['plan_label'] ); ?>
						</div>
					</div>

					<div class="directrelay-card" style="padding:18px;">
						<div style="font-size:12px;text-transform:uppercase;color:var(--directrelay-muted,#6b7280);font-weight:600;"><?php esc_html_e( 'Registered Domain', 'directrelay-pro' ); ?></div>
						<div style="font-size:18px;font-weight:700;margin-top:6px;font-family:monospace;"><?php echo esc_html( $status['domain'] ); ?></div>
						<div style="font-size:12px;color:var(--directrelay-muted,#6b7280);margin-top:4px;">
							<?php
							printf(
								/* translators: 1: active count, 2: max count */
								esc_html__( 'Activations: %1$d / %2$d site(s)', 'directrelay-pro' ),
								(int) $status['activations'],
								(int) max( 1, $status['max_activations'] )
							);
							?>
						</div>
					</div>

					<div class="directrelay-card" style="padding:18px;">
						<div style="font-size:12px;text-transform:uppercase;color:var(--directrelay-muted,#6b7280);font-weight:600;"><?php esc_html_e( 'Fleet Telemetry Snapshot', 'directrelay-pro' ); ?></div>
						<div style="font-size:18px;font-weight:700;margin-top:6px;">
							<?php echo esc_html( count( $telemetry['api_keys'] ) . ' Keys / ' . count( $telemetry['webhooks'] ) . ' Webhooks' ); ?>
						</div>
						<div style="font-size:12px;color:var(--directrelay-muted,#6b7280);margin-top:4px;">
							<?php
							printf(
								/* translators: 1: API calls, 2: Webhook deliveries */
								esc_html__( '%1$s API calls • %2$s WH deliveries', 'directrelay-pro' ),
								number_format( (int) $telemetry['total_api_calls'] ),
								number_format( (int) $telemetry['total_webhook_deliveries'] )
							);
							?>
						</div>
					</div>

					<div class="directrelay-card" style="padding:18px;">
						<div style="font-size:12px;text-transform:uppercase;color:var(--directrelay-muted,#6b7280);font-weight:600;"><?php esc_html_e( 'Expiry & Cryptographic Seal', 'directrelay-pro' ); ?></div>
						<div style="font-size:18px;font-weight:700;margin-top:6px;"><?php echo esc_html( $status['expires'] ); ?></div>
						<div style="font-size:12px;color:var(--directrelay-muted,#6b7280);margin-top:4px;">
							<?php
							echo $status['seal_valid']
								? '🔒 ' . esc_html__( 'AES-256 + Local HMAC Seal Verified', 'directrelay-pro' )
								: '🔓 ' . esc_html__( 'Awaiting License Activation', 'directrelay-pro' );
							?>
						</div>
					</div>
				</div>

				<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:start;">
					<!-- Left Card: License Key Activation & Deactivation -->
					<div class="directrelay-card" style="padding:22px;">
						<h2 style="margin-top:0;font-size:17px;">🔑 <?php esc_html_e( 'License Key Activation', 'directrelay-pro' ); ?></h2>
						<p style="font-size:13px;color:var(--directrelay-muted,#6b7280);">
							<?php esc_html_e( 'Enter your AutoNode Pro license key (ANSOLO-*, ANMKT-*, ANAGY-*, ANLTD-*, or ANPRO-*) generated on your AutoNode License Server.', 'directrelay-pro' ); ?>
						</p>
						<form id="dr-pro-activate-form">
							<table class="form-table" role="presentation">
								<tr>
									<th scope="row"><label for="dr-pro-license-key"><?php esc_html_e( 'License Key', 'directrelay-pro' ); ?></label></th>
									<td>
										<input type="text" id="dr-pro-license-key" name="license_key" class="regular-text" style="font-family:monospace;width:100%;" placeholder="ANMKT-XXXX-XXXX-XXXX" value="<?php echo esc_attr( $status['valid'] ? $status['key_masked'] : '' ); ?>" <?php echo $status['valid'] ? 'readonly' : ''; ?>>
									</td>
								</tr>
								<tr>
									<th scope="row"><label for="dr-pro-buyer-email"><?php esc_html_e( 'Buyer / Admin Email', 'directrelay-pro' ); ?></label></th>
									<td>
										<input type="email" id="dr-pro-buyer-email" name="buyer_email" class="regular-text" style="width:100%;" value="<?php echo esc_attr( $status['buyer'] ?: $cfg['buyer_email'] ); ?>">
									</td>
								</tr>
							</table>
							<div style="display:flex;gap:10px;margin-top:12px;">
								<?php if ( ! $status['valid'] ) : ?>
									<button type="submit" class="button button-primary button-large" id="dr-pro-btn-activate">
										<?php esc_html_e( 'Activate License on This Domain', 'directrelay-pro' ); ?>
									</button>
								<?php else : ?>
									<button type="button" class="button button-secondary button-large" id="dr-pro-btn-deactivate" style="color:#dc2626;border-color:#dc2626;">
										<?php esc_html_e( 'Deactivate License on This Domain', 'directrelay-pro' ); ?>
									</button>
								<?php endif; ?>
							</div>
						</form>

						<?php if ( ! empty( $status['last_error'] ) ) : ?>
							<div style="margin-top:14px;padding:10px 12px;background:rgba(239,68,68,0.1);border-left:3px solid #ef4444;color:#ef4444;font-size:13px;">
								<strong><?php esc_html_e( 'Last Notice:', 'directrelay-pro' ); ?></strong> <?php echo esc_html( $status['last_error'] ); ?>
							</div>
						<?php endif; ?>
					</div>

					<!-- Right Card: License Server Endpoint & Security Config -->
					<div class="directrelay-card" style="padding:22px;">
						<h2 style="margin-top:0;font-size:17px;">🛡️ <?php esc_html_e( 'License Server & Security Configuration', 'directrelay-pro' ); ?></h2>
						<form id="dr-pro-config-form">
							<table class="form-table" role="presentation">
								<tr>
									<th scope="row"><label for="dr-pro-server-url"><?php esc_html_e( 'License Server Base URL', 'directrelay-pro' ); ?></label></th>
									<td>
										<input type="url" id="dr-pro-server-url" name="server_url" class="regular-text" style="width:100%;font-family:monospace;" value="<?php echo esc_attr( $cfg['server_url'] ); ?>">
										<p class="description">
											<?php esc_html_e( 'Verify Endpoint:', 'directrelay-pro' ); ?>
											<code><?php echo esc_html( $status['verify_endpoint'] ); ?></code>
										</p>
									</td>
								</tr>
								<tr>
									<th scope="row"><label for="dr-pro-hmac-secret"><?php esc_html_e( 'Server Verification Secret (Optional HMAC)', 'directrelay-pro' ); ?></label></th>
									<td>
										<input type="password" id="dr-pro-hmac-secret" name="hmac_secret" class="regular-text" style="width:100%;font-family:monospace;" placeholder="<?php echo $cfg['hmac_configured'] ? '•••••••••••••••••••••••• (Configured)' : 'Optional: als_server_secret for strict HMAC check'; ?>">
										<p class="description">
											<?php esc_html_e( 'If set, DirectRelay Pro verifies the SHA-256 HMAC signature on every response from ALS_Key_Manager::verify().', 'directrelay-pro' ); ?>
										</p>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php esc_html_e( 'Strict License Gate', 'directrelay-pro' ); ?></th>
									<td>
										<label>
											<input type="checkbox" id="dr-pro-strict-gate" name="enforce_strict_gate" value="1" <?php checked( $cfg['enforce_strict_gate'] ); ?>>
											<?php esc_html_e( 'Require an activated license key before allowing Pro REST write endpoints (disable for instant local/staging testing).', 'directrelay-pro' ); ?>
										</label>
									</td>
								</tr>
							</table>
							<button type="submit" class="button button-primary" id="dr-pro-btn-save-cfg">
								<?php esc_html_e( 'Save Server & Security Config', 'directrelay-pro' ); ?>
							</button>
						</form>
					</div>
				</div>
			</div>

			<script>
			jQuery(function($){
				var nonce = <?php echo wp_json_encode( $nonce ); ?>;
				var $fb   = $('#dr-pro-license-feedback');

				function showNotice(msg, isError) {
					$fb.stop(true, true).css({
						display: 'block',
						background: isError ? 'rgba(239,68,68,0.12)' : 'rgba(16,185,129,0.12)',
						borderLeft: '4px solid ' + (isError ? '#ef4444' : '#10b981'),
						color: isError ? '#ef4444' : '#10b981'
					}).text(msg);
				}

				$('#dr-pro-activate-form').on('submit', function(e){
					e.preventDefault();
					var $btn = $('#dr-pro-btn-activate').prop('disabled', true).text('Verifying with License Server…');
					$.post(ajaxurl, {
						action: 'directrelay_pro_activate_license',
						nonce: nonce,
						license_key: $('#dr-pro-license-key').val(),
						buyer_email: $('#dr-pro-buyer-email').val(),
						server_url: $('#dr-pro-server-url').val()
					}).done(function(res){
						if (res.success) {
							showNotice(res.data.message, false);
							setTimeout(function(){ window.location.reload(); }, 900);
						} else {
							showNotice((res.data && res.data.message) ? res.data.message : 'Activation failed.', true);
							$btn.prop('disabled', false).text('Activate License on This Domain');
						}
					}).fail(function(xhr){
						var msg = (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ? xhr.responseJSON.data.message : 'Request failed.';
						showNotice(msg, true);
						$btn.prop('disabled', false).text('Activate License on This Domain');
					});
				});

				$('#dr-pro-btn-deactivate').on('click', function(){
					if (!confirm('Deactivate DirectRelay Pro on this domain?')) return;
					var $btn = $(this).prop('disabled', true).text('Deactivating…');
					$.post(ajaxurl, {
						action: 'directrelay_pro_deactivate_license',
						nonce: nonce
					}).done(function(res){
						showNotice(res.data && res.data.message ? res.data.message : 'Deactivated.', false);
						setTimeout(function(){ window.location.reload(); }, 800);
					});
				});

				$('#dr-pro-btn-sync').on('click', function(){
					var $btn = $(this).prop('disabled', true);
					$.post(ajaxurl, {
						action: 'directrelay_pro_verify_license',
						nonce: nonce
					}).done(function(res){
						if (res.success) {
							showNotice(res.data.message, false);
						} else {
							showNotice((res.data && res.data.message) ? res.data.message : 'Verification failed.', true);
						}
					}).fail(function(xhr){
						var msg = (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ? xhr.responseJSON.data.message : 'Sync failed.';
						showNotice(msg, true);
					}).always(function(){
						$btn.prop('disabled', false);
					});
				});

				$('#dr-pro-btn-ping').on('click', function(){
					var $btn = $(this).prop('disabled', true);
					$.post(ajaxurl, {
						action: 'directrelay_pro_ping_license_server',
						nonce: nonce
					}).done(function(res){
						if (res.success) {
							showNotice(res.data.message, false);
						} else {
							showNotice((res.data && res.data.message) ? res.data.message : 'Server unreachable.', true);
						}
					}).fail(function(xhr){
						var msg = (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ? xhr.responseJSON.data.message : 'License server ping failed.';
						showNotice(msg, true);
					}).always(function(){
						$btn.prop('disabled', false);
					});
				});

				$('#dr-pro-config-form').on('submit', function(e){
					e.preventDefault();
					var $btn = $('#dr-pro-btn-save-cfg').prop('disabled', true).text('Saving…');
					$.post(ajaxurl, {
						action: 'directrelay_pro_save_license_config',
						nonce: nonce,
						server_url: $('#dr-pro-server-url').val(),
						hmac_secret: $('#dr-pro-hmac-secret').val(),
						enforce_strict_gate: $('#dr-pro-strict-gate').is(':checked') ? 1 : 0,
						buyer_email: $('#dr-pro-buyer-email').val()
					}).done(function(res){
						if (res.success) {
							showNotice(res.data.message, false);
							setTimeout(function(){ window.location.reload(); }, 800);
						} else {
							showNotice('Could not save settings.', true);
						}
					}).always(function(){
						$btn.prop('disabled', false).text('Save Server & Security Config');
					});
				});
			});
			</script>
			<?php
		}
	}
	}
}

namespace DirectRelay\Pro\REST {

	defined( 'ABSPATH' ) || exit;

	use DirectRelay\Pro\License_Manager;

	/**
	 * REST Controller for AutoNode License Activation, Deactivation, Telemetry Sync & Server Ping
	 *
	 * Endpoints:
	 *   - `GET  /wp-json/directrelay/v1/license/status`
	 *   - `POST /wp-json/directrelay/v1/license/activate`
	 *   - `POST /wp-json/directrelay/v1/license/deactivate`
	 *   - `POST /wp-json/directrelay/v1/license/verify`
	 *   - `POST /wp-json/directrelay/v1/license/telemetry`
	 *   - `GET  /wp-json/directrelay/v1/license/ping`
	 */
	if ( ! class_exists( '\DirectRelay\Pro\REST\License_Controller', false ) ) {
	final class License_Controller extends Pro_Base_Controller {

		public static function register(): void {
			register_rest_route(
				self::NS,
				'/license/status',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'status' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'system:read' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/license/activate',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'activate' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'keys:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/license/deactivate',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'deactivate' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'keys:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/license/verify',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'verify' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'keys:write' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/license/telemetry',
				[
					[
						'methods'             => \WP_REST_Server::CREATABLE,
						'callback'            => [ self::class, 'telemetry' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'system:read' ),
					],
				]
			);

			register_rest_route(
				self::NS,
				'/license/ping',
				[
					[
						'methods'             => \WP_REST_Server::READABLE,
						'callback'            => [ self::class, 'ping' ],
						'permission_callback' => fn( \WP_REST_Request $r ) => self::guard( $r, 'system:read' ),
					],
				]
			);
		}

		public static function status( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			return self::ok( $req, License_Manager::get_public_status(), 200, 'license_status' );
		}

		public static function activate( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$body = $req->get_json_params() ?: [];

			$cfg_updates = [];
			if ( ! empty( $body['server_url'] ) ) {
				$cfg_updates['server_url'] = (string) $body['server_url'];
			}
			if ( isset( $body['hmac_secret'] ) ) {
				$cfg_updates['hmac_secret'] = (string) $body['hmac_secret'];
			}
			if ( isset( $body['enforce_strict_gate'] ) ) {
				$cfg_updates['enforce_strict_gate'] = (bool) $body['enforce_strict_gate'];
			}
			if ( ! empty( $cfg_updates ) ) {
				License_Manager::save_config( $cfg_updates );
			}

			$key   = (string) ( $body['license_key'] ?? '' );
			$email = (string) ( $body['buyer_email'] ?? '' );

			$res = License_Manager::activate( $key, $email );
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'license_activate' );
			}

			return self::ok( $req, $res, 200, 'license_activate' );
		}

		public static function deactivate( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			return self::ok( $req, License_Manager::deactivate(), 200, 'license_deactivate' );
		}

		public static function verify( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$res = License_Manager::verify_remote( true );
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'license_verify' );
			}
			return self::ok( $req, $res, 200, 'license_verify' );
		}

		public static function telemetry( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			$res = License_Manager::send_telemetry();
			if ( is_wp_error( $res ) ) {
				return self::fail( $req, $res, 'license_telemetry' );
			}
			return self::ok( $req, $res, 200, 'license_telemetry' );
		}

		public static function ping( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
			return self::ok( $req, License_Manager::ping_server(), 200, 'license_ping' );
		}
	}
	}
}
namespace DirectRelay\Pro {

	defined( 'ABSPATH' ) || exit;

	// Load bundled core files after all Pro & Bridge classes are registered.
	if ( class_exists( '\DirectRelay\Pro\Plugin', false ) && method_exists( '\DirectRelay\Pro\Plugin', 'load_bundled_core' ) ) {
		Plugin::load_bundled_core();
	}

	// Boot DirectRelay Pro on `plugins_loaded` priority 20.
	add_action(
		'plugins_loaded',
		static function (): void {
			try {
				if ( class_exists( '\DirectRelay\Pro\Plugin', false ) ) {
					Plugin::init();
				}
			} catch ( \Throwable $e ) {
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG && function_exists( 'error_log' ) ) {
					@error_log( '[DirectRelay Pro] Boot error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );
				}
			}
		},
		20
	);

	// Safe Activation Hook (never throws uncaught exceptions or unexpected output).
	register_activation_hook(
		__FILE__,
		static function ( $network_wide = false ): void {
			try {
				if ( class_exists( '\DirectRelay\Pro\Plugin', false ) && method_exists( '\DirectRelay\Pro\Plugin', 'load_bundled_core' ) ) {
					Plugin::load_bundled_core();
				}
				if ( class_exists( '\DirectRelay\Installer', false ) && method_exists( '\DirectRelay\Installer', 'activate' ) ) {
					\DirectRelay\Installer::activate( (bool) $network_wide );
				}
				if ( class_exists( '\DirectRelay\Pro\License_Manager', false ) && method_exists( '\DirectRelay\Pro\License_Manager', 'on_plugin_activate' ) ) {
					License_Manager::on_plugin_activate( (bool) $network_wide );
				}
			} catch ( \Throwable $e ) {
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG && function_exists( 'error_log' ) ) {
					@error_log( '[DirectRelay Pro] Activation error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );
				}
			}
		}
	);

	// Safe Deactivation Hook.
	register_deactivation_hook(
		__FILE__,
		static function (): void {
			try {
				if ( class_exists( '\DirectRelay\Pro\License_Manager', false ) && method_exists( '\DirectRelay\Pro\License_Manager', 'on_plugin_deactivate' ) ) {
					License_Manager::on_plugin_deactivate();
				}
			} catch ( \Throwable $e ) {
				// Ignore deactivation errors.
			}
		}
	);
}
