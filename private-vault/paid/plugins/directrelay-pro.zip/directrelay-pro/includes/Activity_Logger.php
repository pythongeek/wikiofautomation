<?php
namespace DirectRelay;

defined( 'ABSPATH' ) || exit;

final class Activity_Logger {

    public static function init(): void {
        if ( ! wp_next_scheduled( 'directrelay_prune_logs' ) ) {
            wp_schedule_event( time(), 'daily', 'directrelay_prune_logs' );
        }
        add_action( 'directrelay_prune_logs', array( __CLASS__, 'prune' ) );
    }

    public static function write( array $d ): void {
        global $wpdb;

        $key_id     = isset( $d['key_id'] )      ? (int) $d['key_id']      : null;
        $user_id    = isset( $d['user_id'] )     ? (int) $d['user_id']     : null;
        $obj_id     = isset( $d['object_id'] )   ? (int) $d['object_id']   : null;
        $status     = isset( $d['http_status'] ) ? (int) $d['http_status'] : 200;
        $ms         = isset( $d['duration_ms'] ) ? (int) $d['duration_ms'] : null;
        $req_uuid   = isset( $d['request_uuid'] ) ? sanitize_text_field( $d['request_uuid'] ) : null;
        $payload    = isset( $d['request_payload'] ) ? wp_json_encode( $d['request_payload'] ) : null;
        $trace      = isset( $d['execution_trace'] ) ? wp_json_encode( $d['execution_trace'] ) : null;
        $is_replay  = ! empty( $d['is_replay'] ) ? 1 : 0;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- custom table, not cacheable.
        $wpdb->insert( "{$wpdb->prefix}directrelay_log", array(
            'request_uuid'    => $req_uuid,
            'key_id'          => $key_id,
            'user_id'         => $user_id,
            'ip_address'      => Api_Auth::client_ip(),
            'method'          => strtoupper( sanitize_key( $d['method'] ?? 'GET' ) ),
            'endpoint'        => sanitize_text_field( $d['endpoint'] ?? '' ),
            'action'          => sanitize_key( $d['action'] ?? '' ),
            'object_type'     => isset( $d['object_type'] ) ? sanitize_key( $d['object_type'] ) : null,
            'object_id'       => $obj_id,
            'http_status'     => $status,
            'response_msg'    => isset( $d['response_msg'] ) ? substr( sanitize_text_field( $d['response_msg'] ), 0, 500 ) : null,
            'duration_ms'     => $ms,
            'request_payload' => $payload,
            'execution_trace' => $trace,
            'is_replay'       => $is_replay,
            'created_at'      => current_time( 'mysql', true ),
        ), array( '%s', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%d', '%s', '%s', '%d', '%s' ) );

        /* Analytics bucket */
        if ( null !== $key_id ) {
            $bucket = gmdate( 'Y-m-d H:00:00' );
            $ep     = substr( sanitize_key( str_replace( '/', '_', $d['endpoint'] ?? '' ) ), 0, 128 );
            $ana    = "{$wpdb->prefix}directrelay_analytics";
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- custom table, ON DUPLICATE KEY not supportable via WP API.
            $wpdb->query( $wpdb->prepare(
                "INSERT INTO {$wpdb->prefix}directrelay_analytics (bucket_hour,key_id,endpoint,method,http_status,hits,total_ms) VALUES(%s,%d,%s,%s,%d,1,%d) ON DUPLICATE KEY UPDATE hits=hits+1, total_ms=total_ms+%d",
                $bucket, $key_id, $ep, strtoupper( sanitize_key( $d['method'] ?? 'GET' ) ), $status, $ms ?? 0, $ms ?? 0
            ) );
        }
    }

    public static function query( array $args = array() ): array {
        global $wpdb;
        $t = "{$wpdb->prefix}directrelay_log";
        $w = array( '1=1' );
        $v = array();
        if ( ! empty( $args['key_id'] ) )     { $w[] = 'key_id = %d';      $v[] = (int) $args['key_id']; }
        if ( ! empty( $args['action'] ) )      { $w[] = 'action = %s';      $v[] = $args['action']; }
        if ( ! empty( $args['object_type'] ) ) { $w[] = 'object_type = %s'; $v[] = $args['object_type']; }
        if ( ! empty( $args['http_status'] ) ) { $w[] = 'http_status = %d'; $v[] = (int) $args['http_status']; }
        if ( ! empty( $args['date_from'] ) )   { $w[] = 'created_at >= %s'; $v[] = $args['date_from']; }

        $limit  = min( (int) ( $args['limit'] ?? 50 ), 500 );
        $offset = (int) ( $args['offset'] ?? 0 );
        $clause = implode( ' AND ', $w );
        $v[]    = $limit;
        $v[]    = $offset;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, PluginCheck.Security.DirectDB.UnescapedDBParameter -- dynamic WHERE built from allow-listed columns above; custom table.
        return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}directrelay_log WHERE $clause ORDER BY created_at DESC LIMIT %d OFFSET %d", ...$v ), ARRAY_A ) ?: array();
    }

    public static function summary(): array {
        global $wpdb;
        $today_utc             = gmdate( 'Y-m-d 00:00:00' );
        $seven_days_ago        = gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS );
        $twenty_four_hours_ago = gmdate( 'Y-m-d H:i:s', time() - 24 * HOUR_IN_SECONDS );

        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $log_today = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}directrelay_log WHERE created_at >= %s", $today_utc ) );
        $ana_today = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(hits), 0) FROM {$wpdb->prefix}directrelay_analytics WHERE bucket_hour >= %s", $today_utc ) );
        $requests_today = max( $log_today, $ana_today );

        $log_week = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}directrelay_log WHERE created_at >= %s", $seven_days_ago ) );
        $ana_week = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(hits), 0) FROM {$wpdb->prefix}directrelay_analytics WHERE bucket_hour >= %s", $seven_days_ago ) );
        $requests_week = max( $log_week, $ana_week );

        $errors_24h = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}directrelay_log WHERE http_status >= 400 AND created_at >= %s", $twenty_four_hours_ago ) );
        if ( 0 === $errors_24h ) {
            $errors_24h = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(hits), 0) FROM {$wpdb->prefix}directrelay_analytics WHERE http_status >= 400 AND bucket_hour >= %s", $twenty_four_hours_ago ) );
        }

        $avg_ms = (float) $wpdb->get_var( $wpdb->prepare( "SELECT AVG(total_ms/hits) FROM {$wpdb->prefix}directrelay_analytics WHERE bucket_hour >= %s", $twenty_four_hours_ago ) );
        if ( ! $avg_ms ) {
            $avg_ms = (float) $wpdb->get_var( $wpdb->prepare( "SELECT AVG(duration_ms) FROM {$wpdb->prefix}directrelay_log WHERE duration_ms IS NOT NULL AND created_at >= %s", $twenty_four_hours_ago ) );
        }
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        return array(
            'requests_today'  => $requests_today,
            'requests_week'   => $requests_week,
            'errors_24h'      => $errors_24h,
            'avg_response_ms' => (float) round( $avg_ms, 1 ),
        );
    }

    public static function hourly_stats( int $hours = 24, ?int $key_id = null ): array {
        global $wpdb;
        /* PHP-side date math for SQLite portability (the wp-sqlite-db shim
           cannot translate DATE_SUB/UTC_TIMESTAMP). bucket_hour is UTC. */
        $cutoff = gmdate( 'Y-m-d H:00:00', time() - $hours * HOUR_IN_SECONDS );
        if ( $key_id ) {
            $query = $wpdb->prepare(
                "SELECT bucket_hour, SUM(hits) as hits, SUM(total_ms) as total_ms, SUM(CASE WHEN http_status >= 400 THEN hits ELSE 0 END) as errors FROM {$wpdb->prefix}directrelay_analytics WHERE bucket_hour >= %s AND key_id = %d GROUP BY bucket_hour ORDER BY bucket_hour ASC",
                $cutoff,
                $key_id
            );
        } else {
            $query = $wpdb->prepare(
                "SELECT bucket_hour, SUM(hits) as hits, SUM(total_ms) as total_ms, SUM(CASE WHEN http_status >= 400 THEN hits ELSE 0 END) as errors FROM {$wpdb->prefix}directrelay_analytics WHERE bucket_hour >= %s GROUP BY bucket_hour ORDER BY bucket_hour ASC",
                $cutoff
            );
        }
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
        return $wpdb->get_results( $query, ARRAY_A ) ?: array();
    }

    public static function top_endpoints( int $days = 7 ): array {
        global $wpdb;
        /* PHP-side date math for SQLite portability. */
        $cutoff = gmdate( 'Y-m-d H:00:00', time() - $days * DAY_IN_SECONDS );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- custom table.
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT endpoint, method, SUM(hits) as hits, AVG(total_ms/hits) as avg_ms FROM {$wpdb->prefix}directrelay_analytics WHERE bucket_hour >= %s GROUP BY endpoint,method ORDER BY hits DESC LIMIT 10",
            $cutoff
        ), ARRAY_A ) ?: array();
    }

    public static function prune(): void {
        global $wpdb;
        $days = (int) get_option( 'directrelay_log_retention_days', 30 );
        /* PHP-side date math for SQLite portability; created_at/bucket_hour are UTC. */
        $cutoff = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );

        /* Prune standard logs */
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- bulk delete on custom table.
        $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}directrelay_log WHERE created_at < %s", $cutoff ) );

        /* Prune analytics (uses bucket_hour instead of created_at) */
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- bulk delete on custom table.
        $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}directrelay_analytics WHERE bucket_hour < %s", $cutoff ) );

        /* Safety cap: hard bound on table growth regardless of retention days
           (matches the export cap). Two-step portable delete — no self-join. */
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table.
        $boundary = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}directrelay_log ORDER BY id DESC LIMIT 1 OFFSET %d", 10000 ) );
        if ( $boundary ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- bulk delete on custom table.
            $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}directrelay_log WHERE id < %d", (int) $boundary ) );
        }
    }

    public static function export( string $format = 'csv' ): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Forbidden', 'directrelay-automation-bridge-for-n8n' ) );
        }

        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- export needs all rows, no caching needed
        $logs = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}directrelay_log ORDER BY created_at DESC LIMIT 10000", ARRAY_A );
        if ( ! $logs ) return;

        $filename = 'directrelay-logs-' . current_time( 'Y-m-d' );

        if ( 'json' === $format ) {
            header( 'Content-Type: application/json' );
            header( 'Content-Disposition: attachment; filename="' . $filename . '.json"' );
            echo wp_json_encode( $logs );
            exit;
        }

        header( 'Content-Type: text/csv' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '.csv"' );
        $out = fopen( 'php://output', 'w' );
        fputcsv( $out, array_keys( $logs[0] ) );
        foreach ( $logs as $row ) fputcsv( $out, $row );
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- php://output is not a real filesystem path
        fclose( $out );
        exit;
    }
}
