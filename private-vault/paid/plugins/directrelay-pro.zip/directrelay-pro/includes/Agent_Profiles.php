<?php
namespace DirectRelay;

defined( 'ABSPATH' ) || exit;

/**
 * AI Agent Permission Profiles & Identity Layer.
 *
 * Implements strict agent personas (Content Agent, SEO Agent, Publishing Agent)
 * with endpoint-level permission controls, post-ownership isolation, and
 * action-level safeguards.
 *
 * @since 5.0.0
 */
final class Agent_Profiles {

    public const ROLE_FULL_ACCESS       = 'full_access';
    public const ROLE_CONTENT_AGENT     = 'content_agent';
    public const ROLE_SEO_AGENT         = 'seo_agent';
    public const ROLE_PUBLISHING_AGENT  = 'publishing_agent';
    public const ROLE_CUSTOM_AGENT      = 'custom_agent';

    /**
     * Get list of all available agent roles with metadata.
     */
    public static function get_roles(): array {
        return [
            self::ROLE_FULL_ACCESS => [
                'name'        => __( 'Full Access Key', 'directrelay-automation-bridge-for-n8n' ),
                'description' => __( 'Unrestricted access to all permitted endpoints and actions.', 'directrelay-automation-bridge-for-n8n' ),
                'icon'        => 'dashicons-shield',
                'badge'       => 'All Scopes',
                'scopes'      => Api_Auth::SCOPES,
            ],
            self::ROLE_CONTENT_AGENT => [
                'name'        => __( 'AI Content Agent', 'directrelay-automation-bridge-for-n8n' ),
                'description' => __( 'Can create/edit drafts, upload media, assign categories/tags. Cannot publish directly or delete.', 'directrelay-automation-bridge-for-n8n' ),
                'icon'        => 'dashicons-edit',
                'badge'       => 'Drafts Only',
                'scopes'      => [
                    'posts:read', 'posts:write',
                    'pages:read', 'pages:write',
                    'media:read', 'media:write',
                    'taxonomy:read', 'taxonomy:write',
                    'system:read', 'bulk:write',
                ],
                'forbidden_statuses' => [ 'publish', 'future', 'trash' ],
            ],
            self::ROLE_SEO_AGENT => [
                'name'        => __( 'AI SEO Agent', 'directrelay-automation-bridge-for-n8n' ),
                'description' => __( 'Can read posts and modify SEO metadata, canonicals, and schema. Cannot create posts or publish.', 'directrelay-automation-bridge-for-n8n' ),
                'icon'        => 'dashicons-chart-area',
                'badge'       => 'SEO Only',
                'scopes'      => [
                    'posts:read', 'pages:read',
                    'seo:read', 'seo:write',
                    'taxonomy:read', 'system:read',
                ],
            ],
            self::ROLE_PUBLISHING_AGENT => [
                'name'        => __( 'AI Publishing Agent', 'directrelay-automation-bridge-for-n8n' ),
                'description' => __( 'Can publish and schedule approved drafts. Cannot delete posts or modify site settings.', 'directrelay-automation-bridge-for-n8n' ),
                'icon'        => 'dashicons-megaphone',
                'badge'       => 'Publishing',
                'scopes'      => [
                    'posts:read', 'posts:publish',
                    'pages:read', 'system:read',
                ],
            ],
            self::ROLE_CUSTOM_AGENT => [
                'name'        => __( 'Custom Agent Profile', 'directrelay-automation-bridge-for-n8n' ),
                'description' => __( 'Fine-grained custom permission scopes configured individually.', 'directrelay-automation-bridge-for-n8n' ),
                'icon'        => 'dashicons-admin-generic',
                'badge'       => 'Custom Matrix',
                'scopes'      => [],
            ],
        ];
    }

    /**
     * Resolve effective scopes for a key based on its agent role.
     */
    public static function get_role_scopes( string $role ): array {
        $roles = self::get_roles();
        return $roles[ $role ]['scopes'] ?? [];
    }

    /**
     * Verify whether an API key identity is allowed to perform a specific action.
     *
     * @param array    $key     Authenticated key row.
     * @param string   $action  Action identifier (e.g. 'posts:publish', 'posts:create_draft').
     * @param int|null $post_id Optional post ID for ownership verification.
     * @return true|\WP_Error
     */
    public static function can_perform( array $key, string $action, ?int $post_id = null ): bool|\WP_Error {
        $role = $key['agent_role'] ?? self::ROLE_FULL_ACCESS;

        // Agent personas (non-FULL_ACCESS) are an add-on feature. The free
        // plugin has only the FULL_ACCESS role, so any non-default role
        // means the add-on plugin is extending the agent profile. The free
        // plugin here just allows the action through.

        // 2. Role-specific constraints
        if ( self::ROLE_CONTENT_AGENT === $role ) {
            if ( in_array( $action, [ 'posts:publish', 'pages:publish', 'posts:delete', 'pages:delete', 'settings:write' ], true ) ) {
                return new \WP_Error(
                    'amp_agent_forbidden',
                    __( 'AI Content Agent is restricted to draft creation and cannot publish or delete content.', 'directrelay-automation-bridge-for-n8n' ),
                    [ 'status' => 403 ]
                );
            }
        }

        if ( self::ROLE_SEO_AGENT === $role ) {
            if ( in_array( $action, [ 'posts:create', 'posts:delete', 'posts:publish', 'pages:create', 'pages:delete' ], true ) ) {
                return new \WP_Error(
                    'amp_agent_forbidden',
                    __( 'AI SEO Agent is restricted to metadata optimization and cannot create, publish, or delete posts.', 'directrelay-automation-bridge-for-n8n' ),
                    [ 'status' => 403 ]
                );
            }
        }

        // 3. Post Ownership Isolation check
        if ( $post_id && ! empty( $key['restrict_own_posts'] ) ) {
            return self::assert_owns( $key, $post_id );
        }

        return true;
    }

    /**
     * Post Ownership Isolation enforcement for a specific post.
     *
     * Called from the REST controllers once the target post ID is known
     * (guard() runs before the route resolves an ID, so it cannot pass one).
     * Keys without the restriction always pass; a restricted key may only
     * manage posts stamped with its own key ID — unstamped (admin-created)
     * content stays shared.
     *
     * @return true|\WP_Error
     */
    public static function assert_owns( array $key, int $post_id ): bool|\WP_Error {
        if ( empty( $key['restrict_own_posts'] ) ) {
            return true;
        }
        $creator_key_id = (int) get_post_meta( $post_id, '_directrelay_created_by_key', true );
        if ( $creator_key_id > 0 && $creator_key_id !== (int) ( $key['id'] ?? 0 ) ) {
            return new \WP_Error(
                'amp_ownership_restricted',
                __( 'This API Agent is restricted to managing only content created by its own API key.', 'directrelay-automation-bridge-for-n8n' ),
                [ 'status' => 403 ]
            );
        }
        return true;
    }

    /**
     * Stamp post with creator API Key identity and agent role metadata.
     */
    public static function stamp_post( int $post_id, array $key ): void {
        if ( empty( $key['id'] ) ) {
            return;
        }
        update_post_meta( $post_id, '_directrelay_created_by_key', (int) $key['id'] );
        update_post_meta( $post_id, '_directrelay_agent_role', sanitize_key( $key['agent_role'] ?? 'full_access' ) );
        update_post_meta( $post_id, '_directrelay_agent_label', sanitize_text_field( $key['label'] ?? 'API Agent' ) );
    }

    /**
     * Check if a requested post status is permitted for this agent.
     */
    public static function is_status_allowed( array $key, string $status ): bool {
        $role = $key['agent_role'] ?? self::ROLE_FULL_ACCESS;
        if ( self::ROLE_CONTENT_AGENT === $role && in_array( $status, [ 'publish', 'future' ], true ) ) {
            return false;
        }
        return true;
    }
}
