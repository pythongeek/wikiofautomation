<?php
namespace DirectRelay;

defined( 'ABSPATH' ) || exit;

final class Api_Auth {

    public const PREFIX = 'ampcm_';

    public const SCOPES = [
        'posts:read', 'posts:write', 'posts:delete', 'posts:publish',
        'pages:read', 'pages:write', 'pages:delete',
        'seo:read', 'seo:write',
        'media:read', 'media:write', 'media:delete',
        'taxonomy:read', 'taxonomy:write',
        'bulk:write',
        'webhooks:read', 'webhooks:write',
        'analytics:read',
        'keys:read', 'keys:write', 'keys:rotate',
        'system:read',
        'approval:read', 'approval:write',
        'debugger:read', 'debugger:write',
        'universal:write',
    ];

    public const PRESET_SCOPES = [
        'readonly' => [
            'posts:read', 'pages:read', 'seo:read', 'media:read',
            'taxonomy:read', 'analytics:read', 'system:read', 'approval:read',
        ],
        'writer' => [
            'posts:read', 'posts:write', 'posts:publish',
            'pages:read', 'pages:write',
            'seo:read', 'seo:write',
            'media:read', 'media:write',
            'taxonomy:read', 'taxonomy:write',
            'bulk:write', 'system:read', 'universal:write',
        ],
        'full_access' => [], // empty = all scopes granted
    ];

    /* ── Key Generation ─────────────────────────────────────────────── */

    public static function generate_raw(): string {
        return self::PREFIX . bin2hex( random_bytes( 32 ) );
    }

    public static function hash_key( string $raw ): string {
        return hash( 'sha256', $raw );
    }

    /* ── Create ─────────────────────────────────────────────────────── */

    public static function create( array $args ): array {
        global $wpdb;
        // The free plugin allows unlimited active API keys.
        // A previous per-site cap (1 active key on free) was removed
        // because the WP.org Plugin Directory Guidelines forbid usage
        // limits in the free build. The directrelay-pro add-on may
        // re-introduce a limit via the `directrelay_ext_guardrails_check`
        // filter.
        $raw    = self::generate_raw();
        $scopes = array_values( array_intersect( $args['scopes'] ?? [], self::SCOPES ) );

        $role = sanitize_key( $args['agent_role'] ?? 'full_access' );
        if ( empty( $scopes ) && 'full_access' !== $role ) {
            $scopes = Agent_Profiles::get_role_scopes( $role );
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- custom table insert.
        $wpdb->insert( "{$wpdb->prefix}directrelay_keys", array(
            'user_id'            => (int) ( $args['user_id'] ?? get_current_user_id() ),
            'key_hash'           => password_hash( $raw, PASSWORD_DEFAULT ),
            'key_prefix'         => substr( $raw, 0, 12 ),
            'label'              => sanitize_text_field( $args['label'] ?? '' ),
            'description'        => sanitize_textarea_field( $args['description'] ?? '' ),
            'environment'        => in_array( $args['environment'] ?? '', [ 'production', 'staging', 'development' ], true )
                                    ? $args['environment'] : 'production',
            'agent_role'         => $role,
            'daily_limit'        => absint( $args['daily_limit'] ?? 0 ),
            'restrict_own_posts' => ! empty( $args['restrict_own_posts'] ) ? 1 : 0,
            'require_approval'   => ! empty( $args['require_approval'] ) ? 1 : 0,
            'scopes'             => wp_json_encode( $scopes ),
            'ip_whitelist'       => ! empty( $args['ip_whitelist'] ) ? wp_json_encode( array_values( $args['ip_whitelist'] ) ) : null,
            'expires_at'         => $args['expires_at'] ?? null,
            'created_at'         => current_time( 'mysql', true ),
        ) );

        return [
            'raw_key'            => $raw,
            'id'                 => (int) $wpdb->insert_id,
            'prefix'             => substr( $raw, 0, 12 ),
            'label'              => $args['label'] ?? '',
            'agent_role'         => $role,
            'daily_limit'        => absint( $args['daily_limit'] ?? 0 ),
            'restrict_own_posts' => ! empty( $args['restrict_own_posts'] ),
            'require_approval'   => ! empty( $args['require_approval'] ),
            'scopes'             => $scopes,
        ];
    }

    /* â”€â”€ Rotate (generate new key, keep same id / scopes / settings) */

    public static function rotate( int $id ): array|\WP_Error {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table lookup.
        $row = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}directrelay_keys WHERE id = %d AND revoked = 0", $id ),
            ARRAY_A
        );
        if ( ! $row ) {
            return new \WP_Error( 'amp_not_found', 'Key not found.', [ 'status' => 404 ] );
        }
        $raw = self::generate_raw();
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table update.
        $wpdb->update( "{$wpdb->prefix}directrelay_keys", [
            'key_hash'   => password_hash( $raw, PASSWORD_DEFAULT ),
            'key_prefix' => substr( $raw, 0, 12 ),
        ], [ 'id' => $id ], [ '%s', '%s' ], [ '%d' ] );

        return [
            'raw_key' => $raw,
            'id'      => $id,
            'prefix'  => substr( $raw, 0, 12 ),
            'label'   => $row['label'],
        ];
    }

    /* ————————————————————————————————————————————————————————————————————————————————————————————————————————————————— */

    public static function is_ip_whitelisted( string $ip ): bool {
        $settings   = get_option( 'directrelay_settings', [] );
        $bypass_raw = $settings['bypass_ips'] ?? '';
        if ( empty( $bypass_raw ) ) {
            return false;
        }
        $list = array_values( array_filter( array_map( 'trim', preg_split( '/[\n,]+/', $bypass_raw ) ) ) );
        if ( empty( $list ) ) {
            return false;
        }
        if ( ! self::ip_allowed( $ip, $list ) ) {
            return false;
        }
        if ( function_exists( 'directrelay_debug_log' ) ) {
            directrelay_debug_log( 'INFO', 'Global IP bypass engaged', [ 'ip' => $ip ] );
        }
        do_action( 'directrelay_ip_whitelisted', $ip );
        return true;
    }

    public static function authenticate( \WP_REST_Request $req ): array|\WP_Error {
        $ip             = self::client_ip();
        $is_whitelisted = self::is_ip_whitelisted( $ip );

        /* Brute-force check first */
        if ( ! $is_whitelisted ) {
            $bf = Brute_Force::check_ip( $ip );
            if ( is_wp_error( $bf ) ) {
                return $bf;
            }
        }

        /* HTTPS check */
        $settings = get_option( 'directrelay_settings', [] );
        if ( ! $is_whitelisted && ! empty( $settings['require_https'] ) && ! is_ssl() && ! ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ) {
            return new \WP_Error( 'amp_ssl_required', __( 'HTTPS required.', 'directrelay-automation-bridge-for-n8n' ), [ 'status' => 403 ] );
        }

        /* Extract bearer token */
        $auth = $req->get_header( 'authorization' );
        if ( empty( $auth ) ) {
            $xkey = $req->get_header( 'x-api-key' );
            if ( ! empty( $xkey ) ) {
                $auth = 'Bearer ' . trim( $xkey );
            }
        }
        if ( empty( $auth ) || ! str_starts_with( $auth, 'Bearer ' ) ) {
            if ( ! $is_whitelisted ) {
                Brute_Force::record_failure( $ip );
            }
            return new \WP_Error( 'amp_no_auth', __( 'Missing Authorization header.', 'directrelay-automation-bridge-for-n8n' ), [ 'status' => 401 ] );
        }

        $raw = trim( substr( $auth, 7 ) );
        if ( empty( $raw ) || strlen( $raw ) < 8 ) {
            if ( ! $is_whitelisted ) {
                Brute_Force::record_failure( $ip );
            }
            return new \WP_Error( 'amp_bad_token', __( 'Malformed token.', 'directrelay-automation-bridge-for-n8n' ), [ 'status' => 401 ] );
        }

        global $wpdb;
        $prefix       = substr( $raw, 0, 12 );
        $prefix_short = substr( $raw, 0, 8 );
        /* PHP-side date math for SQLite portability (the wp-sqlite-db shim
           cannot translate UTC_TIMESTAMP()); expires_at is stored as UTC. */
        $now_utc = current_time( 'mysql', true );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table auth lookup.
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}directrelay_keys
                 WHERE (key_prefix = %s OR key_prefix = %s)
                 AND revoked = 0
                 AND (expires_at IS NULL OR expires_at > %s)",
                $prefix,
                $prefix_short,
                $now_utc
            ),
            ARRAY_A
        );

        $row = null;
        if ( ! empty( $rows ) ) {
            foreach ( $rows as $r ) {
                $stored_hash = $r['key_hash'];
                if ( str_starts_with( $stored_hash, '$' ) ) {
                    if ( password_verify( $raw, $stored_hash ) ) {
                        $row = $r;
                        break;
                    }
                } else {
                    if ( hash_equals( $stored_hash, self::hash_key( $raw ) ) ) {
                        $row = $r;
                        break;
                    }
                }
            }
        }

        if ( ! $row ) {
            if ( ! $is_whitelisted ) {
                Brute_Force::record_failure( $ip );
            }
            return new \WP_Error( 'amp_invalid_key', __( 'Invalid or expired API key.', 'directrelay-automation-bridge-for-n8n' ), [ 'status' => 401 ] );
        }

        /* Key Rotation Check () */
        if ( ! empty( $settings['key_rotation_days'] ) ) {
            $days = (int) $settings['key_rotation_days'];
            $created = strtotime( $row['created_at'] );
            if ( ( time() - $created ) > ( $days * DAY_IN_SECONDS ) ) {
                return new \WP_Error(
                    'amp_key_expired',
                    sprintf(
                        /* translators: %d: rotation days */
                        __( 'API key expired due to rotation policy (%d days). Please rotate your key.', 'directrelay-automation-bridge-for-n8n' ),
                        $days
                    ),
                    [ 'status' => 401 ]
                );
            }
        }

        /* Successful auth — clear any brute-force record */
        if ( ! $is_whitelisted ) {
            Brute_Force::clear( $ip );
        }

        /* IP whitelist */
        if ( ! $is_whitelisted && ! empty( $row['ip_whitelist'] ) ) {
            $list = json_decode( $row['ip_whitelist'], true ) ?: [];
            if ( $list && ! self::ip_allowed( $ip, $list ) ) {
                return new \WP_Error( 'amp_ip_blocked', __( 'Client IP not permitted.', 'directrelay-automation-bridge-for-n8n' ), [ 'status' => 403 ] );
            }
        }

        /* Update last used (lightweight and atomic) */
        $now_utc = current_time( 'mysql', true );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table update.
        $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$wpdb->prefix}directrelay_keys
                 SET last_used_at = %s, last_used_ip = %s, total_requests = total_requests + 1
                 WHERE id = %d",
                $now_utc,
                $ip,
                (int) $row['id']
            )
        );

        $row['last_used_at']   = $now_utc;
        $row['last_used_ip']   = $ip;
        $row['total_requests'] = (int) ( $row['total_requests'] ?? 0 ) + 1;
        $row['scopes_array']   = json_decode( $row['scopes'] ?? '[]', true ) ?: [];
        $row['is_full']        = empty( $row['scopes_array'] );
        return $row;
    }

    public static function has_scope( array $key, string $scope ): bool {
        return ( $key['is_full'] ?? false ) || in_array( $scope, $key['scopes_array'] ?? [], true );
    }

    public static function revoke( int $id ): bool {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table update.
        return (bool) $wpdb->update(
            "{$wpdb->prefix}directrelay_keys",
            [ 'revoked' => 1, 'revoked_at' => current_time( 'mysql', true ) ],
            [ 'id' => $id ], [ '%d', '%s' ], [ '%d' ]
        );
    }

    public static function list_keys( int $uid = 0, bool $include_revoked = false ): array {
        global $wpdb;

        if ( $uid > 0 ) {
            if ( ! $include_revoked ) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Custom table key query.
                $rows = $wpdb->get_results(
                    $wpdb->prepare(
                        "SELECT id, user_id, key_prefix, label, description, environment, agent_role, daily_limit, posts_today, posts_today_date, restrict_own_posts, require_approval, scopes, ip_whitelist, last_used_at, last_used_ip, expires_at, total_requests, created_at, revoked, revoked_at FROM {$wpdb->prefix}directrelay_keys WHERE revoked = 0 AND user_id = %d ORDER BY created_at DESC",
                        $uid
                    ),
                    ARRAY_A
                ) ?: [];
            } else {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Custom table key query.
                $rows = $wpdb->get_results(
                    $wpdb->prepare(
                        "SELECT id, user_id, key_prefix, label, description, environment, agent_role, daily_limit, posts_today, posts_today_date, restrict_own_posts, require_approval, scopes, ip_whitelist, last_used_at, last_used_ip, expires_at, total_requests, created_at, revoked, revoked_at FROM {$wpdb->prefix}directrelay_keys WHERE user_id = %d ORDER BY created_at DESC",
                        $uid
                    ),
                    ARRAY_A
                ) ?: [];
            }
        } else {
            if ( ! $include_revoked ) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Custom table key query.
                $rows = $wpdb->get_results( "SELECT id, user_id, key_prefix, label, description, environment, agent_role, daily_limit, posts_today, posts_today_date, restrict_own_posts, require_approval, scopes, ip_whitelist, last_used_at, last_used_ip, expires_at, total_requests, created_at, revoked, revoked_at FROM {$wpdb->prefix}directrelay_keys WHERE revoked = 0 ORDER BY created_at DESC", ARRAY_A ) ?: [];
            } else {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Custom table key query.
                $rows = $wpdb->get_results( "SELECT id, user_id, key_prefix, label, description, environment, agent_role, daily_limit, posts_today, posts_today_date, restrict_own_posts, require_approval, scopes, ip_whitelist, last_used_at, last_used_ip, expires_at, total_requests, created_at, revoked, revoked_at FROM {$wpdb->prefix}directrelay_keys ORDER BY created_at DESC", ARRAY_A ) ?: [];
            }
        }

        if ( empty( $rows ) ) {
            return [];
        }

        // Get analytics aggregates per key_id in a single query
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $ana_stats = $wpdb->get_results(
            "SELECT key_id, SUM(hits) as total_hits, MAX(bucket_hour) as max_time FROM {$wpdb->prefix}directrelay_analytics GROUP BY key_id",
            ARRAY_A
        ) ?: [];
        $ana_map         = [];
        $unassigned_hits = 0;
        $unassigned_time = null;
        foreach ( $ana_stats as $stat ) {
            $kid = (int) ( $stat['key_id'] ?? 0 );
            if ( $kid > 0 ) {
                $ana_map[ $kid ] = [
                    'hits' => (int) $stat['total_hits'],
                    'time' => $stat['max_time'],
                ];
            } else {
                $unassigned_hits += (int) $stat['total_hits'];
                if ( ! empty( $stat['max_time'] ) ) {
                    $unassigned_time = $stat['max_time'];
                }
            }
        }

        // Get log aggregates per key_id in a single query
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $log_stats = $wpdb->get_results(
            "SELECT key_id, COUNT(*) as total_count, MAX(created_at) as max_time FROM {$wpdb->prefix}directrelay_log GROUP BY key_id",
            ARRAY_A
        ) ?: [];
        $log_map = [];
        foreach ( $log_stats as $stat ) {
            $kid = (int) ( $stat['key_id'] ?? 0 );
            if ( $kid > 0 ) {
                $log_map[ $kid ] = [
                    'count' => (int) $stat['total_count'],
                    'time'  => $stat['max_time'],
                ];
            } elseif ( empty( $unassigned_hits ) ) {
                $unassigned_hits += (int) $stat['total_count'];
                if ( ! empty( $stat['max_time'] ) ) {
                    $unassigned_time = $stat['max_time'];
                }
            }
        }

        // Find primary active key ID if we have unassigned hits
        $primary_key_id = 0;
        if ( $unassigned_hits > 0 ) {
            foreach ( $rows as $r ) {
                if ( empty( $r['revoked'] ) ) {
                    $primary_key_id = (int) $r['id'];
                    break;
                }
            }
        }

        foreach ( $rows as &$row ) {
            $kid       = (int) $row['id'];
            $db_reqs   = (int) ( $row['total_requests'] ?? 0 );
            $k_hits    = (int) ( $ana_map[ $kid ]['hits'] ?? 0 );
            $k_log     = (int) ( $log_map[ $kid ]['count'] ?? 0 );
            $extra     = ( $kid === $primary_key_id ) ? $unassigned_hits : 0;
            $real_reqs = max( $db_reqs, $k_hits + $extra, $k_log + $extra );

            $latest_time = $row['last_used_at'];
            if ( ! empty( $ana_map[ $kid ]['time'] ) && ( empty( $latest_time ) || $ana_map[ $kid ]['time'] > $latest_time ) ) {
                $latest_time = $ana_map[ $kid ]['time'];
            }
            if ( ! empty( $log_map[ $kid ]['time'] ) && ( empty( $latest_time ) || $log_map[ $kid ]['time'] > $latest_time ) ) {
                $latest_time = $log_map[ $kid ]['time'];
            }
            if ( $kid === $primary_key_id && ! empty( $unassigned_time ) && ( empty( $latest_time ) || $unassigned_time > $latest_time ) ) {
                $latest_time = $unassigned_time;
            }

            if ( $real_reqs > $db_reqs || ( $latest_time && $latest_time !== $row['last_used_at'] ) ) {
                $row['total_requests'] = $real_reqs;
                $row['last_used_at']   = $latest_time;

                // Sync back to custom table so it stays permanently accurate
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table update.
                $wpdb->update(
                    "{$wpdb->prefix}directrelay_keys",
                    [
                        'total_requests' => $real_reqs,
                        'last_used_at'   => $latest_time,
                    ],
                    [ 'id' => $kid ],
                    [ '%d', '%s' ],
                    [ '%d' ]
                );
            }
        }
        unset( $row );

        return $rows;
    }

    public static function count_active_keys( int $uid = 0 ): int {
        $keys = self::list_keys( $uid, false );
        return count( array_filter( $keys, fn( $k ) => ! $k['revoked'] ) );
    }

    /* â”€â”€ Helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */

    public static function client_ip(): string {
        $remote_ip = '';
        if ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
            $raw = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
            $remote_ip = trim( explode( ',', $raw )[0] );
            if ( ! filter_var( $remote_ip, FILTER_VALIDATE_IP ) ) {
                $remote_ip = '0.0.0.0';
            }
        } else {
            $remote_ip = '0.0.0.0';
        }

        // Get trusted proxies.
        $trusted_proxies = [];
        if ( defined( 'DIRECTRELAY_TRUSTED_PROXIES' ) ) {
            $val = DIRECTRELAY_TRUSTED_PROXIES;
            if ( is_array( $val ) ) {
                $trusted_proxies = $val;
            } elseif ( is_string( $val ) ) {
                $trusted_proxies = array_filter( array_map( 'trim', explode( ',', $val ) ) );
            }
        } else {
            $settings = get_option( 'directrelay_settings', [] );
            if ( ! empty( $settings['trusted_proxies'] ) ) {
                $trusted_proxies = array_filter( array_map( 'trim', explode( "\n", $settings['trusted_proxies'] ) ) );
            }
        }

        // If remote_ip is in trusted proxies, we can trust proxy headers.
        $trust_proxies = false;
        if ( ! empty( $trusted_proxies ) ) {
            foreach ( $trusted_proxies as $proxy ) {
                if ( self::cidr_match( $remote_ip, $proxy ) ) {
                    $trust_proxies = true;
                    break;
                }
            }
        }

        if ( $trust_proxies ) {
            foreach ( [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP' ] as $h ) {
                if ( empty( $_SERVER[ $h ] ) ) {
                    continue;
                }
                $raw = sanitize_text_field( wp_unslash( $_SERVER[ $h ] ) );
                $ip  = trim( explode( ',', $raw )[0] );
                if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                    $is_private_or_res = filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) === false;
                    if ( ! $is_private_or_res ) {
                        return $ip;
                    }
                    $remote_is_private_or_res = filter_var( $remote_ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) === false;
                    if ( $remote_is_private_or_res ) {
                        return $ip;
                    }
                }
            }
        }

        return $remote_ip;
    }

    public static function ip_allowed( string $ip, array $list ): bool {
        foreach ( $list as $cidr ) {
            if ( self::cidr_match( $ip, trim( $cidr ) ) ) {
                return true;
            }
        }
        return false;
    }

    private static function cidr_match( string $ip, string $cidr ): bool {
        if ( ! str_contains( $cidr, '/' ) ) {
            return $ip === $cidr;
        }
        [ $subnet, $bits ] = explode( '/', $cidr, 2 );
        $bits = (int) $bits;

        $ip_packed     = @inet_pton( $ip );
        $subnet_packed = @inet_pton( $subnet );
        if ( false === $ip_packed || false === $subnet_packed ) {
            return false;
        }
        // Family mismatch (IPv4 vs IPv6) → never match.
        if ( strlen( $ip_packed ) !== strlen( $subnet_packed ) ) {
            return false;
        }
        if ( 0 === $bits ) {
            return true;
        }
        $max_bits = strlen( $ip_packed ) * 8;
        if ( $bits < 0 || $bits > $max_bits ) {
            return false;
        }
        $full_bytes = intdiv( $bits, 8 );
        $remainder  = $bits % 8;
        if ( 0 !== substr_compare( $ip_packed, $subnet_packed, 0, $full_bytes ) ) {
            return false;
        }
        if ( 0 === $remainder ) {
            return true;
        }
        $mask     = chr( ( ~0 << ( 8 - $remainder ) ) & 0xff );
        $ip_byte  = $ip_packed[ $full_bytes ] & $mask;
        $sub_byte = $subnet_packed[ $full_bytes ] & $mask;
        return $ip_byte === $sub_byte;
    }

    public static function is_url_safe( string $url ): bool {
        $scheme = strtolower( (string) wp_parse_url( $url, PHP_URL_SCHEME ) );
        if ( ! in_array( $scheme, [ 'http', 'https' ], true ) ) {
            return false;
        }
        $host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
        if ( empty( $host ) ) {
            return false;
        }

        // Block typical local network domain suffixes.
        if ( 'localhost' === $host || str_ends_with( $host, '.local' ) || str_ends_with( $host, '.localhost' ) || str_ends_with( $host, '.internal' ) ) {
            return false;
        }

        $ips = [];
        if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
            // Literal IPv4/IPv6 hosts are validated directly (gethostbyname()
            // would return them unchanged and read as "couldn't resolve").
            $ips[] = $host;
        } else {
            // Every A record must be public — gethostbyname() alone only
            // inspects one record, leaving the rest unchecked.
            $a_records = gethostbynamel( $host );
            if ( is_array( $a_records ) ) {
                $ips = $a_records;
            }
            // AAAA records for IPv6-only hosts (gethostbynamel() is v4-only).
            $aaaa = function_exists( 'dns_get_record' ) ? dns_get_record( $host, DNS_AAAA ) : false;
            if ( is_array( $aaaa ) ) {
                foreach ( $aaaa as $rec ) {
                    if ( ! empty( $rec['ipv6'] ) ) {
                        $ips[] = $rec['ipv6'];
                    }
                }
            }
        }

        if ( empty( $ips ) ) {
            // Couldn't resolve — block it.
            return false;
        }

        foreach ( $ips as $ip ) {
            if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                return false;
            }

            // Block loopback, private and reserved ranges.
            if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) === false ) {
                return false;
            }

            if ( in_array( $ip, [ '127.0.0.1', '::1', '0.0.0.0' ], true ) ) {
                return false;
            }
        }

        return true;
    }

    /**
     * Re-verify that the URL still resolves to a public IP at fetch time.
     *
     * Mitigates DNS rebinding: an attacker registers a domain that
     * resolves to a public IP at check time but a private IP at fetch
     * time. Always re-resolve immediately before wp_remote_get().
     *
     * @param string $url The URL about to be fetched.
     * @return string|null The re-resolved IP, or null if rejected.
     */
    public static function revalidate_ip( string $url ): ?string {
        $host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
        if ( '' === $host ) {
            return null;
        }
        $ips = gethostbynamel( $host );
        if ( false === $ips || empty( $ips ) ) {
            return null;
        }
        foreach ( $ips as $ip ) {
            if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                continue;
            }
            if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) === false ) {
                return null;
            }
            if ( in_array( $ip, [ '127.0.0.1', '::1', '0.0.0.0' ], true ) ) {
                return null;
            }
        }
        return $ips[0];
    }
}
