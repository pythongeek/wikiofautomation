<?php
namespace DirectRelay;

defined( 'ABSPATH' ) || exit;

/**
 * Brute-force protection.
 * Tracks failed auth attempts per IP with a sliding window.
 * After limit is exceeded the IP is blocked for escalating durations.
 */
final class Brute_Force {

    public static function init(): void {
        if ( ! wp_next_scheduled( 'directrelay_prune_brute_force' ) ) {
            wp_schedule_event( time(), 'hourly', 'directrelay_prune_brute_force' );
        }
        add_action( 'directrelay_prune_brute_force', [ __CLASS__, 'prune' ] );
    }

    /**
     * Check if this IP is currently blocked.
     * Returns WP_Error if blocked, true if allowed.
     */
    public static function check_ip( string $ip ): bool|\WP_Error {
        global $wpdb;
        $t = "{$wpdb->prefix}directrelay_brute_force";
        /* Both event types are enforced here: 'failed_auth' rows carry the
         * automatic escalating block, 'manual_block' rows come from the admin
         * Blocked-IPs card. The latest expiry wins when an IP has both. */
        $row = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table.
            $wpdb->prepare( "SELECT blocked_until FROM $t WHERE ip_address = %s AND event_type IN ( 'failed_auth', 'manual_block' ) AND blocked_until IS NOT NULL ORDER BY blocked_until DESC LIMIT 1", $ip ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            ARRAY_A
        );
        if ( ! $row || empty( $row['blocked_until'] ) ) {
            return true;
        }
        /* blocked_until is written with gmdate() (UTC), so parse it as UTC. */
        $until = strtotime( $row['blocked_until'] . ' UTC' );
        if ( false !== $until && $until > time() ) {
            $secs = $until - time();
            return new \WP_Error(
                'amp_ip_blocked',
                sprintf(
                    /* translators: %d: number of seconds */
                    __( 'Too many failed attempts. Retry in %d seconds.', 'directrelay-automation-bridge-for-n8n'),
                    $secs
                ),
                [ 'status' => 429 ]
            );
        }
        return true;
    }

    /**
     * Record a failed authentication attempt.
     * Blocks the IP if limit is exceeded (escalating durations).
     *
     * Date math is done in PHP (not SQL) so the query stays portable across
     * MySQL, MariaDB, and SQLite (WordPress Playground's wp-sqlite-db
     * driver). The previous TIMESTAMPDIFF / DATE_ADD formulation threw
     * "no such column: SECOND" on the SQLite driver because TIMESTAMPDIFF
     * is a MySQL function the SQLite shim does not translate.
     */
    public static function record_failure( string $ip ): void {
        global $wpdb;
        $s        = get_option( 'directrelay_settings', [] );
        $limit    = (int) ( $s['brute_force_limit']  ?? 10 );
        $window   = (int) ( $s['brute_force_window'] ?? 300 ); // 5 min default
        $t        = "{$wpdb->prefix}directrelay_brute_force";
        $now_mysql = current_time( 'mysql', true );
        $now_ts    = time();

        // Ensure the row exists (insert with 0 hits if not present).
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table.
        $wpdb->query(
            $wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $t is $wpdb->prefix + static name, not user input.
                "INSERT IGNORE INTO $t (ip_address, event_type, hits, window_open, created_at)
                 VALUES (%s, 'failed_auth', 0, %s, %s)",
                $ip,
                $now_mysql,
                $now_mysql
            )
        );

        // Read current state, compute new state in PHP, then write.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table.
        $row = $wpdb->get_row(
            $wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $t is $wpdb->prefix + static name, not user input.
                "SELECT hits, window_open, blocked_until FROM $t WHERE ip_address = %s AND event_type = 'failed_auth'",
                $ip
            ),
            ARRAY_A
        );
        if ( ! $row ) {
            return;
        }

        $old_hits = (int) $row['hits'];
        // strtotime() + UTC tag is portable; MySQL "UTC_TIMESTAMP()" / "TIMESTAMPDIFF" are not.
        $old_wo_ts = strtotime( (string) $row['window_open'] . ' UTC' );
        if ( false === $old_wo_ts ) {
            $old_wo_ts = strtotime( (string) $row['window_open'] );
        }
        $old_wo_ts = (int) $old_wo_ts;
        $window_expired = ( $now_ts - $old_wo_ts ) >= $window;

        if ( $window_expired ) {
            $new_hits = 1;
            $new_wo   = $now_mysql;
            $new_bu   = null;
        } else {
            $new_hits = $old_hits + 1;
            $new_wo   = (string) $row['window_open'];
            if ( $new_hits >= $limit ) {
                $seconds = 300; /* base block for first cross */
                if ( $new_hits >= $limit * 5 ) {
                    $seconds = 86400;
                } elseif ( $new_hits >= $limit * 3 ) {
                    $seconds = 7200;
                } elseif ( $new_hits >= $limit * 2 ) {
                    $seconds = 1800;
                }
                $new_bu = gmdate( 'Y-m-d H:i:s', $now_ts + $seconds );
            } else {
                /* Not crossing the limit this time — keep any existing block. */
                $new_bu = $row['blocked_until'] !== null ? (string) $row['blocked_until'] : null;
            }
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table.
        $wpdb->update(
            $t,
            [
                'hits'          => $new_hits,
                'window_open'   => $new_wo,
                'blocked_until' => $new_bu,
            ],
            [
                'ip_address' => $ip,
                'event_type' => 'failed_auth',
            ],
            [ '%d', '%s', '%s' ],
            [ '%s', '%s' ]
        );
    }

    /** Clear record after a successful auth (IP is no longer suspect) */
    public static function clear( string $ip ): void {
        global $wpdb;
        $t = "{$wpdb->prefix}directrelay_brute_force";
        $wpdb->delete( $t, [ 'ip_address' => $ip, 'event_type' => 'failed_auth' ], [ '%s', '%s' ] ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    }

    /** Prune old entries not touched in 24h. Date math is PHP-side for SQLite portability. */
    public static function prune(): void {
        global $wpdb;
        $t          = "{$wpdb->prefix}directrelay_brute_force";
        $now_mysql  = current_time( 'mysql', true );
        $threshold  = gmdate( 'Y-m-d H:i:s', time() - 86400 );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table.
        $wpdb->query(
            $wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $t is $wpdb->prefix + static name, not user input.
                "DELETE FROM $t WHERE window_open < %s AND (blocked_until IS NULL OR blocked_until < %s)",
                $threshold,
                $now_mysql
            )
        );
    }

    /** Returns all current blocks for the admin UI. Date filter is PHP-side for SQLite portability. */
    public static function list_blocks(): array {
        global $wpdb;
        $t         = "{$wpdb->prefix}directrelay_brute_force";
        $now_mysql = current_time( 'mysql', true );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table.
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $t is $wpdb->prefix + static name, not user input.
                "SELECT * FROM $t WHERE blocked_until > %s ORDER BY hits DESC LIMIT 100",
                $now_mysql
            ),
            ARRAY_A
        );
        return $rows ?: [];
    }

    /**
     * Manually block an IP from the admin UI.
     *
     * Inserts (or refreshes) a row in the brute-force table with a 24h
     * blocked_until and event_type 'manual_block'. The IP gets the same
     * 429 response from check_ip() as if it had tripped the automatic
     * limit. The admin can remove the block with the chip's unblock
     * button (which calls Brute_Force::clear() via the AJAX handler).
     *
     * @param string $ip Plain IPv4 or IPv6 address (CIDR is rejected to
     *                   keep the table key exact-match; range blocking
     *                   is an add-on feature).
     * @return true|\WP_Error True on success, WP_Error with reason on failure.
     */
    public static function block_ip( string $ip ): true|\WP_Error {
        $ip = trim( $ip );
        if ( '' === $ip ) {
            return new \WP_Error( 'amp_invalid_ip', __( 'IP address is required.', 'directrelay-automation-bridge-for-n8n' ) );
        }
        if ( str_contains( $ip, '/' ) ) {
            return new \WP_Error( 'amp_cidr_unsupported', __( 'CIDR ranges are not supported in the free plugin. Enter a single IP address.', 'directrelay-automation-bridge-for-n8n' ) );
        }
        // filter_var validates both IPv4 and IPv6.
        if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
            return new \WP_Error( 'amp_invalid_ip', __( 'That is not a valid IPv4 or IPv6 address.', 'directrelay-automation-bridge-for-n8n' ) );
        }

        global $wpdb;
        $t   = "{$wpdb->prefix}directrelay_brute_force";
        $now = current_time( 'mysql', true );
        $until = gmdate( 'Y-m-d H:i:s', time() + DAY_IN_SECONDS );

        // Upsert: replace any existing row for this IP + event_type so the
        // new block window starts fresh from now. wpdb::delete() / insert()
        // handle the table interpolation safely (no prepared SQL needed for
        // the table name itself) and the rows are short-lived brute-force
        // state - not a good fit for object caching, hence the per-call
        // phpcs:ignore for DirectQuery and NoCaching.
        $wpdb->delete( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $t,
            [ 'ip_address' => $ip, 'event_type' => 'manual_block' ],
            [ '%s', '%s' ]
        );
        $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $t,
            [
                'ip_address'    => $ip,
                'event_type'    => 'manual_block',
                'hits'          => 0,
                'window_open'   => $now,
                'created_at'    => $now,
                'blocked_until' => $until,
            ],
            [ '%s', '%s', '%d', '%s', '%s', '%s' ]
        );
        return true;
    }
}
