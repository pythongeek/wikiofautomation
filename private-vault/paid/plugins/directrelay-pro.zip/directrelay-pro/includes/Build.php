<?php
namespace DirectRelay;

/**
 * Build-time helper for the DirectRelay free plugin.
 *
 * The free plugin is a single build (`type() === 'all-in-one'`) and
 * does not carry an add-on variant, a third-party distribution channel,
 * or an activation-state flag. Those concerns live in the separate
 * `directrelay-pro` add-on distributed from
 * https://directrelay.wikiofautomation.com/directrelay-pro.
 */
final class Build {

	/**
	 * @return string Always 'all-in-one' for the free WP.org build.
	 */
	public static function type(): string {
		return 'all-in-one';
	}

	/**
	 * Text domain to use.
	 */
	public static function text_domain(): string {
		return 'directrelay-automation-bridge-for-n8n';
	}
}
