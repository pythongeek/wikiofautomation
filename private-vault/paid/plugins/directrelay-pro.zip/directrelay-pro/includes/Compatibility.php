<?php
namespace DirectRelay;

defined( 'ABSPATH' ) || exit;

final class Compatibility {

    private static bool $initialized = false;
    private static ?bool $is_agentic  = null;

    public static function init(): void {
        if ( self::$initialized ) return;
        self::$initialized = true;

        add_filter( 'admin_body_class', [ __CLASS__, 'admin_body_class' ] );

        if ( is_admin() ) {
            add_action( 'admin_notices', [ __CLASS__, 'app_password_notice' ] );
        }

        /*
         * No determine_current_user filter: DirectRelay keys must never act as
         * their bound WordPress user outside the directrelay/v1 namespace.
         * Base_Controller::guard() authenticates each plugin route itself and
         * calls wp_set_current_user() only after scope/agent/rate checks, so
         * a leaked key cannot reach core /wp/v2, wp-admin or admin-ajax
         * capabilities (the pre-5.1.32 scope bypass).
         */
    }

    public static function is_agentic_theme(): bool {
        if ( self::$is_agentic === null ) {
            $theme             = wp_get_theme();
            self::$is_agentic  = str_contains( strtolower( $theme->get( 'Name' ) ), 'agentic' )
                              || str_contains( strtolower( $theme->get_stylesheet() ), 'agentic' );
        }
        return self::$is_agentic;
    }

    public static function admin_body_class( string $classes ): string {
        $screen = get_current_screen();
        if ( ! $screen ) return $classes;
        $ours = [ 'toplevel_page_directrelay-cm', 'directrelay-cm_page_directrelay-keys', 'directrelay-cm_page_directrelay-webhooks', 'directrelay-cm_page_directrelay-logs', 'directrelay-cm_page_directrelay-settings', 'directrelay-cm_page_directrelay-docs', 'directrelay-cm_page_directrelay-compat' ];
        if ( in_array( $screen->id, $ours, true ) ) {
            $classes .= ' directrelay-page';
        }
        return $classes;
    }

    public static function app_password_notice(): void {
        $screen = get_current_screen();
        if ( ! $screen ) return;
        if ( ! in_array( $screen->id, [ 'toplevel_page_directrelay-cm', 'directrelay-cm_page_directrelay-settings' ], true ) ) return;
        if ( ! apply_filters( 'wp_is_application_passwords_available', false ) ) return; // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WP core filter.
        if ( get_option( 'directrelay_apppass_dismissed' ) ) return;
        echo '<div class="notice notice-warning is-dismissible"><p>';
        printf(
            /* translators: %s: link to security recommendation */
            wp_kses_post( __( '<strong>DirectRelay:</strong> Your theme enables WordPress Application Passwords globally. %s', 'directrelay-automation-bridge-for-n8n') ),
            '<a href="' . esc_url( admin_url( 'admin.php?page=directrelay-compat' ) ) . '">' . esc_html__( 'View security recommendation →', 'directrelay-automation-bridge-for-n8n') . '</a>'
        );
        echo '</p></div>';
    }

    public static function status(): array {
        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $theme    = wp_get_theme();
        $app_pass = apply_filters( 'wp_is_application_passwords_available', false ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WP core filter.

        // Conflicting plugins
        $conflicts = [];
        $check_plugins = [
            'wordpress-seo/wp-seo.php'                    => 'Yoast SEO',
            'all-in-one-seo-pack/all_in_one_seo_pack.php' => 'All in One SEO Pack',
            'wp-seopress/seopress.php'                     => 'SEOPress',
        ];
        foreach ( $check_plugins as $path => $name ) {
            if ( is_plugin_active( $path ) ) {
                $conflicts[] = $name;
            }
        }

        // Required PHP extensions
        $extensions = [ 'json', 'curl', 'mbstring' ];
        $missing_ext = [];
        foreach ( $extensions as $ext ) {
            if ( ! extension_loaded( $ext ) ) {
                $missing_ext[] = $ext;
            }
        }

        // Rank Math version check
        $rank_math_version = defined( 'RANK_MATH_VERSION' ) ? RANK_MATH_VERSION : null;
        $rank_math_compatible = false;
        if ( $rank_math_version ) {
            $rank_math_compatible = version_compare( $rank_math_version, '1.0.100', '>=' );
        }

        return [
            'theme_name'           => $theme->get( 'Name' ),
            'theme_slug'           => $theme->get_stylesheet(),
            'parent_slug'          => $theme->get_template(),
            'is_agentic'           => self::$is_agentic,
            'app_pass_active'      => $app_pass,
            'conflicts'            => $conflicts,
            'missing_extensions'   => $missing_ext,
            'rank_math_version'    => $rank_math_version,
            'rank_math_compatible' => $rank_math_compatible,
        ];
    }

    public static function run_diagnostics(): array {
        global $wpdb;
        $results = [];

        /* 1. REST API Loopback Ping */
        $status_url = get_site_url() . '/wp-json/' . DIRECTRELAY_NS . '/status';
        $ping = wp_remote_get( $status_url, [ 'timeout' => 6, 'sslverify' => false ] );
        if ( is_wp_error( $ping ) ) {
            $results['rest_loopback'] = [
                'status'  => 'error',
                'title'   => __( 'REST API Loopback', 'directrelay-automation-bridge-for-n8n' ),
                'message' => $ping->get_error_message(),
                'code'    => 500,
            ];
        } else {
            $code = wp_remote_retrieve_response_code( $ping );
            /* translators: %d: HTTP status code */
            $msg_http_err = sprintf( __( 'REST API returned HTTP %d', 'directrelay-automation-bridge-for-n8n' ), $code );
            $results['rest_loopback'] = [
                'status'  => $code >= 200 && $code < 300 ? 'pass' : 'warn',
                'title'   => __( 'REST API Loopback', 'directrelay-automation-bridge-for-n8n' ),
                'message' => $code >= 200 && $code < 300 ? __( 'REST API endpoint reachable and responsive.', 'directrelay-automation-bridge-for-n8n' ) : $msg_http_err,
                'code'    => $code,
            ];
        }

        /* 2. Authorization Header Forwarding */
        $has_auth_env = ! empty( $_SERVER['HTTP_AUTHORIZATION'] ) || ! empty( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ) || ! empty( $_SERVER['HTTP_X_API_KEY'] );
        $results['auth_header'] = [
            'status'  => $has_auth_env ? 'pass' : 'warn',
            'title'   => __( 'Authorization Header', 'directrelay-automation-bridge-for-n8n' ),
            'message' => $has_auth_env ? __( 'Server environment passes HTTP Authorization headers.', 'directrelay-automation-bridge-for-n8n' ) : __( 'HTTP Authorization headers may be stripped by Apache/Nginx. Recommended: Add "SetEnvIf Authorization (.*) HTTP_AUTHORIZATION=$1" to .htaccess', 'directrelay-automation-bridge-for-n8n' ),
        ];

        /* 3. Database Schema Integrity */
        $tables = [
            $wpdb->prefix . 'directrelay_keys',
            $wpdb->prefix . 'directrelay_log',
            $wpdb->prefix . 'directrelay_webhooks',
            $wpdb->prefix . 'directrelay_rate',
            $wpdb->prefix . 'directrelay_brute_force',
        ];
        $missing_tables = [];
        foreach ( $tables as $tbl ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $tbl ) ) !== $tbl ) {
                $missing_tables[] = $tbl;
            }
        }
        /* translators: %s: list of missing database table names */
        $msg_missing_tables = sprintf( __( 'Missing tables: %s', 'directrelay-automation-bridge-for-n8n' ), implode( ', ', $missing_tables ) );
        $results['db_integrity'] = [
            'status'  => empty( $missing_tables ) ? 'pass' : 'error',
            'title'   => __( 'Database Tables', 'directrelay-automation-bridge-for-n8n' ),
            'message' => empty( $missing_tables ) ? __( 'All 5 custom DirectRelay database tables verified.', 'directrelay-automation-bridge-for-n8n' ) : $msg_missing_tables,
        ];

        /* 4. Cron Health */
        $next_cron = wp_next_scheduled( 'directrelay_cron_health_ping' );
        /* translators: %d: number of seconds until next cron ping */
        $msg_cron_active = sprintf( __( 'Background cron active (Next ping in %d seconds)', 'directrelay-automation-bridge-for-n8n' ), max( 0, (int) $next_cron - time() ) );
        $results['cron_health'] = [
            'status'  => $next_cron ? 'pass' : 'warn',
            'title'   => __( 'WP-Cron Health', 'directrelay-automation-bridge-for-n8n' ),
            'message' => $next_cron ? $msg_cron_active : __( 'Cron health ping task is not scheduled. Check system cron.', 'directrelay-automation-bridge-for-n8n' ),
        ];

        /* 5. PHP Extensions */
        $missing_exts = [];
        foreach ( [ 'json', 'curl', 'mbstring', 'openssl' ] as $ext ) {
            if ( ! extension_loaded( $ext ) ) {
                $missing_exts[] = $ext;
            }
        }
        /* translators: %s: list of missing PHP extension names */
        $msg_missing_exts = sprintf( __( 'Missing required extensions: %s', 'directrelay-automation-bridge-for-n8n' ), implode( ', ', $missing_exts ) );
        $results['php_extensions'] = [
            'status'  => empty( $missing_exts ) ? 'pass' : 'error',
            'title'   => __( 'PHP Extensions', 'directrelay-automation-bridge-for-n8n' ),
            'message' => empty( $missing_exts ) ? __( 'All required PHP extensions (json, curl, mbstring, openssl) installed.', 'directrelay-automation-bridge-for-n8n' ) : $msg_missing_exts,
        ];

        return $results;
    }
}
