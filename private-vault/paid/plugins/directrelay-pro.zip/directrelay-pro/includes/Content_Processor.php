<?php
namespace DirectRelay;

defined( 'ABSPATH' ) || exit;

/**
 * DirectRelay  Content Processor
 *
 * Production-grade AI conversational artifact cleaner and GFM Markdown-to-HTML parser.
 * Zero external dependencies, fully WordPress VIP & PHPCS compliant.
 *
 * @since 4.3.0
 */
final class Content_Processor {

    /**
     * Main entry point for processing incoming post content.
     */
    public static function process( string $content, array $options = [] ): string {
        if ( empty( trim( $content ) ) ) {
            return $content;
        }

        $clean_garbage = $options['clean_ai_garbage'] ?? true;
        if ( $clean_garbage ) {
            $content = self::clean_ai_garbage( $content );
        }

        $parse_markdown = $options['markdown_auto_parse'] ?? true;
        if ( $parse_markdown && self::is_markdown( $content ) ) {
            $content = self::markdown_to_html( $content );
        }

        return $content;
    }

    /**
     * Robust AI Conversational Chatter & Artifact Stripper.
     */
    public static function clean_ai_garbage( string $content ): string {
        // Strip opening markdown code fences like ```html or ```markdown or ```
        $content = preg_replace( '/^```(?:html|markdown|text|xml)?\s*\n/i', '', $content );
        $content = preg_replace( '/\n```\s*$/i', '', $content );

        // Strip conversational AI intros & assistant greetings
        $garbage_patterns = [
            '/^(?:Here is (?:a|your|the) (?:article|post|content|blog post|summary|draft)[:\s]*\n*)+/i',
            '/^(?:Sure[!,.]?\s*here is (?:a|your|the) (?:article|post|content|blog post|draft)[:\s]*\n*)+/i',
            '/^(?:Certainly[!,.]?\s*here is (?:a|your|the) (?:article|post|content)[:\s]*\n*)+/i',
            '/^(?:Below is (?:a|your|the) (?:article|post|content|blog post)[:\s]*\n*)+/i',
            '/^(?:As an AI language model[!,.]?\s*here is (?:a|your|the) (?:article|post|content)[:\s]*\n*)+/i',
            '/^(?:I have written (?:a|your|the) (?:article|post|content)[:\s]*\n*)+/i',
            '/^(?:Enjoy the following (?:article|post|content)[:\s]*\n*)+/i',
        ];

        foreach ( $garbage_patterns as $pattern ) {
            $content = preg_replace( $pattern, '', $content );
        }

        // Strip conversational AI outros at the very end
        $outro_patterns = [
            '/\n+(?:Let me know if you (?:need|would like) any (?:changes|edits|further assistance|more details)[!.].*)$/i',
            '/\n+(?:Hope this helps[!.]?.*)$/i',
            '/\n+(?:Feel free to (?:ask|request) (?:for|any) (?:changes|edits|modifications)[!.]?.*)$/i',
        ];

        foreach ( $outro_patterns as $pattern ) {
            $content = preg_replace( $pattern, '', $content );
        }

        return trim( $content );
    }

    /**
     * Check if string contains markdown syntax formatting.
     */
    public static function is_markdown( string $content ): bool {
        // If content is wrapped in standard HTML tags (<p>, <div>, <h1>, <article>), do not parse as Markdown
        if ( preg_match( '/^<(?:p|div|h[1-6]|article|section|table|ul|ol)\b[^>]*>/i', trim( $content ) ) ) {
            return false;
        }

        // Look for Markdown indicators (headings, lists, bold, links, tables, code fences)
        return (bool) preg_match( '/(?:^#{1,6}\s|^\s*[\*\-]\s|\*\*[^\*]+\*\*|\[[^\]]+\]\([^\)]+\)|^\s*\|\s*.*?\s*\|\s*$|^\s*```)/m', $content );
    }

    /**
     * Full GFM-Compliant Markdown to HTML Converter.
     */
    public static function markdown_to_html( string $text ): string {
        $text = str_replace( [ "\r\n", "\r" ], "\n", $text );

        // 1. Code blocks: ```lang ... ```
        $text = preg_replace_callback( '/```(\w*)\n([\s\S]*?)```/', function( $m ) {
            $lang = $m[1] ? ' class="language-' . esc_attr( strtolower( $m[1] ) ) . '"' : '';
            return '<pre><code' . $lang . '>' . esc_html( $m[2] ) . '</code></pre>';
        }, $text );

        // 2. Horizontal Rules: --- or *** or ___
        $text = preg_replace( '/^(?:---|[*]{3}|_{3})\s*$/m', '<hr />', $text );

        // 3. Blockquotes: > text
        $text = preg_replace_callback( '/^>\s*(.*)$/m', fn( $m ) => '<blockquote><p>' . esc_html( $m[1] ) . '</p></blockquote>', $text );

        // 4. Headings (# H1 to ###### H6)
        $text = preg_replace_callback( '/^######\s+(.*)$/m', fn( $m ) => '<h6>' . esc_html( $m[1] ) . '</h6>', $text );
        $text = preg_replace_callback( '/^#####\s+(.*)$/m', fn( $m ) => '<h5>' . esc_html( $m[1] ) . '</h5>', $text );
        $text = preg_replace_callback( '/^####\s+(.*)$/m', fn( $m ) => '<h4>' . esc_html( $m[1] ) . '</h4>', $text );
        $text = preg_replace_callback( '/^###\s+(.*)$/m', fn( $m ) => '<h3>' . esc_html( $m[1] ) . '</h3>', $text );
        $text = preg_replace_callback( '/^##\s+(.*)$/m', fn( $m ) => '<h2>' . esc_html( $m[1] ) . '</h2>', $text );
        $text = preg_replace_callback( '/^#\s+(.*)$/m', fn( $m ) => '<h1>' . esc_html( $m[1] ) . '</h1>', $text );

        // 5. Tables: | Col 1 | Col 2 |
        $text = preg_replace_callback( '/(?:^\|.+\|\s*$\n?)+/m', function( $m ) {
            $lines = array_filter( array_map( 'trim', explode( "\n", trim( $m[0] ) ) ) );
            if ( count( $lines ) < 2 ) return $m[0];

            $header = array_shift( $lines );
            // Skip alignment row (|---|---|)
            if ( isset( $lines[0] ) && preg_match( '/^\|?[\s\:\-]+\|[\s\:\-\|]+$/', $lines[0] ) ) {
                array_shift( $lines );
            }

            $th_cells = array_filter( array_map( 'trim', explode( '|', trim( $header, '|' ) ) ) );
            $html = "<table>\n<thead>\n<tr>";
            foreach ( $th_cells as $th ) {
                $html .= '<th>' . esc_html( $th ) . '</th>';
            }
            $html .= "</tr>\n</thead>\n<tbody>\n";

            foreach ( $lines as $row ) {
                $td_cells = array_filter( array_map( 'trim', explode( '|', trim( $row, '|' ) ) ) );
                $html .= "<tr>";
                foreach ( $td_cells as $td ) {
                    $html .= '<td>' . wp_kses_post( $td ) . '</td>';
                }
                $html .= "</tr>\n";
            }
            $html .= "</tbody>\n</table>";
            return $html;
        }, $text );

        // 6. Inline Formatting (Images, Links, Bold, Italic, Strikethrough, Code)
        //
        // URLs go through esc_url() — protocol allowlist plus attribute-safe
        // encoding — so javascript:/data: hrefs and quote-breakout payloads
        // are neutralized, and captured text goes through esc_html()/esc_attr().
        // The decode-then-esc_url on the URL keeps links that were already
        // esc_html()'d by an earlier block pass (heading/blockquote text)
        // from being double-encoded.
        $text = preg_replace_callback( '/!\[([^\]]*)\]\(([^\)]+)\)/', function( $m ) {
            $url = esc_url( html_entity_decode( trim( $m[2] ), ENT_QUOTES, 'UTF-8' ) );
            if ( '' === $url ) {
                return esc_html( $m[0] ); /* Unsafe protocol: render as plain text. */
            }
            return '<img src="' . $url . '" alt="' . esc_attr( $m[1] ) . '" />';
        }, $text );
        $text = preg_replace_callback( '/\[([^\]]+)\]\(([^\)]+)\)/', function( $m ) {
            $url = esc_url( html_entity_decode( trim( $m[2] ), ENT_QUOTES, 'UTF-8' ) );
            if ( '' === $url ) {
                return esc_html( $m[1] ); /* Unsafe protocol: keep the text, drop the link. */
            }
            return '<a href="' . $url . '" target="_blank" rel="noopener">' . esc_html( $m[1] ) . '</a>';
        }, $text );
        $text = preg_replace_callback( '/\*\*([^\*]+)\*\*/', fn( $m ) => '<strong>' . esc_html( $m[1] ) . '</strong>', $text );
        $text = preg_replace_callback( '/~~([^~]+)~~/', fn( $m ) => '<del>' . esc_html( $m[1] ) . '</del>', $text );
        $text = preg_replace_callback( '/\*([^\*]+)\*/', fn( $m ) => '<em>' . esc_html( $m[1] ) . '</em>', $text );
        $text = preg_replace_callback( '/`([^`]+)`/', fn( $m ) => '<code>' . esc_html( $m[1] ) . '</code>', $text );

        // 7. Unordered Lists (* or -) & Ordered Lists (1.)
        $text = preg_replace_callback( '/(?:^\s*[\*\-]\s+.*$\n?)+/m', function( $m ) {
            $items = preg_replace_callback( '/^\s*[\*\-]\s+(.*)$/m', fn( $li ) => '<li>' . esc_html( $li[1] ) . '</li>', $m[0] );
            return "<ul>\n" . $items . "</ul>\n";
        }, $text );

        $text = preg_replace_callback( '/(?:^\s*\d+\.\s+.*$\n?)+/m', function( $m ) {
            $items = preg_replace_callback( '/^\s*\d+\.\s+(.*)$/m', fn( $li ) => '<li>' . esc_html( $li[1] ) . '</li>', $m[0] );
            return "<ol>\n" . $items . "</ol>\n";
        }, $text );

        // 8. Paragraph Wrapping
        $blocks = explode( "\n\n", $text );
        $html   = [];
        foreach ( $blocks as $block ) {
            $block = trim( $block );
            if ( empty( $block ) ) {
                continue;
            }
            if ( preg_match( '/^<(?:h[1-6]|ul|ol|blockquote|pre|table|hr|img|div)/i', $block ) ) {
                $html[] = $block;
            } else {
                $html[] = '<p>' . nl2br( $block ) . '</p>';
            }
        }

        return implode( "\n\n", $html );
    }
}
