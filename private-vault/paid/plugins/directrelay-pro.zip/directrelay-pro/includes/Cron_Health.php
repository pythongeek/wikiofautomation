<?php
namespace DirectRelay;

defined( 'ABSPATH' ) || exit;

/**
 * Cron Health Monitor
 *
 * Schedules a frequent "ping" cron event that updates an option timestamp.
 * The admin dashboard then compares last_ping to now â€” if more than 10 minutes
 * old, WP-Cron is broken (no traffic to trigger it) and the admin is warned.
 *
 * Also detects if DISABLE_WP_CRON is set (site using real cron), in which
 * case we skip the warning and show a "Real cron active" badge instead.
 */
final class Cron_Health {

    private const PING_HOOK     = 'directrelay_cron_health_ping';
    private const OPTION_KEY    = 'directrelay_cron_last_ping';
    private const STALE_SECONDS = 600; /* 10 minutes */

    public static function init(): void {
        /* Register custom interval BEFORE scheduling (WordPress needs to know the interval) */
        add_filter( 'cron_schedules', [ __CLASS__, 'add_5min_interval' ] );
        add_action( self::PING_HOOK, [ __CLASS__, 'record_ping' ] );

        /* Schedule ping every 5 minutes */
        if ( ! wp_next_scheduled( self::PING_HOOK ) ) {
            if ( function_exists( 'directrelay_debug_log' ) ) {
                directrelay_debug_log( 'INFO', 'Scheduling health check ping cron because it was not scheduled' );
            }
            wp_schedule_event( time(), 'directrelay_5min', self::PING_HOOK );
        }
    }

    public static function add_5min_interval( array $schedules ): array {
        if ( ! isset( $schedules['directrelay_5min'] ) ) {
            $schedules['directrelay_5min'] = [
                'interval' => 300,
                'display'  => 'Every 5 minutes (DirectRelay add-on health check)',
            ];
        }
        return $schedules;
    }

    public static function record_ping(): void {
        update_option( self::OPTION_KEY, time(), false );
    }

    /**
     * Returns full health status.
     * @return array{
     *   status: 'ok'|'stale'|'real_cron'|'disabled',
     *   last_ping: int|null,
     *   stale_seconds: int,
     *   message: string,
     *   next_event: string|null,
     *   scheduled_hooks: array
     * }
     */
    public static function status(): array {
        $last_ping = (int) get_option( self::OPTION_KEY, 0 );
        $age       = $last_ping ? time() - $last_ping : PHP_INT_MAX;
        $next      = wp_next_scheduled( self::PING_HOOK );

        /* If real server cron is configured, WP-Cron is bypassed but still works */
        if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
            if ( $last_ping === 0 || $age > self::STALE_SECONDS ) {
                return [
                    'status'          => 'stale',
                    'last_ping'       => $last_ping ?: null,
                    'stale_seconds'   => self::STALE_SECONDS,
                    'message'         => __( 'Server cron is active (DISABLE_WP_CRON = true), but no cron pings have been received. Please verify that your system crontab job is configured correctly.', 'directrelay-automation-bridge-for-n8n'),
                    'next_event'      => $next ? sprintf(
                        /* translators: %s: human-readable time difference, e.g. "5 minutes" */
                        __( '%s from now', 'directrelay-automation-bridge-for-n8n'),
                        human_time_diff( $next )
                    ) : null,
                    'scheduled_hooks' => self::list_hooks(),
                ];
            }
            return [
                'status'          => 'real_cron',
                'last_ping'       => $last_ping ?: null,
                'stale_seconds'   => self::STALE_SECONDS,
                'message'         => __( 'Server cron active (DISABLE_WP_CRON = true). Webhooks and jobs run on schedule.', 'directrelay-automation-bridge-for-n8n'),
                'next_event'      => $next ? sprintf(
                    /* translators: %s: human-readable time difference, e.g. "5 minutes" */
                    __( '%s from now', 'directrelay-automation-bridge-for-n8n'),
                    human_time_diff( $next )
                ) : null,
                'scheduled_hooks' => self::list_hooks(),
            ];
        }

        if ( $last_ping === 0 ) {
            $msg = __( 'Cron has never fired. Either the site has no traffic or WP-Cron is disabled.', 'directrelay-automation-bridge-for-n8n');
            $st  = 'stale';
        } elseif ( $age > self::STALE_SECONDS ) {
            $mins = (int) ceil( $age / 60 );
            $msg  = sprintf( 
                /* translators: %d: number of minutes */
                __( 'Last cron ping was %d minutes ago - WP-Cron may not be running. Add a real server cron job.', 'directrelay-automation-bridge-for-n8n'), 
                $mins 
            );
            $st   = 'stale';
        } else {
            $mins = (int) ceil( $age / 60 );
            $msg  = sprintf( 
                /* translators: %d: number of minutes */
                __( 'Cron is healthy. Last ping %d minute(s) ago.', 'directrelay-automation-bridge-for-n8n'), 
                $mins 
            );
            $st   = 'ok';
        }

        return [
            'status'          => $st,
            'last_ping'       => $last_ping ?: null,
            'age_seconds'     => $last_ping ? $age : null,
            'stale_seconds'   => self::STALE_SECONDS,
            'message'         => $msg,
            'next_event'      => $next ? sprintf(
                    /* translators: %s: human-readable time difference, e.g. "5 minutes" */
                    __( '%s from now', 'directrelay-automation-bridge-for-n8n'),
                    human_time_diff( $next )
                ) : __( 'Not scheduled', 'directrelay-automation-bridge-for-n8n'),
            'scheduled_hooks' => self::list_hooks(),
        ];
    }

	private static function list_hooks(): array {
		$hooks = array(
			'directrelay_cron_health_ping'  => array(
				'label'    => __( 'Health ping (5 min)', 'directrelay-automation-bridge-for-n8n' ),
				'ondemand' => false,
			),
			'directrelay_prune_logs'        => array(
				'label'    => __( 'Prune activity log (daily)', 'directrelay-automation-bridge-for-n8n' ),
				'ondemand' => false,
			),
			'directrelay_prune_rate_limits' => array(
				'label'    => __( 'Prune rate limit buckets (hourly)', 'directrelay-automation-bridge-for-n8n' ),
				'ondemand' => false,
			),
			'directrelay_prune_brute_force' => array(
				'label'    => __( 'Prune brute-force log (hourly)', 'directrelay-automation-bridge-for-n8n' ),
				'ondemand' => false,
			),
			'directrelay_fire_webhook'      => array(
				'label'    => __( 'Webhook delivery', 'directrelay-automation-bridge-for-n8n' ),
				'ondemand' => true,
			),
			'directrelay_deliver_webhook'   => array(
				'label'    => __( 'Webhook delivery attempt (with retries)', 'directrelay-automation-bridge-for-n8n' ),
				'ondemand' => true,
			),
		);
		$result = array();
		foreach ( $hooks as $hook => $meta ) {
			$next = wp_next_scheduled( $hook );
			$result[] = array(
				'hook'        => $hook,
				'label'       => $meta['label'],
				'is_ondemand' => $meta['ondemand'],
				'scheduled'   => (bool) $next,
				'next_run'    => $next ? sprintf(
					/* translators: %s: human-readable time difference, e.g. "5 minutes" */
					__( 'in %s', 'directrelay-automation-bridge-for-n8n' ),
					human_time_diff( $next )
				) : ( $meta['ondemand'] ? __( 'On Demand (event-driven)', 'directrelay-automation-bridge-for-n8n' ) : '-' ),
			);
		}
		return $result;
	}
}
