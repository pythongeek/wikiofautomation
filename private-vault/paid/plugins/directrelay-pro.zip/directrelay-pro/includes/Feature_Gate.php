<?php
namespace DirectRelay;

defined( 'ABSPATH' ) || exit;

/**
 * Backward-compatibility shim for the legacy Feature_Gate class.
 *
 * The free plugin distributed on WordPress.org has every feature
 * fully unlocked. The class is kept so that any code path in the
 * add-on extension or older versions of the codebase can still call
 * these methods without fataling, but every method is a no-op:
 *
 *   - is_pro() / is_free() return their natural constant values
 *     so any "if ( ! is_pro() )" check is a no-op pass-through.
 *   - allow() always returns true.
 *   - upgrade_msg() returns an empty string.
 *   - can_create_post() always returns true.
 *
 * NOTE: do NOT reintroduce the legacy limit or activation-state
 * methods here. The WordPress.org Plugin Directory Guidelines forbid
 * usage limits, keyed unlock, and add-on build flags in any
 * plugin hosted on WP.org. The free plugin uses direct free options
 * (`directrelay_settings`) for any tunable webhook configuration.
 */
final class Feature_Gate {

	/**
	 * Whether the current site has add-on features.
	 *
	 * Returns true so legacy "if ( ! is_pro() )" checks degrade to
	 * a no-op pass-through. The free plugin does not gate features
	 * by activation state.
	 */
	public static function is_pro(): bool {
		return true;
	}

	/**
	 * Whether the current site is on the free site.
	 *
	 * Always false on a site that has the add-on plugin installed;
	 * always true on a free-only site. Kept for compatibility with
	 * older code that branched on the tier label; the free plugin
	 * has no behaviour gated on this value.
	 */
	public static function is_free(): bool {
		return ! self::is_pro();
	}

	/**
	 * Whether a feature is currently allowed.
	 */
	public static function allow( string $feature ): bool {
		return true;
	}

	/**
	 * Whether a specific SEO field is allowed.
	 */
	public static function allow_seo_field( string $field ): bool {
		return true;
	}

	/**
	 * Upgrade message placeholder.
	 *
	 * SEO write is provided by the directrelay-pro add-on plugin.
	 * See https://directrelay.wikiofautomation.com/directrelay-pro.
	 */
	public static function upgrade_msg( string $feature = '' ): string {
		return '';
	}

	/**
	 * Whether a new post or page can be created.
	 *
	 * The free plugin has no per-key monthly post limit. Post
	 * creation is always allowed.
	 */
	public static function can_create_post( int $key_id = 0 ): bool {
		return true;
	}
}
