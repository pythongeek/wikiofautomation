<?php
namespace DirectRelay;

defined( 'ABSPATH' ) || exit;

/**
 * DirectRelay  IndexNow Pinger
 *
 * Pings the IndexNow aggregator (api.indexnow.org) when a post is published;
 * the aggregator routes the submission to every participating search engine
 * (Bing, Yandex, Seznam, Naver), so no per-engine pings are needed. Includes
 * activity logging and the key-verification endpoint.
 *
 * @since 4.3.0
 */
final class IndexNow_Pinger {

    private const ENDPOINTS = [
        'https://api.indexnow.org/indexnow',
    ];

    public static function init(): void {
        /*
         * IndexNow pings are opt-in per the readme "External services" disclosure
         * and the WP.org Plugin Directory Guidelines (no data sent silently or by
         * default). The `enable_indexnow` setting must be true before the
         * transition_post_status listener is registered. The key-file endpoint
         * stays always-on so the site owner can verify the key is published
         * regardless of whether pings are currently enabled.
         */
        $settings = get_option( 'directrelay_settings', [] );
        if ( ! empty( $settings['enable_indexnow'] ) ) {
            add_action( 'transition_post_status', [ __CLASS__, 'on_post_publish' ], 10, 3 );
        }
        add_action( 'init', [ __CLASS__, 'serve_key_file' ] );
    }

    public static function get_api_key(): string {
        $key = get_option( 'directrelay_indexnow_key' );
        if ( ! $key ) {
            $key = bin2hex( random_bytes( 16 ) );
            update_option( 'directrelay_indexnow_key', $key );
        }
        return $key;
    }

    public static function serve_key_file(): void {
        if ( ! isset( $_SERVER['REQUEST_URI'] ) ) {
            return;
        }
        $path = rtrim( (string) wp_parse_url( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ), '/' );
        /* Exact path match (any subdirectory depth) — a substring match would
         * also hijack unrelated 404s like /?x=indexnow-key.txt. */
        if ( substr( $path, -17 ) !== '/indexnow-key.txt' ) {
            return;
        }
        header( 'Content-Type: text/plain; charset=utf-8' );
        echo esc_html( self::get_api_key() );
        exit;
    }

    public static function on_post_publish( string $new_status, string $old_status, \WP_Post $post ): void {
        if ( $post->post_type !== 'post' ) {
            return;
        }

        // Only trigger when transitioning to publish
        if ( $new_status !== 'publish' || $old_status === 'publish' ) {
            return;
        }

        $permalink = get_permalink( $post->ID );
        if ( ! $permalink ) {
            return;
        }

        self::ping( [ $permalink ], $post->ID );
    }

    public static function ping( array $urls, int $post_id = 0 ): void {
        $host = wp_parse_url( get_site_url(), PHP_URL_HOST );
        $key  = self::get_api_key();

        $payload = [
            'host'        => $host,
            'key'         => $key,
            'keyLocation' => get_site_url() . '/indexnow-key.txt',
            'urlList'     => array_values( array_unique( $urls ) ),
        ];

        $json_body = wp_json_encode( $payload );

        foreach ( self::ENDPOINTS as $endpoint ) {
            $response = wp_remote_post( $endpoint, [
                'method'    => 'POST',
                'timeout'   => 5,
                'blocking'  => false,
                'headers'   => [ 'Content-Type' => 'application/json' ],
                'body'      => $json_body,
                'sslverify' => true,
            ] );

            if ( is_wp_error( $response ) ) {
                /* Non-blocking requests still return WP_Error when the
                 * connection cannot be opened at all; record it in the
                 * activity log instead of letting it fatal the request. */
                Activity_Logger::write( [
                    'action'       => 'indexnow_error',
                    'method'       => 'POST',
                    'endpoint'     => 'indexnow',
                    'object_type'  => $post_id > 0 ? 'post' : null,
                    'object_id'    => $post_id > 0 ? $post_id : null,
                    'http_status'  => 0,
                    'response_msg' => $response->get_error_message(),
                ] );
            }
        }
    }
}
