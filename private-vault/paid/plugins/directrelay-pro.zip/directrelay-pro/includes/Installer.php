<?php
namespace DirectRelay;

defined( 'ABSPATH' ) || exit;

final class Installer {

    public static function activate( $network_wide = false ): void {
        /* Single-site build: the loader in directrelay.php refuses multisite
         * entirely, so activation always targets the one active site. */
        self::activate_blog();
    }

    public static function activate_blog(): void {
        /* Multisite supported in DirectRelay Pro */
        self::create_tables();
        update_option( 'directrelay_db_version', DIRECTRELAY_DB_VERSION );
        add_option( 'directrelay_settings', [
            'rate_limit'         => 120,
            'rate_window_sec'    => 60,
            'log_retention_days' => 30,
            'key_rotation_days'  => 0, /* site: Force expire keys */
            'require_https'      => false,
            'enable_webhooks'    => true,
            'webhook_timeout_ms' => 5000,
            'max_retry_attempts' => 3,
            'enable_indexnow'    => false, /* opt-in per WP.org Guideline 6 (no silent external calls) */
            'brute_force_limit'  => 10,
            'brute_force_window' => 300,
            'min_capability'     => 'manage_options',
            'max_sideload_size'  => 20, /* MB */
        ] );
    }

    public static function deactivate( $network_wide = false ): void {
        self::deactivate_blog();
    }

    public static function deactivate_blog(): void {
        /* Clear every scheduled hook this plugin uses */
        $hooks = [
            'directrelay_prune_logs',
            'directrelay_prune_rate_limits',
            'directrelay_fire_webhook',
            'directrelay_deliver_webhook',
            'directrelay_cron_health_ping',
            'directrelay_prune_brute_force',
        ];
        foreach ( $hooks as $h ) {
            wp_clear_scheduled_hook( $h );
        }
    }

    /*
     * Per-blog uninstall cleanup lives in the root uninstall.php, which runs
     * standalone: WordPress does not load the plugin during uninstall, so the
     * routine must not depend on this class being loaded.
     */

    /**
     * Schema rule: TEXT columns must never carry a DEFAULT literal. MySQL rejects
     * defaults on TEXT/BLOB columns ("BLOB, TEXT ... column can't have a default
     * value") while MariaDB and SQLite accept them, which hides the failure —
     * dbDelta() swallows the error and the tables silently never get created.
     * Every writer supplies these values explicitly (Api_Auth::create(), the
     * webhook create/update paths in Webhook_Controller and Ajax_Handler).
     */
    public static function create_tables(): void {
        global $wpdb;
        $c = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        /* ── API Keys & Agent Identities ────────────────────────────── */
        dbDelta( "CREATE TABLE {$wpdb->prefix}directrelay_keys (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            key_hash VARCHAR(191) NOT NULL,
            key_prefix CHAR(12) NOT NULL DEFAULT '',
            label VARCHAR(191) NOT NULL DEFAULT '',
            description TEXT DEFAULT NULL,
            environment VARCHAR(20) NOT NULL DEFAULT 'production',
            agent_role VARCHAR(50) NOT NULL DEFAULT 'full_access',
            daily_limit INT UNSIGNED NOT NULL DEFAULT 0,
            posts_today INT UNSIGNED NOT NULL DEFAULT 0,
            posts_today_date DATE DEFAULT NULL,
            restrict_own_posts TINYINT(1) NOT NULL DEFAULT 0,
            require_approval TINYINT(1) NOT NULL DEFAULT 0,
            scopes TEXT NOT NULL,
            ip_whitelist TEXT DEFAULT NULL,
            last_used_at DATETIME DEFAULT NULL,
            last_used_ip VARCHAR(45) DEFAULT NULL,
            expires_at DATETIME DEFAULT NULL,
            total_requests BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            revoked TINYINT(1) NOT NULL DEFAULT 0,
            revoked_at DATETIME DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY  uq_hash (key_hash),
            KEY  idx_uid (user_id),
            KEY  idx_prefix (key_prefix),
            KEY  idx_agent_role (agent_role)
        ) $c;" );

        /* ── Human Approvals Gateway ────────────────────────────────── */
        dbDelta( "CREATE TABLE {$wpdb->prefix}directrelay_approvals (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            ticket_uuid CHAR(36) NOT NULL,
            key_id BIGINT UNSIGNED NOT NULL,
            post_id BIGINT UNSIGNED DEFAULT NULL,
            token_hash VARCHAR(255) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            payload LONGTEXT NOT NULL,
            editor_feedback TEXT DEFAULT NULL,
            reviewer_user_id BIGINT UNSIGNED DEFAULT NULL,
            expires_at DATETIME NOT NULL,
            created_at DATETIME NOT NULL,
            resolved_at DATETIME DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY  uq_ticket (ticket_uuid),
            KEY  idx_status (status),
            KEY  idx_post (post_id),
            KEY  idx_key (key_id),
            KEY  idx_expires (expires_at)
        ) $c;" );

        /* ── Activity Log & Execution Traces ────────────────────────── */
        dbDelta( "CREATE TABLE {$wpdb->prefix}directrelay_log (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            request_uuid CHAR(36) DEFAULT NULL,
            key_id BIGINT UNSIGNED DEFAULT NULL,
            user_id BIGINT UNSIGNED DEFAULT NULL,
            ip_address VARCHAR(45) NOT NULL DEFAULT '',
            method VARCHAR(10) NOT NULL DEFAULT '',
            endpoint VARCHAR(512) NOT NULL DEFAULT '',
            action VARCHAR(128) NOT NULL DEFAULT '',
            object_type VARCHAR(64) DEFAULT NULL,
            object_id BIGINT UNSIGNED DEFAULT NULL,
            http_status SMALLINT DEFAULT NULL,
            response_msg TEXT DEFAULT NULL,
            duration_ms SMALLINT UNSIGNED DEFAULT NULL,
            request_payload LONGTEXT DEFAULT NULL,
            execution_trace LONGTEXT DEFAULT NULL,
            is_replay TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY  idx_key (key_id),
            KEY  idx_date (created_at),
            KEY  idx_action (action),
            KEY  idx_req_uuid (request_uuid)
        ) $c;" );

        /* ── Rate Limit ─────────────────────────────────────────────── */
        dbDelta( "CREATE TABLE {$wpdb->prefix}directrelay_rate (
            bucket VARCHAR(128) NOT NULL,
            hits SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            window_open DATETIME NOT NULL,
            PRIMARY KEY  (bucket)
        ) $c;" );

        /* ── Webhooks ───────────────────────────────────────────────── */
        dbDelta( "CREATE TABLE {$wpdb->prefix}directrelay_webhooks (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            key_id BIGINT UNSIGNED DEFAULT NULL,
            label VARCHAR(191) NOT NULL DEFAULT '',
            target_url TEXT NOT NULL,
            secret VARCHAR(255) DEFAULT NULL,
            events TEXT NOT NULL,
            post_types TEXT NOT NULL,
            active TINYINT(1) NOT NULL DEFAULT 1,
            last_fired_at DATETIME DEFAULT NULL,
            last_status SMALLINT DEFAULT NULL,
            fire_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
            fail_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id)
        ) $c;" );

        /* ── Webhook Delivery Log ───────────────────────────────────── */
        dbDelta( "CREATE TABLE {$wpdb->prefix}directrelay_webhook_log (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            webhook_id BIGINT UNSIGNED NOT NULL,
            event VARCHAR(64) NOT NULL DEFAULT '',
            object_id BIGINT UNSIGNED DEFAULT NULL,
            attempt TINYINT UNSIGNED NOT NULL DEFAULT 1,
            http_status SMALLINT DEFAULT NULL,
            duration_ms SMALLINT UNSIGNED DEFAULT NULL,
            response_body TEXT DEFAULT NULL,
            error_message TEXT DEFAULT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY  idx_wh (webhook_id),
            KEY  idx_date (created_at)
        ) $c;" );

        /* ── Analytics ──────────────────────────────────────────────── */
        dbDelta( "CREATE TABLE {$wpdb->prefix}directrelay_analytics (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            bucket_hour DATETIME NOT NULL,
            key_id BIGINT UNSIGNED DEFAULT NULL,
            endpoint VARCHAR(128) NOT NULL DEFAULT '',
            method VARCHAR(10) NOT NULL DEFAULT '',
            http_status SMALLINT NOT NULL DEFAULT 200,
            hits INT UNSIGNED NOT NULL DEFAULT 1,
            total_ms INT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY  uq_bucket (bucket_hour, key_id, endpoint, method, http_status),
            KEY  idx_hour (bucket_hour)
        ) $c;" );

        /* ── Brute Force Tracking ───────────────────────────────────── */
        dbDelta( "CREATE TABLE {$wpdb->prefix}directrelay_brute_force (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            ip_address VARCHAR(45) NOT NULL,
            event_type VARCHAR(32) NOT NULL DEFAULT 'failed_auth',
            hits SMALLINT UNSIGNED NOT NULL DEFAULT 1,
            window_open DATETIME NOT NULL,
            blocked_until DATETIME DEFAULT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY  uq_ip_type (ip_address, event_type),
            KEY  idx_ip (ip_address)
        ) $c;" );
    }

}
