<?php
namespace DirectRelay;

defined( 'ABSPATH' ) || exit;

final class Plugin {

    private static bool $booted = false;

    private function __construct() {}

    public static function settings(): array {
        return get_option( 'directrelay_settings', array() );
    }

    public static function boot(): void {
        if ( self::$booted ) {
            return;
        }
        self::$booted = true;

        /* DB schema upgrade */
        if ( (int) get_option( 'directrelay_db_version', 0 ) < DIRECTRELAY_DB_VERSION ) {
            Installer::create_tables();
            update_option( 'directrelay_db_version', DIRECTRELAY_DB_VERSION );
        }

        /* Services - order matters (Brute_Force before Api_Auth) */
        if ( class_exists( '\DirectRelay\Compatibility' ) ) {
            Compatibility::init();
        }
        if ( class_exists( '\DirectRelay\Brute_Force' ) ) {
            Brute_Force::init();
        }
        if ( class_exists( '\DirectRelay\Rate_Limiter' ) ) {
            Rate_Limiter::init();
        }
        if ( class_exists( '\DirectRelay\Activity_Logger' ) ) {
            Activity_Logger::init();
        }
        if ( class_exists( '\DirectRelay\Webhook_Manager' ) ) {
            Webhook_Manager::init();
        }
        if ( class_exists( '\DirectRelay\IndexNow_Pinger' ) ) {
            IndexNow_Pinger::init();
        }
        if ( class_exists( '\DirectRelay\Cron_Health' ) ) {
            Cron_Health::init();
        }
        if ( class_exists( '\DirectRelay\Approval_Gateway' ) ) {
            Approval_Gateway::init();
        }

        /* REST API */
        add_action( 'rest_api_init', [ __CLASS__, 'register_rest_routes' ] );
        add_filter( 'rest_post_dispatch', [ __CLASS__, 'security_headers' ], 10, 3 );

        /* Admin UI */
        if ( is_admin() ) {
            Admin\Menu::init();
        }

    }

    /**
     * Register the free REST surface.
     *
     * The add-on plugin (distributed from https://directrelay.wikiofautomation.com)
     * re-attaches its own routes via the `directrelay_ext_register_routes`
     * action fired at the end of this method. The add-on plugin is never
     * distributed via WordPress.org and is not required for any free feature.
     */
    public static function register_rest_routes(): void {
        $controllers = [
            'REST\Posts_Controller',
            'REST\Pages_Controller',
            'REST\SEO_Controller',
            'REST\Meta_Controller',
            'REST\Media_Controller',
            'REST\Taxonomy_Controller',
            'REST\Webhook_Controller',
            'REST\Openapi_Controller',
            'REST\Keys_Controller',
            'REST\System_Controller',
            'REST\Discovery_Controller',
        ];
        foreach ( $controllers as $class ) {
            $fqn = __NAMESPACE__ . '\\' . $class;
            if ( class_exists( $fqn ) ) {
                $fqn::register();
            }
        }
        /**
         * Fires after the free REST surface has been registered.
         *
         * The directrelay-pro plugin uses this hook to register its
         * add-on routes (bulk publish, universal schema publish,
         * approval portal, full debugger, Chart.js analytics). It is a
         * no-op when the add-on plugin is not installed.
         *
         * @since 5.1.0
         */
        do_action( 'directrelay_ext_register_routes' );
    }

    /**
     * Add security headers to all REST API responses.
     */
    public static function security_headers( $resp, \WP_REST_Server $server, \WP_REST_Request $req ) {
        if ( $resp instanceof \WP_HTTP_Response ) {
            $resp->header( 'X-Content-Type-Options', 'nosniff' );
            $resp->header( 'X-REST-Version', DIRECTRELAY_VERSION );
        }
        return $resp;
    }
}
