<?php
namespace DirectRelay;

defined( 'ABSPATH' ) || exit;

final class Post_Manager {

    private const STATUSES = [ 'draft', 'publish', 'pending', 'private', 'future', 'trash' ];

    public static function create( array $data, string $type = 'post' ): int|\WP_Error {
        if ( ! in_array( $data['status'] ?? 'draft', self::STATUSES, true ) ) {
            return new \WP_Error( 'amp_invalid', __( 'Invalid status.', 'directrelay-automation-bridge-for-n8n'), [ 'status' => 400 ] );
        }

        $raw_content = $data['content'] ?? '';
        $processed_content = Content_Processor::process( $raw_content, [
            'clean_ai_garbage'   => $data['clean_ai_garbage']   ?? true,
            'markdown_auto_parse' => $data['markdown_auto_parse'] ?? true,
        ] );

        $args = [
            'post_type'    => $type,
            'post_status'  => $data['status'] ?? 'draft',
            'post_title'   => wp_slash( $data['title']   ?? '' ),
            'post_content' => wp_slash( $processed_content ),
            'post_excerpt' => wp_slash( $data['excerpt'] ?? '' ),
            'post_name'    => sanitize_title( $data['slug'] ?? '' ),
            'post_author'  => get_current_user_id() ?: 1,
        ];
        if ( ! empty( $data['date'] ) ) {
            $ts = strtotime( $data['date'] );
            if ( $ts ) $args['post_date'] = get_date_from_gmt( gmdate( 'Y-m-d H:i:s', $ts ) );
        }
        if ( ! empty( $data['parent_id'] ) ) $args['post_parent'] = (int) $data['parent_id'];

        $id = wp_insert_post( $args, true );
        if ( is_wp_error( $id ) ) return $id;

        self::apply_taxonomy( $id, $data );
        self::apply_featured_image( $id, $data );
        if ( ! empty( $data['meta'] ) && is_array( $data['meta'] ) ) {
            self::apply_meta( $id, $data['meta'] );
        }
        if ( ! empty( $data['acf'] ) && is_array( $data['acf'] ) ) {
            self::apply_acf( $id, $data['acf'] );
        }
        return $id;
    }

    public static function update( int $id, array $data ): int|\WP_Error {
        $args = [ 'ID' => $id ];
        if ( array_key_exists( 'title',   $data ) ) $args['post_title']   = wp_slash( $data['title'] );
        if ( array_key_exists( 'content', $data ) ) {
            $args['post_content'] = wp_slash( Content_Processor::process( $data['content'], [
                'clean_ai_garbage'   => $data['clean_ai_garbage']   ?? true,
                'markdown_auto_parse' => $data['markdown_auto_parse'] ?? true,
            ] ) );
        }
        if ( array_key_exists( 'excerpt', $data ) ) $args['post_excerpt'] = wp_slash( $data['excerpt'] );
        if ( array_key_exists( 'slug',    $data ) ) $args['post_name']    = sanitize_title( $data['slug'] );
        if ( ! empty( $data['status'] ) && in_array( $data['status'], self::STATUSES, true ) ) {
            $args['post_status'] = $data['status'];
        }
        if ( ! empty( $data['date'] ) ) {
            $ts = strtotime( $data['date'] );
            if ( $ts ) $args['post_date'] = get_date_from_gmt( gmdate( 'Y-m-d H:i:s', $ts ) );
        }
        $r = wp_update_post( $args, true );
        if ( is_wp_error( $r ) ) return $r;

        self::apply_taxonomy( $id, $data );
        self::apply_featured_image( $id, $data );
        if ( ! empty( $data['meta'] ) && is_array( $data['meta'] ) ) {
            self::apply_meta( $id, $data['meta'] );
        }
        if ( ! empty( $data['acf'] ) && is_array( $data['acf'] ) ) {
            self::apply_acf( $id, $data['acf'] );
        }
        return $id;
    }

    public static function format( ?\WP_Post $post, array $fields = [] ): array {
        if ( ! $post ) return [];
        $fid = (int) get_post_thumbnail_id( $post->ID );
        $full = [
            'id'             => $post->ID,
            'type'           => $post->post_type,
            'status'         => $post->post_status,
            'title'          => $post->post_title,
            'slug'           => $post->post_name,
            'link'           => get_permalink( $post->ID ),
            'date_gmt'       => $post->post_date_gmt,
            'modified_gmt'   => $post->post_modified_gmt,
            'excerpt'        => $post->post_excerpt,
            'content'        => $post->post_content,
            'author'         => (int) $post->post_author,
            'parent'         => (int) $post->post_parent,
            'featured_media' => $fid ?: null,
            'featured_url'   => $fid ? wp_get_attachment_image_url( $fid, 'full' ) : null,
            'categories'     => wp_get_post_categories( $post->ID, [ 'fields' => 'ids' ] ),
            'tags'           => wp_get_post_tags( $post->ID, [ 'fields' => 'ids' ] ),
            'word_count'     => str_word_count( wp_strip_all_tags( $post->post_content ) ),
        ];
        return $fields ? array_intersect_key( $full, array_flip( $fields ) ) : $full;
    }

    private static function apply_featured_image( int $id, array $data ): void {
        $url = $data['featured_media_url'] ?? $data['featured_url'] ?? null;
        if ( ! $url && isset( $data['featured_media'] ) && is_string( $data['featured_media'] ) && str_starts_with( $data['featured_media'], 'http' ) ) {
            $url = $data['featured_media'];
        }

        if ( $url && filter_var( $url, FILTER_VALIDATE_URL ) ) {
            $safe_url = esc_url_raw( $url );
            if ( ! Api_Auth::is_url_safe( $safe_url ) ) {
                return;
            }

            $att_id = self::sideload_url( $safe_url, $id );
            if ( ! is_wp_error( $att_id ) && (int) $att_id > 0 ) {
                set_post_thumbnail( $id, (int) $att_id );
                
                // Auto ALT Text & Image SEO Optimization
                $alt_text = $data['seo']['focus_keyword'] ?? $data['title'] ?? get_the_title( $id );
                if ( ! empty( $alt_text ) ) {
                    update_post_meta( (int) $att_id, '_wp_attachment_image_alt', sanitize_text_field( $alt_text ) );
                    wp_update_post( [
                        'ID'           => (int) $att_id,
                        'post_title'   => sanitize_text_field( $alt_text ),
                        'post_excerpt' => sanitize_text_field( $alt_text ),
                    ] );
                }
                return;
            }
        }

        if ( array_key_exists( 'featured_media', $data ) ) {
            $media_id = (int) $data['featured_media'];
            $media_id > 0 ? set_post_thumbnail( $id, $media_id ) : delete_post_thumbnail( $id );
        }
    }

    /**
     * Fetch a remote file with SSRF validation on every hop.
     *
     * download_url()/wp_remote_get follow redirects blindly, so a public URL
     * can 302 into an internal address. This fetches with redirects disabled
     * and re-validates every Location with Api_Auth::is_url_safe() +
     * revalidate_ip() before the next hop, closing the open-redirect gap and
     * narrowing the DNS-rebinding window to the unavoidable same-request
     * resolution inside the final fetch.
     *
     * @return array{body:string,content_type:string,final_url:string}|\WP_Error
     */
    public static function safe_fetch_url( string $url, int $max_bytes ): array|\WP_Error {
        $current = esc_url_raw( $url );
        $body    = null;

        for ( $hop = 0; $hop < 4; $hop++ ) {
            if ( ! Api_Auth::is_url_safe( $current ) || null === Api_Auth::revalidate_ip( $current ) ) {
                return new \WP_Error( 'amp_ssrf_blocked', __( 'SSRF protection: Image URL is blocked.', 'directrelay-automation-bridge-for-n8n' ), [ 'status' => 403 ] );
            }

            $response = wp_safe_remote_get( $current, [
                'timeout'             => 15,
                'redirection'         => 0, /* Redirects are followed manually, re-validated above. */
                'limit_response_size' => $max_bytes,
            ] );
            if ( is_wp_error( $response ) ) {
                return $response;
            }

            $code = (int) wp_remote_retrieve_response_code( $response );
            if ( $code >= 300 && $code < 400 ) {
                $location = (string) wp_remote_retrieve_header( $response, 'location' );
                if ( '' === $location ) {
                    return new \WP_Error( 'amp_sideload_failed', __( 'Remote server returned a redirect without a location header.', 'directrelay-automation-bridge-for-n8n' ), [ 'status' => 502 ] );
                }
                $next = self::absolutize_redirect( $current, $location );
                if ( '' === $next ) {
                    return new \WP_Error( 'amp_sideload_failed', __( 'Remote server returned an invalid redirect location.', 'directrelay-automation-bridge-for-n8n' ), [ 'status' => 502 ] );
                }
                $current = $next;
                continue;
            }

            if ( $code < 200 || $code >= 300 ) {
                return new \WP_Error(
                    'amp_sideload_failed',
                    sprintf( /* translators: %d: HTTP status code */ __( 'Remote image request returned HTTP %d.', 'directrelay-automation-bridge-for-n8n' ), $code ),
                    [ 'status' => 502 ]
                );
            }

            $body = wp_remote_retrieve_body( $response );
            break;
        }

        if ( null === $body || '' === $body ) {
            return new \WP_Error( 'amp_sideload_failed', __( 'Remote image could not be downloaded (redirect limit reached or empty response).', 'directrelay-automation-bridge-for-n8n' ), [ 'status' => 502 ] );
        }
        if ( strlen( $body ) >= $max_bytes ) {
            return new \WP_Error( 'amp_sideload_failed', __( 'Remote image exceeds the maximum sideload size.', 'directrelay-automation-bridge-for-n8n' ), [ 'status' => 413 ] );
        }

        return [
            'body'         => $body,
            'content_type' => strtolower( (string) wp_remote_retrieve_header( $response, 'content-type' ) ),
            'final_url'    => $current,
        ];
    }

    /**
     * Sideload a remote image into the media library (safe fetch + attach).
     *
     * @param int    $post_id Post to attach to (0 = unattached).
     * @param string $title   Optional attachment title (media_handle_sideload desc).
     * @return int|\WP_Error Attachment ID on success.
     */
    public static function sideload_url( string $url, int $post_id = 0, string $title = '' ): int|\WP_Error {
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $max_bytes = max( 1, (int) ( get_option( 'directrelay_settings', [] )['max_sideload_size'] ?? 20 ) ) * MB_IN_BYTES;
        $fetched   = self::safe_fetch_url( $url, $max_bytes );
        if ( is_wp_error( $fetched ) ) {
            return $fetched;
        }

        /* The filename extension must match the real bytes or
         * media_handle_sideload() rejects the file, so the Content-Type wins
         * over the URL's own tail when both are known. */
        $ext_map = [
            'image/jpeg' => 'jpg', 'image/jpg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif',
            'image/webp' => 'webp', 'image/avif' => 'avif', 'image/bmp' => 'bmp',
            'image/x-icon' => 'ico', 'image/vnd.microsoft.icon' => 'ico',
        ];
        $ext = '';
        foreach ( $ext_map as $mime => $candidate ) {
            if ( str_starts_with( $fetched['content_type'], $mime ) ) {
                $ext = $candidate;
                break;
            }
        }

        $name = sanitize_file_name( basename( (string) wp_parse_url( $fetched['final_url'], PHP_URL_PATH ) ) );
        $stem = pathinfo( $name, PATHINFO_FILENAME );
        $stem = is_string( $stem ) && '' !== $stem ? $stem : 'image-' . gmdate( 'YmdHis' );
        if ( '' !== $ext ) {
            $name = $stem . '.' . $ext;
        } elseif ( ! preg_match( '/\.(jpe?g|png|gif|webp|avif|ico|bmp)$/i', $name ) ) {
            return new \WP_Error( 'amp_sideload_failed', __( 'Remote file is not a recognizable image type.', 'directrelay-automation-bridge-for-n8n' ), [ 'status' => 415 ] );
        }

        $tmp = wp_tempnam( $name );
        if ( ! $tmp ) {
            return new \WP_Error( 'amp_sideload_failed', __( 'Could not create a temporary file for the image.', 'directrelay-automation-bridge-for-n8n' ), [ 'status' => 500 ] );
        }
        global $wp_filesystem;
        if ( ! $wp_filesystem ) {
            WP_Filesystem();
        }
        if ( ! $wp_filesystem->put_contents( $tmp, $fetched['body'] ) ) {
            wp_delete_file( $tmp );
            return new \WP_Error( 'amp_sideload_failed', __( 'Could not store the downloaded image.', 'directrelay-automation-bridge-for-n8n' ), [ 'status' => 500 ] );
        }

        $att_id = media_handle_sideload(
            [ 'name' => $name, 'tmp_name' => $tmp ],
            $post_id,
            '' !== $title ? sanitize_text_field( $title ) : null
        );
        if ( is_wp_error( $att_id ) ) {
            /* media_handle_sideload() leaves the temp file behind on failure. */
            wp_delete_file( $tmp );
            return $att_id;
        }
        return (int) $att_id;
    }

    /**
     * Resolve a redirect Location against the URL it came from.
     * Returns '' for anything that does not produce a clean http(s) URL.
     */
    private static function absolutize_redirect( string $base_url, string $location ): string {
        $location = trim( $location );
        if ( '' === $location ) {
            return '';
        }
        if ( preg_match( '#^https?://#i', $location ) ) {
            return esc_url_raw( $location );
        }
        $p = wp_parse_url( $base_url );
        if ( empty( $p['scheme'] ) || empty( $p['host'] ) ) {
            return '';
        }
        $base = $p['scheme'] . '://' . $p['host'] . ( isset( $p['port'] ) ? ':' . $p['port'] : '' );
        if ( str_starts_with( $location, '/' ) ) {
            return esc_url_raw( $base . $location );
        }
        $dir = isset( $p['path'] ) ? (string) $p['path'] : '/';
        return esc_url_raw( $base . preg_replace( '#/[^/]*$#', '/', $dir ) . $location );
    }

    private static function apply_taxonomy( int $id, array $data ): void {
        if ( ! empty( $data['category_names'] ) ) {
            $data['categories'] = Taxonomy_Manager::resolve_categories( (array) $data['category_names'] );
        }
        if ( ! empty( $data['tag_names'] ) ) {
            $data['tags'] = Taxonomy_Manager::resolve_tags( (array) $data['tag_names'] );
        }
        if ( isset( $data['categories'] ) ) {
            $cats = Taxonomy_Manager::resolve_categories( (array) $data['categories'] );
            wp_set_post_categories( $id, $cats );
        }
        if ( isset( $data['tags'] ) ) {
            $tags = Taxonomy_Manager::resolve_tags( (array) $data['tags'] );
            wp_set_post_tags( $id, $tags );
        }
    }

    private static function apply_meta( int $id, array $meta ): void {
        $protected = [ '_edit_lock', '_edit_last', '_wp_old_slug', '_wp_attachment_metadata', '_thumbnail_id' ];
        $has_acf = function_exists( 'update_field' );
        foreach ( $meta as $k => $v ) {
            $key = sanitize_text_field( (string) $k );
            if ( empty( $key ) || in_array( $key, $protected, true ) ) {
                continue;
            }
            /* Core-internal (_wp_*: templates, attachment files, menu items),
             * attachment-binding (_thumbnail_id) and plugin-internal meta are
             * never agent-writable. Custom theme meta like _myfield stays
             * writable. */
            if ( str_starts_with( $key, '_wp_' ) || str_starts_with( $key, 'directrelay_' ) || str_starts_with( $key, '_directrelay' ) ) {
                continue;
            }

            if ( $has_acf && str_starts_with( $key, 'field_' ) ) {
                update_field( $key, $v, $id );
            } else {
                update_post_meta( $id, $key, self::sanitize_meta_value( $v ) );
            }
        }
    }

    private static function apply_acf( int $id, array $acf_fields ): void {
        if ( ! function_exists( 'update_field' ) ) {
            self::apply_meta( $id, $acf_fields );
            return;
        }
        foreach ( $acf_fields as $selector => $val ) {
            $sel = sanitize_text_field( (string) $selector );
            if ( ! empty( $sel ) ) {
                update_field( $sel, $val, $id );
            }
        }
    }

    public static function sanitize_meta_value( mixed $value ): mixed {
        if ( is_array( $value ) ) {
            return array_map( [ self::class, 'sanitize_meta_value' ], $value );
        }
        if ( is_string( $value ) ) {
            if ( is_serialized( $value ) ) {
                return '';
            }
            if ( $value !== wp_strip_all_tags( $value ) ) {
                return wp_kses_post( $value );
            }
            return sanitize_text_field( $value );
        }
        return $value;
    }
}
