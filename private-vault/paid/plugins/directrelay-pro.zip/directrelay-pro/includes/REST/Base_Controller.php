<?php
namespace DirectRelay\REST;

defined( 'ABSPATH' ) || exit;

use DirectRelay\Api_Auth;
use DirectRelay\Rate_Limiter;
use DirectRelay\Activity_Logger;

abstract class Base_Controller {

    protected const NS = DIRECTRELAY_NS;

    /** Authenticate + rate-limit + scope check. Returns true or WP_Error. */
    protected static function guard( \WP_REST_Request $req, string $scope ): bool|\WP_Error {
        $has_api_auth = ! empty( $req->get_header( 'authorization' ) ) || ! empty( $req->get_header( 'x-api-key' ) );

        if ( ! $has_api_auth && is_user_logged_in() && current_user_can( 'manage_options' ) ) {
            $req->set_param( '_amp_key', [
                'id'           => 0,
                'user_id'      => get_current_user_id(),
                'label'        => 'Native Admin Session',
                'is_full'      => true,
                'scopes_array' => [],
            ] );
            $req->set_param( '_amp_start', microtime( true ) );
            $req->set_param( '_amp_rid',   wp_generate_uuid4() );
            return true;
        }

        $key = Api_Auth::authenticate( $req );
        if ( is_wp_error( $key ) ) {
            return $key;
        }

        $ip = Api_Auth::client_ip();
        if ( Api_Auth::is_ip_whitelisted( $ip ) ) {
            $rate = [
                'allowed'   => true,
                'remaining' => 999999,
                'reset_at'  => time() + 3600,
                'limit'     => 999999,
            ];
        } else {
            $rate = Rate_Limiter::check( (int) $key['id'] );
        }

        add_filter( 'rest_post_dispatch', static function ( \WP_REST_Response $r ) use ( $rate ): \WP_REST_Response {
            $r->header( 'X-RateLimit-Limit',     (string) $rate['limit'] );
            $r->header( 'X-RateLimit-Remaining', (string) $rate['remaining'] );
            $r->header( 'X-RateLimit-Reset',     (string) $rate['reset_at'] );
            return $r;
        } );

        if ( ! $rate['allowed'] ) {
            return new \WP_Error( 
                'amp_rate_limited', 
                sprintf( 
                    /* translators: %s: retry date/time */
                    __( 'Rate limit exceeded. Retry after %s', 'directrelay-automation-bridge-for-n8n' ), 
                    gmdate( 'c', $rate['reset_at'] ) 
                ), 
                [ 'status' => 429 ] 
            );
        }

        if ( $scope && ! Api_Auth::has_scope( $key, $scope ) ) {
            return new \WP_Error( 
                'amp_forbidden', 
                sprintf( 
                    /* translators: %s: required scope name */
                    __( 'Scope required: %s', 'directrelay-automation-bridge-for-n8n' ), 
                    $scope 
                ), 
                [ 'status' => 403 ] 
            );
        }

        // Agent Profile restrictions check
        $agent_check = \DirectRelay\Agent_Profiles::can_perform( $key, $scope );
        if ( is_wp_error( $agent_check ) ) {
            return $agent_check;
        }

        // Daily Post / Velocity Guardrails check on write actions
        // (add-on advanced guardrails. The free plugin's Rate_Limiter
        // already applies a sliding-window rate cap below, so the
        // absence of the add-on class is a safe no-op.)
        if ( in_array( $scope, [ 'posts:write', 'posts:publish', 'bulk:write', 'universal:write' ], true ) && class_exists( '\DirectRelay\Guardrails_Manager' ) ) {
            $daily_check = \DirectRelay\Guardrails_Manager::check_daily_limit( $key );
            if ( is_wp_error( $daily_check ) ) {
                return $daily_check;
            }
        }

        if ( ! empty( $key['user_id'] ) ) {
            wp_set_current_user( (int) $key['user_id'] );
        }

        $req->set_param( '_amp_key',   $key );
        $req->set_param( '_amp_start', microtime( true ) );
        $req->set_param( '_amp_rid',   wp_generate_uuid4() );
        return true;
    }

    /** Return true or a WP_Error when an add-on feature is required. */
    protected static function require_pro( string $feature ): bool|\WP_Error {
        return true;
    }

    protected static function ok( \WP_REST_Request $req, mixed $data, int $status = 200, string $action = '', ?int $obj_id = null, string $obj_type = '' ): \WP_REST_Response {
        self::log( $req, $status, 'success', $action, $obj_id, $obj_type );
        $r = new \WP_REST_Response( [ 'success' => true, 'data' => $data, 'request_id' => $req->get_param( '_amp_rid' ) ], $status );
        $r->header( 'X-Request-ID', (string) $req->get_param( '_amp_rid' ) );
        return $r;
    }

    protected static function fail( \WP_REST_Request $req, \WP_Error $err, string $action = '' ): \WP_Error {
        self::log( $req, (int) ( $err->get_error_data()['status'] ?? 400 ), $err->get_error_message(), $action );
        return $err;
    }

    private static function log( \WP_REST_Request $req, int $status, string $msg, string $action, ?int $obj_id = null, string $obj_type = '' ): void {
        $key   = $req->get_param( '_amp_key' );
        $start = (float) ( $req->get_param( '_amp_start' ) ?? microtime( true ) );
        $body  = $req->get_json_params() ?: [];
        $sanitized_body = $body;
        unset( $sanitized_body['content'], $sanitized_body['post_content'], $sanitized_body['body'] );
        if ( isset( $body['content'] ) ) {
            $sanitized_body['content_preview'] = substr( wp_strip_all_tags( (string) $body['content'] ), 0, 150 ) . '...';
        }

        Activity_Logger::write( [
            'request_uuid'    => $req->get_param( '_amp_rid' ),
            'key_id'          => $key['id']      ?? null,
            'user_id'         => $key['user_id'] ?? null,
            'method'          => $req->get_method(),
            'endpoint'        => $req->get_route(),
            'action'          => $action ?: str_replace( '/', '_', trim( $req->get_route(), '/' ) ),
            'object_type'     => $obj_type ?: null,
            'object_id'       => $obj_id,
            'http_status'     => $status,
            'response_msg'    => substr( $msg, 0, 200 ),
            'duration_ms'     => (int) round( ( microtime( true ) - $start ) * 1000 ),
            'request_payload' => $sanitized_body,
            'is_replay'       => (bool) $req->get_param( '_amp_is_replay' ),
        ] );
    }

    protected static function pagination_args(): array {
        return [
            'per_page' => [ 'type' => 'integer', 'default' => 20, 'minimum' => 1, 'maximum' => 100 ],
            'page'     => [ 'type' => 'integer', 'default' => 1,  'minimum' => 1 ],
            'search'   => [ 'type' => 'string' ],
            'orderby'  => [ 'type' => 'string', 'enum' => [ 'date', 'modified', 'title', 'id' ], 'default' => 'date' ],
            'order'    => [ 'type' => 'string', 'enum' => [ 'ASC', 'DESC' ], 'default' => 'DESC' ],
        ];
    }
}
