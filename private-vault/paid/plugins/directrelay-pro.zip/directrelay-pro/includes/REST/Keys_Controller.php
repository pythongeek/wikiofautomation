<?php
namespace DirectRelay\REST;

defined( 'ABSPATH' ) || exit;

use DirectRelay\Api_Auth;

final class Keys_Controller extends Base_Controller {

    public static function register(): void {
        register_rest_route( self::NS, '/keys', [ [ 'methods' => \WP_REST_Server::READABLE, 'callback' => [ self::class, 'index' ], 'permission_callback' => fn( $r ) => self::guard( $r, 'keys:read' ) ] ] );
        register_rest_route( self::NS, '/keys/(?P<id>\d+)/revoke', [ [ 'methods' => \WP_REST_Server::CREATABLE, 'callback' => [ self::class, 'revoke' ], 'permission_callback' => fn( $r ) => self::guard( $r, 'keys:write' ) ] ] );
        register_rest_route( self::NS, '/keys/(?P<id>\d+)/rotate', [ [ 'methods' => \WP_REST_Server::CREATABLE, 'callback' => [ self::class, 'rotate' ], 'permission_callback' => fn( $r ) => self::guard( $r, 'keys:rotate' ) ] ] );
    }

    public static function index( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $key  = $req->get_param( '_amp_key' );
        $rows = Api_Auth::list_keys( (int) $key['user_id'] );
        return self::ok( $req, [ 'keys' => $rows, 'total' => count( $rows ) ], 200, 'list_keys' );
    }

    public static function revoke( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $id  = (int) $req->get_param( 'id' );
        $key = $req->get_param( '_amp_key' );
        global $wpdb;
        $owner = (int) $wpdb->get_var( $wpdb->prepare( "SELECT user_id FROM {$wpdb->prefix}directrelay_keys WHERE id=%d", $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        if ( $owner !== (int) $key['user_id'] && ! user_can( (int) $key['user_id'], 'manage_options' ) ) {
            return self::fail( $req, new \WP_Error( 'amp_forbidden', 'Cannot revoke this key.', [ 'status' => 403 ] ), 'revoke_key' );
        }
        return self::ok( $req, [ 'revoked' => Api_Auth::revoke( $id ), 'id' => $id ], 200, 'revoke_key', $id, 'key' );
    }

    public static function rotate( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $id  = (int) $req->get_param( 'id' );
        $key = $req->get_param( '_amp_key' );
        global $wpdb;
        $owner = (int) $wpdb->get_var( $wpdb->prepare( "SELECT user_id FROM {$wpdb->prefix}directrelay_keys WHERE id=%d", $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        if ( $owner !== (int) $key['user_id'] && ! user_can( (int) $key['user_id'], 'manage_options' ) ) {
            return self::fail( $req, new \WP_Error( 'amp_forbidden', 'Cannot rotate this key.', [ 'status' => 403 ] ), 'rotate_key' );
        }
        $result = Api_Auth::rotate( $id );
        if ( is_wp_error( $result ) ) {
            return self::fail( $req, $result, 'rotate_key' );
        }
        return self::ok( $req, $result, 200, 'rotate_key', $id, 'key' );
    }
}
