<?php
namespace DirectRelay\REST;

defined( 'ABSPATH' ) || exit;

final class Media_Controller extends Base_Controller {

    public static function register(): void {
        register_rest_route( self::NS, '/media', [
            [ 'methods' => \WP_REST_Server::READABLE,  'callback' => [ self::class, 'index' ],   'permission_callback' => fn( $r ) => self::guard( $r, 'media:read' ),  'args' => self::pagination_args() ],
            [ 'methods' => \WP_REST_Server::CREATABLE, 'callback' => [ self::class, 'upload' ],  'permission_callback' => fn( $r ) => self::guard( $r, 'media:write' ) ],
        ] );
        register_rest_route( self::NS, '/media/sideload', [
            [ 'methods' => \WP_REST_Server::CREATABLE, 'callback' => [ self::class, 'sideload' ],'permission_callback' => fn( $r ) => self::guard( $r, 'media:write' ) ],
        ] );
        register_rest_route( self::NS, '/media/(?P<id>\d+)', [
            [ 'methods' => \WP_REST_Server::READABLE,  'callback' => [ self::class, 'show' ],    'permission_callback' => fn( $r ) => self::guard( $r, 'media:read' ) ],
            [ 'methods' => \WP_REST_Server::EDITABLE,  'callback' => [ self::class, 'update' ],  'permission_callback' => fn( $r ) => self::guard( $r, 'media:write' ) ],
            [ 'methods' => \WP_REST_Server::DELETABLE, 'callback' => [ self::class, 'destroy' ], 'permission_callback' => fn( $r ) => self::guard( $r, 'media:delete' ) ],
        ] );
    }

    public static function index( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $q = new \WP_Query( [
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'posts_per_page' => (int) $req->get_param( 'per_page' ),
            'paged'          => (int) $req->get_param( 'page' ),
            'no_found_rows'  => false,
        ] );
        return self::ok( $req, [
            'media' => array_map( [ self::class, 'format_media' ], $q->posts ),
            'total' => (int) $q->found_posts,
        ], 200, 'list_media' );
    }

    public static function show( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $id = (int) $req->get_param( 'id' );
        $a  = get_post( $id );
        if ( ! $a || $a->post_type !== 'attachment' ) {
            return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Media not found.', 'directrelay-automation-bridge-for-n8n'), [ 'status' => 404 ] ), 'get_media' );
        }
        return self::ok( $req, [ 'media' => self::format_media( $a ) ], 200, 'get_media', $id, 'media' );
    }

    /** Upload via base64-encoded file data */
    public static function upload( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        self::require_wp_files();
        $body = $req->get_json_params() ?: [];

        if ( empty( $body['file_base64'] ) || empty( $body['filename'] ) ) {
            return self::fail( $req, new \WP_Error( 'amp_invalid', __( 'file_base64 and filename are required.', 'directrelay-automation-bridge-for-n8n'), [ 'status' => 400 ] ), 'upload_media' );
        }

        $settings = get_option( 'directrelay_settings', [] );
        $max_mb   = (int) ( $settings['max_sideload_size'] ?? 20 );
        
        /* Estimate size from base64 (roughly 4/3 of binary) */
        if ( strlen( $body['file_base64'] ) > ( $max_mb * 1024 * 1024 * 1.35 ) ) {
            /* translators: %d: file size limit in megabytes */
            return self::fail( $req, new \WP_Error( 'amp_too_large', sprintf( __( 'File exceeds limit of %dMB.', 'directrelay-automation-bridge-for-n8n'), $max_mb ), [ 'status' => 413 ] ), 'upload_media' );
        }

        $decoded = base64_decode( $body['file_base64'], true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
        if ( ! $decoded ) {
            return self::fail( $req, new \WP_Error( 'amp_invalid', __( 'Invalid base64 data.', 'directrelay-automation-bridge-for-n8n'), [ 'status' => 400 ] ), 'upload_media' );
        }

        return self::save_upload( $req, $decoded, $body );
    }

    /** Sideload from a public URL — fetches the file then attaches it to the media library */
    public static function sideload( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        self::require_wp_files();
        $body = $req->get_json_params() ?: [];
        $url  = esc_url_raw( $body['url'] ?? '' );

        if ( ! $url || ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
            return self::fail( $req, new \WP_Error( 'amp_invalid', __( 'A valid "url" field is required.', 'directrelay-automation-bridge-for-n8n'), [ 'status' => 400 ] ), 'sideload_media' );
        }

        $settings = get_option( 'directrelay_settings', [] );
        $max_mb   = (int) ( $settings['max_sideload_size'] ?? 20 );

        /* Redirect-safe fetch: every hop is re-validated against SSRF
         * (is_url_safe + revalidate_ip) before it is followed, so a public
         * URL cannot 302 into an internal address. */
        $fetched = \DirectRelay\Post_Manager::safe_fetch_url( $url, $max_mb * MB_IN_BYTES );
        if ( is_wp_error( $fetched ) ) {
            return self::fail( $req, $fetched, 'sideload_media' );
        }

        /* Derive filename from URL if not provided */
        $filename = $body['filename'] ?? basename( wp_parse_url( $fetched['final_url'], PHP_URL_PATH ) ) ?: 'media-file';

        return self::save_upload( $req, $fetched['body'], array_merge( $body, [ 'filename' => $filename ] ), 'sideload_media' );
    }

    /** Shared logic: write bytes to media library */
    private static function save_upload( \WP_REST_Request $req, string $bytes, array $meta, string $action = 'upload_media' ): \WP_REST_Response|\WP_Error {
        $filename  = sanitize_file_name( $meta['filename'] ?? 'upload' );

        /* Validate MIME type against WordPress allowed types */
        $filetype  = wp_check_filetype( $filename );
        $mime_type = $filetype['type'] ?: 'application/octet-stream';
        $allowed   = get_allowed_mime_types();
        $ext       = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
        $valid_ext = ! empty( $allowed ) && in_array( $mime_type, $allowed, true );

        if ( ! $valid_ext ) {
            /* translators: %s: MIME type */
            return self::fail( $req, new \WP_Error( 'amp_bad_filetype', sprintf( __( 'File type %s is not allowed.', 'directrelay-automation-bridge-for-n8n'), $mime_type ), [ 'status' => 415 ] ), $action );
        }

        $tmp       = wp_tempnam( $filename );
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
        file_put_contents( $tmp, $bytes );

        $file_arr = [
            'name'     => $filename,
            'type'     => $mime_type,
            'tmp_name' => $tmp,
            'size'     => strlen( $bytes ),
            'error'    => 0,
        ];
        $uploaded = wp_handle_sideload( $file_arr, [ 'test_form' => false ] );
        @unlink( $tmp ); // phpcs:ignore

        if ( isset( $uploaded['error'] ) ) {
            return self::fail( $req, new \WP_Error( 'amp_upload_fail', $uploaded['error'], [ 'status' => 500 ] ), $action );
        }

        $att_id = wp_insert_attachment( [
            'post_mime_type' => $uploaded['type'],
            'post_title'     => sanitize_text_field( $meta['title'] ?? pathinfo( $filename, PATHINFO_FILENAME ) ),
            'post_excerpt'   => sanitize_text_field( $meta['caption'] ?? '' ),
            'post_status'    => 'inherit',
        ], $uploaded['file'] );

        if ( is_wp_error( $att_id ) ) {
            return self::fail( $req, $att_id, $action );
        }

        wp_update_attachment_metadata( $att_id, wp_generate_attachment_metadata( $att_id, $uploaded['file'] ) );
        if ( ! empty( $meta['alt'] ) ) {
            update_post_meta( $att_id, '_wp_attachment_image_alt', sanitize_text_field( $meta['alt'] ) );
        }
        if ( ! empty( $meta['post_id'] ) ) {
            /* Optionally attach to a post */
            wp_update_post( [ 'ID' => $att_id, 'post_parent' => absint( $meta['post_id'] ) ] );
        }

        return self::ok( $req, [ 'media' => self::format_media( get_post( $att_id ) ) ], 201, $action, $att_id, 'media' );
    }

    public static function update( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $id   = (int) $req->get_param( 'id' );
        $body = $req->get_json_params() ?: [];
        $att  = get_post( $id );
        if ( ! $att || $att->post_type !== 'attachment' ) {
            return self::fail( $req, new \WP_Error( 'amp_not_found', 'Media not found.', [ 'status' => 404 ] ), 'update_media' );
        }
        $args = [ 'ID' => $id ];
        if ( isset( $body['title'] )       ) $args['post_title']  = sanitize_text_field( $body['title'] );
        if ( isset( $body['caption'] )     ) $args['post_excerpt'] = sanitize_text_field( $body['caption'] );
        if ( isset( $body['description'] ) ) $args['post_content'] = sanitize_textarea_field( $body['description'] );
        wp_update_post( $args );
        if ( isset( $body['alt'] ) ) {
            update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( $body['alt'] ) );
        }
        return self::ok( $req, [ 'media' => self::format_media( get_post( $id ) ) ], 200, 'update_media', $id, 'media' );
    }

    public static function destroy( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $id = (int) $req->get_param( 'id' );
        if ( ! get_post( $id ) ) {
            return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Media not found.', 'directrelay-automation-bridge-for-n8n'), [ 'status' => 404 ] ), 'delete_media' );
        }
        $r = wp_delete_attachment( $id, true );
        return self::ok( $req, [ 'deleted' => (bool) $r, 'id' => $id ], 200, 'delete_media', $id, 'media' );
    }

    public static function format_media( \WP_Post $a ): array {
        $meta = wp_get_attachment_metadata( $a->ID );
        return [
            'id'          => $a->ID,
            'title'       => $a->post_title,
            'alt'         => get_post_meta( $a->ID, '_wp_attachment_image_alt', true ),
            'caption'     => $a->post_excerpt,
            'description' => $a->post_content,
            'mime_type'   => $a->post_mime_type,
            'source_url'  => wp_get_attachment_url( $a->ID ),
            'full'        => wp_get_attachment_image_url( $a->ID, 'full' ),
            'thumbnail'   => wp_get_attachment_image_url( $a->ID, 'thumbnail' ),
            'medium'      => wp_get_attachment_image_url( $a->ID, 'medium' ),
            'width'       => $meta['width']  ?? null,
            'height'      => $meta['height'] ?? null,
            'filesize'    => $meta['filesize'] ?? null,
            'date'        => $a->post_date_gmt,
        ];
    }

    private static function require_wp_files(): void {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
    }
}
