<?php
namespace DirectRelay\REST;

defined( 'ABSPATH' ) || exit;

/**
 * Dedicated meta endpoint.
 * GET  /posts/{id}/meta  â€” return all postmeta (filtered)
 * PUT  /posts/{id}/meta  â€” upsert one or more meta keys
 * DEL  /posts/{id}/meta/{key} â€” delete a single meta key
 */
final class Meta_Controller extends Base_Controller {

    /* Keys that must never be exposed or modified via the API */
    private const PROTECTED_KEYS = [
        '_edit_lock', '_edit_last', '_wp_old_slug',
        '_wp_attachment_metadata', '_wp_attached_file',
        '_thumbnail_id',
    ];

    /* Rank Math / Yoast prefixes that belong to the SEO endpoint */
    private const SEO_PREFIXES = [ 'rank_math_', '_yoast_wpseo_', '_aioseo_' ];

    public static function register(): void {
        $types = 'posts|pages';
        register_rest_route( self::NS, "/(?P<type>{$types})/(?P<id>\\d+)/meta", [
            [
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => [ self::class, 'show' ],
                'permission_callback' => function( \WP_REST_Request $r ) {
                    $scope = ( $r->get_param( 'type' ) === 'pages' ) ? 'pages:read' : 'posts:read';
                    return self::guard( $r, $scope );
                },
            ],
            [
                'methods'             => \WP_REST_Server::EDITABLE,
                'callback'            => [ self::class, 'update' ],
                'permission_callback' => function( \WP_REST_Request $r ) {
                    $scope = ( $r->get_param( 'type' ) === 'pages' ) ? 'pages:write' : 'posts:write';
                    return self::guard( $r, $scope );
                },
            ],
        ] );
        register_rest_route( self::NS, "/(?P<type>{$types})/(?P<id>\\d+)/meta/(?P<key>[\\w-]+)", [
            [
                'methods'             => \WP_REST_Server::DELETABLE,
                'callback'            => [ self::class, 'delete_key' ],
                'permission_callback' => function( \WP_REST_Request $r ) {
                    $scope = ( $r->get_param( 'type' ) === 'pages' ) ? 'pages:write' : 'posts:write';
                    return self::guard( $r, $scope );
                },
            ],
        ] );
    }

    public static function show( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $id   = (int) $req->get_param( 'id' );
        $post = get_post( $id );
        $expected = ( $req->get_param( 'type' ) === 'pages' ) ? 'page' : 'post';
        if ( ! $post || $post->post_type !== $expected ) {
            return self::fail( $req, new \WP_Error( 'amp_not_found', 'Content not found.', [ 'status' => 404 ] ), 'get_meta' );
        }
        $raw    = get_post_meta( $id );
        $result = [];
        foreach ( $raw as $key => $values ) {
            if ( self::is_blocked( $key ) ) {
                continue;
            }
            $result[ $key ] = count( $values ) === 1 ? maybe_unserialize( $values[0] ) : array_map( 'maybe_unserialize', $values );
        }
        return self::ok( $req, [ 'meta' => $result, 'count' => count( $result ) ], 200, 'get_meta', $id, $expected );
    }

    public static function update( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $id   = (int) $req->get_param( 'id' );
        $body = $req->get_json_params() ?: [];
        $post = get_post( $id );
        $expected = ( $req->get_param( 'type' ) === 'pages' ) ? 'page' : 'post';
        if ( ! $post || $post->post_type !== $expected ) {
            return self::fail( $req, new \WP_Error( 'amp_not_found', 'Content not found.', [ 'status' => 404 ] ), 'update_meta' );
        }
        $own = \DirectRelay\Agent_Profiles::assert_owns( (array) $req->get_param( '_amp_key' ), $id );
        if ( is_wp_error( $own ) ) {
            return self::fail( $req, $own, 'update_meta' );
        }
        $updated = 0; $skipped = 0; $errors = [];
        foreach ( $body as $key => $value ) {
            $key = sanitize_key( (string) $key );
            if ( empty( $key ) || self::is_blocked( $key ) ) {
                $skipped++;
                continue;
            }
            $r = update_post_meta( $id, $key, self::sanitize_meta_value( $value ) );
            if ( false === $r ) {
                $errors[] = $key;
            } else {
                $updated++;
            }
        }
        return self::ok( $req, [
            'post_id' => $id,
            'updated' => $updated,
            'skipped' => $skipped,
            'errors'  => $errors,
        ], 200, 'update_meta', $id, $expected );
    }

    public static function delete_key( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $id  = (int) $req->get_param( 'id' );
        $key = sanitize_key( $req->get_param( 'key' ) );
        $post = get_post( $id );
        $expected = ( $req->get_param( 'type' ) === 'pages' ) ? 'page' : 'post';
        if ( ! $post || $post->post_type !== $expected ) {
            return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Content not found.', 'directrelay-automation-bridge-for-n8n'), [ 'status' => 404 ] ), 'delete_meta' );
        }
        if ( self::is_blocked( $key ) ) {
            return self::fail( $req, new \WP_Error( 'amp_forbidden', __( 'Cannot delete protected meta key.', 'directrelay-automation-bridge-for-n8n'), [ 'status' => 403 ] ), 'delete_meta' );
        }
        $own = \DirectRelay\Agent_Profiles::assert_owns( (array) $req->get_param( '_amp_key' ), $id );
        if ( is_wp_error( $own ) ) return self::fail( $req, $own, 'delete_meta' );
        $r = delete_post_meta( $id, $key );
        return self::ok( $req, [ 'deleted' => $r, 'key' => $key, 'post_id' => $id ], 200, 'delete_meta', $id, $expected );
    }

    private static function is_blocked( string $key ): bool {
        if ( in_array( $key, self::PROTECTED_KEYS, true ) ) {
            return true;
        }
        foreach ( self::SEO_PREFIXES as $prefix ) {
            if ( str_starts_with( $key, $prefix ) ) {
                return true; /* Use /seo endpoint for these */
            }
        }
        /* Plugin-internal identity stamps are never exposed or writable. */
        if ( str_starts_with( $key, '_directrelay' ) || str_starts_with( $key, 'directrelay_' ) ) {
            return true;
        }
        return false;
    }

    public static function sanitize_meta_value( mixed $value ): mixed {
        if ( is_array( $value ) ) {
            return array_map( [ self::class, 'sanitize_meta_value' ], $value );
        }
        if ( is_string( $value ) ) {
            if ( is_serialized( $value ) ) {
                return '';
            }
            if ( $value !== wp_strip_all_tags( $value ) ) {
                return wp_kses_post( $value );
            }
            return sanitize_text_field( $value );
        }
        return $value;
    }
}
