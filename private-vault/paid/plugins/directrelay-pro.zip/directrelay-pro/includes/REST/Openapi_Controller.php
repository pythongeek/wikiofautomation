<?php
namespace DirectRelay\REST;

defined( 'ABSPATH' ) || exit;

use DirectRelay\Api_Auth;

final class Openapi_Controller extends Base_Controller {

	public static function register(): void {
		// The OpenAPI spec and the REST root are intentionally public so that
		// API consumers (n8n, AI agents, OpenAPI tooling like Postman / Swagger UI)
		// can discover the schema without first needing credentials. This matches
		// the WP.org Plugin Directory recommendation that endpoints intended to
		// be publicly discoverable should use `__return_true` as the
		// permission_callback. Authentication is still enforced at the route
		// level once a consumer has the schema and wants to call a protected
		// endpoint.
		register_rest_route(
			self::NS,
			'/',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( self::class, 'get_schema' ),
					'permission_callback' => '__return_true',
				),
			)
		);
		register_rest_route(
			self::NS,
			'/openapi.json',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( self::class, 'handle' ),
					'permission_callback' => '__return_true',
				),
			)
		);
	}

	public static function get_schema( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
		return new \WP_REST_Response(
			array(
				'name'           => 'DirectRelay Automation Bridge for n8n',
				'description'    => __( 'REST API bridge for n8n. Manage WordPress Posts, Rank Math SEO, Media, and Webhooks.', 'directrelay-automation-bridge-for-n8n' ),
				'version'        => defined( 'DIRECTRELAY_VERSION' ) ? DIRECTRELAY_VERSION : DIRECTRELAY_VERSION,
				'authentication' => __( 'Bearer token (ampcm_<key>) or X-API-Key header', 'directrelay-automation-bridge-for-n8n' ),
				'endpoints'      => array(
					'posts'     => rest_url( self::NS ) . '/posts',
					'pages'     => rest_url( self::NS ) . '/pages',
					'media'     => rest_url( self::NS ) . '/media',
					'webhooks'  => rest_url( self::NS ) . '/webhooks',
					'seo'       => rest_url( self::NS ) . '/seo',
					'openapi'   => rest_url( self::NS ) . '/openapi.json',
				),
				'documentation'  => admin_url( 'admin.php?page=directrelay-docs' ),
			),
			200
		);
	}

	public static function handle( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
		$api_url = rest_url( self::NS );

		$paths = self::discover_paths();

		// Diagnostic: log the route count to the plugin's error log so
		// a stuck introspection is visible without curl in hand.
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( '[directrelay openapi] discover_paths returned ' . count( $paths ) . ' paths' ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}

		$schema = array(
			'openapi'    => '3.0.0',
			'info'       => array(
				'title'       => 'DirectRelay Automation Bridge for n8n',
				'description' => __( 'REST API bridge for n8n. Manage WordPress Posts, Rank Math SEO, Media, and Webhooks.', 'directrelay-automation-bridge-for-n8n' ),
				'version'     => defined( 'DIRECTRELAY_VERSION' ) ? DIRECTRELAY_VERSION : DIRECTRELAY_VERSION,
			),
			'servers'    => array(
				array(
					'url'         => $api_url,
					'description' => __( 'Current WordPress Site', 'directrelay-automation-bridge-for-n8n' ),
				),
			),
			'components' => array(
				'securitySchemes' => array(
					'bearerAuth' => array(
						'type'         => 'http',
						'scheme'       => 'bearer',
						'bearerFormat' => 'API Key',
					),
					'apiKeyAuth' => array(
						'type' => 'apiKey',
						'in'   => 'header',
						'name' => 'X-API-Key',
					),
				),
			),
			'security'   => array(
				array( 'bearerAuth' => array() ),
				array( 'apiKeyAuth' => array() ),
			),
			'paths'      => $paths,
		);

		return new \WP_REST_Response( $schema, 200 );
	}

	/**
	 * Introspect every REST route registered under our namespace and
	 * emit an OpenAPI 3.0 path entry per (method, route) pair.
	 *
	 * Routes registered with `permission_callback => '__return_true'`
	 * are emitted as public (security: []). Everything else is marked
	 * as requiring the bearer / X-API-Key scheme declared in
	 * `components.securitySchemes`.
	 *
	 * @return array<string,array<string,array<string,mixed>>> OpenAPI paths map.
	 */
	private static function discover_paths(): array {
		$server = rest_get_server();
		$routes = $server->get_routes();
		$ns     = self::NS;
		$paths  = [];

		// WP_REST_Server stores the methods field as an integer mask
		// (1=GET, 2=POST, 4=PUT/PATCH, 8=DELETE) OR as an array of
		// method strings, depending on when the route was registered.
		// Normalize both shapes into a list of method strings.
		$methods_to_strings = static function ( $methods ): array {
			$list = [];
			if ( is_array( $methods ) ) {
				$list = $methods;
			} elseif ( is_int( $methods ) ) {
				if ( $methods & \WP_REST_Server::READABLE ) {
					$list[] = 'GET';
				}
				if ( $methods & \WP_REST_Server::CREATABLE ) {
					$list[] = 'POST';
				}
				if ( $methods & \WP_REST_Server::EDITABLE ) {
					$list[] = 'PUT';
					$list[] = 'PATCH';
				}
				if ( $methods & \WP_REST_Server::DELETABLE ) {
					$list[] = 'DELETE';
				}
			} else {
				$list = [ (string) $methods ];
			}
			return array_values( array_unique( array_map( 'strtoupper', $list ) ) );
		};

		$method_map = [
			'GET'    => 'get',
			'POST'   => 'post',
			'PUT'    => 'put',
			'PATCH'  => 'patch',
			'DELETE' => 'delete',
		];

		foreach ( $routes as $route => $handlers ) {
			// Only include our namespace; skip WP core routes.
			if ( strpos( $route, '/' . $ns . '/' ) !== 0 && $route !== '/' . $ns ) {
				continue;
			}
			// Strip the namespace prefix so paths read as /posts, /pages, etc.
			$path = substr( $route, strlen( '/' . $ns ) );
			if ( $path === '' ) {
				$path = '/';
			}

			$openapi_methods = [];
			foreach ( $handlers as $handler ) {
				if ( empty( $handler['methods'] ) ) {
					continue;
				}
				$methods   = $methods_to_strings( $handler['methods'] );
				$perm      = $handler['permission_callback'] ?? null;
				$is_public = ( $perm === '__return_true' );

				foreach ( $methods as $m ) {
					if ( ! isset( $method_map[ $m ] ) ) {
						continue;
					}
					$op = [
						'summary'   => strtoupper( $m ) . ' ' . $path,
						'responses' => [
							'200' => [ 'description' => 'Successful response' ],
						],
					];
					if ( $is_public ) {
						$op['security'] = [];
					}
					$openapi_methods[ $method_map[ $m ] ] = $op;
				}
			}
			if ( ! empty( $openapi_methods ) ) {
				$paths[ $path ] = $openapi_methods;
			}
		}

		// Sort paths alphabetically for a stable spec (Postman / Swagger UI
		// both show them in deterministic order which helps reviewers).
		ksort( $paths );

		// Fallback: if rest_get_server()->get_routes() returned nothing
		// usable (rare, but seen on hosts where the server is initialized
		// lazily after the OpenAPI handler runs), fall back to a hardcoded
		// list derived from the controller files. Better to ship a useful
		// spec than an empty one.
		if ( empty( $paths ) ) {
			return self::fallback_paths();
		}
		return $paths;
	}

	/**
	 * Hardcoded path map used as a last-resort fallback if the runtime
	 * introspection via rest_get_server()->get_routes() returns nothing.
	 * The shape mirrors what `discover_paths()` would have produced.
	 * Pure inline construction - no closures, no variable capture.
	 *
	 * @return array<string,array<string,array<string,mixed>>> OpenAPI paths map.
	 */
	private static function fallback_paths(): array {
		$mk = static function ( string $summary, bool $public = false ): array {
			$op = [
				'summary'   => $summary,
				'responses' => [ '200' => [ 'description' => 'Successful response' ] ],
			];
			if ( $public ) {
				$op['security'] = [];
			}
			return $op;
		};
		$priv = static function ( string $summary ) use ( $mk ): array {
			return $mk( $summary, false );
		};
		$pub = static function ( string $summary ) use ( $mk ): array {
			return $mk( $summary, true );
		};

		return array(
			'/' => array(
				'get' => $pub( 'GET / - REST root with endpoint catalogue' ),
			),
			'/openapi.json' => array(
				'get' => $pub( 'GET /openapi.json - OpenAPI 3.0 spec for the whole namespace' ),
			),
			'/ping' => array(
				'get' => $pub( 'GET /ping - Public health check' ),
			),
			'/status' => array(
				'get' => $priv( 'GET /status - System status (requires system:read scope)' ),
			),
			'/cron-health' => array(
				'get' => $priv( 'GET /cron-health - Cron health snapshot' ),
			),
			'/blocked-ips' => array(
				'get' => $priv( 'GET /blocked-ips - Currently blocked IPs' ),
			),
			'/posts' => array(
				'get'  => $priv( 'GET /posts - List posts' ),
				'post' => $priv( 'POST /posts - Create a post' ),
			),
			'/posts/(?P<id>\\d+)' => array(
				'get'    => $priv( 'GET /posts/{id} - Read a single post' ),
				'put'    => $priv( 'PUT /posts/{id} - Update a post' ),
				'patch'  => $priv( 'PATCH /posts/{id} - Partial update of a post' ),
				'delete' => $priv( 'DELETE /posts/{id} - Delete a post' ),
			),
			'/posts/(?P<id>\\d+)/publish' => array(
				'post' => $priv( 'POST /posts/{id}/publish - Publish a post' ),
			),
			'/pages' => array(
				'get'  => $priv( 'GET /pages - List pages' ),
				'post' => $priv( 'POST /pages - Create a page' ),
			),
			'/pages/(?P<id>\\d+)' => array(
				'get'    => $priv( 'GET /pages/{id} - Read a single page' ),
				'put'    => $priv( 'PUT /pages/{id} - Update a page' ),
				'patch'  => $priv( 'PATCH /pages/{id} - Partial update of a page' ),
				'delete' => $priv( 'DELETE /pages/{id} - Delete a page' ),
			),
			'/(?P<type>posts|pages)/(?P<id>\\d+)/seo' => array(
				'get' => $priv( 'GET /{type}/{id}/seo - Read SEO metadata' ),
			),
			'/(?P<type>posts|pages)/(?P<id>\\d+)/meta' => array(
				'get' => $priv( 'GET /{type}/{id}/meta - List post meta keys' ),
			),
			'/(?P<type>posts|pages)/(?P<id>\\d+)/meta/(?P<key>[\\w-]+)' => array(
				'get'    => $priv( 'GET /{type}/{id}/meta/{key} - Read a single meta value' ),
				'put'    => $priv( 'PUT /{type}/{id}/meta/{key} - Update a single meta value' ),
				'delete' => $priv( 'DELETE /{type}/{id}/meta/{key} - Delete a single meta value' ),
			),
			'/media' => array(
				'get' => $priv( 'GET /media - List media attachments' ),
			),
			'/media/sideload' => array(
				'post' => $priv( 'POST /media/sideload - Sideload a media file from URL or base64' ),
			),
			'/media/(?P<id>\\d+)' => array(
				'get'    => $priv( 'GET /media/{id} - Read a single media attachment' ),
				'delete' => $priv( 'DELETE /media/{id} - Delete a media attachment' ),
			),
			'/categories' => array(
				'get' => $priv( 'GET /categories - List categories' ),
			),
			'/tags' => array(
				'get' => $priv( 'GET /tags - List tags' ),
			),
			'/keys' => array(
				'get' => $priv( 'GET /keys - List API keys (requires keys:read)' ),
			),
			'/keys/(?P<id>\\d+)/revoke' => array(
				'post' => $priv( 'POST /keys/{id}/revoke - Revoke an API key' ),
			),
			'/keys/(?P<id>\\d+)/rotate' => array(
				'post' => $priv( 'POST /keys/{id}/rotate - Rotate an API key (returns the new raw key once)' ),
			),
			'/webhooks' => array(
				'get'  => $priv( 'GET /webhooks - List webhooks' ),
				'post' => $priv( 'POST /webhooks - Create a webhook' ),
			),
			'/webhooks/presets' => array(
				'get' => $priv( 'GET /webhooks/presets - Built-in webhook event presets' ),
			),
			'/webhooks/usage' => array(
				'get' => $priv( 'GET /webhooks/usage - Recent webhook delivery stats' ),
			),
			'/webhooks/(?P<id>\\d+)' => array(
				'get'    => $priv( 'GET /webhooks/{id} - Read a webhook' ),
				'put'    => $priv( 'PUT /webhooks/{id} - Update a webhook' ),
				'delete' => $priv( 'DELETE /webhooks/{id} - Delete a webhook' ),
			),
			'/webhooks/(?P<id>\\d+)/test' => array(
				'post' => $priv( 'POST /webhooks/{id}/test - Fire a test delivery' ),
			),
			'/webhooks/(?P<id>\\d+)/deliveries' => array(
				'get' => $priv( 'GET /webhooks/{id}/deliveries - Recent delivery log' ),
			),
			'/discovery/fields' => array(
				'get' => $priv( 'GET /discovery/fields - Custom-field discovery' ),
			),
			'/discovery/post-types' => array(
				'get' => $priv( 'GET /discovery/post-types - Public post type catalogue' ),
			),
		);
	}
}
