<?php
namespace DirectRelay\REST;

defined( 'ABSPATH' ) || exit;

use DirectRelay\Post_Manager;
use DirectRelay\Rankmath_Handler;

final class Pages_Controller extends Base_Controller {

    public static function register(): void {
        register_rest_route( self::NS, '/pages', [
            [ 'methods' => \WP_REST_Server::READABLE,  'callback' => [ self::class, 'index' ],  'permission_callback' => fn( $r ) => self::guard( $r, 'pages:read' ),  'args' => self::pagination_args() ],
            [ 'methods' => \WP_REST_Server::CREATABLE, 'callback' => [ self::class, 'create' ], 'permission_callback' => fn( $r ) => self::guard( $r, 'pages:write' ) ],
        ] );
        register_rest_route( self::NS, '/pages/(?P<id>\d+)', [
            [ 'methods' => \WP_REST_Server::READABLE,  'callback' => [ self::class, 'show' ],    'permission_callback' => fn( $r ) => self::guard( $r, 'pages:read' ) ],
            [ 'methods' => \WP_REST_Server::EDITABLE,  'callback' => [ self::class, 'update' ],  'permission_callback' => fn( $r ) => self::guard( $r, 'pages:write' ) ],
            [ 'methods' => \WP_REST_Server::DELETABLE, 'callback' => [ self::class, 'destroy' ], 'permission_callback' => fn( $r ) => self::guard( $r, 'pages:delete' ), 'args' => [ 'force' => [ 'type' => 'boolean', 'default' => false ] ] ],
        ] );
    }

    public static function index( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $q = new \WP_Query( [
            'post_type'      => 'page',
            'post_status'    => [ 'publish', 'draft', 'private', 'pending' ],
            'posts_per_page' => (int) $req->get_param( 'per_page' ),
            'paged'          => (int) $req->get_param( 'page' ),
            'orderby'        => sanitize_key( $req->get_param( 'orderby' ) ?: 'date' ),
            'order'          => strtoupper( $req->get_param( 'order' ) ?: 'DESC' ) === 'ASC' ? 'ASC' : 'DESC',
            'no_found_rows'  => false,
        ] );
        return self::ok( $req, [ 'pages' => array_map( [ Post_Manager::class, 'format' ], $q->posts ), 'total' => (int) $q->found_posts, 'total_pages' => (int) $q->max_num_pages ], 200, 'list_pages' );
    }

    public static function create( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $body = $req->get_json_params() ?: [];
        $key  = $req->get_param( '_amp_key' );
        // The free plugin has no monthly dispatch / request limit.
        // The previous add-on-limit guard was removed because the WP.org
        // Plugin Directory Guidelines forbid usage limits in the free
        // build. The directrelay-pro add-on may re-introduce a
        // limit check via the `directrelay_ext_guardrails_check` filter.
        if ( ! \DirectRelay\Agent_Profiles::is_status_allowed( $key, (string) ( $body['status'] ?? 'draft' ) ) ) {
            return self::fail( $req, new \WP_Error(
                'amp_agent_forbidden',
                __( 'This agent role cannot publish content directly. Submit as a draft instead.', 'directrelay-automation-bridge-for-n8n' ),
                [ 'status' => 403 ]
            ), 'create_page' );
        }
        $id   = Post_Manager::create( $body, 'page' );
        if ( is_wp_error( $id ) ) return self::fail( $req, $id, 'create_page' );
        \DirectRelay\Agent_Profiles::stamp_post( (int) $id, $key );
        $page = Post_Manager::format( get_post( $id ) );
        if ( ! empty( $body['seo'] ) ) {
            /* Free build is read-only for SEO: the add-on owns SEO writes. */
            $seo_state         = Rankmath_Handler::handle_inline_write(
                (int) $id,
                is_array( $body['seo'] ) ? $body['seo'] : [],
                \DirectRelay\Api_Auth::has_scope( $key, 'seo:write' )
            );
            $page['seo_write'] = $seo_state['write'];
            $page['seo']       = $seo_state['seo'];
            if ( ! empty( $seo_state['error'] ) ) {
                $page['seo_write_error'] = $seo_state['error'];
            }
        } else {
            $page['seo'] = Rankmath_Handler::read( $id );
        }
        return self::ok( $req, [ 'page' => $page ], 201, 'create_page', $id, 'page' );
    }

    public static function show( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $id   = (int) $req->get_param( 'id' );
        $post = get_post( $id );
        if ( ! $post || $post->post_type !== 'page' ) return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Page not found.', 'directrelay-automation-bridge-for-n8n'), [ 'status' => 404 ] ), 'get_page' );
        $data = Post_Manager::format( $post );
        $data['seo'] = Rankmath_Handler::read( $id );
        return self::ok( $req, [ 'page' => $data ], 200, 'get_page', $id, 'page' );
    }

    public static function update( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $id   = (int) $req->get_param( 'id' );
        $body = $req->get_json_params() ?: [];
        $post = get_post( $id );
        if ( ! $post || $post->post_type !== 'page' ) return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Page not found.', 'directrelay-automation-bridge-for-n8n'), [ 'status' => 404 ] ), 'update_page' );
        $key = $req->get_param( '_amp_key' );
        if ( ! empty( $body['status'] ) && ! \DirectRelay\Agent_Profiles::is_status_allowed( $key, (string) $body['status'] ) ) {
            return self::fail( $req, new \WP_Error(
                'amp_agent_forbidden',
                __( 'This agent role cannot publish content directly. Submit as a draft instead.', 'directrelay-automation-bridge-for-n8n' ),
                [ 'status' => 403 ]
            ), 'update_page' );
        }
        $own = \DirectRelay\Agent_Profiles::assert_owns( $key, $id );
        if ( is_wp_error( $own ) ) return self::fail( $req, $own, 'update_page' );
        $r = Post_Manager::update( $id, $body );
        if ( is_wp_error( $r ) ) return self::fail( $req, $r, 'update_page' );
        $updated = Post_Manager::format( get_post( $id ) );
        if ( ! empty( $body['seo'] ) ) {
            /* Free build is read-only for SEO: the add-on owns SEO writes. */
            $seo_state            = Rankmath_Handler::handle_inline_write(
                (int) $id,
                is_array( $body['seo'] ) ? $body['seo'] : [],
                \DirectRelay\Api_Auth::has_scope( $key, 'seo:write' )
            );
            $updated['seo_write'] = $seo_state['write'];
            $updated['seo']       = $seo_state['seo'];
            if ( ! empty( $seo_state['error'] ) ) {
                $updated['seo_write_error'] = $seo_state['error'];
            }
        } else {
            $updated['seo'] = Rankmath_Handler::read( $id );
        }
        return self::ok( $req, [ 'page' => $updated ], 200, 'update_page', $id, 'page' );
    }

    public static function destroy( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $id = (int) $req->get_param( 'id' );
        $post = get_post( $id );
        if ( ! $post || $post->post_type !== 'page' ) {
            return self::fail( $req, new \WP_Error( 'amp_not_found', 'Page not found.', [ 'status' => 404 ] ), 'delete_page' );
        }
        $own = \DirectRelay\Agent_Profiles::assert_owns( (array) $req->get_param( '_amp_key' ), $id );
        if ( is_wp_error( $own ) ) return self::fail( $req, $own, 'delete_page' );
        $r = wp_delete_post( $id, (bool) $req->get_param( 'force' ) );
        return self::ok( $req, [ 'deleted' => (bool) $r, 'id' => $id ], 200, 'delete_page', $id, 'page' );
    }
}
