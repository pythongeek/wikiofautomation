<?php
namespace DirectRelay\REST;

defined( 'ABSPATH' ) || exit;

use DirectRelay\Post_Manager;
use DirectRelay\Rankmath_Handler;
use DirectRelay\Taxonomy_Manager;

final class Posts_Controller extends Base_Controller {

    public static function register(): void {
        register_rest_route( self::NS, '/posts', [
            [ 'methods' => \WP_REST_Server::READABLE,  'callback' => [ self::class, 'index' ],  'permission_callback' => fn( $r ) => self::guard( $r, 'posts:read' ),  'args' => array_merge( self::pagination_args(), [ 'status' => [ 'type' => 'string', 'default' => 'any' ], 'category' => [ 'type' => 'integer' ] ] ) ],
            [ 'methods' => \WP_REST_Server::CREATABLE, 'callback' => [ self::class, 'create' ], 'permission_callback' => fn( $r ) => self::guard( $r, 'posts:write' ) ],
        ] );
        register_rest_route( self::NS, '/posts/(?P<id>\d+)', [
            [ 'methods' => \WP_REST_Server::READABLE,  'callback' => [ self::class, 'show' ],    'permission_callback' => fn( $r ) => self::guard( $r, 'posts:read' ) ],
            [ 'methods' => \WP_REST_Server::EDITABLE,  'callback' => [ self::class, 'update' ],  'permission_callback' => fn( $r ) => self::guard( $r, 'posts:write' ) ],
            [ 'methods' => \WP_REST_Server::DELETABLE, 'callback' => [ self::class, 'destroy' ], 'permission_callback' => fn( $r ) => self::guard( $r, 'posts:delete' ), 'args' => [ 'force' => [ 'type' => 'boolean', 'default' => false ] ] ],
        ] );
        register_rest_route( self::NS, '/posts/(?P<id>\d+)/publish', [
            [ 'methods' => \WP_REST_Server::CREATABLE, 'callback' => [ self::class, 'publish' ], 'permission_callback' => fn( $r ) => self::guard( $r, 'posts:publish' ) ],
        ] );
    }

    public static function index( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $per  = (int) $req->get_param( 'per_page' );
        $page = (int) $req->get_param( 'page' );
        $q    = new \WP_Query( array_filter( [
            'post_type'      => 'post',
            'post_status'    => $req->get_param( 'status' ) ?: [ 'publish', 'draft', 'pending', 'private' ],
            'posts_per_page' => $per,
            'paged'          => $page,
            'orderby'        => sanitize_key( $req->get_param( 'orderby' ) ?: 'date' ),
            'order'          => strtoupper( $req->get_param( 'order' ) ?: 'DESC' ) === 'ASC' ? 'ASC' : 'DESC',
            's'              => $req->get_param( 'search' ) ? sanitize_text_field( $req->get_param( 'search' ) ) : null,
            'cat'            => (int) $req->get_param( 'category' ) ?: null,
            'no_found_rows'  => false,
        ], fn( $v ) => $v !== null ) );
        return self::ok( $req, [ 'posts' => array_map( [Post_Manager::class,'format'], $q->posts ), 'total' => (int)$q->found_posts, 'total_pages' => (int)$q->max_num_pages ], 200, 'list_posts' );
    }

    public static function create( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $body = $req->get_json_params() ?: [];
        $key  = $req->get_param( '_amp_key' );
        // The free plugin has no monthly dispatch / request limit.
        // The previous add-on-limit guard was removed because the WP.org
        // Plugin Directory Guidelines forbid usage limits in the free
        // build. The directrelay-pro add-on may re-introduce a
        // limit check via the `directrelay_ext_guardrails_check` filter.
        if ( ! \DirectRelay\Agent_Profiles::is_status_allowed( $key, (string) ( $body['status'] ?? 'draft' ) ) ) {
            return self::fail( $req, new \WP_Error(
                'amp_agent_forbidden',
                __( 'This agent role cannot publish content directly. Submit as a draft instead.', 'directrelay-automation-bridge-for-n8n' ),
                [ 'status' => 403 ]
            ), 'create_post' );
        }
        $id   = Post_Manager::create( $body, 'post' );
        if ( is_wp_error( $id ) ) {
            return self::fail( $req, $id, 'create_post' );
        }
        /* Identity stamps + status gate make agent-role limits enforceable. */
        \DirectRelay\Agent_Profiles::stamp_post( (int) $id, $key );
        $post = Post_Manager::format( get_post( $id ) );
        if ( ! empty( $body['seo'] ) ) {
            /* Free build is read-only for SEO: the add-on owns SEO writes. */
            $seo_state         = Rankmath_Handler::handle_inline_write(
                (int) $id,
                is_array( $body['seo'] ) ? $body['seo'] : [],
                \DirectRelay\Api_Auth::has_scope( $key, 'seo:write' )
            );
            $post['seo_write'] = $seo_state['write'];
            $post['seo']       = $seo_state['seo'];
            if ( ! empty( $seo_state['error'] ) ) {
                $post['seo_write_error'] = $seo_state['error'];
            }
        } else {
            $post['seo'] = Rankmath_Handler::read( $id );
        }
        return self::ok( $req, [ 'post' => $post ], 201, 'create_post', $id, 'post' );
    }

    public static function show( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $id   = (int) $req->get_param( 'id' );
        $post = get_post( $id );
        if ( ! $post || 'post' !== $post->post_type ) {
            return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Post not found.', 'directrelay-automation-bridge-for-n8n' ), [ 'status' => 404 ] ), 'get_post' );
        }
        $data = Post_Manager::format( $post );
        $data['seo']  = Rankmath_Handler::read( $id );
        $meta = get_post_meta( $id );
        $filtered_meta = [];
        $protected = [ '_edit_lock', '_edit_last', '_wp_old_slug', '_wp_attachment_metadata', '_wp_attached_file', '_thumbnail_id' ];
        foreach ( $meta as $key => $values ) {
            if ( in_array( $key, $protected, true ) || str_starts_with( $key, 'directrelay_' ) || str_starts_with( $key, '_directrelay' ) ) {
                continue;
            }
            $is_seo = false;
            foreach ( [ 'rank_math_', '_yoast_wpseo_', '_aioseo_' ] as $prefix ) {
                if ( str_starts_with( $key, $prefix ) ) {
                    $is_seo = true;
                    break;
                }
            }
            if ( $is_seo ) {
                continue;
            }
            $filtered_meta[ $key ] = 1 === count( $values ) ? maybe_unserialize( $values[0] ) : array_map( 'maybe_unserialize', $values );
        }
        $data['meta'] = $filtered_meta;
        return self::ok( $req, [ 'post' => $data ], 200, 'get_post', $id, 'post' );
    }

    public static function update( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $id   = (int) $req->get_param( 'id' );
        $body = $req->get_json_params() ?: [];
        $post = get_post( $id );
        if ( ! $post || 'post' !== $post->post_type ) {
            return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Post not found.', 'directrelay-automation-bridge-for-n8n' ), [ 'status' => 404 ] ), 'update_post' );
        }
        $key = $req->get_param( '_amp_key' );
        if ( ! empty( $body['status'] ) && ! \DirectRelay\Agent_Profiles::is_status_allowed( $key, (string) $body['status'] ) ) {
            return self::fail( $req, new \WP_Error(
                'amp_agent_forbidden',
                __( 'This agent role cannot publish content directly. Submit as a draft instead.', 'directrelay-automation-bridge-for-n8n' ),
                [ 'status' => 403 ]
            ), 'update_post' );
        }
        $own = \DirectRelay\Agent_Profiles::assert_owns( $key, $id );
        if ( is_wp_error( $own ) ) {
            return self::fail( $req, $own, 'update_post' );
        }
        $r = Post_Manager::update( $id, $body );
        if ( is_wp_error( $r ) ) {
            return self::fail( $req, $r, 'update_post' );
        }
        $updated = Post_Manager::format( get_post( $id ) );
        if ( ! empty( $body['seo'] ) ) {
            /* Free build is read-only for SEO: the add-on owns SEO writes. */
            $seo_state            = Rankmath_Handler::handle_inline_write(
                (int) $id,
                is_array( $body['seo'] ) ? $body['seo'] : [],
                \DirectRelay\Api_Auth::has_scope( $key, 'seo:write' )
            );
            $updated['seo_write'] = $seo_state['write'];
            $updated['seo']       = $seo_state['seo'];
            if ( ! empty( $seo_state['error'] ) ) {
                $updated['seo_write_error'] = $seo_state['error'];
            }
        } else {
            $updated['seo'] = Rankmath_Handler::read( $id );
        }
        return self::ok( $req, [ 'post' => $updated ], 200, 'update_post', $id, 'post' );
    }

    public static function destroy( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $id = (int) $req->get_param( 'id' );
        if ( ! get_post( $id ) ) {
            return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Post not found.', 'directrelay-automation-bridge-for-n8n' ), [ 'status' => 404 ] ), 'delete_post' );
        }
        $own = \DirectRelay\Agent_Profiles::assert_owns( (array) $req->get_param( '_amp_key' ), $id );
        if ( is_wp_error( $own ) ) {
            return self::fail( $req, $own, 'delete_post' );
        }
        $r = wp_delete_post( $id, (bool) $req->get_param( 'force' ) );
        return self::ok( $req, [ 'deleted' => (bool) $r, 'id' => $id ], 200, 'delete_post', $id, 'post' );
    }

    public static function publish( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $id = (int) $req->get_param( 'id' );
        $post = get_post( $id );
        if ( ! $post || 'post' !== $post->post_type ) {
            return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Post not found.', 'directrelay-automation-bridge-for-n8n' ), [ 'status' => 404 ] ), 'publish_post' );
        }
        $own = \DirectRelay\Agent_Profiles::assert_owns( (array) $req->get_param( '_amp_key' ), $id );
        if ( is_wp_error( $own ) ) {
            return self::fail( $req, $own, 'publish_post' );
        }
        $r  = wp_update_post( [ 'ID' => $id, 'post_status' => 'publish' ], true );
        if ( is_wp_error( $r ) ) {
            return self::fail( $req, $r, 'publish_post' );
        }
        return self::ok( $req, [ 'post' => Post_Manager::format( get_post( $id ) ) ], 200, 'publish_post', $id, 'post' );
    }
}
