<?php
namespace DirectRelay\REST;

defined( 'ABSPATH' ) || exit;

use DirectRelay\Rankmath_Handler;

final class SEO_Controller extends Base_Controller {

    public static function register(): void {
        $types = 'posts|pages';
        // Free: read SEO fields for any post/page.
        register_rest_route( self::NS, "/(?P<type>{$types})/(?P<id>\\d+)/seo", [
            [
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => [ self::class, 'show' ],
                'permission_callback' => fn( $r ) => self::guard( $r, 'seo:read' ),
            ],
        ] );
        // add-on: write SEO fields is provided by the directrelay-pro plugin
        // via the `directrelay_ext_register_routes` action.
    }

    public static function show( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $id       = (int) $req->get_param( 'id' );
        $post     = get_post( $id );
        $expected = ( $req->get_param( 'type' ) === 'pages' ) ? 'page' : 'post';
        if ( ! $post || $post->post_type !== $expected ) {
            return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Content not found.', 'directrelay-automation-bridge-for-n8n'), [ 'status' => 404 ] ), 'get_seo' );
        }
        return self::ok( $req, Rankmath_Handler::read( $id ), 200, 'get_seo', $id, $expected );
    }

    // SEO write routes are intentionally NOT registered here. The free
    // plugin distributed on WordPress.org is read-only for SEO. Writing
    // SEO metadata is provided by the separate DirectRelay add-on plugin
    // (distributed from https://directrelay.wikiofautomation.com), which
    // registers its own write route on the same path via the
    // `directrelay_ext_register_routes` action.
}
