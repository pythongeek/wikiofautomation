<?php
namespace DirectRelay\REST;

defined( 'ABSPATH' ) || exit;

use DirectRelay\Brute_Force;
use DirectRelay\Cron_Health;

final class System_Controller extends Base_Controller {

    public static function register(): void {
        register_rest_route( self::NS, '/status',       [ [ 'methods' => \WP_REST_Server::READABLE, 'callback' => [ self::class, 'status' ],       'permission_callback' => fn( $r ) => self::guard( $r, 'system:read' ) ] ] );
        register_rest_route( self::NS, '/ping',         [ [ 'methods' => \WP_REST_Server::READABLE, 'callback' => [ self::class, 'ping' ],         'permission_callback' => '__return_true' ] ] );
        register_rest_route( self::NS, '/cron-health',  [ [ 'methods' => \WP_REST_Server::READABLE, 'callback' => [ self::class, 'cron_health' ],  'permission_callback' => fn( $r ) => self::guard( $r, 'system:read' ) ] ] );
        register_rest_route( self::NS, '/blocked-ips',  [ [ 'methods' => \WP_REST_Server::READABLE, 'callback' => [ self::class, 'blocked_ips' ],  'permission_callback' => fn( $r ) => self::guard( $r, 'system:read' ) ] ] );
    }

    public static function status( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $key = $req->get_param( '_amp_key' );
        $settings = get_option( 'directrelay_settings', [] );
        $detailed = ! empty( $settings['detailed_status'] );

        $data = [
            'status'      => 'ok',
            'plugin'      => DIRECTRELAY_VERSION,
            'api_base'    => get_site_url() . '/wp-json/' . DIRECTRELAY_NS,
            'key_id'      => $key['id']          ?? null,
            'key_label'   => $key['label']        ?? '',
            'key_prefix'  => $key['key_prefix']   ?? '',
            'key_scopes'  => $key['scopes_array'] ?? [],
            'server_time' => current_time( 'c', true ),
        ];

        if ( $detailed ) {
            $data['wordpress']  = get_bloginfo( 'version' );
            $data['php']        = PHP_VERSION;
            $data['site_url']   = get_site_url();
            $data['seo_plugin'] = \DirectRelay\Rankmath_Handler::active_plugin();
            $data['cron']       = Cron_Health::status()['status'];
        }

        return self::ok( $req, $data, 200, 'system_status' );
    }

    public static function ping( \WP_REST_Request $req ): \WP_REST_Response {
        $resp = new \WP_REST_Response( [ 'pong' => true, 'time' => current_time( 'c', true ) ], 200 );
        $resp->header( 'X-Request-ID', wp_generate_uuid4() );
        return $resp;
    }

    public static function cron_health( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        return self::ok( $req, Cron_Health::status(), 200, 'cron_health' );
    }

    public static function blocked_ips( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        return self::ok( $req, [ 'blocks' => Brute_Force::list_blocks() ], 200, 'blocked_ips' );
    }
}
