<?php
namespace DirectRelay\REST;

defined( 'ABSPATH' ) || exit;

use DirectRelay\Api_Auth;
use DirectRelay\Activity_Logger;
use DirectRelay\Webhook_Manager;
use DirectRelay\Brute_Force;
use DirectRelay\Cron_Health;

/* â”€â”€â”€ Webhook Controller â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
final class Webhook_Controller extends Base_Controller {

    public static function register(): void {
        register_rest_route( self::NS, '/webhooks', [
            [ 'methods' => \WP_REST_Server::READABLE,  'callback' => [ self::class, 'index' ],      'permission_callback' => fn( $r ) => self::guard( $r, 'webhooks:read' ) ],
            [ 'methods' => \WP_REST_Server::CREATABLE, 'callback' => [ self::class, 'create' ],     'permission_callback' => fn( $r ) => self::guard( $r, 'webhooks:write' ) ],
        ] );
        register_rest_route( self::NS, '/webhooks/presets', [
            [ 'methods' => \WP_REST_Server::READABLE,  'callback' => [ self::class, 'presets' ],   'permission_callback' => fn( $r ) => self::guard( $r, 'webhooks:read' ) ],
        ] );
        register_rest_route( self::NS, '/webhooks/usage', [
            [ 'methods' => \WP_REST_Server::READABLE,  'callback' => [ self::class, 'usage' ],     'permission_callback' => fn( $r ) => self::guard( $r, 'webhooks:read' ) ],
        ] );
        register_rest_route( self::NS, '/webhooks/(?P<id>\d+)', [
            [ 'methods' => \WP_REST_Server::READABLE,  'callback' => [ self::class, 'show' ],       'permission_callback' => fn( $r ) => self::guard( $r, 'webhooks:read' ) ],
            [ 'methods' => \WP_REST_Server::EDITABLE,  'callback' => [ self::class, 'update' ],     'permission_callback' => fn( $r ) => self::guard( $r, 'webhooks:write' ) ],
            [ 'methods' => \WP_REST_Server::DELETABLE, 'callback' => [ self::class, 'destroy' ],    'permission_callback' => fn( $r ) => self::guard( $r, 'webhooks:write' ) ],
        ] );
        register_rest_route( self::NS, '/webhooks/(?P<id>\d+)/test', [
            [ 'methods' => \WP_REST_Server::CREATABLE, 'callback' => [ self::class, 'test' ],       'permission_callback' => fn( $r ) => self::guard( $r, 'webhooks:write' ) ],
        ] );
        register_rest_route( self::NS, '/webhooks/(?P<id>\d+)/deliveries', [
            [ 'methods' => \WP_REST_Server::READABLE,  'callback' => [ self::class, 'deliveries' ], 'permission_callback' => fn( $r ) => self::guard( $r, 'webhooks:read' ) ],
        ] );
    }

    public static function index( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- custom table.
        $rows = $wpdb->get_results( "SELECT id,key_id,label,target_url,events,post_types,active,last_fired_at,last_status,fire_count,fail_count,created_at FROM {$wpdb->prefix}directrelay_webhooks ORDER BY created_at DESC", ARRAY_A ) ?: [];
        return self::ok( $req, [
            'webhooks' => $rows,
            'total'    => count( $rows ),
            'settings' => [
                'max_webhooks'       => (int) ( get_option( 'directrelay_settings', [] )['max_webhooks'] ?? 50 ),
                'webhook_max_retries' => (int) ( get_option( 'directrelay_settings', [] )['max_retry_attempts'] ?? 3 ),
                'log_retention_days'  => (int) ( get_option( 'directrelay_settings', [] )['log_retention_days'] ?? 90 ),
            ],
        ], 200, 'list_webhooks' );
    }

    public static function presets( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        return self::ok( $req, [
            'presets' => array_values( Webhook_Manager::get_presets() ),
        ], 200, 'list_webhook_presets' );
    }

    public static function usage( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        return self::ok( $req, Webhook_Manager::get_usage(), 200, 'get_webhook_usage' );
    }

    public static function create( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        global $wpdb;
        $body = $req->get_json_params() ?: [];

        // Check active webhooks limit
        if ( false ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $active_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}directrelay_webhooks WHERE active = 1" );
            if ( $active_count >= (int) ( get_option( 'directrelay_settings', [] )['max_webhooks'] ?? 50 ) ) {
                return self::fail( $req, new \WP_Error(
                    'amp_limit_exceeded',
                    sprintf(
                        /* translators: %d: maximum number of webhooks */
                        __( 'Active webhooks are limited to %d by your plugin settings. Raise the limit in DirectRelay -> Settings.', 'directrelay-automation-bridge-for-n8n' ),
                        (int) ( get_option( 'directrelay_settings', [] )['max_webhooks'] ?? 50 )
                    ),
                    [ 'status' => 403 ]
                ), 'create_webhook' );
            }
        }

        $url = esc_url_raw( $body['target_url'] ?? '' );
        if ( ! $url || ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
            return self::fail( $req, new \WP_Error( 'amp_invalid', 'Valid target_url required.', [ 'status' => 400 ] ), 'create_webhook' );
        }
        if ( ! Api_Auth::is_url_safe( $url ) ) {
            return self::fail( $req, new \WP_Error( 'amp_invalid', 'URL must be a public HTTPS endpoint.', [ 'status' => 400 ] ), 'create_webhook' );
        }

        // Validate Events
        $events = (array) ( $body['events'] ?? [ 'post.published' ] );
        $allowed_events = \DirectRelay\Webhook_Manager::EVENTS;
        $diff_events = array_diff( $events, $allowed_events );
        if ( ! empty( $diff_events ) ) {
            return self::fail( $req, new \WP_Error(
                'invalid_event',
                sprintf(
                    /* translators: %s: event names */
                    __( 'Unknown event(s): "%s".', 'directrelay-automation-bridge-for-n8n' ),
                    implode( ', ', $diff_events )
                ),
                [ 'status' => 400 ]
            ), 'create_webhook' );
        }

        // Validate Post Types
        $types = (array) ( $body['post_types'] ?? [ 'post' ] );
        $allowed_types = array_keys( get_post_types( array( 'public' => true ), 'names' ) );
        $diff_types = array_diff( $types, $allowed_types );
        if ( ! empty( $diff_types ) ) {
            return self::fail( $req, new \WP_Error(
                'invalid_post_type',
                sprintf(
                    /* translators: %s: post type names */
                    __( 'Unknown post type(s): "%s".', 'directrelay-automation-bridge-for-n8n' ),
                    implode( ', ', $diff_types )
                ),
                [ 'status' => 400 ]
            ), 'create_webhook' );
        }

        $key = $req->get_param( '_amp_key' );
        $secret = sanitize_text_field( $body['secret'] ?? '' );
        $enc_secret = $secret ? Webhook_Manager::encrypt_secret( $secret ) : null;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- custom table insert.
        $wpdb->insert( "{$wpdb->prefix}directrelay_webhooks", [
            'key_id'      => $key['id'] ?? null,
            'label'       => sanitize_text_field( $body['label'] ?? '' ),
            'target_url'  => $url,
            'secret'      => $enc_secret,
            'events'      => wp_json_encode( $events ),
            'post_types'  => wp_json_encode( $types ),
            'active'      => 1,
            'created_at'  => current_time( 'mysql', true ),
        ] );
        $id  = (int) $wpdb->insert_id;
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT id,label,target_url,events,post_types,active,created_at FROM {$wpdb->prefix}directrelay_webhooks WHERE id=%d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return self::ok( $req, [ 'webhook' => $row ], 201, 'create_webhook', $id, 'webhook' );
    }

    public static function show( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        global $wpdb;
        $id  = (int) $req->get_param( 'id' );
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT id,key_id,label,target_url,events,post_types,active,last_fired_at,last_status,fire_count,fail_count,created_at FROM {$wpdb->prefix}directrelay_webhooks WHERE id=%d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        if ( ! $row ) return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Webhook not found.', 'directrelay-automation-bridge-for-n8n'), [ 'status' => 404 ] ), 'get_webhook' );
        return self::ok( $req, [ 'webhook' => $row ], 200, 'get_webhook', $id, 'webhook' );
    }

    public static function update( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        global $wpdb;
        $id   = (int) $req->get_param( 'id' );
        $body = $req->get_json_params() ?: [];
        if ( ! $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}directrelay_webhooks WHERE id=%d", $id ) ) ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            return self::fail( $req, new \WP_Error( 'amp_not_found', __( 'Webhook not found.', 'directrelay-automation-bridge-for-n8n'), [ 'status' => 404 ] ), 'update_webhook' );
        }
        $upd = [];
        if ( isset( $body['label'] )      ) $upd['label']      = sanitize_text_field( $body['label'] );
        if ( isset( $body['target_url'] ) ) {
            $upd_url = esc_url_raw( $body['target_url'] );
            if ( ! filter_var( $upd_url, FILTER_VALIDATE_URL ) ) {
                return self::fail( $req, new \WP_Error( 'amp_invalid', 'Valid target_url required.', [ 'status' => 400 ] ), 'update_webhook' );
            }
            if ( ! Api_Auth::is_url_safe( $upd_url ) ) {
                return self::fail( $req, new \WP_Error( 'amp_invalid', 'URL must be a public HTTPS endpoint.', [ 'status' => 400 ] ), 'update_webhook' );
            }
            $upd['target_url'] = $upd_url;
        }
        if ( isset( $body['events'] ) ) {
            $events = (array) $body['events'];
            $allowed_events = \DirectRelay\Webhook_Manager::EVENTS;
            $diff_events = array_diff( $events, $allowed_events );
            if ( ! empty( $diff_events ) ) {
                return self::fail( $req, new \WP_Error(
                    'invalid_event',
                    sprintf(
                        /* translators: %s: event names */
                        __( 'Unknown event(s): "%s".', 'directrelay-automation-bridge-for-n8n' ),
                        implode( ', ', $diff_events )
                    ),
                    [ 'status' => 400 ]
                ), 'update_webhook' );
            }
            $upd['events'] = wp_json_encode( $events );
        }
        if ( isset( $body['post_types'] ) ) {
            $types = (array) $body['post_types'];
            $allowed_types = array_keys( get_post_types( array( 'public' => true ), 'names' ) );
            $diff_types = array_diff( $types, $allowed_types );
            if ( ! empty( $diff_types ) ) {
                return self::fail( $req, new \WP_Error(
                    'invalid_post_type',
                    sprintf(
                        /* translators: %s: post type names */
                        __( 'Unknown post type(s): "%s".', 'directrelay-automation-bridge-for-n8n' ),
                        implode( ', ', $diff_types )
                    ),
                    [ 'status' => 400 ]
                ), 'update_webhook' );
            }
            $upd['post_types'] = wp_json_encode( $types );
        }
        if ( isset( $body['active'] ) ) {
            $new_active = (int) (bool) $body['active'];
            $upd['active'] = $new_active;
        }
        if ( array_key_exists( 'secret', $body ) ) $upd['secret'] = $body['secret'] ? Webhook_Manager::encrypt_secret( sanitize_text_field( $body['secret'] ) ) : null;
        if ( $upd ) $wpdb->update( "{$wpdb->prefix}directrelay_webhooks", $upd, [ 'id' => $id ] ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT id,label,target_url,events,post_types,active,created_at FROM {$wpdb->prefix}directrelay_webhooks WHERE id=%d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return self::ok( $req, [ 'webhook' => $row ], 200, 'update_webhook', $id, 'webhook' );
    }

    public static function destroy( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        global $wpdb;
        $id = (int) $req->get_param( 'id' );
        $r  = $wpdb->delete( "{$wpdb->prefix}directrelay_webhooks", [ 'id' => $id ], [ '%d' ] ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return self::ok( $req, [ 'deleted' => (bool) $r, 'id' => $id ], 200, 'delete_webhook', $id, 'webhook' );
    }

    public static function test( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        global $wpdb;
        $id  = (int) $req->get_param( 'id' );
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}directrelay_webhooks WHERE id=%d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        if ( ! $row ) return self::fail( $req, new \WP_Error( 'amp_not_found', 'Webhook not found.', [ 'status' => 404 ] ), 'test_webhook' );
        return self::ok( $req, [ 'test_result' => Webhook_Manager::fire_test( $row ) ], 200, 'test_webhook', $id, 'webhook' );
    }

    public static function deliveries( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $id   = (int) $req->get_param( 'id' );
        $rows = Webhook_Manager::delivery_log( $id, 50 );
        return self::ok( $req, [ 'deliveries' => $rows, 'total' => count( $rows ) ], 200, 'list_deliveries' );
    }

}
