<?php
namespace DirectRelay;

defined( 'ABSPATH' ) || exit;

/**
 * Read-only access to Rank Math and Yoast SEO post-meta.
 *
 * The free plugin distributed on WordPress.org only READS SEO metadata.
 * Writing SEO metadata is provided by the separate DirectRelay add-on
 * plugin (distributed from https://directrelay.wikiofautomation.com);
 * the add-on plugin ships its own writer and its own REST write route.
 * No SEO write logic lives in this file.
 */
final class Rankmath_Handler {

    private const RM = [
        'focus_keyword'          => 'rank_math_focus_keyword',
        'title'                  => 'rank_math_title',
        'description'            => 'rank_math_description',
        'robots'                 => 'rank_math_robots',
        'canonical_url'          => 'rank_math_canonical_url',
        'og_title'               => 'rank_math_og_title',
        'og_description'         => 'rank_math_og_description',
        'og_image'               => 'rank_math_og_image',
        'og_image_id'            => 'rank_math_og_image_id',
        'og_object_type'         => 'rank_math_og_object_type',
        'twitter_title'          => 'rank_math_twitter_title',
        'twitter_description'    => 'rank_math_twitter_description',
        'twitter_image'          => 'rank_math_twitter_image',
        'twitter_card_type'      => 'rank_math_twitter_card_type',
        'primary_category'       => 'rank_math_primary_category',
        'schema_type'            => 'rank_math_rich_snippet',
        'breadcrumb_title'       => 'rank_math_breadcrumb_title',
        'pillar_content'         => 'rank_math_pillar_content',
        'advanced_robots'        => 'rank_math_advanced_robots',
        'faq_schema'             => 'rank_math_faq_schema',
    ];

    private const YOAST = [
        'focus_keyword'          => '_yoast_wpseo_focuskw',
        'title'                  => '_yoast_wpseo_title',
        'description'            => '_yoast_wpseo_metadesc',
        'canonical_url'          => '_yoast_wpseo_canonical',
        'og_title'               => '_yoast_wpseo_opengraph-title',
        'og_description'         => '_yoast_wpseo_opengraph-description',
        'og_image'               => '_yoast_wpseo_opengraph-image',
        'og_image_id'            => '_yoast_wpseo_opengraph-image-id',
        'twitter_title'          => '_yoast_wpseo_twitter-title',
        'twitter_description'    => '_yoast_wpseo_twitter-description',
        'twitter_image'          => '_yoast_wpseo_twitter-image',
        'breadcrumb_title'       => '_yoast_wpseo_bctitle',
    ];

    public static function active_plugin(): string {
        $rm    = defined( 'RANK_MATH_VERSION' );
        $yoast = defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Options' ) || defined( 'WPSEO_FILE' );

        if ( $rm && $yoast ) return 'both';
        if ( $rm )           return 'rankmath';
        if ( $yoast )        return 'yoast';
        return 'both';
    }

    /**
     * Read SEO fields for a post.
     *
     * Returns the active plugin slug plus all canonical SEO field values
     * from Rank Math or Yoast (whichever is active, or Yoast fallback when
     * the Rank Math value is empty). No write side effects.
     *
     * @since 5.0.0
     *
     * @param int $post_id Target post ID.
     * @return array<string,mixed> Map of field slug => value (plus 'plugin').
     */
    public static function read( int $post_id ): array {
        $plugin = self::active_plugin();
        $data   = [ 'plugin' => $plugin ];

        foreach ( self::RM as $field => $meta_key ) {
            $val = get_post_meta( $post_id, $meta_key, true );
            if ( ( $val === '' || $val === null || $val === false ) && isset( self::YOAST[ $field ] ) ) {
                $val = get_post_meta( $post_id, self::YOAST[ $field ], true );
            }
            $data[ $field ] = $val;
        }

        if ( defined( 'RANK_MATH_VERSION' ) ) {
            $data['seo_score'] = (int) get_post_meta( $post_id, 'rank_math_seo_score', true );
        }

        return $data;
    }

    /**
     * Handle an inline `seo` payload on post/page create/update.
     *
     * The free plugin is strictly read-only for SEO (WP.org serviceware
     * guideline): it contains no SEO write code. The add-on plugin may
     * implement the write by filtering `directrelay_ext_seo_update` and
     * returning a non-null result:
     *
     *     add_filter( 'directrelay_ext_seo_update', function ( $result, $post_id, $seo ) {
     *         // write the fields here, then return the write result,
     *         // or a WP_Error on failure. Return null to pass.
     *     }, 10, 3 );
     *
     * Without the add-on the write is reported as skipped so clients never
     * assume the fields were applied (and no undefined-method fatal can
     * recur the way the pre-5.1.23 write path did).
     *
     * @param int   $post_id   Created/updated post ID.
     * @param array $seo       Inline seo payload from the request body.
     * @param bool  $can_write Whether the authenticated key holds seo:write.
     * @return array { write: string, seo: array, error?: string }
     *               write: handled_addon | skipped_addon | missing_scope | addon_error.
     */
    public static function handle_inline_write( int $post_id, array $seo, bool $can_write ): array {
        $result = null;
        if ( $can_write ) {
            $result = apply_filters( 'directrelay_ext_seo_update', null, $post_id, $seo );
        }

        $state = [
            'write' => 'skipped_addon',
            'seo'   => self::read( $post_id ),
        ];
        if ( ! $can_write ) {
            $state['write'] = 'missing_scope';
        } elseif ( is_wp_error( $result ) ) {
            $state['write'] = 'addon_error';
            $state['error'] = $result->get_error_message();
        } elseif ( null !== $result ) {
            $state['write'] = 'handled_addon';
        }
        return $state;
    }
}
