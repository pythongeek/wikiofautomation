<?php
namespace DirectRelay;

defined( 'ABSPATH' ) || exit;

final class Rate_Limiter {

    /**
     * Quota is enforced per site, not per API key, so revoking and
     * re-creating a key does not reset the counter.
     */
    private const SITE_BUCKET = 'site';

    public static function init(): void {
        if ( ! wp_next_scheduled( 'directrelay_prune_rate_limits' ) ) {
            wp_schedule_event( time(), 'hourly', 'directrelay_prune_rate_limits' );
        }
        add_action( 'directrelay_prune_rate_limits', [ __CLASS__, 'prune' ] );
    }

    /** @return array{0:int,1:int} [limit, window] for the current rate settings. */
    private static function tier_limits(): array {
        $s = get_option( 'directrelay_settings', array() );
        /* Fallbacks match the Installer defaults (120 requests / 60s window). */
        return array( (int) ( $s['rate_limit'] ?? 120 ), (int) ( $s['rate_window_sec'] ?? 60 ) );
    }

    /** @return array{allowed:bool,remaining:int,reset_at:int,limit:int} */
    public static function check( int $key_id ): array {
        global $wpdb;

        [ $limit, $window ] = self::tier_limits();
        /* $key_id is unused for bucketing: the limit bucket is per site. */
        $bucket     = self::SITE_BUCKET;
        $table      = "{$wpdb->prefix}directrelay_rate";
        $now_mysql  = current_time( 'mysql', true );
        $now_ts     = time();

        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- custom table.

        // Ensure the bucket exists.
        $wpdb->query(
            $wpdb->prepare(
                "INSERT IGNORE INTO $table (bucket, hits, window_open) VALUES (%s, 0, %s)",
                $bucket,
                $now_mysql
            )
        );

        /*
         * Read-then-write so the query stays portable across MySQL, MariaDB,
         * and SQLite (WordPress Playground). The previous
         * `TIMESTAMPDIFF(SECOND, ...)` formulation threw
         * "no such column: SECOND" on the SQLite shim.
         */
        $row = $wpdb->get_row(
            $wpdb->prepare( "SELECT hits, window_open FROM {$table} WHERE bucket = %s", $bucket ),
            ARRAY_A
        );

        if ( ! $row ) {
            $row = [ 'hits' => 0, 'window_open' => $now_mysql ];
        }
        $old_hits    = (int) $row['hits'];
        $old_wo_ts   = strtotime( (string) $row['window_open'] . ' UTC' );
        if ( false === $old_wo_ts ) {
            $old_wo_ts = strtotime( (string) $row['window_open'] );
        }
        $window_expired = ( $now_ts - (int) $old_wo_ts ) >= $window;

        if ( $window_expired ) {
            $new_hits = 1;
            $new_wo   = $now_mysql;
        } else {
            $new_hits = $old_hits + 1;
            $new_wo   = (string) $row['window_open'];
        }

        $wpdb->update(
            $table,
            [ 'hits' => $new_hits, 'window_open' => $new_wo ],
            [ 'bucket' => $bucket ],
            [ '%d', '%s' ],
            [ '%s' ]
        );

        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        $hits     = $new_hits;
        $win_open = $new_wo;
        $reset_at = (int) strtotime( $win_open . ' UTC' );
        if ( false === $reset_at ) {
            $reset_at = (int) strtotime( $win_open );
        }
        $reset_at = $reset_at + $window;

        if ( $hits > $limit ) {
            return [ 'allowed' => false, 'remaining' => 0, 'reset_at' => $reset_at, 'limit' => $limit ];
        }

        return [ 'allowed' => true, 'remaining' => $limit - $hits, 'reset_at' => $reset_at, 'limit' => $limit ];
    }

    /**
     * Read-only remaining-requests lookup for the site bucket.
     * Never writes; an expired or missing window counts as full limit.
     * $key_id is unused for bucketing: the limit bucket is per site.
     */
    public static function get_remaining( int $key_id ): int {
        global $wpdb;

        [ $limit, $window ] = self::tier_limits();

        $bucket = self::SITE_BUCKET;
        $table  = "{$wpdb->prefix}directrelay_rate";

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- custom table.
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT hits, window_open FROM {$table} WHERE bucket = %s", $bucket ), ARRAY_A );

        if ( ! $row ) {
            return $limit;
        }

        /* Expired window: the next check() resets the bucket, so full limit is available. */
        if ( ( time() - (int) strtotime( $row['window_open'] . ' UTC' ) ) >= $window ) {
            return $limit;
        }

        return max( 0, $limit - (int) $row['hits'] );
    }

    /**
     * Get the site's hits in the current 30-day free site window (for dashboard display).
     * Only meaningful for unlicensed sites, which run under the  limit.
     * An expired or missing bucket counts as zero usage.
     */
    public static function get_usage(): array {
        global $wpdb;
        $table = "{$wpdb->prefix}directrelay_rate";
        /* Compute the 30-day window threshold in PHP so the query stays portable
           across MySQL, MariaDB, and SQLite (WordPress Playground). */
        $threshold = gmdate( 'Y-m-d H:i:s', time() - 30 * 86400 );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table.
        $row = $wpdb->get_row(
            $wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is $wpdb->prefix + static name, not user input.
                "SELECT hits, window_open FROM {$table}
                 WHERE bucket = %s AND window_open >= %s",
                self::SITE_BUCKET,
                $threshold
            ),
            ARRAY_A
        );
        $total = $row ? (int) $row['hits'] : 0;
        return [
            'used'      => $total,
            'limit'     => 5000,
            'remaining' => max( 0, 5000 - $total ),
        ];
    }

    public static function prune(): void {
        global $wpdb;
        $t = "{$wpdb->prefix}directrelay_rate";
        /* Delete only fully expired buckets. Licensed windows are at most 1 day
           (settings cap rate_window_sec at 86400), so the 30-day unlicensed
           window covers both tiers. Threshold is computed in PHP for SQLite
           portability. */
        $threshold = gmdate( 'Y-m-d H:i:s', time() - 30 * 86400 );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table bulk delete.
        $wpdb->query(
            $wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $t is $wpdb->prefix + static name, not user input.
                "DELETE FROM {$t} WHERE window_open < %s", $threshold
            )
        );
    }
}
