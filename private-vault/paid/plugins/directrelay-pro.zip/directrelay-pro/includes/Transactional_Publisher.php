<?php
namespace DirectRelay;

defined( 'ABSPATH' ) || exit;

/**
 * Transactional & Atomic Publishing Engine.
 *
 * Coordinates complex, multi-stage publishing pipelines (Post + Media + Gallery +
 * Taxonomies + ACF + Rank Math / Yoast + Custom Meta + Approvals) with
 * compensating rollback on failure.
 *
 * @since 5.0.0
 */
final class Transactional_Publisher {

    /**
     * Execute atomic publishing transaction.
     *
     * @param array $payload Publishing payload.
     * @param array $key     Authenticated API key.
     * @return array|\WP_Error
     */
    public static function execute( array $payload, array $key ): array|\WP_Error {
        $strict_rollback = ! empty( $payload['rollback_on_failure'] ?? true );
        $require_approval = ! empty( $payload['require_approval'] ) || ! empty( $key['require_approval'] );

        // Track created objects for compensating rollback
        $created_attachments = [];
        $created_post_id     = null;
        $execution_steps     = [];

        try {
            // Stage 1: Validation & Agent Persona Checks
            $execution_steps['validation'] = 'running';
            
            $target_status = $payload['status'] ?? 'publish';
            if ( ! Agent_Profiles::is_status_allowed( $key, $target_status ) ) {
                $target_status = 'draft';
                $payload['status'] = 'draft';
            }

            if ( $require_approval && $target_status === 'publish' ) {
                $target_status = 'pending';
            }

            $val = class_exists( '\DirectRelay\Guardrails_Manager' )
                ? \DirectRelay\Guardrails_Manager::validate_content(
                    $payload['content'] ?? '',
                    $payload['title'] ?? '',
                    $key
                )
                : true;
            if ( is_wp_error( $val ) ) {
                return $val;
            }
            $execution_steps['validation'] = 'passed';

            // Stage 2: Sideload Media & Featured Image
            $execution_steps['media'] = 'running';
            $featured_media_id = null;
            if ( ! empty( $payload['featured_image_url'] ) ) {
                $att = self::sideload_image( $payload['featured_image_url'], $payload['title'] ?? '' );
                if ( is_wp_error( $att ) ) {
                    if ( $strict_rollback ) {
                        /* translators: %s: error message detail */
                        throw new \Exception( sprintf( __( 'Featured image upload failed: %s', 'directrelay-automation-bridge-for-n8n' ), $att->get_error_message() ) );
                    }
                } else {
                    $featured_media_id = $att;
                    $created_attachments[] = $att;
                }
            }

            // Sideload gallery images
            $gallery_ids = [];
            if ( ! empty( $payload['gallery'] ) && is_array( $payload['gallery'] ) ) {
                foreach ( $payload['gallery'] as $img_url ) {
                    if ( is_string( $img_url ) && filter_var( $img_url, FILTER_VALIDATE_URL ) ) {
                        $att = self::sideload_image( $img_url );
                        if ( ! is_wp_error( $att ) ) {
                            $gallery_ids[] = $att;
                            $created_attachments[] = $att;
                        }
                    }
                }
            }
            $execution_steps['media'] = 'completed';

            // Stage 3: Post Creation
            $execution_steps['post_create'] = 'running';
            $post_type = $payload['post_type'] ?? 'post';
            $post_args = $payload;
            $post_args['status'] = $target_status;
            if ( $featured_media_id ) {
                $post_args['featured_media'] = $featured_media_id;
            }

            // Clean AI artifacts if enabled
            if ( ! empty( $post_args['content'] ) && class_exists( '\DirectRelay\Guardrails_Manager' ) ) {
                $post_args['content'] = \DirectRelay\Guardrails_Manager::sanitize_ai_leakage( $post_args['content'] );
            }

            $created_post_id = Post_Manager::create( $post_args, $post_type );
            if ( is_wp_error( $created_post_id ) ) {
                throw new \Exception( $created_post_id->get_error_message() );
            }
            $execution_steps['post_create'] = 'completed';

            // Stamp Agent Identity
            Agent_Profiles::stamp_post( $created_post_id, $key );

            // Attach media items to the post parent
            foreach ( $created_attachments as $att_id ) {
                wp_update_post( [ 'ID' => $att_id, 'post_parent' => $created_post_id ] );
            }

            // Save Gallery Meta
            if ( ! empty( $gallery_ids ) ) {
                update_post_meta( $created_post_id, '_directrelay_gallery_ids', $gallery_ids );
            }

            // Stage 4: SEO Metadata (read-only in the free build)
            $execution_steps['seo'] = 'running';
            $seo_result = null;
            if ( ! empty( $payload['seo'] ) && is_array( $payload['seo'] ) ) {
                /*
                 * The free plugin is strictly read-only for SEO (WP.org
                 * serviceware guideline — SEO write code must not live in the
                 * WP.org build). The add-on plugin supplies its own SEO writer
                 * and applies it after this transaction returns. Report the
                 * current SEO state instead of writing.
                 */
                $execution_steps['seo'] = 'skipped_addon';
                $seo_result = Rankmath_Handler::read( $created_post_id );
            } else {
                $execution_steps['seo'] = 'completed';
            }

            // Stage 5: Approval Gateway Check (add-on features; free skips silently)
            $approval_data = null;
            if ( $require_approval && class_exists( '\DirectRelay\Approval_Gateway' ) ) {
                $execution_steps['approval'] = 'ticket_created';
                $ticket = \DirectRelay\Approval_Gateway::create_ticket( (int) ( $key['id'] ?? 0 ), $created_post_id, $payload );
                if ( ! is_wp_error( $ticket ) ) {
                    $approval_data = $ticket;
                }
            } elseif ( $require_approval ) {
                $execution_steps['approval'] = 'skipped_free_tier';
            } else {
                // If directly published, increment daily velocity counter
                if ( 'publish' === $target_status ) {
                    if ( class_exists( '\DirectRelay\Guardrails_Manager' ) ) {
                        \DirectRelay\Guardrails_Manager::increment_daily_usage( (int) ( $key['id'] ?? 0 ) );
                    }
                    /* IndexNow is opt-in (same gate as IndexNow_Pinger::init()).
                     * Posts are already pinged by the transition_post_status
                     * listener when the setting is on; this covers other post
                     * types (e.g. pages) so each URL pings exactly once. */
                    $directrelay_settings = get_option( 'directrelay_settings', [] );
                    if ( ! empty( $directrelay_settings['enable_indexnow'] ) && 'post' !== $post_type ) {
                        IndexNow_Pinger::ping( [ get_permalink( $created_post_id ) ], $created_post_id );
                    }
                }
            }

            // Return full transactional payload
            $post_obj = get_post( $created_post_id );
            return [
                'success'           => true,
                'status'            => $require_approval ? 'approval_pending' : 'published',
                'post_id'           => $created_post_id,
                'post_status'       => $target_status,
                'permalink'         => get_permalink( $created_post_id ),
                'featured_media_id' => $featured_media_id,
                'gallery_media_ids' => $gallery_ids,
                'seo'               => $seo_result,
                'approval'          => $approval_data,
                'execution_steps'   => $execution_steps,
                'post'              => Post_Manager::format( $post_obj ),
            ];

        } catch ( \Throwable $e ) {
            // COMPENSATING ROLLBACK: Clean up all created state
            $rollback_telemetry = [];
            if ( $strict_rollback ) {
                // 1. Delete created media attachments
                foreach ( $created_attachments as $att_id ) {
                    wp_delete_attachment( $att_id, true );
                    $rollback_telemetry['deleted_attachments'][] = $att_id;
                }

                // 2. Delete created post
                if ( $created_post_id ) {
                    wp_delete_post( $created_post_id, true );
                    $rollback_telemetry['deleted_post_id'] = $created_post_id;

                    /* Unschedule webhook deliveries still queued for the
                     * rolled-back post so receivers never get events for a
                     * post that no longer exists. fire() args are
                     * [event, id, type]; deliver args are
                     * [hook_id, event, id, type, attempt(, log_id)]. */
                    $unscheduled = 0;
                    $crons       = _get_cron_array() ?: [];
                    foreach ( $crons as $timestamp => $cron_events ) {
                        foreach ( [ 'directrelay_fire_webhook', 'directrelay_deliver_webhook' ] as $cron_hook ) {
                            if ( empty( $cron_events[ $cron_hook ] ) ) {
                                continue;
                            }
                            foreach ( $cron_events[ $cron_hook ] as $event_entry ) {
                                $args   = $event_entry['args'] ?? [];
                                $obj_id = ( 'directrelay_fire_webhook' === $cron_hook ) ? ( $args[1] ?? null ) : ( $args[2] ?? null );
                                if ( (int) $obj_id === (int) $created_post_id ) {
                                    wp_unschedule_event( $timestamp, $cron_hook, $args );
                                    $unscheduled++;
                                }
                            }
                        }
                    }
                    if ( $unscheduled > 0 ) {
                        $rollback_telemetry['unscheduled_webhook_events'] = $unscheduled;
                    }
                }
            }

            /* translators: %s: exception message */
            $err_msg = sprintf( __( 'Publishing transaction failed: %s', 'directrelay-automation-bridge-for-n8n' ), $e->getMessage() );
            return new \WP_Error(
                'amp_transaction_failed',
                $err_msg,
                [
                    'status'             => 422,
                    'rolled_back'        => $strict_rollback,
                    'failed_step'        => array_key_last( $execution_steps ) ?: 'unknown',
                    'rollback_telemetry' => $rollback_telemetry,
                ]
            );
        }
    }

    /**
     * Sideload an image URL into the WordPress media library.
     *
     * The fetch itself lives in Post_Manager::sideload_url(), which re-validates
     * SSRF safety on every redirect hop; this wrapper only adds the ALT text.
     */
    public static function sideload_image( string $url, string $title = '' ): int|\WP_Error {
        $att_id = Post_Manager::sideload_url( $url, 0, $title );
        if ( is_wp_error( $att_id ) ) {
            return $att_id;
        }

        if ( ! empty( $title ) ) {
            update_post_meta( (int) $att_id, '_wp_attachment_image_alt', sanitize_text_field( $title ) );
        }

        return (int) $att_id;
    }
}
