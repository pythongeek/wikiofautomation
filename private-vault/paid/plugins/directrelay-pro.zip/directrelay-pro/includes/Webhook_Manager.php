<?php
namespace DirectRelay;

defined( 'ABSPATH' ) || exit;

/**
 * Webhook Manager â€” v2
 *
 * Fixes:
 *  - HMAC secret stored as raw (not hashed) so n8n can verify signatures correctly
 *  - Delivery log written on every attempt
 *  - Exponential backoff retry via separate cron event
 *  - Retry count tracked per delivery log row
 *  - Attachment events respect post_types filter
 */
final class Webhook_Manager {

    public const EVENTS = [
        'post.created', 'post.updated', 'post.published', 'post.deleted',
        'page.created', 'page.updated', 'page.published', 'page.deleted',
        'media.uploaded', 'test',
    ];

    public const PRESETS = [
        'social_distribution' => [
            'id'          => 'social_distribution',
            'label'       => 'Multi-Platform Social Media Distribution',
            'icon'        => '🌐',
            'events'      => [ 'post.published' ],
            'post_types'  => [ 'post', 'page' ],
            'description' => 'When an article is published, n8n automatically posts the title, link, and featured image to X/Twitter, LinkedIn, Facebook Pages, Telegram, and Pinterest.',
            'badge'       => 'PRESET',
            'is_pro'      => true,
            'workflow'    => '{"name":"DirectRelay - Social Media Blast","nodes":[{"parameters":{"httpMethod":"POST","path":"directrelay-social-blast","options":{}},"name":"DirectRelay Webhook","type":"n8n-nodes-base.webhook","typeVersion":1,"position":[200,300]},{"parameters":{"values":{"string":[{"name":"title","value":"={{$json.body.post.title}}"},{"name":"url","value":"={{$json.body.post.permalink}}"},{"name":"image","value":"={{$json.body.post.featured_image}}"},{"name":"keyword","value":"={{$json.body.seo.focus_keyword}}"}]},"options":{}},"name":"Format Payload","type":"n8n-nodes-base.set","typeVersion":2,"position":[400,300]},{"parameters":{"content":"## 🌐 Multi-Platform Social Blast\\nDispatches published WordPress articles to Twitter/X, LinkedIn, Facebook, Telegram & Pinterest automatically.","height":180,"width":400},"name":"Notes","type":"n8n-nodes-base.stickyNote","typeVersion":1,"position":[200,100]}],"connections":{"DirectRelay Webhook":{"main":[[{"node":"Format Payload","type":"main","index":0}]]}}}',
        ],
        'ai_repurposing' => [
            'id'          => 'ai_repurposing',
            'label'       => 'AI Content Repurposing Pipeline',
            'icon'        => '🤖',
            'events'      => [ 'post.published' ],
            'post_types'  => [ 'post' ],
            'description' => 'Sends full article to Claude/ChatGPT in n8n to automatically generate: (a) A newsletter summary, (b) 5 tweet bullet points, (c) An ElevenLabs audio podcast episode.',
            'badge'       => 'PRESET',
            'is_pro'      => true,
            'workflow'    => '{"name":"DirectRelay - AI Content Repurposing","nodes":[{"parameters":{"httpMethod":"POST","path":"directrelay-ai-repurpose","options":{}},"name":"DirectRelay Webhook","type":"n8n-nodes-base.webhook","typeVersion":1,"position":[200,300]},{"parameters":{"model":"gpt-4o","prompt":"={{$json.body.post.content}}","systemPrompt":"Generate: 1. A 3-sentence newsletter summary. 2. A 5-tweet thread. 3. A 60-second podcast audio script."},"name":"AI Repurposer (LLM)","type":"n8n-nodes-base.openAi","typeVersion":1,"position":[420,300]}],"connections":{"DirectRelay Webhook":{"main":[[{"node":"AI Repurposer (LLM)","type":"main","index":0}]]}}}',
        ],
        'search_indexing' => [
            'id'          => 'search_indexing',
            'label'       => 'Instant Search Engine Indexing (IndexNow & Google)',
            'icon'        => '🔍',
            'events'      => [ 'post.published', 'post.updated' ],
            'post_types'  => [ 'post', 'page' ],
            'description' => 'n8n instantly submits the updated URL and Rank Math canonical link to Google Indexing API and IndexNow (Bing / Yandex).',
            'badge'       => 'PRESET',
            'is_pro'      => true,
            'workflow'    => '{"name":"DirectRelay - Instant Search Indexing","nodes":[{"parameters":{"httpMethod":"POST","path":"directrelay-search-index","options":{}},"name":"DirectRelay Webhook","type":"n8n-nodes-base.webhook","typeVersion":1,"position":[200,300]},{"parameters":{"method":"POST","url":"https://api.indexnow.org/indexnow","sendBody":true,"specifyBody":"json","jsonBody":"={\\n  \\\"host\\\": \\\"{{$json.body.site_url.replace(\'https://\', \'\').replace(\'http://\', \'\')}}\\\",\\n  \\\"key\\\": \\\"YOUR_INDEXNOW_KEY\\\",\\n  \\\"urlList\\\": [\\\"{{$json.body.post.permalink}}\\\"]\\n}"},"name":"IndexNow Ping","type":"n8n-nodes-base.httpRequest","typeVersion":4.1,"position":[440,300]}],"connections":{"DirectRelay Webhook":{"main":[[{"node":"IndexNow Ping","type":"main","index":0}]]}}}',
        ],
        'search_db_sync' => [
            'id'          => 'search_db_sync',
            'label'       => 'External Search Database Sync (Algolia / Meilisearch / Typesense)',
            'icon'        => '⚡',
            'events'      => [ 'post.created', 'post.updated', 'post.deleted' ],
            'post_types'  => [ 'post', 'page' ],
            'description' => 'Keeps external search indexes like Algolia, Meilisearch, or Typesense synchronized without running heavy server-side sync cron jobs.',
            'badge'       => 'PRESET',
            'is_pro'      => true,
            'workflow'    => '{"name":"DirectRelay - Search Index Sync","nodes":[{"parameters":{"httpMethod":"POST","path":"directrelay-search-sync","options":{}},"name":"DirectRelay Webhook","type":"n8n-nodes-base.webhook","typeVersion":1,"position":[200,300]},{"parameters":{"rules":{"values":[{"conditions":{"string":[{"value1":"={{$json.body.event}}","value2":"post.deleted"}]}}]}},"name":"Check Event Type","type":"n8n-nodes-base.switch","typeVersion":1,"position":[420,300]}],"connections":{"DirectRelay Webhook":{"main":[[{"node":"Check Event Type","type":"main","index":0}]]}}}',
        ],
        'team_alerts' => [
            'id'          => 'team_alerts',
            'label'       => 'Editorial Team Alerts (Slack / Discord)',
            'icon'        => '📢',
            'events'      => [ 'post.published', 'post.deleted' ],
            'post_types'  => [ 'post', 'page' ],
            'description' => 'Sends a message to a team Slack channel or Discord server with post details, author, and quick review links.',
            'badge'       => 'PRESET',
            'is_pro'      => true,
            'workflow'    => '{"name":"DirectRelay - Team Slack Alert","nodes":[{"parameters":{"httpMethod":"POST","path":"directrelay-slack-alert","options":{}},"name":"DirectRelay Webhook","type":"n8n-nodes-base.webhook","typeVersion":1,"position":[200,300]},{"parameters":{"channel":"#content-publishing","text":"=📰 *New Article Published!*\\n*Title:* {{$json.body.post.title}}\\n*Author:* {{$json.body.post.author}}\\n*Link:* {{$json.body.post.permalink}}"},"name":"Slack Notification","type":"n8n-nodes-base.slack","typeVersion":1,"position":[440,300]}],"connections":{"DirectRelay Webhook":{"main":[[{"node":"Slack Notification","type":"main","index":0}]]}}}',
        ],
        'cdn_cache_purge' => [
            'id'          => 'cdn_cache_purge',
            'label'       => 'Edge / CDN Cache Invalidation (Cloudflare / BunnyCDN)',
            'icon'        => '🚀',
            'events'      => [ 'post.updated', 'post.deleted' ],
            'post_types'  => [ 'post', 'page' ],
            'description' => 'Calls Cloudflare / BunnyCDN API to purge cache for that specific URL immediately.',
            'badge'       => 'PRESET',
            'is_pro'      => true,
            'workflow'    => '{"name":"DirectRelay - Cloudflare Cache Purge","nodes":[{"parameters":{"httpMethod":"POST","path":"directrelay-cache-purge","options":{}},"name":"DirectRelay Webhook","type":"n8n-nodes-base.webhook","typeVersion":1,"position":[200,300]},{"parameters":{"method":"POST","url":"https://api.cloudflare.com/client/v4/zones/YOUR_ZONE_ID/purge_cache","sendHeaders":true,"headerParameters":{"parameters":[{"name":"Authorization","value":"Bearer YOUR_CF_API_TOKEN"}]},"sendBody":true,"specifyBody":"json","jsonBody":"={\\n  \\\"files\\\": [\\\"{{$json.body.post.permalink}}\\\"]\\n}"},"name":"Purge Cloudflare Cache","type":"n8n-nodes-base.httpRequest","typeVersion":4.1,"position":[440,300]}],"connections":{"DirectRelay Webhook":{"main":[[{"node":"Purge Cloudflare Cache","type":"main","index":0}]]}}}',
        ],
        'git_s3_archival' => [
            'id'          => 'git_s3_archival',
            'label'       => 'Automated GitHub / Notion / S3 Archival',
            'icon'        => '💾',
            'events'      => [ 'post.published', 'media.uploaded' ],
            'post_types'  => [ 'post', 'attachment' ],
            'description' => 'Converts the post to Markdown and commits it to a private GitHub repository or uploads media to an AWS S3 / Cloudflare R2 bucket.',
            'badge'       => 'PRESET',
            'is_pro'      => true,
            'workflow'    => '{"name":"DirectRelay - GitHub & S3 Backup","nodes":[{"parameters":{"httpMethod":"POST","path":"directrelay-backup","options":{}},"name":"DirectRelay Webhook","type":"n8n-nodes-base.webhook","typeVersion":1,"position":[200,300]},{"parameters":{"content":"## 💾 Backup & Archival\\nConverts post JSON into Markdown and pushes to GitHub repository. For media uploads, transfers file to S3 bucket.","height":160,"width":380},"name":"Backup Info","type":"n8n-nodes-base.stickyNote","typeVersion":1,"position":[200,100]}],"connections":{}}',
        ],
    ];

    private const MAX_RETRIES = 3;

    /* Retry delays in seconds: attempt 2 → 60s, attempt 3 → 300s, attempt 4 → 900s */
    private const RETRY_DELAYS = [ 0, 60, 300, 900 ];

    public static function init(): void {
        /* Retention must run even when webhooks are disabled, otherwise
         * existing webhook_log rows are never pruned. */
        add_action( 'directrelay_prune_rate_limits', [ __CLASS__, 'prune_logs' ] );

        $s = get_option( 'directrelay_settings', [] );
        if ( empty( $s['enable_webhooks'] ) ) {
            return;
        }

        add_action( 'wp_insert_post',     [ __CLASS__, 'on_post_save' ],   99, 3 );
        add_action( 'before_delete_post', [ __CLASS__, 'on_post_delete' ], 10, 2 );
        add_action( 'add_attachment',     static fn( $id ) => self::schedule_fire( 'media.uploaded', $id, 'attachment' ) );

        /* Primary delivery worker */
        add_action( 'directrelay_fire_webhook',  [ __CLASS__, 'fire' ],  10, 3 );
        /* Individual delivery & retry worker */
        add_action( 'directrelay_deliver_webhook', [ __CLASS__, 'deliver_worker' ], 10, 6 );
    }

    /** Returns all available webhook presets. */
    public static function get_presets(): array {
        return self::PRESETS;
    }

    /**
     * Get webhook dispatch usage in current 30-day window.
     */
    public static function get_usage(): array {
        global $wpdb;
        $table = "{$wpdb->prefix}directrelay_rate";
        /* PHP-side date math for SQLite portability; window_open is UTC. */
        $cutoff = gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table.
        $row = $wpdb->get_row(
            $wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is prefix + static name, not user input.
                "SELECT hits, window_open FROM {$table}
                 WHERE bucket = %s AND window_open >= %s",
                'webhook_site',
                $cutoff
            ),
            ARRAY_A
        );
        $total = $row ? (int) $row['hits'] : 0;
        $limit = PHP_INT_MAX;
        return [
            'used'      => $total,
            'limit'     => $limit,
            'remaining' => max( 0, $limit - $total ),
            'is_pro'    => true,
        ];
    }

    /**
     * Check and record a webhook dispatch.
     *
     * The free plugin does not enforce a monthly dispatch limit —
     * the WP.org Plugin Directory Guidelines forbid usage limits in
     * the free build. The directrelay-pro add-on may hook into the
     * `directrelay_ext_guardrails_check` filter to re-introduce a
     * limit. This method is kept as a stable entry point so any
     * custom code that already calls it does not break.
     *
     * @return bool Always true.
     */
    public static function check_and_record_dispatch(): bool {
        return true;
    }

    /**
     * Prunes webhook delivery logs according to current tier retention.
     */
    public static function prune_logs(): void {
        global $wpdb;
        $days   = (int) ( get_option( 'directrelay_settings', [] )['log_retention_days'] ?? 90 );
        $table  = "{$wpdb->prefix}directrelay_webhook_log";
        /* PHP-side date math for SQLite portability; created_at is UTC. */
        $cutoff = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table maintenance.
        $wpdb->query(
            $wpdb->prepare(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is prefix + static name, not user input.
                "DELETE FROM {$table} WHERE created_at < %s",
                $cutoff
            )
        );
    }

    /* ── WP hooks ──────────────────────────────────────────────────────── */

    public static function on_post_save( int $id, \WP_Post $post, bool $update ): void {
        if ( wp_is_post_revision( $id ) || wp_is_post_autosave( $id ) ) {
            return;
        }
        if ( ! in_array( $post->post_type, [ 'post', 'page' ], true ) ) {
            return;
        }
        if ( in_array( $post->post_status, [ 'auto-draft', 'new' ], true ) ) {
            return; /* Gutenberg's empty editor shell is not a content event. */
        }
        $type = $post->post_type;
        /*
         * wp_insert_post reports $update === true even for the first real save
         * of a Gutenberg post (its auto-draft row predates it), so created vs
         * updated is tracked with a marker meta instead of the $update flag.
         */
        $seen = get_post_meta( $id, '_directrelay_event_seen', true );
        if ( ! $seen ) {
            update_post_meta( $id, '_directrelay_event_seen', 1 );
            self::schedule_fire( "{$type}.created", $id, $type );
        } else {
            self::schedule_fire( "{$type}.updated", $id, $type );
        }
        if ( $post->post_status === 'publish' ) {
            self::schedule_fire( "{$type}.published", $id, $type );
        }
    }

    public static function on_post_delete( int $id, \WP_Post $post ): void {
        if ( in_array( $post->post_type, [ 'post', 'page' ], true ) ) {
            self::schedule_fire( "{$post->post_type}.deleted", $id, $post->post_type );
        }
    }

    private static function schedule_fire( string $event, int $id, string $type ): void {
        // The free plugin fires all configured events on all configured
        // post types. A previous per-site restriction (only post.published
        // on `post`) was removed because the WP.org Plugin Directory
        // Guidelines forbid usage limits in the free build. The
        // directrelay-pro add-on may re-introduce event filters via the
        // `directrelay_ext_guardrails_check` filter.

        wp_schedule_single_event( time(), 'directrelay_fire_webhook', [ $event, $id, $type ] );
        /* Spawn a cron request immediately so WP-Cron doesn't wait for next page load */
        if ( ! defined( 'DOING_CRON' ) ) {
            wp_remote_post( site_url( 'wp-cron.php' ), [
                'timeout'   => 0.01,
                'blocking'  => false,
                'sslverify' => apply_filters( 'https_local_ssl_verify', false ), // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WP core filter.
            ] );
        }
    }

    /* ── Delivery ──────────────────────────────────────────────────────── */

    public static function fire( string $event, int $object_id, string $object_type ): void {
        // The free plugin has no monthly dispatch limit. The previous
        // add-on monthly cap was removed because the WP.org Plugin
        // Directory Guidelines forbid usage limits in the free build.
        // The directrelay-pro add-on may re-introduce a limit via the
        // `directrelay_ext_guardrails_check` filter.
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table.
        $hooks = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}directrelay_webhooks WHERE active = 1 AND events LIKE %s",
                '%' . $wpdb->esc_like( $event ) . '%'
            ),
            ARRAY_A
        ) ?: [];

        foreach ( $hooks as $hook ) {
            $events = json_decode( $hook['events'] ?? '[]', true ) ?: [];
            $types  = json_decode( $hook['post_types'] ?? '[]', true ) ?: [];
            if ( ! in_array( $event, $events, true ) ) {
                continue;
            }
            /* media.uploaded is delivered only to webhooks whose post_types
             * list includes 'attachment' — the same filter posts/pages use. */
            if ( ! in_array( $object_type, $types, true ) ) {
                continue;
            }
            wp_schedule_single_event( time(), 'directrelay_deliver_webhook', [ (int) $hook['id'], $event, $object_id, $object_type, 1 ] );
        }
    }

    public static function deliver_worker( int $hook_id, string $event, int $object_id, string $object_type, int $attempt = 1, ?int $parent_log_id = null ): void {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- custom table query.
        $hook = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}directrelay_webhooks WHERE id = %d AND active = 1", $hook_id ),
            ARRAY_A
        );
        if ( ! $hook ) {
            return;
        }
        $payload = self::build_payload( $event, $object_id, $object_type );
        self::deliver( $hook, $payload, $attempt, $parent_log_id );
    }

    /** Core delivery — sends, logs, schedules retry on failure */
    private static function deliver( array $hook, array $payload, int $attempt, ?int $parent_log_id = null ): void {
        global $wpdb;
        $t_log  = "{$wpdb->prefix}directrelay_webhook_log";
        $t_hook = "{$wpdb->prefix}directrelay_webhooks";

        $started = microtime( true );
        $result  = self::send( $hook, $payload );
        $ms      = (int) round( ( microtime( true ) - $started ) * 1000 );
        $success = $result['success'];

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- custom table insert.
        $wpdb->insert( $t_log, [
            'webhook_id'    => (int) $hook['id'],
            'event'         => $payload['event'] ?? '',
            'object_id'     => $payload['object_id'] ?? null,
            'attempt'       => $attempt,
            'http_status'   => $result['status'] ?: null,
            'duration_ms'   => $ms,
            'response_body' => isset( $result['body'] ) ? substr( $result['body'], 0, 1000 ) : null,
            'error_message' => $result['error'] ?? null,
            'created_at'    => current_time( 'mysql', true ),
        ], [ '%d', '%s', '%d', '%d', '%d', '%d', '%s', '%s', '%s' ] );

        $log_id = (int) $wpdb->insert_id;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table update.
        $wpdb->update( $t_hook, [
            'last_fired_at' => current_time( 'mysql', true ),
            'last_status'   => $result['status'],
            'fire_count'    => (int) $hook['fire_count'] + 1,
            'fail_count'    => $success ? (int) $hook['fail_count'] : (int) $hook['fail_count'] + 1,
        ], [ 'id' => (int) $hook['id'] ], [ '%s', '%d', '%d', '%d' ], [ '%d' ] );

        /* Schedule retry if failed and attempts remain according to admin's retry setting */
        $max = (int) ( get_option( 'directrelay_settings', [] )['max_retry_attempts'] ?? 3 );
        if ( ! $success && $attempt < $max ) {
            $delay = self::RETRY_DELAYS[ min( $attempt, count( self::RETRY_DELAYS ) - 1 ) ];
            wp_schedule_single_event( time() + $delay, 'directrelay_deliver_webhook', [ (int) $hook['id'], $payload['event'], (int) $payload['object_id'], $payload['object_type'], $attempt + 1, $log_id ] );
        }
    }

    /* â”€â”€ HTTP Send â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */

    private static function send( array $hook, array $payload ): array {
        $body    = wp_json_encode( $payload );
        $headers = [
            'Content-Type'     => 'application/json',
            'X-directrelay-Event'   => $payload['event'] ?? '',
            'X-directrelay-Version' => DIRECTRELAY_VERSION,
            'X-directrelay-Hook-ID' => (string) $hook['id'],
        ];

        /*
         * HMAC signature â€” uses the RAW secret (not a hash of it).
         * The secret column now stores the plaintext secret.
         * n8n verifies: HMAC-SHA256(secret, raw_body) == signature_value
         */
        $plain_secret = '';
        if ( ! empty( $hook['secret'] ) ) {
            $plain_secret = self::decrypt_secret( $hook['secret'] );
            if ( empty( $plain_secret ) ) {
                $plain_secret = $hook['secret']; // Fallback
            }
        }
        if ( ! empty( $plain_secret ) ) {
            $headers['X-directrelay-Signature'] = 'sha256=' . hash_hmac( 'sha256', $body, $plain_secret );

            /*
             * Replay protection: a fresh timestamp plus a second signature over
             * "<timestamp>.<body>". Receivers that need it verify this signature
             * and reject deliveries whose timestamp is older than ~5 minutes.
             * The body-only signature above is unchanged for existing n8n
             * verification workflows.
             */
            $ts                                           = (string) time();
            $headers['X-directrelay-Timestamp']           = $ts;
            $headers['X-directrelay-Signature-Timestamp'] = 'sha256=' . hash_hmac( 'sha256', $ts . '.' . $body, $plain_secret );
        }

        $timeout = 2; // Enforce 2-second timeout to avoid blocking cron processes

        $resp = wp_safe_remote_post( $hook['target_url'], [
            'body'        => $body,
            'headers'     => $headers,
            'timeout'     => $timeout,
            'blocking'    => true,
            'data_format' => 'body',
            'sslverify'   => true,
        ] );

        if ( is_wp_error( $resp ) ) {
            return [ 'status' => 0, 'success' => false, 'error' => $resp->get_error_message() ];
        }

        $code = (int) wp_remote_retrieve_response_code( $resp );
        return [
            'status'  => $code,
            'success' => $code >= 200 && $code < 300,
            'body'    => substr( wp_remote_retrieve_body( $resp ), 0, 500 ),
        ];
    }

    /* â”€â”€ Payload Builder â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */

    private static function build_payload( string $event, int $id, string $type ): array {
        $payload = [
            'event'       => $event,
            'object_id'   => $id,
            'object_type' => $type,
            'timestamp'   => current_time( 'c', true ),
            'site_url'    => get_site_url(),
        ];
        if ( in_array( $type, [ 'post', 'page' ], true ) ) {
            $p = get_post( $id );
            if ( $p ) {
                $post_data = Post_Manager::format( $p );
                $seo_data  = Rankmath_Handler::read( $id );
                
                $s = get_option( 'directrelay_settings', [] );
                if ( ! empty( $s['flatten_n8n_webhooks'] ) ) {
                    // Flatten structure for n8n
                    foreach( $post_data as $k => $v ) {
                        $payload[ 'post_' . $k ] = is_array( $v ) ? wp_json_encode( $v ) : $v;
                    }
                    foreach( $seo_data as $k => $v ) {
                        $payload[ 'seo_' . $k ] = is_array( $v ) ? wp_json_encode( $v ) : $v;
                    }
                } else {
                    $payload['post'] = $post_data;
                    $payload['seo']  = $seo_data;
                }
            }
        }
        return $payload;
    }

    /* â”€â”€ Test â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */

    public static function fire_test( array $hook ): array {
        $payload = [
            'event'      => 'test',
            'test'       => true,
            'webhook_id' => (int) $hook['id'],
            'timestamp'  => current_time( 'c', true ),
            'site_url'   => get_site_url(),
        ];
        $started = microtime( true );
        $result  = self::send( $hook, $payload );
        $result['duration_ms'] = (int) round( ( microtime( true ) - $started ) * 1000 );
        return $result;
    }

    /* â”€â”€ Delivery Log Queries â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */

    public static function delivery_log( int $webhook_id, int $limit = 50 ): array {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- custom table query.
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}directrelay_webhook_log WHERE webhook_id = %d ORDER BY created_at DESC LIMIT %d",
                $webhook_id,
                $limit
            ),
            ARRAY_A
        ) ?: [];
    }

    public static function recent_deliveries( int $limit = 100 ): array {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- custom table query.
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT l.*, w.label, w.target_url FROM {$wpdb->prefix}directrelay_webhook_log l
                 LEFT JOIN {$wpdb->prefix}directrelay_webhooks w ON l.webhook_id = w.id
                 ORDER BY l.created_at DESC LIMIT %d",
                $limit
            ),
            ARRAY_A
        ) ?: [];
    }

    public static function get_events(): array {
        return self::EVENTS;
    }

    /**
     * Key material for secret encryption: the site's WordPress secret keys,
     * in fallback order. SECURE_AUTH_KEY is defined in every correctly
     * configured wp-config.php; the chain (and the final built-in fallback)
     * only matters on misconfigured installs.
     */
    private static function secret_key(): string {
        if ( defined( 'SECURE_AUTH_KEY' ) && SECURE_AUTH_KEY ) {
            return SECURE_AUTH_KEY;
        }
        if ( defined( 'AUTH_KEY' ) && AUTH_KEY ) {
            return AUTH_KEY;
        }
        if ( defined( 'LOGGED_IN_KEY' ) && LOGGED_IN_KEY ) {
            return LOGGED_IN_KEY;
        }
        return 'directrelay_fallback_key';
    }

    public static function encrypt_secret( string $secret ): string {
        if ( empty( $secret ) ) {
            return '';
        }
        $key = self::secret_key();
        $iv  = openssl_random_pseudo_bytes( 16 );
        $enc = openssl_encrypt( $secret, 'aes-256-cbc', $key, 0, $iv );
        return base64_encode( $iv . $enc );
    }

    public static function decrypt_secret( string $enc_secret ): string {
        if ( empty( $enc_secret ) ) {
            return '';
        }
        $raw = base64_decode( $enc_secret ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- storage encoding, not obfuscation.
        if ( ! $raw || strlen( $raw ) <= 16 ) {
            return '';
        }
        $key = self::secret_key();
        $iv  = substr( $raw, 0, 16 );
        $enc = substr( $raw, 16 );
        return openssl_decrypt( $enc, 'aes-256-cbc', $key, 0, $iv ) ?: '';
    }
}
