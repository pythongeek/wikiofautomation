<?php
namespace DirectRelay\Admin;

use DirectRelay\Feature_Gate;

defined( 'ABSPATH' ) || exit;

final class Ajax_Handler {

    private static function verify(): void {
        check_ajax_referer( 'directrelay_admin', 'nonce' );
        if ( ! current_user_can( Menu::get_cap() ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied.' ), 403 );
        }
    }

    public static function clear_logs(): void {
        self::verify();
        global $wpdb;
        $wpdb->query( "DELETE FROM {$wpdb->prefix}directrelay_log" ); // phpcs:ignore
        $wpdb->query( "DELETE FROM {$wpdb->prefix}directrelay_analytics" ); // phpcs:ignore
        $wpdb->query( "DELETE FROM {$wpdb->prefix}directrelay_webhook_log" ); // phpcs:ignore
        wp_send_json_success();
    }

    public static function create_key(): void {
        self::verify();

        // The free plugin allows unlimited active API keys per user.
        // A previous per-site cap (1 active key on free) was removed
        // because the WP.org Plugin Directory Guidelines forbid usage
        // limits in the free build.

        $label              = sanitize_text_field( wp_unslash( $_POST['label'] ?? 'API Key' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified in self::verify().
        $description        = sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $environment        = sanitize_key( wp_unslash( $_POST['environment'] ?? 'production' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $agent_role         = sanitize_key( wp_unslash( $_POST['agent_role'] ?? 'full_access' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $daily_limit        = absint( wp_unslash( $_POST['daily_limit'] ?? 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $restrict_own_posts = ! empty( $_POST['restrict_own_posts'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $require_approval   = ! empty( $_POST['require_approval'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $scopes_raw         = isset( $_POST['scopes'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['scopes'] ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $ip_raw             = sanitize_textarea_field( wp_unslash( $_POST['ip_whitelist'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $expires            = sanitize_text_field( wp_unslash( $_POST['expires_at'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

        /* Scope preset override */
        $preset = sanitize_key( wp_unslash( $_POST['preset'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if ( $preset && isset( \DirectRelay\Api_Auth::PRESET_SCOPES[ $preset ] ) ) {
            $scopes_raw = \DirectRelay\Api_Auth::PRESET_SCOPES[ $preset ];
        }

        $ips           = array_values( array_filter( array_map( 'trim', explode( "\n", $ip_raw ) ) ) );
        $expires_mysql = null;
        if ( $expires ) {
            $ts = strtotime( $expires );
            if ( $ts ) {
                $expires_mysql = gmdate( 'Y-m-d H:i:s', $ts );
            }
        }

        $result = \DirectRelay\Api_Auth::create( array(
            'user_id'            => get_current_user_id(),
            'label'              => $label,
            'description'        => $description,
            'environment'        => $environment,
            'agent_role'         => $agent_role,
            'daily_limit'        => $daily_limit,
            'restrict_own_posts' => $restrict_own_posts,
            'require_approval'   => $require_approval,
            'scopes'             => $scopes_raw,
            'ip_whitelist'       => $ips,
            'expires_at'         => $expires_mysql,
        ) );

        if ( ! empty( $result['error'] ) ) {
            wp_send_json_error( array( 'message' => $result['message'] ?? 'Error creating key.' ), 403 );
        }

        wp_send_json_success( $result );
    }

    public static function revoke_key(): void {
        self::verify();
        $id = absint( wp_unslash( $_POST['key_id'] ?? 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if ( ! $id ) {
            wp_send_json_error( array( 'message' => 'Invalid ID.' ) );
        }
        $ok = \DirectRelay\Api_Auth::revoke( $id );
        $ok ? wp_send_json_success( array( 'revoked' => true, 'id' => $id ) ) : wp_send_json_error( array( 'message' => 'Revoke failed.' ) );
    }

    public static function save_settings(): void {
        self::verify();
        // The free plugin has no per-site settings caps (no rate-limit cap,
        // no log-retention cap, no missing add-on keys). The previous
        // if/else branch that capped rate_limit at 30/min and log_retention
        // at 7 days on the free site was removed because the WP.org Plugin
        // Directory Guidelines forbid usage limits in the free build.
        $s = array(
            'rate_limit'          => absint( wp_unslash( $_POST['rate_limit'] ?? 150 ) ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
            'rate_window_sec'     => absint( wp_unslash( $_POST['rate_window_sec'] ?? 86400 ) ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
            'log_retention_days'  => absint( wp_unslash( $_POST['log_retention_days'] ?? 90 ) ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
            'require_https'       => ! empty( $_POST['require_https'] ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
            'enable_webhooks'     => ! empty( $_POST['enable_webhooks'] ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
            'webhook_timeout_ms'  => absint( wp_unslash( $_POST['webhook_timeout_ms'] ?? 5000 ) ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
            'max_retry_attempts'  => absint( wp_unslash( $_POST['max_retry_attempts'] ?? 3 ) ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
            'enable_indexnow'     => ! empty( $_POST['enable_indexnow'] ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
            'brute_force_limit'   => absint( wp_unslash( $_POST['brute_force_limit'] ?? 10 ) ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
            'brute_force_window'  => absint( wp_unslash( $_POST['brute_force_window'] ?? 300 ) ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
            'flatten_n8n_webhooks' => ! empty( $_POST['flatten_n8n_webhooks'] ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
            'min_capability'       => sanitize_text_field( wp_unslash( $_POST['min_capability'] ?? 'manage_options' ) ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
            'max_sideload_size'    => absint( wp_unslash( $_POST['max_sideload_size'] ?? 20 ) ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
            'key_rotation_days'    => absint( wp_unslash( $_POST['key_rotation_days'] ?? 0 ) ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
            'ui_mode'              => sanitize_text_field( wp_unslash( $_POST['ui_mode'] ?? 'dark' ) ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
            'detailed_status'     => ! empty( $_POST['detailed_status'] ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
            'bypass_ips'          => sanitize_textarea_field( wp_unslash( $_POST['bypass_ips'] ?? '' ) ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
        );
        update_option( 'directrelay_settings', $s );
        update_option( 'directrelay_log_retention_days', $s['log_retention_days'] );
        wp_send_json_success();
    }

    public static function export_logs(): void {
        check_ajax_referer( 'directrelay_admin', 'nonce' );
        if ( ! current_user_can( Menu::get_cap() ) ) wp_die( 'Forbidden' );
        $format = sanitize_key( wp_unslash( $_GET['format'] ?? 'csv' ) );
        \DirectRelay\Activity_Logger::export( $format );
    }

    public static function get_chart_data(): void {
        self::verify();
        $hours  = absint( wp_unslash( $_POST['hours'] ?? 24 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $key_id = absint( wp_unslash( $_POST['key_id'] ?? 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        wp_send_json_success( array( 'hourly' => \DirectRelay\Activity_Logger::hourly_stats( $hours, $key_id ?: null ) ) );
    }

    public static function create_webhook(): void {
        self::verify();
        global $wpdb;

        // The free plugin allows unlimited active webhooks. A previous
        // per-site cap was removed because the WP.org Plugin Directory
        // Guidelines forbid usage limits in the free build. The
        // directrelay-pro add-on may re-introduce a limit via the
        // `directrelay_ext_guardrails_check` filter.

        $url    = esc_url_raw( wp_unslash( $_POST['target_url'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $label  = sanitize_text_field( wp_unslash( $_POST['label'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $events = isset( $_POST['events'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['events'] ) ) : array( 'post.published' ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $types  = isset( $_POST['post_types'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['post_types'] ) ) : array( 'post' ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $secret = sanitize_text_field( wp_unslash( $_POST['secret'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

        if ( ! $url || ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
            wp_send_json_error( array( 'message' => __( 'Valid URL required.', 'directrelay-automation-bridge-for-n8n' ) ) );
        }

        if ( ! \DirectRelay\Api_Auth::is_url_safe( $url ) ) {
            wp_send_json_error( array( 'message' => __( 'URL must be a public HTTPS endpoint.', 'directrelay-automation-bridge-for-n8n' ) ) );
        }

        // The free plugin supports every event that the user has explicitly
        // enabled and every public post type. The previous per-site cap
        // (only "post.published" on "post") was removed because the WP.org
        // Plugin Directory Guidelines forbid usage limits in the free build.
        $allowed_events = Webhook_Manager::EVENTS;
        $diff_events    = array_diff( $events, $allowed_events );
        if ( ! empty( $diff_events ) ) {
            /* translators: 1: list of unknown event names, 2: list of allowed event names */
            $template = __( 'Unknown event(s): %1$s. Allowed: %2$s.', 'directrelay-automation-bridge-for-n8n' );
            wp_send_json_error( array(
                'message' => sprintf(
                    $template,
                    implode( ', ', $diff_events ),
                    implode( ', ', $allowed_events )
                ),
            ), 400 );
        }

        $allowed_types = array_keys( get_post_types( array( 'public' => true ), 'names' ) );
        $diff_types    = array_diff( $types, $allowed_types );
        if ( ! empty( $diff_types ) ) {
            /* translators: 1: list of unknown post type names, 2: list of allowed post type names */
            $template = __( 'Unknown post type(s): %1$s. Allowed: %2$s.', 'directrelay-automation-bridge-for-n8n' );
            wp_send_json_error( array(
                'message' => sprintf(
                    $template,
                    implode( ', ', $diff_types ),
                    implode( ', ', $allowed_types )
                ),
            ), 400 );
        }

        $enc_secret = $secret ? \DirectRelay\Webhook_Manager::encrypt_secret( $secret ) : null;
        $wpdb->insert( "{$wpdb->prefix}directrelay_webhooks", array( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
            'label'       => $label,
            'target_url'  => $url,
            'secret'      => $enc_secret,
            'events'      => wp_json_encode( $events ),
            'post_types'  => wp_json_encode( $types ),
            'active'      => 1,
            'created_at'  => current_time( 'mysql', true ),
        ) );
        wp_send_json_success( array( 'id' => (int) $wpdb->insert_id ) );
    }

    public static function delete_webhook(): void {
        self::verify();
        global $wpdb;
        $id = absint( wp_unslash( $_POST['id'] ?? 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $wpdb->delete( "{$wpdb->prefix}directrelay_webhooks", array( 'id' => $id ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        wp_send_json_success( array( 'deleted' => true ) );
    }

    public static function test_webhook(): void {
        self::verify();
        global $wpdb;
        $id  = absint( wp_unslash( $_POST['id'] ?? 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}directrelay_webhooks WHERE id=%d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        if ( ! $row ) {
            wp_send_json_error( array( 'message' => __( 'Webhook not found.', 'directrelay-automation-bridge-for-n8n' ) ) );
        }
        wp_send_json_success( \DirectRelay\Webhook_Manager::fire_test( $row ) );
    }

    public static function toggle_webhook(): void {
        self::verify();
        global $wpdb;
        $id     = absint( wp_unslash( $_POST['id'] ?? 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $active = absint( wp_unslash( $_POST['active'] ?? 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

        // The free plugin allows unlimited active webhooks. A previous
        // per-site cap was removed because the WP.org Plugin Directory
        // Guidelines forbid usage limits in the free build. The
        // directrelay-pro add-on may re-introduce a limit via the
        // `directrelay_ext_guardrails_check` filter.

        $wpdb->update( "{$wpdb->prefix}directrelay_webhooks", array( 'active' => $active ), array( 'id' => $id ), array( '%d' ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        wp_send_json_success( array( 'id' => $id, 'active' => $active ) );
    }

    public static function unblock_ip(): void {
        self::verify();
        global $wpdb;
        $ip = sanitize_text_field( wp_unslash( $_POST['ip'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if ( ! $ip ) {
            wp_send_json_error( array( 'message' => 'IP required.' ) );
        }
        // Clear both the manual block and any failed_auth counter for this IP.
        $wpdb->delete( "{$wpdb->prefix}directrelay_brute_force", array( 'ip_address' => $ip ), array( '%s' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        wp_send_json_success( array( 'unblocked' => $ip ) );
    }

    public static function block_ip(): void {
        self::verify();
        $ip = sanitize_text_field( wp_unslash( $_POST['ip'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $result = \DirectRelay\Brute_Force::block_ip( $ip );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }
        wp_send_json_success( array( 'blocked' => $ip ) );
    }

    public static function rotate_key(): void {
        self::verify();
        $id = absint( wp_unslash( $_POST['key_id'] ?? 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if ( ! $id ) {
            wp_send_json_error( array( 'message' => 'Invalid ID.' ) );
        }
        $result = \DirectRelay\Api_Auth::rotate( $id );
        is_wp_error( $result )
            ? wp_send_json_error( array( 'message' => $result->get_error_message() ) )
            : wp_send_json_success( $result );
    }

    public static function export_settings(): void {
        self::verify();
        $raw_settings = get_option( 'directrelay_settings', array() );
        $allowed_keys = array(
            'rate_limit', 'rate_window_sec', 'log_retention_days', 'require_https',
            'enable_webhooks', 'webhook_timeout_ms', 'max_retry_attempts', 'enable_indexnow',
            'brute_force_limit', 'brute_force_window', 'flatten_n8n_webhooks',
            'min_capability', 'max_sideload_size', 'key_rotation_days', 'detailed_status',
            'bypass_ips',
        );
        $s = array_intersect_key( $raw_settings, array_flip( $allowed_keys ) );
        $s['exported_at'] = gmdate( 'c' );
        $s['plugin_version'] = DIRECTRELAY_VERSION;
        $json = wp_json_encode( $s, JSON_PRETTY_PRINT );
        header( 'Content-Type: application/json; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=directrelay-settings-' . gmdate( 'Y-m-d' ) . '.json' );
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_json_encode produces safe JSON output
        echo $json;
        exit;
    }

    public static function import_settings(): void {
        self::verify();
        if ( empty( $_FILES['settings_file'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            wp_send_json_error( array( 'message' => 'No file uploaded.' ), 400 );
        }
        $file = $_FILES['settings_file']; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.WP.AlternativeFunctions.file_functions_basic
        if ( $file['error'] !== UPLOAD_ERR_OK ) {
            wp_send_json_error( array( 'message' => 'Upload error.' ), 400 );
        }
        /* Enforce 1MB max upload size for settings files */
        if ( $file['size'] > 1048576 ) {
            wp_send_json_error( array( 'message' => 'File too large. Maximum 1MB allowed.' ), 400 );
        }
        $content = file_get_contents( $file['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_functions_basic, WordPress.WP.AlternativeFunctions.file_system_operations_readfile
        $data = json_decode( $content, true );
        if ( ! is_array( $data ) ) {
            wp_send_json_error( array( 'message' => 'Invalid JSON file.' ), 400 );
        }
        $allowed_keys = array(
            'rate_limit', 'rate_window_sec', 'log_retention_days', 'require_https',
            'enable_webhooks', 'webhook_timeout_ms', 'max_retry_attempts', 'enable_indexnow',
            'brute_force_limit', 'brute_force_window', 'flatten_n8n_webhooks',
            'min_capability', 'max_sideload_size', 'key_rotation_days', 'detailed_status',
            'bypass_ips',
        );
        $imported_raw = array_intersect_key( $data, array_flip( $allowed_keys ) );
        if ( empty( $imported_raw ) ) {
            wp_send_json_error( array( 'message' => 'No valid settings found in file.' ), 400 );
        }
        $imported = array();
        foreach ( $imported_raw as $key => $val ) {
            if ( in_array( $key, array( 'require_https', 'enable_webhooks', 'flatten_n8n_webhooks', 'detailed_status', 'enable_indexnow' ), true ) ) {
                $imported[ $key ] = (bool) $val;
            } elseif ( in_array( $key, array( 'min_capability', 'bypass_ips' ), true ) ) {
                $imported[ $key ] = sanitize_textarea_field( (string) $val );
            } else {
                $int_val = absint( $val );
                if ( 'max_retry_attempts' === $key ) {
                    $int_val = min( 5, $int_val );
                }
                $imported[ $key ] = $int_val;
            }
        }
        $current = get_option( 'directrelay_settings', array() );
        $merged = array_merge( $current, $imported );
        update_option( 'directrelay_settings', $merged );
        update_option( 'directrelay_log_retention_days', $merged['log_retention_days'] ?? 30 );
        wp_send_json_success( array( 'imported' => count( $imported ), 'total' => count( $merged ) ) );
    }

    public static function run_diagnostics(): void {
        self::verify();
        $results = \DirectRelay\Compatibility::run_diagnostics();
        wp_send_json_success( $results );
    }

    public static function approve_ticket(): void {
        self::verify();
        check_ajax_referer( 'directrelay_admin', 'nonce' );
        if ( ! class_exists( '\DirectRelay\Approval_Gateway' ) ) {
            wp_send_json_error(
                [ 'message' => __( 'Approval tickets are provided by the DirectRelay add-on plugin plugin. See https://directrelay.wikiofautomation.com/directrelay-pro for details.', 'directrelay-automation-bridge-for-n8n' ) ],
                402
            );
        }
        $uuid = sanitize_text_field( wp_unslash( $_POST['uuid'] ?? '' ) );
        $res = \DirectRelay\Approval_Gateway::approve( $uuid, get_current_user_id() );
        if ( is_wp_error( $res ) ) {
            wp_send_json_error( [ 'message' => $res->get_error_message() ], 400 );
        }
        wp_send_json_success( $res );
    }

    public static function reject_ticket(): void {
        self::verify();
        check_ajax_referer( 'directrelay_admin', 'nonce' );
        if ( ! class_exists( '\DirectRelay\Approval_Gateway' ) ) {
            wp_send_json_error(
                [ 'message' => __( 'Approval tickets are provided by the DirectRelay add-on plugin plugin. See https://directrelay.wikiofautomation.com/directrelay-pro for details.', 'directrelay-automation-bridge-for-n8n' ) ],
                402
            );
        }
        $uuid     = sanitize_text_field( wp_unslash( $_POST['uuid'] ?? '' ) );
        $feedback = sanitize_textarea_field( wp_unslash( $_POST['feedback'] ?? '' ) );
        $res = \DirectRelay\Approval_Gateway::reject( $uuid, $feedback, get_current_user_id() );
        if ( is_wp_error( $res ) ) {
            wp_send_json_error( [ 'message' => $res->get_error_message() ], 400 );
        }
        wp_send_json_success( $res );
    }

    public static function replay_request(): void {
        self::verify();
        check_ajax_referer( 'directrelay_admin', 'nonce' );
        if ( ! class_exists( '\DirectRelay\Execution_Debugger' ) ) {
            wp_send_json_error(
                [ 'message' => __( 'Full debugger replay is provided by the DirectRelay add-on plugin plugin. See https://directrelay.wikiofautomation.com/directrelay-pro for details.', 'directrelay-automation-bridge-for-n8n' ) ],
                402
            );
        }
        $log_id  = absint( wp_unslash( $_POST['id'] ?? 0 ) );
        $dry_run = ! empty( $_POST['dry_run'] );
        $res = \DirectRelay\Execution_Debugger::replay( $log_id, $dry_run );
        if ( is_wp_error( $res ) ) {
            wp_send_json_error( [ 'message' => $res->get_error_message() ], 400 );
        }
        wp_send_json_success( $res );
    }

    public static function save_guardrails(): void {
        self::verify();
        check_ajax_referer( 'directrelay_admin', 'nonce' );

        $guardrails = [
            'enabled'                  => true,
            'max_daily_posts'          => absint( wp_unslash( $_POST['max_daily_posts'] ?? 50 ) ),
            'min_word_count'           => absint( wp_unslash( $_POST['min_word_count'] ?? 30 ) ),
            'max_word_count'           => absint( wp_unslash( $_POST['max_word_count'] ?? 25000 ) ),
            'clean_ai_leakage'         => ! empty( $_POST['clean_ai_leakage'] ),
            'prevent_duplicate_titles' => ! empty( $_POST['prevent_duplicate_titles'] ),
            'blocked_phrases'          => sanitize_textarea_field( wp_unslash( $_POST['blocked_phrases'] ?? '' ) ),
        ];

        update_option( 'directrelay_guardrails', $guardrails );
        wp_send_json_success( [ 'message' => __( 'Guardrails saved successfully.', 'directrelay-automation-bridge-for-n8n' ) ] );
    }

    public static function get_dashboard_realtime_stats(): void {
        self::verify();

        $summary     = \DirectRelay\Activity_Logger::summary();
        $hourly      = \DirectRelay\Activity_Logger::hourly_stats( 24 );
        $top_ep      = \DirectRelay\Activity_Logger::top_endpoints( 7 );
        $keys        = \DirectRelay\Api_Auth::list_keys();
        $active_keys = array_values( array_filter( $keys, fn( $k ) => ! $k['revoked'] ) );

        $keys_data = array_map( function( $k ) {
            return array(
                'id'              => (int) $k['id'],
                'key_prefix'      => $k['key_prefix'],
                'label'           => $k['label'],
                'environment'     => $k['environment'],
                'total_requests'  => (int) ( $k['total_requests'] ?? 0 ),
                'last_used_at'    => $k['last_used_at'],
                'last_used_human' => $k['last_used_at'] ? human_time_diff( strtotime( $k['last_used_at'] ) ) . ' ' . __( 'ago', 'directrelay-automation-bridge-for-n8n' ) : __( 'Never', 'directrelay-automation-bridge-for-n8n' ),
            );
        }, array_slice( $active_keys, 0, 10 ) );

        $top_endpoints_data = array_map( function( $ep ) {
            return array(
                'endpoint' => $ep['endpoint'],
                'method'   => $ep['method'],
                'hits'     => (int) $ep['hits'],
                'avg_ms'   => $ep['avg_ms'] ? round( (float) $ep['avg_ms'], 1 ) . 'ms' : '0ms',
            );
        }, $top_ep );

        $free_usage = null;
        // The free plugin has no monthly request limit, so the
        // "free usage" indicator is always null. Kept as a stable
        // key in the AJAX response for any client code that reads it.

        wp_send_json_success( array(
            'summary'       => array(
                'requests_today'  => number_format( $summary['requests_today'] ),
                'requests_week'   => number_format( $summary['requests_week'] ),
                'errors_24h'      => number_format( $summary['errors_24h'] ),
                'avg_response_ms' => $summary['avg_response_ms'] . 'ms',
                'active_keys'     => (string) count( $active_keys ),
                'raw_today'       => (int) $summary['requests_today'],
            ),
            'keys'          => $keys_data,
            'top_endpoints' => $top_endpoints_data,
            'free_usage'    => $free_usage,
            'hourly'        => $hourly,
            'hits'          => array_map( fn( $r ) => (int) $r['hits'], $hourly ),
            'errs'          => array_map( fn( $r ) => (int) $r['errors'], $hourly ),
            'ms'            => array_map( fn( $r ) => $r['total_ms'] && $r['hits'] ? round( $r['total_ms'] / $r['hits'], 1 ) : 0, $hourly ),
            'timestamp'     => current_time( 'mysql', true ),
        ) );
    }

}
