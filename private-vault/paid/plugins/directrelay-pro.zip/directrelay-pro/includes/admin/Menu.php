<?php
namespace DirectRelay\Admin;

defined( 'ABSPATH' ) || exit;

final class Menu {

    private static bool $initialized = false;

    public static function init(): void {
        if ( self::$initialized ) return;
        self::$initialized = true;

        add_action( 'admin_menu',            [ __CLASS__, 'register_menus' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
        add_action( 'admin_body_class',      [ __CLASS__, 'body_class' ] );
        add_action( 'wp_ajax_directrelay_dismiss_apppass_notice', [ __CLASS__, 'dismiss_apppass' ] );

        $ajax_actions = [
            'create_key', 'revoke_key', 'save_settings', 'export_logs',
            'rotate_key', 'get_chart_data', 'create_webhook', 'delete_webhook',
            'test_webhook', 'toggle_webhook', 'unblock_ip', 'block_ip', 'clear_logs',
            'export_settings', 'import_settings', 'run_diagnostics',
            'approve_ticket', 'reject_ticket', 'replay_request', 'save_guardrails',
            'get_dashboard_realtime_stats',
        ];

        foreach ( $ajax_actions as $a ) {
            add_action( "wp_ajax_directrelay_{$a}", [ Ajax_Handler::class, $a ] );
        }
    }

    public static function register_menus(): void {
        $cap = self::get_cap();
        add_menu_page( 'DirectRelay Pro', 'DirectRelay Pro', $cap, 'directrelay-cm', [ __CLASS__, 'page_dashboard' ], self::svg_icon(), 80 );
        add_submenu_page( 'directrelay-cm', esc_html__( 'Dashboard', 'directrelay-automation-bridge-for-n8n' ),     esc_html__( 'Dashboard', 'directrelay-automation-bridge-for-n8n' ),     $cap, 'directrelay-cm',           [ __CLASS__, 'page_dashboard' ] );
        add_submenu_page( 'directrelay-cm', esc_html__( 'API Keys', 'directrelay-automation-bridge-for-n8n' ),      esc_html__( 'API Keys', 'directrelay-automation-bridge-for-n8n' ),      $cap, 'directrelay-keys',         [ __CLASS__, 'page_keys' ] );
        add_submenu_page( 'directrelay-cm', esc_html__( 'Webhooks', 'directrelay-automation-bridge-for-n8n' ),      esc_html__( 'Webhooks', 'directrelay-automation-bridge-for-n8n' ),      $cap, 'directrelay-webhooks',     [ __CLASS__, 'page_webhooks' ] );
        add_submenu_page( 'directrelay-cm', esc_html__( 'n8n Templates', 'directrelay-automation-bridge-for-n8n' ), esc_html__( 'n8n Templates', 'directrelay-automation-bridge-for-n8n' ), $cap, 'directrelay-templates',    [ __CLASS__, 'page_templates' ] );
        add_submenu_page( 'directrelay-cm', esc_html__( 'Compatibility', 'directrelay-automation-bridge-for-n8n' ), esc_html__( 'Compatibility', 'directrelay-automation-bridge-for-n8n' ), $cap, 'directrelay-compat',       [ __CLASS__, 'page_compat' ] );
        add_submenu_page( 'directrelay-cm', esc_html__( 'Activity Log', 'directrelay-automation-bridge-for-n8n' ),  esc_html__( 'Activity Log', 'directrelay-automation-bridge-for-n8n' ),  $cap, 'directrelay-logs',         [ __CLASS__, 'page_logs' ] );
        add_submenu_page( 'directrelay-cm', esc_html__( 'Settings', 'directrelay-automation-bridge-for-n8n' ),      esc_html__( 'Settings', 'directrelay-automation-bridge-for-n8n' ),      $cap, 'directrelay-settings',     [ __CLASS__, 'page_settings' ] );
        add_submenu_page( 'directrelay-cm', esc_html__( 'API Docs', 'directrelay-automation-bridge-for-n8n' ),      esc_html__( 'API Docs', 'directrelay-automation-bridge-for-n8n' ),      $cap, 'directrelay-docs',         [ __CLASS__, 'page_docs' ] );

        /* Slug aliases to prevent blank pages on legacy or underscored URLs */
        add_submenu_page( null, '', '', $cap, 'directrelay_cm', [ __CLASS__, 'page_dashboard' ] );

        /**
         * Fires after the free admin menu has been registered.
         *
         * The directrelay-pro plugin uses this hook to add add-on submenu
         * pages (Approvals, Debugger, AI Guardrails, add-on Analytics).
         * Free users see only the eight pages above.
         *
         * @since 5.1.0
         */
        do_action( 'directrelay_ext_register_admin' );
    }

    public static function enqueue( string $hook ): void {
        // WordPress passes $hook like 'toplevel_page_directrelay' or
        // 'directrelay-cm_page_directrelay-keys'. The actual slug never
        // appears in the hook string, so match the 'directrelay-' prefix
        // that every admin page registered by this plugin shares.
        if ( false === strpos( $hook, 'directrelay-' ) ) {
            return;
        }

        wp_enqueue_style(  'directrelay-cm',       DIRECTRELAY_URL . 'assets/css/admin.css', array(), DIRECTRELAY_VERSION . '-' . time() );
        wp_enqueue_script( 'directrelay-admin', DIRECTRELAY_URL . 'assets/js/admin.js', array( 'jquery' ), DIRECTRELAY_VERSION . '-' . time(), true );

        $data = [
            'nonce'          => wp_create_nonce( 'directrelay_admin' ),
            'restNonce'      => wp_create_nonce( 'wp_rest' ),
            'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
            'apiBase'        => get_site_url() . '/wp-json/' . DIRECTRELAY_NS,
            'scopes'         => \DirectRelay\Api_Auth::SCOPES,
            'presets'        => \DirectRelay\Api_Auth::PRESET_SCOPES,
            'events'         => \DirectRelay\Webhook_Manager::get_events(),
            'seoPlugin'      => \DirectRelay\Rankmath_Handler::active_plugin(),
            'version'        => DIRECTRELAY_VERSION,
            'isAgenticTheme' => \DirectRelay\Compatibility::is_agentic_theme(),
            'isPro'          => true,
            'l10n'           => [
                // License strings removed in 5.1.0; the directrelay-pro
                // add-on plugin provides its own activation UI.
            ],
        ];

        if ( str_contains( $hook, 'directrelay-cm' ) ) {
            $hourly = \DirectRelay\Activity_Logger::hourly_stats( 24 );
            // Free dashboard renders a plain text summary only. The
            // directrelay-pro plugin can attach richer data via the
            // `directrelay_ext_dashboard_data` filter.
            $data['chart'] = [
                'hourly' => $hourly,
                'hits'   => array_map( fn( $r ) => (int) $r['hits'], $hourly ),
                'errs'   => array_map( fn( $r ) => (int) $r['errors'], $hourly ),
                'ms'     => array_map( fn( $r ) => $r['total_ms'] && $r['hits'] ? round( $r['total_ms'] / $r['hits'], 1 ) : 0, $hourly ),
            ];
        }

        wp_localize_script( 'directrelay-admin', 'directrelayAdmin', $data );
    }

    /**
     * Filter the body class list.
     *
     * Dark mode (and any other UI variant) is provided by the
     * directrelay-pro plugin via the `directrelay_ext_body_class` filter.
     * The free plugin always renders the standard light theme.
     *
     * @since 5.1.0
     */
    public static function body_class( string $classes ): string {
        $screen = get_current_screen();
        $hook = $screen ? $screen->id : '';
        if ( ! str_contains( $hook, 'directrelay-cm' ) && ! str_contains( $hook, 'directrelay-' ) ) {
            return $classes;
        }

        /**
         * Filters the body classes added on DirectRelay admin pages.
         *
         * The directrelay-pro plugin appends `directrelay-mode-dark` here
         * when the administrator has dark mode enabled.
         *
         * @since 5.1.0
         *
         * @param string $classes Space-separated body classes.
         * @param string $hook    Current admin screen hook suffix.
         */
        $classes = (string) apply_filters( 'directrelay_ext_body_class', $classes, $hook );

        return $classes;
    }

    /* ── Page renderers ────────────────────────────────────────────────────────── */

    public static function page_dashboard(): void {
        self::cap();
        // Free dashboard view reads activity, top endpoints, and active
        // keys directly via the DirectRelay namespace. The view itself
        // applies the `directrelay_ext_dashboard_data` filter so the
                require DIRECTRELAY_DIR . 'includes/admin/views/dashboard.php';
    }

    public static function page_keys(): void {
        self::cap();
        $directrelay_keys = \DirectRelay\Api_Auth::list_keys( 0, true );
        require DIRECTRELAY_DIR . 'includes/admin/views/keys.php';
    }

    public static function page_webhooks(): void {
        self::cap();
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $directrelay_webhooks = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}directrelay_webhooks ORDER BY created_at DESC", ARRAY_A ) ?: array();
        require DIRECTRELAY_DIR . 'includes/admin/views/webhooks.php';
    }

    public static function page_logs(): void {
        self::cap();
        if ( isset( $_GET['_an_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_an_nonce'] ) ), 'directrelay_logs_filter' ) ) {
            $directrelay_offset = isset( $_GET['offset'] ) ? absint( wp_unslash( $_GET['offset'] ) ) : 0;
        } else {
            $directrelay_offset = 0;
        }
        $directrelay_logs = \DirectRelay\Activity_Logger::query( [ 'limit' => 100, 'offset' => $directrelay_offset ] );
        require DIRECTRELAY_DIR . 'includes/admin/views/logs.php';
    }

    public static function page_settings(): void {
        self::cap();
        $directrelay_settings = get_option( 'directrelay_settings', [] );
        $directrelay_compat   = \DirectRelay\Compatibility::status();
        require DIRECTRELAY_DIR . 'includes/admin/views/settings.php';
    }

    public static function page_templates(): void {
        self::cap();
        require DIRECTRELAY_DIR . 'includes/admin/views/n8n-templates.php';
    }

    public static function page_docs(): void {
        self::cap();
        $api_base = get_site_url() . '/wp-json/' . DIRECTRELAY_NS;
        require DIRECTRELAY_DIR . 'includes/admin/views/docs.php';
    }

    public static function page_compat(): void {
        self::cap();
        $directrelay_compat = \DirectRelay\Compatibility::status();
        require DIRECTRELAY_DIR . 'includes/admin/views/compat.php';
    }

    public static function dismiss_apppass(): void {
        check_ajax_referer( 'directrelay_admin', 'nonce' );
        if ( current_user_can( self::get_cap() ) ) update_option( 'directrelay_apppass_dismissed', true );
        wp_send_json_success();
    }

    private static function cap(): void {
        if ( ! current_user_can( self::get_cap() ) ) wp_die( esc_html__( 'Insufficient permissions.', 'directrelay-automation-bridge-for-n8n') );
    }

    public static function get_cap(): string {
        $s = get_option( 'directrelay_settings', [] );
        return (string) ( $s['min_capability'] ?? 'manage_options' );
    }

    /**
     * Base64-encode a brand asset for use as a data URI.
     *
     * The WordPress admin menu icon should be the small icon mark
     * (`icon-256x256.png`), not the wide wordmark. The wordmark
     * (`logo.png`) is reserved for the plugin directory banner.
     */
    private static function svg_icon(): string {
        $icon_path = DIRECTRELAY_DIR . 'assets/icon-256x256.png';
        if ( file_exists( $icon_path ) ) {
            global $wp_filesystem;
            if ( empty( $wp_filesystem ) ) {
                require_once ABSPATH . 'wp-admin/includes/file.php';
                WP_Filesystem();
            }
            $data = $wp_filesystem->get_contents( $icon_path );
            if ( $data ) {
                return 'data:image/png;base64,' . base64_encode( $data );
            }
        }
        // Fallback: animated brand mark inlined as an SVG so the menu icon
        // is still visible (and visibly alive) even if the PNG asset is
        // missing. Pure SMIL animations: a sonar pulse ring, a breathing
        // D opacity pulse, and an arrow translating left-right to convey
        // bidirectional data flow. Renders as a clean static mark in
        // environments that don't support SMIL.
        return 'data:image/svg+xml;base64,' . base64_encode(
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" role="img" aria-label="DirectRelay">' .
            '<defs>' .
            '<linearGradient id="dr-bg" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">' .
            '<stop offset="0" stop-color="#0E1A2B"/><stop offset="1" stop-color="#1A2B45"/>' .
            '</linearGradient>' .
            '<linearGradient id="dr-d" x1="18" y1="18" x2="60" y2="46" gradientUnits="userSpaceOnUse">' .
            '<stop offset="0" stop-color="#3EE0E0"/><stop offset="1" stop-color="#1AAFAF"/>' .
            '</linearGradient>' .
            '</defs>' .
            '<rect width="64" height="64" rx="12" fill="url(#dr-bg)"/>' .
            // Sonar pulse ring.
            '<rect x="20" y="20" width="24" height="24" rx="6" fill="none" stroke="#28CCCD" stroke-width="1.4">' .
            '<animate attributeName="x" values="20;6;20" keyTimes="0;0.5;1" dur="2.4s" repeatCount="indefinite"/>' .
            '<animate attributeName="y" values="20;6;20" keyTimes="0;0.5;1" dur="2.4s" repeatCount="indefinite"/>' .
            '<animate attributeName="width" values="24;52;24" keyTimes="0;0.5;1" dur="2.4s" repeatCount="indefinite"/>' .
            '<animate attributeName="height" values="24;52;24" keyTimes="0;0.5;1" dur="2.4s" repeatCount="indefinite"/>' .
            '<animate attributeName="opacity" values="0;0.65;0" keyTimes="0;0.5;1" dur="2.4s" repeatCount="indefinite"/>' .
            '<animate attributeName="stroke-width" values="1.6;0.6;1.6" keyTimes="0;0.5;1" dur="2.4s" repeatCount="indefinite"/>' .
            '</rect>' .
            // D breathing opacity pulse.
            '<path d="M48 18 C58 18 60 26 60 32 C60 38 58 46 48 46 L18 46 L18 42 L46 42 C52 42 54 38 54 32 C54 26 52 22 46 22 L18 22 L18 18 Z" fill="url(#dr-d)">' .
            '<animate attributeName="opacity" values="1;0.78;1" keyTimes="0;0.5;1" dur="2.2s" repeatCount="indefinite"/>' .
            '</path>' .
            // Arrow translates left-right.
            '<g>' .
            '<path d="M14 32 L34 32 L28 24 L34 24 L42 32 L34 40 L28 40 L34 32 L14 32 Z" fill="#FFFFFF">' .
            '<animateTransform attributeName="transform" type="translate" values="-4 0; 4 0; -4 0" keyTimes="0;0.5;1" dur="1.8s" repeatCount="indefinite"/>' .
            '<animate attributeName="opacity" values="0.55;1;0.55" keyTimes="0;0.5;1" dur="1.8s" repeatCount="indefinite"/>' .
            '</path>' .
            '</g>' .
            '</svg>'
        );
    }
}
