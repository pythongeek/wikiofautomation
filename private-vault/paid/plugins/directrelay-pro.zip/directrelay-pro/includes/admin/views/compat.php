<?php defined( 'ABSPATH' ) || exit; ?>
<div class="directrelay-wrap">
<div class="directrelay-header">
    <div class="directrelay-header-left">
        <h1 class="directrelay-page-title"><?php esc_html_e( 'Theme Compatibility', 'directrelay-automation-bridge-for-n8n'); ?></h1>
        <span class="directrelay-badge-pill <?php echo esc_attr( $directrelay_compat['is_agentic'] ? 'directrelay-pill-ok' : '' ); ?>">
            <?php echo $directrelay_compat['is_agentic'] ? esc_html__( 'Agentic add-on Detected', 'directrelay-automation-bridge-for-n8n') : esc_html__( 'Generic WP Theme', 'directrelay-automation-bridge-for-n8n'); ?>
        </span>
    </div>
</div>

<div class="directrelay-card">
    <div class="directrelay-card-header">
        <h3>🔍 <?php esc_html_e( 'System & REST Diagnostic Test Suite', 'directrelay-automation-bridge-for-n8n'); ?></h3>
        <button type="button" class="directrelay-btn directrelay-btn-primary" id="directrelay-run-diag-btn">
            ⚡ <?php esc_html_e( 'Run System Diagnostic', 'directrelay-automation-bridge-for-n8n'); ?>
        </button>
    </div>
    <div id="directrelay-diag-results" style="display:none;margin-top:16px">
        <div class="directrelay-grid-2" id="directrelay-diag-grid"></div>
    </div>
    <div id="directrelay-diag-placeholder" style="padding:20px 10px;text-align:center;color:var(--directrelay-muted)">
        <p style="margin:0"><?php esc_html_e( 'Click "Run System Diagnostic" to test REST API loopback health, Authorization headers, background cron, and database table integrity in real-time.', 'directrelay-automation-bridge-for-n8n'); ?></p>
    </div>
</div>

<div class="directrelay-card">
    <div class="directrelay-card-header"><h3><?php esc_html_e( 'Active Theme', 'directrelay-automation-bridge-for-n8n'); ?></h3></div>
    <table class="directrelay-table widefat"><tbody>
        <tr><th style="width:35%;padding:10px 14px;font-size:12px;color:var(--directrelay-muted)"><?php esc_html_e( 'Theme Name', 'directrelay-automation-bridge-for-n8n'); ?></th><td style="padding:10px 14px"><strong><?php echo esc_html( $directrelay_compat['theme_name'] ); ?></strong></td></tr>
        <tr><th style="padding:10px 14px;font-size:12px;color:var(--directrelay-muted)"><?php esc_html_e( 'Slug', 'directrelay-automation-bridge-for-n8n'); ?></th><td style="padding:10px 14px"><code><?php echo esc_html( $directrelay_compat['theme_slug'] ); ?></code></td></tr>
        <tr><th style="padding:10px 14px;font-size:12px;color:var(--directrelay-muted)"><?php esc_html_e( 'Parent', 'directrelay-automation-bridge-for-n8n'); ?></th><td style="padding:10px 14px"><code><?php echo esc_html( $directrelay_compat['parent_slug'] ); ?></code></td></tr>
        <tr>
            <th style="padding:10px 14px;font-size:12px;color:var(--directrelay-muted)"><?php esc_html_e( 'Agentic Detected', 'directrelay-automation-bridge-for-n8n'); ?></th>
            <td style="padding:10px 14px">
                <?php if ( $directrelay_compat['is_agentic'] ) : ?>
                    <span class="directrelay-badge directrelay-badge-active"><?php esc_html_e( 'Yes', 'directrelay-automation-bridge-for-n8n'); ?></span>
                <?php else : ?>
                    <span class="directrelay-badge directrelay-badge-expired"><?php esc_html_e( 'No', 'directrelay-automation-bridge-for-n8n'); ?></span>
                <?php endif; ?>
            </td>
        </tr>
    </tbody></table>
</div>

<div class="directrelay-card">
    <div class="directrelay-card-header"><h3><?php esc_html_e( 'Hook Segregation - Zero Conflicts', 'directrelay-automation-bridge-for-n8n'); ?></h3></div>
    <table class="directrelay-table widefat"><thead><tr>
        <th><?php esc_html_e( 'Hook', 'directrelay-automation-bridge-for-n8n'); ?></th>
        <th><?php esc_html_e( 'Theme Uses', 'directrelay-automation-bridge-for-n8n'); ?></th>
        <th><?php esc_html_e( 'Plugin Uses', 'directrelay-automation-bridge-for-n8n'); ?></th>
        <th><?php esc_html_e( 'Safe?', 'directrelay-automation-bridge-for-n8n'); ?></th>
    </tr></thead><tbody>
    <?php
    $directrelay_rows = array(
        array( 'wp_enqueue_scripts', __( 'Frontend CSS/JS (lines 1373-47)', 'directrelay-automation-bridge-for-n8n'), __( 'Never - admin only', 'directrelay-automation-bridge-for-n8n'), '' ),
        array( 'admin_enqueue_scripts', __( 'Never', 'directrelay-automation-bridge-for-n8n'), __( 'Our pages only (hook-gated)', 'directrelay-automation-bridge-for-n8n'), '' ),
        array( 'rest_api_init', __( 'Never', 'directrelay-automation-bridge-for-n8n'), __( 'directrelay/v1/* routes', 'directrelay-automation-bridge-for-n8n'), '' ),
        array( 'wp_head', __( 'Critical CSS, resource hints, animation fixes', 'directrelay-automation-bridge-for-n8n'), __( 'Never', 'directrelay-automation-bridge-for-n8n'), '' ),
        array( 'body_class', __( 'Frontend: page-optimized, no-tailwind', 'directrelay-automation-bridge-for-n8n'), __( 'Never (uses admin_body_class)', 'directrelay-automation-bridge-for-n8n'), '' ),
        array( 'admin_body_class', __( 'Never', 'directrelay-automation-bridge-for-n8n'), __( 'Adds directrelay-page on our pages only', 'directrelay-automation-bridge-for-n8n'), '' ),
        array( 'script_loader_tag', __( 'Defers tailwind-cdn, page-specific-js', 'directrelay-automation-bridge-for-n8n'), __( 'Never uses these handles', 'directrelay-automation-bridge-for-n8n'), '' ),
        array( 'wp_footer', __( 'Tailwind cleanup, loaded class', 'directrelay-automation-bridge-for-n8n'), __( 'Never', 'directrelay-automation-bridge-for-n8n'), '' ),
        array( 'wp_insert_post', __( 'Never', 'directrelay-automation-bridge-for-n8n'), __( 'Webhook dispatcher (background cron)', 'directrelay-automation-bridge-for-n8n'), '' ),
        array( 'wp_is_application_passwords_available', $directrelay_compat['app_pass_active'] ? __( '__return_true (security risk)', 'directrelay-automation-bridge-for-n8n') : __( 'Not used', 'directrelay-automation-bridge-for-n8n'), __( 'Not filtered', 'directrelay-automation-bridge-for-n8n'), $directrelay_compat['app_pass_active'] ? __( 'Risk', 'directrelay-automation-bridge-for-n8n' ) : '' ),
    );
    foreach ( $directrelay_rows as list( $directrelay_hook, $directrelay_theme, $directrelay_plugin, $directrelay_status ) ) :
        $directrelay_warn = str_contains( $directrelay_status, 'Risk' );
    ?>
    <tr <?php if ( $directrelay_warn ) echo 'style="background:rgba(245,158,11,0.05)"'; ?>>
        <td><code><?php echo esc_html( $directrelay_hook ); ?></code></td>
        <td><small style="color:var(--directrelay-muted)"><?php echo esc_html( $directrelay_theme ); ?></small></td>
        <td><small style="color:var(--directrelay-muted)"><?php echo esc_html( $directrelay_plugin ); ?></small></td>
        <td><span class="directrelay-badge <?php echo esc_attr( $directrelay_warn ? 'directrelay-badge-warn' : 'directrelay-badge-active' ); ?>"><?php echo esc_html( $directrelay_status ); ?></span></td>
    </tr>
    <?php endforeach; ?>
    </tbody></table>
</div>

<?php if ( $directrelay_compat['app_pass_active'] ) : ?>
<div class="directrelay-card" style="border-color:rgba(245,158,11,0.4)">
    <div class="directrelay-card-header"><h3 style="color:var(--directrelay-yellow)"><?php esc_html_e( 'Application Passwords Exposed', 'directrelay-automation-bridge-for-n8n'); ?></h3></div>
    <div class="directrelay-alert directrelay-alert-warn">
        <?php 
            printf( 
                /* translators: 1: functions.php filename, 2: filter code example */
                esc_html__( 'Your theme\'s %1$s line 337 has: %2$s. This allows WP REST API access with any valid username/password from any IP.', 'directrelay-automation-bridge-for-n8n'), 
                '<code>functions.php</code>', 
                '<br><code>add_filter(\'wp_is_application_passwords_available\',\'__return_true\');</code>' 
            ); 
        ?>
    </div>
    <div class="directrelay-grid-3" style="margin-top:16px">
        <div class="directrelay-step">
            <span class="directrelay-step-num">1</span>
            <div>
                <strong><?php esc_html_e( 'Audit existing App Passwords', 'directrelay-automation-bridge-for-n8n'); ?></strong>
                <p><?php esc_html_e( 'Users -> Profile -> Application Passwords -> revoke any unrecognised entries.', 'directrelay-automation-bridge-for-n8n'); ?></p>
            </div>
        </div>
        <div class="directrelay-step">
            <span class="directrelay-step-num">2</span>
            <div>
                <strong><?php esc_html_e( 'Migrate n8n to this plugin', 'directrelay-automation-bridge-for-n8n'); ?></strong>
                <p><?php esc_html_e( 'Replace the WordPress Application Password credential in n8n with a plugin API key (Header Auth).', 'directrelay-automation-bridge-for-n8n'); ?></p>
            </div>
        </div>
        <div class="directrelay-step">
            <span class="directrelay-step-num">3</span>
            <div>
                <strong><?php esc_html_e( 'Remove the theme filter', 'directrelay-automation-bridge-for-n8n'); ?></strong>
                <p><?php esc_html_e( 'Once migrated, comment out line 337 in functions.php. This plugin does NOT need Application Passwords.', 'directrelay-automation-bridge-for-n8n'); ?></p>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="directrelay-card">
    <div class="directrelay-card-header"><h3><?php esc_html_e( 'Handle Namespace - No Clashes', 'directrelay-automation-bridge-for-n8n'); ?></h3></div>
    <div class="directrelay-grid-2">
        <div>
            <h4 style="font-size:12px;color:var(--directrelay-muted);text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px"><?php esc_html_e( 'Theme Handles', 'directrelay-automation-bridge-for-n8n'); ?></h4>
            <?php foreach ( array( 'parent-style', 'child-style', 'agentic-fonts', 'agentic-global', 'font-awesome', 'font-awesome-local', 'agentic-mobile-fix', 'agentic-{page-slug}', 'page-specific-css', 'page-specific-js' ) as $directrelay_h ) : ?>
            <span class="directrelay-scope-tag" style="background:rgba(59,130,246,.1);color:#93c5fd;border-color:rgba(59,130,246,.2)"><?php echo esc_html( $directrelay_h ); ?></span>
            <?php endforeach; ?>
        </div>
        <div>
            <h4 style="font-size:12px;color:var(--directrelay-muted);text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px"><?php esc_html_e( 'Plugin Handles (admin only)', 'directrelay-automation-bridge-for-n8n'); ?></h4>
            <?php foreach ( array( 'directrelay-cm', 'directrelay-admin' ) as $directrelay_h ) : ?>
            <span class="directrelay-scope-tag"><?php echo esc_html( $directrelay_h ); ?></span>
            <?php endforeach; ?>
            <p style="margin-top:10px;font-size:12px;color:var(--directrelay-muted)"><?php esc_html_e( 'All admin-only, all prefixed directrelay-cm. Zero frontend bleed.', 'directrelay-automation-bridge-for-n8n'); ?></p>
        </div>
    </div>
</div>
</div>

