<?php
defined( 'ABSPATH' ) || exit;

/**
 * Free dashboard view.
 *
 * Renders a plain text status summary suitable for a system operator.
 * The Chart.js analytics view, request volume graphs, and per-key
 * breakdown are provided by the directrelay-pro plugin via the
 * `directrelay_ext_dashboard_data` filter and the
 * `directrelay_ext_render_pro_dashboard_panel` action.
 *
 * @package DirectRelay
 * @since   5.1.0
 */

$directrelay_summary     = \DirectRelay\Activity_Logger::summary();
$directrelay_hourly      = \DirectRelay\Activity_Logger::hourly_stats( 24 );
$directrelay_top_ep      = \DirectRelay\Activity_Logger::top_endpoints( 7 );
$directrelay_keys        = \DirectRelay\Api_Auth::list_keys();
$directrelay_active_keys = count( array_filter( $directrelay_keys, fn( $k ) => ! $k['revoked'] ) );
$directrelay_compat      = \DirectRelay\Compatibility::status();
$directrelay_sp          = \DirectRelay\Rankmath_Handler::active_plugin();

// Pre-compute a one-line "calls today" summary for the header band.
$directrelay_calls_today = isset( $directrelay_summary['requests_today'] )
    ? (int) $directrelay_summary['requests_today']
    : 0;
$directrelay_errors_24h = isset( $directrelay_summary['errors_24h'] )
    ? (int) $directrelay_summary['errors_24h']
    : 0;

// Find the most recent successful request timestamp.
$directrelay_last_used = '';
foreach ( $directrelay_keys as $directrelay_k ) {
    if ( ! empty( $directrelay_k['last_used_at'] ) ) {
        $directrelay_last_used = $directrelay_k['last_used_at'];
        break;
    }
}
$directrelay_last_used_label = $directrelay_last_used
    ? human_time_diff( strtotime( $directrelay_last_used ) ) . ' ' . __( 'ago', 'directrelay-automation-bridge-for-n8n' )
    : __( 'never', 'directrelay-automation-bridge-for-n8n' );

// Allow the add-on plugin to enrich the dashboard data array.
$directrelay_dashboard_data = (array) apply_filters(
    'directrelay_ext_dashboard_data',
    [
        'summary'     => $directrelay_summary,
        'hourly'      => $directrelay_hourly,
        'top'         => $directrelay_top_ep,
        'active_keys' => $directrelay_active_keys,
    ]
);
?>
<div class="directrelay-wrap">
<div class="directrelay-header">
    <div class="directrelay-header-left">
        <h1 class="directrelay-page-title">
            <span class="dashicons dashicons-rest-api" style="font-size:32px;line-height:1;vertical-align:middle;margin-right:10px;color:#2271b1;"></span>
            <?php esc_html_e( 'DirectRelay Pro', 'directrelay-automation-bridge-for-n8n' ); ?>
        </h1>
        <span class="directrelay-header-tagline" style="display:inline-flex;align-items:center;gap:8px;margin-left:12px;font-size:11px;letter-spacing:0.18em;font-weight:600;color:var(--directrelay-primary,#28CCCD);text-transform:uppercase">
            <span style="display:inline-block;width:24px;height:2px;background:var(--directrelay-primary,#28CCCD);border-radius:1px"></span>
            <?php esc_html_e( 'AUTOMATION BRIDGE', 'directrelay-automation-bridge-for-n8n' ); ?>
        </span>
        <span class="directrelay-badge-pill" style="background:#10b981;color:#fff;font-weight:700;">PRO v<?php echo esc_html( defined( 'DIRECTRELAY_PRO_VERSION' ) ? DIRECTRELAY_PRO_VERSION : '1.0.0' ); ?></span> <span class="directrelay-badge-pill">Core v<?php echo esc_html( DIRECTRELAY_VERSION ); ?></span>
        <span class="directrelay-badge-pill directrelay-pill-<?php echo esc_attr( $directrelay_sp ); ?>">
            <?php
            if ( 'rankmath' === $directrelay_sp ) {
                esc_html_e( 'Rank Math', 'directrelay-automation-bridge-for-n8n' );
            } elseif ( 'yoast' === $directrelay_sp ) {
                esc_html_e( 'Yoast', 'directrelay-automation-bridge-for-n8n' );
            } else {
                esc_html_e( 'No SEO Plugin', 'directrelay-automation-bridge-for-n8n' );
            }
            ?>
        </span>
    </div>
    <div class="directrelay-header-right">
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=directrelay-keys' ) ); ?>" class="directrelay-btn directrelay-btn-primary button button-primary">+ <?php esc_html_e( 'New API Key', 'directrelay-automation-bridge-for-n8n' ); ?></a>
    </div>
</div>

<div class="directrelay-card directrelay-status-band" role="status" aria-live="polite">
    <div class="directrelay-card-body">
        <p style="margin:0; font-size:15px;">
            <strong><?php echo esc_html( number_format( $directrelay_calls_today ) ); ?></strong>
            <?php esc_html_e( 'calls today,', 'directrelay-automation-bridge-for-n8n' ); ?>
            <strong style="color:<?php echo $directrelay_errors_24h > 0 ? 'var(--directrelay-red)' : 'var(--directrelay-green)'; ?>">
                <?php echo esc_html( number_format( $directrelay_errors_24h ) ); ?>
            </strong>
            <?php esc_html_e( 'errors in the last 24 hours, last used', 'directrelay-automation-bridge-for-n8n' ); ?>
            <strong><?php echo esc_html( $directrelay_last_used_label ); ?></strong>.
        </p>
    </div>
</div>

<!-- Stats grid -->
<div class="directrelay-grid-stats">
    <?php
    $directrelay_cards = array(
        array( __( 'Requests Today', 'directrelay-automation-bridge-for-n8n' ), number_format( $directrelay_summary['requests_today'] ?? 0 ), 'directrelay-icon-blue', '<span class="dashicons dashicons-chart-bar"></span>', 'requests_today' ),
        array( __( 'Requests (7d)', 'directrelay-automation-bridge-for-n8n' ), number_format( $directrelay_summary['requests_week'] ?? 0 ),  'directrelay-icon-purple', '<span class="dashicons dashicons-chart-line"></span>', 'requests_week' ),
        array( __( 'Errors (24h)', 'directrelay-automation-bridge-for-n8n' ), number_format( $directrelay_errors_24h ),                       'directrelay-icon-red', '<span class="dashicons dashicons-warning"></span>', 'errors_24h' ),
        array( __( 'Avg Response', 'directrelay-automation-bridge-for-n8n' ), esc_html( $directrelay_summary['avg_response_ms'] ?? '0' ) . 'ms', 'directrelay-icon-green', '<span class="dashicons dashicons-clock"></span>', 'avg_response_ms' ),
        array( __( 'Active Keys', 'directrelay-automation-bridge-for-n8n' ), esc_html( $directrelay_active_keys ),                           'directrelay-icon-teal', '<span class="dashicons dashicons-admin-network"></span>', 'active_keys' ),
        array( __( 'WordPress', 'directrelay-automation-bridge-for-n8n' ), esc_html( get_bloginfo( 'version' ) ),                          'directrelay-icon-orange', '<span class="dashicons dashicons-wordpress"></span>', 'wordpress' ),
    );
    foreach ( $directrelay_cards as list( $directrelay_label, $directrelay_val, $directrelay_cls, $directrelay_icon, $directrelay_id_suffix ) ) :
        ?>
        <div class="directrelay-stat-card">
            <div class="directrelay-stat-icon <?php echo esc_attr( $directrelay_cls ); ?>"><?php echo wp_kses_post( $directrelay_icon ); ?></div>
            <div class="directrelay-stat-body">
                <span class="directrelay-stat-value" id="stat-val-<?php echo esc_attr( $directrelay_id_suffix ); ?>"><?php echo esc_html( $directrelay_val ); ?></span>
                <span class="directrelay-stat-label"><?php echo esc_html( $directrelay_label ); ?></span>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php
/**
 * Fires inside the free dashboard, after the status band and stat cards.
 *
 * The directrelay-pro plugin uses this action to render its Chart.js
 * analytics panel (call volume, error rate, latency trends, per-key
 * breakdown) below the free stat grid.
 *
 * @since 5.1.0
 *
 * @param array $data {
 *     @type array $summary     Free activity summary from Activity_Logger.
 *     @type array $hourly      24-hour hourly stats from Activity_Logger.
 *     @type array $top         Top endpoints from Activity_Logger.
 *     @type int   $active_keys Number of non-revoked API keys.
 * }
 */
do_action( 'directrelay_ext_render_pro_dashboard_panel', $directrelay_dashboard_data );
?>

<!-- Bottom Row -->
<div class="directrelay-grid-2">
    <div class="directrelay-card">
        <div class="directrelay-card-header"><h3><?php esc_html_e( 'Top Endpoints (7d)', 'directrelay-automation-bridge-for-n8n' ); ?></h3></div>
        <div id="directrelay-top-endpoints-container">
            <?php if ( empty( $directrelay_top_ep ) ) : ?>
                <p class="directrelay-empty"><?php esc_html_e( 'No data yet. Make API requests to see analytics.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
            <?php else : ?>
                <table class="directrelay-table widefat">
                    <thead><tr>
                        <th><?php esc_html_e( 'Endpoint', 'directrelay-automation-bridge-for-n8n' ); ?></th>
                        <th><?php esc_html_e( 'Method', 'directrelay-automation-bridge-for-n8n' ); ?></th>
                        <th><?php esc_html_e( 'Hits', 'directrelay-automation-bridge-for-n8n' ); ?></th>
                        <th><?php esc_html_e( 'Avg ms', 'directrelay-automation-bridge-for-n8n' ); ?></th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ( $directrelay_top_ep as $directrelay_ep ) : ?>
                        <tr>
                            <td><code><?php echo esc_html( $directrelay_ep['endpoint'] ); ?></code></td>
                            <td><span class="directrelay-method directrelay-method-<?php echo esc_attr( strtolower( $directrelay_ep['method'] ) ); ?>"><?php echo esc_html( $directrelay_ep['method'] ); ?></span></td>
                            <td><strong><?php echo esc_html( number_format( (int) $directrelay_ep['hits'] ) ); ?></strong></td>
                            <td><?php echo $directrelay_ep['avg_ms'] ? esc_html( round( (float) $directrelay_ep['avg_ms'], 1 ) . 'ms' ) : ''; ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <div class="directrelay-card">
        <div class="directrelay-card-header">
            <h3><?php esc_html_e( 'Active API Keys', 'directrelay-automation-bridge-for-n8n' ); ?></h3>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=directrelay-keys' ) ); ?>" class="directrelay-link"><?php esc_html_e( 'Manage', 'directrelay-automation-bridge-for-n8n' ); ?></a>
        </div>
        <div id="directrelay-keys-container">
            <?php
            $directrelay_active = array_filter( $directrelay_keys, fn( $k ) => ! $k['revoked'] );
            if ( empty( $directrelay_active ) ) :
                ?>
                <p class="directrelay-empty"><a href="<?php echo esc_url( admin_url( 'admin.php?page=directrelay-keys' ) ); ?>"><?php esc_html_e( 'Create your first API key', 'directrelay-automation-bridge-for-n8n' ); ?></a></p>
            <?php else : ?>
                <table class="directrelay-table">
                    <thead><tr>
                        <th><?php esc_html_e( 'Key', 'directrelay-automation-bridge-for-n8n' ); ?></th>
                        <th><?php esc_html_e( 'Label', 'directrelay-automation-bridge-for-n8n' ); ?></th>
                        <th><?php esc_html_e( 'Requests', 'directrelay-automation-bridge-for-n8n' ); ?></th>
                        <th><?php esc_html_e( 'Last Used', 'directrelay-automation-bridge-for-n8n' ); ?></th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ( array_slice( $directrelay_active, 0, 6 ) as $directrelay_k ) : ?>
                        <tr>
                            <td><code class="directrelay-key-prefix"><?php echo esc_html( $directrelay_k['key_prefix'] ); ?></code></td>
                            <td><span class="directrelay-env-dot directrelay-env-<?php echo esc_attr( $directrelay_k['environment'] ); ?>"></span><span><?php echo esc_html( $directrelay_k['label'] ); ?></span></td>
                            <td><strong><?php echo esc_html( number_format( (int) $directrelay_k['total_requests'] ) ); ?></strong></td>
                            <td><small><?php echo $directrelay_k['last_used_at'] ? esc_html( human_time_diff( strtotime( $directrelay_k['last_used_at'] ) ) . ' ' . __( 'ago', 'directrelay-automation-bridge-for-n8n' ) ) : esc_html__( 'Never', 'directrelay-automation-bridge-for-n8n' ); ?></small></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- System Status -->
<div class="directrelay-card">
    <div class="directrelay-card-header"><h3><?php esc_html_e( 'System Status', 'directrelay-automation-bridge-for-n8n' ); ?></h3></div>
    <div class="directrelay-grid-3">
        <div class="directrelay-step" style="border:0">
            <div class="directrelay-stat-body">
                <span style="font-size:12px;color:var(--directrelay-muted)"><?php esc_html_e( 'Permalinks', 'directrelay-automation-bridge-for-n8n' ); ?></span><br>
                <?php
                $directrelay_perm = get_option( 'permalink_structure' );
                if ( ! empty( $directrelay_perm ) ) : ?>
                    <span class="directrelay-badge directrelay-badge-active">&#10003; <?php esc_html_e( 'Post Name / Custom', 'directrelay-automation-bridge-for-n8n' ); ?></span>
                <?php else : ?>
                    <span class="directrelay-badge directrelay-badge-revoked">&#9888; <?php esc_html_e( 'Plain (API incompatible)', 'directrelay-automation-bridge-for-n8n' ); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="directrelay-step" style="border:0">
            <div class="directrelay-stat-body">
                <span style="font-size:12px;color:var(--directrelay-muted)"><?php esc_html_e( 'SEO Support', 'directrelay-automation-bridge-for-n8n' ); ?></span><br>
                <?php if ( 'none' !== $directrelay_sp ) : ?>
                    <span class="directrelay-badge directrelay-badge-active">&#10003; <?php echo esc_html( ucfirst( $directrelay_sp ) ); ?></span>
                <?php else : ?>
                    <span class="directrelay-badge directrelay-badge-expired">&#9888; <?php esc_html_e( 'Not Detected', 'directrelay-automation-bridge-for-n8n' ); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="directrelay-step" style="border:0">
            <div class="directrelay-stat-body">
                <span style="font-size:12px;color:var(--directrelay-muted)"><?php esc_html_e( 'SSL / HTTPS', 'directrelay-automation-bridge-for-n8n' ); ?></span><br>
                <?php if ( is_ssl() ) : ?>
                    <span class="directrelay-badge directrelay-badge-active">&#10003; <?php esc_html_e( 'Secure', 'directrelay-automation-bridge-for-n8n' ); ?></span>
                <?php else : ?>
                    <span class="directrelay-badge directrelay-badge-revoked">&#9888; <?php esc_html_e( 'Insecure', 'directrelay-automation-bridge-for-n8n' ); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- n8n Quick Connect -->
<div class="directrelay-card">
    <div class="directrelay-card-header">
        <h3><?php esc_html_e( 'n8n Quick Connect', 'directrelay-automation-bridge-for-n8n' ); ?></h3>
    </div>
    <div class="directrelay-grid-3">
        <div class="directrelay-step"><span class="directrelay-step-num">1</span>
            <div>
                <strong><?php esc_html_e( 'Add Header Auth Credential', 'directrelay-automation-bridge-for-n8n' ); ?></strong>
                <p><?php esc_html_e( 'In n8n -> Credentials -> Header Auth', 'directrelay-automation-bridge-for-n8n' ); ?></p>
                <code>Name: Authorization<br>Value: Bearer &lt;your_api_key&gt;</code>
            </div>
        </div>
        <div class="directrelay-step"><span class="directrelay-step-num">2</span>
            <div>
                <strong><?php esc_html_e( 'Set Base URL', 'directrelay-automation-bridge-for-n8n' ); ?></strong>
                <p><?php esc_html_e( 'HTTP Request node URL:', 'directrelay-automation-bridge-for-n8n' ); ?></p>
                <code><?php echo esc_url( get_site_url() . '/wp-json/' . DIRECTRELAY_NS ); ?></code>
            </div>
        </div>
        <div class="directrelay-step"><span class="directrelay-step-num">3</span>
            <div>
                <strong><?php esc_html_e( 'POST /posts', 'directrelay-automation-bridge-for-n8n' ); ?></strong>
                <p><?php esc_html_e( 'Send title, content, categories, tags in one call.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=directrelay-docs' ) ); ?>" class="directrelay-link"><?php esc_html_e( 'Full Docs', 'directrelay-automation-bridge-for-n8n' ); ?></a>
            </div>
        </div>
    </div>
</div>

<div class="directrelay-card" style="border-left:4px solid #28CCCD;margin-top:20px;">
    <div class="directrelay-card-header"><h3>🚀 <?php esc_html_e( 'Monster Pro Control Center (All 4 Tiers Active)', 'directrelay-pro' ); ?></h3></div>
    <div class="directrelay-card-body" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px;">
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=directrelay-seo-geo' ) ); ?>" style="text-decoration:none;padding:14px;border-radius:8px;border:1px solid var(--directrelay-border,#e5e7eb);background:var(--directrelay-card2,#f9fafb);display:block;">
            <strong style="color:var(--directrelay-text,#111827);font-size:14px;">🔍 Tier 1 & 2: SEO, GEO & Instant Indexing</strong>
            <p style="margin:6px 0 0;font-size:12px;color:var(--directrelay-muted,#6b7280);">4-Plugin SEO Write, Internal Link Silo Rules, /llms.txt, Google Indexing API & CDN Purge, 1200x630 OG Cards.</p>
        </a>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=directrelay-content-decay' ) ); ?>" style="text-decoration:none;padding:14px;border-radius:8px;border:1px solid var(--directrelay-border,#e5e7eb);background:var(--directrelay-card2,#f9fafb);display:block;">
            <strong style="color:var(--directrelay-text,#111827);font-size:14px;">🧬 Tier 3: CPT, ACF Pro, WC & Content Decay</strong>
            <p style="margin:6px 0 0;font-size:12px;color:var(--directrelay-muted,#6b7280);">Universal CPT & Taxonomies, ACF Pro Repeaters, WooCommerce Bridge, Multilingual & Pre-AI Snapshot Rollback.</p>
        </a>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=directrelay-approvals' ) ); ?>" style="text-decoration:none;padding:14px;border-radius:8px;border:1px solid var(--directrelay-border,#e5e7eb);background:var(--directrelay-card2,#f9fafb);display:block;">
            <strong style="color:var(--directrelay-text,#111827);font-size:14px;">🛡️ Tier 1: Approvals, Guardrails & Debugger</strong>
            <p style="margin:6px 0 0;font-size:12px;color:var(--directrelay-muted,#6b7280);">Human-in-the-Loop Magic Review Portal, AI Velocity Guardrails, and Time-Travel Dry-Run Request Replay.</p>
        </a>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=directrelay-license' ) ); ?>" style="text-decoration:none;padding:14px;border-radius:8px;border:1px solid var(--directrelay-border,#e5e7eb);background:var(--directrelay-card2,#f9fafb);display:block;">
            <strong style="color:var(--directrelay-text,#111827);font-size:14px;">🔑 Tier 4: License Server & Fleet Command</strong>
            <p style="margin:6px 0 0;font-size:12px;color:var(--directrelay-muted,#6b7280);">AutoNode License Server v2.2.0 HMAC Verification, Multi-Site Fleet Sync, White-Labeling & Security Alerts.</p>
        </a>
    </div>
</div>

</div>
