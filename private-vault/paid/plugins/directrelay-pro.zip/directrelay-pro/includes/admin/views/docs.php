<?php defined( 'ABSPATH' ) || exit; ?>


<div class="directrelay-wrap" id="directrelay-docs">

<!-- Hero Banner -->
<div class="directrelay-docs-hero">
    <div class="directrelay-docs-hero-left">
        <h1>
            <img src="<?php echo esc_url( DIRECTRELAY_URL . 'assets/icon-256x256.png' ); ?>" alt="DirectRelay" style="width:32px;height:32px;border-radius:6px;vertical-align:middle;margin-right:8px;">
            <?php esc_html_e( 'API Documentation', 'directrelay-automation-bridge-for-n8n'); ?>
        </h1>
        <p><?php esc_html_e( 'Complete REST API reference for DirectRelay add-on.', 'directrelay-automation-bridge-for-n8n'); ?></p>
    </div>
    <div style="position:relative;z-index:1;min-width:280px">
        <div style="font-size:11px;color:rgba(255,255,255,0.5);margin-bottom:4px;text-transform:uppercase;letter-spacing:0.07em;font-weight:600"><?php esc_html_e( 'API Base URL', 'directrelay-automation-bridge-for-n8n'); ?></div>
        <div class="directrelay-docs-base"><?php echo esc_html( $api_base ); ?></div>
    </div>
</div>

<div class="directrelay-docs-layout">

<!-- Sidebar Nav -->
<nav class="directrelay-docs-sidebar">
    <a href="#quickstart"><span class="directrelay-sidebar-icon">🚀</span><?php esc_html_e( 'Quick Start', 'directrelay-automation-bridge-for-n8n'); ?></a>
    <a href="#auth"><span class="directrelay-sidebar-icon">🔐</span><?php esc_html_e( 'Authentication', 'directrelay-automation-bridge-for-n8n'); ?></a>
    <a href="#posts"><span class="directrelay-sidebar-icon">📝</span><?php esc_html_e( 'Posts', 'directrelay-automation-bridge-for-n8n'); ?></a>
    <a href="#pages"><span class="directrelay-sidebar-icon">📄</span><?php esc_html_e( 'Pages', 'directrelay-automation-bridge-for-n8n'); ?></a>
    <a href="#seo"><span class="directrelay-sidebar-icon">🔍</span><?php esc_html_e( 'SEO Fields', 'directrelay-automation-bridge-for-n8n'); ?></a>
    <a href="#meta"><span class="directrelay-sidebar-icon">🔑</span><?php esc_html_e( 'Post Meta', 'directrelay-automation-bridge-for-n8n'); ?></a>
    <a href="#media"><span class="directrelay-sidebar-icon">🖼️</span><?php esc_html_e( 'Media', 'directrelay-automation-bridge-for-n8n'); ?></a>
    <a href="#taxonomy"><span class="directrelay-sidebar-icon">🏷️</span><?php esc_html_e( 'Taxonomy', 'directrelay-automation-bridge-for-n8n'); ?></a>
    <a href="#bulk"><span class="directrelay-sidebar-icon">⚡</span><?php esc_html_e( 'Bulk', 'directrelay-automation-bridge-for-n8n'); ?></a>
    <a href="#webhooks"><span class="directrelay-sidebar-icon">🪝</span><?php esc_html_e( 'Webhooks', 'directrelay-automation-bridge-for-n8n'); ?></a>
    <a href="#analytics"><span class="directrelay-sidebar-icon">📊</span><?php esc_html_e( 'Analytics', 'directrelay-automation-bridge-for-n8n'); ?></a>
    <a href="#keys"><span class="directrelay-sidebar-icon">🔑</span><?php esc_html_e( 'Key Mgmt', 'directrelay-automation-bridge-for-n8n'); ?></a>
    <a href="#system"><span class="directrelay-sidebar-icon">⚙️</span><?php esc_html_e( 'System', 'directrelay-automation-bridge-for-n8n'); ?></a>
    <a href="#errors"><span class="directrelay-sidebar-icon">⚠️</span><?php esc_html_e( 'Errors', 'directrelay-automation-bridge-for-n8n'); ?></a>
    <a href="#n8n"><span class="directrelay-sidebar-icon">🔧</span><?php esc_html_e( 'n8n Examples', 'directrelay-automation-bridge-for-n8n'); ?></a>
    <hr>
    <a href="<?php echo esc_url( admin_url( 'admin.php?page=directrelay-compat' ) ); ?>"><span class="directrelay-sidebar-icon">📋</span><?php esc_html_e( 'Compatibility', 'directrelay-automation-bridge-for-n8n'); ?></a>
</nav>

<!-- Main Content -->
<div class="directrelay-docs-content">

<!-- Quick Start -->
<section class="directrelay-doc-section" id="quickstart">
    <div class="directrelay-doc-section-header">
        <span class="directrelay-doc-section-icon">🚀</span>
        <h2><?php esc_html_e( 'Quick Start & Prerequisites', 'directrelay-automation-bridge-for-n8n'); ?></h2>
    </div>
    <div class="directrelay-doc-section-body">
        <p class="directrelay-doc-intro"><?php esc_html_e( 'Ensure your environment meets these requirements before using the API:', 'directrelay-automation-bridge-for-n8n'); ?></p>
        <div class="directrelay-prereq-grid">
            <div class="directrelay-prereq-card">
                <span class="directrelay-prereq-icon">🔌</span>
                <div><strong><?php esc_html_e( 'REST API Active', 'directrelay-automation-bridge-for-n8n'); ?></strong><p><?php esc_html_e( 'No security plugins blocking /wp-json/.', 'directrelay-automation-bridge-for-n8n'); ?></p></div>
            </div>
            <div class="directrelay-prereq-card">
                <span class="directrelay-prereq-icon">🔗</span>
                <div><strong><?php esc_html_e( 'Permalinks: Post Name', 'directrelay-automation-bridge-for-n8n'); ?></strong><p><?php esc_html_e( 'Required for API routes to resolve.', 'directrelay-automation-bridge-for-n8n'); ?></p></div>
            </div>
            <div class="directrelay-prereq-card">
                <span class="directrelay-prereq-icon">🔍</span>
                <div><strong><?php esc_html_e( 'Rank Math or Yoast SEO', 'directrelay-automation-bridge-for-n8n'); ?></strong><p><?php esc_html_e( 'Enables advanced SEO field access.', 'directrelay-automation-bridge-for-n8n'); ?></p></div>
            </div>
            <div class="directrelay-prereq-card">
                <span class="directrelay-prereq-icon">⚡</span>
                <div><strong><?php esc_html_e( 'PHP 8.1+', 'directrelay-automation-bridge-for-n8n'); ?></strong><p><?php esc_html_e( 'Required for optimal performance.', 'directrelay-automation-bridge-for-n8n'); ?></p></div>
            </div>
        </div>

        <h3 style="font-size:15px;font-weight:700;margin:20px 0 10px"><?php esc_html_e( 'Why DirectRelay Keys over Application Passwords?', 'directrelay-automation-bridge-for-n8n'); ?></h3>
        <ul class="directrelay-feature-list">
            <li><span class="directrelay-check">✓</span><div><strong><?php esc_html_e( 'Scoped', 'directrelay-automation-bridge-for-n8n'); ?></strong> — <?php esc_html_e( 'Limit to specific actions (e.g. only posts:write)', 'directrelay-automation-bridge-for-n8n'); ?></div></li>
            <li><span class="directrelay-check">✓</span><div><strong><?php esc_html_e( 'Secure', 'directrelay-automation-bridge-for-n8n'); ?></strong> — <?php esc_html_e( 'IP whitelisting and automatic key rotation', 'directrelay-automation-bridge-for-n8n'); ?></div></li>
            <li><span class="directrelay-check">✓</span><div><strong><?php esc_html_e( 'Monitored', 'directrelay-automation-bridge-for-n8n'); ?></strong> — <?php esc_html_e( 'Per-key analytics for n8n workflow tracking', 'directrelay-automation-bridge-for-n8n'); ?></div></li>
        </ul>
    </div>
</section>

<!-- Authentication -->
<section class="directrelay-doc-section" id="auth">
    <div class="directrelay-doc-section-header">
        <span class="directrelay-doc-section-icon">🔐</span>
        <h2><?php esc_html_e( 'Authentication', 'directrelay-automation-bridge-for-n8n'); ?></h2>
    </div>
    <div class="directrelay-doc-section-body">
        <p class="directrelay-doc-intro"><?php esc_html_e( 'Send your API key as a Bearer token (preferred for n8n):', 'directrelay-automation-bridge-for-n8n'); ?></p>
        <pre class="directrelay-code-block">Authorization: Bearer ampcm_&lt;64-hex-chars&gt;</pre>
        <p class="directrelay-doc-intro" style="margin-top:14px"><?php esc_html_e( 'Or as X-API-Key header:', 'directrelay-automation-bridge-for-n8n'); ?></p>
        <pre class="directrelay-code-block">X-API-Key: ampcm_&lt;64-hex-chars&gt;</pre>

        <h3 style="font-size:14px;font-weight:700;margin:20px 0 8px"><?php esc_html_e( 'Rate Limit Headers', 'directrelay-automation-bridge-for-n8n'); ?></h3>
        <pre class="directrelay-code-block">X-RateLimit-Limit: 120
X-RateLimit-Remaining: 118
X-RateLimit-Reset: 1742473260   ← Unix timestamp</pre>

        <h3 style="font-size:14px;font-weight:700;margin:20px 0 8px"><?php esc_html_e( 'Response Envelope', 'directrelay-automation-bridge-for-n8n'); ?></h3>
        <pre class="directrelay-code-block">{
  "success": true,
  "data": { },
  "request_id": "uuid"
}</pre>

        <div class="directrelay-alert directrelay-alert-info" style="margin-top:16px">
            <strong><?php esc_html_e( 'Brute-Force Protection:', 'directrelay-automation-bridge-for-n8n'); ?></strong> <?php esc_html_e( 'After 10 failed attempts within a 5-minute window, the IP is blocked with escalating durations (5min → 30min → 2h → 24h). Successful auth clears the block.', 'directrelay-automation-bridge-for-n8n'); ?>
        </div>
    </div>
</section>

<!-- Posts -->
<section class="directrelay-doc-section" id="posts">
    <div class="directrelay-doc-section-header">
        <span class="directrelay-doc-section-icon">📝</span>
        <h2><?php esc_html_e( 'Posts', 'directrelay-automation-bridge-for-n8n'); ?></h2>
    </div>
    <div class="directrelay-doc-section-body">
        <div class="directrelay-ep-list" style="margin-bottom:16px">
            <?php
            $directrelay_eps = array(
                array( 'GET',    '/posts',              'posts:read',    __( 'List posts — per_page, page, status, search, orderby, order, category', 'directrelay-automation-bridge-for-n8n') ),
                array( 'POST',   '/posts',              'posts:write',   __( 'Create post with optional inline SEO', 'directrelay-automation-bridge-for-n8n') ),
                array( 'GET',    '/posts/{id}',         'posts:read',    __( 'Get post + full SEO fields + all meta', 'directrelay-automation-bridge-for-n8n') ),
                array( 'PUT',    '/posts/{id}',         'posts:write',   __( 'Update post fields + optional inline SEO', 'directrelay-automation-bridge-for-n8n') ),
                array( 'DELETE', '/posts/{id}',         'posts:delete',  __( 'Trash post. Add ?force=true for permanent delete', 'directrelay-automation-bridge-for-n8n') ),
                array( 'POST',   '/posts/{id}/publish', 'posts:publish', __( 'Publish a draft post immediately', 'directrelay-automation-bridge-for-n8n') ),
            );
            foreach ( $directrelay_eps as list( $directrelay_m, $directrelay_ep, $directrelay_sc, $directrelay_d ) ) : ?>
            <div class="directrelay-ep-card">
                <div class="directrelay-ep-row">
                    <span class="directrelay-ep-method directrelay-method-<?php echo esc_attr( strtolower( $directrelay_m ) ); ?>"><?php echo esc_html( $directrelay_m ); ?></span>
                    <code class="directrelay-ep-path"><?php echo esc_html( $directrelay_ep ); ?></code>
                    <span class="directrelay-ep-scope"><?php echo esc_html( $directrelay_sc ); ?></span>
                </div>
                <div class="directrelay-ep-desc"><?php echo esc_html( $directrelay_d ); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
        <pre class="directrelay-code-block">POST <?php echo esc_html( $api_base ); ?>/posts
{
  "title":          "Article Title",
  "content":        "&lt;p&gt;HTML content&lt;/p&gt;",
  "status":         "draft",              // draft | publish | pending | private | future
  "excerpt":        "Short summary",
  "slug":           "custom-url-slug",
  "featured_media": 2231,                 // attachment ID
  "category_names": ["AI Marketing","SEO"],  // auto-created if missing
  "tag_names":      ["n8n","automation"],     // auto-created if missing
  "date":           "2026-03-20T10:00:00Z",
  "meta":           { "custom_field": "value" },
  "seo": {
    "focus_keyword": "AI marketing automation",
    "title":         "SEO Title 2026",
    "description":   "Meta description 145155 chars",
    "canonical_url": "https://example.com/ai-marketing/",
    "og_title":      "OG Title", "og_description": "OG Desc",
    "og_image_id":   2231,
    "robots":        "index,follow",
    "pillar_content": true
  }
}</pre>
    </div>
</section>

<!-- Pages -->
<section class="directrelay-doc-section" id="pages">
    <div class="directrelay-doc-section-header">
        <span class="directrelay-doc-section-icon">📄</span>
        <h2><?php esc_html_e( 'Pages', 'directrelay-automation-bridge-for-n8n'); ?></h2>
    </div>
    <div class="directrelay-doc-section-body">
        <p class="directrelay-doc-intro"><?php esc_html_e( 'Identical payload to Posts. Replace', 'directrelay-automation-bridge-for-n8n'); ?> <code>/posts</code> → <code>/pages</code>. <?php esc_html_e( 'Scopes:', 'directrelay-automation-bridge-for-n8n'); ?> <code>pages:read</code> <code>pages:write</code> <code>pages:delete</code></p>
        <pre class="directrelay-code-block">POST <?php echo esc_html( $api_base ); ?>/pages
{ "title": "Landing Page", "content": "", "status": "publish", "parent_id": 0 }</pre>
    </div>
</section>

<!-- SEO -->
<section class="directrelay-doc-section" id="seo">
    <div class="directrelay-doc-section-header">
        <span class="directrelay-doc-section-icon">🔍</span>
        <h2><?php esc_html_e( 'SEO Fields', 'directrelay-automation-bridge-for-n8n'); ?></h2>
    </div>
    <div class="directrelay-doc-section-body">
        <p class="directrelay-doc-intro"><?php esc_html_e( 'Read or update all SEO fields independently. Works for both posts and pages.', 'directrelay-automation-bridge-for-n8n'); ?></p>
        <div class="directrelay-ep-list" style="margin-bottom:16px">
            <div class="directrelay-ep-card">
                <div class="directrelay-ep-row">
                    <span class="directrelay-ep-method directrelay-method-get">GET</span>
                    <code class="directrelay-ep-path">/posts/{id}/seo</code>
                    <span class="directrelay-ep-scope">seo:read</span>
                    <code class="directrelay-ep-path">/pages/{id}/seo</code>
                </div>
                <div class="directrelay-ep-desc"><?php esc_html_e( 'Returns all Rank Math / Yoast SEO fields', 'directrelay-automation-bridge-for-n8n'); ?></div>
            </div>
            <div class="directrelay-ep-card">
                <div class="directrelay-ep-row">
                    <span class="directrelay-ep-method directrelay-method-put">PUT</span>
                    <code class="directrelay-ep-path">/posts/{id}/seo</code>
                    <span class="directrelay-ep-scope">seo:write</span>
                </div>
                <div class="directrelay-ep-desc"><?php esc_html_e( 'Update any subset of SEO fields', 'directrelay-automation-bridge-for-n8n'); ?></div>
            </div>
        </div>
        <pre class="directrelay-code-block">// Full field list (Rank Math):
{
  "focus_keyword", "title", "description", "robots", "canonical_url",
  "og_title", "og_description", "og_image", "og_image_id", "og_object_type",
  "twitter_title", "twitter_description", "twitter_image", "twitter_card_type",
  "primary_category", "schema_type", "breadcrumb_title",
  "pillar_content", "advanced_robots", "faq_schema"
}</pre>
    </div>
</section>

<!-- Meta -->
<section class="directrelay-doc-section" id="meta">
    <div class="directrelay-doc-section-header">
        <span class="directrelay-doc-section-icon">🔑</span>
        <h2><?php esc_html_e( 'Post Meta', 'directrelay-automation-bridge-for-n8n'); ?></h2>
    </div>
    <div class="directrelay-doc-section-body">
        <p class="directrelay-doc-intro"><?php esc_html_e( 'Dedicated endpoint for custom fields. SEO meta keys (rank_math_*, _yoast_wpseo_*) are blocked — use the', 'directrelay-automation-bridge-for-n8n'); ?> <code>/seo</code> <?php esc_html_e( 'endpoint for those.', 'directrelay-automation-bridge-for-n8n'); ?></p>
        <div class="directrelay-ep-list" style="margin-bottom:16px">
            <?php foreach ( array(
                array( 'GET',    '/posts/{id}/meta',         'posts:read' ),
                array( 'PUT',    '/posts/{id}/meta',         'posts:write' ),
                array( 'DELETE', '/posts/{id}/meta/{key}',   'posts:write' ),
            ) as list( $directrelay_m, $directrelay_ep, $directrelay_sc ) ) : ?>
            <div class="directrelay-ep-card">
                <div class="directrelay-ep-row">
                    <span class="directrelay-ep-method directrelay-method-<?php echo esc_attr( strtolower( $directrelay_m ) ); ?>"><?php echo esc_html( $directrelay_m ); ?></span>
                    <code class="directrelay-ep-path"><?php echo esc_html( $directrelay_ep ); ?></code>
                    <span class="directrelay-ep-scope"><?php echo esc_html( $directrelay_sc ); ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <pre class="directrelay-code-block">PUT /posts/123/meta
{ "custom_css_class": "hero-blue", "reading_time_minutes": 5 }

// Response:
{ "post_id": 123, "updated": 2, "skipped": 0, "errors": [] }</pre>
    </div>
</section>

<!-- Media -->
<section class="directrelay-doc-section" id="media">
    <div class="directrelay-doc-section-header">
        <span class="directrelay-doc-section-icon">🖼️</span>
        <h2><?php esc_html_e( 'Media', 'directrelay-automation-bridge-for-n8n'); ?></h2>
    </div>
    <div class="directrelay-doc-section-body">
        <div class="directrelay-ep-list" style="margin-bottom:16px">
            <?php foreach ( array(
                array( 'GET',    '/media',           'media:read' ),
                array( 'GET',    '/media/{id}',       'media:read' ),
                array( 'PUT',    '/media/{id}',       'media:write' ),
                array( 'DELETE', '/media/{id}',       'media:delete' ),
            ) as list( $directrelay_m, $directrelay_ep, $directrelay_sc ) ) : ?>
            <div class="directrelay-ep-card">
                <div class="directrelay-ep-row">
                    <span class="directrelay-ep-method directrelay-method-<?php echo esc_attr( strtolower( $directrelay_m ) ); ?>"><?php echo esc_html( $directrelay_m ); ?></span>
                    <code class="directrelay-ep-path"><?php echo esc_html( $directrelay_ep ); ?></code>
                    <span class="directrelay-ep-scope"><?php echo esc_html( $directrelay_sc ); ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <h4 style="font-size:13px;font-weight:700;margin:0 0 8px"><?php esc_html_e( 'Upload via base64', 'directrelay-automation-bridge-for-n8n'); ?></h4>
        <pre class="directrelay-code-block">POST <?php echo esc_html( $api_base ); ?>/media
{
  "filename":    "featured.jpg",
  "file_base64": "&lt;base64 bytes&gt;",
  "mime_type":   "image/jpeg",
  "title":       "Image Title",
  "alt":         "Alt text for SEO",
  "post_id":     123
}</pre>
        <h4 style="font-size:13px;font-weight:700;margin:16px 0 8px"><?php esc_html_e( 'Sideload from URL (n8n-friendly)', 'directrelay-automation-bridge-for-n8n'); ?></h4>
        <pre class="directrelay-code-block">POST <?php echo esc_html( $api_base ); ?>/media/sideload
{
  "url":      "https://cdn.example.com/image.jpg",
  "title":    "Featured Image",
  "alt":      "AI robot working at desk",
  "filename": "featured-image.jpg",
  "post_id":  123
}

// Returns:
{ "id": 2231, "title": "", "source_url": "https://…", "width": 1920, "height": 1080 }</pre>
    </div>
</section>

<!-- Taxonomy -->
<section class="directrelay-doc-section" id="taxonomy">
    <div class="directrelay-doc-section-header">
        <span class="directrelay-doc-section-icon">🏷️</span>
        <h2><?php esc_html_e( 'Taxonomy', 'directrelay-automation-bridge-for-n8n'); ?></h2>
    </div>
    <div class="directrelay-doc-section-body">
        <pre class="directrelay-code-block">GET  <?php echo esc_html( $api_base ); ?>/categories    // all categories
POST <?php echo esc_html( $api_base ); ?>/categories    { "name": "AI Tools", "slug": "ai-tools" }
GET  <?php echo esc_html( $api_base ); ?>/tags          // all tags
POST <?php echo esc_html( $api_base ); ?>/tags          { "name": "automation" }

// Auto-create in post body (recommended — no pre-check needed):
POST /posts
{
  "category_names": ["AI Marketing", "Tutorials"],
  "tag_names":      ["n8n", "automation"]
}</pre>
    </div>
</section>

<!-- Bulk -->
<section class="directrelay-doc-section" id="bulk">
    <div class="directrelay-doc-section-header">
        <span class="directrelay-doc-section-icon">⚡</span>
        <h2><?php esc_html_e( 'Bulk Operations', 'directrelay-automation-bridge-for-n8n'); ?></h2>
    </div>
    <div class="directrelay-doc-section-body">
        <p class="directrelay-doc-intro">
            <?php
            echo '<div class="directrelay-ep-list"><div class="directrelay-ep-row"><span class="directrelay-method directrelay-m-post">POST</span><code>/publish/one-shot</code><span class="directrelay-ep-desc">Atomic Post + Media + Gallery + 4-Plugin SEO &amp; 5 JSON-LD Schemas with compensating rollback</span></div><div class="directrelay-ep-row"><span class="directrelay-method directrelay-m-post">POST</span><code>/bulk</code><span class="directrelay-ep-desc">Batch create, update, publish, trash, or delete up to 50 items per request with inline SEO</span></div><div class="directrelay-ep-row"><span class="directrelay-method directrelay-m-post">POST</span><code>/publish/universal</code><span class="directrelay-ep-desc">Universal Schema Translator for arbitrary AI / scraper JSON payloads</span></div><div class="directrelay-ep-row"><span class="directrelay-method directrelay-m-put">PUT</span><code>/{posts|pages}/{id}/seo</code><span class="directrelay-ep-desc">Bidirectional SEO &amp; JSON-LD Schema Write across Rank Math, Yoast, AIOSEO, and SEOPress</span></div><div class="directrelay-ep-row"><span class="directrelay-method directrelay-m-get">GET</span><code>/seo/internal-links</code><span class="directrelay-ep-desc">Contextual internal link suggestions &amp; semantic silo rule management</span></div><div class="directrelay-ep-row"><span class="directrelay-method directrelay-m-post">POST</span><code>/indexer/submit &amp; /cdn/purge</code><span class="directrelay-ep-desc">Google Indexing API (RS256) submission &amp; Cloudflare/BunnyCDN/Fastly/LiteSpeed cache purge</span></div><div class="directrelay-ep-row"><span class="directrelay-method directrelay-m-post">POST</span><code>/cpt/{post_type} &amp; /wc/products</code><span class="directrelay-ep-desc">Universal Custom Post Type + ACF Pro Repeaters &amp; WooCommerce Product/Order/Inventory Bridge</span></div><div class="directrelay-ep-row"><span class="directrelay-method directrelay-m-post">POST</span><code>/fleet/sync &amp; /webhooks/dlq/redrive</code><span class="directrelay-ep-desc">Multi-Site Fleet Command, Webhook 2.0 Conditional Rules &amp; Dead-Letter Queue Re-Drive</span></div></div>';
            printf(
                wp_kses(
                    $directrelay_ext_intro,
                    [ 'a' => [ 'href' => [], 'target' => [], 'rel' => [] ] ]
                ),
                esc_url( 'https://directrelay.wikiofautomation.com/directrelay-pro' )
            );
            ?>
        </p>
    </div>
</section>

<!-- Webhooks -->
<section class="directrelay-doc-section" id="webhooks">
    <div class="directrelay-doc-section-header">
        <span class="directrelay-doc-section-icon">🪝</span>
        <h2><?php esc_html_e( 'Webhooks', 'directrelay-automation-bridge-for-n8n'); ?></h2>
    </div>
   <div class="directrelay-doc-section-body">
        <p class="directrelay-doc-intro"><?php esc_html_e( 'Webhooks fire asynchronously via WP-Cron with automatic retry (up to 3 attempts: 60s → 300s → 900s delays).', 'directrelay-automation-bridge-for-n8n'); ?></p>
        <div class="directrelay-ep-list" style="margin-bottom:14px">
            <?php foreach ( array(
                array( 'GET',    '/webhooks',                   'webhooks:read' ),
                array( 'POST',   '/webhooks',                   'webhooks:write' ),
                array( 'PUT',    '/webhooks/{id}',              'webhooks:write' ),
                array( 'DELETE', '/webhooks/{id}',              'webhooks:write' ),
                array( 'POST',   '/webhooks/{id}/test',         'webhooks:write' ),
                array( 'GET',    '/webhooks/{id}/deliveries',   'webhooks:read' ),
            ) as list( $directrelay_m, $directrelay_ep, $directrelay_sc ) ) : ?>
            <div class="directrelay-ep-card">
                <div class="directrelay-ep-row">
                    <span class="directrelay-ep-method directrelay-method-<?php echo esc_attr( strtolower( $directrelay_m ) ); ?>"><?php echo esc_html( $directrelay_m ); ?></span>
                    <code class="directrelay-ep-path"><?php echo esc_html( $directrelay_ep ); ?></code>
                    <span class="directrelay-ep-scope"><?php echo esc_html( $directrelay_sc ); ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <pre class="directrelay-code-block">POST <?php echo esc_html( $api_base ); ?>/webhooks
{
  "label":      "n8n Post Published",
  "target_url": "https://n8n.example.com/webhook/",
  "secret":     "my-signing-secret",       // optional HMAC signing
  "events":     ["post.published","page.published"],
  "post_types": ["post","page"]
}</pre>
        <h4 style="font-size:13px;font-weight:700;margin:16px 0 8px"><?php esc_html_e( 'Available Events', 'directrelay-automation-bridge-for-n8n'); ?></h4>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:14px">
            <?php foreach ( array( 'post.created', 'post.updated', 'post.published', 'post.deleted', 'page.created', 'page.updated', 'page.published', 'page.deleted', 'media.uploaded', 'test' ) as $directrelay_ev ) : ?>
            <span class="directrelay-ep-scope"><?php echo esc_html( $directrelay_ev ); ?></span>
            <?php endforeach; ?>
        </div>
        <h4 style="font-size:13px;font-weight:700;margin:0 0 8px"><?php esc_html_e( 'Webhook Payload', 'directrelay-automation-bridge-for-n8n'); ?></h4>
        <pre class="directrelay-code-block">{
  "event":       "post.published",
  "object_id":   123,
  "object_type": "post",
  "timestamp":   "2026-03-21T10:30:00+00:00",
  "site_url":    "https://example.com",
  "post": { "id": 123, "title": "", "status": "publish", "link": "https://…" },
  "seo": { "plugin": "rankmath", "focus_keyword": "", "title": "" }
}</pre>
    </div>
</section>

<!-- Analytics -->
<section class="directrelay-doc-section" id="analytics">
    <div class="directrelay-doc-section-header">
        <span class="directrelay-doc-section-icon">📊</span>
        <h2><?php esc_html_e( 'Analytics', 'directrelay-automation-bridge-for-n8n'); ?></h2>
    </div>
    <div class="directrelay-doc-section-body">
        <p style="color:var(--directrelay-dim);margin:0">
            <?php
            /* translators: %s: DirectRelay add-on product page URL */
            $directrelay_ext_intro = __( 'Free analytics live in the dashboard status band (today\'s calls, 24h errors, last-used timestamp). Detailed per-hour, per-endpoint, and per-key analytics, plus the Chart.js dashboard, are provided by the <a href="%s" target="_blank" rel="noopener">DirectRelay add-on</a> add-on plugin.', 'directrelay-automation-bridge-for-n8n' );
            printf(
                wp_kses(
                    $directrelay_ext_intro,
                    [ 'a' => [ 'href' => [], 'target' => [], 'rel' => [] ] ]
                ),
                esc_url( 'https://directrelay.wikiofautomation.com/directrelay-pro' )
            );
            ?>
        </p>
    </div>
</section>

<!-- Key Management -->
<section class="directrelay-doc-section" id="keys">
    <div class="directrelay-doc-section-header">
        <span class="directrelay-doc-section-icon">🔑</span>
        <h2><?php esc_html_e( 'Key Management', 'directrelay-automation-bridge-for-n8n'); ?></h2>
    </div>
    <div class="directrelay-doc-section-body">
        <div class="directrelay-ep-list" style="margin-bottom:14px">
            <?php foreach ( array(
                array( 'GET',    '/keys',                   'keys:read',   __( 'List all your API keys', 'directrelay-automation-bridge-for-n8n') ),
                array( 'POST',   '/keys/{id}/revoke',       'keys:write',  __( 'Permanently revoke a key', 'directrelay-automation-bridge-for-n8n') ),
                array( 'POST',   '/keys/{id}/rotate',       'keys:write',  __( 'Generate new secret, keep same ID and scopes', 'directrelay-automation-bridge-for-n8n') ),
            ) as list( $directrelay_m, $directrelay_ep, $directrelay_sc, $directrelay_d ) ) : ?>
            <div class="directrelay-ep-card">
                <div class="directrelay-ep-row">
                    <span class="directrelay-ep-method directrelay-method-<?php echo esc_attr( strtolower( $directrelay_m ) ); ?>"><?php echo esc_html( $directrelay_m ); ?></span>
                    <code class="directrelay-ep-path"><?php echo esc_html( $directrelay_ep ); ?></code>
                    <span class="directrelay-ep-scope"><?php echo esc_html( $directrelay_sc ); ?></span>
                </div>
                <div class="directrelay-ep-desc"><?php echo esc_html( $directrelay_d ); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
        <pre class="directrelay-code-block">POST <?php echo esc_html( $api_base ); ?>/keys/{id}/rotate
// Returns new raw key — store immediately:
{
  "raw_key": "ampcm_&lt;new-64-hex&gt;",
  "id": 5,
  "prefix": "ampcm_a3f8",
  "label": "n8n Production"
}</pre>
    </div>
</section>

<!-- System -->
<section class="directrelay-doc-section" id="system">
    <div class="directrelay-doc-section-header">
        <span class="directrelay-doc-section-icon">⚙️</span>
        <h2><?php esc_html_e( 'System', 'directrelay-automation-bridge-for-n8n'); ?></h2>
    </div>
    <div class="directrelay-doc-section-body">
        <div class="directrelay-ep-list">
            <?php foreach ( array(
                array( 'GET', '/ping',        null,           __( 'Public health check — no auth required', 'directrelay-automation-bridge-for-n8n') ),
                array( 'GET', '/status',      'system:read',  __( 'Key info, scopes, SEO plugin, cron status', 'directrelay-automation-bridge-for-n8n') ),
                array( 'GET', '/cron-health', 'system:read',  __( 'Detailed cron health: last ping, stale warning', 'directrelay-automation-bridge-for-n8n') ),
                array( 'GET', '/blocked-ips', 'system:read',  __( 'Current brute-force IP blocks', 'directrelay-automation-bridge-for-n8n') ),
            ) as list( $directrelay_m, $directrelay_ep, $directrelay_sc, $directrelay_d ) ) : ?>
            <div class="directrelay-ep-card">
                <div class="directrelay-ep-row">
                    <span class="directrelay-ep-method directrelay-method-get">GET</span>
                    <code class="directrelay-ep-path"><?php echo esc_html( $directrelay_ep ); ?></code>
                    <?php if ( $directrelay_sc ) : ?><span class="directrelay-ep-scope"><?php echo esc_html( $directrelay_sc ); ?></span><?php endif; ?>
                </div>
                <div class="directrelay-ep-desc"><?php echo esc_html( $directrelay_d ); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Errors -->
<section class="directrelay-doc-section" id="errors">
    <div class="directrelay-doc-section-header">
        <span class="directrelay-doc-section-icon">⚠️</span>
        <h2><?php esc_html_e( 'Error Reference', 'directrelay-automation-bridge-for-n8n'); ?></h2>
    </div>
    <div class="directrelay-doc-section-body" style="overflow-x:auto">
        <table class="directrelay-err-table">
            <thead><tr>
                <th><?php esc_html_e( 'HTTP', 'directrelay-automation-bridge-for-n8n'); ?></th>
                <th><?php esc_html_e( 'Code', 'directrelay-automation-bridge-for-n8n'); ?></th>
                <th><?php esc_html_e( 'Cause', 'directrelay-automation-bridge-for-n8n'); ?></th>
            </tr></thead>
            <tbody>
            <?php
            $directrelay_errors = array(
                array( 401, 'amp_no_auth',       __( 'Missing Authorization / X-API-Key header', 'directrelay-automation-bridge-for-n8n') ),
                array( 401, 'amp_bad_token',     __( "Token doesn't start with ampcm_", 'directrelay-automation-bridge-for-n8n') ),
                array( 401, 'amp_invalid_key',   __( 'Key not found, revoked, or expired', 'directrelay-automation-bridge-for-n8n') ),
                array( 403, 'amp_ip_blocked',    __( 'IP not in whitelist or brute-force blocked', 'directrelay-automation-bridge-for-n8n') ),
                array( 403, 'amp_forbidden',     __( 'Key lacks required scope', 'directrelay-automation-bridge-for-n8n') ),
                array( 403, 'amp_ssl_required',  __( 'HTTPS required but HTTP used', 'directrelay-automation-bridge-for-n8n') ),
                array( 404, 'amp_not_found',     __( 'Resource not found', 'directrelay-automation-bridge-for-n8n') ),
                array( 429, 'amp_rate_limited',  __( 'Rate limit exceeded — check X-RateLimit-Reset', 'directrelay-automation-bridge-for-n8n') ),
                array( 429, 'amp_ip_blocked',    __( 'Brute-force block — check retry-after seconds', 'directrelay-automation-bridge-for-n8n') ),
                array( 400, 'amp_invalid',       __( 'Missing or invalid field in request body', 'directrelay-automation-bridge-for-n8n') ),
            );
            foreach ( $directrelay_errors as list( $directrelay_code, $directrelay_err_code, $directrelay_cause ) ) : ?>
            <tr class="directrelay-err-<?php echo (int) $directrelay_code; ?>">
                <td class="directrelay-err-http"><?php echo (int) $directrelay_code; ?></td>
                <td><code class="directrelay-err-code"><?php echo esc_html( $directrelay_err_code ); ?></code></td>
                <td class="directrelay-err-cause"><?php echo esc_html( $directrelay_cause ); ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<!-- n8n Examples -->
<section class="directrelay-doc-section" id="n8n">
    <div class="directrelay-doc-section-header">
        <span class="directrelay-doc-section-icon">🔧</span>
        <h2><?php esc_html_e( 'n8n Workflow Examples', 'directrelay-automation-bridge-for-n8n'); ?></h2>
    </div>
    <div class="directrelay-doc-section-body">

        <div class="directrelay-n8n-example">
            <h4><span class="directrelay-n8n-num">1</span><?php esc_html_e( 'Header Auth Credential', 'directrelay-automation-bridge-for-n8n'); ?></h4>
            <pre class="directrelay-code-block">Type: Header Auth
Name: Authorization
Value: Bearer ampcm_YOUR_KEY_HERE</pre>
        </div>

        <div class="directrelay-n8n-example">
            <h4><span class="directrelay-n8n-num">2</span><?php esc_html_e( 'Create Post with Full SEO', 'directrelay-automation-bridge-for-n8n'); ?></h4>
            <pre class="directrelay-code-block">POST <?php echo esc_html( $api_base ); ?>/posts
{
  "title":          "{{ $json.seo_title }}",
  "content":        "{{ $json.article_html }}",
  "status":         "draft",
  "category_names": {{ $json.categories.split(',').map(s => s.trim()) }},
  "tag_names":      {{ $json.tags.split(',').map(s => s.trim()) }},
  "featured_media": {{ $json.wp_media_id }},
  "seo": {
    "focus_keyword": "{{ $json.seo_focus_keyword }}",
    "title":         "{{ $json.seo_title }}",
    "description":   "{{ $json.seo_meta_description }}",
    "robots":        "index,follow",
    "pillar_content": false
  }
}</pre>
        </div>

        <div class="directrelay-n8n-example">
            <h4><span class="directrelay-n8n-num">3</span><?php esc_html_e( 'Upload Image from URL (sideload)', 'directrelay-automation-bridge-for-n8n'); ?></h4>
            <pre class="directrelay-code-block">POST <?php echo esc_html( $api_base ); ?>/media/sideload
{
  "url":   "{{ $json.image_url }}",
  "title": "{{ $json.image_title }}",
  "alt":   "{{ $json.image_alt }}"
}
// Returns: { "media": { "id": 2231, "source_url": "…" } }
// Use media.id as featured_media in /posts</pre>
        </div>

        <div class="directrelay-n8n-example">
            <h4><span class="directrelay-n8n-num">4</span><?php esc_html_e( 'Bulk Publish After QA Gate', 'directrelay-automation-bridge-for-n8n'); ?></h4>
            <pre class="directrelay-code-block">POST <?php echo esc_html( $api_base ); ?>/bulk
{
  "operation": "publish",
  "items": {{ $items.map(p => ({ id: p.json.wp_post_id })) }}
}</pre>
        </div>

        <div class="directrelay-n8n-example">
            <h4><span class="directrelay-n8n-num">5</span><?php esc_html_e( 'Verify Webhook HMAC Signature', 'directrelay-automation-bridge-for-n8n'); ?></h4>
            <pre class="directrelay-code-block">// Code node after Webhook trigger:
const crypto = require('crypto');
const body   = $input.first().json.rawBody;
const secret = 'your-webhook-secret';
const expected = 'sha256=' + crypto.createHmac('sha256', secret).update(body).digest('hex');
const received  = $input.first().headers['x-directrelay-signature'];
if (expected !== received) throw new Error('Signature mismatch');

// Replay protection (recommended): reject deliveries older than 5 minutes.
const ts      = Number($input.first().headers['x-directrelay-timestamp']);
const tsSig   = $input.first().headers['x-directrelay-signature-timestamp'];
const tsExpected = 'sha256=' + crypto.createHmac('sha256', secret).update(ts + '.' + body).digest('hex');
if (Math.abs(Date.now() / 1000 - ts) > 300 || tsExpected !== tsSig) throw new Error('Stale or invalid timestamp');
return $input.all();</pre>
        </div>

        <div class="directrelay-n8n-example">
            <h4><span class="directrelay-n8n-num">6</span><?php esc_html_e( 'Full Publishing Pipeline Workflow (n8n JSON)', 'directrelay-automation-bridge-for-n8n'); ?></h4>
            <p><?php esc_html_e( 'Copy the JSON below and press Ctrl+V (Cmd+V) directly on your n8n canvas:', 'directrelay-automation-bridge-for-n8n'); ?></p>
            <div style="position:relative;margin-top:10px;">
                <button class="directrelay-btn directrelay-btn-ghost directrelay-copy-btn" data-target="directrelay-pro-wf-full" style="position:absolute;top:10px;right:10px;z-index:2;"><?php esc_html_e( 'Copy JSON', 'directrelay-automation-bridge-for-n8n'); ?></button>
                <pre class="directrelay-code-block" id="directrelay-pro-wf-full" style="max-height:240px;overflow-y:auto;">{
  "name": "DirectRelay - Full Publishing Pipeline",
  "nodes": [
    {
      "parameters": {},
      "id": "full-trigger-0001",
      "name": "When clicking 'Test workflow'",
      "type": "n8n-nodes-base.manualTrigger",
      "typeVersion": 1,
      "position": [220, 300]
    },
    {
      "parameters": {
        "method": "POST",
        "url": "<?php echo esc_url( $api_base ); ?>/posts",
        "sendHeaders": true,
        "headerParameters": {
          "parameters": [
            { "name": "Authorization", "value": "Bearer ampcm_YOUR_API_KEY_HERE" }
          ]
        },
        "sendBody": true,
        "specifyBody": "json",
        "jsonBody": "{\n  \"title\": \"My First Automated Post\",\n  \"content\": \"## Hello from n8n!\\n\\nPublished via DirectRelay.\",\n  \"status\": \"publish\",\n  \"rankmath_focus_keyword\": \"automated publishing\"\n}"
      },
      "id": "full-post-0005",
      "name": "Publish Post with SEO",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 4.2,
      "position": [460, 300]
    }
  ],
  "connections": {
    "When clicking 'Test workflow'": { "main": [[{ "node": "Publish Post with SEO", "type": "main", "index": 0 }]] }
  },
  "settings": { "executionOrder": "v1" }
}</pre>
            </div>
        </div>

    </div>
</section>

</div>
</div>
</div>