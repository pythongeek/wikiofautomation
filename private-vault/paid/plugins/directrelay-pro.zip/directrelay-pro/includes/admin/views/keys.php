<?php
defined( 'ABSPATH' ) || exit;

// Compute stats for the summary strip.
$directrelay_total   = count( $directrelay_keys );
$directrelay_active  = 0;
$directrelay_expired = 0;
$directrelay_revoked = 0;

foreach ( $directrelay_keys as $directrelay_k_stat ) {
	if ( $directrelay_k_stat['revoked'] ) {
		++$directrelay_revoked;
	} elseif ( $directrelay_k_stat['expires_at'] && strtotime( $directrelay_k_stat['expires_at'] ) <= time() ) {
		++$directrelay_expired;
	} else {
		++$directrelay_active;
	}
}
?>
<div class="directrelay-wrap">

<!-- ── Page Header ──────────────────────────────────────────────── -->
<div class="directrelay-header">
	<div class="directrelay-header-left">
		<h1 class="directrelay-page-title">
			<img src="<?php echo esc_url( DIRECTRELAY_URL . 'assets/icon-256x256.png' ); ?>" alt="DirectRelay" style="width:32px;height:32px;vertical-align:middle;margin-right:8px;border-radius:6px;">
			<?php esc_html_e( 'API Keys', 'directrelay-automation-bridge-for-n8n' ); ?>
		</h1>
		<span class="directrelay-badge-pill"><?php
			/* translators: %d: number of active keys */
			echo esc_html( sprintf( __( '%d active', 'directrelay-automation-bridge-for-n8n' ), (int) $directrelay_active ) );
		?></span>
		<span class="directrelay-badge-pill">v<?php echo esc_html( DIRECTRELAY_VERSION ); ?></span>
	</div>
	<div class="directrelay-header-right">
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=directrelay-docs' ) ); ?>" class="directrelay-btn directrelay-btn-ghost" style="font-size:12px;">
			<span class="dashicons dashicons-editor-help" style="font-size:16px;width:16px;height:16px;line-height:16px;"></span>
			<?php esc_html_e( 'API Docs', 'directrelay-automation-bridge-for-n8n' ); ?>
		</a>
	</div>
</div>

<!-- ── Stats Strip ─────────────────────────────────────────────── -->
<div class="directrelay-keys-stats">
	<div class="directrelay-keys-stat-item">
		<div class="directrelay-stat-icon directrelay-icon-blue">
			<span class="dashicons dashicons-admin-network"></span>
		</div>
		<div>
			<span class="directrelay-stat-value"><?php echo esc_html( $directrelay_total ); ?></span>
			<span class="directrelay-stat-label"><?php esc_html_e( 'Total Keys', 'directrelay-automation-bridge-for-n8n' ); ?></span>
		</div>
	</div>
	<div class="directrelay-keys-stat-item">
		<div class="directrelay-stat-icon directrelay-icon-green">
			<span class="dashicons dashicons-yes-alt"></span>
		</div>
		<div>
			<span class="directrelay-stat-value"><?php echo esc_html( $directrelay_active ); ?></span>
			<span class="directrelay-stat-label"><?php esc_html_e( 'Active', 'directrelay-automation-bridge-for-n8n' ); ?></span>
		</div>
	</div>
	<div class="directrelay-keys-stat-item">
		<div class="directrelay-stat-icon directrelay-icon-orange">
			<span class="dashicons dashicons-clock"></span>
		</div>
		<div>
			<span class="directrelay-stat-value"><?php echo esc_html( $directrelay_expired ); ?></span>
			<span class="directrelay-stat-label"><?php esc_html_e( 'Expired', 'directrelay-automation-bridge-for-n8n' ); ?></span>
		</div>
	</div>
	<div class="directrelay-keys-stat-item">
		<div class="directrelay-stat-icon directrelay-icon-red">
			<span class="dashicons dashicons-dismiss"></span>
		</div>
		<div>
			<span class="directrelay-stat-value"><?php echo esc_html( $directrelay_revoked ); ?></span>
			<span class="directrelay-stat-label"><?php esc_html_e( 'Revoked', 'directrelay-automation-bridge-for-n8n' ); ?></span>
		</div>
	</div>
</div>

<!-- ── Create New Key Card ─────────────────────────────────────── -->
<div class="directrelay-card directrelay-wizard-container" id="directrelay-create-key-card">
	<div class="directrelay-wizard-header">
		<h3 class="directrelay-wizard-title">
			<span class="dashicons dashicons-admin-network" style="color:var(--directrelay-primary);font-size:20px;width:20px;height:20px;"></span>
			<?php esc_html_e( 'API Key Setup Wizard', 'directrelay-automation-bridge-for-n8n' ); ?>
		</h3>
		<button type="button" class="directrelay-btn directrelay-btn-ghost-sm directrelay-create-key-toggle" aria-expanded="true" aria-controls="directrelay-create-key-form-wrap">
			<span class="dashicons dashicons-arrow-up-alt2 directrelay-toggle-icon" style="font-size:18px;width:18px;height:18px;line-height:18px;"></span>
		</button>
	</div>
	
	<div id="directrelay-create-key-form-wrap">
		<!-- Step Indicators -->
		<div class="directrelay-wizard-steps">
			<div class="directrelay-wizard-step-item active" data-step="1">
				<div class="directrelay-wizard-step-circle">1</div>
				<div class="directrelay-wizard-step-label">
					<span class="directrelay-wizard-step-name"><?php esc_html_e( 'Identity', 'directrelay-automation-bridge-for-n8n' ); ?></span>
					<span class="directrelay-wizard-step-desc"><?php esc_html_e( 'Name & Environment', 'directrelay-automation-bridge-for-n8n' ); ?></span>
				</div>
			</div>
			<div class="directrelay-wizard-step-line"></div>
			<div class="directrelay-wizard-step-item" data-step="2">
				<div class="directrelay-wizard-step-circle">2</div>
				<div class="directrelay-wizard-step-label">
					<span class="directrelay-wizard-step-name"><?php esc_html_e( 'Security', 'directrelay-automation-bridge-for-n8n' ); ?></span>
					<span class="directrelay-wizard-step-desc"><?php esc_html_e( 'Expiry & Whitelist', 'directrelay-automation-bridge-for-n8n' ); ?></span>
				</div>
			</div>
			<div class="directrelay-wizard-step-line"></div>
			<div class="directrelay-wizard-step-item" data-step="3">
				<div class="directrelay-wizard-step-circle">3</div>
				<div class="directrelay-wizard-step-label">
					<span class="directrelay-wizard-step-name"><?php esc_html_e( 'Permissions', 'directrelay-automation-bridge-for-n8n' ); ?></span>
					<span class="directrelay-wizard-step-desc"><?php esc_html_e( 'Templates & Scopes', 'directrelay-automation-bridge-for-n8n' ); ?></span>
				</div>
			</div>
		</div>

		<div class="directrelay-alert directrelay-alert-info">
			<span class="dashicons dashicons-shield" style="flex-shrink:0;margin-top:1px;"></span>
			<div>
				<?php esc_html_e( 'The raw API key is shown only once after creation. Copy and store it immediately in n8n or your password manager.', 'directrelay-automation-bridge-for-n8n' ); ?>
			</div>
		</div>
		
		<form id="directrelay-create-key-form">
			
			<!-- Step 1: Identity & Context -->
			<div class="directrelay-wizard-step-panel active" id="directrelay-step-panel-1">
				<div class="directrelay-wizard-step-panel-inner">
					<div class="directrelay-form-group" style="margin-bottom: 20px;">
						<label for="directrelay-key-label" style="font-size: 14px;"><?php esc_html_e( 'Label Name', 'directrelay-automation-bridge-for-n8n' ); ?> <span class="directrelay-required">*</span></label>
						<input type="text" id="directrelay-key-label" name="label" placeholder="<?php esc_attr_e( 'e.g. n8n Production', 'directrelay-automation-bridge-for-n8n' ); ?>" required class="directrelay-input" style="font-size: 14px; padding: 12px 16px;">
						<p class="directrelay-field-desc"><?php esc_html_e( 'Enter a descriptive name to easily identify where this key is configured.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
					</div>
					
					<div class="directrelay-form-group" style="margin-bottom: 24px;">
						<label for="directrelay-key-desc" style="font-size: 14px;"><?php esc_html_e( 'Purpose / Description', 'directrelay-automation-bridge-for-n8n' ); ?></label>
						<input type="text" id="directrelay-key-desc" name="description" placeholder="<?php esc_attr_e( 'e.g. Automation integration for n8n publish workflows', 'directrelay-automation-bridge-for-n8n' ); ?>" class="directrelay-input" style="font-size: 14px; padding: 12px 16px;">
						<p class="directrelay-field-desc"><?php esc_html_e( 'Optional notes or developer comments about what this API token handles.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
					</div>
					
					<div class="directrelay-form-group">
						<label for="directrelay-key-agent-role" style="font-size: 14px;"><?php esc_html_e( 'AI Agent Role Persona', 'directrelay-automation-bridge-for-n8n' ); ?></label>
						<select id="directrelay-key-agent-role" name="agent_role" class="directrelay-input" style="font-size: 14px; padding: 10px 14px; margin-bottom: 6px;">
							<option value="full_access"><?php esc_html_e( 'Full Access Key (Standard)', 'directrelay-automation-bridge-for-n8n' ); ?></option>
							<option value="content_agent"><?php esc_html_e( '🤖 AI Content Agent (Drafts Only, No Direct Publish/Delete)', 'directrelay-automation-bridge-for-n8n' ); ?></option>
							<option value="seo_agent"><?php esc_html_e( '🔍 AI SEO Agent (SEO Meta Only, No Post Creation/Publish)', 'directrelay-automation-bridge-for-n8n' ); ?></option>
							<option value="publishing_agent"><?php esc_html_e( '📢 AI Publishing Agent (Publish & Schedule Approved Content)', 'directrelay-automation-bridge-for-n8n' ); ?></option>
							<option value="custom_agent"><?php esc_html_e( '⚙️ Custom Agent Profile (Custom Matrix)', 'directrelay-automation-bridge-for-n8n' ); ?></option>
						</select>
						<p class="directrelay-field-desc"><?php esc_html_e( 'Enforce identity boundaries. Restrict AI agents from performing destructive actions or touching unpermitted endpoints.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
					</div>

					<div class="directrelay-form-group">
						<label style="font-size: 14px;"><?php esc_html_e( 'Target Environment', 'directrelay-automation-bridge-for-n8n' ); ?></label>
						<input type="hidden" id="directrelay-key-env" name="environment" value="production">
						<div class="directrelay-env-selector-grid">
							<div class="directrelay-env-card active" data-env="production">
								<div class="directrelay-env-icon" style="color:var(--directrelay-green);">🚀</div>
								<span class="directrelay-env-card-title"><?php esc_html_e( 'Production', 'directrelay-automation-bridge-for-n8n' ); ?></span>
								<p class="directrelay-env-card-desc"><?php esc_html_e( 'Live public website', 'directrelay-automation-bridge-for-n8n' ); ?></p>
							</div>
							<div class="directrelay-env-card" data-env="staging">
								<div class="directrelay-env-icon" style="color:var(--directrelay-yellow);">🧪</div>
								<span class="directrelay-env-card-title"><?php esc_html_e( 'Staging', 'directrelay-automation-bridge-for-n8n' ); ?></span>
								<p class="directrelay-env-card-desc"><?php esc_html_e( 'Pre-release sandbox', 'directrelay-automation-bridge-for-n8n' ); ?></p>
							</div>
							<div class="directrelay-env-card" data-env="development">
								<div class="directrelay-env-icon" style="color:var(--directrelay-blue);">💻</div>
								<span class="directrelay-env-card-title"><?php esc_html_e( 'Development', 'directrelay-automation-bridge-for-n8n' ); ?></span>
								<p class="directrelay-env-card-desc"><?php esc_html_e( 'Local building node', 'directrelay-automation-bridge-for-n8n' ); ?></p>
							</div>
						</div>
						<p class="directrelay-field-desc"><?php esc_html_e( 'Select the lifecycle state. This helps filter hits and analytics later.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
					</div>
				</div>
			</div>

			<!-- Step 2: Security & Governance Limits -->
			<div class="directrelay-wizard-step-panel" id="directrelay-step-panel-2">
				<div class="directrelay-wizard-step-panel-inner">
					<div class="directrelay-form-group" style="margin-bottom: 20px;">
						<label for="directrelay-key-daily-limit" style="font-size: 14px;"><?php esc_html_e( 'Daily Post Limit (Velocity Cap)', 'directrelay-automation-bridge-for-n8n' ); ?></label>
						<input type="number" id="directrelay-key-daily-limit" name="daily_limit" class="directrelay-input" placeholder="0" min="0" max="10000" style="font-size: 14px; padding: 10px 14px;">
						<p class="directrelay-field-desc"><?php esc_html_e( 'Stored with this key for guardrail use. The free plugin imposes no usage limits; enforcement requires the DirectRelay add-on plugin.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
					</div>

					<div class="directrelay-form-group" style="margin-bottom: 20px;">
						<label style="display: flex; align-items: center; gap: 8px; font-weight: 600; font-size: 14px; color: #1e293b; cursor: pointer;">
							<input type="checkbox" name="require_approval" value="1">
							<?php esc_html_e( 'Enforce Human Approval Gateway', 'directrelay-automation-bridge-for-n8n' ); ?>
						</label>
						<p class="directrelay-field-desc"><?php esc_html_e( 'All posts submitted by this key will be held as pending drafts and require human review before publishing.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
					</div>

					<div class="directrelay-form-group" style="margin-bottom: 20px;">
						<label style="display: flex; align-items: center; gap: 8px; font-weight: 600; font-size: 14px; color: #1e293b; cursor: pointer;">
							<input type="checkbox" name="restrict_own_posts" value="1">
							<?php esc_html_e( 'Post Ownership Isolation', 'directrelay-automation-bridge-for-n8n' ); ?>
						</label>
						<p class="directrelay-field-desc"><?php esc_html_e( 'Restrict this agent to only modify or update posts originally created by this specific API key.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
					</div>

					<div class="directrelay-form-group" style="margin-bottom: 24px;">
						<label for="directrelay-key-expires" style="font-size: 14px;"><?php esc_html_e( 'Expiration Date', 'directrelay-automation-bridge-for-n8n' ); ?></label>
						<input type="datetime-local" id="directrelay-key-expires" name="expires_at" class="directrelay-input" style="font-size: 14px; padding: 12px 16px;">
						<p class="directrelay-field-desc"><?php esc_html_e( 'Configure when this token automatically expires. Leave blank to keep it active indefinitely.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
					</div>

					<div class="directrelay-form-group">
						<label for="directrelay-key-ip" style="font-size: 14px;"><?php esc_html_e( 'IP Restriction / Whitelist', 'directrelay-automation-bridge-for-n8n' ); ?></label>
						<textarea id="directrelay-key-ip" name="ip_whitelist" rows="3" class="directrelay-input directrelay-textarea" placeholder="<?php esc_attr_e( "203.0.113.0/24\n198.51.100.42", 'directrelay-automation-bridge-for-n8n' ); ?>" style="font-size: 13px; line-height: 1.5;"></textarea>
						<p class="directrelay-field-desc"><?php esc_html_e( 'Protect this key. Enter permitted caller IPs or CIDR networks (one per line).', 'directrelay-automation-bridge-for-n8n' ); ?></p>
					</div>
				</div>
			</div>

			<!-- Step 3: Permissions -->
			<div class="directrelay-wizard-step-panel" id="directrelay-step-panel-3">
				<div class="directrelay-wizard-step-panel-inner wide">
					<!-- Scope Presets -->
					<div class="directrelay-form-group" style="margin-bottom: 28px;">
						<label style="font-size: 14px;"><?php esc_html_e( 'Role Templates', 'directrelay-automation-bridge-for-n8n' ); ?></label>
						<div class="directrelay-preset-cards">
							<button type="button" class="directrelay-preset-btn directrelay-preset-card" data-preset="readonly">
								<div class="directrelay-preset-card-icon">
									<span class="dashicons dashicons-visibility" style="font-size:20px;width:20px;height:20px;line-height:20px;"></span>
								</div>
								<span class="directrelay-preset-card-title"><?php esc_html_e( 'Read Only', 'directrelay-automation-bridge-for-n8n' ); ?></span>
								<p class="directrelay-preset-card-desc"><?php esc_html_e( 'Fetch posts and monitor system status safely. Best for reporting dashboards.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
							</button>
							<button type="button" class="directrelay-preset-btn directrelay-preset-card active" data-preset="writer">
								<div class="directrelay-preset-card-icon">
									<span class="dashicons dashicons-edit" style="font-size:20px;width:20px;height:20px;line-height:20px;"></span>
								</div>
								<span class="directrelay-preset-card-title"><?php esc_html_e( 'Content Writer', 'directrelay-automation-bridge-for-n8n' ); ?></span>
								<p class="directrelay-preset-card-desc"><?php esc_html_e( 'Publish content, static pages, media attachments, and update Yoast/Rank Math fields.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
							</button>
							<button type="button" class="directrelay-preset-btn directrelay-preset-card" data-preset="full_access">
								<div class="directrelay-preset-card-icon">
									<span class="dashicons dashicons-admin-tools" style="font-size:20px;width:20px;height:20px;line-height:20px;"></span>
								</div>
								<span class="directrelay-preset-card-title"><?php esc_html_e( 'Full Access', 'directrelay-automation-bridge-for-n8n' ); ?></span>
								<p class="directrelay-preset-card-desc"><?php esc_html_e( 'Administrative authority. Deactivate/rotate keys, configure webhooks, and execute bulk tasks.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
							</button>
						</div>
					</div>

					<!-- Permissions Grid -->
					<div class="directrelay-form-group">
						<label style="font-size: 14px;"><?php esc_html_e( 'Custom Permissions', 'directrelay-automation-bridge-for-n8n' ); ?></label>
						<div class="directrelay-scopes-rich-list">
							<?php
							$directrelay_scope_details = array(
								'posts:read'       => array( 'title' => 'posts:read', 'desc' => __( 'Read posts, titles, and metadata', 'directrelay-automation-bridge-for-n8n' ) ),
								'posts:write'      => array( 'title' => 'posts:write', 'desc' => __( 'Create and edit posts', 'directrelay-automation-bridge-for-n8n' ) ),
								'posts:delete'     => array( 'title' => 'posts:delete', 'desc' => __( 'Delete posts permanently', 'directrelay-automation-bridge-for-n8n' ) ),
								'posts:publish'    => array( 'title' => 'posts:publish', 'desc' => __( 'Publish posts directly', 'directrelay-automation-bridge-for-n8n' ) ),
								'pages:read'       => array( 'title' => 'pages:read', 'desc' => __( 'View page details and structure', 'directrelay-automation-bridge-for-n8n' ) ),
								'pages:write'      => array( 'title' => 'pages:write', 'desc' => __( 'Create and edit static pages', 'directrelay-automation-bridge-for-n8n' ) ),
								'pages:delete'     => array( 'title' => 'pages:delete', 'desc' => __( 'Delete static pages', 'directrelay-automation-bridge-for-n8n' ) ),
								'seo:read'         => array( 'title' => 'seo:read', 'desc' => __( 'Read Yoast/Rank Math SEO data', 'directrelay-automation-bridge-for-n8n' ) ),
								'seo:write'        => array( 'title' => 'seo:write', 'desc' => __( 'Update keywords, titles, and descriptions', 'directrelay-automation-bridge-for-n8n' ) ),
								'media:read'       => array( 'title' => 'media:read', 'desc' => __( 'List media library attachments', 'directrelay-automation-bridge-for-n8n' ) ),
								'media:write'      => array( 'title' => 'media:write', 'desc' => __( 'Upload base64 files or URL sideload', 'directrelay-automation-bridge-for-n8n' ) ),
								'media:delete'     => array( 'title' => 'media:delete', 'desc' => __( 'Remove media library items', 'directrelay-automation-bridge-for-n8n' ) ),
								'taxonomy:read'    => array( 'title' => 'taxonomy:read', 'desc' => __( 'View categories and tags', 'directrelay-automation-bridge-for-n8n' ) ),
								'taxonomy:write'   => array( 'title' => 'taxonomy:write', 'desc' => __( 'Create categories and tags', 'directrelay-automation-bridge-for-n8n' ) ),
								'bulk:write'       => array( 'title' => 'bulk:write', 'desc' => __( 'Publish multiple items in one request', 'directrelay-automation-bridge-for-n8n' ) ),
								'webhooks:read'    => array( 'title' => 'webhooks:read', 'desc' => __( 'View configured outgoing webhooks', 'directrelay-automation-bridge-for-n8n' ) ),
								'webhooks:write'   => array( 'title' => 'webhooks:write', 'desc' => __( 'Create, edit, or test webhooks', 'directrelay-automation-bridge-for-n8n' ) ),
								'analytics:read'   => array( 'title' => 'analytics:read', 'desc' => __( 'Read traffic & request stats', 'directrelay-automation-bridge-for-n8n' ) ),
								'keys:read'        => array( 'title' => 'keys:read', 'desc' => __( 'View existing API keys', 'directrelay-automation-bridge-for-n8n' ) ),
								'keys:write'       => array( 'title' => 'keys:write', 'desc' => __( 'Generate new API keys', 'directrelay-automation-bridge-for-n8n' ) ),
								'keys:rotate'      => array( 'title' => 'keys:rotate', 'desc' => __( 'Rotate key hashes securely', 'directrelay-automation-bridge-for-n8n' ) ),
								'system:read'      => array( 'title' => 'system:read', 'desc' => __( 'Read server and cron health', 'directrelay-automation-bridge-for-n8n' ) ),
							);
							
							$directrelay_groups = array(
								__( 'Posts', 'directrelay-automation-bridge-for-n8n' )    => array( 'posts:read', 'posts:write', 'posts:delete', 'posts:publish' ),
								__( 'Pages', 'directrelay-automation-bridge-for-n8n' )    => array( 'pages:read', 'pages:write', 'pages:delete' ),
								__( 'SEO Support', 'directrelay-automation-bridge-for-n8n' ) => array( 'seo:read', 'seo:write' ),
								__( 'Media', 'directrelay-automation-bridge-for-n8n' )    => array( 'media:read', 'media:write', 'media:delete' ),
								__( 'Taxonomy', 'directrelay-automation-bridge-for-n8n' ) => array( 'taxonomy:read', 'taxonomy:write' ),
								__( 'Advanced Features', 'directrelay-automation-bridge-for-n8n' ) => array( 'bulk:write', 'webhooks:read', 'webhooks:write', 'analytics:read', 'keys:read', 'keys:write', 'keys:rotate', 'system:read' ),
							);
							
							$directrelay_default_writer = \DirectRelay\Api_Auth::PRESET_SCOPES['writer'];
							foreach ( $directrelay_groups as $directrelay_group => $directrelay_scopes ) : ?>
							<div class="directrelay-scope-category-card">
								<div class="directrelay-scope-category-header">
									<span class="dashicons dashicons-admin-generic" style="font-size:13px;width:13px;height:13px;line-height:13px;margin-top:1px;"></span>
									<?php echo esc_html( $directrelay_group ); ?>
									<button type="button" class="directrelay-scope-quick-action directrelay-toggle-all-group" style="font-size:11px;font-weight:600;"><?php esc_html_e( 'Toggle All', 'directrelay-automation-bridge-for-n8n' ); ?></button>
								</div>
								<div class="directrelay-scope-items-container">
									<?php foreach ( $directrelay_scopes as $directrelay_scope ) : 
										$directrelay_sc_info = $directrelay_scope_details[ $directrelay_scope ] ?? [ 'title' => $directrelay_scope, 'desc' => '' ];
									?>
									<label class="directrelay-scope-item-rich">
										<input type="checkbox" name="scopes[]" value="<?php echo esc_attr( $directrelay_scope ); ?>" <?php echo in_array( $directrelay_scope, $directrelay_default_writer, true ) ? 'checked' : ''; ?>>
										<div class="directrelay-scope-item-content">
											<span class="directrelay-scope-item-title"><?php echo esc_html( $directrelay_sc_info['title'] ); ?></span>
											<?php if ( ! empty( $directrelay_sc_info['desc'] ) ) : ?>
												<span class="directrelay-scope-item-desc"><?php echo esc_html( $directrelay_sc_info['desc'] ); ?></span>
											<?php endif; ?>
										</div>
									</label>
									<?php endforeach; ?>
								</div>
							</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			</div>

			<!-- Wizard Navigation -->
			<div class="directrelay-wizard-navigation">
				<div>
					<button type="button" class="directrelay-btn directrelay-btn-secondary" id="directrelay-wizard-prev" style="display:none;">
						<span class="dashicons dashicons-arrow-left-alt2" style="font-size:14px;width:14px;height:14px;line-height:14px;"></span>
						<?php esc_html_e( 'Back', 'directrelay-automation-bridge-for-n8n' ); ?>
					</button>
				</div>
				<div>
					<button type="button" class="directrelay-btn directrelay-btn-primary" id="directrelay-wizard-next">
						<?php esc_html_e( 'Next', 'directrelay-automation-bridge-for-n8n' ); ?>
						<span class="dashicons dashicons-arrow-right-alt2" style="font-size:14px;width:14px;height:14px;line-height:14px;"></span>
					</button>
					<button type="submit" class="directrelay-btn directrelay-btn-primary button button-primary" id="directrelay-create-key-btn" style="display:none;">
						<span class="dashicons dashicons-plus-alt2" style="font-size:16px;width:16px;height:16px;line-height:16px;"></span>
						<?php esc_html_e( 'Generate API Key', 'directrelay-automation-bridge-for-n8n' ); ?>
					</button>
				</div>
			</div>
		</form>

		<!-- Key Created Result Box -->
		<div id="directrelay-new-key-result" style="display:none" class="directrelay-new-key-box directrelay-credentials-lockbox">
			<div class="directrelay-new-key-header">
				<span class="dashicons dashicons-yes-alt" style="font-size:22px;width:22px;height:22px;line-height:22px;"></span>
				<strong><?php esc_html_e( 'API Key Created Successfully', 'directrelay-automation-bridge-for-n8n' ); ?></strong>
			</div>
			<div class="directrelay-key-display-row">
				<div class="directrelay-key-label-mini">
					<span class="dashicons dashicons-admin-network" style="font-size:14px;width:14px;height:14px;line-height:14px;color:var(--directrelay-green);"></span>
					<?php esc_html_e( 'API Key:', 'directrelay-automation-bridge-for-n8n' ); ?>
				</div>
				<code id="directrelay-raw-key"></code>
				<button class="directrelay-btn directrelay-btn-ghost directrelay-copy-btn" data-target="directrelay-raw-key" aria-label="<?php esc_attr_e( 'Copy API key', 'directrelay-automation-bridge-for-n8n' ); ?>">
					<span class="dashicons dashicons-clipboard" style="font-size:14px;width:14px;height:14px;line-height:14px;"></span>
					<?php esc_html_e( 'Copy', 'directrelay-automation-bridge-for-n8n' ); ?>
				</button>
			</div>
			<div class="directrelay-key-display-row" style="margin-top:8px;">
				<div class="directrelay-key-label-mini">
					<span class="dashicons dashicons-rest-api" style="font-size:14px;width:14px;height:14px;line-height:14px;color:var(--directrelay-green);"></span>
					<?php esc_html_e( 'n8n Header Value:', 'directrelay-automation-bridge-for-n8n' ); ?>
				</div>
				<code id="directrelay-n8n-val"></code>
				<button class="directrelay-btn directrelay-btn-ghost directrelay-copy-btn" data-target="directrelay-n8n-val" aria-label="<?php esc_attr_e( 'Copy n8n header value', 'directrelay-automation-bridge-for-n8n' ); ?>">
					<span class="dashicons dashicons-clipboard" style="font-size:14px;width:14px;height:14px;line-height:14px;"></span>
					<?php esc_html_e( 'Copy', 'directrelay-automation-bridge-for-n8n' ); ?>
				</button>
			</div>
			<div class="directrelay-key-warning-bar">
				<span class="dashicons dashicons-warning" style="font-size:16px;width:16px;height:16px;line-height:16px;"></span>
				<?php esc_html_e( 'This key will not be shown again. Make sure you have copied it before dismissing.', 'directrelay-automation-bridge-for-n8n' ); ?>
			</div>
			<div class="directrelay-key-dismiss-area">
				<label class="directrelay-key-confirm-label">
					<input type="checkbox" id="directrelay-confirm-saved">
					<?php esc_html_e( 'I have saved this key securely', 'directrelay-automation-bridge-for-n8n' ); ?>
				</label>
				<button class="directrelay-btn directrelay-btn-secondary" id="directrelay-dismiss-key" disabled>
					<span class="dashicons dashicons-yes" style="font-size:16px;width:16px;height:16px;line-height:16px;"></span>
					<?php esc_html_e( 'Dismiss', 'directrelay-automation-bridge-for-n8n' ); ?>
				</button>
			</div>
		</div>
	</div>
</div>

<!-- ── All API Keys Card ───────────────────────────────────────── -->
<div class="directrelay-card">
	<div class="directrelay-card-header">
		<h3>
			<span class="dashicons dashicons-list-view" style="color:var(--directrelay-primary);font-size:20px;width:20px;height:20px;"></span>
			<?php esc_html_e( 'All API Keys', 'directrelay-automation-bridge-for-n8n' ); ?>
		</h3>
		<div class="directrelay-keys-toolbar">
			<div class="directrelay-search-box">
				<span class="dashicons dashicons-search directrelay-search-icon"></span>
				<input type="text" id="directrelay-key-search" class="directrelay-input" placeholder="<?php esc_attr_e( 'Search keys…', 'directrelay-automation-bridge-for-n8n' ); ?>" aria-label="<?php esc_attr_e( 'Search API keys', 'directrelay-automation-bridge-for-n8n' ); ?>">
			</div>
			<label class="directrelay-toggle-wrap">
				<input type="checkbox" id="directrelay-show-revoked">
				<?php esc_html_e( 'Show revoked', 'directrelay-automation-bridge-for-n8n' ); ?>
			</label>
		</div>
	</div>

	<?php if ( empty( $directrelay_keys ) ) : ?>
	<!-- Empty State -->
	<div class="directrelay-empty-state">
		<div class="directrelay-empty-icon">
			<span class="dashicons dashicons-admin-network"></span>
		</div>
		<h4><?php esc_html_e( 'No API keys yet', 'directrelay-automation-bridge-for-n8n' ); ?></h4>
		<p><?php esc_html_e( 'Create your first API key to connect n8n or other automation tools to your WordPress site.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
		<a href="#directrelay-create-key-card" class="directrelay-btn directrelay-btn-primary button button-primary" style="margin-top:8px;">
			<span class="dashicons dashicons-plus-alt2" style="font-size:16px;width:16px;height:16px;line-height:16px;"></span>
			<?php esc_html_e( 'Create Your First Key', 'directrelay-automation-bridge-for-n8n' ); ?>
		</a>
	</div>
	<?php else : ?>
	<div class="directrelay-table-responsive">
		<table class="directrelay-table directrelay-keys-table widefat wp-list-table" role="table">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Key', 'directrelay-automation-bridge-for-n8n' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Label', 'directrelay-automation-bridge-for-n8n' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Environment', 'directrelay-automation-bridge-for-n8n' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Scopes', 'directrelay-automation-bridge-for-n8n' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Requests', 'directrelay-automation-bridge-for-n8n' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Last Used', 'directrelay-automation-bridge-for-n8n' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Created', 'directrelay-automation-bridge-for-n8n' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Status', 'directrelay-automation-bridge-for-n8n' ); ?></th>
					<th scope="col" class="directrelay-col-actions"><?php esc_html_e( 'Actions', 'directrelay-automation-bridge-for-n8n' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $directrelay_keys as $directrelay_k ) :
				$directrelay_scopes_arr = json_decode( $directrelay_k['scopes'] ?? '[]', true ) ?: array();
				$directrelay_is_expired = $directrelay_k['expires_at'] && strtotime( $directrelay_k['expires_at'] ) <= time();
				$directrelay_is_active  = ! $directrelay_k['revoked'] && ! $directrelay_is_expired;
			?>
			<tr class="directrelay-key-row <?php echo esc_attr( $directrelay_k['revoked'] ? 'directrelay-row-revoked' : '' ); ?>" data-revoked="<?php echo (int) $directrelay_k['revoked']; ?>" data-label="<?php echo esc_attr( strtolower( $directrelay_k['label'] ) ); ?>">
				<td>
					<code class="directrelay-key-prefix" title="<?php esc_attr_e( 'Key prefix (first 12 characters)', 'directrelay-automation-bridge-for-n8n' ); ?>"><?php echo esc_html( $directrelay_k['key_prefix'] ); ?></code>
				</td>
				<td>
					<strong class="directrelay-key-label-text"><?php echo esc_html( $directrelay_k['label'] ); ?></strong>
					<?php if ( ! empty( $directrelay_k['description'] ) ) : ?>
						<br><span class="directrelay-key-description"><?php echo esc_html( mb_strimwidth( $directrelay_k['description'], 0, 60, '…' ) ); ?></span>
					<?php endif; ?>
				</td>
				<td>
					<span class="directrelay-env-badge directrelay-env-<?php echo esc_attr( $directrelay_k['environment'] ); ?>">
						<?php echo esc_html( ucfirst( $directrelay_k['environment'] ) ); ?>
					</span>
				</td>
				<td>
					<div class="directrelay-scopes-compact">
						<?php
						if ( empty( $directrelay_scopes_arr ) ) {
							printf( '<span class="directrelay-scope-tag directrelay-scope-all">%s</span>', esc_html__( 'All Scopes', 'directrelay-automation-bridge-for-n8n' ) );
						} else {
							foreach ( array_slice( $directrelay_scopes_arr, 0, 3 ) as $directrelay_s ) {
								printf( '<span class="directrelay-scope-tag">%s</span>', esc_html( $directrelay_s ) );
							}
							if ( count( $directrelay_scopes_arr ) > 3 ) {
								printf(
									'<span class="directrelay-scope-more" title="%s">+%d</span>',
									esc_attr( implode( ', ', array_slice( $directrelay_scopes_arr, 3 ) ) ),
									count( $directrelay_scopes_arr ) - 3
								);
							}
						}
						?>
					</div>
				</td>
				<td>
					<span class="directrelay-requests-count"><?php echo esc_html( number_format( (int) $directrelay_k['total_requests'] ) ); ?></span>
				</td>
				<td>
					<?php if ( $directrelay_k['last_used_at'] ) : ?>
						<span class="directrelay-last-used" title="<?php echo esc_attr( $directrelay_k['last_used_at'] ); ?>">
							<?php
							/* translators: %s: human time diff string */
							printf( esc_html__( '%s ago', 'directrelay-automation-bridge-for-n8n' ), esc_html( human_time_diff( strtotime( $directrelay_k['last_used_at'] ) ) ) );
							?>
						</span>
						<?php if ( ! empty( $directrelay_k['last_used_ip'] ) ) : ?>
							<br><span class="directrelay-last-ip"><?php echo esc_html( $directrelay_k['last_used_ip'] ); ?></span>
						<?php endif; ?>
					<?php else : ?>
						<span class="directrelay-never-used"><?php esc_html_e( 'Never', 'directrelay-automation-bridge-for-n8n' ); ?></span>
					<?php endif; ?>
				</td>
				<td>
					<span class="directrelay-created-date" title="<?php echo esc_attr( $directrelay_k['created_at'] ); ?>">
						<?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $directrelay_k['created_at'] ) ) ); ?>
					</span>
				</td>
				<td>
					<?php if ( $directrelay_k['revoked'] ) : ?>
						<span class="directrelay-badge directrelay-badge-revoked"><?php esc_html_e( 'Revoked', 'directrelay-automation-bridge-for-n8n' ); ?></span>
					<?php elseif ( $directrelay_is_expired ) : ?>
						<span class="directrelay-badge directrelay-badge-expired"><?php esc_html_e( 'Expired', 'directrelay-automation-bridge-for-n8n' ); ?></span>
					<?php else : ?>
						<span class="directrelay-badge directrelay-badge-active"><?php esc_html_e( 'Active', 'directrelay-automation-bridge-for-n8n' ); ?></span>
					<?php endif; ?>
				</td>
				<td class="directrelay-col-actions">
					<?php if ( ! $directrelay_k['revoked'] ) : ?>
					<div class="directrelay-row-actions">
						<button class="directrelay-btn directrelay-btn-ghost-sm directrelay-rotate-btn" data-id="<?php echo (int) $directrelay_k['id']; ?>" data-label="<?php echo esc_attr( $directrelay_k['label'] ); ?>" title="<?php esc_attr_e( 'Generate new secret, keep same ID and scopes', 'directrelay-automation-bridge-for-n8n' ); ?>" aria-label="<?php
							/* translators: %s: key label */
							printf( esc_attr__( 'Rotate key %s', 'directrelay-automation-bridge-for-n8n' ), esc_attr( $directrelay_k['label'] ) );
						?>">
							<span class="dashicons dashicons-update" style="font-size:14px;width:14px;height:14px;line-height:14px;"></span>
							<?php esc_html_e( 'Rotate', 'directrelay-automation-bridge-for-n8n' ); ?>
						</button>
						<button class="directrelay-btn directrelay-btn-danger-sm directrelay-revoke-btn" data-id="<?php echo (int) $directrelay_k['id']; ?>" data-label="<?php echo esc_attr( $directrelay_k['label'] ); ?>" aria-label="<?php
							/* translators: %s: key label */
							printf( esc_attr__( 'Revoke key %s', 'directrelay-automation-bridge-for-n8n' ), esc_attr( $directrelay_k['label'] ) );
						?>">
							<span class="dashicons dashicons-no" style="font-size:14px;width:14px;height:14px;line-height:14px;"></span>
							<?php esc_html_e( 'Revoke', 'directrelay-automation-bridge-for-n8n' ); ?>
						</button>
					</div>
					<?php else : ?>
						<span class="directrelay-revoked-label"><?php esc_html_e( '—', 'directrelay-automation-bridge-for-n8n' ); ?></span>
					<?php endif; ?>
				</td>
			</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<?php endif; ?>
</div>

</div>