<?php defined( 'ABSPATH' ) || exit; ?>
<div class="directrelay-wrap">
<div class="directrelay-header">
    <div class="directrelay-header-left">
        <h1 class="directrelay-page-title"><?php esc_html_e( 'Activity Log', 'directrelay-automation-bridge-for-n8n'); ?></h1>
        <span class="directrelay-badge-pill"><?php
                /* translators: %d: number of log entries */
                printf( esc_html__( '%d entries', 'directrelay-automation-bridge-for-n8n'), count( $directrelay_logs ) );
            ?></span>
    </div>
    <div class="directrelay-header-right" style="display:flex;gap:10px">
        <a href="<?php echo esc_url( admin_url( 'admin-ajax.php?action=directrelay_export_logs&format=csv&nonce=' . wp_create_nonce( 'directrelay_admin' ) ) ); ?>" class="directrelay-btn directrelay-btn-ghost button"><?php esc_html_e( 'Export CSV', 'directrelay-automation-bridge-for-n8n'); ?></a>
        <a href="<?php echo esc_url( admin_url( 'admin-ajax.php?action=directrelay_export_logs&format=json&nonce=' . wp_create_nonce( 'directrelay_admin' ) ) ); ?>" class="directrelay-btn directrelay-btn-ghost button"><?php esc_html_e( 'Export JSON', 'directrelay-automation-bridge-for-n8n'); ?></a>
        <button id="directrelay-clear-logs-btn" class="directrelay-btn directrelay-btn-danger button"><?php esc_html_e( 'Clear All Logs', 'directrelay-automation-bridge-for-n8n'); ?></button>
    </div>
</div>
<div class="directrelay-card" style="padding:14px 20px;margin-bottom:16px">
    <form method="get" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
        <?php wp_nonce_field( 'directrelay_logs_filter', '_an_nonce' ); ?>
        <input type="hidden" name="page" value="directrelay-logs">
        <?php
        $directrelay_status_filter = 0;
        if ( isset( $_GET['_an_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_an_nonce'] ) ), 'directrelay_logs_filter' ) ) {
            $directrelay_status_filter = isset( $_GET['status'] ) ? absint( wp_unslash( $_GET['status'] ) ) : 0;
        }
        ?>
        <select name="status" class="directrelay-select" style="max-width:160px;padding:7px 10px;font-size:12px" onchange="this.form.submit()">
            <option value=""><?php esc_html_e( 'All Statuses', 'directrelay-automation-bridge-for-n8n'); ?></option>
            <?php foreach ( array( 200, 201, 400, 401, 403, 404, 429, 500 ) as $directrelay_s ) : ?>
            <option value="<?php echo esc_attr( $directrelay_s ); ?>" <?php selected( $directrelay_status_filter, $directrelay_s ); ?>>HTTP <?php echo esc_html( $directrelay_s ); ?></option>
            <?php endforeach; ?>
        </select>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=directrelay-logs' ) ); ?>" class="directrelay-btn directrelay-btn-ghost button" style="padding:6px 12px;font-size:12px"><?php esc_html_e( 'Clear', 'directrelay-automation-bridge-for-n8n'); ?></a>
    </form>
</div>
<div class="directrelay-card" style="padding:0;overflow:hidden">
    <table class="directrelay-table directrelay-log-table widefat wp-list-table">
        <thead><tr>
            <th><?php esc_html_e( 'Time (UTC)', 'directrelay-automation-bridge-for-n8n'); ?></th>
            <th><?php esc_html_e( 'Key', 'directrelay-automation-bridge-for-n8n'); ?></th>
            <th><?php esc_html_e( 'Action', 'directrelay-automation-bridge-for-n8n'); ?></th>
            <th><?php esc_html_e( 'Object', 'directrelay-automation-bridge-for-n8n'); ?></th>
            <th><?php esc_html_e( 'Method', 'directrelay-automation-bridge-for-n8n'); ?></th>
            <th><?php esc_html_e( 'Status', 'directrelay-automation-bridge-for-n8n'); ?></th>
            <th><?php esc_html_e( 'Duration', 'directrelay-automation-bridge-for-n8n'); ?></th>
            <th><?php esc_html_e( 'IP', 'directrelay-automation-bridge-for-n8n'); ?></th>
        </tr></thead>
        <tbody>
        <?php if ( empty( $directrelay_logs ) ) : ?>
            <tr><td colspan="8" class="directrelay-empty-cell"><?php esc_html_e( 'No log entries.', 'directrelay-automation-bridge-for-n8n'); ?></td></tr>
        <?php else : ?>
            <?php
            foreach ( $directrelay_logs as $directrelay_log ) :
                $directrelay_st  = (int) $directrelay_log['http_status'];
                $directrelay_cls = $directrelay_st >= 500 ? 'directrelay-5xx' : ( $directrelay_st >= 400 ? 'directrelay-4xx' : ( $directrelay_st >= 300 ? 'directrelay-3xx' : 'directrelay-2xx' ) );
            ?>
            <tr>
                <td><small class="directrelay-mono"><?php echo esc_html( substr( $directrelay_log['created_at'], 0, 19 ) ); ?></small></td>
                <td><?php if ( $directrelay_log['key_id'] ) : ?><span class="directrelay-mono directrelay-muted">#<?php echo esc_html( $directrelay_log['key_id'] ); ?></span><?php endif; ?></td>
                <td><code class="directrelay-action-code"><?php echo esc_html( $directrelay_log['action'] ); ?></code></td>
                <td><?php
                if ( $directrelay_log['object_type'] && $directrelay_log['object_id'] ) :
                    $directrelay_el = get_edit_post_link( (int) $directrelay_log['object_id'] );
                    if ( $directrelay_el ) {
                        printf( '<a href="%s" target="_blank" class="directrelay-link">%s</a>', esc_url( $directrelay_el ), esc_html( $directrelay_log['object_type'] . ' #' . $directrelay_log['object_id'] ) );
                    } else {
                        printf( '<span class="directrelay-muted">%s</span>', esc_html( $directrelay_log['object_type'] . ' #' . $directrelay_log['object_id'] ) );
                    }
                endif;
                ?></td>
                <td><span class="directrelay-method directrelay-method-<?php echo esc_attr( strtolower( $directrelay_log['method'] ) ); ?>"><?php echo esc_html( $directrelay_log['method'] ); ?></span></td>
                <td><span class="directrelay-http-status <?php echo esc_attr( $directrelay_cls ); ?>"><?php echo esc_html( $directrelay_st ?: '' ); ?></span></td>
                <td><small><?php echo $directrelay_log['duration_ms'] ? esc_html( (int) $directrelay_log['duration_ms'] . 'ms' ) : ''; ?></small></td>
                <td><small class="directrelay-mono directrelay-muted"><?php echo esc_html( $directrelay_log['ip_address'] ); ?></small></td>
            </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
    <div style="display:flex;gap:8px;padding:14px 20px;border-top:1px solid var(--directrelay-border)">
        <?php
        $directrelay_off = 0;
        if ( isset( $_GET['_an_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_an_nonce'] ) ), 'directrelay_logs_filter' ) ) {
            $directrelay_off = isset( $_GET['offset'] ) ? absint( wp_unslash( $_GET['offset'] ) ) : 0;
        }
        ?>
        <?php if ( $directrelay_off > 0 ) : ?><a href="<?php echo esc_url( add_query_arg( 'offset', max( 0, $directrelay_off - 100 ) ) ); ?>" class="directrelay-btn directrelay-btn-ghost" style="font-size:12px"><?php esc_html_e( 'Prev', 'directrelay-automation-bridge-for-n8n'); ?></a><?php endif; ?>
        <?php if ( count( $directrelay_logs ) === 100 ) : ?><a href="<?php echo esc_url( add_query_arg( 'offset', $directrelay_off + 100 ) ); ?>" class="directrelay-btn directrelay-btn-ghost" style="font-size:12px"><?php esc_html_e( 'Next', 'directrelay-automation-bridge-for-n8n'); ?></a><?php endif; ?>
    </div>
</div>
</div>

