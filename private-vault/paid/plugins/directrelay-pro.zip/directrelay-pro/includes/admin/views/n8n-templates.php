<?php
defined( 'ABSPATH' ) || exit;

/**
 * n8n starter workflow templates.
 *
 * The free plugin ships one canonical starter template that uses the
 * free REST surface only (POST /posts, GET /status, /keys). All other
 * templates are contributed by the directrelay-pro plugin via the
 * `directrelay_ext_templates` filter. The add-on plugin owns the bulk
 * publisher, AI writer, universal schema, and approval templates.
 *
 * @package DirectRelay
 * @since   5.1.0
 */

/**
 * Filters the list of additional n8n starter templates.
 *
 * The free plugin ships a single canonical template. add-on users see
 * additional templates contributed by the directrelay-pro plugin.
 *
 * Each entry is an associative array:
 *  - id        string  Unique slug used for the textarea target id.
 *  - title     string  Card heading.
 *  - icon      string  Optional emoji or short label.
 *  - body      string  Short description rendered in the card.
 *  - preview   array   List of node labels rendered as preview chips.
 *  - workflow  string  Raw n8n workflow JSON, used in the copy textarea.
 *  - pro       bool    When true the card is rendered with an add-on badge.
 *
 * @since 5.1.0
 *
 * @param array $templates Array of template definitions.
 */
$directrelay_ext_templates = (array) apply_filters( 'directrelay_ext_templates', [] );
?>
<div class="directrelay-wrap">
    <div class="directrelay-header">
        <div class="directrelay-header-left">
            <h1 class="directrelay-page-title"><?php esc_html_e( 'n8n Starter Workflows', 'directrelay-automation-bridge-for-n8n' ); ?></h1>
            <p><?php esc_html_e( 'Copyable n8n workflows that target the DirectRelay free REST surface.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
        </div>
    </div>

    <div class="directrelay-grid-2">
        <div class="directrelay-card directrelay-template-card">
            <div class="directrelay-card-header">
                <h3><?php esc_html_e( 'Publish a Post via n8n', 'directrelay-automation-bridge-for-n8n' ); ?></h3>
                <button class="directrelay-btn directrelay-btn-primary button button-primary directrelay-copy-btn" data-target="tpl-publish-post"><?php esc_html_e( 'Copy Workflow', 'directrelay-automation-bridge-for-n8n' ); ?></button>
            </div>
            <div class="directrelay-card-body">
                <p><?php esc_html_e( 'The simplest possible workflow: receive a payload, POST to /posts, and you are live. Use it as a starting point or as a connectivity test.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
                <div class="directrelay-workflow-preview">
                    <span class="node webhook"><?php esc_html_e( 'Webhook', 'directrelay-automation-bridge-for-n8n' ); ?></span>
                    <span class="node http"><?php esc_html_e( 'POST /posts', 'directrelay-automation-bridge-for-n8n' ); ?></span>
                </div>
            </div>
            <textarea id="tpl-publish-post" style="display:none;">{"nodes":[{"parameters":{"httpMethod":"POST","path":"directrelay-publish","options":{}},"name":"Webhook","type":"n8n-nodes-base.webhook","typeVersion":1,"position":[250,300]},{"parameters":{"method":"POST","url":"={{$env.WP_URL}}/wp-json/directrelay/v1/posts","sendHeaders":true,"headerParameters":{"parameters":[{"name":"Authorization","value":"Bearer ={{$env.WP_API_KEY}}"}]},"sendBody":true,"specifyBody":"json","jsonBody":"={\n  \"title\": \"{{$json.body.title}}\",\n  \"content\": \"{{$json.body.content}}\",\n  \"status\": \"{{$json.body.status || 'draft'}}\",\n  \"categories\": {{$json.body.categories || []}},\n  \"tags\": {{$json.body.tags || []}}\n}","options":{}},"name":"DirectRelay","type":"n8n-nodes-base.httpRequest","typeVersion":4.1,"position":[450,300]}],"connections":{"Webhook":{"main":[[{"node":"DirectRelay","type":"main","index":0}]]}}}</textarea>
        </div>

        <div class="directrelay-card directrelay-template-card">
            <div class="directrelay-card-header">
                <h3><?php esc_html_e( 'Receive WP Webhooks in n8n', 'directrelay-automation-bridge-for-n8n' ); ?></h3>
                <button class="directrelay-btn directrelay-btn-primary button button-primary directrelay-copy-btn" data-target="tpl-receiver"><?php esc_html_e( 'Copy Workflow', 'directrelay-automation-bridge-for-n8n' ); ?></button>
            </div>
            <div class="directrelay-card-body">
                <p><?php esc_html_e( 'Catches DirectRelay event payloads when posts are created, updated, or published. Useful for syncing downstream systems.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
                <div class="directrelay-workflow-preview">
                    <span class="node webhook"><?php esc_html_e( 'Webhook', 'directrelay-automation-bridge-for-n8n' ); ?></span>
                    <span class="node set"><?php esc_html_e( 'Filter Payload', 'directrelay-automation-bridge-for-n8n' ); ?></span>
                </div>
            </div>
            <textarea id="tpl-receiver" style="display:none;">{"nodes":[{"parameters":{"httpMethod":"POST","path":"wp-webhook-sync","options":{}},"name":"Webhook","type":"n8n-nodes-base.webhook","typeVersion":1,"position":[250,300]},{"parameters":{"values":{"string":[{"name":"Title","value":"={{$json.body.post.post_title}}"},{"name":"Event","value":"={{$json.body.event}}"}],"number":[{"name":"ID","value":"={{$json.body.post.ID}}"}]},"options":{}},"name":"Set","type":"n8n-nodes-base.set","typeVersion":2,"position":[450,300]}],"connections":{"Webhook":{"main":[[{"node":"Set","type":"main","index":0}]]}}}</textarea>
        </div>
    </div>

    <?php if ( ! empty( $directrelay_ext_templates ) ) : ?>
        <h2 style="margin-top:32px"><?php esc_html_e( 'add-on Starter Library', 'directrelay-automation-bridge-for-n8n' ); ?></h2>
        <p style="color:var(--directrelay-dim)"><?php esc_html_e( 'These templates use add-on-only endpoints and ship with the DirectRelay add-on plugin plugin.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
        <div class="directrelay-grid-2">
            <?php foreach ( $directrelay_ext_templates as $directrelay_tpl ) :
                $directrelay_tpl_id       = isset( $directrelay_tpl['id'] ) ? (string) $directrelay_tpl['id'] : '';
                $directrelay_tpl_title    = isset( $directrelay_tpl['title'] ) ? (string) $directrelay_tpl['title'] : '';
                $directrelay_tpl_body     = isset( $directrelay_tpl['body'] ) ? (string) $directrelay_tpl['body'] : '';
                $directrelay_tpl_workflow = isset( $directrelay_tpl['workflow'] ) ? (string) $directrelay_tpl['workflow'] : '';
                $directrelay_tpl_previews = isset( $directrelay_tpl['preview'] ) && is_array( $directrelay_tpl['preview'] ) ? $directrelay_tpl['preview'] : [];
                $directrelay_tpl_icon     = isset( $directrelay_tpl['icon'] ) ? (string) $directrelay_tpl['icon'] : '';
                if ( '' === $directrelay_tpl_id || '' === $directrelay_tpl_workflow ) {
                    continue;
                }
                ?>
                <div class="directrelay-card directrelay-template-card" style="border-left:4px solid #7c3aed">
                    <div class="directrelay-card-header">
                        <h3>
                            <?php if ( '' !== $directrelay_tpl_icon ) : ?>
                                <span aria-hidden="true"><?php echo esc_html( $directrelay_tpl_icon ); ?></span>
                            <?php endif; ?>
                            <?php echo esc_html( $directrelay_tpl_title ); ?>
                            <span class="directrelay-badge directrelay-badge-pro" style="margin-left:8px">PRO</span>
                        </h3>
                        <button class="directrelay-btn directrelay-btn-primary button button-primary directrelay-copy-btn" data-target="tpl-<?php echo esc_attr( $directrelay_tpl_id ); ?>"><?php esc_html_e( 'Copy Workflow', 'directrelay-automation-bridge-for-n8n' ); ?></button>
                    </div>
                    <div class="directrelay-card-body">
                        <p><?php echo esc_html( $directrelay_tpl_body ); ?></p>
                        <?php if ( ! empty( $directrelay_tpl_previews ) ) : ?>
                            <div class="directrelay-workflow-preview">
                                <?php foreach ( $directrelay_tpl_previews as $directrelay_node ) : ?>
                                    <span class="node"><?php echo esc_html( $directrelay_node ); ?></span>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <textarea id="tpl-<?php echo esc_attr( $directrelay_tpl_id ); ?>" style="display:none;"><?php echo esc_textarea( $directrelay_tpl_workflow ); ?></textarea>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else : ?>
        <div class="directrelay-card" style="border-style:dashed;margin-top:24px">
            <div class="directrelay-card-body" style="font-size:14px;color:var(--directrelay-dim);">
                <p style="margin:0">
                    <?php
                    /* translators: %s: DirectRelay add-on product page URL */
                    $directrelay_ext_intro = __( 'The full starter workflow library (AI writer, bulk publisher, universal schema, approval gateway, multi-key orchestration) is available in the <a href="%s" target="_blank" rel="noopener">DirectRelay add-on</a> add-on plugin.', 'directrelay-automation-bridge-for-n8n' );
                    printf(
                        wp_kses(
                            $directrelay_ext_intro,
                            [ 'a' => [ 'href' => [], 'target' => [], 'rel' => [] ] ]
                        ),
                        esc_url( 'https://directrelay.wikiofautomation.com/directrelay-pro' )
                    );
                    ?>
                </p>
            </div>
        </div>
    <?php endif; ?>
</div>
