<?php defined( 'ABSPATH' ) || exit;
$directrelay_s      = $directrelay_settings;
$directrelay_cron   = \DirectRelay\Cron_Health::status();
$directrelay_blocks = \DirectRelay\Brute_Force::list_blocks();
$directrelay_sp     = \DirectRelay\Rankmath_Handler::active_plugin();
$directrelay_block_count = count( $directrelay_blocks );
$directrelay_compat      = isset( $directrelay_compat ) ? $directrelay_compat : \DirectRelay\Compatibility::status();
?>


<div class="directrelay-wrap" id="directrelay-settings">

<!-- Hero Banner -->
<div class="directrelay-set-hero">
    <div class="directrelay-set-hero-left">
        <h1>
            <img src="<?php echo esc_url( DIRECTRELAY_URL . 'assets/icon-256x256.png' ); ?>" alt="DirectRelay" style="width:32px;height:32px;border-radius:6px;vertical-align:middle;margin-right:8px;">
            <?php esc_html_e( 'Settings', 'directrelay-automation-bridge-for-n8n'); ?>
        </h1>
        <p><?php esc_html_e( 'Configure security, rate limiting, webhooks, and plugin behavior.', 'directrelay-automation-bridge-for-n8n'); ?></p>
    </div>
    <div class="directrelay-set-hero-right">
        <div class="directrelay-set-stat">
            <span class="directrelay-set-stat-val">v<?php echo esc_html( DIRECTRELAY_VERSION ); ?></span>
            <span class="directrelay-set-stat-label"><?php esc_html_e( 'Version', 'directrelay-automation-bridge-for-n8n'); ?></span>
        </div>
        <div class="directrelay-set-stat">
            <span class="directrelay-set-stat-val"><?php echo (int) get_option( 'directrelay_db_version' ); ?></span>
            <span class="directrelay-set-stat-label"><?php esc_html_e( 'DB Schema', 'directrelay-automation-bridge-for-n8n'); ?></span>
        </div>
        <div class="directrelay-set-stat">
            <span class="directrelay-set-stat-val"><?php echo esc_html( $directrelay_block_count ); ?></span>
            <span class="directrelay-set-stat-label"><?php esc_html_e( 'Blocked', 'directrelay-automation-bridge-for-n8n'); ?></span>
        </div>
    </div>
</div>

<div class="directrelay-set-layout">

<!-- Left: Settings Forms -->
<div>

    <form id="directrelay-settings-form">

        <!-- Security -->
        <div class="directrelay-set-card">
            <div class="directrelay-set-card-header">
                <span class="directrelay-set-icon">🔒</span>
                <h3><?php esc_html_e( 'Security', 'directrelay-automation-bridge-for-n8n'); ?></h3>
            </div>
            <div class="directrelay-set-card-body">

                <div class="directrelay-set-row">
                    <div class="directrelay-set-label">
                        <strong><?php esc_html_e( 'Require HTTPS', 'directrelay-automation-bridge-for-n8n'); ?></strong>
                        <p><?php esc_html_e( 'Reject all API requests over plain HTTP.', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                    <div class="directrelay-set-control">
                        <label class="directrelay-toggle">
                            <input type="checkbox" name="require_https" <?php checked( ! empty( $directrelay_s['require_https'] ) ); ?>>
                            <div class="directrelay-toggle-slider"></div>
                        </label>
                    </div>
                </div>

                <div class="directrelay-set-row">
                    <div class="directrelay-set-label">
                        <strong><?php esc_html_e( 'Detailed Status Response', 'directrelay-automation-bridge-for-n8n'); ?></strong>
                        <p><?php esc_html_e( 'Include sensitive server information (WordPress version, PHP version, active plugins, theme) in status endpoint response.', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                    <div class="directrelay-set-control">
                        <label class="directrelay-toggle">
                            <input type="checkbox" name="detailed_status" <?php checked( ! empty( $directrelay_s['detailed_status'] ) ); ?>>
                            <div class="directrelay-toggle-slider"></div>
                        </label>
                    </div>
                </div>

                <div class="directrelay-set-row">
                    <div class="directrelay-set-label">
                        <strong><?php esc_html_e( 'Brute-Force Limit', 'directrelay-automation-bridge-for-n8n'); ?></strong>
                        <p><?php esc_html_e( 'Failed auth attempts per IP before blocking.', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                    <div class="directrelay-set-control">
                        <input type="number" name="brute_force_limit" value="<?php echo (int) ( $directrelay_s['brute_force_limit'] ?? 10 ); ?>" min="3" max="100" class="directrelay-input">
                    </div>
                </div>

                <div class="directrelay-set-row">
                    <div class="directrelay-set-label">
                        <strong><?php esc_html_e( 'Brute-Force Window', 'directrelay-automation-bridge-for-n8n'); ?></strong>
                        <p><?php esc_html_e( 'Seconds before failure counter resets. Default: 300 (5 min).', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                    <div class="directrelay-set-control">
                        <input type="number" name="brute_force_window" value="<?php echo (int) ( $directrelay_s['brute_force_window'] ?? 300 ); ?>" min="60" max="3600" class="directrelay-input">
                    </div>
                </div>

                <div class="directrelay-set-row">
                    <div class="directrelay-set-label">
                        <strong><?php esc_html_e( 'Bypass IPs / Whitelist', 'directrelay-automation-bridge-for-n8n'); ?></strong>
                        <p><?php esc_html_e( 'IP addresses (one per line or comma-separated, CIDR supported) that bypass rate limiting and brute force protection.', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                    <div class="directrelay-set-control">
                        <textarea name="bypass_ips" rows="3" class="directrelay-input" placeholder="192.168.1.1&#10;10.0.0.0/24" style="width:100%;font-family:monospace;font-size:12px;box-sizing:border-box;"><?php echo esc_textarea( $directrelay_s['bypass_ips'] ?? '' ); ?></textarea>
                    </div>
                </div>

            </div>
        </div>

        <?php if ( true ) : ?>
        <!-- Rate Limiting -->
        <div class="directrelay-set-card">
            <div class="directrelay-set-card-header">
                <span class="directrelay-set-icon">⚡</span>
                <h3><?php esc_html_e( 'Rate Limiting', 'directrelay-automation-bridge-for-n8n'); ?></h3>
            </div>
            <div class="directrelay-set-card-body">

                <div class="directrelay-set-row">
                    <div class="directrelay-set-label">
                        <strong><?php esc_html_e( 'Max Requests / Window', 'directrelay-automation-bridge-for-n8n'); ?></strong>
                        <p><?php esc_html_e( 'Per site. n8n workflows should stay under the limit.', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                    <div class="directrelay-set-control">
                        <input type="number" name="rate_limit" value="<?php echo (int) ( $directrelay_s['rate_limit'] ?? 150 ); ?>" min="1" max="10000" class="directrelay-input">
                    </div>
                </div>

                <div class="directrelay-set-row">
                    <div class="directrelay-set-label">
                        <strong><?php esc_html_e( 'Window Size', 'directrelay-automation-bridge-for-n8n'); ?> <small>(<?php esc_html_e( 'seconds', 'directrelay-automation-bridge-for-n8n'); ?>)</small></strong>
                        <p><?php esc_html_e( 'Time window for rate limit counter. Default: 86400s (1 Day).', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                    <div class="directrelay-set-control">
                        <input type="number" name="rate_window_sec" value="<?php echo (int) ( $directrelay_s['rate_window_sec'] ?? 86400 ); ?>" min="10" max="86400" class="directrelay-input">
                    </div>
                </div>

            </div>
        </div>

        <!-- Webhooks -->
        <div class="directrelay-set-card">
            <div class="directrelay-set-card-header">
                <span class="directrelay-set-icon">🪝</span>
                <h3><?php esc_html_e( 'Webhooks', 'directrelay-automation-bridge-for-n8n'); ?></h3>
            </div>
            <div class="directrelay-set-card-body">

                <div class="directrelay-set-row">
                    <div class="directrelay-set-label">
                        <strong><?php esc_html_e( 'Enable Webhooks', 'directrelay-automation-bridge-for-n8n'); ?></strong>
                        <p><?php esc_html_e( 'Allow webhook registration and event dispatching.', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                    <div class="directrelay-set-control">
                        <label class="directrelay-toggle">
                            <input type="checkbox" name="enable_webhooks" <?php checked( ! empty( $directrelay_s['enable_webhooks'] ) ); ?>>
                            <div class="directrelay-toggle-slider"></div>
                        </label>
                    </div>
                </div>

                <div class="directrelay-set-row">
                    <div class="directrelay-set-label">
                        <strong><?php esc_html_e( 'Timeout', 'directrelay-automation-bridge-for-n8n'); ?> <small>(<?php esc_html_e( 'ms', 'directrelay-automation-bridge-for-n8n'); ?>)</small></strong>
                        <p><?php esc_html_e( 'HTTP timeout per delivery attempt. Default: 5000ms.', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                    <div class="directrelay-set-control">
                        <input type="number" name="webhook_timeout_ms" value="<?php echo (int) ( $directrelay_s['webhook_timeout_ms'] ?? 5000 ); ?>" min="1000" max="30000" step="500" class="directrelay-input">
                    </div>
                </div>

                <div class="directrelay-set-row">
                    <div class="directrelay-set-label">
                        <strong><?php esc_html_e( 'Max Retry Attempts', 'directrelay-automation-bridge-for-n8n'); ?></strong>
                        <p><?php esc_html_e( 'Retries on failure with escalating delays: 1min → 5min → 15min.', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                    <div class="directrelay-set-control">
                        <input type="number" name="max_retry_attempts" value="<?php echo (int) ( $directrelay_s['max_retry_attempts'] ?? 3 ); ?>" min="0" max="5" class="directrelay-input">
                    </div>
                </div>

                <div class="directrelay-set-row">
                    <div class="directrelay-set-label">
                        <strong><?php esc_html_e( 'IndexNow Auto-Ping', 'directrelay-automation-bridge-for-n8n'); ?></strong>
                        <p><?php esc_html_e( 'Submit published post URLs to the IndexNow aggregator (api.indexnow.org), which routes them to participating search engines (Bing, Yandex, Seznam, Naver). Off by default - when off, no external service is contacted at publish time. The verification key is published automatically at yoursite.com/indexnow-key.txt; open that URL to confirm the key file is reachable.', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                    <div class="directrelay-set-control">
                        <label class="directrelay-toggle">
                            <input type="checkbox" name="enable_indexnow" <?php checked( ! empty( $directrelay_s['enable_indexnow'] ) ); ?>>
                            <div class="directrelay-toggle-slider"></div>
                        </label>
                    </div>
                </div>

                <div class="directrelay-set-row">
                    <div class="directrelay-set-label">
                        <strong><?php esc_html_e( 'Flatten n8n Payloads', 'directrelay-automation-bridge-for-n8n'); ?></strong>
                        <p><?php esc_html_e( 'Simplify JSON structure for n8n to avoid complex expressions.', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                    <div class="directrelay-set-control">
                        <label class="directrelay-toggle">
                            <input type="checkbox" name="flatten_n8n_webhooks" <?php checked( ! empty( $directrelay_s['flatten_n8n_webhooks'] ) ); ?>>
                            <div class="directrelay-toggle-slider"></div>
                        </label>
                    </div>
                </div>

            </div>
        </div>

        <!-- Appearance -->
        <div class="directrelay-set-card">
            <div class="directrelay-set-card-header">
                <span class="directrelay-set-icon">🎨</span>
                <h3><?php esc_html_e( 'Appearance', 'directrelay-automation-bridge-for-n8n'); ?></h3>
            </div>
            <div class="directrelay-set-card-body">

                <div class="directrelay-set-row">
                    <div class="directrelay-set-label">
                        <strong><?php esc_html_e( 'UI Mode', 'directrelay-automation-bridge-for-n8n'); ?></strong>
                        <p><?php esc_html_e( 'Standard WordPress look or Agentic Dark mode.', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                    <div class="directrelay-set-control">
                        <select name="ui_mode" class="directrelay-select" style="max-width:180px">
                            <option value="standard" <?php selected( $directrelay_s['ui_mode'] ?? 'standard', 'standard' ); ?>><?php esc_html_e( 'Standard', 'directrelay-automation-bridge-for-n8n'); ?></option>
                            <option value="dark" <?php selected( $directrelay_s['ui_mode'] ?? 'standard', 'dark' ); ?>><?php esc_html_e( 'Agentic Dark', 'directrelay-automation-bridge-for-n8n'); ?></option>
                        </select>
                    </div>
                </div>

            </div>
        </div>
        <?php endif; ?>

        <!-- Access Control -->
        <div class="directrelay-set-card">
            <div class="directrelay-set-card-header">
                <span class="directrelay-set-icon">👥</span>
                <h3><?php esc_html_e( 'Access Control', 'directrelay-automation-bridge-for-n8n'); ?></h3>
            </div>
            <div class="directrelay-set-card-body">

                <div class="directrelay-set-row">
                    <div class="directrelay-set-label">
                        <strong><?php esc_html_e( 'Menu Access Capability', 'directrelay-automation-bridge-for-n8n'); ?></strong>
                        <p><?php esc_html_e( 'Minimum capability to access DirectRelay menu and dashboard.', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                    <div class="directrelay-set-control">
                        <select name="min_capability" class="directrelay-select" style="max-width:200px">
                            <option value="manage_options" <?php selected( $directrelay_s['min_capability'] ?? 'manage_options', 'manage_options' ); ?>><?php esc_html_e( 'Administrator', 'directrelay-automation-bridge-for-n8n'); ?></option>
                            <option value="edit_others_posts" <?php selected( $directrelay_s['min_capability'] ?? 'manage_options', 'edit_others_posts' ); ?>><?php esc_html_e( 'Editor', 'directrelay-automation-bridge-for-n8n'); ?></option>
                            <option value="publish_posts" <?php selected( $directrelay_s['min_capability'] ?? 'manage_options', 'publish_posts' ); ?>><?php esc_html_e( 'Author', 'directrelay-automation-bridge-for-n8n'); ?></option>
                        </select>
                    </div>
                </div>

            </div>
        </div>

        <?php if ( true ) : ?>
        <!-- Media & Storage -->
        <div class="directrelay-set-card">
            <div class="directrelay-set-card-header">
                <span class="directrelay-set-icon">💾</span>
                <h3><?php esc_html_e( 'Media & Storage', 'directrelay-automation-bridge-for-n8n'); ?></h3>
            </div>
            <div class="directrelay-set-card-body">

                <div class="directrelay-set-row">
                    <div class="directrelay-set-label">
                        <strong><?php esc_html_e( 'Key Rotation', 'directrelay-automation-bridge-for-n8n'); ?> <small>(<?php esc_html_e( 'days, 0 = off', 'directrelay-automation-bridge-for-n8n'); ?>)</small></strong>
                        <p><?php esc_html_e( 'Force API keys to expire after X days. 0 to disable.', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                    <div class="directrelay-set-control">
                        <input type="number" name="key_rotation_days" value="<?php echo (int) ( $directrelay_s['key_rotation_days'] ?? 0 ); ?>" min="0" max="365" class="directrelay-input">
                    </div>
                </div>

                <div class="directrelay-set-row">
                    <div class="directrelay-set-label">
                        <strong><?php esc_html_e( 'Max Sideload Size', 'directrelay-automation-bridge-for-n8n'); ?> <small>(MB)</small></strong>
                        <p><?php esc_html_e( 'Maximum file size for URL sideloading and base64 uploads.', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                    <div class="directrelay-set-control">
                        <input type="number" name="max_sideload_size" value="<?php echo (int) ( $directrelay_s['max_sideload_size'] ?? 20 ); ?>" min="1" max="500" class="directrelay-input">
                    </div>
                </div>

                <div class="directrelay-set-row">
                    <div class="directrelay-set-label">
                        <strong><?php esc_html_e( 'Log Retention', 'directrelay-automation-bridge-for-n8n'); ?> <small>(<?php esc_html_e( 'days', 'directrelay-automation-bridge-for-n8n'); ?>)</small></strong>
                        <p><?php esc_html_e( 'Activity log and analytics pruned daily. Min: 7 days.', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                    <div class="directrelay-set-control">
                        <input type="number" name="log_retention_days" value="<?php echo (int) ( $directrelay_s['log_retention_days'] ?? 90 ); ?>" min="7" max="365" class="directrelay-input">
                    </div>
                </div>

            </div>
        </div>
        <?php endif; ?>

        <!-- Save -->
        <div class="directrelay-set-card">
            <div class="directrelay-save-row">
                <button type="submit" class="directrelay-btn-primary">💾 <?php esc_html_e( 'Save Settings', 'directrelay-automation-bridge-for-n8n'); ?></button>
                <span id="directrelay-save-status" class="directrelay-save-status"></span>
            </div>
        </div>

    </form>

    <?php if ( true ) : ?>
    <!-- Import/Export -->
    <div class="directrelay-set-card">
        <div class="directrelay-set-card-header">
            <span class="directrelay-set-icon">📦</span>
            <h3><?php esc_html_e( 'Configuration', 'directrelay-automation-bridge-for-n8n'); ?></h3>
        </div>
        <div class="directrelay-set-card-body">
            <p style="font-size:13px;color:var(--directrelay-muted);margin:0 0 12px"><?php esc_html_e( 'Export your settings to a JSON file for backup, or import on another site.', 'directrelay-automation-bridge-for-n8n'); ?></p>
            <div class="directrelay-imp-exp">
                <button id="directrelay-export-settings" class="directrelay-btn-secondary">📤 <?php esc_html_e( 'Export Settings', 'directrelay-automation-bridge-for-n8n'); ?></button>
                <label for="directrelay-import-settings-file" class="directrelay-btn-ghost" style="cursor:pointer">📥 <?php esc_html_e( 'Import Settings', 'directrelay-automation-bridge-for-n8n'); ?></label>
                <input type="file" id="directrelay-import-settings-file" accept=".json" style="display:none">
            </div>
            <div id="directrelay-import-status" style="margin-top:10px;font-size:13px;display:none"></div>
        </div>
    </div>
    <?php endif; ?>

</div>

<!-- Right: System Info & Diagnostic Panels -->
<div>

    <!-- System Info -->
    <div class="directrelay-set-card">
        <div class="directrelay-set-card-header">
            <span class="directrelay-set-icon">🖥️</span>
            <h3><?php esc_html_e( 'System Info', 'directrelay-automation-bridge-for-n8n' ); ?></h3>
        </div>
        <div class="directrelay-set-card-body" style="padding:0">
            <table class="directrelay-sys-table">
                <tbody>
                    <?php
                    $directrelay_sys_rows = array(
                        array( __( 'Plugin', 'directrelay-automation-bridge-for-n8n' ), esc_html( DIRECTRELAY_VERSION ) ),
                        array( __( 'DB Schema', 'directrelay-automation-bridge-for-n8n' ), 'v' . (int) get_option( 'directrelay_db_version' ) ),
                        array( __( 'WordPress', 'directrelay-automation-bridge-for-n8n' ), esc_html( get_bloginfo( 'version' ) ) ),
                        array( __( 'PHP', 'directrelay-automation-bridge-for-n8n' ), esc_html( PHP_VERSION ) ),
                        array( __( 'SEO Plugin', 'directrelay-automation-bridge-for-n8n' ), ucfirst( $directrelay_sp ), 'none' !== $directrelay_sp ? 'directrelay-sys-ok' : 'directrelay-sys-err' ),
                        array( __( 'Theme', 'directrelay-automation-bridge-for-n8n' ), esc_html( $directrelay_compat['theme_name'] ) . ( $directrelay_compat['is_agentic'] ? ' <span class="directrelay-sys-badge directrelay-sys-ok">' . esc_html__( 'Compat', 'directrelay-automation-bridge-for-n8n' ) . '</span>' : '' ) ),
                        array( __( 'HTTPS', 'directrelay-automation-bridge-for-n8n' ), is_ssl() ? '<span class="directrelay-sys-badge directrelay-sys-ok">' . esc_html__( 'Yes', 'directrelay-automation-bridge-for-n8n' ) . '</span>' : '<span class="directrelay-sys-badge directrelay-sys-err">' . esc_html__( 'No', 'directrelay-automation-bridge-for-n8n' ) . '</span>' ),
                    );
                    foreach ( $directrelay_sys_rows as $directrelay_row ) :
                        $directrelay_label = $directrelay_row[0];
                        $directrelay_value = $directrelay_row[1];
                        $directrelay_class = isset( $directrelay_row[2] ) ? $directrelay_row[2] : '';
                    ?>
                    <tr>
                        <th style="padding-left:18px"><?php echo esc_html( $directrelay_label ); ?></th>
                        <td style="padding-right:18px;text-align:right"><?php echo wp_kses_post( $directrelay_value ); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <tr>
                        <th style="padding-left:18px"><?php esc_html_e( 'API Base', 'directrelay-automation-bridge-for-n8n' ); ?></th>
                        <td style="padding-right:18px;text-align:right"><code class="directrelay-hook-code" style="font-size:11px;word-break:break-all"><?php echo esc_html( get_site_url() . '/wp-json/' . DIRECTRELAY_NS ); ?></code></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Cron Health -->
    <div class="directrelay-set-card <?php echo 'stale' === $directrelay_cron['status'] ? 'directrelay-cron-stale' : 'directrelay-cron-ok'; ?>">
        <div class="directrelay-set-card-header">
            <span class="directrelay-set-icon">⏰</span>
            <h3><?php esc_html_e( 'Cron Health', 'directrelay-automation-bridge-for-n8n' ); ?></h3>
            <?php if ( 'ok' === $directrelay_cron['status'] || 'real_cron' === $directrelay_cron['status'] ) : ?>
                <span class="directrelay-sys-badge directrelay-sys-ok" style="margin-left:auto"><?php echo 'real_cron' === $directrelay_cron['status'] ? esc_html__( 'Server Cron', 'directrelay-automation-bridge-for-n8n' ) : esc_html__( 'Healthy', 'directrelay-automation-bridge-for-n8n' ); ?></span>
            <?php else : ?>
                <span class="directrelay-sys-badge directrelay-sys-warn" style="margin-left:auto"><?php esc_html_e( 'Stale', 'directrelay-automation-bridge-for-n8n' ); ?></span>
            <?php endif; ?>
        </div>
        <div class="directrelay-set-card-body" style="padding: 16px 18px 12px;">
            <p style="font-size:13px;color:var(--directrelay-muted);margin:0 0 12px;line-height:1.5;"><?php echo esc_html( $directrelay_cron['message'] ); ?></p>

            <?php if ( 'stale' === $directrelay_cron['status'] ) : ?>
            <div class="directrelay-cron-alert" style="margin-bottom:12px;">
                <strong><?php esc_html_e( 'Fix:', 'directrelay-automation-bridge-for-n8n' ); ?></strong> <?php esc_html_e( 'Add a real server cron to your hosting control panel:', 'directrelay-automation-bridge-for-n8n' ); ?><br>
                <code style="font-size:11px;margin-top:6px;display:block;font-family:'JetBrains Mono',monospace;word-break:break-all;">*/5 * * * * php <?php echo esc_html( ABSPATH ); ?>wp-cron.php</code>
            </div>
            <?php endif; ?>
        </div>

        <div class="directrelay-set-card-body" style="padding:0;border-top:1px solid var(--directrelay-border)">
            <table class="directrelay-sys-table directrelay-cron-table">
                <thead><tr>
                    <th style="padding-left:18px"><?php esc_html_e( 'Hook & Schedule', 'directrelay-automation-bridge-for-n8n' ); ?></th>
                    <th style="text-align:right;padding-right:18px"><?php esc_html_e( 'Status / Next Run', 'directrelay-automation-bridge-for-n8n' ); ?></th>
                </tr></thead>
                <tbody>
                <?php foreach ( $directrelay_cron['scheduled_hooks'] as $directrelay_hook ) : ?>
                <tr>
                    <td style="padding-left:18px;vertical-align:top">
                        <div style="font-weight:600;font-size:12px;color:var(--directrelay-text);margin-bottom:3px">
                            <?php echo esc_html( ! empty( $directrelay_hook['label'] ) ? $directrelay_hook['label'] : $directrelay_hook['hook'] ); ?>
                        </div>
                        <code class="directrelay-hook-code"><?php echo esc_html( $directrelay_hook['hook'] ); ?></code>
                    </td>
                    <td style="text-align:right;padding-right:18px;vertical-align:top;white-space:nowrap">
                        <?php if ( ! empty( $directrelay_hook['scheduled'] ) ) : ?>
                            <span class="directrelay-sys-badge directrelay-sys-ok">✓ <?php esc_html_e( 'Active', 'directrelay-automation-bridge-for-n8n' ); ?></span>
                            <div style="font-size:11px;color:var(--directrelay-muted);margin-top:4px;font-family:var(--directrelay-mono)">
                                <?php echo esc_html( $directrelay_hook['next_run'] ); ?>
                            </div>
                        <?php elseif ( ! empty( $directrelay_hook['is_ondemand'] ) ) : ?>
                            <span class="directrelay-sys-badge directrelay-sys-info"><?php esc_html_e( 'On Demand', 'directrelay-automation-bridge-for-n8n' ); ?></span>
                            <div style="font-size:11px;color:var(--directrelay-muted);margin-top:4px">
                                <?php esc_html_e( 'Event-driven', 'directrelay-automation-bridge-for-n8n' ); ?>
                            </div>
                        <?php else : ?>
                            <span class="directrelay-sys-badge directrelay-sys-err"><?php esc_html_e( 'Missing', 'directrelay-automation-bridge-for-n8n' ); ?></span>
                            <div style="font-size:11px;color:var(--directrelay-red);margin-top:4px">
                                <?php esc_html_e( 'Not scheduled', 'directrelay-automation-bridge-for-n8n' ); ?>
                            </div>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Blocked IPs -->
    <div class="directrelay-set-card">
        <div class="directrelay-set-card-header">
            <span class="directrelay-set-icon">🚫</span>
            <h3><?php esc_html_e( 'Blocked IPs', 'directrelay-automation-bridge-for-n8n' ); ?></h3>
            <?php if ( $directrelay_block_count > 0 ) : ?>
                <span class="directrelay-sys-badge directrelay-sys-err" style="margin-left:auto"><?php echo (int) $directrelay_block_count; ?> <?php esc_html_e( 'active', 'directrelay-automation-bridge-for-n8n' ); ?></span>
            <?php else : ?>
                <span class="directrelay-sys-badge directrelay-sys-ok" style="margin-left:auto"><?php esc_html_e( '0 active', 'directrelay-automation-bridge-for-n8n' ); ?></span>
            <?php endif; ?>
        </div>
        <div class="directrelay-set-card-body" style="padding: 16px 18px;">
            <?php if ( empty( $directrelay_blocks ) ) : ?>
                <div class="directrelay-empty" style="padding: 14px 10px; text-align:center;">
                    <div style="font-size: 22px; margin-bottom: 6px;">🛡️</div>
                    <strong style="color: var(--directrelay-text); font-size: 13px;"><?php esc_html_e( 'No blocked IPs', 'directrelay-automation-bridge-for-n8n' ); ?></strong>
                    <span style="color: var(--directrelay-muted); font-size: 12px; display: block; margin-top: 2px;"><?php esc_html_e( 'Brute-force protection is active and monitoring.', 'directrelay-automation-bridge-for-n8n' ); ?></span>
                </div>
            <?php else : ?>
                <div style="display:flex;flex-wrap:wrap;gap:6px">
                    <?php foreach ( $directrelay_blocks as $directrelay_b ) : ?>
                    <div class="directrelay-block-chip ip">
                        <span><?php echo esc_html( $directrelay_b['ip_address'] ); ?></span>
                        <small style="opacity:0.7;font-size:10px"><?php echo $directrelay_b['blocked_until'] ? esc_html( human_time_diff( strtotime( $directrelay_b['blocked_until'] ) ) . ' left' ) : ''; ?></small>
                        <button class="directrelay-unblock" data-ip="<?php echo esc_attr( $directrelay_b['ip_address'] ); ?>" title="<?php esc_attr_e( 'Unblock IP', 'directrelay-automation-bridge-for-n8n' ); ?>">✕</button>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <div style="display:flex;gap:6px;margin-top:12px;align-items:center">
                <input
                    type="text"
                    id="directrelay-block-ip-input"
                    class="directrelay-set-input"
                    placeholder="<?php esc_attr_e( 'IPv4 or IPv6 address (e.g. 192.0.2.1 or 2001:db8::1)', 'directrelay-automation-bridge-for-n8n' ); ?>"
                    style="flex:1;min-width:0"
                    autocomplete="off"
                    spellcheck="false">
                <button
                    type="button"
                    id="directrelay-block-ip-btn"
                    class="directrelay-btn directrelay-btn-primary"
                    style="white-space:nowrap">
                    <?php esc_html_e( 'Block IP', 'directrelay-automation-bridge-for-n8n' ); ?>
                </button>
            </div>
            <p style="color: var(--directrelay-muted); font-size: 11px; margin: 6px 0 0;">
                <?php esc_html_e( 'Manually block a single IP for 24 hours. CIDR ranges are not supported. Manual blocks and the automatic brute-force counter share the same list.', 'directrelay-automation-bridge-for-n8n' ); ?>
            </p>
        </div>
    </div>

    <!-- Live Connection Test -->
    <div class="directrelay-set-card">
        <div class="directrelay-set-card-header">
            <span class="directrelay-set-icon">🔌</span>
            <h3><?php esc_html_e( 'Live Connection Test', 'directrelay-automation-bridge-for-n8n' ); ?></h3>
        </div>
        <div class="directrelay-set-card-body" style="padding: 16px 18px;">
            <p style="font-size:12px;color:var(--directrelay-muted);margin:0 0 12px;line-height:1.5;"><?php esc_html_e( 'Paste your DirectRelay API key to verify connectivity from the browser.', 'directrelay-automation-bridge-for-n8n' ); ?></p>
            <div class="directrelay-conn-row">
                <input type="password" id="directrelay-test-key" placeholder="directrelay_live_xxxxxxxx…" class="directrelay-input" style="flex:1">
                <button class="directrelay-btn-secondary" id="directrelay-test-conn-btn"><?php esc_html_e( 'Test', 'directrelay-automation-bridge-for-n8n' ); ?></button>
            </div>
            <pre id="directrelay-conn-result" class="directrelay-code-block" style="display:none;white-space:pre-wrap;font-size:11px;margin-top:10px;padding:10px 12px;background:var(--directrelay-card2);border:1px solid var(--directrelay-border);border-radius:6px;color:var(--directrelay-text);"></pre>
        </div>
    </div>

</div>

</div>
</div>