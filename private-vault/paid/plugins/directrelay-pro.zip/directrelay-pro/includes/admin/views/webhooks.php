<?php
/**
 * DirectRelay Webhooks admin view (Free).
 *
 * The free plugin has no monthly dispatch limit, no per-site webhook
 * cap, and no activation-state gate. The add-on plugin provides the
 * preset library, event-pipeline cards, and add-on filters via the
 * `directrelay_ext_templates` filter and the
 * `directrelay_ext_render_pro_dashboard_panel` action hooks.
 *
 * @package DirectRelay
 */

defined( 'ABSPATH' ) || exit;

$directrelay_usage          = \DirectRelay\Webhook_Manager::get_usage();
$directrelay_max_webhooks   = (int) ( get_option( 'directrelay_settings', [] )['max_webhooks'] ?? 50 );
$directrelay_allowed_events = \DirectRelay\Webhook_Manager::EVENTS;
$directrelay_allowed_types  = array_keys( get_post_types( array( 'public' => true ), 'names' ) );
$directrelay_presets        = \DirectRelay\Webhook_Manager::get_presets();

$directrelay_active_count = count( array_filter( $directrelay_webhooks, fn( $w ) => $w['active'] ) );
$directrelay_total_fires  = array_sum( array_map( fn( $w ) => (int) $w['fire_count'], $directrelay_webhooks ) );
$directrelay_failed_fires = array_sum( array_map( fn( $w ) => (int) $w['fail_count'], $directrelay_webhooks ) );
$directrelay_wh_count     = count( $directrelay_webhooks );
?>

<div class="directrelay-wrap" id="directrelay-webhooks">

<!-- Hero Banner -->
<div class="directrelay-wh-hero">
    <div class="directrelay-wh-hero-left">
        <h1>
            <img src="<?php echo esc_url( DIRECTRELAY_URL . 'assets/icon-256x256.png' ); ?>" alt="DirectRelay" style="width:32px;height:32px;border-radius:6px;vertical-align:middle;margin-right:8px;">
            <?php esc_html_e( 'Webhooks & Event Dispatcher', 'directrelay-automation-bridge-for-n8n'); ?>
        </h1>
        <p><?php esc_html_e( 'Real-time outbound event notifications for n8n, Make, and AI agents with HMAC signing and exponential retry logic.', 'directrelay-automation-bridge-for-n8n'); ?></p>
    </div>
    <div class="directrelay-wh-hero-right">
        <div class="directrelay-wh-stat">
            <span class="directrelay-wh-stat-val"><?php echo esc_html( $directrelay_active_count ); ?><small style="font-size:14px;opacity:0.7">/ <?php echo (int) $directrelay_max_webhooks; ?></small></span>
            <span class="directrelay-wh-stat-label"><?php esc_html_e( 'Active Endpoints', 'directrelay-automation-bridge-for-n8n'); ?></span>
        </div>
        <div class="directrelay-wh-stat">
            <span class="directrelay-wh-stat-val"><?php echo esc_html( number_format( $directrelay_usage['used'] ) ); ?></span>
            <span class="directrelay-wh-stat-label"><?php esc_html_e( 'Total Dispatches', 'directrelay-automation-bridge-for-n8n'); ?></span>
        </div>
        <div class="directrelay-wh-stat">
            <span class="directrelay-wh-stat-val"><?php echo esc_html( number_format( $directrelay_total_fires ) ); ?></span>
            <span class="directrelay-wh-stat-label"><?php esc_html_e( 'Total Fires', 'directrelay-automation-bridge-for-n8n'); ?></span>
        </div>
        <div class="directrelay-wh-stat">
            <span class="directrelay-wh-stat-val"><?php echo esc_html( number_format( $directrelay_failed_fires ) ); ?></span>
            <span class="directrelay-wh-stat-label"><?php esc_html_e( 'Failed', 'directrelay-automation-bridge-for-n8n'); ?></span>
        </div>
    </div>
</div>

<!-- Webhook Presets — free uses 1 starter preset; add-on contributes more. -->
<div class="directrelay-table-section" style="margin-bottom:28px">
    <div class="directrelay-table-section-header">
        <div>
            <h2><?php esc_html_e( 'Webhook Presets', 'directrelay-automation-bridge-for-n8n'); ?></h2>
            <p style="margin:4px 0 0;font-size:13px;color:var(--directrelay-muted)"><?php esc_html_e( 'Pre-configured endpoints for common n8n and AI workflows. The add-on plugin adds the full pipeline library.', 'directrelay-automation-bridge-for-n8n'); ?></p>
        </div>
    </div>

    <div class="directrelay-presets-grid" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(320px, 1fr));gap:16px;margin-top:12px">
        <?php foreach ( $directrelay_presets as $directrelay_pid => $directrelay_p ) : ?>
        <div class="directrelay-wf-card directrelay-preset-card" style="display:flex;flex-direction:column;justify-content:space-between;padding:18px;border-top:3px solid #7c3aed;background:var(--directrelay-card)">
            <div>
                <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:10px">
                    <div style="display:flex;align-items:center;gap:8px">
                        <span style="font-size:24px"><?php echo esc_html( $directrelay_p['icon'] ); ?></span>
                        <strong style="font-size:14px;color:var(--directrelay-text);line-height:1.3"><?php echo esc_html( $directrelay_p['label'] ); ?></strong>
                    </div>
                </div>
                <p style="font-size:12px;color:var(--directrelay-muted);line-height:1.5;margin:0 0 12px"><?php echo esc_html( $directrelay_p['description'] ); ?></p>
                <div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:16px">
                    <?php foreach ( $directrelay_p['events'] as $directrelay_pev ) : ?>
                        <span style="font-size:10px;background:var(--directrelay-card2);border:1px solid var(--directrelay-border);color:var(--directrelay-dim);padding:2px 6px;border-radius:4px;font-family:var(--directrelay-mono)"><?php echo esc_html( $directrelay_pev ); ?></span>
                    <?php endforeach; ?>
                </div>
            </div>

            <div style="display:flex;gap:8px;padding-top:12px;border-top:1px solid var(--directrelay-border)">
                <button type="button" class="directrelay-btn directrelay-load-preset"
                    style="flex:1;background:#7c3aed;color:#fff;border:none;border-radius:6px;padding:8px 12px;font-size:12px;font-weight:700;cursor:pointer"
                    data-id="<?php echo esc_attr( $directrelay_pid ); ?>"
                    data-label="<?php echo esc_attr( $directrelay_p['label'] ); ?>"
                    data-events="<?php echo esc_attr( wp_json_encode( $directrelay_p['events'] ) ); ?>"
                    data-types="<?php echo esc_attr( wp_json_encode( $directrelay_p['post_types'] ) ); ?>"
                    data-ispro="<?php echo esc_attr( empty( $directrelay_p['is_pro'] ) ? 0 : 1 ); ?>">
                    <?php esc_html_e( 'Load Preset', 'directrelay-automation-bridge-for-n8n'); ?>
                </button>
                <button type="button" class="directrelay-btn directrelay-copy-btn"
                    style="background:var(--directrelay-card2);border:1px solid var(--directrelay-border);color:var(--directrelay-text);border-radius:6px;padding:8px 12px;font-size:12px;font-weight:600;cursor:pointer"
                    data-target="preset-wf-<?php echo esc_attr( $directrelay_pid ); ?>"
                    title="<?php esc_attr_e( 'Copy n8n Workflow JSON', 'directrelay-automation-bridge-for-n8n'); ?>">
                    <?php esc_html_e( 'n8n JSON', 'directrelay-automation-bridge-for-n8n'); ?>
                </button>
                <textarea id="preset-wf-<?php echo esc_attr( $directrelay_pid ); ?>" style="display:none;"><?php echo esc_textarea( $directrelay_p['workflow'] ); ?></textarea>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Main Layout: Form + Reference Sidebar -->
<div class="directrelay-wh-layout">

    <!-- Left: Register Form -->
    <div class="directrelay-wf-card" id="directrelay-webhook-form-card">
        <form id="directrelay-create-webhook-form" method="post" action="">

            <!-- Section 1: Target -->
            <div class="directrelay-wf-section">
                <div class="directrelay-wf-section-header">
                    <div class="directrelay-wf-num">1</div>
                    <div>
                        <h3><?php esc_html_e( 'Endpoint Configuration', 'directrelay-automation-bridge-for-n8n'); ?></h3>
                        <p><?php esc_html_e( 'Where should we send the webhook payloads?', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                </div>
                <div class="directrelay-fields-row">
                    <div>
                        <label class="directrelay-label"><?php esc_html_e( 'Label', 'directrelay-automation-bridge-for-n8n'); ?> <span style="color:var(--directrelay-red)">*</span></label>
                        <input type="text" name="label" id="directrelay-wh-label-input" class="directrelay-input" placeholder="<?php esc_attr_e( 'e.g. n8n Post Published', 'directrelay-automation-bridge-for-n8n'); ?>" required>
                    </div>
                    <div>
                        <label class="directrelay-label"><?php esc_html_e( 'Target URL', 'directrelay-automation-bridge-for-n8n'); ?> <span style="color:var(--directrelay-red)">*</span></label>
                        <input type="url" name="target_url" id="directrelay-wh-url-input" class="directrelay-input" placeholder="https://your-n8n.com/webhook/" required>
                    </div>
                    <div class="directrelay-field-full">
                        <label class="directrelay-label"><?php esc_html_e( 'Signing Secret', 'directrelay-automation-bridge-for-n8n'); ?> <small><?php esc_html_e( 'optional — used for X-DirectRelay-Signature header', 'directrelay-automation-bridge-for-n8n'); ?></small></label>
                        <input type="password" name="secret" id="directrelay-wh-secret-input" class="directrelay-input" placeholder="<?php esc_attr_e( 'Leave blank for no signature verification', 'directrelay-automation-bridge-for-n8n'); ?>">
                    </div>
                </div>
            </div>

            <!-- Section 2: Events & Post Types -->
            <div class="directrelay-wf-section">
                <div class="directrelay-wf-section-header">
                    <div class="directrelay-wf-num">2</div>
                    <div>
                        <h3><?php esc_html_e( 'Events & Post Types', 'directrelay-automation-bridge-for-n8n'); ?></h3>
                        <p><?php esc_html_e( 'Choose which WordPress events trigger this webhook.', 'directrelay-automation-bridge-for-n8n'); ?></p>
                    </div>
                </div>

                <div style="margin-bottom:16px">
                    <label class="directrelay-label" style="margin-bottom:10px"><?php esc_html_e( 'Events', 'directrelay-automation-bridge-for-n8n'); ?></label>
                    <div class="directrelay-ev-grid">
                        <?php foreach ( \DirectRelay\Webhook_Manager::EVENTS as $directrelay_ev ) :
                            $directrelay_ev_allowed = in_array( $directrelay_ev, $directrelay_allowed_events, true );
                        ?>
                        <label class="directrelay-ev-item <?php echo ! $directrelay_ev_allowed ? 'is-disabled' : ''; ?>"
                               style="<?php echo ! $directrelay_ev_allowed ? 'opacity:0.6;cursor:not-allowed' : ''; ?>">
                            <input type="checkbox" name="events[]" value="<?php echo esc_attr( $directrelay_ev ); ?>"
                                <?php checked( $directrelay_ev === 'post.published' ); ?>
                                <?php echo ! $directrelay_ev_allowed ? 'disabled' : ''; ?>>
                            <code><?php echo esc_html( $directrelay_ev ); ?></code>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div>
                    <label class="directrelay-label" style="margin-bottom:10px"><?php esc_html_e( 'Post Types', 'directrelay-automation-bridge-for-n8n'); ?></label>
                    <div class="directrelay-ev-grid">
                        <?php foreach ( $directrelay_allowed_types as $directrelay_ptype ) : ?>
                        <label class="directrelay-ev-item">
                            <input type="checkbox" name="post_types[]" value="<?php echo esc_attr( $directrelay_ptype ); ?>" <?php checked( $directrelay_ptype === 'post' ); ?>>
                            <code><?php echo esc_html( $directrelay_ptype ); ?></code>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Section 3: Delivery Mode -->
            <div class="directrelay-wf-section">
                <div class="directrelay-wf-section-header">
                    <div class="directrelay-wf-num">3</div>
                    <div>
                        <h3><?php esc_html_e( 'Delivery Mode', 'directrelay-automation-bridge-for-n8n'); ?></h3>
                    </div>
                </div>
                <div class="directrelay-info-banner" style="background:var(--directrelay-card2);border:1px solid var(--directrelay-border);border-radius:8px;padding:12px 16px;display:flex;gap:12px;align-items:center">
                    <span class="directrelay-info-icon" style="font-size:20px">ℹ️</span>
                    <div style="font-size:12px;color:var(--directrelay-muted);line-height:1.5">
                        <?php
                            printf(
                                /* translators: %s: cron command example */
                                esc_html__( 'Webhooks fire via non-blocking WP-Cron by default. For guaranteed sub-second delivery, configure a real server cron: %s', 'directrelay-automation-bridge-for-n8n' ),
                                '<br><code style="font-size:11px;margin-top:4px;display:inline-block;color:var(--directrelay-text)">*/1 * * * * php /path/to/public_html/wp-cron.php</code>'
                            );
                        ?>
                    </div>
                </div>
            </div>

            <div class="directrelay-wf-actions">
                <button type="submit" class="directrelay-btn-primary" id="directrelay-create-wh-btn">
                    🪝 <?php esc_html_e( 'Register Webhook', 'directrelay-automation-bridge-for-n8n'); ?>
                </button>
                <span style="font-size:12px;color:var(--directrelay-muted)"><?php esc_html_e( 'Payloads include HMAC-SHA256 signature for verification.', 'directrelay-automation-bridge-for-n8n'); ?></span>
            </div>
        </form>
    </div>

    <!-- Right: Event Reference Sidebar -->
    <div class="directrelay-ref-card">
        <div class="directrelay-ref-card-header">
            <span>📋</span>
            <h3><?php esc_html_e( 'Reference', 'directrelay-automation-bridge-for-n8n'); ?></h3>
        </div>
        <div class="directrelay-ref-card-body">

            <div class="directrelay-ref-block">
                <div class="directrelay-ref-block-title"><?php esc_html_e( 'Active Endpoints', 'directrelay-automation-bridge-for-n8n'); ?></div>
                <div style="font-size:12px;color:var(--directrelay-dim);line-height:1.7">
                    <?php
                    printf(
                        /* translators: 1: active endpoints, 2: configured max */
                        esc_html__( '%1$s active / %2$s configured maximum', 'directrelay-automation-bridge-for-n8n' ),
                        (int) $directrelay_active_count,
                        (int) $directrelay_max_webhooks
                    );
                    ?><br>
                    <?php esc_html_e( 'Adjust the maximum on the Settings page.', 'directrelay-automation-bridge-for-n8n' ); ?>
                </div>
            </div>

            <hr class="directrelay-ref-divider">

            <div class="directrelay-ref-block">
                <div class="directrelay-ref-block-title"><?php esc_html_e( 'HMAC Signature Header', 'directrelay-automation-bridge-for-n8n'); ?></div>
                <div class="directrelay-ref-code">X-DirectRelay-Signature:<br>sha256=&lt;hmac_hash&gt;</div>
            </div>

            <hr class="directrelay-ref-divider">

            <div class="directrelay-ref-block">
                <div class="directrelay-ref-block-title"><?php esc_html_e( 'Verification (Node.js / n8n)', 'directrelay-automation-bridge-for-n8n'); ?></div>
                <div class="directrelay-ref-code" style="font-size:11px">crypto.createHmac('sha256', secret)<br>  .update(rawBody)<br>  .digest('hex')</div>
            </div>

            <hr class="directrelay-ref-divider">

            <div class="directrelay-ref-block">
                <div class="directrelay-ref-block-title"><?php esc_html_e( 'Payload Sample', 'directrelay-automation-bridge-for-n8n'); ?></div>
                <div class="directrelay-ref-code" style="font-size:10px">{
  "event": "post.published",
  "post": { "id": 101, "title": "..." },
  "seo": { "focus_keyword": "..." },
  "timestamp": "2026-08-19T..."
}</div>
            </div>

        </div>
    </div>

</div>

<!-- Registered Webhooks Table -->
<div class="directrelay-table-section">
    <div class="directrelay-table-section-header">
        <h2>🪝 <?php esc_html_e( 'Registered Webhooks', 'directrelay-automation-bridge-for-n8n'); ?></h2>
        <div class="directrelay-table-controls">
            <input type="text" id="directrelay-wh-search" class="directrelay-search-input" placeholder="<?php esc_attr_e( 'Search by label or URL…', 'directrelay-automation-bridge-for-n8n'); ?>">
        </div>
    </div>

    <div class="directrelay-wf-card">
        <?php if ( empty( $directrelay_webhooks ) ) : ?>
            <div style="padding:48px 20px;text-align:center">
                <div style="font-size:40px;margin-bottom:12px">🪝</div>
                <div style="font-size:15px;font-weight:700;color:var(--directrelay-text);margin-bottom:6px"><?php esc_html_e( 'No webhooks registered yet', 'directrelay-automation-bridge-for-n8n'); ?></div>
                <div style="font-size:13px;color:var(--directrelay-muted)"><?php esc_html_e( 'Register an endpoint above to start dispatching real-time events to n8n.', 'directrelay-automation-bridge-for-n8n'); ?></div>
            </div>
        <?php else : ?>
        <table class="directrelay-table widefat wp-list-table" style="margin:0">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Label', 'directrelay-automation-bridge-for-n8n'); ?></th>
                    <th><?php esc_html_e( 'Target URL', 'directrelay-automation-bridge-for-n8n'); ?></th>
                    <th><?php esc_html_e( 'Events', 'directrelay-automation-bridge-for-n8n'); ?></th>
                    <th><?php esc_html_e( 'Status', 'directrelay-automation-bridge-for-n8n'); ?></th>
                    <th><?php esc_html_e( 'Fires', 'directrelay-automation-bridge-for-n8n'); ?></th>
                    <th><?php esc_html_e( 'Last Fire', 'directrelay-automation-bridge-for-n8n'); ?></th>
                    <th><?php esc_html_e( 'Actions', 'directrelay-automation-bridge-for-n8n'); ?></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ( $directrelay_webhooks as $directrelay_wh ) :
                $directrelay_events = json_decode( $directrelay_wh['events'] ?? '[]', true ) ?: array();
            ?>
            <tr>
                <td><strong><?php echo esc_html( $directrelay_wh['label'] ); ?></strong></td>
                <td><code style="font-size:12px"><?php echo esc_html( $directrelay_wh['target_url'] ); ?></code></td>
                <td>
                    <?php foreach ( $directrelay_events as $directrelay_ev ) : ?>
                        <span style="font-size:10px;background:var(--directrelay-card2);padding:2px 6px;border-radius:4px;margin-right:4px"><?php echo esc_html( $directrelay_ev ); ?></span>
                    <?php endforeach; ?>
                </td>
                <td>
                    <?php if ( $directrelay_wh['active'] ) : ?>
                        <span class="directrelay-badge directrelay-badge-active"><?php esc_html_e( 'Active', 'directrelay-automation-bridge-for-n8n'); ?></span>
                    <?php else : ?>
                        <span class="directrelay-badge directrelay-badge-inactive"><?php esc_html_e( 'Paused', 'directrelay-automation-bridge-for-n8n'); ?></span>
                    <?php endif; ?>
                </td>
                <td><?php echo esc_html( number_format( (int) $directrelay_wh['fire_count'] ) ); ?></td>
                <td><?php echo $directrelay_wh['last_fired_at'] ? esc_html( human_time_diff( strtotime( $directrelay_wh['last_fired_at'] ) ) . ' ' . __( 'ago', 'directrelay-automation-bridge-for-n8n' ) ) : esc_html__( 'Never', 'directrelay-automation-bridge-for-n8n'); ?></td>
                <td>
                    <button class="directrelay-btn directrelay-toggle-wh" data-id="<?php echo (int) $directrelay_wh['id']; ?>" data-active="<?php echo (int) ! $directrelay_wh['active']; ?>">
                        <?php echo $directrelay_wh['active'] ? esc_html__( 'Pause', 'directrelay-automation-bridge-for-n8n' ) : esc_html__( 'Activate', 'directrelay-automation-bridge-for-n8n' ); ?>
                    </button>
                    <button class="directrelay-btn directrelay-test-wh" data-id="<?php echo (int) $directrelay_wh['id']; ?>">
                        <?php esc_html_e( 'Test', 'directrelay-automation-bridge-for-n8n'); ?>
                    </button>
                    <button class="directrelay-btn directrelay-view-log" data-id="<?php echo (int) $directrelay_wh['id']; ?>" data-label="<?php echo esc_attr( $directrelay_wh['label'] ); ?>">
                        <?php esc_html_e( 'Deliveries', 'directrelay-automation-bridge-for-n8n'); ?>
                    </button>
                    <button class="directrelay-btn directrelay-delete-wh" data-id="<?php echo (int) $directrelay_wh['id']; ?>" style="color:var(--directrelay-red)">
                        <?php esc_html_e( 'Delete', 'directrelay-automation-bridge-for-n8n'); ?>
                    </button>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<!-- Webhook Test Result Modal -->
<div id="directrelay-test-modal" class="directrelay-modal-overlay" style="display:none;">
    <div class="directrelay-modal-box" style="margin:10vh auto;max-width:640px;width:90%;background:var(--directrelay-card,#fff);border-radius:12px;padding:24px;box-shadow:0 20px 60px rgba(0,0,0,.3);">
        <div class="directrelay-modal-header" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
            <strong><?php esc_html_e( 'Webhook Test Result', 'directrelay-automation-bridge-for-n8n'); ?></strong>
            <button type="button" class="directrelay-modal-close" style="background:none;border:none;font-size:20px;cursor:pointer;line-height:1;">&times;</button>
        </div>
        <pre id="directrelay-test-result" style="white-space:pre-wrap;max-height:320px;overflow:auto;font-size:12px;"></pre>
    </div>
</div>

<!-- Webhook Delivery Log Modal -->
<div id="directrelay-deliveries-modal" class="directrelay-modal-overlay" style="display:none;">
    <div class="directrelay-modal-box" style="margin:8vh auto;max-width:900px;width:94%;background:var(--directrelay-card,#fff);border-radius:12px;padding:24px;box-shadow:0 20px 60px rgba(0,0,0,.3);">
        <div class="directrelay-modal-header" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
            <strong><span class="directrelay-modal-title"><?php esc_html_e( 'Deliveries', 'directrelay-automation-bridge-for-n8n'); ?></span> <span class="directrelay-badge" id="directrelay-delivery-count"></span></strong>
            <button type="button" class="directrelay-modal-close" style="background:none;border:none;font-size:20px;cursor:pointer;line-height:1;">&times;</button>
        </div>
        <div id="directrelay-delivery-log" style="max-height:60vh;overflow:auto;"></div>
    </div>
</div>

</div>
