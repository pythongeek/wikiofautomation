=== DirectRelay Pro — Monster Automation Bridge for n8n ===
Contributors: n4nion
Requires at least: 6.3
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Complete all-in-one Monster Pro WordPress Automation Bridge for n8n and AI Agents. Includes full core bridge + Tier 1-4 Pro Engine + AutoNode License Server v2.2.0 integration.

== Description ==
DirectRelay Pro is a complete, standalone all-in-one WordPress automation bridge for n8n, Make, and autonomous AI agents:
* **Full Core Bridge Included**: Scoped API Keys, Agent Permission Profiles, Sliding-Window Rate Limiter, Activity Logger, Transactional Publisher, Outbound Webhooks, Admin Dashboard, and OpenAPI 3.1 Spec.
* **Tier 1 (Core Pro)**: Full Bidirectional 4-Plugin SEO Write Engine (Rank Math, Yoast SEO, AIOSEO, SEOPress + FAQ, HowTo, Article, Product, Review JSON-LD Schemas), One-Shot / Bulk (50 items) / Universal Schema Publishing, Human Approval Portal with signed Magic Review URLs, AI Content Guardrails & Velocity Engine, Time-Travel Execution Debugger, Chart.js Telemetry, and Agentic Dark Mode.
* **Tier 2 (AI, GEO/AEO & Indexing)**: Automated Internal Linking & Semantic Silo Engine, live `/llms.txt` & `/llms-full.txt` generator + AEO Citation Box + ClaimReview JSON-LD, native OpenSSL RS256 Google Indexing API + Cloudflare/BunnyCDN/Fastly/LiteSpeed Edge Purge, Smart Media Pipeline (Inline `<img>` Sideloader, WebP Converter, 1200x630 OpenGraph Card Generator), and Gutenberg Block Converter.
* **Tier 3 (CPT, ACF Pro, WooCommerce & Multilingual)**: Universal Custom Post Type & Custom Taxonomy CRUD, deep ACF Pro (Repeaters, Flexible Content, Galleries)/Meta Box/JetEngine/Pods engine, WooCommerce Product/Variation/Inventory/Order Bridge, WPML/Polylang/TranslatePress Multilingual Sync, and Content Decay Detector + Pre-AI Snapshot Rollback.
* **Tier 4 (Fleet Command, Webhook 2.0, White-Label & License Server)**: Multi-Site & Multi-Domain Fleet Command (`/fleet/health`, `/fleet/sites`, `/fleet/keys/provision`, `/fleet/sync`), Webhook 2.0 Conditional Rules & Dead-Letter Queue (DLQ) Re-Drive, Agency White-Labeling, Real-Time Slack/Telegram/Discord Security Alerts, and AutoNode License Server v2.2.0 HMAC & Telemetry Sync.

== Installation ==
1. Upload `directrelay-pro.zip` via **Plugins -> Add New Plugin -> Upload Plugin** in WordPress Admin.
2. Activate **DirectRelay Pro — Monster Automation Bridge for n8n** (works standalone or alongside the Free plugin).
3. Open **DirectRelay -> License & Fleet** (`admin.php?page=directrelay-license`) to verify your AutoNode Pro license key or test immediately in Grace Mode.
