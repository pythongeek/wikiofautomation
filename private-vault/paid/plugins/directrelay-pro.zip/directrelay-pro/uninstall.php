<?php
/**
 * DirectRelay - Standalone uninstall handler
 *
 * This file is invoked when the user deletes the plugin from the WordPress plugins page.
 * It performs a clean uninstall of all plugin data including:
 *   - All custom database tables
 *   - All plugin options (including the generated IndexNow key)
 *   - Scheduled cron events
 *   - Diagnostic trace/error log files under the uploads directory
 *
 * @since 4.2.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Multisite: run for all blogs first, then delete network-wide options
if ( is_multisite() ) {
    global $wpdb;
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- multisite blog enumeration requires direct query
    $directrelay_blog_ids = $wpdb->get_col( "SELECT blog_id FROM {$wpdb->blogs}" );
    foreach ( $directrelay_blog_ids as $directrelay_blog_id ) {
        switch_to_blog( $directrelay_blog_id );
        directrelay_uninstall_blog();
        restore_current_blog();
    }
    delete_site_option( 'directrelay_db_version' );
    delete_site_option( 'directrelay_settings' );
} else {
    directrelay_uninstall_blog();
}

/**
 * Clean up a single blog's plugin data.
 */
function directrelay_uninstall_blog(): void {
    global $wpdb;

    $tables = [
        'directrelay_keys',
        'directrelay_log',
        'directrelay_rate',
        'directrelay_webhooks',
        'directrelay_analytics',
        'directrelay_approvals',
        'directrelay_webhook_log',
        'directrelay_brute_force',
    ];

    foreach ( $tables as $table ) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- uninstall-time DDL with known static table names, no user input
        $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$table}" );
    }

    // Clean up transients
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- bulk delete on options table for transients
    $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_directrelay_brute_%' OR option_name LIKE '_transient_timeout_directrelay_brute_%'" );
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- bulk delete on options table for transients
    $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_directrelay_rate_%' OR option_name LIKE '_transient_timeout_directrelay_rate_%'" );

    // Clean up cron events using wp_unschedule_event
    $hooks = [
        'directrelay_prune_logs',
        'directrelay_prune_rate_limits',
        'directrelay_fire_webhook',
        'directrelay_deliver_webhook',
        'directrelay_cron_health_ping',
        'directrelay_prune_brute_force',
    ];
    foreach ( $hooks as $h ) {
        $timestamp = wp_next_scheduled( $h );
        while ( $timestamp ) {
            wp_unschedule_event( $timestamp, $h );
            $timestamp = wp_next_scheduled( $h );
        }
    }

    delete_option( 'directrelay_db_version' );
    delete_option( 'directrelay_settings' );
    delete_option( 'directrelay_guardrails' );
    delete_option( 'directrelay_cron_last_ping' );
    delete_option( 'directrelay_apppass_dismissed' );
    delete_option( 'directrelay_log_retention_days' );
    delete_option( 'directrelay_indexnow_key' );

    /* Remove diagnostic trace/error logs left behind by WP_DEBUG_LOG sessions. */
    if ( function_exists( 'wp_upload_dir' ) ) {
        $directrelay_up = wp_upload_dir();
        if ( ! empty( $directrelay_up['basedir'] ) ) {
            $directrelay_log_dir = trailingslashit( $directrelay_up['basedir'] ) . 'directrelay-automation-bridge-for-n8n';
            foreach ( [ 'trace.log', 'error.log' ] as $directrelay_log_file ) {
                $directrelay_log_path = $directrelay_log_dir . '/' . $directrelay_log_file;
                if ( is_file( $directrelay_log_path ) ) {
                    // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_file -- guard before delete.
                    wp_delete_file( $directrelay_log_path );
                }
            }
        }
    }
}
