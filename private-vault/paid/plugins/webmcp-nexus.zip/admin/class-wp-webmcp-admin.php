<?php
/**
 * Admin — Doc Part 5.
 *
 * Responsibilities:
 *   - Register the 8 admin screens per Doc §5.3 (top-level "WebMCP",
 *     dashicons-rest-api, position 58, manage_options, exact order).
 *   - Wire the screen router: load the matching partial from
 *     admin/partials/wp-webmcp-{slug}.php.
 *   - Gate admin CSS + JS enqueue on the 8 registered $hook_suffixes
 *     (no CSS/JS on non-plugin admin pages).
 *   - Handle the dismiss_onboarding AJAX action (per-user, nonce'd,
 *     wp_ajax_ endpoint — never REST).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- admin handlers are registered via wp_ajax_* actions which check nonces internally; nonces are created in corresponding form templates
final class WP_WebMCP_Admin {

	/** Top-level menu slug — also the first child slug. */
	public const PARENT_SLUG = 'webmcp-nexus';

	/** Capability required for every screen. */
	public const CAPABILITY = 'manage_options';

	/**
	 * The 8 screens in spec order. Each row = (slug, screen title,
	 * partial filename). Partial names follow the §5.8 layout filename
	 * pattern from the Step 1 scaffold.
	 *
	 * @var array<int, array{slug:string,title:string,partial:string}>
	 */
	private const SCREENS = array(
		array( 'slug' => 'webmcp-nexus',              'title' => 'Dashboard',      'partial' => 'wp-webmcp-dashboard.php' ),
		array( 'slug' => 'wp-webmcp-tools',         'title' => 'Tool Builder',   'partial' => 'wp-webmcp-tool-builder.php' ),
		array( 'slug' => 'wp-webmcp-analytics',     'title' => 'Analytics',      'partial' => 'wp-webmcp-analytics.php' ),
		array( 'slug' => 'wp-webmcp-log',           'title' => 'Audit Log',      'partial' => 'wp-webmcp-audit-log.php' ),
		array( 'slug' => 'wp-webmcp-agents',        'title' => 'Agents',         'partial' => 'wp-webmcp-agents.php' ),
		array( 'slug' => 'wp-webmcp-policies',      'title' => 'Policies',       'partial' => 'wp-webmcp-policies.php' ),
		array( 'slug' => 'wp-webmcp-exclusions',    'title' => 'Exclusions',     'partial' => 'wp-webmcp-exclusions.php' ),
		array( 'slug' => 'wp-webmcp-access',        'title' => 'Tool Access',    'partial' => 'wp-webmcp-tool-access.php' ),
		array( 'slug' => 'wp-webmcp-import-export', 'title' => 'Import / Export','partial' => 'wp-webmcp-import-export.php' ),
		array( 'slug' => 'wp-webmcp-settings',      'title' => 'Settings',       'partial' => 'wp-webmcp-settings.php' ),
		array( 'slug' => 'wp-webmcp-freshness',     'title' => 'Freshness',      'partial' => 'wp-webmcp-freshness.php' ),
		array( 'slug' => 'wp-webmcp-citation-leaderboard', 'title' => 'Citation Leaderboard', 'partial' => 'wp-webmcp-citation-leaderboard.php' ),
		array( 'slug' => 'wp-webmcp-agent-trace', 'title' => 'Agent Live Trace', 'partial' => 'wp-webmcp-agent-trace.php' ),
		array( 'slug' => 'wp-webmcp-packs',       'title' => 'Tool Packs',       'partial' => 'wp-webmcp-packs.php' ),
	);

	/** The 8 hook_suffixes — populated in register_menus(). */
	private static array $hook_suffixes = array();

	/**
	 * Singleton entry — called from WP_WebMCP::define_admin_hooks().
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'admin_menu',            array( __CLASS__, 'register_menus' ) );
		WP_WebMCP_Loader::register_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_scripts' ) );
		WP_WebMCP_Loader::register_action( 'wp_ajax_wpwebmcp_dismiss_onboarding', array( __CLASS__, 'dismiss_onboarding' ) );
		WP_WebMCP_Loader::register_action( 'wp_ajax_wpwebmcp_apply_preset',       array( __CLASS__, 'ajax_apply_preset' ) );
	}

	/**
	 * Public access to the screen registry — used by the routing + tests.
	 *
	 * @return array<int,array{slug:string,title:string,partial:string}>
	 */
	public static function screens(): array {
		return self::SCREENS;
	}

	/**
	 * @return string[] The 8 hook_suffixes after admin_menu fires.
	 */
	public static function hook_suffixes(): array {
		return self::$hook_suffixes;
	}

	/**
	 * Register the top-level menu + 7 sub-menus.
	 *
	 * Position 58 per Doc §5.3. Icon dashicons-rest-api.
	 * All 8 pages get capability = manage_options.
	 */
	public static function register_menus(): void {
		$parent = self::PARENT_SLUG;

		// Top-level (Dashboard). add_menu_page returns the hook_suffix.
		$first_hook = add_menu_page(
			__( 'WebMCP Nexus', 'webmcp-nexus' ),
			__( 'WebMCP', 'webmcp-nexus' ),
			self::CAPABILITY,
			$parent,
			array( __CLASS__, 'render_screen' ),
			'dashicons-rest-api',
			58
		);
		self::$hook_suffixes[] = (string) $first_hook;

		// Sub-menus for the other screens. Order matters.
		foreach ( array_slice( self::SCREENS, 1 ) as $i => $row ) {
			$hook = add_submenu_page(
				$parent,
				$row['title'],
				$row['title'],
				self::CAPABILITY,
				$row['slug'],
				array( __CLASS__, 'render_screen' )
			);
			if ( false !== $hook ) {
				self::$hook_suffixes[] = (string) $hook;
			}
		}

		// Register aliases as hidden submenu pages so any historical, deep, or REST-provided links never throw "Sorry, you are not allowed to access this page."
		$aliases = array(
			'wp-webmcp-tool-builder' => __( 'Tool Builder', 'webmcp-nexus' ),
			'wp-webmcp'              => __( 'Dashboard', 'webmcp-nexus' ),
			'wp-webmcp-audit-log'    => __( 'Audit Log', 'webmcp-nexus' ),
		);
		foreach ( $aliases as $alias_slug => $alias_title ) {
			$alias_hook = add_submenu_page(
				null,
				$alias_title,
				$alias_title,
				self::CAPABILITY,
				$alias_slug,
				array( __CLASS__, 'render_screen' )
			);
			if ( false !== $alias_hook ) {
				self::$hook_suffixes[] = (string) $alias_hook;
			}
		}

		// Register contextual help tabs for all screens.
		foreach ( self::$hook_suffixes as $hook_suffix ) {
			WP_WebMCP_Loader::register_action( 'load-' . $hook_suffix, array( __CLASS__, 'add_help_tabs' ) );
		}
	}

	/**
	 * Register contextual help tabs on all WebMCP admin screens.
	 */
	public static function add_help_tabs(): void {
		$screen = get_current_screen();
		if ( ! $screen ) {
			return;
		}

		// 1. Universal "What is WebMCP?" Tab
		$screen->add_help_tab(
			array(
				'id'      => 'wpwebmcp-help-overview',
				'title'   => __( 'What is WebMCP?', 'webmcp-nexus' ),
				'content' => '<p><strong>' . esc_html__( 'WebMCP Nexus', 'webmcp-nexus' ) . '</strong> ' .
					esc_html__( 'enables modern Artificial Intelligence (AI) agents — such as ChatGPT, Claude, Google Gemini, Perplexity, Cursor, Copilot, and autonomous agent browsers — to safely discover, understand, and interact with your WordPress site using structured tools and manifests.', 'webmcp-nexus' ) . '</p>' .
					'<p>' . esc_html__( 'Instead of scraping messy HTML or getting confused by JavaScript layouts, AI agents read your site’s standardized Model Context Protocol (MCP) tool schema in the page head, allowing them to accurately answer visitor questions, search your catalog, check real-time stock, and summarize articles with precision.', 'webmcp-nexus' ) . '</p>',
			)
		);

		// 2. Universal "Best Practices & Safety" Tab
		$screen->add_help_tab(
			array(
				'id'      => 'wpwebmcp-help-safety',
				'title'   => __( 'Safety & Permissions', 'webmcp-nexus' ),
				'content' => '<p><strong>' . esc_html__( 'Read vs. Write Tools:', 'webmcp-nexus' ) . '</strong></p>' .
					'<ul>' .
					'<li><strong>' . esc_html__( 'Read Tools (Safe):', 'webmcp-nexus' ) . '</strong> ' . esc_html__( 'Query public information (e.g. searching articles, viewing product prices, reading event dates). These are safe and open to public AI search crawlers.', 'webmcp-nexus' ) . '</li>' .
					'<li><strong>' . esc_html__( 'Write Tools (State-Changing):', 'webmcp-nexus' ) . '</strong> ' . esc_html__( 'Perform actions (e.g. submitting forms, adding items to cart, adding comments). Anonymous users are blocked from write tools by default to protect your site.', 'webmcp-nexus' ) . '</li>' .
					'</ul>' .
					'<p>' . esc_html__( 'You can configure permissions for each user role under the "Tool Access" screen and set request rate limits under "Settings" &rarr; "Rate Limits".', 'webmcp-nexus' ) . '</p>',
			)
		);

		// 3. Screen-specific Help Tab
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( (string) $_GET['page'] ) ) : self::PARENT_SLUG;
		switch ( $page ) {
			case 'webmcp-nexus':
				$screen->add_help_tab(
					array(
						'id'      => 'wpwebmcp-help-dashboard',
						'title'   => __( 'Dashboard Guide', 'webmcp-nexus' ),
						'content' => '<p><strong>' . esc_html__( 'Dashboard Features:', 'webmcp-nexus' ) . '</strong></p>' .
							'<ul>' .
							'<li><strong>' . esc_html__( 'Agent Readiness Score:', 'webmcp-nexus' ) . '</strong> ' . esc_html__( 'Measures how well your site is configured for AI agents. Click "⚡ Run Live Validation" anytime to check your schema compliance.', 'webmcp-nexus' ) . '</li>' .
							'<li><strong>' . esc_html__( 'Interactive Live Playground:', 'webmcp-nexus' ) . '</strong> ' . esc_html__( 'Allows you to simulate how an AI agent interacts with your site. Choose any tool from the dropdown, enter sample parameters, and click "Execute Tool Query" to view the live JSON response.', 'webmcp-nexus' ) . '</li>' .
							'<li><strong>' . esc_html__( 'Engine Toggles:', 'webmcp-nexus' ) . '</strong> ' . esc_html__( 'Quick switches to enable/disable WebMCP sitewide or toggle analytics telemetry.', 'webmcp-nexus' ) . '</li>' .
							'</ul>',
					)
				);
				break;

			case 'wp-webmcp-tools':
				$screen->add_help_tab(
					array(
						'id'      => 'wpwebmcp-help-tools',
						'title'   => __( 'Tool Builder Guide', 'webmcp-nexus' ),
						'content' => '<p><strong>' . esc_html__( 'Creating Custom Tools:', 'webmcp-nexus' ) . '</strong></p>' .
							'<ul>' .
							'<li><strong>' . esc_html__( 'Tool Name:', 'webmcp-nexus' ) . '</strong> ' . esc_html__( 'Use camelCase without spaces (e.g. checkStockStatus, searchKnowledgeBase).', 'webmcp-nexus' ) . '</li>' .
							'<li><strong>' . esc_html__( 'Description:', 'webmcp-nexus' ) . '</strong> ' . esc_html__( 'Explain clearly what the tool does. AI models read this description to decide when to call the tool.', 'webmcp-nexus' ) . '</li>' .
							'<li><strong>' . esc_html__( 'Action Type:', 'webmcp-nexus' ) . '</strong> ' . esc_html__( 'Choose "Navigate" (redirect browser to a page), "Search" (run a site search query), "REST" (forward to an API endpoint), or "Hook" (trigger a WordPress PHP action).', 'webmcp-nexus' ) . '</li>' .
							'</ul>',
					)
				);
				break;

			case 'wp-webmcp-analytics':
				$screen->add_help_tab(
					array(
						'id'      => 'wpwebmcp-help-analytics',
						'title'   => __( 'Analytics & AI Bots Guide', 'webmcp-nexus' ),
						'content' => '<p><strong>' . esc_html__( 'Understanding AI Crawler Traffic:', 'webmcp-nexus' ) . '</strong></p>' .
							'<p>' . esc_html__( 'This screen tracks when AI crawlers (like OpenAI’s GPTBot, Anthropic’s ClaudeBot, Google-Extended, PerplexityBot, and Bytespider) visit your site. Tracking bot visits helps you understand which pages are being cited and digested by modern AI search engines.', 'webmcp-nexus' ) . '</p>',
					)
				);
				break;

			case 'wp-webmcp-log':
				$screen->add_help_tab(
					array(
						'id'      => 'wpwebmcp-help-log',
						'title'   => __( 'Audit Log Guide', 'webmcp-nexus' ),
						'content' => '<p><strong>' . esc_html__( 'Monitoring Agent Calls:', 'webmcp-nexus' ) . '</strong></p>' .
							'<p>' . esc_html__( 'Every time an AI agent or visitor executes a WebMCP tool, the request is recorded here with timestamp, tool name, execution latency (in milliseconds), user role, and status (Success, Error, Rate Limited, or Auth Failed). You can filter logs or export them to CSV.', 'webmcp-nexus' ) . '</p>',
					)
				);
				break;

			case 'wp-webmcp-agents':
				$screen->add_help_tab(
					array(
						'id'      => 'wpwebmcp-help-agents',
						'title'   => __( 'Agents Guide', 'webmcp-nexus' ),
						'content' => '<p><strong>' . esc_html__( 'Agent Identity (M0c):', 'webmcp-nexus' ) . '</strong> ' .
							esc_html__( 'Each tool call is tagged with the resolved calling agent (GPTBot, ClaudeBot, ChatGPT-User, Claude-User, Perplexity, Google-Extended, etc.) via User-Agent + IP CIDR + reverse-DNS verification. Every WebMCP REST response carries an X-WebMCP-Agent-Resolved header so agents can audit how they were identified.', 'webmcp-nexus' ) . '</p>' .
							'<p>' . esc_html__( 'Per-agent toggles let you disable a noisy bot or set a tighter per-minute cap than the global rate limit. Per-agent caps are independent buckets, so a polite agent never gets blocked because another agent exhausted the global budget.', 'webmcp-nexus' ) . '</p>' .
							'<p>' . esc_html__( 'The blocklist rejects any caller whose User-Agent contains the listed substring (case-insensitive) with HTTP 403 before rate-limit / audit even run.', 'webmcp-nexus' ) . '</p>',
					)
				);
				break;

			case 'wp-webmcp-policies':
				$screen->add_help_tab(
					array(
						'id'      => 'wpwebmcp-help-policies',
						'title'   => __( 'Policies Guide', 'webmcp-nexus' ),
						'content' => '<p><strong>' . esc_html__( 'Visual policy builder (A2a):', 'webmcp-nexus' ) . '</strong></p>' .
							'<p>' . esc_html__( 'Rules are evaluated in priority order (lowest priority value wins). The first matching rule decides the outcome for the tool call.', 'webmcp-nexus' ) . '</p>' .
							'<p>' . esc_html__( 'Match clauses: All (catch-all), Agent slug (e.g., gptbot), Agent family (e.g., gpt), Unknown agent (unidentified callers), Blocked agent (per-agent toggles set to disabled in the Agents page).', 'webmcp-nexus' ) . '</p>' .
							'<p>' . esc_html__( 'Actions: Allow (pass-through), Block (returns HTTP 403 with the custom message + claim-flow link), Rate-limit (returns HTTP 429 with per-minute cap), Redact email (pass-through but strips email addresses from the response).', 'webmcp-nexus' ) . '</p>' .
							'<p>' . esc_html__( 'Common presets: GPTBot → redact_email (read-only). ClaudeBot → allow. unknown_agent → rate_limit @ 30/min. blocked_agent → block.', 'webmcp-nexus' ) . '</p>',
					)
				);
				break;

			case 'wp-webmcp-exclusions':
				$screen->add_help_tab(
					array(
						'id'      => 'wpwebmcp-help-exclusions',
						'title'   => __( 'Exclusions Guide', 'webmcp-nexus' ),
						'content' => '<p><strong>' . esc_html__( 'Hiding Content from AI Agents:', 'webmcp-nexus' ) . '</strong></p>' .
							'<p>' . esc_html__( 'Use this screen to exclude specific posts, pages, or categories from having WebMCP agent manifests injected. This is ideal for private pages, thank-you pages, member-only areas, or internal documents.', 'webmcp-nexus' ) . '</p>',
					)
				);
				break;

			case 'wp-webmcp-access':
				$screen->add_help_tab(
					array(
						'id'      => 'wpwebmcp-help-access',
						'title'   => __( 'Tool Access Matrix Guide', 'webmcp-nexus' ),
						'content' => '<p><strong>' . esc_html__( 'Configuring Role Permissions:', 'webmcp-nexus' ) . '</strong></p>' .
							'<p>' . esc_html__( 'Control which user roles have permission to execute Read and Write tools. For maximum security, anonymous visitors cannot execute Write tools.', 'webmcp-nexus' ) . '</p>',
					)
				);
				break;

			case 'wp-webmcp-import-export':
				$screen->add_help_tab(
					array(
						'id'      => 'wpwebmcp-help-import-export',
						'title'   => __( 'Import / Export Guide', 'webmcp-nexus' ),
						'content' => '<p><strong>' . esc_html__( 'Backups & Migration:', 'webmcp-nexus' ) . '</strong></p>' .
							'<p>' . esc_html__( 'Export your entire WebMCP Nexus configuration to a JSON snapshot file for safe keeping or migrating between staging and live servers. Before any import is performed, an automatic backup snapshot is stored automatically.', 'webmcp-nexus' ) . '</p>',
					)
				);
				break;

			case 'wp-webmcp-settings':
				$screen->add_help_tab(
					array(
						'id'      => 'wpwebmcp-help-settings',
						'title'   => __( 'Settings Guide', 'webmcp-nexus' ),
						'content' => '<p><strong>' . esc_html__( 'Configuring WebMCP Nexus:', 'webmcp-nexus' ) . '</strong></p>' .
							'<p>' . esc_html__( 'Configure sitewide behavior across 6 sections: General settings, Sandbox & failure alerts, Rate limiting rules, Crawler & GA4 integrations, Privacy/GDPR data retention, and Advanced protocol features (llms.txt, Markdown endpoints, and DB optimization).', 'webmcp-nexus' ) . '</p>',
					)
				);
				break;

			case 'wp-webmcp-freshness':
				$screen->add_help_tab(
					array(
						'id'      => 'wpwebmcp-help-freshness',
						'title'   => __( 'Freshness Guide', 'webmcp-nexus' ),
						'content' => '<p><strong>' . esc_html__( 'Freshness ping protocol (A1c):', 'webmcp-nexus' ) . '</strong></p>' .
							'<p>' . esc_html__( 'Whenever a post is published, updated, or deleted, the URL is enqueued and submitted to IndexNow (Bing, Yandex, Seznam, Naver) within 5 minutes. Agents holding the SSE connection also receive a content_updated event in near real time so they can drop cached versions of the page.', 'webmcp-nexus' ) . '</p>' .
							'<p>' . esc_html__( 'Generate an IndexNow key at indexnow.org, paste it here, and upload <code>&lt;key&gt;.txt</code> to your site root. The endpoint defaults to https://api.indexnow.org/indexnow which fans out automatically.', 'webmcp-nexus' ) . '</p>',
					)
				);
				break;

			case 'wp-webmcp-citation-leaderboard':
				$screen->add_help_tab(
					array(
						'id'      => 'wpwebmcp-help-citation-leaderboard',
						'title'   => __( 'Citation Leaderboard Guide', 'webmcp-nexus' ),
						'content' => '<p><strong>' . esc_html__( 'Citation leaderboard (A1d):', 'webmcp-nexus' ) . '</strong></p>' .
							'<p>' . esc_html__( 'Ranks every canonical AI agent by real signals pulled from existing tables. Tool calls come from the audit log (wpwebmcp_log) and bot visits from the bot log (wpwebmcp_bot_log). No sample rows; if the tables are empty the dashboard shows the empty state.', 'webmcp-nexus' ) . '</p>' .
							'<p>' . esc_html__( 'JSON snapshot endpoint: /wp-json/wpwebmcp/v1/citation-leaderboard (public read).', 'webmcp-nexus' ) . '</p>',
					)
				);
				break;
		}

		$screen->set_help_sidebar(
			'<p><strong>' . esc_html__( 'Need Help?', 'webmcp-nexus' ) . '</strong></p>' .
			'<p><a href="' . esc_url( home_url( '/?webmcp_inspect=1' ) ) . '" target="_blank">' . esc_html__( 'Live Frontend Inspector', 'webmcp-nexus' ) . '</a></p>' .
			'<p><a href="' . esc_url( rest_url( 'wpwebmcp/v1/manifest' ) ) . '" target="_blank">' . esc_html__( 'View Live Manifest JSON', 'webmcp-nexus' ) . '</a></p>' .
			'<p><a href="' . esc_url( home_url( '/llms.txt' ) ) . '" target="_blank">' . esc_html__( 'View /llms.txt', 'webmcp-nexus' ) . '</a></p>'
		);
	}

	/**
	 * Render the screen body by including the matching partial.
	 *
	 * Hooked as page-rendering callback; we resolve the current screen
	 * from the `page` GET param (more reliable than GLOBALS in some
	 * setups) and load the partial directly. Direct include (not
	 * locate_template) so we know the file we render.
	 */
	public static function render_screen(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'webmcp-nexus' ) );
		}

		// A2b diagnostic: ?action=set_exposure_tier&post_id=14&tier=cited
		// admin-only URL handler used to flip a post's exposure tier without
		// having to go through the Gutenberg meta box. Useful for scripting
		// the 3-tier gate test from the address bar.
		if ( isset( $_GET['action'] ) && 'set_exposure_tier' === sanitize_key( wp_unslash( (string) $_GET['action'] ) ) ) {
			if ( class_exists( 'WP_WebMCP_Exposure_Tier' ) ) {
				$pid  = isset( $_GET['post_id'] ) ? absint( wp_unslash( (string) $_GET['post_id'] ) ) : 0;
				$tier = isset( $_GET['tier'] ) ? sanitize_key( wp_unslash( (string) $_GET['tier'] ) ) : 'public';
				if ( $pid > 0 && in_array( $tier, WP_WebMCP_Exposure_Tier::allowed_tiers(), true ) ) {
					WP_WebMCP_Exposure_Tier::set_tier( $pid, $tier );
					wp_die(
						sprintf(
							'<h1>%s</h1><p>%s</p><p><a href="%s">%s</a></p>',
							esc_html__( 'Exposure tier updated', 'webmcp-nexus' ),
							esc_html( sprintf( 'Post %1$d is now tier "%2$s".', $pid, $tier ) ),
							esc_url( admin_url( 'admin.php?page=wp-webmcp' ) ),
							esc_html__( 'Back to Dashboard', 'webmcp-nexus' )
						)
					);
				}
			}
		}

		// Resolve which screen we are on, normalizing aliases.
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( (string) $_GET['page'] ) ) : self::PARENT_SLUG;
		if ( 'wp-webmcp-tool-builder' === $page ) {
			$page = 'wp-webmcp-tools';
		} elseif ( 'wp-webmcp' === $page ) {
			$page = 'webmcp-nexus';
		} elseif ( 'wp-webmcp-audit-log' === $page ) {
			$page = 'wp-webmcp-log';
		}

		$row = null;
		foreach ( self::SCREENS as $candidate ) {
			if ( $candidate['slug'] === $page ) {
				$row = $candidate;
				break;
			}
		}
		if ( null === $row ) {
			$row = self::SCREENS[0];
		}

		// The wrapper — header + title row + notice area. Per §5.8
		// "every screen: .wpwm-wrap max-width 1200px, screen title row
		// (H1 + primary action right), notice area below title".
		echo '<div class="wrap wpwm-wrap">';
		echo '<h1 class="wp-heading-inline wpwm-screen-title">' . esc_html( $row['title'] ) . '</h1>';
		echo '<hr class="wpwm-divider">';
		echo '<div class="wpwm-notices">';
		settings_errors( 'wpwebmcp' );
		echo '</div>';

		$partial = WEBMCP_NEXUS_PATH . 'admin/partials/' . $row['partial'];
		// M0c: the Agents page has its own save handler + scoped variables
		// (registry, settings, blocklist, call counts), so route it through
		// the dedicated page handler instead of including a bare partial.
		if ( 'wp-webmcp-agents' === $page && class_exists( 'WP_WebMCP_Agents_Page' ) ) {
			WP_WebMCP_Agents_Page::render();
			echo '</div>'; // close the wrapper opened above.
			return;
		}
		// A2a: visual policy builder — dedicated page handler for save/delete.
		if ( 'wp-webmcp-policies' === $page && class_exists( 'WP_WebMCP_Policies_Page' ) ) {
			WP_WebMCP_Policies_Page::render();
			echo '</div>';
			return;
		}
		// A1c: freshness ping protocol — dedicated page handler.
		if ( 'wp-webmcp-freshness' === $page && class_exists( 'WP_WebMCP_Freshness_Page' ) ) {
			WP_WebMCP_Freshness_Page::render();
			echo '</div>';
			return;
		}
		// A1d: citation leaderboard — dedicated page handler.
		if ( 'wp-webmcp-citation-leaderboard' === $page && class_exists( 'WP_WebMCP_Citation_Leaderboard_Page' ) ) {
			WP_WebMCP_Citation_Leaderboard_Page::render();
			echo '</div>';
			return;
		}
		if ( file_exists( $partial ) ) {
			/** @noinspection PhpIncludeInspection */
			include $partial;
		} else {
			echo '<div class="wpwm-empty"><p>' . esc_html__( 'Screen partial missing.', 'webmcp-nexus' ) . '</p></div>';
		}

		echo '</div>';
	}

	/**
	 * Enqueue admin CSS + JS ONLY on plugin screens.
	 *
	 * $hook_suffix is the second arg of admin_enqueue_scripts. The 8
	 * registered hooks are tracked in self::$hook_suffixes (filled in
	 * register_menus). For any other admin page we skip enqueue entirely
	 * so we don't pay the cost of a stylesheet on Posts/Pages/Settings.
	 */
	public static function enqueue_admin_scripts( string $hook_suffix ): void {
		$screen           = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		$screen_id        = $screen ? (string) $screen->id : '';
		$page             = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( (string) $_GET['page'] ) ) : '';
		$is_plugin_screen = in_array( $hook_suffix, self::$hook_suffixes, true )
			|| ( false !== strpos( $screen_id, 'wp-webmcp' ) )
			|| ( false !== strpos( $screen_id, 'webmcp-nexus' ) )
			|| ( 0 === strpos( $page, 'wp-webmcp' ) )
			|| ( 'webmcp-nexus' === $page );

		// Even non-plugin-screen requests can short-circuit fast.
		if ( ! $is_plugin_screen ) {
			return;
		}

		wp_enqueue_style(
			'wp-webmcp-admin',
			WEBMCP_NEXUS_URL . 'admin/css/wp-webmcp-admin.css',
			array(),
			WEBMCP_NEXUS_VERSION
		);

		// Chart.js is enqueued ONLY on Analytics (Step 11 owns the
		// enqueue + boot). We do not register the asset here to avoid
		// a second HTTP request on every other screen. The vendored
		// file lives at admin/lib/chart.min.js.
		if ( false !== strpos( $hook_suffix, 'analytics' ) ) {
			// Intentionally not enqueued — Step 11 owns this.
		}

		wp_enqueue_script(
			'wp-webmcp-admin',
			WEBMCP_NEXUS_URL . 'admin/js/wp-webmcp-admin.js',
			array(),
			WEBMCP_NEXUS_VERSION,
			true
		);

		// Localize keys per Doc §5.9 (ajaxurl + nonce + restUrl + restNonce).
		$localized_data = array(
			'ajaxurl'              => admin_url( 'admin-ajax.php' ),
			'wpwebmcp_admin_nonce' => wp_create_nonce( 'wpwebmcp_admin_nonce' ),
			'restUrl'              => rest_url( 'wpwebmcp/v1/' ),
			'restNonce'            => wp_create_nonce( 'wp_rest' ),
		);
		wp_localize_script( 'wp-webmcp-admin', 'WPWEBMCP_ADMIN', $localized_data );
		wp_localize_script( 'wp-webmcp-admin', 'WEBMCP_NEXUS_ADMIN', $localized_data );
	}

	/**
	 * AJAX: dismiss the onboarding checklist.
	 *
	 * Per Doc §5.5 C12: per-user, nonce wpwebmcp_admin_nonce,
	 * sets user meta wpwebmcp_onboarding_dismissed=1. NEVER a REST route.
	 */
	public static function dismiss_onboarding(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_send_json_error( array( 'code' => 'forbidden' ), 403 );
		}
		check_ajax_referer( 'wpwebmcp_admin_nonce', 'nonce' );

		$user_id = get_current_user_id();
		if ( $user_id <= 0 ) {
			wp_send_json_error( array( 'code' => 'no_user' ), 400 );
		}

		update_user_meta( $user_id, 'wpwebmcp_onboarding_dismissed', 1 );
		wp_send_json_success( array( 'dismissed' => true, 'user_id' => $user_id ) );
	}

	/**
	 * AJAX: 1-click apply Done-For-You (DFY) industry preset.
	 */
	public static function ajax_apply_preset(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => 'Unauthorized' ), 403 );
		}
		check_ajax_referer( 'wpwebmcp_admin_nonce', 'nonce' );

		$preset = isset( $_POST['preset'] ) ? sanitize_key( (string) wp_unslash( $_POST['preset'] ) ) : '';
		if ( class_exists( 'WP_WebMCP_Presets' ) && WP_WebMCP_Presets::apply_preset( $preset ) ) {
			/* translators: %s: Preset suite name */
			$wpwebmcp_activated_label = sprintf( __( 'Activated %s preset suite successfully!', 'webmcp-nexus' ), strtoupper( $preset ) );
			wp_send_json_success(
				array(
					'preset'  => $preset,
					'message' => $wpwebmcp_activated_label,
				)
			);
		}

		wp_send_json_error( array( 'message' => __( 'Invalid preset selected.', 'webmcp-nexus' ) ), 400 );
	}
}