<?php
/**
 * Agents admin page (M0c) — handler for the WP_WebMCP_Admin router.
 *
 * This page is wired via the SCREENS list in WP_WebMCP_Admin. It owns:
 *   - The Settings/POST save roundtrip for per-agent toggles + the blocklist.
 *   - Rendering the partial `admin/partials/wp-webmcp-agents.php`.
 *
 * Capability: manage_options (per the SCREENS registration).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- admin page handler; nonce is created in the corresponding form partial; $_SERVER/$_POST reads are followed by wp_verify_nonce or sanitize_text_field in the actual handler bodies
final class WP_WebMCP_Agents_Page {

	/**
	 * Nonce action for the per-agent form submission.
	 */
	private const NONCE_ACTION = 'wpwebmcp_agents_save';

	/**
	 * Option key (kept here for symmetry with the partial).
	 */
	public const OPTION_SETTINGS  = 'wpwebmcp_agent_settings';
	public const OPTION_BLOCKLIST = 'wpwebmcp_agent_blocklist';

	/**
	 * Entry point — invoked by the Admin router when `page=wp-webmcp-agents`.
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'webmcp-nexus' ) );
		}

		$notice = self::maybe_handle_save();
		$partial = WEBMCP_NEXUS_PATH . 'admin/partials/wp-webmcp-agents.php';
		if ( ! file_exists( $partial ) ) {
			wp_die( esc_html__( 'Agents page partial is missing.', 'webmcp-nexus' ) );
		}

		$registry       = class_exists( 'WP_WebMCP_Agent_Identity' ) ? WP_WebMCP_Agent_Identity::registry() : array();
		$settings       = (array) get_option( self::OPTION_SETTINGS, array() );
		$blocklist      = (array) get_option( self::OPTION_BLOCKLIST, array() );
		$identity_on    = (bool) get_option( 'wpwebmcp_agent_identity_enabled', true );
		$call_counts    = class_exists( 'WP_WebMCP_Log_Repository' ) ? WP_WebMCP_Log_Repository::counts_by_agent() : array();
		$last_seen_map  = class_exists( 'WP_WebMCP_Log_Repository' ) ? WP_WebMCP_Log_Repository::last_seen_by_agent() : array();

		include $partial;
	}

	/**
	 * Handle the POST save roundtrip.
	 *
	 * @return string|null Updated notice key ('saved'|'invalid_nonce') or null when no save.
	 */
	private static function maybe_handle_save(): ?string {
		$req_method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : '';
		if ( 'POST' !== $req_method ) {
			return null;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return null;
		}

		$nonce = isset( $_POST['wpwebmcp_agents_nonce'] )
			? sanitize_text_field( (string) wp_unslash( $_POST['wpwebmcp_agents_nonce'] ) )
			: '';
		if ( '' === $nonce || ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			return 'invalid_nonce';
		}

		// Master toggle.
		$identity_on = ! empty( $_POST['wpwebmcp_agent_identity_enabled'] );
		update_option( 'wpwebmcp_agent_identity_enabled', $identity_on );

		// Per-agent settings — sanitize the incoming array.
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Array values are individually validated and sanitized in the loop below.
		$raw_settings = isset( $_POST['wpwebmcp_agent_settings'] ) && is_array( $_POST['wpwebmcp_agent_settings'] )
			? (array) wp_unslash( $_POST['wpwebmcp_agent_settings'] )
			: array();
		$clean = array();
		foreach ( $raw_settings as $slug => $row ) {
			if ( ! is_string( $slug ) || '' === $slug ) {
				continue;
			}
			$slug_clean = strtolower( preg_replace( '/[^a-z0-9_\-]/', '', strtolower( $slug ) ) ?? '' );
			if ( '' === $slug_clean ) {
				continue;
			}
			if ( ! is_array( $row ) ) {
				continue;
			}
			$clean[ $slug_clean ] = array(
				'enabled'          => isset( $row['enabled'] ) ? (bool) (int) $row['enabled'] : false,
				'per_minute_limit' => isset( $row['per_minute_limit'] ) ? max( 0, (int) $row['per_minute_limit'] ) : 0,
			);
		}
		update_option( self::OPTION_SETTINGS, $clean );

		// Blocklist — split on newlines + commas, trim, dedupe.
		$raw_block = isset( $_POST['wpwebmcp_agent_blocklist'] )
			? sanitize_textarea_field( wp_unslash( $_POST['wpwebmcp_agent_blocklist'] ) )
			: '';
		$fragments = preg_split( '/[\r\n,]+/', $raw_block ) ?: array();
		$out = array();
		foreach ( $fragments as $frag ) {
			$f = strtolower( trim( (string) $frag ) );
			if ( '' !== $f && strlen( $f ) <= 100 ) {
				$out[] = $f;
			}
		}
		update_option( self::OPTION_BLOCKLIST, array_values( array_unique( $out ) ) );

		return 'saved';
	}

	/**
	 * Build the nonce field for inclusion in the partial.
	 *
	 * @return string
	 */
	public static function nonce_field(): string {
		return wp_nonce_field( self::NONCE_ACTION, 'wpwebmcp_agents_nonce', true, false );
	}
	// phpcs:enable WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
}