<?php
/**
 * Admin handler for the Citation leaderboard (A1d).
 *
 * Thin pass-through: queries WP_WebMCP_Citation_Leaderboard for real
 * data and hands the result to the partial. No mocks, no fallbacks.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Citation_Leaderboard_Page {

	/** Page slug — must match SCREENS in WP_WebMCP_Admin. */
	public const SLUG = 'wp-webmcp-citation-leaderboard';

	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'webmcp-nexus' ) );
		}
		if ( ! class_exists( 'WP_WebMCP_Citation_Leaderboard' ) ) {
			echo '<div class="wrap"><h1>Citation Leaderboard</h1><p>' .
				esc_html__( 'Citation leaderboard class not loaded.', 'webmcp-nexus' ) .
				'</p></div>';
			return;
		}

		$rows        = WP_WebMCP_Citation_Leaderboard::get_rows();
		$totals      = WP_WebMCP_Citation_Leaderboard::get_totals( 30 );
		$recent_visits = WP_WebMCP_Citation_Leaderboard::get_recent_citations( 20 );
		$recent_calls  = WP_WebMCP_Citation_Leaderboard::get_recent_tool_calls( 20 );
		$generated_at = gmdate( 'c' );

		include WEBMCP_NEXUS_PATH . 'admin/partials/wp-webmcp-citation-leaderboard.php';
	}
}
