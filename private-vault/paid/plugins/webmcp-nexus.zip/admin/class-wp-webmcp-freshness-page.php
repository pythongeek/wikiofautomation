<?php
/**
 * Admin handler for the Freshness ping protocol (A1c).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Freshness_Page {

	/** Page slug — matches the admin URL used by SCREENS in WP_WebMCP_Admin. */
	public const SLUG = 'wp-webmcp-freshness';

	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'webmcp-nexus' ) );
		}
		$enabled  = WP_WebMCP_Freshness_Pinger::is_enabled();
		$key      = WP_WebMCP_Freshness_Pinger::get_key();
		$endpoint = WP_WebMCP_Freshness_Pinger::get_endpoint();
		$queue    = WP_WebMCP_Freshness_Pinger::get_queue_count();
		$stats    = WP_WebMCP_Freshness_Pinger::get_stats();
		$log      = WP_WebMCP_Freshness_Pinger::get_log( 25 );
		$host     = wp_parse_url( home_url(), PHP_URL_HOST );

		include WEBMCP_NEXUS_PATH . 'admin/partials/wp-webmcp-freshness.php';
	}
}
