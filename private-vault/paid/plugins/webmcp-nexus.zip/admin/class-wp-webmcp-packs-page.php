<?php
/**
 * Packs_Page — admin page handler for the Tool Packs screen.
 *
 * Reads installed + available packs from WP_WebMCP_Pack_Registry and exposes
 * helper methods used by the partial (wp-webmcp-packs.php).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- nonce verified at admin-post entry via check_admin_referer() in handle_install()/handle_uninstall() which is called before this method
final class WP_WebMCP_Packs_Page {

	/**
	 * List installed packs. Returns [] if SDK not loaded.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function installed(): array {
		if ( ! class_exists( 'WP_WebMCP_Pack_Registry' ) ) {
			return array();
		}
		return WP_WebMCP_Pack_Registry::list_installed();
	}

	/**
	 * List available (on-disk but not installed) packs.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function available(): array {
		if ( ! class_exists( 'WP_WebMCP_Pack_Registry' ) ) {
			return array();
		}
		return WP_WebMCP_Pack_Registry::list_available();
	}

	/**
	 * Get the install REST URL (admin-relative).
	 */
	public static function install_url( string $slug ): string {
		return wp_nonce_url(
			add_query_arg(
				array(
					'action' => 'wpwebmcp_install_pack',
					'slug'   => $slug,
				),
				admin_url( 'admin-post.php' )
			),
			'wpwebmcp_install_pack_' . $slug
		);
	}

	/**
	 * Get the uninstall REST URL (admin-relative).
	 */
	public static function uninstall_url( string $slug ): string {
		return wp_nonce_url(
			add_query_arg(
				array(
					'action' => 'wpwebmcp_uninstall_pack',
					'slug'   => $slug,
				),
				admin_url( 'admin-post.php' )
			),
			'wpwebmcp_uninstall_pack_' . $slug
		);
	}

	/**
	 * Admin-post handler: install a pack.
	 */
	public static function handle_install(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'webmcp-nexus' ) );
		}
		$slug = isset( $_GET['slug'] ) ? sanitize_key( wp_unslash( $_GET['slug'] ) ) : '';
		check_admin_referer( 'wpwebmcp_install_pack_' . $slug );

		$result = WP_WebMCP_Pack_Registry::install( $slug );

		$redirect = add_query_arg(
			array(
				'page' => 'wp-webmcp-packs',
				'install' => $result['ok'] ? 'ok' : 'err',
				'install_msg' => $result['ok'] ? sprintf( 'Installed %s.', $slug ) : (string) $result['error'],
			),
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Admin-post handler: uninstall a pack.
	 */
	public static function handle_uninstall(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'webmcp-nexus' ) );
		}
		$slug = isset( $_GET['slug'] ) ? sanitize_key( wp_unslash( $_GET['slug'] ) ) : '';
		check_admin_referer( 'wpwebmcp_uninstall_pack_' . $slug );

		$result = WP_WebMCP_Pack_Registry::uninstall( $slug );

		$redirect = add_query_arg(
			array(
				'page' => 'wp-webmcp-packs',
				'uninstall' => $result['ok'] ? 'ok' : 'err',
				'uninstall_msg' => $result['ok'] ? sprintf( 'Uninstalled %s.', $slug ) : (string) $result['error'],
			),
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Register admin-post handlers + admin notice for the result.
	 */
	public static function register(): void {
		add_action( 'admin_post_wpwebmcp_install_pack', array( self::class, 'handle_install' ) );
		add_action( 'admin_post_wpwebmcp_uninstall_pack', array( self::class, 'handle_uninstall' ) );
		add_action( 'admin_notices', array( self::class, 'maybe_print_notice' ) );
	}

	public static function maybe_print_notice(): void {
		if ( ! isset( $_GET['page'] ) || 'wp-webmcp-packs' !== $_GET['page'] ) {
			return;
		}
		if ( isset( $_GET['install'] ) ) {
			$ok  = 'ok' === $_GET['install'];
			$msg = isset( $_GET['install_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['install_msg'] ) ) : '';
			printf(
				'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
				esc_attr( $ok ? 'success' : 'error' ),
				esc_html( $msg )
			);
		}
		if ( isset( $_GET['uninstall'] ) ) {
			$ok  = 'ok' === $_GET['uninstall'];
			$msg = isset( $_GET['uninstall_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['uninstall_msg'] ) ) : '';
			printf(
				'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
				esc_attr( $ok ? 'success' : 'error' ),
				esc_html( $msg )
			);
		}
	}
// phpcs:enable WordPress.Security.NonceVerification.Recommended
}
