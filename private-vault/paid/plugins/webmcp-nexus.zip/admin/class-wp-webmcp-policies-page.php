<?php
/**
 * Policies admin page (A2a — visual policy builder).
 *
 * Handler for the WP_WebMCP_Admin router when `page=wp-webmcp-policies`.
 * Owns:
 *   - The POST save roundtrip (add / update / delete policies).
 *   - Rendering the partial `admin/partials/wp-webmcp-policies.php`.
 *
 * Capability: manage_options (per the SCREENS registration).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- admin page handler; nonce is created in the corresponding form partial; $_SERVER/$_POST reads are followed by wp_verify_nonce or sanitize_text_field in the actual handler bodies
final class WP_WebMCP_Policies_Page {

	private const NONCE_ACTION = 'wpwebmcp_policies_save';

	public const OPTION_KEY = 'wpwebmcp_policies';

	/**
 * Invoked by the Admin router.
 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'webmcp-nexus' ) );
		}

		$wpwebmcp_notice = self::maybe_handle_save();

		$wpwebmcp_policies = class_exists( 'WP_WebMCP_Policy' ) ? WP_WebMCP_Policy::all() : array();
		$policies = $wpwebmcp_policies; // F2 D1: partial contract for the Active policies list.
		$sets     = class_exists( 'WP_WebMCP_Policy' ) ? WP_WebMCP_Policy::option_sets() : array(
			'match_types' => array(),
			'actions'     => array(),
		);
		$presets           = self::preset_summary();
		$preset_apply_map  = array();
		$preset_counts     = array();
		foreach ( $presets as $preset ) {
			$slug = isset( $preset['slug'] ) ? (string) $preset['slug'] : '';
			if ( '' !== $slug ) {
				$preset_apply_map[ $slug ] = self::is_preset_applied( $slug );
				$preset_counts[ $slug ] = self::preset_row_count( $slug );
			}
		}
		$editing  = null;
		if ( isset( $_GET['edit'] ) ) {
			$edit_id = sanitize_text_field( (string) wp_unslash( $_GET['edit'] ) );
			foreach ( $wpwebmcp_policies as $p ) {
				if ( isset( $p['id'] ) && (string) $p['id'] === $edit_id ) {
					$editing = $p;
					break;
				}
			}
		}

		$partial = WEBMCP_NEXUS_PATH . 'admin/partials/wp-webmcp-policies.php';
		if ( ! file_exists( $partial ) ) {
			wp_die( esc_html__( 'Policies page partial is missing.', 'webmcp-nexus' ) );
		}

		include $partial;
	}

	/**
 * Handle POST save roundtrip + GET delete via URL handler.
 *
 * @return string|null Notice key ('saved'|'deleted'|'invalid_nonce'|'save_error')
 */
	private static function maybe_handle_save(): ?string {
		// POST: add / update policy.
		if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) ) {
			if ( ! current_user_can( 'manage_options' ) ) {
				return null;
			}
			$nonce = isset( $_POST['wpwebmcp_policies_nonce'] )
				? sanitize_text_field( (string) wp_unslash( $_POST['wpwebmcp_policies_nonce'] ) )
				: '';
			if ( '' === $nonce || ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
				return 'invalid_nonce';
			}
			if ( ! class_exists( 'WP_WebMCP_Policy' ) ) {
				return 'save_error';
			}
			$input  = array(
				'id'                    => isset( $_POST['id'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['id'] ) ) : '',
				'name'                  => isset( $_POST['name'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['name'] ) ) : '',
				'enabled'               => isset( $_POST['enabled'] ) ? 1 : 0,
				'priority'              => isset( $_POST['priority'] ) ? (int) $_POST['priority'] : 100,
				'match_type'            => isset( $_POST['match_type'] ) ? sanitize_key( (string) wp_unslash( $_POST['match_type'] ) ) : 'all',
				'match_value'           => isset( $_POST['match_value'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['match_value'] ) ) : '',
				'action'                => isset( $_POST['action'] ) ? sanitize_key( (string) wp_unslash( $_POST['action'] ) ) : 'allow',
				'rate_limit_per_minute' => isset( $_POST['rate_limit_per_minute'] ) ? (int) $_POST['rate_limit_per_minute'] : 0,
				'custom_message'        => isset( $_POST['custom_message'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['custom_message'] ) ) : '',
				'redact_email'          => isset( $_POST['redact_email'] ) ? 1 : 0,
			);
			$saved = WP_WebMCP_Policy::save( $input );
			if ( is_wp_error( $saved ) ) {
				return 'save_error';
			}
			return 'saved';
		}

		// GET: delete policy via URL handler.
		if ( isset( $_GET['action'] ) && 'delete_policy' === sanitize_key( wp_unslash( (string) $_GET['action'] ) ) ) {
			if ( ! current_user_can( 'manage_options' ) ) {
				return null;
			}
			$nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['_wpnonce'] ) ) : '';
			if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'wpwebmcp_delete_policy' ) ) {
				return 'invalid_nonce';
			}
			if ( ! class_exists( 'WP_WebMCP_Policy' ) ) {
				return null;
			}
			$id = isset( $_GET['id'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['id'] ) ) : '';
			if ( '' !== $id ) {
				WP_WebMCP_Policy::delete( $id );
				return 'deleted';
			}
		}

		// GET: seed 3 sample policies (allow + redact_email, block, rate_limit)
		// for live verification of A2a actions. Used during build verification.
		if ( isset( $_GET['action'] ) && 'seed_test_policies' === sanitize_key( wp_unslash( (string) $_GET['action'] ) ) ) {
			if ( ! current_user_can( 'manage_options' ) ) {
				return null;
			}
			$nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['_wpnonce'] ) ) : '';
			if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'wpwebmcp_seed_test_policies' ) ) {
				return 'invalid_nonce';
			}
			if ( ! class_exists( 'WP_WebMCP_Policy' ) ) {
				return null;
			}
			$samples = array(
				array(
					'name'           => 'Block fake agent "Scrapebot"',
					'priority'       => 10,
					'match_type'     => WP_WebMCP_Policy::MATCH_AGENT_SLUG,
					'match_value'    => 'scrapebot',
					'action'         => WP_WebMCP_Policy::ACTION_BLOCK,
					'custom_message' => 'Scrapebot is blocked from accessing WebMCP tools. If you operate this bot, contact the site owner to negotiate access.',
				),
				array(
					'name'                  => 'Rate-limit unknown agents @ 5/min',
					'priority'              => 20,
					'match_type'            => WP_WebMCP_Policy::MATCH_UNKNOWN_AGENT,
					'action'                => WP_WebMCP_Policy::ACTION_RATE_LIMIT,
					'rate_limit_per_minute' => 5,
				),
				array(
					'name'         => 'Always redact emails for GPTBot',
					'priority'     => 30,
					'match_type'   => WP_WebMCP_Policy::MATCH_AGENT_FAMILY,
					'match_value'  => 'openai',
					'action'       => WP_WebMCP_Policy::ACTION_REDACT_EMAIL,
					'redact_email' => 1,
				),
			);
			$existing_names = array();
			foreach ( WP_WebMCP_Policy::all() as $row ) {
				if ( isset( $row['name'] ) && is_string( $row['name'] ) ) {
					$existing_names[] = (string) $row['name'];
				}
			}
			$wpwebmcp_created = 0;
			$wpwebmcp_skipped = 0;
			foreach ( $samples as $sample ) {
				if ( in_array( (string) $sample['name'], $existing_names, true ) ) {
					++$wpwebmcp_skipped;
					continue;
				}
				WP_WebMCP_Policy::save( $sample );
				++$wpwebmcp_created;
			}
			wp_safe_redirect( add_query_arg( array( 'page' => 'wp-webmcp-policies', 'notice' => 'seeded_' . $wpwebmcp_created . '_' . $wpwebmcp_skipped ), admin_url( 'admin.php' ) ) );
			exit;
		}

		// GET: remove duplicate policy rules (F2 D3). Keeps the first-stored
		// (oldest) row per (name, match_type, match_value) tuple.
		if ( isset( $_GET['action'] ) && 'dedupe_policies' === sanitize_key( wp_unslash( (string) $_GET['action'] ) ) ) {
			if ( ! current_user_can( 'manage_options' ) ) {
				return null;
			}
			$nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['_wpnonce'] ) ) : '';
			if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'wpwebmcp_dedupe_policies' ) ) {
				return 'invalid_nonce';
			}
			$wpwebmcp_raw = get_option( WP_WebMCP_Policy::OPTION_KEY, array() );
			if ( ! is_array( $wpwebmcp_raw ) ) {
				$wpwebmcp_raw = array();
			}
			$wpwebmcp_seen = array();
			$wpwebmcp_clean = array();
			$wpwebmcp_removed = 0;
			foreach ( $wpwebmcp_raw as $wpwebmcp_row ) {
				if ( ! is_array( $wpwebmcp_row ) ) {
					continue;
				}
				$wpwebmcp_key = ( isset( $wpwebmcp_row['name'] ) ? (string) $wpwebmcp_row['name'] : '' ) . '|' . ( isset( $wpwebmcp_row['match_type'] ) ? (string) $wpwebmcp_row['match_type'] : '' ) . '|' . ( isset( $wpwebmcp_row['match_value'] ) ? (string) $wpwebmcp_row['match_value'] : '' );
				if ( isset( $wpwebmcp_seen[ $wpwebmcp_key ] ) ) {
					++$wpwebmcp_removed;
					continue;
				}
				$wpwebmcp_seen[ $wpwebmcp_key ] = true;
				$wpwebmcp_clean[] = $wpwebmcp_row;
			}
			update_option( WP_WebMCP_Policy::OPTION_KEY, $wpwebmcp_clean, false );
			wp_safe_redirect( add_query_arg( array( 'page' => 'wp-webmcp-policies', 'notice' => 'deduped_' . $wpwebmcp_removed ), admin_url( 'admin.php' ) ) );
			exit;
		}

		// GET: toggle the new-crawler grace rail (F2 D4). When enabled (default),
		// an unknown-agent block is enforced as a 60 req/min rate limit instead
		// of a hard 403, so legitimate new crawlers missing from the registry
		// are throttled rather than locked out.
		if ( isset( $_GET['action'] ) && ( 'grace_on' === sanitize_key( wp_unslash( (string) $_GET['action'] ) ) || 'grace_off' === sanitize_key( wp_unslash( (string) $_GET['action'] ) ) ) ) {
			if ( ! current_user_can( 'manage_options' ) ) {
				return null;
			}
			$nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['_wpnonce'] ) ) : '';
			if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'wpwebmcp_grace_toggle' ) ) {
				return 'invalid_nonce';
			}
			update_option( 'wpwebmcp_unknown_grace_enabled', 'grace_on' === sanitize_key( wp_unslash( (string) $_GET['action'] ) ) ? '1' : '0', false ); // store '1'/'0': update_option(false) on a missing option is a no-op
			wp_safe_redirect( add_query_arg( array( 'page' => 'wp-webmcp-policies', 'notice' => 'grace_updated' ), admin_url( 'admin.php' ) ) );
			exit;
		}

		// GET: clear all policies (used during verification cleanup).
		if ( isset( $_GET['action'] ) && 'clear_test_policies' === sanitize_key( wp_unslash( (string) $_GET['action'] ) ) ) {
			if ( ! current_user_can( 'manage_options' ) ) {
				return null;
			}
			$nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['_wpnonce'] ) ) : '';
			if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'wpwebmcp_clear_test_policies' ) ) {
				return 'invalid_nonce';
			}
			update_option( WP_WebMCP_Policy::OPTION_KEY, array(), false );
			wp_safe_redirect( add_query_arg( array( 'page' => 'wp-webmcp-policies', 'notice' => 'deleted' ), admin_url( 'admin.php' ) ) );
			exit;
		}

		// GET: apply a policy preset (A2c). Idempotent — skips already-applied rows.
		if ( isset( $_GET['action'] ) && 'apply_policy_preset' === sanitize_key( wp_unslash( (string) $_GET['action'] ) ) ) {
			if ( ! current_user_can( 'manage_options' ) ) {
				return null;
			}
			$nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['_wpnonce'] ) ) : '';
			if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'wpwebmcp_apply_policy_preset' ) ) {
				return 'invalid_nonce';
			}
			if ( ! class_exists( 'WP_WebMCP_Policy_Presets' ) ) {
				return 'save_error';
			}
			$preset_slug = isset( $_GET['preset'] ) ? sanitize_key( (string) wp_unslash( $_GET['preset'] ) ) : '';
			$result      = WP_WebMCP_Policy_Presets::apply( $preset_slug );
			if ( empty( $result['ok'] ) ) {
				return 'save_error';
			}
			set_transient( 'wpwebmcp_last_preset_apply_' . get_current_user_id(), $result, MINUTE_IN_SECONDS );
			wp_safe_redirect( add_query_arg( array( 'page' => 'wp-webmcp-policies', 'notice' => 'preset_applied' ), admin_url( 'admin.php' ) ) );
			exit;
		}

		// GET: remove a previously applied preset (A2c). Removes all rows whose name starts with [slug].
		if ( isset( $_GET['action'] ) && 'remove_policy_preset' === sanitize_key( wp_unslash( (string) $_GET['action'] ) ) ) {
			if ( ! current_user_can( 'manage_options' ) ) {
				return null;
			}
			$nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['_wpnonce'] ) ) : '';
			if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'wpwebmcp_remove_policy_preset' ) ) {
				return 'invalid_nonce';
			}
			if ( ! class_exists( 'WP_WebMCP_Policy_Presets' ) ) {
				return 'save_error';
			}
			$preset_slug = isset( $_GET['preset'] ) ? sanitize_key( (string) wp_unslash( $_GET['preset'] ) ) : '';
			$wpwebmcp_deleted     = WP_WebMCP_Policy_Presets::remove( $preset_slug );
			set_transient( 'wpwebmcp_last_preset_remove_' . get_current_user_id(), array( 'slug' => $preset_slug, 'deleted' => $wpwebmcp_deleted ), MINUTE_IN_SECONDS );
			wp_safe_redirect( add_query_arg( array( 'page' => 'wp-webmcp-policies', 'notice' => 'preset_removed' ), admin_url( 'admin.php' ) ) );
			exit;
		}

		return null;
	}

	/**
 * Build the seed-test-policies URL (admin-only verification helper).
 */
	public static function seed_test_policies_url(): string {
		return wp_nonce_url(
			add_query_arg(
				array(
					'page'   => 'wp-webmcp-policies',
					'action' => 'seed_test_policies',
				),
				admin_url( 'admin.php' )
			),
			'wpwebmcp_seed_test_policies'
		);
	}

	/**
 * Build the clear-test-policies URL (admin-only verification cleanup).
 */
	public static function clear_test_policies_url(): string {
		return wp_nonce_url(
			add_query_arg(
				array(
					'page'   => 'wp-webmcp-policies',
					'action' => 'clear_test_policies',
				),
				admin_url( 'admin.php' )
			),
			'wpwebmcp_clear_test_policies'
		);
	}

	/**
 * Build the nonce field for inclusion in the partial.
 */
	public static function nonce_field(): string {
		return wp_nonce_field( self::NONCE_ACTION, 'wpwebmcp_policies_nonce', true, false );
	}

	/**
 * Build a delete URL for a policy row.
 */
	public static function delete_url( string $id ): string {
		return wp_nonce_url(
			add_query_arg(
				array(
					'page'   => 'wp-webmcp-policies',
					'action' => 'delete_policy',
					'id'     => $id,
				),
				admin_url( 'admin.php' )
			),
			'wpwebmcp_delete_policy'
		);
	}

	/**
 * Build an edit URL for a policy row.
 */
	public static function edit_url( string $id ): string {
		return add_query_arg(
			array(
				'page' => 'wp-webmcp-policies',
				'edit' => $id,
			),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * Build the apply-preset URL (admin-only). Used by the policy preset
	 * card buttons in the policies partial.
	 */
	public static function apply_preset_url( string $preset_slug ): string {
		return wp_nonce_url(
			add_query_arg(
				array(
					'page'   => 'wp-webmcp-policies',
					'action' => 'apply_policy_preset',
					'preset' => $preset_slug,
				),
				admin_url( 'admin.php' )
			),
			'wpwebmcp_apply_policy_preset'
		);
	}

	/**
	 * Build the remove-preset URL (admin-only). Removes all policy rows
	 * previously inserted by the given preset slug.
	 */
	public static function remove_preset_url( string $preset_slug ): string {
		return wp_nonce_url(
			add_query_arg(
				array(
					'page'   => 'wp-webmcp-policies',
					'action' => 'remove_policy_preset',
					'preset' => $preset_slug,
				),
				admin_url( 'admin.php' )
			),
			'wpwebmcp_remove_policy_preset'
		);
	}

	/**
	 * Return the summary list of available policy presets for rendering in
	 * the policies partial. Returns an empty array when the preset class
	 * is not loaded yet (defensive guard for partials hit before the
	 * main loader has included the class file).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function preset_summary(): array {
		if ( ! class_exists( 'WP_WebMCP_Policy_Presets' ) ) {
			return array();
		}
		return WP_WebMCP_Policy_Presets::get_summary();
	}

	/**
	 * Whether a preset has been applied (i.e., at least one active policy
	 * row is tagged with the preset slug). Used to render Apply vs Remove
	 * affordances on the preset cards.
	 */
	public static function is_preset_applied( string $preset_slug ): bool {
		if ( ! class_exists( 'WP_WebMCP_Policy' ) ) {
			return false;
		}
		$tag = '[' . $preset_slug . ']';
		foreach ( WP_WebMCP_Policy::all() as $row ) {
			if ( isset( $row['name'] ) && is_string( $row['name'] ) && strpos( $row['name'], $tag ) === 0 ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Number of policy rows tagged with the given preset slug (F2 D3:
	 * preset-card counts so cards and the table corroborate each other).
	 */
	public static function preset_row_count( string $preset_slug ): int {
		if ( ! class_exists( 'WP_WebMCP_Policy' ) ) {
			return 0;
		}
		$tag = '[' . $preset_slug . ']';
		$n = 0;
		foreach ( WP_WebMCP_Policy::all() as $row ) {
			if ( isset( $row['name'] ) && is_string( $row['name'] ) && strpos( $row['name'], $tag ) === 0 ) {
				++$n;
			}
		}
		return $n;
	}
}