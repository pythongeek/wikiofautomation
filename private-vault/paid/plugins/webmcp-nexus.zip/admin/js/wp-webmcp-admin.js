/*!
 * WebMCP Nexus — admin JS (Doc §5.9 + Steps 6–13 additions).
 *
 * Vanilla JS, no build step. Provides:
 *   - Tab deep-link controller (C9): #tab={key} hash sync + arrow navigation.
 *   - C1 toggle AJAX persistence: wp_ajax_wpwebmcp_toggle.
 *   - C7 modal controller: focus trap + Esc-to-close + trigger focus return.
 *   - Live Toast system.
 *   - Settings PUT via /wp-json/wpwebmcp/v1/settings.
 *   - Tool Builder CRUD (table rendering, modal add/edit, delete).
 *   - Audit Log REST fetching, filtering, pagination, CSV streaming, clear modal.
 *   - Analytics REST stats fetching and chart/table rendering.
 *   - Tool Access matrix saving (PUT /access).
 *   - Import/Export file dropping and upload.
 *
 * Localized as window.WPWEBMCP_ADMIN: ajaxurl, wpwebmcp_admin_nonce, restUrl, restNonce.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */
(function () {
	'use strict';

	var CFG = (typeof window.WPWEBMCP_ADMIN === 'object' && window.WPWEBMCP_ADMIN)
		|| (typeof window.WEBMCP_NEXUS_ADMIN === 'object' && window.WEBMCP_NEXUS_ADMIN)
		|| {};

	// Defensive fallback for REST URL & nonces to prevent 'undefined...' 404s
	if (!CFG.restUrl) {
		if (window.wpApiSettings && window.wpApiSettings.root) {
			CFG.restUrl = window.wpApiSettings.root + 'wpwebmcp/v1/';
		} else {
			CFG.restUrl = (window.location.origin || '') + '/wp-json/wpwebmcp/v1/';
		}
	}
	if (!CFG.restNonce && window.wpApiSettings && window.wpApiSettings.nonce) {
		CFG.restNonce = window.wpApiSettings.nonce;
	}
	if (!CFG.ajaxurl) {
		CFG.ajaxurl = (window.location.origin || '') + '/wp-admin/admin-ajax.php';
	}

	/* ============================================================
	 * Toasts (live region)
	 * ============================================================ */

	function ensureToastRegion() {
		var el = document.querySelector('.wpwm-toasts');
		if (el) { return el; }
		el = document.createElement('div');
		el.className = 'wpwm-toasts';
		el.setAttribute('role', 'status');
		el.setAttribute('aria-live', 'polite');
		el.setAttribute('aria-atomic', 'false');
		document.body.appendChild(el);
		return el;
	}

	function toast(message, kind) {
		var region = ensureToastRegion();
		var node = document.createElement('div');
		node.className = 'wpwm-toast' + (kind ? (' wpwm-toast--' + kind) : '');
		node.textContent = String(message);
		region.appendChild(node);
		setTimeout(function () {
			if (node && node.parentNode) { node.parentNode.removeChild(node); }
		}, 4500);
	}

	/* ============================================================
	 * C1 — Toggle switch (AJAX persistence)
	 * ============================================================ */

	function bindToggles(root) {
		var nodes = (root || document).querySelectorAll('.wpwm-switch input[type="checkbox"][data-wpwm-toggle]');
		for (var i = 0; i < nodes.length; i++) {
			(function (input) {
				if (input.dataset.wpwmBound === '1') { return; }
				input.dataset.wpwmBound = '1';

				var busy = false;
				input.addEventListener('change', function () {
					if (busy) { return; }
					busy = true;
					var prev = !input.checked;
					var key = input.getAttribute('data-wpwm-toggle');
					var value = input.checked ? 1 : 0;
					sendToggle(key, value, function (ok, msg) {
						busy = false;
						if (!ok) {
							input.checked = prev;
							toast(msg || 'Save failed', 'error');
						} else if (msg) {
							toast(msg, 'success');
						}
					});
				});
			})(nodes[i]);
		}
	}

	function sendToggle(key, value, cb) {
		if (!CFG.ajaxurl || !CFG.wpwebmcp_admin_nonce) {
			cb(false, 'Missing AJAX config');
			return;
		}
		var fd = new FormData();
		fd.append('action', 'wpwebmcp_toggle');
		fd.append('nonce', CFG.wpwebmcp_admin_nonce);
		fd.append('key', key);
		fd.append('value', String(value));
		fetch(CFG.ajaxurl, {
			method: 'POST',
			credentials: 'include',
			body: fd
		})
		.then(function (r) { return r.json(); })
		.then(function (j) { cb(!!(j && j.success), (j && j.data && j.data.message) || ''); })
		.catch(function () { cb(false, 'Network error'); });
	}

	/* ============================================================
	 * C9 — Tabs (deep-link via #tab={key})
	 * ============================================================ */

	function bindTabs(root) {
		var groups = (root || document).querySelectorAll('[data-wpwm-tabs]');
		for (var i = 0; i < groups.length; i++) {
			(function (group) {
				var tabs = group.querySelectorAll('.wpwm-tab');
				var groupId = group.id;
				var panels = document.querySelectorAll('[data-wpwm-tabpanel][data-group="' + groupId + '"]');
				if (!tabs.length) { return; }

				function activate(tab) {
					for (var t = 0; t < tabs.length; t++) {
						var on = (tabs[t] === tab);
						tabs[t].setAttribute('aria-selected', on ? 'true' : 'false');
						var key = tabs[t].getAttribute('data-tab');
						for (var p = 0; p < panels.length; p++) {
							if (panels[p].getAttribute('data-tab') === key) {
								if (on) { panels[p].removeAttribute('hidden'); }
								else { panels[p].setAttribute('hidden', ''); }
							}
						}
					}
				}

				for (var k = 0; k < tabs.length; k++) {
					(function (tab) {
						tab.addEventListener('click', function (e) {
							e.preventDefault();
							activate(tab);
							var key = tab.getAttribute('data-tab');
							if (key) {
								if (history && history.replaceState) {
									history.replaceState(null, '', '#tab=' + key);
								} else {
									window.location.hash = '#tab=' + key;
								}
							}
						});
						tab.addEventListener('keydown', function (e) {
							if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') { return; }
							var idx = -1;
							for (var i2 = 0; i2 < tabs.length; i2++) { if (tabs[i2] === tab) { idx = i2; break; } }
							if (idx < 0) { return; }
							var next = e.key === 'ArrowRight' ? (idx + 1) % tabs.length : (idx - 1 + tabs.length) % tabs.length;
							e.preventDefault();
							tabs[next].focus();
							activate(tabs[next]);
						});
					})(tabs[k]);
				}

				// Hash sync on load.
				var hash = (window.location.hash || '').replace(/^#tab=/, '');
				if (hash) {
					for (var m = 0; m < tabs.length; m++) {
						if (tabs[m].getAttribute('data-tab') === hash) { activate(tabs[m]); break; }
					}
				} else {
					activate(tabs[0]);
				}
			})(groups[i]);
		}
	}

	/* ============================================================
	 * C7 — Confirm modal
	 * ============================================================ */

	function openModal(modal) {
		var trigger = document.activeElement;
		modal.dataset.wpwmTrigger = trigger && trigger.tagName ? (trigger.id || trigger.tagName) : '';
		modal.setAttribute('aria-hidden', 'false');
		var first = modal.querySelector('[autofocus]') || modal.querySelector('button, [tabindex]:not([tabindex="-1"])');
		if (first) { first.focus(); }
		document.addEventListener('keydown', trapFocus);
	}

	function closeModal(modal) {
		modal.setAttribute('aria-hidden', 'true');
		document.removeEventListener('keydown', trapFocus);
		var sel = modal.dataset.wpwmTrigger;
		if (sel) {
			var el = document.getElementById(sel) || null;
			if (el) { el.focus(); }
		}
	}

	function trapFocus(e) {
		if (e.key !== 'Escape' && e.key !== 'Tab') { return; }
		var open = document.querySelector('.wpwm-modal[aria-hidden="false"]');
		if (!open) { return; }
		if (e.key === 'Escape') {
			e.preventDefault();
			closeModal(open);
			return;
		}
		var focusables = open.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
		if (!focusables.length) { return; }
		var first = focusables[0];
		var last = focusables[focusables.length - 1];
		if (e.shiftKey && document.activeElement === first) {
			e.preventDefault(); last.focus();
		} else if (!e.shiftKey && document.activeElement === last) {
			e.preventDefault(); first.focus();
		}
	}

	function bindModals(root) {
		var triggers = (root || document).querySelectorAll('[data-wpwm-open-modal]');
		for (var i = 0; i < triggers.length; i++) {
			(function (trig) {
				if (trig.dataset.wpwmBound === '1') { return; }
				trig.dataset.wpwmBound = '1';
				var sel = trig.getAttribute('data-wpwm-open-modal');
				trig.addEventListener('click', function (e) {
					e.preventDefault();
					var modal = sel ? document.querySelector(sel) : null;
					if (modal) { openModal(modal); }
				});
			})(triggers[i]);
		}

		var closers = (root || document).querySelectorAll('[data-wpwm-close-modal]');
		for (var j = 0; j < closers.length; j++) {
			(function (btn) {
				btn.addEventListener('click', function (e) {
					e.preventDefault();
					var modal = btn.closest('.wpwm-modal');
					if (modal) { closeModal(modal); }
				});
			})(closers[j]);
		}
	}

	/* ============================================================
	 * Onboarding dismiss (C12)
	 * ============================================================ */

	function bindDismiss(root) {
		var links = (root || document).querySelectorAll('[data-wpwm-dismiss-onboarding]');
		for (var i = 0; i < links.length; i++) {
			(function (a) {
				if (a.dataset.wpwmBound === '1') { return; }
				a.dataset.wpwmBound = '1';
				a.addEventListener('click', function (e) {
					e.preventDefault();
					if (!CFG.ajaxurl || !CFG.wpwebmcp_admin_nonce) {
						toast('Missing AJAX config', 'error');
						return;
					}
					var fd = new FormData();
					fd.append('action', 'wpwebmcp_dismiss_onboarding');
					fd.append('nonce', CFG.wpwebmcp_admin_nonce);
					fetch(CFG.ajaxurl, {
						method: 'POST',
						credentials: 'include',
						body: fd
					})
					.then(function (r) { return r.json(); })
					.then(function (j) {
						if (j && j.success) {
							var card = a.closest('.wpwm-checklist');
							if (card) { card.style.display = 'none'; }
							toast('Onboarding dismissed', 'success');
						} else {
							toast('Could not dismiss onboarding', 'error');
						}
					})
					.catch(function () { toast('Network error', 'error'); });
				});
			})(links[i]);
		}
	}

	/* ============================================================
	 * Settings — PUT /wp-json/wpwebmcp/v1/settings
	 * ============================================================ */

	function collectSettings(form) {
		var out = {};
		var nodes = form.querySelectorAll('[data-wpwm-setting]');
		for (var i = 0; i < nodes.length; i++) {
			var n   = nodes[i];
			var key = n.getAttribute('data-wpwm-setting');
			if (!key) { continue; }
			if (n.type === 'checkbox') {
				if (n.name && n.name.indexOf('[]') !== -1) {
					var stripped = n.name.replace(/\[\]$/, '');
					var key2 = stripped;
					if (!out[key2]) { out[key2] = []; }
					if (n.checked) { out[key2].push(n.value); }
				} else {
					out[key] = n.checked ? 1 : 0;
				}
			} else if (n.tagName === 'SELECT' && n.multiple) {
				out[key] = Array.prototype.slice.call(n.selectedOptions).map(function (o) { return o.value; });
			} else {
				out[key] = n.value;
			}
		}
		return out;
	}

	function bindSaveSettings(root) {
		var form = (root || document).querySelector('[data-wpwm-settings-form]');
		if (!form) { return; }
		var btn = form.querySelector('[data-wpwm-action="save-settings"]');
		if (!btn) { return; }
		if (btn.dataset.wpwmBound === '1') { return; }
		btn.dataset.wpwmBound = '1';
		btn.addEventListener('click', function (e) {
			e.preventDefault();
			var status = form.querySelector('[data-wpwm-save-status]');
			if (status) { status.textContent = ''; }
			btn.disabled = true;

			var payload = collectSettings(form);
			if (!CFG.restUrl || !CFG.restNonce) {
				if (status) { status.textContent = 'Missing REST config.'; }
				btn.disabled = false;
				return;
			}

			fetch(CFG.restUrl + 'settings', {
				method: 'PUT',
				credentials: 'include',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': CFG.restNonce
				},
				body: JSON.stringify(payload)
			})
			.then(function (r) {
				return r.json().then(function (j) { return { status: r.status, body: j }; });
			})
			.then(function (resp) {
				if (resp && resp.status === 200 && resp.body && resp.body.ok) {
					toast('Settings saved.', 'success');
					if (status) { status.textContent = 'Saved at ' + new Date().toLocaleTimeString(); }
				} else {
					var msg = (resp && resp.body && (resp.body.message || resp.body.detail)) || ('HTTP ' + (resp ? resp.status : '???'));
					toast('Save failed: ' + msg, 'error');
					if (status) { status.textContent = 'Save failed.'; }
				}
			})
			.catch(function () {
				toast('Network error', 'error');
				if (status) { status.textContent = 'Network error.'; }
			})
			.then(function () {
				btn.disabled = false;
			});
		});
	}

	/* ============================================================
	 * Push server (Module 0 M0a) — copy + rotate token
	 * ============================================================ */

	function bindPushServer(root) {
		var copyBtn = (root || document).getElementById('wpwebmcp-push-copy-token');
		var rotateBtn = (root || document).getElementById('wpwebmcp-push-rotate-token');
		var status = (root || document).getElementById('wpwebmcp-push-token-status');
		var display = (root || document).getElementById('wpwebmcp-push-token-display');
		if (!copyBtn && !rotateBtn) { return; }

		function setStatus(msg, ok) {
			if (status) {
				status.textContent = msg || '';
				status.style.color = ok ? '#007017' : '#d63638';
			}
		}

		if (copyBtn) {
			copyBtn.addEventListener('click', function () {
				var t = display ? (display.textContent || '').trim() : '';
				if (!t || t === '(will be generated on first request)') {
					setStatus('No token yet.', false);
					return;
				}
				if (navigator.clipboard && navigator.clipboard.writeText) {
					navigator.clipboard.writeText(t).then(function () {
						setStatus('Copied to clipboard.', true);
					}).catch(function () {
						fallbackCopy(t);
					});
				} else {
					fallbackCopy(t);
				}
			});
		}

		function fallbackCopy(text) {
			try {
				var ta = document.createElement('textarea');
				ta.value = text;
				ta.style.position = 'fixed';
				ta.style.opacity = '0';
				document.body.appendChild(ta);
				ta.select();
				document.execCommand('copy');
				document.body.removeChild(ta);
				setStatus('Copied to clipboard.', true);
			} catch (e) {
				setStatus('Copy failed.', false);
			}
		}

		if (rotateBtn) {
			rotateBtn.addEventListener('click', function () {
				if (!CFG.restUrl || !CFG.restNonce) {
					setStatus('Missing REST config.', false);
					return;
				}
				if (!window.confirm('Rotate the push token? All current subscribers will be disconnected.')) {
					return;
				}
				rotateBtn.disabled = true;
				setStatus('Rotating…', true);
				fetch(CFG.restUrl + 'push/rotate-token', {
					method: 'POST',
					credentials: 'include',
					headers: {
						'Content-Type': 'application/json',
						'X-WP-Nonce': CFG.restNonce
					}
				})
				.then(function (r) {
					return r.json().then(function (j) { return { status: r.status, body: j }; });
				})
				.then(function (resp) {
					if (resp && resp.status === 200 && resp.body && resp.body.ok && resp.body.token) {
						if (display) { display.textContent = resp.body.token; }
						setStatus('New token issued. All subscribers disconnected.', true);
					} else {
						var msg = (resp && resp.body && (resp.body.message || resp.body.detail)) || ('HTTP ' + (resp ? resp.status : '???'));
						setStatus('Rotation failed: ' + msg, false);
					}
				})
				.catch(function () {
					setStatus('Network error', false);
				})
				.then(function () {
					rotateBtn.disabled = false;
				});
			});
		}

		// M0a-debug: set-token handlers (force a known-good token).
		var setStatusEl = (root || document).getElementById('wpwebmcp-push-set-token-status');
		function setSetStatus(msg, ok) {
			if (setStatusEl) {
				setStatusEl.textContent = msg || '';
				setStatusEl.style.color = ok ? '#007017' : '#d63638';
			}
		}
		function callSetToken(tokenValue, after) {
			setSetStatus('Saving…', true);
			fetch(CFG.restUrl + 'push/set-token', {
				method: 'POST',
				credentials: 'include',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': CFG.restNonce
				},
				body: JSON.stringify({ token: tokenValue || '' })
			})
			.then(function (r) { return r.json().then(function (j) { return { status: r.status, body: j }; }); })
			.then(function (resp) {
				if (resp && resp.status === 200 && resp.body && resp.body.ok && resp.body.token) {
					if (display) { display.textContent = resp.body.token; }
					setSetStatus('Saved. New length=' + resp.body.token_length + '. Reloading…', true);
					setTimeout(function () { window.location.reload(); }, 600);
				} else {
					var msg = (resp && resp.body && (resp.body.message || resp.body.detail)) || ('HTTP ' + (resp ? resp.status : '???'));
					setSetStatus('Failed: ' + msg, false);
					if (typeof after === 'function') { after(resp); }
				}
			})
			.catch(function () {
				setSetStatus('Network error', false);
				if (typeof after === 'function') { after(); }
			});
		}
		var setDefaultBtn = (root || document).getElementById('wpwebmcp-push-set-token-default');
		var setCustomBtn  = (root || document).getElementById('wpwebmcp-push-set-token-custom');
		var setInput      = (root || document).getElementById('wpwebmcp-push-set-token-input');
		if (setDefaultBtn) {
			setDefaultBtn.addEventListener('click', function () { callSetToken(''); });
		}
		if (setCustomBtn && setInput) {
			setCustomBtn.addEventListener('click', function () {
				var v = (setInput.value || '').trim();
				if (v.length < 8) { setSetStatus('Token must be at least 8 chars.', false); return; }
				callSetToken(v);
			});
		}
	}

	/* ============================================================
	 * Tool Builder — REST /tools CRUD
	 * ============================================================ */

	function bindToolBuilder(root) {
		var table = (root || document).querySelector('[data-wpwm-tools-table]');
		var tbody = (root || document).querySelector('[data-wpwm-tools-body]');
		var emptyBox = (root || document).querySelector('[data-wpwm-empty-tools]');
		var form = (root || document).querySelector('[data-wpwm-tool-form]');
		var modal = document.querySelector('#wpwm-tool-modal');
		if (!table && !form) { return; }

		function loadTools() {
			if (!CFG.restUrl || !CFG.restNonce || !tbody) { return; }
			fetch(CFG.restUrl + 'custom-tools', { // F5: repository rows (tool_name/id/status) — the registry endpoint returns manifest-shaped rows this renderer cannot display
				credentials: 'include',
				headers: { 'X-WP-Nonce': CFG.restNonce }
			})
			.then(function (r) { return r.json(); })
			.then(function (data) {
				var tools = (data && data.tools) || [];
				if (!tools.length) {
					if (tbody) { tbody.innerHTML = ''; }
					if (table) { table.style.display = 'none'; }
					if (emptyBox) { emptyBox.style.display = ''; }
					return;
				}
				if (table) { table.style.display = ''; }
				if (emptyBox) { emptyBox.style.display = 'none'; }

				var html = '';
				for (var i = 0; i < tools.length; i++) {
					var t = tools[i];
					html += '<tr data-tool-id="' + t.id + '">' +
						'<td><strong>' + escapeHtml(t.tool_name) + '</strong></td>' +
						'<td><span class="wpwm-badge ' + (t.tool_type === 'write' ? 'wpwm-badge--warn' : 'wpwm-badge--muted') + '">' + escapeHtml(t.tool_type) + '</span></td>' +
						'<td>' + escapeHtml(t.tool_scope || 'all') + '</td>' +
						'<td>' + escapeHtml(t.action_type || 'rest') + '</td>' +
						'<td><span class="wpwm-badge ' + (t.status === 'active' ? 'wpwm-badge--good' : 'wpwm-badge--muted') + '">' + escapeHtml(t.status) + '</span></td>' +
						'<td class="wpwm-col-actions">' +
							'<button type="button" class="button button-small" data-wpwm-edit-tool="' + t.id + '">Edit</button> ' +
							'<button type="button" class="button button-small button-link-delete" data-wpwm-delete-tool="' + t.id + '">Delete</button>' +
						'</td>' +
					'</tr>';
				}
				tbody.innerHTML = html;
			})
			.catch(function () {});
		}

		if (tbody) {
			loadTools();
			tbody.addEventListener('click', function (e) {
				var editBtn = e.target.closest('[data-wpwm-edit-tool]');
				if (editBtn) {
					var id = editBtn.getAttribute('data-wpwm-edit-tool');
					fetch(CFG.restUrl + 'tools/' + id, {
						credentials: 'include',
						headers: { 'X-WP-Nonce': CFG.restNonce }
					})
					.then(function (r) { return r.json(); })
					.then(function (res) {
						var tool = res.tool;
						if (tool && form) {
							form.querySelector('[name="tool_id"]').value = tool.id || '';
							form.querySelector('[name="tool_name"]').value = tool.tool_name || '';
							form.querySelector('[name="tool_description"]').value = tool.tool_description || '';
							form.querySelector('[name="tool_type"]').value = tool.tool_type || 'read';
							form.querySelector('[name="tool_scope"]').value = tool.tool_scope || 'all';
							form.querySelector('[name="action_type"]').value = tool.action_type || 'navigate';
							form.querySelector('[name="action_value"]').value = tool.action_value || '';
							form.querySelector('[name="status"]').value = tool.status || 'active';
							form.querySelector('[name="parameters"]').value = tool.parameters ? (typeof tool.parameters === 'object' ? JSON.stringify(tool.parameters, null, 2) : tool.parameters) : '';
							if (modal) { openModal(modal); }
						}
					});
					return;
				}

				var delBtn = e.target.closest('[data-wpwm-delete-tool]');
				if (delBtn) {
					if (!confirm('Delete this custom tool?')) { return; }
					var delId = delBtn.getAttribute('data-wpwm-delete-tool');
					fetch(CFG.restUrl + 'tools/' + delId, {
						method: 'DELETE',
						credentials: 'include',
						headers: { 'X-WP-Nonce': CFG.restNonce }
					})
					.then(function (r) { return r.json(); })
					.then(function () {
						toast('Tool deleted.', 'success');
						loadTools();
					})
					.catch(function () { toast('Could not delete tool.', 'error'); });
				}
			});
		}

		// New tool button resets form.
		var newBtn = document.querySelector('[data-wpwm-action="new-tool"]');
		if (newBtn && form) {
			newBtn.addEventListener('click', function () {
				form.reset();
				form.querySelector('[name="tool_id"]').value = '';
			});
		}

		// Auto-open tool modal if ?edit={id} is in URL
		try {
			var searchParams = new URLSearchParams(window.location.search);
			var autoEditId = searchParams.get('edit');
			if (autoEditId && form && modal) {
				fetch(CFG.restUrl + 'tools/' + encodeURIComponent(autoEditId), {
					credentials: 'include',
					headers: { 'X-WP-Nonce': CFG.restNonce }
				})
				.then(function (r) { return r.json(); })
				.then(function (res) {
					var tool = res && res.tool;
					if (tool) {
						form.querySelector('[name="tool_id"]').value = tool.id || '';
						form.querySelector('[name="tool_name"]').value = tool.tool_name || '';
						form.querySelector('[name="tool_description"]').value = tool.tool_description || '';
						form.querySelector('[name="tool_type"]').value = tool.tool_type || 'read';
						form.querySelector('[name="tool_scope"]').value = tool.tool_scope || 'all';
						form.querySelector('[name="action_type"]').value = tool.action_type || 'navigate';
						form.querySelector('[name="action_value"]').value = tool.action_value || '';
						form.querySelector('[name="status"]').value = tool.status || 'active';
						form.querySelector('[name="parameters"]').value = tool.parameters ? (typeof tool.parameters === 'object' ? JSON.stringify(tool.parameters, null, 2) : tool.parameters) : '';
						openModal(modal);
					}
				})
				.catch(function () {});
			}
		} catch (err) {}

		// 1-Click Quick Template Presets for non-tech users
		var presetBtns = document.querySelectorAll('[data-wpwm-preset]');
		presetBtns.forEach(function (pBtn) {
			pBtn.addEventListener('click', function (e) {
				e.preventDefault();
				var presetType = pBtn.getAttribute('data-wpwm-preset');
				if (!form) { return; }
				form.querySelector('[name="tool_id"]').value = '';

				if (presetType === 'search') {
					form.querySelector('[name="tool_name"]').value = 'searchKnowledgeBase';
					form.querySelector('[name="tool_description"]').value = 'Search help center articles and return matching titles, excerpts, and URLs.';
					form.querySelector('[name="tool_type"]').value = 'read';
					form.querySelector('[name="tool_scope"]').value = 'all';
					form.querySelector('[name="action_type"]').value = 'search';
					form.querySelector('[name="action_value"]').value = 's';
					form.querySelector('[name="parameters"]').value = JSON.stringify({
						type: 'object',
						properties: {
							query: { type: 'string', description: 'Search term or question' }
						},
						required: ['query']
					}, null, 2);
					form.querySelector('[name="status"]').value = 'active';
					toast('Loaded Search Tool template!', 'info');
				} else if (presetType === 'navigate') {
					form.querySelector('[name="tool_name"]').value = 'openContactPage';
					form.querySelector('[name="tool_description"]').value = 'Navigate the browser to the official customer support and contact page.';
					form.querySelector('[name="tool_type"]').value = 'read';
					form.querySelector('[name="tool_scope"]').value = 'all';
					form.querySelector('[name="action_type"]').value = 'navigate';
					form.querySelector('[name="action_value"]').value = '/contact';
					form.querySelector('[name="parameters"]').value = '';
					form.querySelector('[name="status"]').value = 'active';
					toast('Loaded Navigation Tool template!', 'info');
				} else if (presetType === 'hook') {
					form.querySelector('[name="tool_name"]').value = 'recordCustomerInquiry';
					form.querySelector('[name="tool_description"]').value = 'Trigger a custom WordPress PHP action hook when an AI assistant logs an inquiry.';
					form.querySelector('[name="tool_type"]').value = 'write';
					form.querySelector('[name="tool_scope"]').value = 'all';
					form.querySelector('[name="action_type"]').value = 'hook';
					form.querySelector('[name="action_value"]').value = 'wpwebmcp_customer_inquiry';
					form.querySelector('[name="parameters"]').value = JSON.stringify({
						type: 'object',
						properties: {
							customer_name: { type: 'string', description: 'Full name' },
							inquiry_notes: { type: 'string', description: 'Message summary' }
						},
						required: ['customer_name']
					}, null, 2);
					form.querySelector('[name="status"]').value = 'active';
					toast('Loaded PHP Action Hook template!', 'info');
				}
			});
		});

		if (form) {
			form.addEventListener('submit', function (e) {
				e.preventDefault();
				var toolId = form.querySelector('[name="tool_id"]').value;
				var toolName = form.querySelector('[name="tool_name"]').value.trim();
				var toolDesc = form.querySelector('[name="tool_description"]').value.trim();
				var toolType = form.querySelector('[name="tool_type"]').value;
				var toolScope = form.querySelector('[name="tool_scope"]').value;
				var actionType = form.querySelector('[name="action_type"]').value;
				var actionVal = form.querySelector('[name="action_value"]').value.trim();
				var statusVal = form.querySelector('[name="status"]').value;
				var rawParams = form.querySelector('[name="parameters"]').value.trim();

				var paramsObj = {};
				if (rawParams) {
					try {
						paramsObj = JSON.parse(rawParams);
					} catch (err) {
						toast('Invalid JSON in parameters schema.', 'error');
						return;
					}
				}

				var payload = {
					tool_name: toolName,
					tool_description: toolDesc,
					tool_type: toolType,
					tool_scope: toolScope,
					action_type: actionType,
					action_value: actionVal,
					status: statusVal,
					parameters: paramsObj
				};

				var method = toolId ? 'PUT' : 'POST';
				var url = CFG.restUrl + 'tools' + (toolId ? ('/' + toolId) : '');

				fetch(url, {
					method: method,
					credentials: 'include',
					headers: {
						'Content-Type': 'application/json',
						'X-WP-Nonce': CFG.restNonce
					},
					body: JSON.stringify(payload)
				})
				.then(function (r) { return r.json(); })
				.then(function (res) {
					if (res && res.ok) {
						toast('Tool saved successfully.', 'success');
						if (modal) { closeModal(modal); }
						loadTools();
					} else {
						toast('Save failed: ' + ((res && res.message) || 'Unknown error'), 'error');
					}
				})
				.catch(function () { toast('Network error.', 'error'); });
			});
		}
	}

	/* ============================================================
	 * Aggregator (Module 0 M0b) — child site registry + live test
	 * ============================================================ */

	function bindAggregator(root) {
		var doc = root || document;
		var enabledEl  = doc.getElementById('wpwebmcp-aggregator-enabled');
		var idEl       = doc.getElementById('agg-id');
		var labelEl    = doc.getElementById('agg-label');
		var modeEl     = doc.getElementById('agg-mode');
		var siteIdEl   = doc.getElementById('agg-site-id');
		var urlEl      = doc.getElementById('agg-url');
		var tokenEl    = doc.getElementById('agg-token');
		var addBtn     = doc.getElementById('wpwebmcp-aggregator-add');
		var removeBtn  = doc.getElementById('wpwebmcp-aggregator-remove');
		var saveBtn    = doc.getElementById('wpwebmcp-aggregator-save');
		var statusEl   = doc.getElementById('wpwebmcp-aggregator-status');
		var rowSiteId  = doc.getElementById('agg-row-siteid');
		var rowUrl     = doc.getElementById('agg-row-url');
		var rowToken   = doc.getElementById('agg-row-token');
		var testBtn    = doc.getElementById('wpwebmcp-aggregator-test');
		var testSiteEl = doc.getElementById('agg-test-site');
		var testToolEl = doc.getElementById('agg-test-tool');
		var testParamsEl = doc.getElementById('agg-test-params');
		var testStatusEl = doc.getElementById('wpwebmcp-aggregator-test-status');
		var testResultEl = doc.getElementById('wpwebmcp-aggregator-test-result');

		if (!addBtn && !testBtn) { return; }

		// Local client-side registry mirror. Keeps the UI in sync with the
		// server-rendered table. On Save, this is sent to the server.
		var localRegistry = [];
		// Hydrate from the rendered table.
		var rows = doc.querySelectorAll('#wpwebmcp-aggregator-sites table tbody tr');
		rows.forEach(function (tr) {
			var idCell    = tr.children[0];
			var labelCell = tr.children[1];
			var modeCell  = tr.children[2];
			var targetCell = tr.children[3];
			if (!idCell || !labelCell || !modeCell || !targetCell) { return; }
			var mode = (modeCell.textContent || '').trim();
			var entry = {
				id:    (idCell.textContent || '').trim(),
				label: (labelCell.textContent || '').trim(),
				mode:  mode
			};
			if (mode === 'multisite') {
				var m = /site_id=(\d+)/.exec(targetCell.textContent || '');
				if (m) { entry.site_id = parseInt(m[1], 10); }
			} else if (mode === 'remote') {
				entry.url = (targetCell.textContent || '').trim();
			}
			localRegistry.push(entry);
		});

		function setAggStatus(msg, ok) {
			if (statusEl) {
				statusEl.textContent = msg || '';
				statusEl.style.color = ok ? '#007017' : '#d63638';
			}
		}
		function setTestStatus(msg, ok) {
			if (testStatusEl) {
				testStatusEl.textContent = msg || '';
				testStatusEl.style.color = ok ? '#007017' : '#d63638';
			}
		}

		function syncModeRows() {
			if (!modeEl) { return; }
			var m = modeEl.value;
			if (rowSiteId) { rowSiteId.style.display = (m === 'multisite') ? '' : 'none'; }
			if (rowUrl)    { rowUrl.style.display    = (m === 'remote')     ? '' : 'none'; }
			if (rowToken)  { rowToken.style.display  = (m === 'remote')     ? '' : 'none'; }
		}
		if (modeEl) { modeEl.addEventListener('change', syncModeRows); syncModeRows(); }

		function renderTable() {
			var host = doc.getElementById('wpwebmcp-aggregator-sites');
			if (!host) { return; }
			if (!localRegistry.length) {
				host.innerHTML = '<p class="wpwm-field-helper">No child sites yet. Add one below.</p>';
				return;
			}
			var rowsHtml = '';
			localRegistry.forEach(function (r) {
				var target = '—';
				var auth   = 'n/a';
				if (r.mode === 'multisite') {
					target = 'site_id=' + (r.site_id || 0);
				} else if (r.mode === 'remote') {
					target = r.url || '';
					auth   = r.auth_token ? '✓ token set' : '⚠ no token';
				}
				rowsHtml += '<tr>'
					+ '<td><code>' + (r.id || '') + '</code></td>'
					+ '<td>' + (r.label || '') + '</td>'
					+ '<td><code>' + (r.mode || '') + '</code></td>'
					+ '<td style="word-break:break-all;">' + target + '</td>'
					+ '<td>' + auth + '</td>'
					+ '</tr>';
			});
			host.innerHTML = '<table class="widefat striped" style="margin-top:6px;">'
				+ '<thead><tr><th>ID</th><th>Label</th><th>Mode</th><th>Target</th><th>Auth</th></tr></thead>'
				+ '<tbody>' + rowsHtml + '</tbody></table>';

			// Refresh the test-site dropdown too.
			if (testSiteEl) {
				var opts = '';
				localRegistry.forEach(function (r) {
					opts += '<option value="' + (r.id || '') + '">' + (r.id || '') + ' — ' + (r.label || '') + '</option>';
				});
				testSiteEl.innerHTML = opts;
			}
		}

		function postAgg(path, body) {
			return fetch(CFG.restUrl + path, {
				method: 'POST',
				credentials: 'include',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': CFG.restNonce
				},
				body: JSON.stringify(body || {})
			}).then(function (r) { return r.json().then(function (j) { return { status: r.status, body: j }; }); });
		}

		if (addBtn) {
			addBtn.addEventListener('click', function () {
				setAggStatus('', true);
				var id    = (idEl.value || '').trim();
				var label = (labelEl.value || '').trim() || id;
				var mode  = modeEl.value;
				if (!id) { setAggStatus('Site id is required.', false); return; }
				if (localRegistry.some(function (r) { return r.id === id; })) {
					setAggStatus('A site with that id already exists.', false); return;
				}
				var entry = { id: id, label: label, mode: mode };
				if (mode === 'multisite') {
					entry.site_id = parseInt(siteIdEl.value || '0', 10);
					if (!entry.site_id) { setAggStatus('Multisite mode needs a positive site_id.', false); return; }
				} else if (mode === 'remote') {
					entry.url = (urlEl.value || '').trim();
					if (!entry.url) { setAggStatus('Remote mode needs a base URL.', false); return; }
					if (tokenEl.value) { entry.auth_token = tokenEl.value; }
				}
				localRegistry.push(entry);
				renderTable();
				setAggStatus('Added. Click "Save registry" to persist.', true);
			});
		}

		if (removeBtn) {
			removeBtn.addEventListener('click', function () {
				var id = (idEl.value || '').trim();
				if (!id) { setAggStatus('Type the site id to remove in the Site id field.', false); return; }
				var before = localRegistry.length;
				localRegistry = localRegistry.filter(function (r) { return r.id !== id; });
				if (localRegistry.length === before) {
					setAggStatus('No site with id "' + id + '".', false); return;
				}
				renderTable();
				setAggStatus('Removed. Click "Save registry" to persist.', true);
			});
		}

		if (saveBtn) {
			saveBtn.addEventListener('click', function () {
				setAggStatus('Saving…', true);
				postAgg('aggregator/sites', {
					enabled: !!(enabledEl && enabledEl.checked),
					sites:   localRegistry
				}).then(function (resp) {
					if (resp && resp.status === 200 && resp.body && resp.body.ok) {
						setAggStatus('Saved (' + resp.body.count + ' sites). Reloading…', true);
						setTimeout(function () { window.location.reload(); }, 600);
					} else {
						var msg = (resp && resp.body && (resp.body.message || resp.body.detail)) || ('HTTP ' + (resp ? resp.status : '???'));
						setAggStatus('Save failed: ' + msg, false);
					}
				}).catch(function () { setAggStatus('Network error', false); });
			});
		}

		if (testBtn) {
			testBtn.addEventListener('click', function () {
				if (testResultEl) { testResultEl.textContent = ''; }
				setTestStatus('Running…', true);
				var site = (testSiteEl.value || '').trim();
				var tool = (testToolEl.value || '').trim();
				var rawParams = (testParamsEl.value || '{}').trim() || '{}';
				var params = {};
				try { params = JSON.parse(rawParams); }
				catch (e) { setTestStatus('Params must be valid JSON.', false); return; }
				if (!site || !tool) { setTestStatus('Site and Tool are required.', false); return; }
				postAgg('aggregator/call', { site: site, tool: tool, params: params })
					.then(function (resp) {
						var body = resp.body || {};
						if (resp && resp.status === 200 && body && body.ok) {
							setTestStatus('OK in ' + (body.latency_ms || 0) + ' ms', true);
						} else if (resp && resp.body && resp.body.code) {
							setTestStatus('Failed: ' + resp.body.code + ' — ' + (resp.body.message || ''), false);
						} else {
							setTestStatus('HTTP ' + (resp ? resp.status : '???'), false);
						}
						if (testResultEl) {
							testResultEl.textContent = JSON.stringify(body, null, 2);
						}
					})
					.catch(function () {
						setTestStatus('Network error', false);
					});
			});
		}
	}

	/* ============================================================
	 * Audit Log — REST /log
	 * ============================================================ */

	function bindAuditLog(root) {
		var tbody = (root || document).querySelector('[data-wpwm-log-body]');
		var filterbar = (root || document).querySelector('[data-wpwm-filterbar]');
		if (!tbody) { return; }

		// Cached rows so we can filter the merged list client-side without
		// re-fetching when the View dropdown changes.
		var toolRows = [];
		var writeRows = [];

		function getView() {
			if (!filterbar) { return ''; }
			var el = filterbar.querySelector('[data-wpwm-filter="view"]');
			return el ? (el.value || '') : '';
		}

		function fetchToolLog(onDone) {
			if (!CFG.restUrl || !CFG.restNonce) { if (onDone) { onDone(); } return; }
			var params = new URLSearchParams();
			if (filterbar) {
				var tool = filterbar.querySelector('[data-wpwm-filter="tool_name"]').value;
				var status = filterbar.querySelector('[data-wpwm-filter="status"]').value;
				var dateFrom = filterbar.querySelector('[data-wpwm-filter="date_from"]').value;
				var dateTo = filterbar.querySelector('[data-wpwm-filter="date_to"]').value;
				if (tool) { params.append('tool_name', tool); }
				if (status) { params.append('status', status); }
				if (dateFrom) { params.append('date_from', dateFrom + ' 00:00:00'); }
				if (dateTo) { params.append('date_to', dateTo + ' 23:59:59'); }
			}
			params.append('per_page', '50');

			fetch(CFG.restUrl + 'log?' + params.toString(), {
				credentials: 'include',
				headers: { 'X-WP-Nonce': CFG.restNonce }
			})
			.then(function (r) { return r.json(); })
			.then(function (data) {
				toolRows = ((data && data.entries) || (data && data.rows) || []).slice();
				if (onDone) { onDone(); }
			})
			.catch(function () { if (onDone) { onDone(); } });
		}

		function fetchWriteLog(onDone) {
			if (!CFG.restUrl || !CFG.restNonce) { if (onDone) { onDone(); } return; }
			var params = new URLSearchParams();
			if (filterbar) {
				var status = filterbar.querySelector('[data-wpwm-filter="status"]').value;
				var dateFrom = filterbar.querySelector('[data-wpwm-filter="date_from"]').value;
				var dateTo = filterbar.querySelector('[data-wpwm-filter="date_to"]').value;
				if (status) { params.append('status', status); }
				if (dateFrom) { params.append('date_from', dateFrom + ' 00:00:00'); }
				if (dateTo) { params.append('date_to', dateTo + ' 23:59:59'); }
			}
			params.append('per_page', '50');

			fetch(CFG.restUrl + 'write-log?' + params.toString(), {
				credentials: 'include',
				headers: { 'X-WP-Nonce': CFG.restNonce }
			})
			.then(function (r) { return r.json(); })
			.then(function (data) {
				writeRows = ((data && data.entries) || []).slice();
				if (onDone) { onDone(); }
			})
			.catch(function () { if (onDone) { onDone(); } });
		}

		function fetchLog() {
			var view = getView();
			var pending = 2;
			if (view === 'tool_calls') { pending = 1; }
			else if (view === 'writes') { pending = 1; }
			function done() {
				pending -= 1;
				if (pending <= 0) { render(); }
			}
			if (view === 'writes') {
				fetchWriteLog(done);
			} else if (view === 'tool_calls') {
				fetchToolLog(done);
			} else {
				fetchToolLog(done);
				fetchWriteLog(done);
			}
		}

		function statusBadge(status) {
			if (status === 'error') { return 'wpwm-badge--error'; }
			if (status === 'rate_limited' || status === 'auth_failed') { return 'wpwm-badge--warn'; }
			if (status === 'rolled_back') { return 'wpwm-badge--muted'; }
			if (status === 'failed') { return 'wpwm-badge--error'; }
			return 'wpwm-badge--good';
		}

		function formatRow(r) {
			var time  = r.created_at || r.logged_at || '';
			var type  = (r.kind === 'tool') ? 'Tool' : 'Write';
			var target = (r.kind === 'tool') ? (r.tool_name || '') : (r.target_key || '');
			var status = r.status || '';
			var ms    = (r.kind === 'tool') ? (r.execution_ms || 0) : '';
			var actor = (r.kind === 'tool')
				? (r.user_id ? '#' + r.user_id : '<em>anon</em>')
				: (r.actor || '<em>system</em>');
			var ip    = r.ip_address || (r.ip_hashed ? r.ip_hashed.substring(0, 8) + '…' : (r.ip_hash ? r.ip_hash.substring(0, 8) + '…' : '—'));
			var action = '';
			if (r.kind === 'write' && r.event_type === 'option_update' && r.status === 'applied') {
				action = '<button type="button" class="button button-small" data-wpwm-rollback="' + r.id + '" data-wpwm-rollback-target="' + escapeHtml(r.target_key || '') + '">Rollback</button>';
			} else if (r.kind === 'write' && r.status === 'rolled_back') {
				action = '<span class="wpwm-badge wpwm-badge--muted">' + escapeHtml('rolled back') + '</span>';
			}
			return '<tr data-wpwm-row-id="' + r.id + '" data-wpwm-row-kind="' + r.kind + '">' +
				'<td>' + escapeHtml(time) + '</td>' +
				'<td><span class="wpwm-badge ' + (r.kind === 'tool' ? 'wpwm-badge--muted' : 'wpwm-badge--warn') + '">' + type + '</span></td>' +
				'<td><strong>' + escapeHtml(target) + '</strong>' +
					(r.diff_summary ? '<br><small style="color:#646970;">' + escapeHtml(r.diff_summary) + '</small>' : '') + '</td>' +
				'<td><span class="wpwm-badge ' + statusBadge(status) + '">' + escapeHtml(status) + '</span></td>' +
				'<td>' + ms + '</td>' +
				'<td>' + actor + '</td>' +
				'<td><code>' + escapeHtml(ip) + '</code></td>' +
				'<td class="wpwm-col-actions">' + action + '</td>' +
			'</tr>';
		}

		function render() {
			var view = getView();
			var merged = [];
			if (view !== 'writes') {
				for (var i = 0; i < toolRows.length; i++) {
					toolRows[i].kind = 'tool';
					merged.push(toolRows[i]);
				}
			}
			if (view !== 'tool_calls') {
				for (var j = 0; j < writeRows.length; j++) {
					writeRows[j].kind = 'write';
					merged.push(writeRows[j]);
				}
			}
			merged.sort(function (a, b) {
				var at = a.created_at || a.logged_at || '';
				var bt = b.created_at || b.logged_at || '';
				return bt.localeCompare(at);
			});
			if (!merged.length) {
				tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; color:#646970;">No log entries match criteria.</td></tr>';
				return;
			}
			var html = '';
			for (var k = 0; k < merged.length; k++) {
				html += formatRow(merged[k]);
			}
			tbody.innerHTML = html;
			bindRollbackButtons();
		}

		function bindRollbackButtons() {
			var btns = tbody.querySelectorAll('[data-wpwm-rollback]');
			for (var i = 0; i < btns.length; i++) {
				(function (btn) {
					btn.addEventListener('click', function (e) {
						e.preventDefault();
						openRollbackModal(btn);
					});
				})(btns[i]);
			}
		}

		var rollbackModal   = document.querySelector('#wpwm-rollback-modal');
		var rollbackConfirm = document.querySelector('[data-wpwm-confirm-rollback]');
		var rollbackTarget  = document.querySelector('[data-wpwm-rollback-target]');
		var pendingRollbackId = 0;

		function openRollbackModal(btn) {
			pendingRollbackId = parseInt(btn.getAttribute('data-wpwm-rollback'), 10) || 0;
			var label = btn.getAttribute('data-wpwm-rollback-target') || '';
			if (rollbackTarget) {
				rollbackTarget.textContent = label
					? ('Restores the prior value of ' + label + '.')
					: 'Restores the prior option value.';
			}
			if (rollbackModal) { openModal(rollbackModal); }
		}

		if (rollbackConfirm) {
			rollbackConfirm.addEventListener('click', function (e) {
				e.preventDefault();
				if (!pendingRollbackId || !CFG.ajaxurl || !CFG.wpwebmcp_admin_nonce) {
					toast('Cannot rollback — missing config.', 'error');
					return;
				}
				rollbackConfirm.disabled = true;
				var fd = new FormData();
				fd.append('action', 'wpwebmcp_rollback');
				fd.append('nonce', CFG.wpwebmcp_admin_nonce);
				fd.append('id', String(pendingRollbackId));
				fetch(CFG.ajaxurl, {
					method: 'POST',
					credentials: 'include',
					body: fd
				})
				.then(function (r) { return r.json(); })
				.then(function (j) {
					if (j && j.success) {
						toast((j.data && j.data.message) || 'Rolled back.', 'success');
						if (rollbackModal) { closeModal(rollbackModal); }
						fetchLog();
					} else {
						var msg = (j && j.data && j.data.message) || 'Rollback failed.';
						toast(msg, 'error');
					}
				})
				.catch(function () { toast('Network error during rollback.', 'error'); })
				.then(function () { rollbackConfirm.disabled = false; pendingRollbackId = 0; });
			});
		}

		fetchLog();

		if (filterbar) {
			var applyBtn = filterbar.querySelector('[data-wpwm-action="apply-filters"]');
			var resetBtn = filterbar.querySelector('[data-wpwm-action="reset-filters"]');
			var viewSel  = filterbar.querySelector('[data-wpwm-filter="view"]');
			if (applyBtn) {
				applyBtn.addEventListener('click', function (e) {
					e.preventDefault();
					fetchLog();
				});
			}
			if (resetBtn) {
				resetBtn.addEventListener('click', function (e) {
					e.preventDefault();
					filterbar.querySelector('[data-wpwm-filter="view"]').value = '';
					filterbar.querySelector('[data-wpwm-filter="tool_name"]').value = '';
					filterbar.querySelector('[data-wpwm-filter="status"]').value = '';
					filterbar.querySelector('[data-wpwm-filter="date_from"]').value = '';
					filterbar.querySelector('[data-wpwm-filter="date_to"]').value = '';
					filterbar.querySelector('[data-wpwm-filter="search"]').value = '';
					fetchLog();
				});
			}
			if (viewSel) {
				viewSel.addEventListener('change', function () { fetchLog(); });
			}
		}

		// CSV export button (tool-log only — write-log CSV is out of scope for M0d).
		var exportCsv = document.querySelector('[data-wpwm-action="export-csv"]');
		if (exportCsv) {
			exportCsv.href = CFG.ajaxurl ? (CFG.ajaxurl.replace('admin-ajax.php', 'admin-post.php') + '?action=wpwebmcp_log_csv&nonce=' + encodeURIComponent(CFG.wpwebmcp_admin_nonce)) : '#';
		}

		// Clear log button in modal (clears tool-log only).
		var confirmClear = document.querySelector('[data-wpwm-confirm-clear]');
		var clearModal = document.querySelector('#wpwm-clear-log-modal');
		if (confirmClear) {
			confirmClear.addEventListener('click', function (e) {
				e.preventDefault();
				fetch(CFG.restUrl + 'log', {
					method: 'DELETE',
					credentials: 'include',
					headers: { 'X-WP-Nonce': CFG.restNonce }
				})
				.then(function (r) { return r.json(); })
				.then(function () {
					toast('Audit log cleared.', 'success');
					if (clearModal) { closeModal(clearModal); }
					fetchLog();
				})
				.catch(function () { toast('Could not clear log.', 'error'); });
			});
		}
	}

	/* ============================================================
	 * Analytics — REST /analytics/stats
	 * ============================================================ */

	function bindAnalytics(root) {
		var botTable = (root || document).querySelector('[data-wpwm-by-bot-table] tbody');
		var pagesTable = (root || document).querySelector('[data-wpwm-top-pages-table] tbody');
		if (!botTable && !pagesTable) { return; }

		if (!CFG.restUrl || !CFG.restNonce) { return; }

		function loadStats() {
			fetch(CFG.restUrl + 'analytics/stats?days=30', {
				credentials: 'include',
				headers: { 'X-WP-Nonce': CFG.restNonce }
			})
			.then(function (r) { return r.json(); })
			.then(function (data) {
				if (!data) { return; }

				// 1. Stat cards
				var statHits = document.querySelector('[data-wpwm-stat="bot_visits_30d"]');
				var statBots = document.querySelector('[data-wpwm-stat="unique_bots"]');
				var statTop = document.querySelector('[data-wpwm-stat="top_bot"]');

				if (statHits) { statHits.textContent = (data.total_hits || 0).toLocaleString(); }
				if (statBots && data.by_bot) { statBots.textContent = data.by_bot.length; }
				if (statTop && data.by_bot && data.by_bot.length) { statTop.textContent = data.by_bot[0].bot_name; }
				else if (statTop) { statTop.textContent = '—'; }

				// 2. By bot table
				if (botTable && data.by_bot) {
					if (!data.by_bot.length) {
						botTable.innerHTML = '<tr><td colspan="2" style="text-align:center; color:#646970;">No bot visits recorded yet.</td></tr>';
					} else {
						var bHtml = '';
						for (var i = 0; i < data.by_bot.length; i++) {
							var b = data.by_bot[i];
							bHtml += '<tr><td><strong>' + escapeHtml(b.bot_name) + '</strong></td><td>' + Number(b.hits).toLocaleString() + '</td></tr>';
						}
						botTable.innerHTML = bHtml;
					}
				}

				// 3. Top pages table
				if (pagesTable && data.top_pages) {
					if (!data.top_pages.length) {
						pagesTable.innerHTML = '<tr><td colspan="2" style="text-align:center; color:#646970;">No bot page visits recorded yet.</td></tr>';
					} else {
						var pHtml = '';
						for (var j = 0; j < data.top_pages.length; j++) {
							var p = data.top_pages[j];
							pHtml += '<tr><td><a href="' + escapeHtml(p.url) + '" target="_blank">' + escapeHtml(p.title) + '</a></td><td>' + Number(p.hits).toLocaleString() + '</td></tr>';
						}
						pagesTable.innerHTML = pHtml;
					}
				}

				// 4. Chart placeholder
				var chartBox = document.querySelector('[data-wpwm-chart-placeholder]');
				if (chartBox && data.by_day && data.by_day.length) {
					renderSimpleBarChart(chartBox, data.by_day);
				} else if (chartBox) {
					chartBox.innerHTML = '<p style="text-align:center; padding-top:80px; color:#646970;">No telemetry data in the last 30 days.</p>';
				}
			})
			.catch(function () {});
		}

		loadStats();

		// Refresh button
		var refreshBtn = (root || document).querySelector('#wpwm-btn-refresh-analytics');
		if (refreshBtn) {
			refreshBtn.addEventListener('click', function () {
				loadStats();
				toast('Analytics refreshed', 'info');
			});
		}

		// Simulation button
		var simBtn = (root || document).querySelector('#wpwm-btn-simulate-ping');
		var simSelect = (root || document).querySelector('#wpwm-sim-bot-select');
		if (simBtn) {
			simBtn.addEventListener('click', function () {
				var bot = simSelect ? simSelect.value : 'Google-Extended (Gemini)';
				simBtn.disabled = true;
				var origHtml = simBtn.innerHTML;
				simBtn.textContent = 'Simulating...';

				fetch(CFG.restUrl + 'analytics/simulate-ping', {
					method: 'POST',
					credentials: 'include',
					headers: {
						'Content-Type': 'application/json',
						'X-WP-Nonce': CFG.restNonce
					},
					body: JSON.stringify({ bot: bot })
				})
				.then(function (r) { return r.json(); })
				.then(function (res) {
					simBtn.disabled = false;
					simBtn.innerHTML = origHtml;
					if (res && res.ok) {
						toast(res.message || 'Simulated bot hit logged!', 'success');
						loadStats();
					} else {
						toast('Simulation error: ' + ((res && res.message) || 'Unknown'), 'error');
					}
				})
				.catch(function (err) {
					simBtn.disabled = false;
					simBtn.innerHTML = origHtml;
					toast('Network error: ' + err.message, 'error');
				});
			});
		}
	}

	function renderSimpleBarChart(container, daysData) {
		var maxHits = 1;
		for (var i = 0; i < daysData.length; i++) {
			if (Number(daysData[i].hits) > maxHits) { maxHits = Number(daysData[i].hits); }
		}

		var svg = '<svg width="100%" height="200" style="overflow:visible;" viewBox="0 0 ' + (daysData.length * 24 + 40) + ' 200">';
		for (var d = 0; d < daysData.length; d++) {
			var h = Number(daysData[d].hits);
			var barH = Math.max(4, Math.round((h / maxHits) * 150));
			var x = 30 + d * 24;
			var y = 170 - barH;
			svg += '<rect x="' + x + '" y="' + y + '" width="16" height="' + barH + '" fill="var(--wpwm-accent,#2271b1)" rx="2"><title>' + daysData[d].day + ': ' + h + ' hits</title></rect>';
		}
		svg += '<line x1="20" y1="170" x2="' + (daysData.length * 24 + 40) + '" y2="170" stroke="#ccd0d4" stroke-width="1" />';
		svg += '</svg>';
		container.innerHTML = svg;
		container.classList.remove('wpwm-skel');
	}

	/* ============================================================
	 * Tool Access — PUT /access
	 * ============================================================ */

	function bindToolAccess(root) {
		var btn = (root || document).querySelector('[data-wpwm-action="save-access"]');
		var matrixBody = (root || document).querySelector('[data-wpwm-access-body]');
		if (!btn || !matrixBody) { return; }

		btn.addEventListener('click', function (e) {
			e.preventDefault();
			btn.disabled = true;

			var matrix = {};
			var rows = matrixBody.querySelectorAll('tr[data-role]');
			for (var i = 0; i < rows.length; i++) {
				var role = rows[i].getAttribute('data-role');
				var readChk = rows[i].querySelector('input[data-wpwm-toggle^="access_"][data-wpwm-toggle$="_read"]');
				var writeChk = rows[i].querySelector('input[data-wpwm-toggle^="access_"][data-wpwm-toggle$="_write"]');
				var allowed = [];
				if (readChk && readChk.checked) { allowed.push('read'); }
				if (writeChk && writeChk.checked) { allowed.push('write'); }
				matrix[role] = allowed;
			}

			fetch(CFG.restUrl + 'access', {
				method: 'PUT',
				credentials: 'include',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': CFG.restNonce
				},
				body: JSON.stringify(matrix)
			})
			.then(function (r) { return r.json(); })
			.then(function (res) {
				if (res && res.ok) {
					toast('Tool access matrix saved.', 'success');
				} else {
					toast('Save failed.', 'error');
				}
			})
			.catch(function () { toast('Network error.', 'error'); })
			.then(function () { btn.disabled = false; });
		});
	}

	/* ============================================================
	 * Import / Export file dropper
	 * ============================================================ */

	function bindImport(root) {
		var fileInput = (root || document).querySelector('[data-wpwm-import-file]');
		var statusDiv = (root || document).querySelector('#wpwm-import-status');
		if (!fileInput) { return; }

		fileInput.addEventListener('change', function () {
			if (!fileInput.files || !fileInput.files[0]) { return; }
			var file = fileInput.files[0];
			var reader = new FileReader();

			reader.onload = function (e) {
				try {
					var json = JSON.parse(e.target.result);
					if (statusDiv) {
						statusDiv.style.display = '';
						statusDiv.innerHTML = '<span class="spinner is-active" style="float:none;"></span> Importing settings...';
					}

					fetch(CFG.restUrl + 'settings/import', {
						method: 'POST',
						credentials: 'include',
						headers: {
							'Content-Type': 'application/json',
							'X-WP-Nonce': CFG.restNonce
						},
						body: JSON.stringify(json)
					})
					.then(function (r) { return r.json(); })
					.then(function (res) {
						if (res && res.ok) {
							toast('Configuration imported successfully.', 'success');
							setTimeout(function () { window.location.reload(); }, 1200);
						} else {
							toast('Import failed: ' + ((res && res.message) || 'Invalid format'), 'error');
							if (statusDiv) { statusDiv.style.display = 'none'; }
						}
					})
					.catch(function () {
						toast('Network error during import.', 'error');
						if (statusDiv) { statusDiv.style.display = 'none'; }
					});
				} catch (err) {
					toast('Selected file is not valid JSON.', 'error');
				}
			};

			reader.readAsText(file);
		});
	}

	/* ============================================================
	 * Dashboard — Run validation action
	 * ============================================================ */

	function bindValidation(root) {
		var btn = (root || document).querySelector('[data-wpwm-action="run-validation"]');
		if (!btn) { return; }
		if (btn.dataset.wpwmBound === '1') { return; }
		btn.dataset.wpwmBound = '1';

		btn.addEventListener('click', function (e) {
			e.preventDefault();
			if (!CFG.restUrl || !CFG.restNonce) {
				toast('Missing REST configuration', 'error');
				return;
			}
			btn.disabled = true;
			var origText = btn.textContent;
			btn.textContent = 'Validating...';

			fetch(CFG.restUrl + 'health/validate', {
				method: 'POST',
				credentials: 'include',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': CFG.restNonce
				}
			})
			.then(function (r) { return r.json(); })
			.then(function (res) {
				if (res && res.ok && typeof res.score === 'number') {
					var score = res.score;
					var scoreEl = document.querySelector('[data-wpwm-ring-score]');
					var captionEl = document.querySelector('[data-wpwm-ring-caption]');
					var ringEl = document.querySelector('.wpwm-ring');
					var arcEl = document.querySelector('.wpwm-ring-arc');

					if (scoreEl) { scoreEl.textContent = String(score); }
   toast('Validation complete — score ' + score + '/100', 'success');
   var lvEl = document.querySelector('[data-wpwm-last-validated]');
   if (!lvEl && btn && btn.parentNode) { lvEl = document.createElement('p'); lvEl.className = 'wpwm-muted'; lvEl.setAttribute('data-wpwm-last-validated', '1'); lvEl.style.margin = '6px 0 0'; btn.parentNode.insertBefore(lvEl, btn.nextSibling); }
   if (lvEl) { lvEl.textContent = 'Last validated: ' + new Date().toLocaleTimeString(); }
					if (captionEl) {
						captionEl.textContent = score >= 80 ? 'All systems compliant' : (score >= 50 ? 'Minor issues detected' : 'Attention required');
					}
					if (arcEl) {
						var dasharray = Math.round((score / 100) * 351.85 * 100) / 100;
						arcEl.setAttribute('stroke-dasharray', dasharray + ' 351.85');
					}
					if (ringEl) {
						ringEl.classList.remove('wpwm-ring--good', 'wpwm-ring--warn', 'wpwm-ring--bad');
						if (score >= 80) { ringEl.classList.add('wpwm-ring--good'); }
						else if (score >= 50) { ringEl.classList.add('wpwm-ring--warn'); }
						else { ringEl.classList.add('wpwm-ring--bad'); }
					}
					toast('Validation complete. Score: ' + score + '/100', 'success');
				} else {
					toast('Validation failed.', 'error');
				}
			})
			.catch(function () {
				toast('Network error during validation.', 'error');
			})
			.then(function () {
				btn.disabled = false;
				btn.textContent = origText;
			});
		});
	}

	/* ============================================================
	 * Dashboard — Interactive Live Playground
	 * ============================================================ */

	var toolPresets = {
		getSiteInfo: { desc: 'Get WordPress site metadata, capabilities, and active theme.', fields: [] },
		searchSite: { desc: 'Search public posts and pages across the site by keyword query.', fields: [{ name: 'query', label: 'Search Query (query) *', type: 'text', val: 'WordPress' }] },
		getFeaturedContent: { desc: 'Get latest published posts with title, excerpt, and permalink.', fields: [{ name: 'limit', label: 'Max Posts (limit)', type: 'number', val: 5 }] },
		getSiteMap: { desc: 'Get a list of all public permalinks on the site for agent discovery.', fields: [] },
		navigateTo: { desc: 'Navigate to an in-site URL or archive path.', fields: [{ name: 'path', label: 'In-site Path (path) *', type: 'text', val: '/' }] },
		getBreakingNews: { desc: 'Retrieve urgent breaking news flashes, headlines, and live coverage.', fields: [{ name: 'limit', label: 'Alerts Count (limit)', type: 'number', val: 3 }] },
		getArticlesByTopic: { desc: 'Query news stories filtered by category/topic slug.', fields: [{ name: 'topic', label: 'Topic Slug (topic) *', type: 'text', val: 'technology' }, { name: 'limit', label: 'Max Articles (limit)', type: 'number', val: 5 }] },
		getTrendingNews: { desc: 'Retrieve top trending stories based on reader velocity and comments.', fields: [{ name: 'limit', label: 'Max Stories (limit)', type: 'number', val: 5 }] },
		getFactCheckSummary: { desc: 'Retrieve fact-checking verdicts and claim reviews on a topic.', fields: [{ name: 'query', label: 'Claim Topic (query) *', type: 'text', val: 'AI development' }] },
		getEditorialStaff: { desc: 'Get journalist, editor, and columnist profiles.', fields: [{ name: 'role', label: 'Editorial Role (role)', type: 'text', val: 'editor' }] },
		searchDocumentation: { desc: 'Search developer documentation, technical manuals, and tutorials.', fields: [{ name: 'query', label: 'Doc Keyword (query) *', type: 'text', val: 'REST API' }] },
		getApiReference: { desc: 'Get structured API endpoints, methods, parameters, and schemas.', fields: [{ name: 'endpoint', label: 'Endpoint (endpoint) *', type: 'text', val: '/wp-json/wpwebmcp/v1/manifest' }] },
		getCodeSnippet: { desc: 'Retrieve copy-pasteable code examples by programming language.', fields: [{ name: 'topic', label: 'Code Topic (topic) *', type: 'text', val: 'authentication' }, { name: 'language', label: 'Language (language)', type: 'text', val: 'php' }] },
		getVersionChangelog: { desc: 'Retrieve release notes, version history, and breaking changes.', fields: [{ name: 'version', label: 'Version String (version)', type: 'text', val: 'latest' }] },
		getTechnicalSpecs: { desc: 'Extract technical server specs, requirements, and compatibility tables.', fields: [{ name: 'subject', label: 'Subject (subject)', type: 'text', val: 'environment' }] },
		getLatestArticles: { desc: 'Paginated blog articles with clean summary, author, and reading time.', fields: [{ name: 'limit', label: 'Max Articles (limit)', type: 'number', val: 5 }] },
		getPopularArticles: { desc: 'Retrieve most popular and commented blog posts.', fields: [{ name: 'limit', label: 'Max Posts (limit)', type: 'number', val: 5 }] },
		getAuthorProfile: { desc: 'Get author biography, credentials, social links, and post archive.', fields: [{ name: 'author', label: 'Author ID or Slug (author) *', type: 'text', val: 'admin' }] },
		estimateReadingTime: { desc: 'Calculate estimated reading minutes and word count for an article.', fields: [{ name: 'post_id', label: 'Post ID (post_id) *', type: 'number', val: 1 }] },
		listCategories: { desc: 'Explore the taxonomy categories with post counts.', fields: [] },
		listTags: { desc: 'View popular content tags across published articles.', fields: [] },
		searchVideos: { desc: 'Search video catalog by keywords, creator, and duration.', fields: [{ name: 'query', label: 'Video Query (query) *', type: 'text', val: 'tutorial' }] },
		getVideoDetails: { desc: 'Get full video metadata by ID: duration, resolution, stream URL.', fields: [{ name: 'video_id', label: 'Video Post ID (video_id) *', type: 'number', val: 1 }] },
		getVideoTranscript: { desc: 'Retrieve timestamped subtitles and captions for a video.', fields: [{ name: 'video_id', label: 'Video Post ID (video_id) *', type: 'number', val: 1 }] },
		getChapterTimestamps: { desc: 'Get chapter markers, timestamps, and section outlines.', fields: [{ name: 'video_id', label: 'Video Post ID (video_id) *', type: 'number', val: 1 }] },
		getPlaylists: { desc: 'Browse curated video playlists and episode collections.', fields: [{ name: 'limit', label: 'Max Playlists (limit)', type: 'number', val: 5 }] },
		getUpcomingEvents: { desc: 'Get scheduled upcoming events, webinars, and conferences.', fields: [{ name: 'limit', label: 'Max Events (limit)', type: 'number', val: 5 }] },
		getEventDetails: { desc: 'Get full details for a specific event: dates, venue, registration.', fields: [{ name: 'event_id', label: 'Event Post ID (event_id) *', type: 'number', val: 1 }] },
		searchEvents: { desc: 'Search and filter events by topic, date, or location.', fields: [{ name: 'query', label: 'Event Query (query) *', type: 'text', val: 'conference' }] },
		getProductDetails: { desc: 'Get full product details: name, price, stock status, attributes.', fields: [{ name: 'product_id', label: 'Product ID (product_id) *', type: 'number', val: 1 }] },
		searchProducts: { desc: 'Search WooCommerce store catalog by keyword query.', fields: [{ name: 'query', label: 'Product Query (query) *', type: 'text', val: 'shirt' }] },
		checkStock: { desc: 'Check real-time stock availability and inventory counts.', fields: [{ name: 'product_id', label: 'Product ID (product_id) *', type: 'number', val: 1 }] },
		getCartContents: { desc: 'Get current shopping cart contents, line items, and subtotal.', fields: [] },
		addToCart: { desc: 'Add product to shopping cart by ID and quantity.', fields: [{ name: 'product_id', label: 'Product ID (product_id) *', type: 'number', val: 1 }, { name: 'quantity', label: 'Quantity (quantity)', type: 'number', val: 1 }] }
	};

	function bindAdminPlayground(root) {
		var toolSelect = (root || document).querySelector('#wpwm-admin-tool-select');
		var descEl = (root || document).querySelector('#wpwm-admin-tool-desc');
		var paramsContainer = (root || document).querySelector('#wpwm-admin-params-container');
		var runBtn = (root || document).querySelector('#wpwm-admin-run-tool');
		var statusBadge = (root || document).querySelector('#wpwm-admin-res-status');
		var jsonViewer = (root || document).querySelector('#wpwm-admin-json-viewer');
		var copyBtn = (root || document).querySelector('#wpwm-admin-copy-json');

		if (!toolSelect || !runBtn) { return; }
		if (toolSelect.dataset.wpwmBound === '1') { return; }
		toolSelect.dataset.wpwmBound = '1';

	// F4: merge every registered tool (packs, answer-gap, custom) into the playground.
	var repo = window.WPWEBMCP_TOOL_REPO || {};
	Object.keys(repo).forEach(function (slug) {
		if (toolPresets[slug]) { return; }
		var fields = [];
		var ps = repo[slug].params;
		if (Array.isArray(ps)) {
			ps.forEach(function (pp) {
				if (pp && pp.name) { fields.push({ name: pp.name, label: pp.name + (pp.required ? ' *' : ''), type: (pp.type === 'integer' || pp.type === 'number') ? 'number' : 'text', val: '' }); }
			});
		} else if (ps && ps.properties) {
			Object.keys(ps.properties).forEach(function (pn) {
				var pp = ps.properties[pn] || {};
				fields.push({ name: pn, label: pn + (pp.required ? ' *' : ''), type: (pp.type === 'integer' || pp.type === 'number') ? 'number' : 'text', val: '' });
			});
		}
		toolPresets[slug] = { desc: repo[slug].desc || ('Invoke tool: ' + slug), fields: fields };
	});
	var knownOpts = {};
	Array.prototype.forEach.call(toolSelect.options, function (o) { knownOpts[o.value] = true; });
	var og = document.createElement('optgroup');
	og.label = 'Pack & Custom Tools';
	Object.keys(repo).sort().forEach(function (slug) {
		if (!knownOpts[slug]) { var opt = document.createElement('option'); opt.value = slug; opt.textContent = slug; og.appendChild(opt); }
	});
	if (og.children.length) { toolSelect.appendChild(og); }

		function renderFields(slug) {
			var preset = toolPresets[slug] || { desc: 'Invoke tool: ' + slug, fields: [{ name: 'query', label: 'Query Parameter', type: 'text', val: '' }] };
			if (descEl) { descEl.textContent = preset.desc; }
			if (!paramsContainer) { return; }

			paramsContainer.innerHTML = '';
			if (!preset.fields || preset.fields.length === 0) {
				var noParams = document.createElement('p');
				noParams.className = 'wpwm-field-helper';
				noParams.style.margin = '4px 0';
				noParams.textContent = 'This tool takes no parameters (executes immediately).';
				paramsContainer.appendChild(noParams);
				return;
			}

			preset.fields.forEach(function (f) {
				var fieldDiv = document.createElement('div');
				fieldDiv.className = 'wpwm-field';

				var lbl = document.createElement('label');
				lbl.className = 'wpwm-label';
				lbl.setAttribute('for', 'wpwm-admin-input-' + f.name);
				lbl.textContent = f.label;
				fieldDiv.appendChild(lbl);

				var inp = document.createElement('input');
				inp.type = f.type || 'text';
				inp.id = 'wpwm-admin-input-' + f.name;
				inp.name = f.name;
				inp.className = 'wpwm-input';
				inp.value = String(f.val !== undefined ? f.val : '');
				fieldDiv.appendChild(inp);

				paramsContainer.appendChild(fieldDiv);
			});
		}

		toolSelect.addEventListener('change', function () {
			renderFields(toolSelect.value);
		});

		// Render initial tool fields
		renderFields(toolSelect.value);

		runBtn.addEventListener('click', function () {
			var slug = toolSelect.value;
			if (!slug) { return; }

			var params = {};
			if (paramsContainer) {
				var inputs = paramsContainer.querySelectorAll('input, select, textarea');
				inputs.forEach(function (inp) {
					if (inp.name) {
						params[inp.name] = (inp.type === 'number') ? Number(inp.value) : inp.value;
					}
				});
			}

			runBtn.disabled = true;
			var origHtml = runBtn.innerHTML;
			runBtn.innerHTML = '<span class="dashicons dashicons-update" style="margin-top:2px; animation: rotation 1s infinite linear;"></span> Executing...';

			var startTime = performance.now();
			var callUrl = (CFG.restUrl || '/wp-json/wpwebmcp/v1/') + 'call/' + encodeURIComponent(slug);

			fetch(callUrl, {
				method: 'POST',
				credentials: 'include',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': CFG.restNonce || ''
				},
				body: JSON.stringify(params)
			})
			.then(function (r) {
				var ms = Math.round(performance.now() - startTime);
				if (statusBadge) {
					statusBadge.textContent = r.status + ' ' + r.statusText + ' (' + ms + 'ms)';
					statusBadge.className = 'wpwm-badge ' + (r.ok ? 'wpwm-badge--success' : 'wpwm-badge--error');
				}
				return r.json();
			})
			.then(function (data) {
				if (jsonViewer) {
					jsonViewer.textContent = JSON.stringify(data, null, 2);
				}
				toast('Tool executed successfully (' + slug + ')', 'success');
			})
			.catch(function (err) {
				if (statusBadge) {
					statusBadge.textContent = 'Error';
					statusBadge.className = 'wpwm-badge wpwm-badge--error';
				}
				if (jsonViewer) {
					jsonViewer.textContent = JSON.stringify({ error: err.message }, null, 2);
				}
				toast('Tool call failed: ' + err.message, 'error');
			})
			.then(function () {
				runBtn.disabled = false;
				runBtn.innerHTML = origHtml;
			});
		});

		if (copyBtn && jsonViewer) {
			copyBtn.addEventListener('click', function () {
				navigator.clipboard.writeText(jsonViewer.textContent).then(function () {
					toast('JSON response copied to clipboard!', 'success');
				});
			});
		}
	}

	function escapeHtml(str) {
		return String(str || '').replace(/[&<>"']/g, function (c) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
		});
	}

	function bindPresetButtons(root) {
		var btns = (root || document).querySelectorAll('.wpwm-btn-apply-preset');
		for (var i = 0; i < btns.length; i++) {
			(function (btn) {
				btn.addEventListener('click', function () {
					var presetKey = btn.getAttribute('data-preset');
					if (!presetKey || !CFG.ajaxurl) return;

					btn.disabled = true;
					var origText = btn.textContent;
					btn.textContent = 'Activating...';

					var fd = new FormData();
					fd.append('action', 'wpwebmcp_apply_preset');
					fd.append('nonce', CFG.wpwebmcp_admin_nonce);
					fd.append('preset', presetKey);

					fetch(CFG.ajaxurl, {
						method: 'POST',
						credentials: 'include',
						body: fd
					})
					.then(function (r) { return r.json(); })
					.then(function (res) {
						btn.disabled = false;
						if (res && res.success) {
							toast((res.data && res.data.message) ? res.data.message : 'Preset activated!', 'success');
							var badge = document.getElementById('wpwm-active-preset-badge');
							if (badge) badge.textContent = presetKey.toUpperCase();
							setTimeout(function () {
								window.location.reload();
							}, 600);
						} else {
							btn.textContent = origText;
							toast((res && res.data && res.data.message) || 'Activation failed', 'error');
						}
					})
					.catch(function (err) {
						btn.disabled = false;
						btn.textContent = origText;
						toast('Network error: ' + err.message, 'error');
					});
				});
			})(btns[i]);
		}
	}

	/* ============================================================
	 * Boot
	 * ============================================================ */

	function boot(root) {
		bindToggles(root || document);
		bindTabs(root || document);
		bindModals(root || document);
		bindDismiss(root || document);
		bindSaveSettings(root || document);
		bindPushServer(root || document);
		bindAggregator(root || document);
		bindToolBuilder(root || document);
		bindAuditLog(root || document);
		bindAnalytics(root || document);
		bindToolAccess(root || document);
		bindImport(root || document);
		bindValidation(root || document);
		bindAdminPlayground(root || document);
		bindPresetButtons(root || document);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', function () { boot(); });
	} else {
		boot();
	}

	window.WPWEBMCP_BOOT = boot;
})();