<?php
/**
 * Agent Live Trace (A5) — Module A A5.
 *
 * Read-only diagnostic page that surfaces REAL agent activity from the
 * audit log + bot log, plus on-demand identity resolution and policy
 * preview. The "rerun" button re-executes a logged call with the current
 * state — useful after editing policies / content / tools.
 *
 * Every number on this page comes from a real DB row, a real identity
 * resolver call, or a real policy evaluator call. Nothing is simulated
 * or fabricated.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$wpwebmcp_calls = class_exists( 'WP_WebMCP_Agent_Inspector' )
	? WP_WebMCP_Agent_Inspector::recent_tool_calls( 20 )
	: array();
$wpwebmcp_bots  = class_exists( 'WP_WebMCP_Agent_Inspector' )
	? WP_WebMCP_Agent_Inspector::recent_bot_visits_rows( 20, 30 )
	: array();
$wpwebmcp_rest_nonce   = wp_create_nonce( 'wp_rest' );
$wpwebmcp_resolve_url  = esc_url_raw( rest_url( 'wpwebmcp/v1/a5/resolve-agent' ) );
$wpwebmcp_policy_url   = esc_url_raw( rest_url( 'wpwebmcp/v1/a5/preview-policy' ) );
$wpwebmcp_rerun_url    = esc_url_raw( rest_url( 'wpwebmcp/v1/a5/rerun-call' ) );
?>
<!-- Educational Guide Card -->
<div class="wpwm-guide-card wpwm-guide-card--featured">
	<div class="wpwm-guide-header">
		<span class="wpwm-guide-icon"><span class="dashicons dashicons-visibility" aria-hidden="true"></span></span>
		<div>
			<h2 class="wpwm-guide-title"><?php esc_html_e( 'Live Agent Activity & Execution Inspector', 'webmcp-nexus' ); ?></h2>
			<p class="wpwm-field-helper" style="margin:2px 0 0;"><?php esc_html_e( 'Monitor, test, and debug real-time AI crawler visits and MCP tool executions.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
	<p class="wpwm-guide-desc">
		<?php esc_html_e( 'This trace console displays real diagnostic telemetry recorded in your local WordPress database. You can inspect request parameters, verify response latencies, preview how your security policies treat specific AI agents, test-resolve raw User-Agent headers, and re-execute logged calls on demand.', 'webmcp-nexus' ); ?>
	</p>
	<div class="wpwm-guide-grid">
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-update" style="color:var(--wpwm-accent);"></span> <?php esc_html_e( '1. Live Audit Replay', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Click "↻ Re-run" on any logged tool call to test current tool output, latency, and permission rules in real-time.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-shield" style="color:var(--wpwm-success);"></span> <?php esc_html_e( '2. Policy Preview', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Click "Preview policy" to check whether an agent is allowed, rate-limited, redacted, or blocked by your security rules.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-search" style="color:var(--wpwm-info);"></span> <?php esc_html_e( '3. User-Agent Debugger', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Paste any incoming User-Agent string below to see its identified AI crawler family and verification status.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
</div>

	<div class="wpwm-card" style="margin-top: var(--wpwm-sp-3);">
		<h2 class="wpwm-h2" style="margin-top:0;"><?php esc_html_e( 'Recent tool calls (audit log)', 'webmcp-nexus' ); ?></h2>
		<?php if ( empty( $wpwebmcp_calls ) ) : ?>
			<div style="padding:14px 16px; background:var(--wpwm-surface, #f6f7f7); border:1px dashed var(--wpwm-border, #dcdcde); border-radius:6px; color:var(--wpwm-text-muted, #646970);">
				<?php esc_html_e( 'No tool calls logged yet. The audit log fills as real agents call your tools.', 'webmcp-nexus' ); ?>
			</div>
		<?php else : ?>
			<table class="widefat striped wpwm-a5-table">
				<thead>
					<tr>
						<th style="width:140px;"><?php esc_html_e( 'When', 'webmcp-nexus' ); ?></th>
						<th style="width:140px;"><?php esc_html_e( 'Agent', 'webmcp-nexus' ); ?></th>
						<th><?php esc_html_e( 'Tool', 'webmcp-nexus' ); ?></th>
						<th style="width:90px;"><?php esc_html_e( 'Status', 'webmcp-nexus' ); ?></th>
						<th style="width:90px;"><?php esc_html_e( 'Latency', 'webmcp-nexus' ); ?></th>
						<th style="width:200px;"><?php esc_html_e( 'Actions', 'webmcp-nexus' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $wpwebmcp_calls as $wpwebmcp_call ) :
						$wpwebmcp_cid      = (int) ( $wpwebmcp_call['id'] ?? 0 );
						$wpwebmcp_tool     = (string) ( $wpwebmcp_call['tool_name'] ?? '' );
						$status   = (string) ( $wpwebmcp_call['status'] ?? '' );
						$wpwebmcp_latency  = (int) ( $wpwebmcp_call['execution_ms'] ?? 0 );
						$wpwebmcp_agent    = (string) ( $wpwebmcp_call['agent_slug'] ?? '' );
						$wpwebmcp_when     = (string) ( $wpwebmcp_call['logged_at'] ?? '' );
						$wpwebmcp_params   = isset( $wpwebmcp_call['params'] ) && is_array( $wpwebmcp_call['params'] ) ? $wpwebmcp_call['params'] : array();
						?>
						<tr data-call-id="<?php echo (int) $wpwebmcp_cid; ?>" data-tool="<?php echo esc_attr( $wpwebmcp_tool ); ?>" data-agent="<?php echo esc_attr( $wpwebmcp_agent ); ?>">
							<td><code class="wpwm-mono" style="font-size:11px;"><?php echo esc_html( $wpwebmcp_when ); ?></code></td>
							<td>
								<?php if ( '' !== $wpwebmcp_agent ) : ?>
									<code class="wpwm-mono"><?php echo esc_html( $wpwebmcp_agent ); ?></code>
								<?php else : ?>
									<span style="color:var(--wpwm-text-muted, #646970);"><?php esc_html_e( 'unknown', 'webmcp-nexus' ); ?></span>
								<?php endif; ?>
							</td>
							<td>
								<strong><?php echo esc_html( $wpwebmcp_tool ); ?></strong>
								<?php if ( ! empty( $wpwebmcp_params ) ) : ?>
									<details style="margin-top:2px;">
										<summary style="cursor:pointer; font-size:11px; color:var(--wpwm-text-muted, #646970);"><?php esc_html_e( 'Params', 'webmcp-nexus' ); ?></summary>
										<pre style="font-size:11px; margin:4px 0 0; max-height:120px; overflow:auto; white-space:pre-wrap;"><?php echo esc_html( wp_json_encode( $wpwebmcp_params, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></pre>
									</details>
								<?php endif; ?>
							</td>
							<td>
								<span class="wpwm-a5-status wpwm-a5-status--<?php echo esc_attr( $status ); ?>"><?php echo esc_html( $status ); ?></span>
							</td>
							<td><?php echo (int) $wpwebmcp_latency; ?> ms</td>
							<td>
								<button type="button" class="button button-small wpwm-a5-rerun" data-call-id="<?php echo (int) $wpwebmcp_cid; ?>"><?php esc_html_e( '↻ Re-run', 'webmcp-nexus' ); ?></button>
								<button type="button" class="button button-small wpwm-a5-preview-policy" data-agent="<?php echo esc_attr( $wpwebmcp_agent ); ?>"><?php esc_html_e( 'Preview policy', 'webmcp-nexus' ); ?></button>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<div id="wpwm-a5-rerun-result" style="display:none; margin-top:12px;"></div>
		<?php endif; ?>
	</div>

	<div class="wpwm-card" style="margin-top: var(--wpwm-sp-4);">
		<h2 class="wpwm-h2" style="margin-top:0;"><?php esc_html_e( 'Recent bot visits (bot log)', 'webmcp-nexus' ); ?></h2>
		<?php if ( empty( $wpwebmcp_bots ) ) : ?>
			<div style="padding:14px 16px; background:var(--wpwm-surface, #f6f7f7); border:1px dashed var(--wpwm-border, #dcdcde); border-radius:6px; color:var(--wpwm-text-muted, #646970);">
				<?php esc_html_e( 'No bot visits logged yet. Hits accumulate as AI agents crawl your content.', 'webmcp-nexus' ); ?>
			</div>
		<?php else : ?>
			<table class="widefat striped wpwm-a5-table">
				<thead>
					<tr>
						<th style="width:140px;"><?php esc_html_e( 'When', 'webmcp-nexus' ); ?></th>
						<th><?php esc_html_e( 'Bot', 'webmcp-nexus' ); ?></th>
						<th style="width:140px;"><?php esc_html_e( 'Category', 'webmcp-nexus' ); ?></th>
						<th style="width:90px;"><?php esc_html_e( 'Hits', 'webmcp-nexus' ); ?></th>
						<th><?php esc_html_e( 'Post', 'webmcp-nexus' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $wpwebmcp_bots as $wpwebmcp_b ) :
						$wpwebmcp_pid    = (int) ( $wpwebmcp_b['post_id'] ?? 0 );
						$title  = $wpwebmcp_pid > 0 ? get_the_title( $wpwebmcp_pid ) : '';
						?>
						<tr>
							<td><code class="wpwm-mono" style="font-size:11px;"><?php echo esc_html( (string) ( $wpwebmcp_b['logged_at'] ?? '' ) ); ?></code></td>
							<td><strong><?php echo esc_html( (string) ( $wpwebmcp_b['bot_name'] ?? '' ) ); ?></strong></td>
							<td><?php echo esc_html( (string) ( $wpwebmcp_b['category'] ?? '' ) ); ?></td>
							<td><?php echo (int) ( $wpwebmcp_b['hits'] ?? 0 ); ?></td>
							<td>
								<?php if ( $wpwebmcp_pid > 0 ) : ?>
									<a href="<?php echo esc_url( get_edit_post_link( $wpwebmcp_pid, 'raw' ) ); ?>"><?php echo esc_html( '' !== $title ? $title : sprintf( '#%d', $wpwebmcp_pid ) ); ?></a>
								<?php else : ?>
									<span style="color:var(--wpwm-text-muted, #646970);">—</span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>

	<div class="wpwm-card" style="margin-top: var(--wpwm-sp-4);">
		<h2 class="wpwm-h2" style="margin-top:0;"><?php esc_html_e( 'Resolve a user-agent', 'webmcp-nexus' ); ?></h2>
		<p class="wpwm-field-helper" style="margin-bottom: var(--wpwm-sp-3);">
			<?php esc_html_e( 'Paste any user-agent string to see how it would be resolved by the agent-identity registry. Useful for debugging unknown AI agents hitting your site.', 'webmcp-nexus' ); ?>
		</p>
		<form id="wpwm-a5-resolver" style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
			<input type="text" id="wpwm-a5-ua" name="user_agent" class="regular-text" style="flex:1; min-width:280px;" placeholder="Mozilla/5.0 (compatible; GPTBot/1.2; +https://openai.com/gptbot)" />
			<button type="submit" class="button button-primary"><?php esc_html_e( 'Resolve', 'webmcp-nexus' ); ?></button>
		</form>
		<div id="wpwm-a5-resolver-result" style="margin-top:12px;"></div>
	</div>

<script type="text/javascript">
(function(){
	var resolveUrl = <?php echo wp_json_encode( $wpwebmcp_resolve_url ); ?>;
	var policyUrl  = <?php echo wp_json_encode( $wpwebmcp_policy_url ); ?>;
	var rerunUrl   = <?php echo wp_json_encode( $wpwebmcp_rerun_url ); ?>;
	var nonce      = <?php echo wp_json_encode( $wpwebmcp_rest_nonce ); ?>;

	function escapeHtml(s){
		return String(s).replace(/[&<>"']/g, function(c){
			return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c];
		});
	}
	function renderBox(id, title, body){
		var el = document.getElementById(id);
		if (!el) return;
		el.style.display = 'block';
		el.innerHTML = '<div class="wpwm-card" style="border-left:4px solid var(--wpwm-accent);">' +
			'<strong>' + escapeHtml(title) + '</strong>' +
			'<pre style="font-size:12px; margin:8px 0 0; white-space:pre-wrap; max-height:340px; overflow:auto;">' + escapeHtml(body) + '</pre>' +
			'</div>';
	}

	// Resolve UA form.
	var resolver = document.getElementById('wpwm-a5-resolver');
	if (resolver) {
		resolver.addEventListener('submit', function(ev){
			ev.preventDefault();
			var ua = document.getElementById('wpwm-a5-ua').value;
			if (!ua) return;
			fetch(resolveUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
				body: JSON.stringify({ user_agent: ua })
			}).then(function(r){ return r.json().then(function(j){ return { s: r.status, j: j }; }); })
			.then(function(out){
				if (out.s !== 200) { renderBox('wpwm-a5-resolver-result', 'Error', out.j && out.j.message ? out.j.message : 'Request failed'); return; }
				renderBox('wpwm-a5-resolver-result', 'Resolved agent', JSON.stringify(out.j.agent, null, 2));
			}).catch(function(){ renderBox('wpwm-a5-resolver-result', 'Network error', 'Could not reach the REST endpoint'); });
		});
	}

	// Re-run button per row.
	document.addEventListener('click', function(ev){
		var t = ev.target;
		if (t && t.classList && t.classList.contains('wpwm-a5-rerun')) {
			ev.preventDefault();
			var cid = t.getAttribute('data-call-id');
			if (!cid) return;
			var original = t.textContent;
			t.textContent = '↻ Re-running…';
			t.disabled = true;
			fetch(rerunUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
				body: JSON.stringify({ call_id: parseInt(cid, 10) })
			}).then(function(r){ return r.json().then(function(j){ return { s: r.status, j: j }; }); })
			.then(function(out){
				t.disabled = false;
				t.textContent = original;
				var title = out.s === 200 ? 'Re-run OK (call #' + cid + ')' : 'Re-run failed (' + (out.j && out.j.message || 'unknown') + ')';
				renderBox('wpwm-a5-rerun-result', title, JSON.stringify(out.j, null, 2));
			}).catch(function(){ t.disabled = false; t.textContent = original; renderBox('wpwm-a5-rerun-result', 'Network error', 'Could not reach the REST endpoint'); });
		}
		if (t && t.classList && t.classList.contains('wpwm-a5-preview-policy')) {
			ev.preventDefault();
			var agent = t.getAttribute('data-agent') || '';
			if (!agent) { renderBox('wpwm-a5-rerun-result', 'No agent on this row', 'Cannot preview policy without an agent_slug'); return; }
			fetch(policyUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
				body: JSON.stringify({ agent_slug: agent, family: '' })
			}).then(function(r){ return r.json().then(function(j){ return { s: r.status, j: j }; }); })
			.then(function(out){
				var title = out.j && out.j.matched ? 'First-match policy for ' + agent : 'No A2a policy matches ' + agent;
				renderBox('wpwm-a5-rerun-result', title, JSON.stringify(out.j, null, 2));
			}).catch(function(){ renderBox('wpwm-a5-rerun-result', 'Network error', 'Could not reach the REST endpoint'); });
		}
	});
})();
</script>
