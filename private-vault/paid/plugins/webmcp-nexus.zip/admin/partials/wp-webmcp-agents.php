<?php
/**
 * Agents admin page partial (M0c).
 *
 * Renders:
 *   - master toggle for agent identity resolution
 *   - per-agent table (toggle, per-minute cap, call count, last seen)
 *   - blocklist textarea (UA-fragment substrings, hard 403)
 *   - diagnostics: a live "what would this resolve for the current request" panel
 *
 * Variables provided by WP_WebMCP_Agents_Page::render():
 *   $registry       array<string, array{...}>
 *   $settings       array<string, array{enabled:bool, per_minute_limit:int}>
 *   $blocklist      array<int, string>
 *   $identity_on    bool
 *   $call_counts    array<string, int>
 *   $last_seen_map  array<string, string> (MySQL datetime)
 *   $wpwebmcp_notice         ?string
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
	wp_die( esc_html__( 'You do not have permission to view this page.', 'webmcp-nexus' ) );
}

// $wpwebmcp_notice is provided by WP_WebMCP_Agents_Page::render().
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only rendering after the save handler ran.
$wpwebmcp_notice = isset( $wpwebmcp_notice ) ? (string) $wpwebmcp_notice : '';
?>
<div class="wpwebmcp-agents-wrap">

<!-- Educational Guide Card -->
<div class="wpwm-guide-card wpwm-guide-card--featured">
	<div class="wpwm-guide-header">
		<span class="wpwm-guide-icon"><span class="dashicons dashicons-groups" aria-hidden="true"></span></span>
		<div>
			<h2 class="wpwm-guide-title"><?php esc_html_e( 'AI Agent Identity & Crawler Access Management', 'webmcp-nexus' ); ?></h2>
			<p class="wpwm-field-helper" style="margin:2px 0 0;"><?php esc_html_e( 'Identify, monitor, and regulate AI engines accessing your WordPress tools.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
	<p class="wpwm-guide-desc">
		<?php esc_html_e( 'Every time an AI assistant or bot visits your website (like ChatGPT, Claude, Perplexity, or Google Gemini), WebMCP Nexus checks their User-Agent, IP CIDR ranges, and reverse-DNS to resolve their true identity. You can customize per-minute rate limits, temporarily disable specific agents, or block aggressive scrapers.', 'webmcp-nexus' ); ?>
	</p>
	<div class="wpwm-guide-grid">
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-shield-alt" style="color:var(--wpwm-success);"></span> <?php esc_html_e( '1. Verified IP & rDNS', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Distinguishes authentic crawler traffic from official provider IP ranges versus fake or spoofed User-Agent headers.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-dashboard" style="color:var(--wpwm-accent);"></span> <?php esc_html_e( '2. Per-Agent Rate Caps', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Set maximum requests per minute per agent to safeguard server CPU and database resources from spikes.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-dismiss" style="color:var(--wpwm-error);"></span> <?php esc_html_e( '3. Instant Blocklist', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Instantly reject traffic matching rogue bot signatures with a hard 403 response before tools run.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
</div>

<?php if ( 'saved' === $wpwebmcp_notice ) : ?>
	<div class="notice notice-success is-dismissible">
		<p><strong><?php esc_html_e( 'Agent settings saved.', 'webmcp-nexus' ); ?></strong></p>
	</div>
<?php elseif ( 'invalid_nonce' === $wpwebmcp_notice ) : ?>
	<div class="notice notice-error is-dismissible">
		<p><strong><?php esc_html_e( 'Security check failed. Please reload the page and try again.', 'webmcp-nexus' ); ?></strong></p>
	</div>
<?php endif; ?>

<form method="post" action="">
	<?php echo WP_WebMCP_Agents_Page::nonce_field(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WP nonce field is safe. ?>

	<div class="wpwm-card" style="margin-top:12px; margin-bottom:16px;">
		<h2 class="wpwm-h2" style="margin-top:0;"><?php esc_html_e( 'Agent Identity Resolution', 'webmcp-nexus' ); ?></h2>
		<p class="wpwm-field-helper" style="margin-bottom:12px;"><?php esc_html_e( 'When enabled, every WebMCP REST response carries an X-WebMCP-Agent-Resolved header so agents can audit how they were identified. Every tool-call log row is tagged with the resolved agent slug. Disable only if you are debugging unrelated issues.', 'webmcp-nexus' ); ?></p>
		<label>
			<input type="checkbox" name="wpwebmcp_agent_identity_enabled" value="1" <?php checked( $identity_on, true ); ?>>
			<strong><?php esc_html_e( 'Enable agent identity resolution', 'webmcp-nexus' ); ?></strong>
		</label>
	</div>

	<div class="wpwm-card" style="margin-top:16px; margin-bottom:16px;">
		<h2 class="wpwm-h2" style="margin-top:0;"><?php esc_html_e( 'Per-Agent Toggles & Rate Limits', 'webmcp-nexus' ); ?></h2>
		<p class="wpwm-field-helper" style="margin-bottom:12px;"><?php esc_html_e( 'Independent buckets. Set per_minute_limit to 0 to fall back to the global rate limit. Disable an agent to reject it with HTTP 403.', 'webmcp-nexus' ); ?></p>
		<table class="widefat striped" style="margin-top:6px;">
			<thead>
				<tr>
					<th style="width:18%;"><?php esc_html_e( 'Agent', 'webmcp-nexus' ); ?></th>
					<th style="width:10%;"><?php esc_html_e( 'Family', 'webmcp-nexus' ); ?></th>
					<th style="width:8%;"><?php esc_html_e( 'Type', 'webmcp-nexus' ); ?></th>
					<th style="width:12%;"><?php esc_html_e( 'Calls', 'webmcp-nexus' ); ?></th>
					<th style="width:14%;"><?php esc_html_e( 'Last seen', 'webmcp-nexus' ); ?></th>
					<th style="width:8%;"><?php esc_html_e( 'Enabled', 'webmcp-nexus' ); ?></th>
					<th style="width:14%;"><?php esc_html_e( 'Per-minute limit', 'webmcp-nexus' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $registry as $wpwebmcp_slug => $wpwebmcp_def ) :
				$wpwebmcp_row        = isset( $settings[ $wpwebmcp_slug ] ) && is_array( $settings[ $wpwebmcp_slug ] ) ? $settings[ $wpwebmcp_slug ] : array( 'enabled' => true, 'per_minute_limit' => 0 );
				$wpwebmcp_enabled    = isset( $wpwebmcp_row['enabled'] ) ? (bool) $wpwebmcp_row['enabled'] : true;
				$wpwebmcp_per_minute = isset( $wpwebmcp_row['per_minute_limit'] ) ? (int) $wpwebmcp_row['per_minute_limit'] : 0;
				$wpwebmcp_count      = isset( $call_counts[ $wpwebmcp_slug ] ) ? (int) $call_counts[ $wpwebmcp_slug ] : 0;
				$wpwebmcp_last_seen  = isset( $last_seen_map[ $wpwebmcp_slug ] ) ? (string) $last_seen_map[ $wpwebmcp_slug ] : '';
			?>
				<tr>
					<td>
						<strong><?php echo esc_html( (string) $wpwebmcp_def['label'] ); ?></strong>
						<div style="color:#646970; font-size:11px;"><?php echo esc_html( (string) $wpwebmcp_slug ); ?></div>
					</td>
					<td><?php echo esc_html( (string) $wpwebmcp_def['family'] ); ?></td>
					<td><?php echo $wpwebmcp_def['is_user'] ? esc_html__( 'user', 'webmcp-nexus' ) : esc_html__( 'operator', 'webmcp-nexus' ); ?></td>
					<td><?php echo esc_html( (string) $wpwebmcp_count ); ?></td>
					<td>
						<?php
						if ( '' === $wpwebmcp_last_seen ) {
							esc_html_e( '—', 'webmcp-nexus' );
						} else {
							$wpwebmcp_ts = strtotime( $wpwebmcp_last_seen . ' UTC' );
							echo esc_html( $wpwebmcp_ts ? human_time_diff( $wpwebmcp_ts, time() ) . ' ' . esc_html__( 'ago', 'webmcp-nexus' ) : $wpwebmcp_last_seen );
						}
						?>
					</td>
					<td>
						<input type="checkbox" name="wpwebmcp_agent_settings[<?php echo esc_attr( $wpwebmcp_slug ); ?>][enabled]" value="1" <?php checked( $wpwebmcp_enabled, true ); ?>>
					</td>
					<td>
						<input type="number" min="0" max="10000" step="1" name="wpwebmcp_agent_settings[<?php echo esc_attr( $wpwebmcp_slug ); ?>][per_minute_limit]" value="<?php echo esc_attr( (string) $wpwebmcp_per_minute ); ?>" class="small-text">
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p style="margin-top:8px; color:#646970;"><?php esc_html_e( '"unknown" agent rows live below — they include any caller we could not match to a known User-Agent.', 'webmcp-nexus' ); ?></p>
		<?php
		$wpwebmcp_unknown_count = isset( $call_counts['unknown'] ) ? (int) $call_counts['unknown'] : 0;
		$wpwebmcp_unknown_seen  = isset( $last_seen_map['unknown'] ) ? (string) $last_seen_map['unknown'] : '';
		?>
		<p>
			<strong><?php esc_html_e( 'unknown:', 'webmcp-nexus' ); ?></strong>
			<?php echo esc_html( (string) $wpwebmcp_unknown_count ); ?>
			<?php esc_html_e( 'calls', 'webmcp-nexus' ); ?>
			<?php if ( '' !== $wpwebmcp_unknown_seen ) : ?>
				— <?php
				$wpwebmcp_ts = strtotime( $wpwebmcp_unknown_seen . ' UTC' );
				echo esc_html( $wpwebmcp_ts ? human_time_diff( $wpwebmcp_ts, time() ) . ' ' . esc_html__( 'ago', 'webmcp-nexus' ) : $wpwebmcp_unknown_seen );
				?>
			<?php endif; ?>
		</p>
	</div>

	<div class="wpwm-card" style="margin-top:16px; margin-bottom:16px;">
		<h2 class="wpwm-h2" style="margin-top:0;"><?php esc_html_e( 'User-Agent Blocklist', 'webmcp-nexus' ); ?></h2>
		<p class="wpwm-field-helper" style="margin-bottom:12px;"><?php esc_html_e( 'Any caller whose User-Agent contains one of these substrings (case-insensitive) gets HTTP 403 before rate-limit or audit. One per line, or comma-separated.', 'webmcp-nexus' ); ?></p>
		<textarea name="wpwebmcp_agent_blocklist" rows="4" class="large-text code" placeholder="bad-bot&#10;scraper-x, scraper-y"><?php echo esc_textarea( implode( "\n", array_map( 'strval', $blocklist ) ) ); ?></textarea>
	</div>

	<div class="wpwm-card" style="margin-top:16px; margin-bottom:16px;">
		<h2 class="wpwm-h2" style="margin-top:0;"><?php esc_html_e( 'Diagnostics — Live Request Resolver Test', 'webmcp-nexus' ); ?></h2>
		<p class="wpwm-field-helper" style="margin-bottom:12px;"><?php esc_html_e( 'Inspect how the agent identity engine currently resolves your administrator session and browser request.', 'webmcp-nexus' ); ?></p>
		<?php
		if ( class_exists( 'WP_WebMCP_Agent_Identity' ) ) {
			// Force a fresh resolve for the current admin request.
			WP_WebMCP_Agent_Identity::reset_cache();
			$wpwebmcp_diag = WP_WebMCP_Agent_Identity::resolve();
			?>
			<table class="widefat striped">
				<tbody>
					<tr><th style="width:24%;"><?php esc_html_e( 'Resolved slug', 'webmcp-nexus' ); ?></th><td><code><?php echo esc_html( (string) $wpwebmcp_diag['slug'] ); ?></code></td></tr>
					<tr><th><?php esc_html_e( 'Label', 'webmcp-nexus' ); ?></th><td><?php echo esc_html( (string) $wpwebmcp_diag['label'] ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Family', 'webmcp-nexus' ); ?></th><td><?php echo esc_html( (string) $wpwebmcp_diag['family'] ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Confidence', 'webmcp-nexus' ); ?></th><td><?php echo esc_html( (string) $wpwebmcp_diag['confidence'] ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Is user agent', 'webmcp-nexus' ); ?></th><td><?php echo $wpwebmcp_diag['is_user'] ? esc_html__( 'yes', 'webmcp-nexus' ) : esc_html__( 'no', 'webmcp-nexus' ); ?></td></tr>
					<tr><th><?php esc_html_e( 'User-Agent', 'webmcp-nexus' ); ?></th><td><code style="word-break:break-all;"><?php echo esc_html( (string) $wpwebmcp_diag['ua'] ); ?></code></td></tr>
					<tr><th><?php esc_html_e( 'Client IP', 'webmcp-nexus' ); ?></th><td><code><?php echo esc_html( (string) $wpwebmcp_diag['ip'] ); ?></code></td></tr>
				</tbody>
			</table>
			<p style="margin-top:8px; color:#646970;">
				<?php esc_html_e( 'Confidence legend: high = UA match + IP CIDR + rDNS, medium = UA match + one IP check, low = UA match only, none = no UA match.', 'webmcp-nexus' ); ?>
			</p>
		<?php } else { ?>
			<p><?php esc_html_e( 'Identity resolver not loaded.', 'webmcp-nexus' ); ?></p>
		<?php } ?>
	</div>

	<p style="margin-top:14px;">
		<button type="submit" class="button button-primary"><?php esc_html_e( 'Save agents settings', 'webmcp-nexus' ); ?></button>
	</p>
</form>
</div>
