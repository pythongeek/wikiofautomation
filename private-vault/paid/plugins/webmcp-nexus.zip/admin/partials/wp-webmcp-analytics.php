<?php
/**
 * Analytics screen — Doc §5.8 #4.
 *
 * Step 5 shell: 3× C4 stat cards skeleton + chart area + two C5 tables
 * skeleton. Data + chart arrive in Step 11.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- Educational Guide Card -->
<div class="wpwm-guide-card wpwm-guide-card--featured">
	<div class="wpwm-guide-header">
		<span class="wpwm-guide-icon"><span class="dashicons dashicons-chart-area" aria-hidden="true"></span></span>
		<div>
			<h2 class="wpwm-guide-title"><?php esc_html_e( 'AI Bot Analytics & Generative Search Traffic', 'webmcp-nexus' ); ?></h2>
			<p class="wpwm-field-helper" style="margin:2px 0 0;"><?php esc_html_e( 'Monitor how artificial intelligence crawlers and search assistants discover and index your WordPress content.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
	<p class="wpwm-guide-desc">
		<?php esc_html_e( 'Next-generation AI engines (like ChatGPT Search, Claude, Google Gemini, and Perplexity) send specialized crawlers to understand your website. WebMCP Nexus tracks these visits so you know which AI models are reading your site, how frequently they crawl, and which pages are most popular for AI citations.', 'webmcp-nexus' ); ?>
	</p>
	<div class="wpwm-guide-grid">
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-search" style="color:var(--wpwm-accent);"></span> <?php esc_html_e( 'Known AI Crawlers', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Automatically tracks GPTBot (OpenAI), ClaudeBot (Anthropic), Google-Extended (Gemini), PerplexityBot, Bytespider, and CCBot.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-performance" style="color:var(--wpwm-success);"></span> <?php esc_html_e( 'GEO Optimization', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Frequent crawler hits indicate your structured schemas and /llms.txt are helping AI engines digest your content accurately.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-admin-settings" style="color:var(--wpwm-info);"></span> <?php esc_html_e( 'Granular Control', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'You can allow or block specific crawlers at any time under Settings &rarr; Integrations &rarr; Crawler directives.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
</div>

<div class="wpwm-card wpwm-card--interactive" style="margin-bottom: var(--wpwm-sp-4); display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
	<div>
		<strong style="font-size:14px; color:var(--wpwm-text); display:flex; align-items:center; gap:6px;">
			<span>🧪</span> <?php esc_html_e( 'Test & Verify AI Bot Telemetry', 'webmcp-nexus' ); ?>
		</strong>
		<p class="wpwm-field-helper" style="margin:2px 0 0;">
			<?php esc_html_e( 'Simulate an incoming AI crawler request to immediately verify that the tracking pipeline, database logging, and graphs are active.', 'webmcp-nexus' ); ?>
		</p>
	</div>
	<div style="display:flex; gap:8px; align-items:center;">
		<select id="wpwm-sim-bot-select" class="wpwm-select" style="max-width:200px;">
			<option value="Google-Extended (Gemini)">Google Gemini (Google-Extended)</option>
			<option value="Google AI / Gemini">Google AI / Gemini (GoogleOther)</option>
			<option value="GPTBot (OpenAI)">ChatGPT / GPTBot (OpenAI)</option>
			<option value="ClaudeBot (Anthropic)">ClaudeBot (Anthropic)</option>
			<option value="PerplexityBot">PerplexityBot (Search)</option>
			<option value="Apple Intelligence">Apple Intelligence (Applebot)</option>
		</select>
		<button type="button" class="button button-primary" id="wpwm-btn-simulate-ping">
			⚡ <?php esc_html_e( 'Simulate Bot Visit', 'webmcp-nexus' ); ?>
		</button>
		<button type="button" class="button" id="wpwm-btn-refresh-analytics" title="<?php esc_attr_e( 'Refresh Stats', 'webmcp-nexus' ); ?>">
			<span class="dashicons dashicons-update" style="margin-top:4px;"></span>
		</button>
	</div>
</div>

<div class="wpwm-stat-grid">
	<div class="wpwm-stat"><p class="wpwm-stat-label"><?php esc_html_e( 'Bot visits (Last 30 Days)', 'webmcp-nexus' ); ?></p><p class="wpwm-stat-value" data-wpwm-stat="bot_visits_30d">—</p><span class="wpwm-stat-sub"><?php esc_html_e( 'Total AI crawler hits', 'webmcp-nexus' ); ?></span></div>
	<div class="wpwm-stat"><p class="wpwm-stat-label"><?php esc_html_e( 'Unique AI Bots Detected', 'webmcp-nexus' ); ?></p><p class="wpwm-stat-value" data-wpwm-stat="unique_bots">—</p><span class="wpwm-stat-sub"><?php esc_html_e( 'Distinct AI platforms', 'webmcp-nexus' ); ?></span></div>
	<div class="wpwm-stat"><p class="wpwm-stat-label"><?php esc_html_e( 'Most Active Bot', 'webmcp-nexus' ); ?></p><p class="wpwm-stat-value" data-wpwm-stat="top_bot">—</p><span class="wpwm-stat-sub"><?php esc_html_e( 'Highest crawl volume', 'webmcp-nexus' ); ?></span></div>
</div>

<div class="wpwm-row">
	<div class="wpwm-col">
		<div class="wpwm-card">
			<h2 class="wpwm-h2"><?php esc_html_e( 'Visits over time', 'webmcp-nexus' ); ?></h2>
			<div class="wpwm-skel" style="height:220px" data-wpwm-chart-placeholder aria-label="<?php esc_attr_e( 'Chart loading', 'webmcp-nexus' ); ?>"></div>
		</div>
	</div>
</div>

<div class="wpwm-row">
	<div class="wpwm-col">
		<h2 class="wpwm-h2"><?php esc_html_e( 'By bot', 'webmcp-nexus' ); ?></h2>
		<table class="wpwm-table" data-wpwm-by-bot-table>
			<thead><tr><th scope="col"><?php esc_html_e( 'Bot', 'webmcp-nexus' ); ?></th><th scope="col"><?php esc_html_e( 'Hits', 'webmcp-nexus' ); ?></th></tr></thead>
			<tbody><tr><td colspan="2"><div class="wpwm-skel"></div></td></tr></tbody>
		</table>
	</div>
	<div class="wpwm-col">
		<h2 class="wpwm-h2"><?php esc_html_e( 'Top pages', 'webmcp-nexus' ); ?></h2>
		<table class="wpwm-table" data-wpwm-top-pages-table>
			<thead><tr><th scope="col"><?php esc_html_e( 'Page', 'webmcp-nexus' ); ?></th><th scope="col"><?php esc_html_e( 'Hits', 'webmcp-nexus' ); ?></th></tr></thead>
			<tbody><tr><td colspan="2"><div class="wpwm-skel"></div></td></tr></tbody>
		</table>
	</div>
</div>