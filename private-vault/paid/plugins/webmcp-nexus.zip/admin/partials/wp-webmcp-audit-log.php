<?php
/**
 * Audit Log screen — Doc §5.8 #5.
 *
 * Real-time tool-call and write audit log viewer, filter bar, CSV export,
 * clear log modal, and option rollback interface.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- Educational Guide Card -->
<div class="wpwm-guide-card wpwm-guide-card--featured">
	<div class="wpwm-guide-header">
		<span class="wpwm-guide-icon"><span class="dashicons dashicons-list-view" aria-hidden="true"></span></span>
		<div>
			<h2 class="wpwm-guide-title"><?php esc_html_e( 'How to Read the Audit Log & Diagnose AI Activity', 'webmcp-nexus' ); ?></h2>
			<p class="wpwm-field-helper" style="margin:2px 0 0;"><?php esc_html_e( 'Inspect real-time AI tool executions, response latencies, and security events.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
	<p class="wpwm-guide-desc">
		<?php esc_html_e( 'Every time an AI assistant or visitor invokes a WebMCP tool on your website, the request details are recorded in this audit log. This helps you verify that agents are getting accurate responses and ensure your rate limits are keeping your site safe.', 'webmcp-nexus' ); ?>
	</p>
	<div class="wpwm-guide-grid">
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-clock" style="color:var(--wpwm-accent);"></span> <?php esc_html_e( 'Execution Latency (ms)', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Shows how fast your WordPress server answered the agent query in milliseconds (typically 5ms to 40ms).', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-yes-alt" style="color:var(--wpwm-success);"></span> <?php esc_html_e( 'Status Codes Explained', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Success = valid response; Rate limited = bot exceeded request limits; Error = invalid parameters.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-download" style="color:var(--wpwm-info);"></span> <?php esc_html_e( 'Filtering & Exporting', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Filter by tool name or date range to inspect specific agent sessions, or click Export CSV for reporting.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
</div>

<div class="wpwm-filterbar" data-wpwm-filterbar>
	<select data-wpwm-filter="view" aria-label="<?php esc_attr_e( 'Filter by view', 'webmcp-nexus' ); ?>">
		<option value=""><?php esc_html_e( 'All entries', 'webmcp-nexus' ); ?></option>
		<option value="tool_calls"><?php esc_html_e( 'Tool calls', 'webmcp-nexus' ); ?></option>
		<option value="writes"><?php esc_html_e( 'Write history', 'webmcp-nexus' ); ?></option>
	</select>
	<select data-wpwm-filter="tool_name" aria-label="<?php esc_attr_e( 'Filter by tool', 'webmcp-nexus' ); ?>">
		<option value=""><?php esc_html_e( 'All tools', 'webmcp-nexus' ); ?></option>
	</select>
	<select data-wpwm-filter="status" aria-label="<?php esc_attr_e( 'Filter by status', 'webmcp-nexus' ); ?>">
		<option value=""><?php esc_html_e( 'Any status', 'webmcp-nexus' ); ?></option>
		<option value="success"><?php esc_html_e( 'Success', 'webmcp-nexus' ); ?></option>
		<option value="error"><?php esc_html_e( 'Error', 'webmcp-nexus' ); ?></option>
		<option value="rate_limited"><?php esc_html_e( 'Rate limited', 'webmcp-nexus' ); ?></option>
		<option value="auth_failed"><?php esc_html_e( 'Auth failed', 'webmcp-nexus' ); ?></option>
		<option value="rolled_back"><?php esc_html_e( 'Rolled back', 'webmcp-nexus' ); ?></option>
	</select>
	<input type="date" data-wpwm-filter="date_from" aria-label="<?php esc_attr_e( 'From date', 'webmcp-nexus' ); ?>">
	<input type="date" data-wpwm-filter="date_to" aria-label="<?php esc_attr_e( 'To date', 'webmcp-nexus' ); ?>">
	<input type="search" data-wpwm-filter="search" placeholder="<?php esc_attr_e( 'Search', 'webmcp-nexus' ); ?>" aria-label="<?php esc_attr_e( 'Search', 'webmcp-nexus' ); ?>">
	<button class="button" data-wpwm-action="apply-filters"><?php esc_html_e( 'Apply', 'webmcp-nexus' ); ?></button>
	<button class="button" data-wpwm-action="reset-filters"><?php esc_html_e( 'Reset', 'webmcp-nexus' ); ?></button>
</div>

<div class="wpwm-row">
	<div class="wpwm-col wpwm-col--wide">
		<table class="wpwm-table" data-wpwm-log-table>
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Time', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Type', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Target / Tool', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Status', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'ms', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Actor', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'IP', 'webmcp-nexus' ); ?></th>
					<th scope="col" class="wpwm-col-actions"><?php esc_html_e( 'Action', 'webmcp-nexus' ); ?></th>
				</tr>
			</thead>
			<tbody data-wpwm-log-body>
				<tr><td colspan="8"><div class="wpwm-skel"></div></td></tr>
				<tr><td colspan="8"><div class="wpwm-skel"></div></td></tr>
			</tbody>
		</table>
	</div>
</div>

<p class="wpwm-actions-row">
	<a href="#" class="button" data-wpwm-action="export-csv"><?php esc_html_e( 'Export CSV', 'webmcp-nexus' ); ?></a>
	<a href="#" class="button" data-wpwm-open-modal="#wpwm-clear-log-modal"><?php esc_html_e( 'Clear log', 'webmcp-nexus' ); ?></a>
</p>

<div id="wpwm-clear-log-modal" class="wpwm-modal" role="dialog" aria-modal="true" aria-labelledby="wpwm-clear-log-title" aria-hidden="true">
	<div class="wpwm-modal-dialog">
		<h2 id="wpwm-clear-log-title" class="wpwm-modal-title"><?php esc_html_e( 'Clear audit log?', 'webmcp-nexus' ); ?></h2>
		<p class="wpwm-modal-consequence"><?php esc_html_e( 'This deletes every entry. The action cannot be undone.', 'webmcp-nexus' ); ?></p>
		<div class="wpwm-modal-actions">
			<button type="button" class="button" data-wpwm-close-modal><?php esc_html_e( 'Cancel', 'webmcp-nexus' ); ?></button>
			<button type="button" class="button button-primary" data-wpwm-confirm-clear><?php esc_html_e( 'Clear log', 'webmcp-nexus' ); ?></button>
		</div>
	</div>
</div>

<div id="wpwm-rollback-modal" class="wpwm-modal" role="dialog" aria-modal="true" aria-labelledby="wpwm-rollback-title" aria-hidden="true">
	<div class="wpwm-modal-dialog">
		<h2 id="wpwm-rollback-title" class="wpwm-modal-title"><?php esc_html_e( 'Rollback this change?', 'webmcp-nexus' ); ?></h2>
		<p class="wpwm-modal-consequence" data-wpwm-rollback-target><?php esc_html_e( 'Restores the prior option value.', 'webmcp-nexus' ); ?></p>
		<div class="wpwm-modal-actions">
			<button type="button" class="button" data-wpwm-close-modal><?php esc_html_e( 'Cancel', 'webmcp-nexus' ); ?></button>
			<button type="button" class="button button-primary" data-wpwm-confirm-rollback><?php esc_html_e( 'Rollback', 'webmcp-nexus' ); ?></button>
		</div>
	</div>
</div>