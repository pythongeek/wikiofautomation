<?php
/**
 * Admin partial — Citation leaderboard (A1d).
 *
 * Variables supplied by WP_WebMCP_Citation_Leaderboard_Page::render():
 *   $rows, $totals, $recent_visits, $recent_calls, $generated_at
 *
 * Empty-state policy: if a table has no rows, show a single muted
 * "no data yet" line — never fabricated sample rows.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- Educational Guide Card -->
<div class="wpwm-guide-card wpwm-guide-card--featured">
	<div class="wpwm-guide-header">
		<span class="wpwm-guide-icon"><span class="dashicons dashicons-chart-bar" aria-hidden="true"></span></span>
		<div>
			<h2 class="wpwm-guide-title"><?php esc_html_e( 'AI Citation Leaderboard & Attribution Tracker', 'webmcp-nexus' ); ?></h2>
			<p class="wpwm-field-helper" style="margin:2px 0 0;"><?php esc_html_e( 'Track which generative AI models cite your content most and verify their identity.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
	<p class="wpwm-guide-desc">
		<?php esc_html_e( 'When AI assistants (like ChatGPT, Claude, Perplexity, or Copilot) answer questions using your content, they attribute answers back to your pages. This leaderboard tracks real tool calls from your audit log and visits from your bot log to show which AI platforms cite your WordPress site most.', 'webmcp-nexus' ); ?>
	</p>
	<div class="wpwm-guide-grid">
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-shield-alt" style="color:var(--wpwm-success);"></span> <?php esc_html_e( '1. Verified Identity', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'High confidence means the agent verified via official IP CIDRs and reverse-DNS suffix. Low means User-Agent only.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-media-document" style="color:var(--wpwm-accent);"></span> <?php esc_html_e( '2. Pages Cited', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Displays the exact count of unique posts and articles referenced by each AI engine.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-database" style="color:var(--wpwm-info);"></span> <?php esc_html_e( '3. Real Local DB Stats', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( '100% self-hosted on your WordPress database. Zero external API calls, tracking cookies, or mock data.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
</div>

	<h2><?php esc_html_e( 'Last 30 days', 'webmcp-nexus' ); ?></h2>
	<div class="wpwebmcp-card wpwebmcp-stats">
		<table class="widefat striped" role="presentation">
			<tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Tool calls', 'webmcp-nexus' ); ?></th>
					<td><code><?php echo (int) $totals['total_tool_calls']; ?></code></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Bot visits', 'webmcp-nexus' ); ?></th>
					<td><code><?php echo (int) $totals['total_bot_visits']; ?></code></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Distinct agents (called)', 'webmcp-nexus' ); ?></th>
					<td><code><?php echo (int) $totals['distinct_agents']; ?></code></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Pages cited (distinct)', 'webmcp-nexus' ); ?></th>
					<td><code><?php echo (int) $totals['pages_cited']; ?></code></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Generated', 'webmcp-nexus' ); ?></th>
					<td><code><?php echo esc_html( $generated_at ); ?></code> <span class="description"><?php esc_html_e( 'GMT', 'webmcp-nexus' ); ?></span></td>
				</tr>
			</tbody>
		</table>
	</div>

	<hr/>

	<h2><?php esc_html_e( 'Per-agent ranking', 'webmcp-nexus' ); ?></h2>
	<p class="description">
		<?php
		printf(
			/* translators: %1$s: High label, %2$s: Medium label, %3$s: Low label */
			esc_html__( 'Confidence is the ceiling this agent can reach given its registry definition: %1$s = both IP CIDRs and rDNS suffix published (cryptographically verifiable), %2$s = one of them, %3$s = UA-pattern-only (UA strings are spoofable).', 'webmcp-nexus' ),
			'<code>high</code>',
			'<code>medium</code>',
			'<code>low</code>'
		);
		?>
	</p>
	<?php if ( empty( $rows ) ) : ?>
		<p class="wpwm-muted"><?php esc_html_e( 'No data yet. The leaderboard will populate as agents call your tools and visit your pages.', 'webmcp-nexus' ); ?></p>
	<?php else : ?>
		<table class="widefat striped wpwm-table" role="presentation">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Agent', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Family', 'webmcp-nexus' ); ?></th>
					<th scope="col">
						<?php esc_html_e( 'Confidence', 'webmcp-nexus' ); ?>
						<span class="description" style="font-weight:normal;">
							<?php esc_html_e( '(registry ceiling)', 'webmcp-nexus' ); ?>
						</span>
					</th>
					<th scope="col"><?php esc_html_e( 'Tool calls', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Bot visits', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Pages cited', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Last seen', 'webmcp-nexus' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $rows as $wpwebmcp_r ) :
					$wpwebmcp_conf = isset( $wpwebmcp_r['confidence'] ) ? (string) $wpwebmcp_r['confidence'] : 'low';
					if ( 'high'   === $wpwebmcp_conf ) { $wpwebmcp_conf_color = '#1a7f37'; $wpwebmcp_conf_label = 'high'; }
					elseif ( 'medium' === $wpwebmcp_conf ) { $wpwebmcp_conf_color = '#9a6700'; $wpwebmcp_conf_label = 'medium'; }
					else { $wpwebmcp_conf_color = '#9a9a9a'; $wpwebmcp_conf_label = 'low'; }
				?>
					<tr>
						<td>
							<strong><?php echo esc_html( (string) $wpwebmcp_r['label'] ); ?></strong>
							<?php if ( ! empty( $wpwebmcp_r['is_user'] ) ) : ?>
								<span class="description">user-action</span>
							<?php endif; ?>
							<br/>
							<code style="font-size:11px;"><?php echo esc_html( (string) $wpwebmcp_r['slug'] ); ?></code>
						</td>
						<td><code><?php echo esc_html( (string) $wpwebmcp_r['family'] ); ?></code></td>
						<td>
							<span style="color:<?php echo esc_attr( $wpwebmcp_conf_color ); ?>;font-weight:600;" title="<?php echo esc_attr( $wpwebmcp_conf === 'high' ? 'Registry has IP CIDRs + rDNS suffix — requests can be verified cryptographically.' : ( $wpwebmcp_conf === 'medium' ? 'Registry has IP CIDRs or rDNS suffix — partial verification possible.' : 'Registry only has UA patterns — UA-spoofable, treat with caution.' ) ); ?>">
								<?php echo esc_html( $wpwebmcp_conf_label ); ?>
							</span>
						</td>
						<td><code><?php echo (int) $wpwebmcp_r['tool_calls']; ?></code></td>
						<td><code><?php echo (int) $wpwebmcp_r['bot_visits']; ?></code></td>
						<td><code><?php echo (int) $wpwebmcp_r['pages_cited']; ?></code></td>
						<td><code><?php echo esc_html( (string) $wpwebmcp_r['last_seen'] ); ?></code></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>

	<hr/>

	<h2><?php esc_html_e( 'Recent tool calls (with agent)', 'webmcp-nexus' ); ?></h2>
	<?php if ( empty( $recent_calls ) ) : ?>
		<p class="wpwm-muted"><?php esc_html_e( 'No tool calls logged yet.', 'webmcp-nexus' ); ?></p>
	<?php else : ?>
		<table class="widefat striped wpwm-table" role="presentation">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Time (GMT)', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Tool', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Agent', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Status', 'webmcp-nexus' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $recent_calls as $wpwebmcp_c ) : ?>
					<tr>
						<td><code style="font-size:11px;"><?php echo esc_html( (string) $wpwebmcp_c['ts'] ); ?></code></td>
						<td><code><?php echo esc_html( (string) $wpwebmcp_c['tool'] ); ?></code></td>
						<td><code><?php echo esc_html( (string) $wpwebmcp_c['agent_slug'] ); ?></code></td>
						<td>
							<?php if ( 'success' === (string) $wpwebmcp_c['status'] ) : ?>
								<span style="color:#1a7f37;"><?php echo esc_html( (string) $wpwebmcp_c['status'] ); ?></span>
							<?php elseif ( 'rate_limited' === (string) $wpwebmcp_c['status'] ) : ?>
								<span style="color:#9a6700;"><?php echo esc_html( (string) $wpwebmcp_c['status'] ); ?></span>
							<?php else : ?>
								<span style="color:#cf222e;"><?php echo esc_html( (string) $wpwebmcp_c['status'] ); ?></span>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>

	<hr/>

	<h2><?php esc_html_e( 'Recent bot visits', 'webmcp-nexus' ); ?></h2>
	<?php if ( empty( $recent_visits ) ) : ?>
		<p class="wpwm-muted"><?php esc_html_e( 'No bot visits logged yet.', 'webmcp-nexus' ); ?></p>
	<?php else : ?>
		<table class="widefat striped wpwm-table" role="presentation">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Time (GMT)', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Agent', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Post', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Hits', 'webmcp-nexus' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $recent_visits as $wpwebmcp_v ) : ?>
					<tr>
						<td><code style="font-size:11px;"><?php echo esc_html( (string) $wpwebmcp_v['ts'] ); ?></code></td>
						<td>
							<?php echo esc_html( (string) $wpwebmcp_v['bot_name'] ); ?>
							<br/><code style="font-size:11px;"><?php echo esc_html( (string) $wpwebmcp_v['slug'] ); ?></code>
						</td>
						<td>
							<?php if ( $wpwebmcp_v['post_id'] > 0 ) : ?>
								<?php echo esc_html( (string) ( '' !== $wpwebmcp_v['post_title'] ? $wpwebmcp_v['post_title'] : '(post #' . (int) $wpwebmcp_v['post_id'] . ')' ) ); ?>
								<br/><code style="font-size:11px;">id=<?php echo (int) $wpwebmcp_v['post_id']; ?></code>
							<?php else : ?>
								<span class="description">non-post URL</span>
							<?php endif; ?>
						</td>
						<td><code><?php echo (int) $wpwebmcp_v['hits']; ?></code></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>

	<p class="description" style="margin-top:24px;">
		<?php
		printf(
			/* translators: %s: REST endpoint URL */
			esc_html__( 'JSON snapshot: %s', 'webmcp-nexus' ),
			'<code>' . esc_html( rest_url( 'wpwebmcp/v1/citation-leaderboard' ) ) . '</code>'
		);
		?>
	</p>

<style>
.wpwebmcp-wrap .wpwebmcp-card { background:#fff; border:1px solid #c3c4c7; border-radius:4px; padding:16px; margin:8px 0 16px; max-width:980px; }
.wpwebmcp-wrap .wpwebmcp-stats table th { width:280px; }
.wpwebmcp-wrap .wpwm-muted { color:#646970; font-style:italic; }
.wpwebmcp-wrap .wpwm-table code { font-size:11px; word-break:break-all; }
</style>
