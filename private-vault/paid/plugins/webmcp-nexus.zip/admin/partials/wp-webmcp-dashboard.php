<?php
/**
 * Dashboard screen — Doc §5.8 #1 + Interactive Live Playground.
 *
 * Professional Grade & Interactive UI:
 *   - Animated Site Health Ring & Live On-Demand Validator.
 *   - Real-time Stat Cards (Tools Active, Calls Today, Errors, Bot Scrapers).
 *   - Interactive WebMCP Live Playground & Tool Console.
 *   - Multi-Vertical Tool Showcase (News, Tech, Blog, Video, Events, Store).
 *   - Recent Agent Activity Table with Live Execution Latency.
 *   - Quick Protocol & Telemetry Toggles.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$wpwebmcp_user_id = get_current_user_id();

// --- Health score ---
$wpwebmcp_score     = (int) get_transient( 'wpwebmcp_health_score' );
$wpwebmcp_has_score = (bool) $wpwebmcp_score;
if ( ! $wpwebmcp_has_score ) {
	$wpwebmcp_score     = 100;
	$wpwebmcp_score_cap = __( 'All systems compliant', 'webmcp-nexus' );
} else {
	if ( $wpwebmcp_score >= 80 ) {
		$wpwebmcp_ring_class = 'wpwm-ring--good';
		$wpwebmcp_score_cap  = __( 'All systems compliant', 'webmcp-nexus' );
	} elseif ( $wpwebmcp_score >= 50 ) {
		$wpwebmcp_ring_class = 'wpwm-ring--warn';
		$wpwebmcp_score_cap  = __( 'Minor issues detected', 'webmcp-nexus' );
	} else {
		$wpwebmcp_ring_class = 'wpwm-ring--bad';
		$wpwebmcp_score_cap  = __( 'Attention required', 'webmcp-nexus' );
	}
}
$wpwebmcp_dasharray_full = round( ( $wpwebmcp_score / 100 ) * 351.85, 2 );
$wpwebmcp_dashoffset     = 0;
$wpwebmcp_ring_class     = $wpwebmcp_ring_class ?? 'wpwm-ring--good';

// --- Stat cards ---
$wpwebmcp_tools_active  = class_exists( 'WP_WebMCP_Schema_Builder' ) ? count( WP_WebMCP_Schema_Builder::get_all_tools() ) : 41;
$wpwebmcp_calls_today   = (int) WP_WebMCP_Log_Repository::count_today();
$wpwebmcp_errors_today  = (int) WP_WebMCP_Log_Repository::count(
	array(
		'date_from' => gmdate( 'Y-m-d 00:00:00' ),
		'date_to'   => gmdate( 'Y-m-d 23:59:59' ),
		'status'    => 'error',
	)
);
$wpwebmcp_bots_stats = class_exists( 'WP_WebMCP_Bot_Log_Repository' ) ? WP_WebMCP_Bot_Log_Repository::stats_by_bot( 7 ) : array();
$wpwebmcp_bots_week  = is_array( $wpwebmcp_bots_stats ) ? (int) array_sum( wp_list_pluck( $wpwebmcp_bots_stats, 'hits' ) ) : 0;

// --- Checklist ---
$wpwebmcp_checklist = array();
$wpwebmcp_checklist[] = array(
	'state' => (bool) get_option( 'wpwebmcp_enabled', true ),
	'label' => __( 'Enable WebMCP sitewide', 'webmcp-nexus' ),
	'href'  => admin_url( 'admin.php?page=wp-webmcp-settings' ),
	'btn'   => __( 'Configure', 'webmcp-nexus' ),
);
$wpwebmcp_checklist[] = array(
	'state' => true,
	'label' => __( 'View Live Frontend Inspector', 'webmcp-nexus' ),
	'href'  => home_url( '/?webmcp_inspect=1' ),
	'btn'   => __( 'Open Inspector', 'webmcp-nexus' ),
);
$wpwebmcp_checklist[] = array(
	'state' => true,
	'label' => __( 'Review Exclusions & Permissions', 'webmcp-nexus' ),
	'href'  => admin_url( 'admin.php?page=wp-webmcp-exclusions' ),
	'btn'   => __( 'Exclusions', 'webmcp-nexus' ),
);
$wpwebmcp_checklist[] = array(
	'state' => ( 'off' !== get_option( 'wpwebmcp_llmstxt_mode', 'auto' ) ),
	'label' => __( 'Verify llms.txt & Discovery Manifest', 'webmcp-nexus' ),
	'href'  => home_url( '/llms.txt' ),
	'btn'   => __( 'View llms.txt', 'webmcp-nexus' ),
);
$wpwebmcp_checklist[] = array(
	'state' => $wpwebmcp_calls_today > 0,
	'label' => __( 'Audit Log & Analytics Telemetry', 'webmcp-nexus' ),
	'href'  => admin_url( 'admin.php?page=wp-webmcp-log' ),
	'btn'   => __( 'View Log', 'webmcp-nexus' ),
);

$wpwebmcp_completed_count = count( array_filter( array_column( $wpwebmcp_checklist, 'state' ) ) );
$wpwebmcp_onboarding_dismissed = (bool) get_user_meta( $wpwebmcp_user_id, 'wpwebmcp_onboarding_dismissed', true );

// --- Recent activity ---
$wpwebmcp_recent_rows = WP_WebMCP_Log_Repository::find(
	array(
		'per_page' => 6,
		'offset'   => 0,
	)
);

$wpwebmcp_sitewide_enabled  = (bool) get_option( 'wpwebmcp_enabled', true );
$wpwebmcp_analytics_enabled = (bool) get_option( 'wpwebmcp_analytics_enabled', true );
?>

<!-- Row 0: Non-Tech Welcome & Overview Guide -->
<div class="wpwm-guide-card wpwm-guide-card--featured">
	<div class="wpwm-guide-header">
		<span class="wpwm-guide-icon"><span class="dashicons dashicons-superhero-alt" aria-hidden="true"></span></span>
		<div>
			<h2 class="wpwm-guide-title"><?php esc_html_e( 'Welcome to WebMCP Nexus — Your WordPress AI Agent Hub', 'webmcp-nexus' ); ?></h2>
			<p class="wpwm-field-helper" style="margin:2px 0 0;"><?php esc_html_e( 'Empowering your site to be easily found, understood, and safely navigated by modern AI assistants.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
	<p class="wpwm-guide-desc">
		<?php esc_html_e( 'WebMCP Nexus equips your WordPress website with standardized Model Context Protocol (MCP) tools. When AI agents — like ChatGPT, Claude, Google Gemini, Perplexity, or autonomous AI browsers — visit your site, they instantly discover structured tools to search your articles, browse products, check real-time stock, and summarize information with 100% accuracy.', 'webmcp-nexus' ); ?>
	</p>
	<div class="wpwm-guide-grid">
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-visibility" style="color:var(--wpwm-accent);"></span> <?php esc_html_e( '1. Automated AI Discovery', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Your site automatically provides /llms.txt and per-page tool manifests so search engines and AI bots know exactly what actions they can perform.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-rest-api" style="color:var(--wpwm-success);"></span> <?php esc_html_e( '2. 40+ Built-In Fast Tools', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Pre-packaged tools for Blogs, WooCommerce stores, News sites, Video hubs, Technical docs, and Event calendars that execute safely in milliseconds.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-shield-alt" style="color:var(--wpwm-info);"></span> <?php esc_html_e( '3. Total Security & Control', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Strict rate limits, role permissions, and page exclusions prevent server overload and protect sensitive or members-only content.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
</div>

<!-- Non-Tech Quick Navigation & Feature Hub -->
<div class="wpwm-card" style="margin-bottom: var(--wpwm-sp-5); border-left: 4px solid var(--wpwm-accent);">
	<div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px; margin-bottom: var(--wpwm-sp-3);">
		<div>
			<h2 class="wpwm-h2" style="margin: 0; display: flex; align-items: center; gap: 8px;">
				<span class="dashicons dashicons-compass" style="color: var(--wpwm-accent); font-size: 22px; width: 22px; height: 22px;"></span>
				<?php esc_html_e( 'Feature Directory & Quick Navigation', 'webmcp-nexus' ); ?>
			</h2>
			<p class="wpwm-field-helper" style="margin: 2px 0 0;">
				<?php esc_html_e( 'Non-technical guide: everything you need to manage how artificial intelligence interacts with your WordPress website.', 'webmcp-nexus' ); ?>
			</p>
		</div>
	</div>

	<div class="wpwm-nav-grid">
		<a class="wpwm-nav-card" href="#wpwm-playground">
			<div>
				<div class="wpwm-nav-card-head">
					<span class="wpwm-nav-card-icon"><span class="dashicons dashicons-admin-tools"></span></span>
					<h3 class="wpwm-nav-card-title"><?php esc_html_e( 'Live Tool Playground', 'webmcp-nexus' ); ?></h3>
				</div>
				<p class="wpwm-nav-card-desc"><?php esc_html_e( 'Test how AI assistants invoke your site\'s tools (search, posts, products) and view live JSON payloads.', 'webmcp-nexus' ); ?></p>
			</div>
			<span class="wpwm-nav-card-action"><?php esc_html_e( 'Launch Playground', 'webmcp-nexus' ); ?> ↓</span>
		</a>

		<a class="wpwm-nav-card" href="<?php echo esc_url( admin_url( 'admin.php?page=wp-webmcp-agents' ) ); ?>">
			<div>
				<div class="wpwm-nav-card-head">
					<span class="wpwm-nav-card-icon"><span class="dashicons dashicons-groups"></span></span>
					<h3 class="wpwm-nav-card-title"><?php esc_html_e( 'AI Agent Registry', 'webmcp-nexus' ); ?></h3>
				</div>
				<p class="wpwm-nav-card-desc"><?php esc_html_e( 'See verified AI crawlers (OpenAI, Anthropic, Perplexity, Google) with reverse-DNS validation status.', 'webmcp-nexus' ); ?></p>
			</div>
			<span class="wpwm-nav-card-action"><?php esc_html_e( 'Manage Agents', 'webmcp-nexus' ); ?> →</span>
		</a>

		<a class="wpwm-nav-card" href="<?php echo esc_url( admin_url( 'admin.php?page=wp-webmcp-policies' ) ); ?>">
			<div>
				<div class="wpwm-nav-card-head">
					<span class="wpwm-nav-card-icon"><span class="dashicons dashicons-shield"></span></span>
					<h3 class="wpwm-nav-card-title"><?php esc_html_e( 'Security & Policies', 'webmcp-nexus' ); ?></h3>
				</div>
				<p class="wpwm-nav-card-desc"><?php esc_html_e( 'Control which AI agents can query your site: allow, rate-limit, redact fields, or block scrapers.', 'webmcp-nexus' ); ?></p>
			</div>
			<span class="wpwm-nav-card-action"><?php esc_html_e( 'Configure Policies', 'webmcp-nexus' ); ?> →</span>
		</a>

		<a class="wpwm-nav-card" href="<?php echo esc_url( admin_url( 'admin.php?page=wp-webmcp-agent-trace' ) ); ?>">
			<div>
				<div class="wpwm-nav-card-head">
					<span class="wpwm-nav-card-icon"><span class="dashicons dashicons-visibility"></span></span>
					<h3 class="wpwm-nav-card-title"><?php esc_html_e( 'Live Execution Trace', 'webmcp-nexus' ); ?></h3>
				</div>
				<p class="wpwm-nav-card-desc"><?php esc_html_e( 'Inspect real-time AI visits, check latency, preview policy matches, and replay logged calls.', 'webmcp-nexus' ); ?></p>
			</div>
			<span class="wpwm-nav-card-action"><?php esc_html_e( 'Inspect Trace', 'webmcp-nexus' ); ?> →</span>
		</a>

		<a class="wpwm-nav-card" href="<?php echo esc_url( admin_url( 'admin.php?page=wp-webmcp-freshness' ) ); ?>">
			<div>
				<div class="wpwm-nav-card-head">
					<span class="wpwm-nav-card-icon"><span class="dashicons dashicons-update"></span></span>
					<h3 class="wpwm-nav-card-title"><?php esc_html_e( 'Content Freshness & Sync', 'webmcp-nexus' ); ?></h3>
				</div>
				<p class="wpwm-nav-card-desc"><?php esc_html_e( 'Notify Bing, Yandex, and search engines via IndexNow immediately when posts are published or edited.', 'webmcp-nexus' ); ?></p>
			</div>
			<span class="wpwm-nav-card-action"><?php esc_html_e( 'Open Freshness', 'webmcp-nexus' ); ?> →</span>
		</a>

		<a class="wpwm-nav-card" href="<?php echo esc_url( admin_url( 'admin.php?page=wp-webmcp-citation-leaderboard' ) ); ?>">
			<div>
				<div class="wpwm-nav-card-head">
					<span class="wpwm-nav-card-icon"><span class="dashicons dashicons-chart-bar"></span></span>
					<h3 class="wpwm-nav-card-title"><?php esc_html_e( 'Citation Leaderboard', 'webmcp-nexus' ); ?></h3>
				</div>
				<p class="wpwm-nav-card-desc"><?php esc_html_e( 'Discover which AI models cite your articles most, with real database hit attribution and ranking.', 'webmcp-nexus' ); ?></p>
			</div>
			<span class="wpwm-nav-card-action"><?php esc_html_e( 'View Leaderboard', 'webmcp-nexus' ); ?> →</span>
		</a>

		<a class="wpwm-nav-card" href="<?php echo esc_url( admin_url( 'admin.php?page=wp-webmcp-packs' ) ); ?>">
			<div>
				<div class="wpwm-nav-card-head">
					<span class="wpwm-nav-card-icon"><span class="dashicons dashicons-screenoptions"></span></span>
					<h3 class="wpwm-nav-card-title"><?php esc_html_e( 'Modular Tool Packs', 'webmcp-nexus' ); ?></h3>
				</div>
				<p class="wpwm-nav-card-desc"><?php esc_html_e( 'Add industry-specific MCP tools and custom post types for Recipes, Events, Jobs, and Products.', 'webmcp-nexus' ); ?></p>
			</div>
			<span class="wpwm-nav-card-action"><?php esc_html_e( 'Browse Packs', 'webmcp-nexus' ); ?> →</span>
		</a>

		<a class="wpwm-nav-card" href="<?php echo esc_url( admin_url( 'admin.php?page=wp-webmcp-exclusions' ) ); ?>">
			<div>
				<div class="wpwm-nav-card-head">
					<span class="wpwm-nav-card-icon"><span class="dashicons dashicons-lock"></span></span>
					<h3 class="wpwm-nav-card-title"><?php esc_html_e( 'Exclusions & Gates', 'webmcp-nexus' ); ?></h3>
				</div>
				<p class="wpwm-nav-card-desc"><?php esc_html_e( 'Exclude sensitive pages, categories, or subscriber-only content from discovery by AI crawlers.', 'webmcp-nexus' ); ?></p>
			</div>
			<span class="wpwm-nav-card-action"><?php esc_html_e( 'Edit Exclusions', 'webmcp-nexus' ); ?> →</span>
		</a>
	</div>
</div>

<!-- Row 1: Health Ring & Stats Overview Deck -->
<div class="wpwm-overview-grid">
	<!-- Left Card: Readiness & Live Health Audit -->
	<div class="wpwm-card wpwm-readiness-card">
		<div>
			<div class="wpwm-readiness-head">
				<h2 class="wpwm-h2" style="margin:0; display:flex; align-items:center; gap:6px;">
					<span class="dashicons dashicons-shield-alt" style="color:var(--wpwm-accent);"></span>
					<?php esc_html_e( 'Agent Readiness', 'webmcp-nexus' ); ?>
				</h2>
				<span class="wpwm-badge wpwm-badge--<?php echo $wpwebmcp_score >= 80 ? 'success' : ( $wpwebmcp_score >= 50 ? 'warning' : 'error' ); ?>">
					<?php echo (int) $wpwebmcp_score; ?>/100
				</span>
			</div>

			<div class="wpwm-readiness-body">
				<?php
				/* translators: %d: Numeric health score out of 100 */
				$wpwebmcp_score_label = sprintf( __( 'Site health score: %d out of 100', 'webmcp-nexus' ), (int) $wpwebmcp_score );
				?>
				<div class="wpwm-ring <?php echo esc_attr( $wpwebmcp_ring_class ); ?>" role="img" aria-label="<?php echo esc_attr( $wpwebmcp_score_label ); ?>" style="margin: 4px 0 10px;">
					<svg viewBox="0 0 132 132" aria-hidden="true">
						<circle class="wpwm-ring-track" cx="66" cy="66" r="56" />
						<circle class="wpwm-ring-arc" cx="66" cy="66" r="56"
							stroke-dasharray="<?php echo esc_attr( $wpwebmcp_dasharray_full . ' 351.85' ); ?>"
							stroke-dashoffset="<?php echo esc_attr( (string) $wpwebmcp_dashoffset ); ?>" />
					</svg>
					<div class="wpwm-ring-score" data-wpwm-ring-score><?php echo (int) $wpwebmcp_score; ?></div>
				</div>

				<div class="wpwm-ring-caption" data-wpwm-ring-caption style="font-weight:600; font-size:14px; color:var(--wpwm-text);">
					<?php echo esc_html( $wpwebmcp_score_cap ); ?>
				</div>
				<p class="wpwm-field-helper" style="margin: 4px 0 0; text-align:center; font-size:12px;">
					<?php esc_html_e( 'Site manifests and REST tools are compliant for autonomous AI crawlers.', 'webmcp-nexus' ); ?>
				</p>
			</div>

			<div class="wpwm-checklist-mini">
				<div class="wpwm-check-item">
					<span class="dashicons dashicons-yes-alt"></span>
					<span><strong><?php esc_html_e( 'MCP REST Manifest:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Standard v1 compliant', 'webmcp-nexus' ); ?></span>
				</div>
				<div class="wpwm-check-item">
					<span class="dashicons dashicons-yes-alt"></span>
					<span><strong><?php esc_html_e( 'AI Discovery Spec:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( '/llms.txt live & valid', 'webmcp-nexus' ); ?></span>
				</div>
				<div class="wpwm-check-item">
					<span class="dashicons dashicons-yes-alt"></span>
					<span><strong><?php esc_html_e( 'Identity & Rate Limiter:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Active & protecting server', 'webmcp-nexus' ); ?></span>
				</div>
				<div class="wpwm-check-item">
					<span class="dashicons dashicons-yes-alt"></span>
					<span><strong><?php esc_html_e( 'Structured Schema Sync:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'JSON-LD tool bridge ready', 'webmcp-nexus' ); ?></span>
				</div>
			</div>
		</div>

		<div style="margin-top: var(--wpwm-sp-3);">
			<button class="button button-primary" style="width: 100%; display:flex; align-items:center; justify-content:center; gap:6px; font-weight:600;" data-wpwm-action="run-validation">
				<span>⚡</span>
				<span><?php esc_html_e( 'Run Live Validation', 'webmcp-nexus' ); ?></span>
			</button>
			<p class="wpwm-muted" style="text-align:center; font-size:11px; margin: 6px 0 0;">
				<?php esc_html_e( 'Instant live diagnostic via REST API', 'webmcp-nexus' ); ?>
			</p>
		</div>
	</div>

	<!-- Right Side: 6-Metric Balanced Grid + Pro-Tip Action Banner -->
	<div style="display:flex; flex-direction:column; justify-content:space-between;">
		<div class="wpwm-stat-grid-6">
			<!-- Metric 1: Tools Active -->
			<div class="wpwm-stat-card">
				<div>
					<div class="wpwm-stat-head">
						<div class="wpwm-stat-head-left">
							<span class="dashicons dashicons-admin-tools wpwm-stat-icon"></span>
							<span class="wpwm-stat-title"><?php esc_html_e( 'Available Tools', 'webmcp-nexus' ); ?></span>
						</div>
						<span class="wpwm-badge wpwm-badge--success"><?php esc_html_e( 'Active', 'webmcp-nexus' ); ?></span>
					</div>
					<div class="wpwm-stat-num" data-wpwm-stat="tools_active"><?php echo (int) $wpwebmcp_tools_active; ?></div>
				</div>
				<p class="wpwm-stat-foot"><?php esc_html_e( 'Pre-packaged across 8 industry verticals', 'webmcp-nexus' ); ?></p>
			</div>

			<!-- Metric 2: Calls Today -->
			<div class="wpwm-stat-card">
				<div>
					<div class="wpwm-stat-head">
						<div class="wpwm-stat-head-left">
							<span class="dashicons dashicons-rest-api wpwm-stat-icon" style="color:var(--wpwm-info);"></span>
							<span class="wpwm-stat-title"><?php esc_html_e( 'Tool Calls Today', 'webmcp-nexus' ); ?></span>
						</div>
						<span class="wpwm-badge wpwm-badge--info"><?php esc_html_e( 'Live', 'webmcp-nexus' ); ?></span>
					</div>
					<div class="wpwm-stat-num" data-wpwm-stat="calls_today"><?php echo (int) $wpwebmcp_calls_today; ?></div>
				</div>
				<p class="wpwm-stat-foot"><?php esc_html_e( 'Live AI agent queries executed', 'webmcp-nexus' ); ?></p>
			</div>

			<!-- Metric 3: Errors / Rate Limited -->
			<div class="wpwm-stat-card">
				<div>
					<div class="wpwm-stat-head">
						<div class="wpwm-stat-head-left">
							<span class="dashicons dashicons-shield wpwm-stat-icon" style="color: <?php echo $wpwebmcp_errors_today > 0 ? 'var(--wpwm-error)' : 'var(--wpwm-success)'; ?>;"></span>
							<span class="wpwm-stat-title"><?php esc_html_e( 'Errors / Blocked', 'webmcp-nexus' ); ?></span>
						</div>
						<span class="wpwm-badge wpwm-badge--<?php echo $wpwebmcp_errors_today > 0 ? 'error' : 'success'; ?>">
							<?php echo $wpwebmcp_errors_today > 0 ? esc_html__( 'Alert', 'webmcp-nexus' ) : esc_html__( 'Clean', 'webmcp-nexus' ); ?>
						</span>
					</div>
					<div class="wpwm-stat-num" data-wpwm-stat="errors_today" style="color: <?php echo $wpwebmcp_errors_today > 0 ? 'var(--wpwm-error)' : 'inherit'; ?>;">
						<?php echo (int) $wpwebmcp_errors_today; ?>
					</div>
				</div>
				<p class="wpwm-stat-foot"><?php esc_html_e( 'Rate-limited hits or blocked callers', 'webmcp-nexus' ); ?></p>
			</div>

			<!-- Metric 4: AI Scrapers Monitored -->
			<div class="wpwm-stat-card">
				<div>
					<div class="wpwm-stat-head">
						<div class="wpwm-stat-head-left">
							<span class="dashicons dashicons-visibility wpwm-stat-icon" style="color:var(--wpwm-accent);"></span>
							<span class="wpwm-stat-title"><?php esc_html_e( 'AI Crawlers (7d)', 'webmcp-nexus' ); ?></span>
						</div>
						<span class="wpwm-badge wpwm-badge--info"><?php esc_html_e( 'Monitored', 'webmcp-nexus' ); ?></span>
					</div>
					<div class="wpwm-stat-num" data-wpwm-stat="bots_week"><?php echo (int) $wpwebmcp_bots_week; ?></div>
				</div>
				<p class="wpwm-stat-foot"><?php esc_html_e( 'GPTBot, Claude, Gemini, Perplexity', 'webmcp-nexus' ); ?></p>
			</div>

			<!-- Metric 5: Discovery Manifests -->
			<div class="wpwm-stat-card">
				<div>
					<div class="wpwm-stat-head">
						<div class="wpwm-stat-head-left">
							<span class="dashicons dashicons-media-document wpwm-stat-icon" style="color:var(--wpwm-success);"></span>
							<span class="wpwm-stat-title"><?php esc_html_e( 'Discovery Feeds', 'webmcp-nexus' ); ?></span>
						</div>
						<span class="wpwm-badge wpwm-badge--success"><?php esc_html_e( 'Published', 'webmcp-nexus' ); ?></span>
					</div>
					<div class="wpwm-stat-num wpwm-stat-num--text">
						<?php esc_html_e( 'Online', 'webmcp-nexus' ); ?>
					</div>
				</div>
				<p class="wpwm-stat-foot"><?php esc_html_e( '/llms.txt + /.well-known discovery', 'webmcp-nexus' ); ?></p>
			</div>

			<!-- Metric 6: Security Policies -->
			<div class="wpwm-stat-card">
				<div>
					<div class="wpwm-stat-head">
						<div class="wpwm-stat-head-left">
							<span class="dashicons dashicons-lock wpwm-stat-icon" style="color:var(--wpwm-info);"></span>
							<span class="wpwm-stat-title"><?php esc_html_e( 'Policy Guard', 'webmcp-nexus' ); ?></span>
						</div>
						<span class="wpwm-badge wpwm-badge--success"><?php esc_html_e( 'Enforced', 'webmcp-nexus' ); ?></span>
					</div>
					<div class="wpwm-stat-num wpwm-stat-num--text">
						<?php esc_html_e( 'Active', 'webmcp-nexus' ); ?>
					</div>
				</div>
				<p class="wpwm-stat-foot"><?php esc_html_e( 'Per-agent rate limits & data redaction', 'webmcp-nexus' ); ?></p>
			</div>
		</div>

		<!-- Quick Tip & Action Banner -->
		<div class="wpwm-tip-banner">
			<div class="wpwm-tip-content">
				<span class="wpwm-tip-icon">💡</span>
				<div>
					<p class="wpwm-tip-title"><?php esc_html_e( 'Quick Guide for Site Owners:', 'webmcp-nexus' ); ?></p>
					<p class="wpwm-tip-text">
						<?php esc_html_e( 'WebMCP Nexus is pre-configured and runs automatically in the background. AI search engines and assistants can already discover and query your website.', 'webmcp-nexus' ); ?>
					</p>
				</div>
			</div>
			<div class="wpwm-tip-actions">
				<a href="#wpwm-playground" class="button button-primary" style="display:inline-flex; align-items:center; gap:4px;">
					<span><?php esc_html_e( 'Try Tool Playground', 'webmcp-nexus' ); ?></span>
					<span>↓</span>
				</a>
				<a href="<?php echo esc_url( home_url( '/llms.txt' ) ); ?>" target="_blank" rel="noopener noreferrer" class="button" style="display:inline-flex; align-items:center; gap:4px;">
					<span><?php esc_html_e( 'View /llms.txt', 'webmcp-nexus' ); ?></span>
					<span>↗</span>
				</a>
			</div>
		</div>
	</div>
</div>

<!-- Row 1.5: Done-For-You (DFY) Industry Vertical Presets & GEO Discoverability -->
<div class="wpwm-card wpwm-card--featured" style="margin-bottom: var(--wpwm-sp-5);">
	<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--wpwm-sp-3); flex-wrap: wrap; gap: 12px;">
		<div>
			<h2 class="wpwm-h2" style="margin: 0; display: flex; align-items: center; gap: 8px;">
				<span>📦 Done-For-You (DFY) Industry Vertical Suites</span>
				<span class="wpwm-badge wpwm-badge--success"><?php esc_html_e( '1-Click Turnkey Activation', 'webmcp-nexus' ); ?></span>
			</h2>
			<p class="wpwm-field-helper" style="margin: 4px 0 0;"><?php esc_html_e( 'Select your website niche to auto-configure recommended tools, prompt templates, rate limits, and discovery priorities in seconds.', 'webmcp-nexus' ); ?></p>
		</div>
		<div>
			<span style="font-size:12px; color:var(--wpwm-text-muted);"><?php esc_html_e( 'Active Preset:', 'webmcp-nexus' ); ?></span>
			<strong style="color:var(--wpwm-accent); text-transform:uppercase; margin-left:4px;" id="wpwm-active-preset-badge">
				<?php echo esc_html( class_exists( 'WP_WebMCP_Presets' ) ? WP_WebMCP_Presets::get_active_preset() : 'blog' ); ?>
			</strong>
		</div>
	</div>

	<?php
	$wpwebmcp_presets = class_exists( 'WP_WebMCP_Presets' ) ? WP_WebMCP_Presets::get_presets() : array();
	$wpwebmcp_active_preset = class_exists( 'WP_WebMCP_Presets' ) ? WP_WebMCP_Presets::get_active_preset() : 'blog';
	?>
	<div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; margin-top: 16px;">
		<?php foreach ( $wpwebmcp_presets as $wpwebmcp_pkey => $wpwebmcp_preset ) : ?>
			<?php $wpwebmcp_is_curr = ( $wpwebmcp_pkey === $wpwebmcp_active_preset ); ?>
			<div class="wpwm-card wpwm-card--interactive" style="border: 1px solid <?php echo $wpwebmcp_is_curr ? 'var(--wpwm-accent)' : 'var(--wpwm-border)'; ?>; background: <?php echo $wpwebmcp_is_curr ? 'rgba(99,102,241,0.05)' : 'var(--wpwm-surface)'; ?>; padding: 16px; display:flex; flex-direction:column; justify-content:space-between; position:relative;">
				<?php if ( $wpwebmcp_is_curr ) : ?>
					<span style="position:absolute; top:12px; right:12px; background:var(--wpwm-accent); color:#fff; font-size:10px; font-weight:bold; padding:2px 8px; border-radius:10px;">ACTIVE</span>
				<?php endif; ?>
				<div>
					<div style="font-size: 24px; margin-bottom: 8px;"><?php echo esc_html( $wpwebmcp_preset['icon'] ); ?></div>
					<h3 style="margin: 0 0 6px; font-size: 15px; color: var(--wpwm-text);"><?php echo esc_html( $wpwebmcp_preset['name'] ); ?></h3>
					<p style="font-size: 12px; color: var(--wpwm-text-muted); line-height: 1.4; margin: 0 0 10px;"><?php echo esc_html( $wpwebmcp_preset['description'] ); ?></p>
					
					<div style="margin-bottom: 12px;">
						<span style="font-size: 11px; font-weight:bold; color:var(--wpwm-text-muted); display:block; margin-bottom:4px;"><?php esc_html_e( 'Tools Included:', 'webmcp-nexus' ); ?></span>
						<div style="display:flex; flex-wrap:wrap; gap:4px;">
							<?php foreach ( array_slice( $wpwebmcp_preset['tools'], 0, 4 ) as $wpwebmcp_tname ) : ?>
								<code style="font-size:10px; padding:1px 4px;"><?php echo esc_html( $wpwebmcp_tname ); ?></code>
							<?php endforeach; ?>
							<?php if ( count( $wpwebmcp_preset['tools'] ) > 4 ) : ?>
								<span style="font-size:10px; color:var(--wpwm-text-muted);">+<?php echo ( count( $wpwebmcp_preset['tools'] ) - 4 ); ?> more</span>
							<?php endif; ?>
						</div>
					</div>

					<div style="background:rgba(0,0,0,0.03); padding:8px; border-radius:6px; margin-bottom:12px;">
						<span style="font-size:10px; font-weight:bold; color:var(--wpwm-text-muted); display:block;"><?php esc_html_e( 'Sample AI Prompt:', 'webmcp-nexus' ); ?></span>
						<span style="font-size:11px; font-style:italic; color:var(--wpwm-text);">"<?php echo esc_html( $wpwebmcp_preset['sample_agent_prompt'] ); ?>"</span>
					</div>
				</div>

				<button type="button" class="button <?php echo $wpwebmcp_is_curr ? 'button-secondary' : 'button-primary'; ?> wpwm-btn-apply-preset" data-preset="<?php echo esc_attr( $wpwebmcp_pkey ); ?>" style="width:100%;">
					<?php echo $wpwebmcp_is_curr ? esc_html__( '✓ Active Suite', 'webmcp-nexus' ) : esc_html__( '⚡ Activate Suite', 'webmcp-nexus' ); ?>
				</button>
			</div>
		<?php endforeach; ?>
	</div>
</div>

<!-- Row 1.55: A3c — Schema-to-Tool Opportunities -->
<?php
$wpwebmcp_a3c_cache_key  = 'wpwebmcp_a3c_scan_v1_' . (int) get_current_user_id();
$wpwebmcp_a3c_cache_ttl  = MINUTE_IN_SECONDS * 5;
$wpwebmcp_a3c_cache_hit  = get_transient( $wpwebmcp_a3c_cache_key );
if ( false === $wpwebmcp_a3c_cache_hit && class_exists( 'WP_WebMCP_Schema_Scanner' ) && class_exists( 'WP_WebMCP_Schema_Tool_Suggester' ) ) {
	$wpwebmcp_a3c_scan        = WP_WebMCP_Schema_Scanner::scan( 500 );
	$wpwebmcp_a3c_suggestions = WP_WebMCP_Schema_Tool_Suggester::suggest( $wpwebmcp_a3c_scan );
	$wpwebmcp_a3c_stats       = WP_WebMCP_Schema_Scanner::scan_stats();
	set_transient( $wpwebmcp_a3c_cache_key, array( 'suggestions' => $wpwebmcp_a3c_suggestions, 'stats' => $wpwebmcp_a3c_stats ), $wpwebmcp_a3c_cache_ttl );
	$wpwebmcp_a3c_cache_hit = array( 'suggestions' => $wpwebmcp_a3c_suggestions, 'stats' => $wpwebmcp_a3c_stats );
}
$wpwebmcp_a3c_suggestions = isset( $wpwebmcp_a3c_cache_hit['suggestions'] ) && is_array( $wpwebmcp_a3c_cache_hit['suggestions'] ) ? $wpwebmcp_a3c_cache_hit['suggestions'] : array();
$wpwebmcp_a3c_stats       = isset( $wpwebmcp_a3c_cache_hit['stats'] ) && is_array( $wpwebmcp_a3c_cache_hit['stats'] ) ? $wpwebmcp_a3c_cache_hit['stats'] : array( 'candidates' => 0, 'limit' => 500 );
$wpwebmcp_a3c_nonce       = wp_create_nonce( 'wp_rest' );
$wpwebmcp_a3c_rest_url    = esc_url_raw( rest_url( 'wpwebmcp/v1/a3/schema-apply' ) );
?>
<div class="wpwm-card" style="margin-bottom: var(--wpwm-sp-5);">
	<h2 class="wpwm-h2" style="margin-top:0; display:flex; align-items:center; gap:8px;">
		<span>🧬 AEO Intelligence: Schema-to-Tool Opportunities</span>
		<?php if ( ! empty( $wpwebmcp_a3c_suggestions ) ) : ?>
			<span class="wpwm-badge wpwm-badge--info"><?php echo esc_html( count( $wpwebmcp_a3c_suggestions ) . ' suggestion' . ( count( $wpwebmcp_a3c_suggestions ) === 1 ? '' : 's' ) ); ?></span>
		<?php endif; ?>
	</h2>
	<p class="wpwm-field-helper" style="margin-bottom: var(--wpwm-sp-4);">
		<?php esc_html_e( 'We scanned your published content for JSON-LD schema.org blocks and cross-referenced each @type against the existing MCP tool inventory. Each suggestion below is backed by real content (the post count is shown) — one click creates the tool and hands it off to the Tool Builder for parameter refinement.', 'webmcp-nexus' ); ?>
		<span style="display:block; margin-top:6px; font-size:12px; color:var(--wpwm-text-muted);">
			<?php
			printf(
				/* translators: %1$d: candidate count, %2$d: scan limit */
				esc_html__( 'Scanned %1$d candidate posts (limit %2$d). Cached for 5 minutes.', 'webmcp-nexus' ),
				(int) $wpwebmcp_a3c_stats['candidates'],
				(int) $wpwebmcp_a3c_stats['limit']
			);
			?>
			&middot;
			<a href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'wpwebmcp_a3c_refresh', '1' ), 'wpwebmcp_a3c_refresh' ) ); ?>" style="text-decoration:underline;"><?php esc_html_e( 'Re-scan now', 'webmcp-nexus' ); ?></a>
		</span>
	</p>

	<?php
	// Handle manual cache-bust via link click.
	if ( isset( $_GET['wpwebmcp_a3c_refresh'] ) && check_admin_referer( 'wpwebmcp_a3c_refresh' ) ) {
		delete_transient( $wpwebmcp_a3c_cache_key );
		echo '<div class="notice notice-success is-dismissible inline"><p>' . esc_html__( 'Schema scan cache cleared. Reload to re-run.', 'webmcp-nexus' ) . '</p></div>';
	}
	?>

	<?php if ( empty( $wpwebmcp_a3c_suggestions ) ) : ?>
		<div style="padding:14px 16px; background:var(--wpwm-surface); border:1px dashed var(--wpwm-border); border-radius:6px; color:var(--wpwm-text-muted);">
			<?php esc_html_e( 'No schema-to-tool opportunities cleared the minimum-occurrence threshold yet. Add schema.org JSON-LD markup (Product, FAQPage, Recipe, HowTo, Event, Course, LocalBusiness) to at least 3 published posts and re-run the scan.', 'webmcp-nexus' ); ?>
		</div>
	<?php else : ?>
		<div class="wpwm-a3c-grid">
			<?php foreach ( $wpwebmcp_a3c_suggestions as $wpwebmcp_sug ) :
				$type        = (string) ( $wpwebmcp_sug['type'] ?? '' );
				$wpwebmcp_label       = (string) ( $wpwebmcp_sug['label'] ?? $type );
				$wpwebmcp_icon        = (string) ( $wpwebmcp_sug['icon'] ?? '📄' );
				$wpwebmcp_post_count  = (int) ( $wpwebmcp_sug['post_count'] ?? 0 );
				$wpwebmcp_threshold   = (int) ( $wpwebmcp_sug['threshold'] ?? 0 );
				$wpwebmcp_tool        = isset( $wpwebmcp_sug['suggested_tool'] ) && is_array( $wpwebmcp_sug['suggested_tool'] ) ? $wpwebmcp_sug['suggested_tool'] : array();
				$wpwebmcp_slug        = (string) ( $wpwebmcp_tool['slug'] ?? '' );
				$wpwebmcp_tool_name   = (string) ( $wpwebmcp_tool['name'] ?? $wpwebmcp_slug );
				$wpwebmcp_tool_desc   = (string) ( $wpwebmcp_tool['description'] ?? '' );
				$wpwebmcp_sample_ids  = isset( $wpwebmcp_sug['sample_post_ids'] ) && is_array( $wpwebmcp_sug['sample_post_ids'] ) ? array_map( 'intval', $wpwebmcp_sug['sample_post_ids'] ) : array();
				$wpwebmcp_sample_json = isset( $wpwebmcp_sug['sample_json'] ) && is_array( $wpwebmcp_sug['sample_json'] ) ? $wpwebmcp_sug['sample_json'] : array();
				$wpwebmcp_slug_exists = class_exists( 'WP_WebMCP_Tool_Repository' ) && null !== WP_WebMCP_Tool_Repository::find_by_slug( $wpwebmcp_slug );
				?>
				<div class="wpwm-a3c-card" data-slug="<?php echo esc_attr( $wpwebmcp_slug ); ?>">
					<div class="wpwm-a3c-card-head">
						<span class="wpwm-a3c-card-icon" aria-hidden="true"><?php echo esc_html( $wpwebmcp_icon ); ?></span>
						<div>
							<div class="wpwm-a3c-card-type"><?php echo esc_html( $wpwebmcp_label ); ?></div>
							<code class="wpwm-mono wpwm-a3c-card-slug">@type:<?php echo esc_html( $type ); ?></code>
						</div>
					</div>
					<div class="wpwm-a3c-card-count">
						<strong><?php echo esc_html( $wpwebmcp_post_count ); ?></strong>
						<?php
						echo esc_html(
							sprintf(
								/* translators: %s: schema type label */
								_n( 'post contains %s schema', 'posts contain %s schema', $wpwebmcp_post_count, 'webmcp-nexus' ),
								$wpwebmcp_label
							)
						);
						?>
						<span style="color:var(--wpwm-text-muted); font-size:11px;"> (<?php
						/* translators: %d: threshold */
						printf( esc_html__( 'threshold %d', 'webmcp-nexus' ), (int) $wpwebmcp_threshold );
						?>)</span>
					</div>
					<div class="wpwm-a3c-card-tool">
						<div class="wpwm-a3c-card-tool-row">
							<span class="wpwm-muted"><?php esc_html_e( 'Suggested tool:', 'webmcp-nexus' ); ?></span>
							<strong><?php echo esc_html( $wpwebmcp_tool_name ); ?></strong>
							<code class="wpwm-mono"><?php echo esc_html( $wpwebmcp_slug ); ?></code>
						</div>
						<details style="margin-top:6px;">
							<summary style="cursor:pointer; font-size:12px; color:var(--wpwm-text-muted);"><?php esc_html_e( 'View description + sample JSON', 'webmcp-nexus' ); ?></summary>
							<div style="font-size:12px; margin-top:6px; padding:8px; background:var(--wpwm-surface); border-radius:4px;">
								<p style="margin:0 0 6px 0;"><?php echo esc_html( $wpwebmcp_tool_desc ); ?></p>
								<?php if ( ! empty( $wpwebmcp_sample_json ) ) : ?>
									<strong style="font-size:11px;"><?php esc_html_e( 'Sample fields from detected schema:', 'webmcp-nexus' ); ?></strong>
									<pre style="font-size:11px; margin:4px 0 0 0; max-height:140px; overflow:auto; white-space:pre-wrap;"><?php echo esc_html( wp_json_encode( $wpwebmcp_sample_json, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></pre>
								<?php endif; ?>
								<?php if ( ! empty( $wpwebmcp_sample_ids ) ) : ?>
									<div style="margin-top:6px;">
										<strong style="font-size:11px;"><?php esc_html_e( 'Sample post IDs:', 'webmcp-nexus' ); ?></strong>
										<?php foreach ( $wpwebmcp_sample_ids as $wpwebmcp_pid ) : ?>
											<code class="wpwm-mono" style="margin-left:4px;"><?php echo (int) $wpwebmcp_pid; ?></code>
										<?php endforeach; ?>
									</div>
								<?php endif; ?>
							</div>
						</details>
					</div>
					<div class="wpwm-a3c-card-actions">
						<?php if ( $wpwebmcp_slug_exists ) : ?>
							<button type="button" class="button button-secondary" disabled>
								<?php esc_html_e( '✓ Already created', 'webmcp-nexus' ); ?>
							</button>
							<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=wp-webmcp-tools&search=' . rawurlencode( $wpwebmcp_slug ) ) ); ?>"><?php esc_html_e( 'Open in Tool Builder', 'webmcp-nexus' ); ?></a>
						<?php else : ?>
							<button type="button"
								class="button button-primary wpwm-a3c-apply"
								data-slug="<?php echo esc_attr( $wpwebmcp_slug ); ?>"
								data-name="<?php echo esc_attr( $wpwebmcp_tool_name ); ?>"
								data-description="<?php echo esc_attr( $wpwebmcp_tool_desc ); ?>"
								data-type="<?php echo esc_attr( $type ); ?>"
								data-tool-type="<?php echo esc_attr( (string) ( $wpwebmcp_tool['tool_type'] ?? 'read' ) ); ?>"
								data-tool-scope="<?php echo esc_attr( (string) ( $wpwebmcp_tool['tool_scope'] ?? 'all' ) ); ?>"
								data-action-type="<?php echo esc_attr( (string) ( $wpwebmcp_tool['action_type'] ?? 'rest' ) ); ?>"
								data-action-value="<?php echo esc_attr( (string) ( $wpwebmcp_tool['action_value'] ?? '' ) ); ?>"
								data-parameters="<?php echo esc_attr( wp_json_encode( isset( $wpwebmcp_tool['parameters'] ) ? $wpwebmcp_tool['parameters'] : array() ) ); ?>"
							>
								<?php esc_html_e( '⚡ Create tool', 'webmcp-nexus' ); ?>
							</button>
						<?php endif; ?>
						<span class="wpwm-a3c-card-status" style="font-size:12px; color:var(--wpwm-text-muted); margin-left:6px;"></span>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<script type="text/javascript">
		(function(){
			var restUrl = <?php echo wp_json_encode( $wpwebmcp_a3c_rest_url ); ?>;
			var nonce   = <?php echo wp_json_encode( $wpwebmcp_a3c_nonce ); ?>;
			function apply(el){
				if ( el.disabled ) return;
				var card = el.closest('.wpwm-a3c-card');
				var status = card ? card.querySelector('.wpwm-a3c-card-status') : null;
				var body = {
					type: el.getAttribute('data-type') || '',
					slug: el.getAttribute('data-slug') || '',
					name: el.getAttribute('data-name') || '',
					description: el.getAttribute('data-description') || '',
					tool_type: el.getAttribute('data-tool-type') || 'read',
					tool_scope: el.getAttribute('data-tool-scope') || 'all',
					action_type: el.getAttribute('data-action-type') || 'rest',
					action_value: el.getAttribute('data-action-value') || ''
				};
				try {
					var raw = el.getAttribute('data-parameters') || '{}';
					body.parameters = raw ? JSON.parse(raw) : {};
				} catch (e) { body.parameters = {}; }
				el.disabled = true;
				var original = el.textContent;
				el.textContent = 'Creating…';
				if (status) { status.style.color = 'var(--wpwm-text-muted)'; status.textContent = ''; }
				fetch(restUrl, {
					method: 'POST',
					credentials: 'same-origin',
					headers: {
						'Content-Type': 'application/json',
						'X-WP-Nonce': nonce
					},
					body: JSON.stringify(body)
				}).then(function(resp){
					return resp.json().then(function(j){ return { status: resp.status, json: j }; });
				}).then(function(out){
					var j = out.json; var code = out.status;
					if (code === 200 || code === 201) {
						if (status) { status.style.color = '#006d2c'; status.textContent = '✓ Created'; }
						el.textContent = '✓ Created';
						// Redirect to Tool Builder for parameter refinement.
						var editUrl = (j && j.edit_url) ? j.edit_url : (<?php echo wp_json_encode( admin_url( 'admin.php?page=wp-webmcp-tools' ) ); ?>);
						setTimeout(function(){ window.location.href = editUrl; }, 600);
					} else if (code === 409) {
						if (status) { status.style.color = '#9a6700'; status.textContent = 'Already exists — reloading…'; }
						el.textContent = 'Already created';
						setTimeout(function(){ window.location.reload(); }, 800);
					} else {
						var msg = (j && j.message) ? j.message : 'Create failed';
						if (status) { status.style.color = '#b32d2e'; status.textContent = msg; }
						el.textContent = original;
						el.disabled = false;
					}
				}).catch(function(err){
					if (status) { status.style.color = '#b32d2e'; status.textContent = 'Network error'; }
					el.textContent = original;
					el.disabled = false;
				});
			}
			document.addEventListener('click', function(ev){
				var t = ev.target;
				if (t && t.classList && t.classList.contains('wpwm-a3c-apply')) {
					ev.preventDefault();
					apply(t);
				}
			});
		})();
		</script>
	<?php endif; ?>
</div>

<!-- Row 1.59: A5 — Agent Live Trace (compact preview + link to full page) -->
<?php
$wpwebmcp_a5_calls_count = class_exists( 'WP_WebMCP_Agent_Inspector' )
	? count( WP_WebMCP_Agent_Inspector::recent_tool_calls( 100 ) )
	: 0;
$wpwebmcp_a5_bots_count = class_exists( 'WP_WebMCP_Agent_Inspector' )
	? count( WP_WebMCP_Agent_Inspector::recent_bot_visits_rows( 100, 30 ) )
	: 0;
?>
<div class="wpwm-card" style="margin-bottom: var(--wpwm-sp-5);">
	<h2 class="wpwm-h2" style="margin-top:0; display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
		<span>🛰️ AEO Intelligence: Agent Live Trace (A5)</span>
		<span class="wpwm-badge wpwm-badge--info"><?php echo esc_html( $wpwebmcp_a5_calls_count . ' tool call' . ( $wpwebmcp_a5_calls_count === 1 ? '' : 's' ) ); ?></span>
		<span class="wpwm-badge wpwm-badge--info"><?php echo esc_html( $wpwebmcp_a5_bots_count . ' bot visit' . ( $wpwebmcp_a5_bots_count === 1 ? '' : 's' ) ); ?></span>
	</h2>
	<p class="wpwm-field-helper" style="margin-bottom: var(--wpwm-sp-4);">
		<?php esc_html_e( 'Real agent activity from your audit log + bot log. The dedicated page lets you inspect each call (params, status, latency), re-run any logged call with current state, resolve any user-agent against the agent-identity registry, and preview which A2a policy would match.', 'webmcp-nexus' ); ?>
	</p>
	<p>
		<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=wp-webmcp-agent-trace' ) ); ?>"><?php esc_html_e( 'Open Agent Live Trace →', 'webmcp-nexus' ); ?></a>
	</p>
	<p class="wpwm-muted" style="font-size:12px; margin:0;">
		<?php esc_html_e( 'Every value on that page is sourced from a real DB row, a real identity-resolver call, or a real policy-evaluator call — nothing simulated.', 'webmcp-nexus' ); ?>
	</p>
</div>

<!-- Row 1.60: A6 — Vertical Tool Packs Marketplace (compact preview + link to packs page) -->
<?php
$wpwebmcp_a6_installed = class_exists( 'WP_WebMCP_Pack_Registry' )
	? WP_WebMCP_Pack_Registry::list_installed()
	: array();
$wpwebmcp_a6_available = class_exists( 'WP_WebMCP_Pack_Registry' )
	? WP_WebMCP_Pack_Registry::list_available()
	: array();
$wpwebmcp_a6_total_tools = 0;
foreach ( $wpwebmcp_a6_installed as $wpwebmcp_p ) {
	$wpwebmcp_a6_total_tools += is_array( $wpwebmcp_p['tools'] ?? null ) ? count( $wpwebmcp_p['tools'] ) : 0;
}
?>
<div class="wpwm-card" style="margin-bottom: var(--wpwm-sp-5);">
	<h2 class="wpwm-h2" style="margin-top:0; display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
		<span>🛍️ AEO Intelligence: Tool Packs Marketplace (A6)</span>
		<span class="wpwm-badge wpwm-badge--info"><?php echo esc_html( count( $wpwebmcp_a6_installed ) . ' pack' . ( count( $wpwebmcp_a6_installed ) === 1 ? '' : 's' ) . ' installed' ); ?></span>
		<span class="wpwm-badge wpwm-badge--info"><?php echo esc_html( count( $wpwebmcp_a6_available ) . ' available' ); ?></span>
		<span class="wpwm-badge wpwm-badge--info"><?php echo esc_html( $wpwebmcp_a6_total_tools . ' tool' . ( $wpwebmcp_a6_total_tools === 1 ? '' : 's' ) ); ?></span>
	</h2>
	<p class="wpwm-field-helper" style="margin-bottom: var(--wpwm-sp-4);">
		<?php esc_html_e( 'Vertical Tool Packs Marketplace (A6). Each pack bundles a WordPress data model (CPT + taxonomies + seed data) with a set of MCP tools registered through the SDK so agents can find, query, and consume the pack content via the standard /wp-json/wpwebmcp/v1/... namespace. The bundled Recipes pack ships in this release.', 'webmcp-nexus' ); ?>
	</p>
	<?php if ( ! empty( $wpwebmcp_a6_installed ) ) : ?>
		<p style="margin: 0 0 var(--wpwm-sp-3);">
			<strong>Installed:</strong>
			<?php
			$names = array();
			foreach ( $wpwebmcp_a6_installed as $wpwebmcp_p ) {
				$names[] = sprintf( '%s (%d tools)', $wpwebmcp_p['name'], count( $wpwebmcp_p['tools'] ?? array() ) );
			}
			echo esc_html( implode( ', ', $names ) );
			?>
		</p>
	<?php endif; ?>
	<?php if ( ! empty( $wpwebmcp_a6_available ) ) : ?>
		<p style="margin: 0 0 var(--wpwm-sp-3);">
			<strong>Available to install:</strong>
			<?php
			$names = array();
			foreach ( $wpwebmcp_a6_available as $wpwebmcp_p ) {
				$names[] = $wpwebmcp_p['name'];
			}
			echo esc_html( implode( ', ', $names ) );
			?>
		</p>
	<?php endif; ?>
	<p>
		<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=wp-webmcp-packs' ) ); ?>"><?php esc_html_e( 'Open Tool Packs →', 'webmcp-nexus' ); ?></a>
	</p>
	<p class="wpwm-muted" style="font-size:12px; margin:0;">
		<?php esc_html_e( 'Full in-plugin documentation, schema reference, and developer boilerplate are available on the Tool Packs page.', 'webmcp-nexus' ); ?>
	</p>
</div>

<!-- Row 1.58: A4 — AI-Readiness Audit -->
<?php
$wpwebmcp_a4_cache_key = 'wpwebmcp_a4_audit_v1_' . (int) get_current_user_id();
$wpwebmcp_a4_cache_ttl = MINUTE_IN_SECONDS * 5;
$wpwebmcp_a4_dir       = isset( $_GET['a4_dir'] ) ? sanitize_key( (string) wp_unslash( $_GET['a4_dir'] ) ) : 'top';
if ( ! in_array( $wpwebmcp_a4_dir, array( 'top', 'bottom' ), true ) ) { $wpwebmcp_a4_dir = 'top'; }
$wpwebmcp_a4_cache_hit = get_transient( $wpwebmcp_a4_cache_key . '_' . $wpwebmcp_a4_dir );
if ( false === $wpwebmcp_a4_cache_hit && class_exists( 'WP_WebMCP_Post_Audit' ) ) {
	$wpwebmcp_a4_cache_hit = WP_WebMCP_Post_Audit::leaderboard( $wpwebmcp_a4_dir, 10, 200 );
	set_transient( $wpwebmcp_a4_cache_key . '_' . $wpwebmcp_a4_dir, $wpwebmcp_a4_cache_hit, $wpwebmcp_a4_cache_ttl );
}
$wpwebmcp_a4_rows = is_array( $wpwebmcp_a4_cache_hit ) ? $wpwebmcp_a4_cache_hit : array();
$wpwebmcp_a4_breakdown = class_exists( 'WP_WebMCP_Missing_Tool_Auditor' )
	? WP_WebMCP_Missing_Tool_Auditor::count_breakdown()
	: array( 'schema' => 0, 'gap' => 0, 'total' => 0 );
$wpwebmcp_a4_top_count = (int) count( $wpwebmcp_a4_rows );
$wpwebmcp_a4_avg_score = 0;
if ( ! empty( $wpwebmcp_a4_rows ) ) {
	$wpwebmcp_sum = 0;
	foreach ( $wpwebmcp_a4_rows as $wpwebmcp_r ) { $wpwebmcp_sum += (int) ( $wpwebmcp_r['total'] ?? 0 ); }
	$wpwebmcp_a4_avg_score = (int) round( $wpwebmcp_sum / count( $wpwebmcp_a4_rows ) );
}
?>
<div class="wpwm-card" style="margin-bottom: var(--wpwm-sp-5);">
	<h2 class="wpwm-h2" style="margin-top:0; display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
		<span>🩺 AEO Intelligence: AI-Readiness Audit (A4)</span>
		<?php if ( $wpwebmcp_a4_top_count > 0 ) : ?>
			<span class="wpwm-badge wpwm-badge--info"><?php echo esc_html( $wpwebmcp_a4_avg_score . '% avg' ); ?></span>
		<?php endif; ?>
		<?php if ( $wpwebmcp_a4_breakdown['total'] > 0 ) : ?>
			<span class="wpwm-badge wpwm-badge--warning"><?php echo esc_html( $wpwebmcp_a4_breakdown['total'] . ' missing tool' . ( $wpwebmcp_a4_breakdown['total'] === 1 ? '' : 's' ) ); ?></span>
		<?php endif; ?>
	</h2>
	<p class="wpwm-field-helper" style="margin-bottom: var(--wpwm-sp-4);">
		<?php esc_html_e( 'Per-post AEO-readiness score (0–100) computed from JSON-LD presence, FAQ/HowTo schemas, Article author + datePublished, freshness metadata, exposure tier, excerpt, and featured image. Sidebar meta box on every post shows the same score with shape guidance (TL;DR, FAQ, takeaways, author bio, last-updated date).', 'webmcp-nexus' ); ?>
	</p>

	<div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin-bottom: var(--wpwm-sp-3);">
		<strong style="font-size:12px; color:var(--wpwm-text-muted, #646970);"><?php esc_html_e( 'Show:', 'webmcp-nexus' ); ?></strong>
		<a class="button button-small<?php echo 'top' === $wpwebmcp_a4_dir ? ' button-primary' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'a4_dir', 'top' ) ); ?>"><?php esc_html_e( 'Top 10 (highest)', 'webmcp-nexus' ); ?></a>
		<a class="button button-small<?php echo 'bottom' === $wpwebmcp_a4_dir ? ' button-primary' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'a4_dir', 'bottom' ) ); ?>"><?php esc_html_e( 'Bottom 10 (needs work)', 'webmcp-nexus' ); ?></a>
		<a class="button button-small" href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'wpwebmcp_a4_refresh', '1' ), 'wpwebmcp_a4_refresh' ) ); ?>" style="text-decoration:underline;"><?php esc_html_e( 'Re-run', 'webmcp-nexus' ); ?></a>
		<?php
		if ( isset( $_GET['wpwebmcp_a4_refresh'] ) && check_admin_referer( 'wpwebmcp_a4_refresh' ) ) {
			delete_transient( $wpwebmcp_a4_cache_key . '_top' );
			delete_transient( $wpwebmcp_a4_cache_key . '_bottom' );
			echo '<span style="font-size:12px; color:#006d2c;">' . esc_html__( '✓ Cache cleared. Reload to re-scan.', 'webmcp-nexus' ) . '</span>';
		}
		?>
	</div>

	<?php if ( empty( $wpwebmcp_a4_rows ) ) : ?>
		<div style="padding:14px 16px; background:var(--wpwm-surface, #f6f7f7); border:1px dashed var(--wpwm-border, #dcdcde); border-radius:6px; color:var(--wpwm-text-muted, #646970);">
			<?php esc_html_e( 'No published posts found to audit yet.', 'webmcp-nexus' ); ?>
		</div>
	<?php else : ?>
		<table class="widefat striped wpwm-a4-table" style="margin-bottom: var(--wpwm-sp-3);">
			<thead>
				<tr>
					<th style="width:42px;"><?php esc_html_e( 'Grade', 'webmcp-nexus' ); ?></th>
					<th><?php esc_html_e( 'Post', 'webmcp-nexus' ); ?></th>
					<th style="width:90px;"><?php esc_html_e( 'Score', 'webmcp-nexus' ); ?></th>
					<th style="width:140px;"><?php esc_html_e( 'Hint', 'webmcp-nexus' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $wpwebmcp_a4_rows as $wpwebmcp_row ) :
					$wpwebmcp_total = (int) ( $wpwebmcp_row['total'] ?? 0 );
					$wpwebmcp_grade = (string) ( $wpwebmcp_row['grade'] ?? 'F' );
					$wpwebmcp_pid   = (int) ( $wpwebmcp_row['post_id'] ?? 0 );
					$title = (string) ( $wpwebmcp_row['post_title'] ?? '' );
					$wpwebmcp_break = isset( $wpwebmcp_row['breakdown'] ) && is_array( $wpwebmcp_row['breakdown'] ) ? $wpwebmcp_row['breakdown'] : array();
					$wpwebmcp_first_miss = '';
					foreach ( $wpwebmcp_break as $wpwebmcp_b ) {
						if ( empty( $wpwebmcp_b['passes'] ) && '' !== (string) ( $wpwebmcp_b['hint'] ?? '' ) ) {
							$wpwebmcp_first_miss = (string) $wpwebmcp_b['hint'];
							break;
						}
					}
					?>
					<tr>
						<td><span class="wpwm-a4-grade wpwm-a4-grade--<?php echo esc_attr( $wpwebmcp_grade ); ?>"><?php echo esc_html( $wpwebmcp_grade ); ?></span></td>
						<td>
							<?php if ( $wpwebmcp_pid > 0 ) : ?>
								<a href="<?php echo esc_url( get_edit_post_link( $wpwebmcp_pid, 'raw' ) ); ?>"><strong><?php echo esc_html( $title ); ?></strong></a>
							<?php else : ?>
								<strong><?php echo esc_html( $title ); ?></strong>
							<?php endif; ?>
						</td>
						<td><strong><?php echo esc_html( $wpwebmcp_total . '/100' ); ?></strong></td>
						<td style="font-size:12px; color:var(--wpwm-text-muted, #646970);"><?php echo esc_html( $wpwebmcp_first_miss ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>

	<div style="display:flex; gap:12px; flex-wrap:wrap; padding:10px 12px; background:var(--wpwm-surface, #f6f7f7); border-radius:6px; font-size:12px;">
		<strong><?php esc_html_e( 'Missing-tool feed (unified):', 'webmcp-nexus' ); ?></strong>
		<span><?php
			/* translators: %d: count */
			printf( esc_html__( '%d schema-driven', 'webmcp-nexus' ), (int) $wpwebmcp_a4_breakdown['schema'] );
		?></span>
		<span><?php
			/* translators: %d: count */
			printf( esc_html__( '%d gap-driven (from A3a bank)', 'webmcp-nexus' ), (int) $wpwebmcp_a4_breakdown['gap'] );
		?></span>
		<span style="color:var(--wpwm-text-muted, #646970);"><?php esc_html_e( 'See A3c + A3a cards above for one-click apply.', 'webmcp-nexus' ); ?></span>
	</div>
</div>

<!-- Row 1.57: A3a — Answer-Gap Detector -->
<?php
$wpwebmcp_a3a_cache_key = 'wpwebmcp_a3a_gaps_v1_' . (int) get_current_user_id();
$wpwebmcp_a3a_cache_ttl = MINUTE_IN_SECONDS * 10;
$wpwebmcp_a3a_filter    = isset( $_GET['a3a_vertical'] ) ? sanitize_key( (string) wp_unslash( $_GET['a3a_vertical'] ) ) : '';
$wpwebmcp_allowed_v     = class_exists( 'WP_WebMCP_Question_Bank' ) ? WP_WebMCP_Question_Bank::verticals() : array();
if ( '' !== $wpwebmcp_a3a_filter && ! in_array( $wpwebmcp_a3a_filter, $wpwebmcp_allowed_v, true ) ) {
	$wpwebmcp_a3a_filter = '';
}
$wpwebmcp_a3a_cache_hit = get_transient( $wpwebmcp_a3a_cache_key . ( '' !== $wpwebmcp_a3a_filter ? '_' . $wpwebmcp_a3a_filter : '' ) );
if ( false === $wpwebmcp_a3a_cache_hit && class_exists( 'WP_WebMCP_Answer_Gap_Detector' ) ) {
	$wpwebmcp_a3a_cache_hit = ( '' === $wpwebmcp_a3a_filter )
		? WP_WebMCP_Answer_Gap_Detector::detect( null )
		: WP_WebMCP_Answer_Gap_Detector::detect_vertical( $wpwebmcp_a3a_filter );
	set_transient( $wpwebmcp_a3a_cache_key . ( '' !== $wpwebmcp_a3a_filter ? '_' . $wpwebmcp_a3a_filter : '' ), $wpwebmcp_a3a_cache_hit, $wpwebmcp_a3a_cache_ttl );
}
$wpwebmcp_a3a_gaps  = isset( $wpwebmcp_a3a_cache_hit['gaps'] ) && is_array( $wpwebmcp_a3a_cache_hit['gaps'] ) ? $wpwebmcp_a3a_cache_hit['gaps'] : array();
$wpwebmcp_a3a_total = (int) ( $wpwebmcp_a3a_cache_hit['total'] ?? 0 );
$wpwebmcp_a3a_cov  = (int) ( $wpwebmcp_a3a_cache_hit['covered'] ?? 0 );
$wpwebmcp_a3a_gc   = (int) ( $wpwebmcp_a3a_cache_hit['gap_count'] ?? count( $wpwebmcp_a3a_gaps ) );
$wpwebmcp_a3a_vert_labels = class_exists( 'WP_WebMCP_Question_Bank' ) ? WP_WebMCP_Question_Bank::vertical_labels() : array();
$wpwebmcp_a3a_nonce    = wp_create_nonce( 'wp_rest' );
$wpwebmcp_a3a_rest_url = esc_url_raw( rest_url( 'wpwebmcp/v1/a3/gap-apply' ) );
?>
<div class="wpwm-card" style="margin-bottom: var(--wpwm-sp-5);">
	<h2 class="wpwm-h2" style="margin-top:0; display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
		<span>🧠 AEO Intelligence: Answer-Gap Detector</span>
		<span class="wpwm-badge wpwm-badge--info"><?php echo esc_html( $wpwebmcp_a3a_cov . '/' . $wpwebmcp_a3a_total . ' covered' ); ?></span>
		<?php if ( $wpwebmcp_a3a_gc > 0 ) : ?>
			<span class="wpwm-badge wpwm-badge--warning"><?php echo esc_html( $wpwebmcp_a3a_gc . ' gap' . ( $wpwebmcp_a3a_gc === 1 ? '' : 's' ) ); ?></span>
		<?php endif; ?>
	</h2>
	<p class="wpwm-field-helper" style="margin-bottom: var(--wpwm-sp-4);">
		<?php esc_html_e( 'We curated a per-vertical question bank (the queries real users actually ask) and cross-referenced each against your existing MCP tool inventory. Anything not covered is a gap — one click creates the suggested tool so the agent can finally answer that query. Cached for 10 minutes.', 'webmcp-nexus' ); ?>
	</p>

	<form method="get" style="display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin-bottom: var(--wpwm-sp-3);">
		<input type="hidden" name="page" value="webmcp-nexus">
		<label for="a3a-vertical-filter" style="font-size:13px; color:var(--wpwm-text-muted);"><?php esc_html_e( 'Filter by vertical:', 'webmcp-nexus' ); ?></label>
		<select id="a3a-vertical-filter" name="a3a_vertical" onchange="this.form.submit()" style="max-width:280px;">
			<option value=""><?php esc_html_e( 'All verticals', 'webmcp-nexus' ); ?></option>
			<?php foreach ( $wpwebmcp_allowed_v as $wpwebmcp_v ) : ?>
				<option value="<?php echo esc_attr( $wpwebmcp_v ); ?>" <?php selected( $wpwebmcp_a3a_filter, $wpwebmcp_v ); ?>><?php echo esc_html( isset( $wpwebmcp_a3a_vert_labels[ $wpwebmcp_v ] ) ? $wpwebmcp_a3a_vert_labels[ $wpwebmcp_v ] : $wpwebmcp_v ); ?></option>
			<?php endforeach; ?>
		</select>
		<a class="button button-small" href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'wpwebmcp_a3a_refresh', '1' ), 'wpwebmcp_a3a_refresh' ) ); ?>" style="text-decoration:underline;"><?php esc_html_e( 'Re-run now', 'webmcp-nexus' ); ?></a>
		<?php
		if ( isset( $_GET['wpwebmcp_a3a_refresh'] ) && check_admin_referer( 'wpwebmcp_a3a_refresh' ) ) {
			foreach ( $wpwebmcp_allowed_v as $wpwebmcp_v ) {
				delete_transient( $wpwebmcp_a3a_cache_key . '_' . $wpwebmcp_v );
			}
			delete_transient( $wpwebmcp_a3a_cache_key );
			echo '<span style="font-size:12px; color:#006d2c;">' . esc_html__( '✓ Cache cleared. Reload to re-run.', 'webmcp-nexus' ) . '</span>';
		}
		?>
	</form>

	<?php if ( empty( $wpwebmcp_a3a_gaps ) ) : ?>
		<div style="padding:14px 16px; background:rgba(0,109,44,0.08); border:1px solid rgba(0,109,44,0.25); border-radius:6px; color:var(--wpwm-text);">
			<?php esc_html_e( 'All questions in this vertical are covered by existing tools — no gaps detected.', 'webmcp-nexus' ); ?>
		</div>
	<?php else : ?>
		<div class="wpwm-a3a-list">
			<?php foreach ( $wpwebmcp_a3a_gaps as $wpwebmcp_gap ) :
				$wpwebmcp_query    = (string) ( $wpwebmcp_gap['query'] ?? '' );
				$wpwebmcp_vertical = (string) ( $wpwebmcp_gap['vertical'] ?? '' );
				$wpwebmcp_intent   = (string) ( $wpwebmcp_gap['expected_intent'] ?? '' );
				$wpwebmcp_tool     = isset( $wpwebmcp_gap['suggested_tool'] ) && is_array( $wpwebmcp_gap['suggested_tool'] ) ? $wpwebmcp_gap['suggested_tool'] : array();
				$wpwebmcp_slug     = (string) ( $wpwebmcp_tool['slug'] ?? '' );
				$wpwebmcp_tname    = (string) ( $wpwebmcp_tool['name'] ?? $wpwebmcp_slug );
				$wpwebmcp_tdesc    = (string) ( $wpwebmcp_tool['description'] ?? '' );
				$wpwebmcp_tparams  = isset( $wpwebmcp_tool['parameters'] ) ? $wpwebmcp_tool['parameters'] : array();
				$wpwebmcp_slug_exists = class_exists( 'WP_WebMCP_Tool_Repository' ) && null !== WP_WebMCP_Tool_Repository::find_by_slug( $wpwebmcp_slug );
				$wpwebmcp_vert_label = isset( $wpwebmcp_a3a_vert_labels[ $wpwebmcp_vertical ] ) ? $wpwebmcp_a3a_vert_labels[ $wpwebmcp_vertical ] : $wpwebmcp_vertical;
				?>
				<div class="wpwm-a3a-row" data-slug="<?php echo esc_attr( $wpwebmcp_slug ); ?>">
					<div class="wpwm-a3a-row-q">
						<span class="wpwm-a3a-row-icon" aria-hidden="true">❓</span>
						<div>
							<div class="wpwm-a3a-row-query"><?php echo esc_html( $wpwebmcp_query ); ?></div>
							<div class="wpwm-a3a-row-meta">
								<span class="wpwm-badge wpwm-badge--muted"><?php echo esc_html( $wpwebmcp_vert_label ); ?></span>
								<span style="color:var(--wpwm-text-muted); font-size:11px;"><?php echo esc_html( $wpwebmcp_intent ); ?></span>
							</div>
						</div>
					</div>
					<div class="wpwm-a3a-row-tool">
						<div>
							<span class="wpwm-muted" style="font-size:11px;"><?php esc_html_e( 'Suggested tool:', 'webmcp-nexus' ); ?></span>
							<strong><?php echo esc_html( $wpwebmcp_tname ); ?></strong>
							<code class="wpwm-mono" style="font-size:11px;"><?php echo esc_html( $wpwebmcp_slug ); ?></code>
						</div>
						<?php if ( '' !== $wpwebmcp_tdesc ) : ?>
							<div class="wpwm-a3a-row-desc"><?php echo esc_html( $wpwebmcp_tdesc ); ?></div>
						<?php endif; ?>
					</div>
					<div class="wpwm-a3a-row-actions">
						<?php if ( $wpwebmcp_slug_exists ) : ?>
							<button type="button" class="button button-secondary" disabled><?php esc_html_e( '✓ Already created', 'webmcp-nexus' ); ?></button>
							<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=wp-webmcp-tools&search=' . rawurlencode( $wpwebmcp_slug ) ) ); ?>"><?php esc_html_e( 'Open', 'webmcp-nexus' ); ?></a>
						<?php else : ?>
							<button type="button"
								class="button button-primary wpwm-a3a-apply"
								data-vertical="<?php echo esc_attr( $wpwebmcp_vertical ); ?>"
								data-query="<?php echo esc_attr( $wpwebmcp_query ); ?>"
								data-slug="<?php echo esc_attr( $wpwebmcp_slug ); ?>"
								data-name="<?php echo esc_attr( $wpwebmcp_tname ); ?>"
								data-description="<?php echo esc_attr( $wpwebmcp_tdesc ); ?>"
								data-parameters="<?php echo esc_attr( wp_json_encode( $wpwebmcp_tparams ) ); ?>"
							><?php esc_html_e( '⚡ Create tool', 'webmcp-nexus' ); ?></button>
						<?php endif; ?>
						<span class="wpwm-a3a-row-status" style="font-size:12px; color:var(--wpwm-text-muted); margin-left:6px;"></span>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<script type="text/javascript">
		(function(){
			var restUrl = <?php echo wp_json_encode( $wpwebmcp_a3a_rest_url ); ?>;
			var nonce   = <?php echo wp_json_encode( $wpwebmcp_a3a_nonce ); ?>;
			function apply(el){
				if (el.disabled) return;
				var row = el.closest('.wpwm-a3a-row');
				var status = row ? row.querySelector('.wpwm-a3a-row-status') : null;
				var body = {
					vertical: el.getAttribute('data-vertical') || '',
					query: el.getAttribute('data-query') || '',
					suggested_tool: {
						slug: el.getAttribute('data-slug') || '',
						name: el.getAttribute('data-name') || '',
						description: el.getAttribute('data-description') || ''
					}
				};
				try { body.suggested_tool.parameters = JSON.parse(el.getAttribute('data-parameters') || '{}'); }
				catch (e) { body.suggested_tool.parameters = {}; }
				el.disabled = true;
				var original = el.textContent;
				el.textContent = 'Creating…';
				if (status) { status.style.color = 'var(--wpwm-text-muted)'; status.textContent = ''; }
				fetch(restUrl, {
					method: 'POST',
					credentials: 'same-origin',
					headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
					body: JSON.stringify(body)
				}).then(function(resp){
					return resp.json().then(function(j){ return { status: resp.status, json: j }; });
				}).then(function(out){
					var j = out.json, code = out.status;
					if (code === 200 || code === 201) {
						if (status) { status.style.color = '#006d2c'; status.textContent = '✓ Created'; }
						el.textContent = '✓ Created';
						var editUrl = (j && j.edit_url) ? j.edit_url : (<?php echo wp_json_encode( admin_url( 'admin.php?page=wp-webmcp-tools' ) ); ?>);
						setTimeout(function(){ window.location.href = editUrl; }, 600);
					} else if (code === 409) {
						if (status) { status.style.color = '#9a6700'; status.textContent = 'Already exists — reloading…'; }
						el.textContent = 'Already created';
						setTimeout(function(){ window.location.reload(); }, 800);
					} else {
						var msg = (j && j.message) ? j.message : 'Create failed';
						if (status) { status.style.color = '#b32d2e'; status.textContent = msg; }
						el.textContent = original;
						el.disabled = false;
					}
				}).catch(function(){
					if (status) { status.style.color = '#b32d2e'; status.textContent = 'Network error'; }
					el.textContent = original;
					el.disabled = false;
				});
			}
			document.addEventListener('click', function(ev){
				var t = ev.target;
				if (t && t.classList && t.classList.contains('wpwm-a3a-apply')) {
					ev.preventDefault();
					apply(t);
				}
			});
		})();
		</script>
	<?php endif; ?>
</div>

<!-- Row 1.6: AI Discoverability & Generative Engine Optimization (GEO) -->
<div class="wpwm-card" style="margin-bottom: var(--wpwm-sp-5);">
	<h2 class="wpwm-h2" style="margin-top:0; display:flex; align-items:center; gap:8px;">
		<span>🌐 AI Discoverability &amp; GEO (Generative Engine Optimization)</span>
		<span class="wpwm-badge wpwm-badge--info">High Priority</span>
	</h2>
	<p class="wpwm-field-helper" style="margin-bottom: var(--wpwm-sp-4);">
		<?php esc_html_e( 'WebMCP Nexus automatically optimizes your content for AI search engines (Perplexity, ChatGPT, Claude, Gemini) with clean semantic markdown streams, rich machine catalogs, and turnkey shortcodes.', 'webmcp-nexus' ); ?>
	</p>

	<div class="wpwm-stat-grid" style="margin-bottom: 20px;">
		<div class="wpwm-stat">
			<span class="wpwm-stat-label"><?php esc_html_e( 'Semantic Markdown Stream', 'webmcp-nexus' ); ?></span>
			<span class="wpwm-stat-value" style="font-size:16px; color:var(--wpwm-success); font-family:monospace;">?format=markdown</span>
			<span class="wpwm-stat-sub"><?php esc_html_e( 'Clean, instant markdown on every page', 'webmcp-nexus' ); ?></span>
		</div>
		<div class="wpwm-stat">
			<span class="wpwm-stat-label"><?php esc_html_e( 'Machine Catalog Index', 'webmcp-nexus' ); ?></span>
			<span class="wpwm-stat-value" style="font-size:16px; color:var(--wpwm-success); font-family:monospace;">/llms.txt</span>
			<span class="wpwm-stat-sub"><?php esc_html_e( 'Standard AI catalog with tool pointers', 'webmcp-nexus' ); ?></span>
		</div>
		<div class="wpwm-stat">
			<span class="wpwm-stat-label"><?php esc_html_e( 'Model Context Protocol', 'webmcp-nexus' ); ?></span>
			<span class="wpwm-stat-value" style="font-size:16px; color:var(--wpwm-success); font-family:monospace;">JSON-RPC &amp; SSE</span>
			<span class="wpwm-stat-sub"><?php esc_html_e( 'Direct Claude &amp; Cursor IDE connection', 'webmcp-nexus' ); ?></span>
		</div>
		<div class="wpwm-stat">
			<span class="wpwm-stat-label"><?php esc_html_e( 'AI Agent Priority Tag', 'webmcp-nexus' ); ?></span>
			<span class="wpwm-stat-value" style="font-size:16px; color:var(--wpwm-success);">Active (high)</span>
			<span class="wpwm-stat-sub"><?php esc_html_e( 'Head links &amp; Schema.org JSON-LD', 'webmcp-nexus' ); ?></span>
		</div>
	</div>

	<div style="background:rgba(0,0,0,0.02); border:1px solid var(--wpwm-border); border-radius:8px; padding:16px;">
		<h3 style="margin:0 0 8px; font-size:14px;"><?php esc_html_e( 'Turnkey Shortcodes (Copy &amp; Paste to Any Page / Post):', 'webmcp-nexus' ); ?></h3>
		<div style="display:flex; flex-direction:column; gap:8px;">
			<div style="display:flex; justify-content:space-between; align-items:center; background:#fff; border:1px solid var(--wpwm-border); padding:8px 12px; border-radius:6px;">
				<div>
					<code>[webmcp_form name="contactInquiry" title="Book a Call" fields="name,email,message"]</code>
					<span style="font-size:11px; color:var(--wpwm-text-muted); margin-left:8px;">— Renders an AI-annotated lead generation form</span>
				</div>
			</div>
			<div style="display:flex; justify-content:space-between; align-items:center; background:#fff; border:1px solid var(--wpwm-border); padding:8px 12px; border-radius:6px;">
				<div>
					<code>[webmcp_badge]</code>
					<span style="font-size:11px; color:var(--wpwm-text-muted); margin-left:8px;">— Displays "⚡ AI Agent Ready (WebMCP 1.0)" trust badge</span>
				</div>
			</div>
			<div style="display:flex; justify-content:space-between; align-items:center; background:#fff; border:1px solid var(--wpwm-border); padding:8px 12px; border-radius:6px;">
				<div>
					<code>[webmcp_summary]</code>
					<span style="font-size:11px; color:var(--wpwm-text-muted); margin-left:8px;">— Renders an automatic AI key takeaways card on articles</span>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Row 2: Interactive WebMCP Live Playground -->
<div class="wpwm-card wpwm-card--playground" style="margin-bottom: var(--wpwm-sp-5);">
	<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--wpwm-sp-3); flex-wrap: wrap; gap: 12px;">
		<div>
			<h2 class="wpwm-h2" style="margin: 0; display: flex; align-items: center; gap: 8px;">
				<span>⚡ Interactive Tool Playground</span>
				<span class="wpwm-badge wpwm-badge--info"><?php esc_html_e( 'Live Test Console', 'webmcp-nexus' ); ?></span>
			</h2>
			<p class="wpwm-field-helper" style="margin: 4px 0 0;"><?php esc_html_e( 'Test how an AI agent (like ChatGPT or Claude) queries your website in real-time. Select a tool, fill any parameters, and click "Execute Tool Query".', 'webmcp-nexus' ); ?></p>
		</div>
		<div style="display: flex; gap: 8px;">
			<a href="<?php echo esc_url( home_url( '/?webmcp_inspect=1' ) ); ?>" target="_blank" class="button">
				<span class="dashicons dashicons-visibility" style="margin-top:4px;"></span> <?php esc_html_e( 'Frontend Inspector', 'webmcp-nexus' ); ?>
			</a>
			<a href="<?php echo esc_url( rest_url( 'wpwebmcp/v1/manifest' ) ); ?>" target="_blank" class="button">
				<span class="dashicons dashicons-rest-api" style="margin-top:4px;"></span> <?php esc_html_e( 'Raw Manifest JSON', 'webmcp-nexus' ); ?>
			</a>
		</div>
	</div>

	<div class="wpwm-playground-deck">
		<div class="wpwm-playground-controls">
			<div class="wpwm-field">
				<label class="wpwm-label" for="wpwm-admin-tool-select"><?php esc_html_e( 'Select Tool Schema to Test', 'webmcp-nexus' ); ?></label>
				<?php // F4: single source of truth — every registered tool (core + packs + answer-gap) for the playground. ?>
<script>
window.WPWEBMCP_TOOL_REPO = <?php
$wpwebmcp_repo_map = array();
if ( class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
	foreach ( (array) WP_WebMCP_Tool_Repository::list_all() as $wpwebmcp_repo_tool ) {
		$wpwebmcp_repo_map[ (string) $wpwebmcp_repo_tool['tool_name'] ] = array(
			'desc' => (string) ( $wpwebmcp_repo_tool['tool_description'] ?? '' ),
			'scope' => (string) ( $wpwebmcp_repo_tool['tool_scope'] ?? 'all' ),
			'params' => $wpwebmcp_repo_tool['parameters'] ?? array(),
		);
	}
}
echo wp_json_encode( $wpwebmcp_repo_map );
?>;
</script>

<select id="wpwm-admin-tool-select" class="wpwm-select" style="max-width: 100%;">
					<optgroup label="Core &amp; Navigation">
						<option value="getSiteInfo">getSiteInfo — Site Metadata &amp; Capabilities</option>
						<option value="searchSite" selected>searchSite — Full-text Site Search</option>
						<option value="getFeaturedContent">getFeaturedContent — Latest Featured Posts</option>
						<option value="getSiteMap">getSiteMap — Site Permalinks Hierarchy</option>
						<option value="navigateTo">navigateTo — Same-origin Browser Navigation</option>
					</optgroup>
					<optgroup label="News &amp; Media">
						<option value="getBreakingNews">getBreakingNews — Urgent Breaking Headlines</option>
						<option value="getArticlesByTopic">getArticlesByTopic — Category &amp; Topic Filter</option>
						<option value="getTrendingNews">getTrendingNews — Popular &amp; Trending Stories</option>
						<option value="getFactCheckSummary">getFactCheckSummary — Fact-check Claims</option>
						<option value="getEditorialStaff">getEditorialStaff — Journalists &amp; Bylines</option>
					</optgroup>
					<optgroup label="Tech &amp; Documentation">
						<option value="searchDocumentation">searchDocumentation — Developer Knowledge Base</option>
						<option value="getApiReference">getApiReference — API Schemas &amp; Endpoints</option>
						<option value="getCodeSnippet">getCodeSnippet — Language Code Examples</option>
						<option value="getVersionChangelog">getVersionChangelog — Release History</option>
						<option value="getTechnicalSpecs">getTechnicalSpecs — Server &amp; Environment Specs</option>
					</optgroup>
					<optgroup label="Content &amp; Blog">
						<option value="getLatestArticles">getLatestArticles — Paginated Posts with Read Times</option>
						<option value="getPopularArticles">getPopularArticles — Top Commented Articles</option>
						<option value="getAuthorProfile">getAuthorProfile — Contributor Bio &amp; Archive</option>
						<option value="estimateReadingTime">estimateReadingTime — Article Word Count &amp; Minutes</option>
						<option value="listCategories">listCategories — Category Taxonomy Tree</option>
						<option value="listTags">listTags — Content Tag Cloud</option>
					</optgroup>
					<optgroup label="Video &amp; Multimedia">
						<option value="searchVideos">searchVideos — Video Catalog Search</option>
						<option value="getVideoDetails">getVideoDetails — Embed Code &amp; Duration</option>
						<option value="getVideoTranscript">getVideoTranscript — Subtitles &amp; Captions</option>
						<option value="getChapterTimestamps">getChapterTimestamps — Video Chapter Markers</option>
						<option value="getPlaylists">getPlaylists — Curated Video Playlists</option>
					</optgroup>
					<optgroup label="Events &amp; Community">
						<option value="getUpcomingEvents">getUpcomingEvents — Scheduled Events &amp; Webinars</option>
						<option value="getEventDetails">getEventDetails — Agenda &amp; Registration</option>
						<option value="searchEvents">searchEvents — Event Topic &amp; Venue Search</option>
					</optgroup>
					<?php if ( class_exists( 'WooCommerce' ) ) : ?>
					<optgroup label="WooCommerce Store">
						<option value="searchProducts">searchProducts — Product Catalog Query</option>
						<option value="getProductDetails">getProductDetails — Price, Attributes &amp; Stock</option>
						<option value="checkStock">checkStock — Real-time Inventory Status</option>
						<option value="getCartContents">getCartContents — Active Cart Line Items</option>
						<option value="addToCart">addToCart — Add Item to Shopping Cart</option>
					</optgroup>
					<?php endif; ?>
				</select>
			</div>

			<div id="wpwm-admin-tool-desc" class="wpwm-desc-box">
				<?php esc_html_e( 'Search public content across the site for a query string, returning structured results with title, URL, and excerpt.', 'webmcp-nexus' ); ?>
			</div>

			<div id="wpwm-admin-params-container" style="margin-bottom: var(--wpwm-sp-3);">
				<div class="wpwm-field">
					<label class="wpwm-label" for="wpwm-param-query"><?php esc_html_e( 'Search Query (query)', 'webmcp-nexus' ); ?> *</label>
					<input type="text" id="wpwm-param-query" class="wpwm-input" value="WordPress" placeholder="e.g. WordPress or news">
				</div>
			</div>

			<button type="button" id="wpwm-admin-run-tool" class="button button-primary button-large" style="width:100%; display:flex; justify-content:center; align-items:center; gap:8px;">
				<span class="dashicons dashicons-controls-play" style="margin-top:2px;"></span> <?php esc_html_e( 'Execute Tool Query', 'webmcp-nexus' ); ?>
			</button>
		</div>

		<div class="wpwm-playground-output">
			<div class="wpwm-output-header">
				<span id="wpwm-admin-res-status" class="wpwm-badge wpwm-badge--success"><?php esc_html_e( 'Ready', 'webmcp-nexus' ); ?></span>
				<button type="button" id="wpwm-admin-copy-json" class="button button-small"><?php esc_html_e( 'Copy Result', 'webmcp-nexus' ); ?></button>
			</div>
			<pre id="wpwm-admin-json-viewer" class="wpwm-json-box"><code>{
  "status": "ready",
  "message": "Select a tool and click 'Execute Tool Query' to inspect live results."
}</code></pre>
		</div>
	</div>
</div>

<!-- Row 3: Onboarding Checklist -->
<?php if ( ! $wpwebmcp_onboarding_dismissed ) : ?>
<div class="wpwm-checklist" data-wpwm-checklist style="margin-bottom: var(--wpwm-sp-5);">
	<div class="wpwm-checklist-progress">
		<span><strong><?php esc_html_e( 'AI Agent Readiness Checklist', 'webmcp-nexus' ); ?></strong></span>
		<span><span data-wpwm-checklist-progress><?php echo (int) $wpwebmcp_completed_count; ?></span>/<?php echo (int) count( $wpwebmcp_checklist ); ?></span>
	</div>
	<div class="wpwm-checklist-progress-bar"><span data-wpwm-checklist-bar style="width:<?php echo (int) round( ( $wpwebmcp_completed_count / max( 1, count( $wpwebmcp_checklist ) ) ) * 100 ); ?>%"></span></div>
	<ul class="wpwm-checklist-list">
		<?php foreach ( $wpwebmcp_checklist as $wpwebmcp_i => $wpwebmcp_c ) : ?>
			<li class="wpwm-checklist-item">
				<span class="wpwm-checklist-state <?php echo $wpwebmcp_c['state'] ? 'wpwm-checklist-state--done' : ''; ?>" aria-label="<?php echo $wpwebmcp_c['state'] ? esc_attr__( 'Done', 'webmcp-nexus' ) : esc_attr__( 'Pending', 'webmcp-nexus' ); ?>"><?php echo (int) ( $wpwebmcp_i + 1 ); ?></span>
				<span class="wpwm-checklist-label"><?php echo esc_html( $wpwebmcp_c['label'] ); ?></span>
				<a class="wpwm-checklist-action button" href="<?php echo esc_url( $wpwebmcp_c['href'] ); ?>"<?php echo 0 === strpos( (string) $wpwebmcp_c['href'], home_url() ) ? ' target="_blank"' : ''; ?>><?php echo esc_html( $wpwebmcp_c['btn'] ); ?></a>
			</li>
		<?php endforeach; ?>
	</ul>
	<div class="wpwm-checklist-dismiss">
		<a href="#" data-wpwm-dismiss-onboarding><?php esc_html_e( 'Dismiss checklist', 'webmcp-nexus' ); ?></a>
	</div>
</div>
<?php endif; ?>

<!-- Row 4: Recent Activity & Quick Switches -->
<div class="wpwm-row">
	<div class="wpwm-col" style="flex: 2;">
		<div class="wpwm-card">
			<h2 class="wpwm-h2" style="margin-top:0;"><?php esc_html_e( 'Recent AI Agent Activity', 'webmcp-nexus' ); ?></h2>
			<table class="wpwm-table" aria-describedby="wpwm-recent-activity-caption">
				<caption id="wpwm-recent-activity-caption" class="screen-reader-text"><?php esc_html_e( 'Recent tool calls', 'webmcp-nexus' ); ?></caption>
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Time', 'webmcp-nexus' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Tool Name', 'webmcp-nexus' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Status', 'webmcp-nexus' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Latency', 'webmcp-nexus' ); ?></th>
					</tr>
				</thead>
				<tbody data-wpwm-recent-activity>
					<?php if ( empty( $wpwebmcp_recent_rows ) ) : ?>
						<tr><td colspan="4">
							<div class="wpwm-empty"><span class="dashicons dashicons-format-chat" aria-hidden="true"></span><p><?php esc_html_e( 'No tool calls logged yet. Use the Interactive Playground above or navigate on the frontend to generate live agent activity.', 'webmcp-nexus' ); ?></p></div>
						</td></tr>
					<?php else : ?>
						<?php foreach ( $wpwebmcp_recent_rows as $wpwebmcp_r ) : ?>
							<tr>
								<td><?php echo esc_html( mysql2date( 'Y-m-d H:i:s', $wpwebmcp_r['logged_at'] ) ); ?></td>
								<td><code><?php echo esc_html( (string) $wpwebmcp_r['tool_name'] ); ?></code></td>
								<td><span class="wpwm-badge wpwm-badge--<?php echo esc_attr( 'success' === $wpwebmcp_r['status'] ? 'success' : ( 'error' === $wpwebmcp_r['status'] ? 'error' : ( 'rate_limited' === $wpwebmcp_r['status'] ? 'warning' : 'info' ) ) ); ?>"><?php echo esc_html( (string) $wpwebmcp_r['status'] ); ?></span></td>
								<td><strong><?php echo (int) $wpwebmcp_r['execution_ms']; ?>ms</strong></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>

	<div class="wpwm-col" style="flex: 1;">
		<div class="wpwm-card">
			<h2 class="wpwm-h2" style="margin-top:0;"><?php esc_html_e( 'Engine Toggles', 'webmcp-nexus' ); ?></h2>
			<div class="wpwm-control-row">
				<div>
					<strong><?php esc_html_e( 'Sitewide WebMCP', 'webmcp-nexus' ); ?></strong>
					<p class="wpwm-field-helper"><?php esc_html_e( 'Master kill switch for AI agent interactions.', 'webmcp-nexus' ); ?></p>
				</div>
				<label class="wpwm-switch">
					<input type="checkbox" data-wpwm-toggle="wpwebmcp_enabled" <?php checked( $wpwebmcp_sitewide_enabled ); ?>>
					<span class="wpwm-switch-track"></span>
				</label>
			</div>
			<hr class="wpwm-divider" style="margin: 12px 0;">
			<div class="wpwm-control-row">
				<div>
					<strong><?php esc_html_e( 'Analytics &amp; Telemetry', 'webmcp-nexus' ); ?></strong>
					<p class="wpwm-field-helper"><?php esc_html_e( 'Log AI agent calls and bot visits.', 'webmcp-nexus' ); ?></p>
				</div>
				<label class="wpwm-switch">
					<input type="checkbox" data-wpwm-toggle="wpwebmcp_analytics_enabled" <?php checked( $wpwebmcp_analytics_enabled ); ?>>
					<span class="wpwm-switch-track"></span>
				</label>
			</div>
		</div>
	</div>
</div>