<?php
/**
 * Exclusions screen — Doc §5.8 #6.
 *
 * Step 7: renders the current chip list server-side via
 * `WP_WebMCP_Exclusions::get_current_chips()` and ships a small inline
 * script for search debouncing + chip add/remove + POST persist.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$wpwebmcp_chips = method_exists( 'WP_WebMCP_Exclusions', 'get_current_chips' )
	? WP_WebMCP_Exclusions::get_current_chips()
	: array();

$wpwebmcp_rest_url   = esc_url_raw( rest_url( 'wpwebmcp/v1/exclusions' ) );
$wpwebmcp_search_url = esc_url_raw( rest_url( 'wpwebmcp/v1/exclusions/search' ) );
$wpwebmcp_rest_nonce = wp_create_nonce( 'wp_rest' );
$wpwebmcp_admin_nonce = wp_create_nonce( 'wpwebmcp_admin_nonce' );
?>
<!-- Educational Guide Card -->
<div class="wpwm-guide-card wpwm-guide-card--featured">
	<div class="wpwm-guide-header">
		<span class="wpwm-guide-icon"><span class="dashicons dashicons-hidden" aria-hidden="true"></span></span>
		<div>
			<h2 class="wpwm-guide-title"><?php esc_html_e( 'Content Exclusions — Protect Sensitive Pages', 'webmcp-nexus' ); ?></h2>
			<p class="wpwm-field-helper" style="margin:2px 0 0;"><?php esc_html_e( 'Control exactly which posts, pages, or categories are hidden from AI agents and crawler tools.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
	<p class="wpwm-guide-desc">
		<?php esc_html_e( 'While public articles and products are great for AI search discovery, certain pages should never be operated by autonomous bots. Exclude pages like thank-you pages, member-only areas, internal documentation, or checkout flows here with one click.', 'webmcp-nexus' ); ?>
	</p>
	<div class="wpwm-guide-grid">
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-search" style="color:var(--wpwm-accent);"></span> <?php esc_html_e( '1. Search & Select', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Type any keyword or post ID into the search box below to find the content you want to hide.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-lock" style="color:var(--wpwm-error);"></span> <?php esc_html_e( '2. Automatic Masking', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Excluded items immediately have all WebMCP tool manifests and discovery headers stripped.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-dismiss" style="color:var(--wpwm-info);"></span> <?php esc_html_e( '3. Instant Undo', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Click the × icon on any badge below to instantly restore WebMCP tools to that page.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
</div>

<div class="wpwm-row">
	<div class="wpwm-col">
		<label for="wpwm-exclusions-search" class="screen-reader-text"><?php esc_html_e( 'Search posts and pages to exclude', 'webmcp-nexus' ); ?></label>
		<input type="search" id="wpwm-exclusions-search" class="wpwm-input-wide" placeholder="<?php esc_attr_e( 'Type post or page title to search and exclude…', 'webmcp-nexus' ); ?>" data-wpwm-exclusions-search autocomplete="off">
		<p class="wpwm-field-helper"><?php esc_html_e( 'Type to search. Exclusions take precedence over all other per-page settings.', 'webmcp-nexus' ); ?></p>
		<div class="wpwm-search-results" data-wpwm-exclusions-results style="display:none; margin-top: var(--wpwm-sp-2);"></div>
	</div>
</div>

<div class="wpwm-row">
	<div class="wpwm-col">
		<h2 class="wpwm-h2"><?php esc_html_e( 'Excluded posts', 'webmcp-nexus' ); ?></h2>
		<div class="wpwm-chips" data-wpwm-excluded-chips>
			<?php if ( empty( $wpwebmcp_chips ) ) : ?>
				<p class="wpwm-field-helper" data-wpwm-empty><?php esc_html_e( 'Nothing excluded — the whole site is agent-ready.', 'webmcp-nexus' ); ?></p>
			<?php else : ?>
				<?php foreach ( $wpwebmcp_chips as $wpwebmcp_chip ) : ?>
					<span class="wpwm-chip wpwm-badge wpwm-badge--muted" data-wpwm-chip-id="<?php echo (int) $wpwebmcp_chip['id']; ?>">
						<span class="dashicons dashicons-<?php echo esc_attr( 'post' === $wpwebmcp_chip['type'] ? 'admin-post' : ( 'page' === $wpwebmcp_chip['type'] ? 'admin-page' : 'category' ) ); ?>" aria-hidden="true"></span>
						<span class="wpwm-chip-title"><?php echo esc_html( $wpwebmcp_chip['title'] ); ?></span>
						<button type="button" class="wpwm-chip-remove" aria-label="<?php esc_attr_e( 'Remove exclusion', 'webmcp-nexus' ); ?>" data-wpwm-chip-remove="<?php echo (int) $wpwebmcp_chip['id']; ?>">&times;</button>
					</span>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
		<p class="wpwm-field-helper" data-wpwm-empty style="display:none; margin-top: var(--wpwm-sp-2);"><?php esc_html_e( 'Nothing excluded — the whole site is agent-ready.', 'webmcp-nexus' ); ?></p>
	</div>
</div>

<script>
(function () {
	var restUrl = <?php echo wp_json_encode( $wpwebmcp_rest_url ); ?>;
	var searchUrl = <?php echo wp_json_encode( $wpwebmcp_search_url ); ?>;
	var nonce = <?php echo wp_json_encode( $wpwebmcp_rest_nonce ); ?>;
	var adminNonce = <?php echo wp_json_encode( $wpwebmcp_admin_nonce ); ?>;

	var searchInput = document.querySelector('[data-wpwm-exclusions-search]');
	var resultsBox = document.querySelector('[data-wpwm-exclusions-results]');
	var chipsBox = document.querySelector('[data-wpwm-excluded-chips]');
	var emptyMsg = document.querySelectorAll('[data-wpwm-empty]');
	var debounceTimer = null;

	function getChipIds() {
		var ids = [];
		chipsBox.querySelectorAll('[data-wpwm-chip-id]').forEach(function (el) {
			ids.push(parseInt(el.getAttribute('data-wpwm-chip-id'), 10));
		});
		return ids;
	}

	function refreshEmpty() {
		var any = chipsBox.querySelector('[data-wpwm-chip-id]');
		emptyMsg.forEach(function (el) { el.style.display = any ? 'none' : ''; });
	}

	function buildChip(chip) {
		var span = document.createElement('span');
		span.className = 'wpwm-chip wpwm-badge wpwm-badge--muted';
		span.setAttribute('data-wpwm-chip-id', chip.id);
		span.innerHTML = '<span class="dashicons dashicons-' + (chip.type === 'page' ? 'admin-page' : (chip.type === 'post' ? 'admin-post' : 'category')) + '" aria-hidden="true"></span>' +
			'<span class="wpwm-chip-title">' + chip.title.replace(/[&<>"']/g, function (c) { return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]); }) + '</span>' +
			'<button type="button" class="wpwm-chip-remove" aria-label="Remove exclusion" data-wpwm-chip-remove="' + chip.id + '">&times;</button>';
		return span;
	}

	function persist() {
		var ids = getChipIds();
		return fetch(restUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': nonce
			},
			body: JSON.stringify({ ids: ids })
		}).then(function (r) { return r.json(); });
	}

	function addChip(chip) {
		if (chipsBox.querySelector('[data-wpwm-chip-id="' + chip.id + '"]')) { return; }
		chipsBox.appendChild(buildChip(chip));
		refreshEmpty();
	}

	function removeChip(id) {
		var el = chipsBox.querySelector('[data-wpwm-chip-id="' + id + '"]');
		if (el) { el.parentNode.removeChild(el); }
		refreshEmpty();
	}

	function renderResults(results) {
		resultsBox.innerHTML = '';
		if (!results || !results.length) {
			resultsBox.style.display = 'none';
			return;
		}
		resultsBox.style.display = '';
		results.forEach(function (r) {
			var btn = document.createElement('button');
			btn.type = 'button';
			btn.className = 'button wpwm-search-result';
			btn.setAttribute('data-wpwm-add', r.id);
			btn.textContent = '+ ' + r.title + ' (' + r.type + ')';
			resultsBox.appendChild(btn);
		});
	}

	if (searchInput) {
		searchInput.addEventListener('input', function () {
			var s = searchInput.value.trim();
			if (debounceTimer) { clearTimeout(debounceTimer); }
			if (s.length < 2) { renderResults([]); return; }
			debounceTimer = setTimeout(function () {
				fetch(searchUrl + '?s=' + encodeURIComponent(s) + '&_wpnonce=' + encodeURIComponent(nonce), { credentials: 'same-origin' })
					.then(function (r) { return r.json(); })
					.then(function (j) { renderResults(j.results || []); })
					.catch(function () { renderResults([]); });
			}, 250);
		});
	}

	if (resultsBox) {
		resultsBox.addEventListener('click', function (e) {
			var btn = e.target.closest('[data-wpwm-add]');
			if (!btn) { return; }
			var id = parseInt(btn.getAttribute('data-wpwm-add'), 10);
			var title = btn.textContent.replace(/^\+\s*/, '').replace(/\s*\([^)]+\)\s*$/, '');
			var type = (btn.textContent.match(/\(([^)]+)\)/) || [])[1] || 'post';
			addChip({ id: id, title: title, type: type });
			renderResults([]);
			persist();
		});
	}

	if (chipsBox) {
		chipsBox.addEventListener('click', function (e) {
			var btn = e.target.closest('[data-wpwm-chip-remove]');
			if (!btn) { return; }
			var id = parseInt(btn.getAttribute('data-wpwm-chip-remove'), 10);
			removeChip(id);
			persist();
		});
	}
})();
</script>