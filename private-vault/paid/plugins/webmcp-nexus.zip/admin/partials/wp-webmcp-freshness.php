<?php
/**
 * Admin partial — Freshness ping protocol (A1c).
 *
 * Variables supplied by WP_WebMCP_Freshness_Page::render():
 *   $enabled, $key, $endpoint, $queue, $stats, $log, $host
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- Educational Guide Card -->
<div class="wpwm-guide-card wpwm-guide-card--featured">
	<div class="wpwm-guide-header">
		<span class="wpwm-guide-icon"><span class="dashicons dashicons-update" aria-hidden="true"></span></span>
		<div>
			<h2 class="wpwm-guide-title"><?php esc_html_e( 'Content Freshness & Real-Time AI Pings (IndexNow + SSE)', 'webmcp-nexus' ); ?></h2>
			<p class="wpwm-field-helper" style="margin:2px 0 0;"><?php esc_html_e( 'Ensure AI assistants and generative search engines never cite outdated versions of your posts.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
	<p class="wpwm-guide-desc">
		<?php esc_html_e( 'When you publish or update content, AI models often keep cached snapshots in memory. WebMCP Nexus solves this by broadcasting instant IndexNow pings (to Microsoft Bing, Copilot, Yandex, etc.) and firing real-time Server-Sent Events (SSE) so connected AI agents immediately refresh their content models.', 'webmcp-nexus' ); ?>
	</p>
	<div class="wpwm-guide-grid">
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-cloud" style="color:var(--wpwm-accent);"></span> <?php esc_html_e( '1. IndexNow Protocol', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Automatically queues and notifies search engines within 5 minutes of any post publish or edit.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-rss" style="color:var(--wpwm-success);"></span> <?php esc_html_e( '2. Real-Time SSE Stream', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Provides an event stream URL that AI agents can subscribe to for live content updates.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-yes-alt" style="color:var(--wpwm-info);"></span> <?php esc_html_e( '3. Automatic Verification', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Generate your key at indexnow.org, paste it below, and place the key text file in your site root.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
</div>

	<h2><?php esc_html_e( 'Settings', 'webmcp-nexus' ); ?></h2>
	<form id="wpwebmcp-freshness-settings" class="wpwebmcp-card" method="post">
		<?php wp_nonce_field( 'wpwebmcp_freshness_settings', '_wpnonce' ); ?>

		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable Freshness', 'webmcp-nexus' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="enabled" value="1" <?php checked( $enabled, true ); ?>/>
							<?php esc_html_e( 'Send IndexNow pings + emit SSE events on content changes.', 'webmcp-nexus' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="wpwebmcp-indexnow-key"><?php esc_html_e( 'IndexNow API key', 'webmcp-nexus' ); ?></label>
					</th>
					<td>
						<input id="wpwebmcp-indexnow-key" name="indexnow_key" type="text" class="regular-text code" value="<?php echo esc_attr( $key ); ?>" placeholder="32-hex-chars" autocomplete="off"/>
						<p class="description">
							<?php
							echo wp_kses(
								__( 'Generate a key at <a href="https://www.indexnow.org/" target="_blank" rel="noopener">indexnow.org</a>, then upload <code>&lt;key&gt;.txt</code> to your site root containing the key. Format: 8-128 hex characters.', 'webmcp-nexus' ),
								array(
									'a'    => array( 'href' => array(), 'target' => array(), 'rel' => array() ),
									'code' => array(),
								)
							);
							?>
						</p>
						<?php if ( '' !== $key && '' !== $host ) : ?>
							<p class="description">
								<?php
								printf(
									/* translators: %s: Verification URL */
									esc_html__( 'Verify ownership: %s', 'webmcp-nexus' ),
									'<code>' . esc_html( trailingslashit( home_url() ) . $key . '.txt' ) . '</code>'
								);
								?>
							</p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="wpwebmcp-indexnow-endpoint"><?php esc_html_e( 'Endpoint', 'webmcp-nexus' ); ?></label>
					</th>
					<td>
						<input id="wpwebmcp-indexnow-endpoint" name="endpoint" type="url" class="regular-text code" value="<?php echo esc_attr( $endpoint ); ?>" placeholder="https://api.indexnow.org/indexnow"/>
						<p class="description">
							<?php esc_html_e( 'Default fans out to Bing, Yandex, Seznam, Naver. Override only if your region requires a specific endpoint.', 'webmcp-nexus' ); ?>
						</p>
					</td>
				</tr>
			</tbody>
		</table>

		<p class="submit">
			<button type="submit" class="button button-primary">
				<?php esc_html_e( 'Save settings', 'webmcp-nexus' ); ?>
			</button>
			<button type="button" id="wpwebmcp-freshness-flush" class="button">
				<?php esc_html_e( 'Ping now (flush queue)', 'webmcp-nexus' ); ?>
			</button>
		</p>
	</form>

	<hr/>

	<h2><?php esc_html_e( 'Status', 'webmcp-nexus' ); ?></h2>
	<div class="wpwebmcp-card wpwebmcp-stats">
		<table class="widefat striped" role="presentation">
			<tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Enabled', 'webmcp-nexus' ); ?></th>
					<td>
						<?php if ( $enabled ) : ?>
							<span style="color:#1a7f37;font-weight:600;">● <?php esc_html_e( 'Active', 'webmcp-nexus' ); ?></span>
						<?php else : ?>
							<span style="color:#9a6700;font-weight:600;">● <?php esc_html_e( 'Inactive', 'webmcp-nexus' ); ?></span>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Pending in queue', 'webmcp-nexus' ); ?></th>
					<td>
						<code id="wpwebmcp-queue-count"><?php echo (int) $queue; ?></code>
						<span class="description"><?php esc_html_e( 'Flushed every 5 minutes via WP-Cron.', 'webmcp-nexus' ); ?></span>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Submitted today', 'webmcp-nexus' ); ?></th>
					<td>
						<?php echo (int) $stats['submitted_today']; ?> / 8000
						<span class="description"><?php esc_html_e( 'soft daily cap', 'webmcp-nexus' ); ?></span>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Total submitted', 'webmcp-nexus' ); ?></th>
					<td><?php echo (int) $stats['total_submitted']; ?></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Last submitted', 'webmcp-nexus' ); ?></th>
					<td>
						<?php
						if ( '' !== $stats['last_submitted_at'] ) {
							echo esc_html( $stats['last_submitted_at'] );
							echo ' &middot; <code>' . esc_html( $stats['last_submitted_url'] ) . '</code>';
						} else {
							echo '&mdash;';
						}
						?>
					</td>
				</tr>
				<?php if ( '' !== $stats['last_error_message'] ) : ?>
					<tr>
						<th scope="row"><?php esc_html_e( 'Last error', 'webmcp-nexus' ); ?></th>
						<td style="color:#cf222e;">
							<?php echo esc_html( $stats['last_error_at'] ); ?> &middot;
							<code><?php echo esc_html( $stats['last_error_message'] ); ?></code>
						</td>
					</tr>
				<?php endif; ?>
				<tr>
					<th scope="row"><?php esc_html_e( 'SSE listener URL', 'webmcp-nexus' ); ?></th>
					<td>
						<code><?php echo esc_html( rest_url( 'wpwebmcp/v1/freshness/stream' ) ); ?></code>
						<p class="description"><?php esc_html_e( 'Connect any EventSource client (browser, Node, curl --no-buffer) to receive real-time content_updated events.', 'webmcp-nexus' ); ?></p>
					</td>
				</tr>
			</tbody>
		</table>
	</div>

	<hr/>

	<h2><?php esc_html_e( 'Recent pings', 'webmcp-nexus' ); ?></h2>
	<?php if ( empty( $log ) ) : ?>
		<p class="wpwm-muted"><?php esc_html_e( 'No pings yet. Publish or update a post to trigger your first IndexNow submission.', 'webmcp-nexus' ); ?></p>
	<?php else : ?>
		<table class="widefat striped wpwm-table" role="presentation">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Time (GMT)', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Status', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Detail', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'URLs', 'webmcp-nexus' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $log as $wpwebmcp_row ) : ?>
					<tr>
						<td><code><?php echo esc_html( (string) ( $wpwebmcp_row['ts'] ?? '' ) ); ?></code></td>
						<td>
							<?php if ( 'success' === ( $wpwebmcp_row['status'] ?? '' ) ) : ?>
								<span style="color:#1a7f37;">✓ success</span>
							<?php else : ?>
								<span style="color:#cf222e;">✗ <?php echo esc_html( (string) ( $wpwebmcp_row['status'] ?? '' ) ); ?></span>
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( (string) ( $wpwebmcp_row['message'] ?? '' ) ); ?></td>
						<td>
							<?php if ( ! empty( $wpwebmcp_row['urls'] ) && is_array( $wpwebmcp_row['urls'] ) ) : ?>
								<ul style="margin:0;padding-left:18px;">
									<?php foreach ( (array) $wpwebmcp_row['urls'] as $wpwebmcp_u ) : ?>
										<li><code style="font-size:11px;"><?php echo esc_html( (string) $wpwebmcp_u ); ?></code></li>
									<?php endforeach; ?>
								</ul>
							<?php else : ?>
								&mdash;
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>

<style>
.wpwebmcp-wrap .wpwebmcp-card { background:#fff; border:1px solid #c3c4c7; border-radius:4px; padding:16px; margin:8px 0 16px; max-width:980px; }
.wpwebmcp-wrap .wpwebmcp-stats table th { width:200px; }
.wpwebmcp-wrap .wpwm-muted { color:#646970; font-style:italic; }
.wpwebmcp-wrap .wpwm-table code { font-size:11px; word-break:break-all; }
</style>

<script>
(function () {
	// Save settings
	var form = document.getElementById('wpwebmcp-freshness-settings');
	if (form) {
		form.addEventListener('submit', function (e) {
			e.preventDefault();
			var fd = new FormData(form);
			fd.append('_wpnonce', '<?php echo esc_js( wp_create_nonce( 'wpwebmcp_freshness_settings' ) ); ?>');
			fetch('<?php echo esc_js( rest_url( 'wpwebmcp/v1/freshness/settings' ) ); ?>', {
				method: 'POST',
				headers: { 'X-WP-Nonce': '<?php echo esc_js( wp_create_nonce( 'wp_rest' ) ); ?>' },
				body: fd,
				credentials: 'same-origin'
			}).then(function (r) { return r.json(); }).then(function (j) {
				alert(j.ok ? 'Saved.' : ('Error: ' + (j.message || j.code || 'unknown')));
				if (j.ok) location.reload();
			});
		});
	}

	// Flush button
	var btn = document.getElementById('wpwebmcp-freshness-flush');
	if (btn) {
		btn.addEventListener('click', function () {
			btn.disabled = true;
			fetch('<?php echo esc_js( rest_url( 'wpwebmcp/v1/freshness/flush' ) ); ?>', {
				method: 'POST',
				headers: { 'X-WP-Nonce': '<?php echo esc_js( wp_create_nonce( 'wp_rest' ) ); ?>' },
				credentials: 'same-origin'
			}).then(function (r) { return r.json(); }).then(function (j) {
				btn.disabled = false;
				alert('Flush: submitted=' + (j.submitted || 0) + ' error=' + (j.error || 'none'));
				location.reload();
			});
		});
	}

	// Optional: connect to the SSE stream for live updates.
	if (window.EventSource && <?php echo $enabled ? 'true' : 'false'; ?>) {
		try {
			var es = new EventSource('<?php echo esc_js( rest_url( 'wpwebmcp/v1/freshness/stream' ) ); ?>');
			es.addEventListener('content_updated', function (e) {
				console.log('[freshness]', e.data);
			});
		} catch (_) {}
	}
})();
</script>
