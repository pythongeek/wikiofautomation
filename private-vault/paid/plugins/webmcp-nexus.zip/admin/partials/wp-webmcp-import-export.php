<?php
// phpcs:disable WordPress.Security.NonceVerification.Recommended -- nonce verified by caller (page handler)

/**
 * Import / Export screen — Doc §5.8 #8 + §4.8 + §7.6.
 *
 * Provides JSON configuration export, file upload import with automatic
 * pre-import snapshots, and backup restore capabilities.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$wpwebmcp_backups = class_exists( 'WP_WebMCP_Import_Export' ) ? WP_WebMCP_Import_Export::list_backups() : array();
$wpwebmcp_export_url = wp_nonce_url( admin_url( 'admin-post.php?action=wpwebmcp_export' ), 'wpwebmcp_export_action', 'wpwebmcp_export_nonce' );
$wpwebmcp_restored = isset( $_GET['restored'] ) && '1' === $_GET['restored'];
?>
<!-- Educational Guide Card -->
<div class="wpwm-guide-card wpwm-guide-card--featured">
	<div class="wpwm-guide-header">
		<span class="wpwm-guide-icon"><span class="dashicons dashicons-database" aria-hidden="true"></span></span>
		<div>
			<h2 class="wpwm-guide-title"><?php esc_html_e( 'Configuration Snapshots & Migration Guide', 'webmcp-nexus' ); ?></h2>
			<p class="wpwm-field-helper" style="margin:2px 0 0;"><?php esc_html_e( 'Safely backup, restore, and transfer your WebMCP setup and custom tools.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
	<p class="wpwm-guide-desc">
		<?php esc_html_e( 'Take full control of your WebMCP configuration. Download offline JSON snapshots for safekeeping, migrate settings from your staging site to live production, and restore earlier snapshots with zero technical hassle.', 'webmcp-nexus' ); ?>
	</p>
	<div class="wpwm-guide-grid">
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-download" style="color:var(--wpwm-accent);"></span> <?php esc_html_e( '1. Export Snapshots', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Exports all 32 settings, rate limits, crawler directives, and custom tools into a lightweight JSON file.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-shield-alt" style="color:var(--wpwm-success);"></span> <?php esc_html_e( '2. Automatic Pre-Import Backup', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Before applying any uploaded configuration, WebMCP automatically saves a backup of your current setup.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-undo" style="color:var(--wpwm-info);"></span> <?php esc_html_e( '3. Instant 1-Click Restore', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Easily revert to any of your last 5 stored backups with a single click from the Stored Backups table below.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
</div>

<div class="wpwm-row">
	<div class="wpwm-col">
		<div class="wpwm-card">
			<h2 class="wpwm-h2"><?php esc_html_e( 'Export Configuration', 'webmcp-nexus' ); ?></h2>
			<p><?php esc_html_e( 'Download a JSON snapshot containing all 32 configuration options and custom tools. Useful for site migration or offline backup.', 'webmcp-nexus' ); ?></p>
			<p><a href="<?php echo esc_url( $wpwebmcp_export_url ); ?>" class="button button-primary" data-wpwm-action="download-export">
				<span class="dashicons dashicons-download" style="vertical-align: text-bottom;" aria-hidden="true"></span>
				<?php esc_html_e( 'Download JSON Snapshot', 'webmcp-nexus' ); ?>
			</a></p>
		</div>
	</div>

	<div class="wpwm-col">
		<div class="wpwm-card">
			<h2 class="wpwm-h2"><?php esc_html_e( 'Import Configuration', 'webmcp-nexus' ); ?></h2>
			<p><?php esc_html_e( 'Upload a previously exported JSON snapshot. An automatic backup is created before settings are applied.', 'webmcp-nexus' ); ?></p>
			<div class="wpwm-import-dropzone" style="border: 2px dashed #ccd0d4; padding: 20px; text-align: center; border-radius: 4px; background: #fafafa;">
				<input type="file" accept="application/json" data-wpwm-import-file id="wpwm-import-file-input" style="display: none;">
				<label for="wpwm-import-file-input" class="button" style="cursor: pointer;">
					<span class="dashicons dashicons-upload" style="vertical-align: text-bottom;" aria-hidden="true"></span>
					<?php esc_html_e( 'Select JSON File', 'webmcp-nexus' ); ?>
				</label>
				<p class="wpwm-field-helper" style="margin-top: 8px;"><?php esc_html_e( 'or drag & drop a file here', 'webmcp-nexus' ); ?></p>
			</div>
			<div id="wpwm-import-status" style="margin-top: 10px; display: none;"></div>
		</div>
	</div>
</div>

<div class="wpwm-row" style="margin-top: var(--wpwm-sp-3);">
	<div class="wpwm-col wpwm-col--wide">
		<div class="wpwm-card">
			<h2 class="wpwm-h2"><?php esc_html_e( 'Stored Backups', 'webmcp-nexus' ); ?></h2>
			<p class="wpwm-field-helper"><?php esc_html_e( 'Automatic snapshots created before imports (up to 5 retained).', 'webmcp-nexus' ); ?></p>

			<?php if ( empty( $wpwebmcp_backups ) ) : ?>
				<div class="wpwm-empty" data-wpwm-empty-backups>
					<span class="dashicons dashicons-backup" aria-hidden="true"></span>
					<p><?php esc_html_e( 'No backups created yet.', 'webmcp-nexus' ); ?></p>
				</div>
			<?php else : ?>
				<table class="wpwm-table">
					<thead>
						<tr>
							<th scope="col"><?php esc_html_e( 'Label', 'webmcp-nexus' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Timestamp (GMT)', 'webmcp-nexus' ); ?></th>
							<th scope="col" class="wpwm-col-actions"><?php esc_html_e( 'Action', 'webmcp-nexus' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $wpwebmcp_backups as $wpwebmcp_b ) : ?>
							<tr>
								<td><strong><?php echo esc_html( $wpwebmcp_b['label'] ); ?></strong></td>
								<td><?php echo esc_html( $wpwebmcp_b['created_at'] ); ?></td>
								<td>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display: inline;" onsubmit="return confirm('<?php echo esc_js( __( 'Restore this backup? Current settings will be overwritten.', 'webmcp-nexus' ) ); ?>');">
										<input type="hidden" name="action" value="wpwebmcp_restore_backup">
										<input type="hidden" name="backup_key" value="<?php echo esc_attr( $wpwebmcp_b['key'] ); ?>">
										<?php wp_nonce_field( 'wpwebmcp_restore_backup_action', 'wpwebmcp_restore_nonce' ); ?>
										<button type="submit" class="button button-small"><?php esc_html_e( 'Restore', 'webmcp-nexus' ); ?></button>
									</form>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
	</div>
</div>