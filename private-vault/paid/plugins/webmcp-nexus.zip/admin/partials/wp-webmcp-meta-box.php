<?php
/**
 * Meta box partial — Doc §5.8 #10.
 *
 * Step 5 shell: 3 radio choices (Inherit / Force on / Force off).
 * Logic lands in Step 7 (Meta Box class).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wpwm-metabox">
	<p class="wpwm-field-helper" style="margin-top:0; margin-bottom:8px;">
		<?php esc_html_e( 'Choose whether AI agents (like ChatGPT and Claude) can discover tools on this specific page:', 'webmcp-nexus' ); ?>
	</p>
	<label style="display:block; margin-bottom:6px;">
		<input type="radio" name="_wpwebmcp_override" value="" <?php checked( $current_override, '' ); ?>>
		<strong><?php esc_html_e( 'Inherit (Default)', 'webmcp-nexus' ); ?></strong>
		<span class="wpwm-field-helper" style="display:block; margin-left:20px; font-size:11px;"><?php esc_html_e( 'Follows sitewide settings & exclusions.', 'webmcp-nexus' ); ?></span>
	</label>
	<label style="display:block; margin-bottom:6px;">
		<input type="radio" name="_wpwebmcp_override" value="on" <?php checked( $current_override, 'on' ); ?>>
		<strong><?php esc_html_e( 'Force on', 'webmcp-nexus' ); ?></strong>
		<span class="wpwm-field-helper" style="display:block; margin-left:20px; font-size:11px;"><?php esc_html_e( 'Always expose WebMCP tools on this page.', 'webmcp-nexus' ); ?></span>
	</label>
	<label style="display:block; margin-bottom:8px;">
		<input type="radio" name="_wpwebmcp_override" value="off" <?php checked( $current_override, 'off' ); ?>>
		<strong><?php esc_html_e( 'Force off', 'webmcp-nexus' ); ?></strong>
		<span class="wpwm-field-helper" style="display:block; margin-left:20px; font-size:11px;"><?php esc_html_e( 'Hide all AI tools & manifests from this page.', 'webmcp-nexus' ); ?></span>
	</label>
	<hr style="margin: 8px 0; border:0; border-top: 1px solid #ddd;">
	<p class="wpwm-field-helper" style="margin: 4px 0 4px;">
		<strong><?php esc_html_e( 'AI Access & Citation Gate:', 'webmcp-nexus' ); ?></strong>
	</p>
	<label style="display:block; margin-bottom:4px;">
		<input type="radio" name="_wpwebmcp_exposure_tier" value="public" <?php checked( $current_tier, 'public' ); ?>>
		<strong><?php esc_html_e( 'Public (Default)', 'webmcp-nexus' ); ?></strong>
		<span class="wpwm-field-helper" style="display:block; margin-left:20px; font-size:11px;"><?php esc_html_e( 'Any AI agent can freely read, index, and cite this content.', 'webmcp-nexus' ); ?></span>
	</label>
	<label style="display:block; margin-bottom:4px;">
		<input type="radio" name="_wpwebmcp_exposure_tier" value="cited" <?php checked( $current_tier, 'cited' ); ?>>
		<strong><?php esc_html_e( 'Citation Proof Required', 'webmcp-nexus' ); ?></strong>
		<span class="wpwm-field-helper" style="display:block; margin-left:20px; font-size:11px;"><?php esc_html_e( 'Only AI agents providing verified cryptographic citation proof receive citations.', 'webmcp-nexus' ); ?></span>
	</label>
	<label style="display:block; margin-bottom:8px;">
		<input type="radio" name="_wpwebmcp_exposure_tier" value="premium" <?php checked( $current_tier, 'premium' ); ?>>
		<strong><?php esc_html_e( 'Token / Subscriber Gate', 'webmcp-nexus' ); ?></strong>
		<span class="wpwm-field-helper" style="display:block; margin-left:20px; font-size:11px;"><?php esc_html_e( 'For your paid or subscriber-only posts. AI agents must provide a valid receipt token (X-Premium-Receipt) to cite this content.', 'webmcp-nexus' ); ?></span>
	</label>
	<hr style="margin: 8px 0; border:0; border-top: 1px solid #ddd;">
	<p class="wpwm-field-helper" style="margin: 4px 0 0;">
		<a href="#" data-wpwm-preview-manifest class="button button-small" style="display:inline-block; margin-top:2px;">
			<span class="dashicons dashicons-visibility" style="vertical-align:text-bottom; font-size:14px; width:14px; height:14px;"></span>
			<?php esc_html_e( 'Preview Page Manifest', 'webmcp-nexus' ); ?>
		</a>
		<?php if ( ! empty( $excluded_summary ) ) : ?>
			<span style="display:block; color:#d63638; margin-top:4px;"><strong><?php echo esc_html( $excluded_summary ); ?></strong></span>
		<?php endif; ?>
	</p>
</div>