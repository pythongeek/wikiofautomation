<?php
// phpcs:disable WordPress.Security.NonceVerification.Recommended -- nonce verified by caller (page handler)
/**
 * Tool Packs admin page partial.
 *
 * Renders the installed + available packs lists with 1-click install/uninstall
 * and a comprehensive, accessible developer hub & manifest documentation.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$wpwebmcp_installed = WP_WebMCP_Packs_Page::installed();
$wpwebmcp_available = WP_WebMCP_Packs_Page::available();

// Calculate total tools across installed packs.
$wpwebmcp_total_installed_tools = 0;
foreach ( $wpwebmcp_installed as $wpwebmcp_pack ) {
	$wpwebmcp_total_installed_tools += count( (array) ( $wpwebmcp_pack['tools'] ?? array() ) );
}

$wpwebmcp_icon_map = array(
	'recipes'     => 'dashicons-food',
	'real-estate' => 'dashicons-building',
	'events'      => 'dashicons-calendar-alt',
	'job-board'   => 'dashicons-businessman',
	'courses'     => 'dashicons-welcome-learn-more',
);
?>

<!-- Educational Guide Card -->
<div class="wpwm-guide-card wpwm-guide-card--featured" style="margin-bottom: var(--wpwm-sp-4);">
	<div class="wpwm-guide-header">
		<span class="wpwm-guide-icon"><span class="dashicons dashicons-products" aria-hidden="true"></span></span>
		<div>
			<h2 class="wpwm-guide-title"><?php esc_html_e( 'Vertical Tool Packs — Industry Niche Data Models & AI Tools', 'webmcp-nexus' ); ?></h2>
			<p class="wpwm-field-helper" style="margin:2px 0 0;"><?php esc_html_e( 'Turnkey domain-specific extensions bundling Custom Post Types, taxonomies, sample content, and dedicated MCP tool endpoints.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
	<p class="wpwm-guide-desc">
		<?php esc_html_e( 'Tool Packs enable modern AI assistants like Claude, ChatGPT, Cursor, and custom autonomous agents to discover, query, and recommend your niche catalog with 100% structured accuracy. Each pack provisions required post types, registers schema-validated tools on /wp-json/wpwebmcp/v1/tools, and seeds realistic demo content for immediate testing.', 'webmcp-nexus' ); ?>
	</p>
	<div class="wpwm-guide-grid">
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-admin-post" style="color:var(--wpwm-accent);"></span> <?php esc_html_e( '1. Structured Data Model', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Automatically registers schema-compliant Custom Post Types (CPTs) and taxonomies tailored for your industry niche.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-rest-api" style="color:var(--wpwm-success);"></span> <?php esc_html_e( '2. Dedicated MCP Tools', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Adds domain-specific tools over standard REST endpoints with strict parameter validation and source citations.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-saved" style="color:var(--wpwm-info);"></span> <?php esc_html_e( '3. 1-Click Management', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Install or uninstall any pack with a single click. Tools, taxonomies, and seeded data are managed automatically.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
</div>

<!-- Metrics Quick Bar -->
<div class="wpwm-stats-bar" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; margin-bottom: var(--wpwm-sp-4);">
	<div class="wpwm-card" style="padding: 14px 18px; display:flex; align-items:center; gap: 12px;">
		<span class="dashicons dashicons-category" style="font-size: 28px; width: 28px; height: 28px; color: var(--wpwm-accent);"></span>
		<div>
			<div style="font-size: 20px; font-weight: 700; color: var(--wpwm-text);"><?php echo count( $wpwebmcp_available ) + count( $wpwebmcp_installed ); ?></div>
			<div style="font-size: 11px; color: var(--wpwm-text-muted); text-transform: uppercase; font-weight: 600;"><?php esc_html_e( 'Total Available Packs', 'webmcp-nexus' ); ?></div>
		</div>
	</div>
	<div class="wpwm-card" style="padding: 14px 18px; display:flex; align-items:center; gap: 12px;">
		<span class="dashicons dashicons-yes-alt" style="font-size: 28px; width: 28px; height: 28px; color: var(--wpwm-success);"></span>
		<div>
			<div style="font-size: 20px; font-weight: 700; color: var(--wpwm-text);"><?php echo count( $wpwebmcp_installed ); ?></div>
			<div style="font-size: 11px; color: var(--wpwm-text-muted); text-transform: uppercase; font-weight: 600;"><?php esc_html_e( 'Installed & Active Packs', 'webmcp-nexus' ); ?></div>
		</div>
	</div>
	<div class="wpwm-card" style="padding: 14px 18px; display:flex; align-items:center; gap: 12px;">
		<span class="dashicons dashicons-admin-tools" style="font-size: 28px; width: 28px; height: 28px; color: var(--wpwm-info);"></span>
		<div>
			<div style="font-size: 20px; font-weight: 700; color: var(--wpwm-text);"><?php echo (int) $wpwebmcp_total_installed_tools; ?></div>
			<div style="font-size: 11px; color: var(--wpwm-text-muted); text-transform: uppercase; font-weight: 600;"><?php esc_html_e( 'Active Pack Tools', 'webmcp-nexus' ); ?></div>
		</div>
	</div>
	<div class="wpwm-card" style="padding: 14px 18px; display:flex; align-items:center; gap: 12px;">
		<span class="dashicons dashicons-share-alt" style="font-size: 28px; width: 28px; height: 28px; color: var(--wpwm-accent);"></span>
		<div>
			<div style="font-size: 14px; font-weight: 700; color: var(--wpwm-text);">JSON-RPC 2.0 / REST</div>
			<div style="font-size: 11px; color: var(--wpwm-text-muted); text-transform: uppercase; font-weight: 600;"><?php esc_html_e( 'MCP Transport Protocol', 'webmcp-nexus' ); ?></div>
		</div>
	</div>
</div>

<!-- SECTION 1: Installed Packs -->
<div class="wpwm-section">
	<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 12px;">
		<h2 class="wpwm-h2" style="margin:0;"><?php esc_html_e( 'Installed Packs', 'webmcp-nexus' ); ?> <span class="count" style="font-size:14px; color:var(--wpwm-accent);">(<?php echo count( $wpwebmcp_installed ); ?>)</span></h2>
		<?php if ( ! empty( $wpwebmcp_installed ) ) : ?>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-webmcp-tools' ) ); ?>" class="button button-secondary" style="font-size:12px;">
				<span class="dashicons dashicons-admin-tools" style="vertical-align:text-bottom; margin-right:4px;"></span>
				<?php esc_html_e( 'View All Registered Tools', 'webmcp-nexus' ); ?>
			</a>
		<?php endif; ?>
	</div>

	<?php if ( empty( $wpwebmcp_installed ) ) : ?>
		<div class="wpwebmcp-empty" style="background:#fff; border:1px dashed var(--wpwm-border); border-radius:6px; padding:28px; text-align:center;">
			<span class="dashicons dashicons-store" style="font-size:36px; width:36px; height:36px; color:var(--wpwm-text-muted); margin-bottom:8px;"></span>
			<p style="margin:0 0 8px 0; color:var(--wpwm-text-muted); font-size:14px; font-weight:500;">
				<?php esc_html_e( 'No packs installed yet. Select from the turnkey packs below to supercharge your site with structured data & MCP tools.', 'webmcp-nexus' ); ?>
			</p>
			<p style="margin:0; font-size:12px; color:var(--wpwm-text-muted);">
				<?php esc_html_e( 'Click "Install Pack" on any available vertical to automatically register its post types, seed demo content, and publish its AI tools.', 'webmcp-nexus' ); ?>
			</p>
		</div>
	<?php else : ?>
		<div class="wpwebmcp-pack-grid" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap:16px;">
			<?php foreach ( $wpwebmcp_installed as $wpwebmcp_p ) : ?>
				<?php
				$wpwebmcp_slug = (string) $wpwebmcp_p['slug'];
				$wpwebmcp_icon = $wpwebmcp_icon_map[ $wpwebmcp_slug ] ?? 'dashicons-products';
				$wpwebmcp_tools = (array) ( $wpwebmcp_p['tools'] ?? array() );
				?>
				<div class="wpwm-card wpwebmcp-pack-card wpwebmcp-pack-installed" style="display:flex; flex-direction:column; justify-content:space-between; border-top: 3px solid var(--wpwm-success);">
					<div>
						<header style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:12px;">
							<div style="display:flex; align-items:center; gap:10px;">
								<span style="display:inline-flex; align-items:center; justify-content:center; width:36px; height:36px; border-radius:6px; background:var(--wpwm-accent-soft); color:var(--wpwm-accent);">
									<span class="dashicons <?php echo esc_attr( $wpwebmcp_icon ); ?>"></span>
								</span>
								<div>
									<h3 style="margin:0; font-size:15px; font-weight:600; color:var(--wpwm-text);">
										<?php echo esc_html( $wpwebmcp_p['name'] ); ?>
									</h3>
									<code class="wpwm-mono" style="font-size:11px; color:var(--wpwm-text-muted);"><?php echo esc_html( $wpwebmcp_slug ); ?></code>
								</div>
							</div>
							<span class="wpwm-badge wpwm-badge--success" style="font-weight:600;">v<?php echo esc_html( $wpwebmcp_p['version'] ); ?></span>
						</header>

						<p class="wpwebmcp-pack-desc" style="font-size:13px; color:var(--wpwm-text-muted); margin:0 0 14px; line-height:1.45;">
							<?php echo esc_html( $wpwebmcp_p['description'] ); ?>
						</p>

						<div style="background:#f8f9fa; border:1px solid var(--wpwm-border-soft); border-radius:6px; padding:10px 12px; margin-bottom:14px; font-size:12px;">
							<div style="display:flex; justify-content:space-between; margin-bottom:4px;">
								<span style="color:var(--wpwm-text-muted);"><?php esc_html_e( 'Author:', 'webmcp-nexus' ); ?></span>
								<strong><?php echo esc_html( $wpwebmcp_p['author'] ); ?></strong>
							</div>
							<div style="display:flex; justify-content:space-between; margin-bottom:4px;">
								<span style="color:var(--wpwm-text-muted);"><?php esc_html_e( 'Installed:', 'webmcp-nexus' ); ?></span>
								<span><?php echo esc_html( human_time_diff( (int) $wpwebmcp_p['installed_at'], time() ) ); ?> <?php esc_html_e( 'ago', 'webmcp-nexus' ); ?></span>
							</div>
							<div style="display:flex; justify-content:space-between;">
								<span style="color:var(--wpwm-text-muted);"><?php esc_html_e( 'Active Tools:', 'webmcp-nexus' ); ?></span>
								<span class="wpwm-badge wpwm-badge--info" style="font-size:11px;"><?php echo count( $wpwebmcp_tools ); ?> <?php esc_html_e( 'Tools Online', 'webmcp-nexus' ); ?></span>
							</div>
						</div>

						<?php if ( ! empty( $wpwebmcp_p['post_types'] ) || ! empty( $wpwebmcp_p['taxonomies'] ) ) : ?>
							<div style="margin-bottom:14px; font-size:12px;">
								<?php if ( ! empty( $wpwebmcp_p['post_types'] ) ) : ?>
									<div style="margin-bottom:4px;">
										<span style="color:var(--wpwm-text-muted); font-size:11px; text-transform:uppercase; font-weight:600; display:inline-block; min-width:80px;"><?php esc_html_e( 'CPTs:', 'webmcp-nexus' ); ?></span>
										<?php foreach ( (array) $wpwebmcp_p['post_types'] as $wpwebmcp_cpt ) : ?>
											<code style="background:#eef0ff; color:var(--wpwm-accent); padding:2px 6px; border-radius:3px; margin-right:4px; font-size:11px;"><?php echo esc_html( $wpwebmcp_cpt ); ?></code>
										<?php endforeach; ?>
									</div>
								<?php endif; ?>
								<?php if ( ! empty( $wpwebmcp_p['taxonomies'] ) ) : ?>
									<div>
										<span style="color:var(--wpwm-text-muted); font-size:11px; text-transform:uppercase; font-weight:600; display:inline-block; min-width:80px;"><?php esc_html_e( 'Taxonomies:', 'webmcp-nexus' ); ?></span>
										<?php foreach ( (array) $wpwebmcp_p['taxonomies'] as $wpwebmcp_tax ) : ?>
											<code style="background:#f0f0f1; color:var(--wpwm-text); padding:2px 6px; border-radius:3px; margin-right:4px; font-size:11px;"><?php echo esc_html( $wpwebmcp_tax ); ?></code>
										<?php endforeach; ?>
									</div>
								<?php endif; ?>
							</div>
						<?php endif; ?>

						<details class="wpwebmcp-pack-tools" style="margin-bottom:14px; font-size:12px; background:#fff; border:1px solid var(--wpwm-border-soft); border-radius:4px; padding:6px 10px;">
							<summary style="cursor:pointer; font-weight:600; color:var(--wpwm-accent); outline:none;">
								<span class="dashicons dashicons-admin-generic" style="font-size:14px; vertical-align:middle;"></span>
								<?php
								/* translators: %d: Number of pack tools */
								printf( esc_html__( 'Inspect %d Pack Tools & Schema', 'webmcp-nexus' ), count( $wpwebmcp_tools ) );
								?>
							</summary>
							<ul style="margin:8px 0 0 16px; padding:0; list-style:disc;">
								<?php foreach ( $wpwebmcp_tools as $wpwebmcp_t ) : ?>
									<li style="margin-bottom:6px;">
										<code style="color:var(--wpwm-accent); font-weight:600;"><?php echo esc_html( (string) ( $wpwebmcp_t['name'] ?? $wpwebmcp_t['key'] ?? '' ) ); ?></code>
										<p style="margin:2px 0 0; color:var(--wpwm-text-muted); font-size:11px; line-height:1.35;"><?php echo esc_html( (string) ( $wpwebmcp_t['description'] ?? '' ) ); ?></p>
									</li>
								<?php endforeach; ?>
							</ul>
						</details>
					</div>

					<footer style="border-top:1px solid var(--wpwm-border-soft); padding-top:12px; margin-top:8px; display:flex; justify-content:space-between; align-items:center;">
						<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=wp-webmcp-tools&scope=' . urlencode( $wpwebmcp_slug ) ) ); ?>" style="font-size:11px;">
							<?php esc_html_e( 'View in Tools Table', 'webmcp-nexus' ); ?> &rarr;
						</a>
						<a class="button button-small wpwebmcp-pack-uninstall"
						   style="color:var(--wpwm-error); border-color:var(--wpwm-border-soft);"
						   href="<?php echo esc_url( WP_WebMCP_Packs_Page::uninstall_url( $wpwebmcp_slug ) ); ?>"
						   onclick="return confirm('<?php
						   /* translators: %s: Pack name */
						   echo esc_js( sprintf( __( 'Uninstall %s? This will remove its registered MCP tools and seeded demo posts.', 'webmcp-nexus' ), $wpwebmcp_p['name'] ) );
						   ?>');">
							<?php esc_html_e( 'Uninstall Pack', 'webmcp-nexus' ); ?>
						</a>
					</footer>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</div>

<!-- SECTION 1b: F3 Phase 4 - Niche pack generator -->
<div class="wpwm-section" style="margin-top: var(--wpwm-sp-5);">
	<h2 class="wpwm-h2" style="margin-bottom: 12px;"><?php esc_html_e( 'Add Niche Pack (Generator)', 'webmcp-nexus' ); ?></h2>
	<p class="wpwm-muted" style="margin-bottom: 12px;"><?php esc_html_e( 'One click writes a real vertical pack (CPT + taxonomies + seeded demo content + dedicated MCP tools) into wp-content/wp-webmcp-packs/. Generated packs then appear as regular turnkey packs.', 'webmcp-nexus' ); ?></p>
<?php if ( class_exists( 'WP_WebMCP_Pack_Registry' ) ) : ?>
	<div class="wpwm-preset-grid">
	<?php foreach ( WP_WebMCP_Pack_Registry::niche_pack_catalogue() as $wpwebmcp_niche_slug => $wpwebmcp_niche ) :
		$wpwebmcp_niche_dir = trailingslashit( WP_WebMCP_Pack_Registry::packs_root() ) . $wpwebmcp_niche_slug;
		$wpwebmcp_niche_made = is_dir( $wpwebmcp_niche_dir );
		$wpwebmcp_niche_url = wp_nonce_url( admin_url( 'admin-post.php?action=wpwebmcp_generate_pack&pack=' . $wpwebmcp_niche_slug ), 'wp_rest' );
	?>
	<div class="wpwm-preset-card">
		<h3 class="wpwm-h3"><?php echo esc_html( (string) $wpwebmcp_niche['name'] ); ?></h3>
		<p class="wpwm-muted"><?php echo esc_html( (string) $wpwebmcp_niche['description'] ); ?></p>
		<p><code class="wpwm-mono"><?php echo esc_html( $wpwebmcp_niche_slug ); ?></code> &middot; <?php echo esc_html( count( $wpwebmcp_niche['tools'] ) ); ?> tools &middot; <?php echo esc_html( count( $wpwebmcp_niche['seeds'] ) ); ?> seed posts</p>
		<p>
		<?php if ( $wpwebmcp_niche_made ) : ?>
			<span style="color:#006d2c;"><?php echo esc_html( '✓ Generated' ); ?></span>
			<a class="button button-small" href="<?php echo esc_url( $wpwebmcp_niche_url ); ?>"><?php esc_html_e( 'Regenerate files', 'webmcp-nexus' ); ?></a>
		<?php else : ?>
			<a class="button button-primary button-small" href="<?php echo esc_url( $wpwebmcp_niche_url ); ?>"><?php esc_html_e( 'Generate pack files', 'webmcp-nexus' ); ?></a>
		<?php endif; ?>
		</p>
	</div>
	<?php endforeach; ?>
	</div>
<?php endif; ?>
</div>

<!-- SECTION 2: Available Turnkey Packs -->
<div class="wpwm-section" style="margin-top: var(--wpwm-sp-5);">
	<h2 class="wpwm-h2" style="margin-bottom: 12px;">
		<?php esc_html_e( 'Available Turnkey Packs', 'webmcp-nexus' ); ?>
		<span class="count" style="font-size:14px; color:var(--wpwm-accent);">(<?php echo count( $wpwebmcp_available ); ?>)</span>
	</h2>

	<?php if ( empty( $wpwebmcp_available ) ) : ?>
		<div class="wpwebmcp-empty" style="background:#fff; border:1px solid var(--wpwm-border-soft); border-radius:6px; padding:24px; text-align:center;">
			<p style="margin:0 0 6px; font-weight:600; color:var(--wpwm-text);">
				<?php esc_html_e( 'All available turnkey packs are currently installed and active!', 'webmcp-nexus' ); ?>
			</p>
			<p style="margin:0; color:var(--wpwm-text-muted); font-size:12px;">
				<?php
				printf(
					/* translators: %s: Directory path */
					esc_html__( 'You can author custom packs by creating a folder in %s with a wp-webmcp-pack.json manifest.', 'webmcp-nexus' ),
					'<code>' . esc_html( str_replace( ABSPATH, '', WP_WebMCP_Pack_Registry::packs_root() ) ) . '</code>'
				);
				?>
			</p>
		</div>
	<?php else : ?>
		<div class="wpwebmcp-pack-grid" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap:16px;">
			<?php foreach ( $wpwebmcp_available as $wpwebmcp_p ) : ?>
				<?php
				$wpwebmcp_slug = (string) $wpwebmcp_p['slug'];
				$wpwebmcp_icon = $wpwebmcp_icon_map[ $wpwebmcp_slug ] ?? 'dashicons-products';
				?>
				<div class="wpwm-card wpwebmcp-pack-card wpwebmcp-pack-available" style="display:flex; flex-direction:column; justify-content:space-between;">
					<div>
						<header style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:12px;">
							<div style="display:flex; align-items:center; gap:10px;">
								<span style="display:inline-flex; align-items:center; justify-content:center; width:36px; height:36px; border-radius:6px; background:var(--wpwm-accent-soft); color:var(--wpwm-accent);">
									<span class="dashicons <?php echo esc_attr( $wpwebmcp_icon ); ?>"></span>
								</span>
								<div>
									<h3 style="margin:0; font-size:15px; font-weight:600; color:var(--wpwm-text);">
										<?php echo esc_html( $wpwebmcp_p['name'] ); ?>
									</h3>
									<code class="wpwm-mono" style="font-size:11px; color:var(--wpwm-text-muted);"><?php echo esc_html( $wpwebmcp_slug ); ?></code>
								</div>
							</div>
							<span class="wpwm-badge wpwm-badge--info">v<?php echo esc_html( $wpwebmcp_p['version'] ); ?></span>
						</header>

						<p class="wpwebmcp-pack-desc" style="font-size:13px; color:var(--wpwm-text-muted); margin:0 0 14px; line-height:1.45;">
							<?php echo esc_html( $wpwebmcp_p['description'] ); ?>
						</p>

						<div style="background:#fcfcfc; border:1px solid var(--wpwm-border-soft); border-radius:6px; padding:10px 12px; margin-bottom:14px; font-size:12px;">
							<div style="display:flex; justify-content:space-between; margin-bottom:4px;">
								<span style="color:var(--wpwm-text-muted);"><?php esc_html_e( 'Author:', 'webmcp-nexus' ); ?></span>
								<strong><?php echo esc_html( $wpwebmcp_p['author'] ); ?></strong>
							</div>
							<div style="display:flex; justify-content:space-between; margin-bottom:4px;">
								<span style="color:var(--wpwm-text-muted);"><?php esc_html_e( 'Tools Included:', 'webmcp-nexus' ); ?></span>
								<strong><?php echo (int) $wpwebmcp_p['tools_count']; ?> <?php esc_html_e( 'Specialized Tools', 'webmcp-nexus' ); ?></strong>
							</div>
							<div style="display:flex; justify-content:space-between;">
								<span style="color:var(--wpwm-text-muted);"><?php esc_html_e( 'Demo Content:', 'webmcp-nexus' ); ?></span>
								<span style="color:var(--wpwm-success); font-weight:600;"><?php esc_html_e( 'Seeded on install', 'webmcp-nexus' ); ?></span>
							</div>
						</div>

						<?php if ( ! empty( $wpwebmcp_p['post_types'] ) || ! empty( $wpwebmcp_p['taxonomies'] ) ) : ?>
							<div style="margin-bottom:14px; font-size:12px;">
								<?php if ( ! empty( $wpwebmcp_p['post_types'] ) ) : ?>
									<div style="margin-bottom:4px;">
										<span style="color:var(--wpwm-text-muted); font-size:11px; text-transform:uppercase; font-weight:600; display:inline-block; min-width:80px;"><?php esc_html_e( 'CPTs:', 'webmcp-nexus' ); ?></span>
										<?php foreach ( (array) $wpwebmcp_p['post_types'] as $wpwebmcp_cpt ) : ?>
											<code style="background:#f0f0f1; color:var(--wpwm-text); padding:2px 6px; border-radius:3px; margin-right:4px; font-size:11px;"><?php echo esc_html( $wpwebmcp_cpt ); ?></code>
										<?php endforeach; ?>
									</div>
								<?php endif; ?>
								<?php if ( ! empty( $wpwebmcp_p['taxonomies'] ) ) : ?>
									<div>
										<span style="color:var(--wpwm-text-muted); font-size:11px; text-transform:uppercase; font-weight:600; display:inline-block; min-width:80px;"><?php esc_html_e( 'Taxonomies:', 'webmcp-nexus' ); ?></span>
										<?php foreach ( (array) $wpwebmcp_p['taxonomies'] as $wpwebmcp_tax ) : ?>
											<code style="background:#f0f0f1; color:var(--wpwm-text); padding:2px 6px; border-radius:3px; margin-right:4px; font-size:11px;"><?php echo esc_html( $wpwebmcp_tax ); ?></code>
										<?php endforeach; ?>
									</div>
								<?php endif; ?>
							</div>
						<?php endif; ?>
					</div>

					<footer style="border-top:1px solid var(--wpwm-border-soft); padding-top:12px; margin-top:8px;">
						<a class="button button-primary wpwebmcp-pack-install"
						   style="width:100%; text-align:center; justify-content:center; display:flex; align-items:center; gap:6px; font-weight:600; padding:4px 0;"
						   href="<?php echo esc_url( WP_WebMCP_Packs_Page::install_url( $wpwebmcp_slug ) ); ?>">
							<span class="dashicons dashicons-download" style="font-size:16px; width:16px; height:16px;"></span>
							<?php esc_html_e( 'Install Pack (1-Click)', 'webmcp-nexus' ); ?>
						</a>
					</footer>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</div>

<hr class="wpwm-divider" style="margin-top: var(--wpwm-sp-6); margin-bottom: var(--wpwm-sp-5);">

<!-- SECTION 3: In-Plugin Developer Hub & Complete Pack Author Documentation -->
<div class="wpwm-card wpwm-docs-hub" style="background:#fff; border:1px solid var(--wpwm-border-soft); border-radius:8px; padding:0; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,0.04);">
	<div style="background:linear-gradient(135deg, #1d2327 0%, #2c3338 100%); color:#fff; padding:20px 24px; display:flex; justify-content:space-between; align-items:center;">
		<div style="display:flex; align-items:center; gap:12px;">
			<span style="display:inline-flex; align-items:center; justify-content:center; width:40px; height:40px; border-radius:8px; background:rgba(255,255,255,0.12); color:#fff;">
				<span class="dashicons dashicons-book-alt" style="font-size:22px; width:22px; height:22px;"></span>
			</span>
			<div>
				<h3 style="margin:0; font-size:17px; font-weight:700; color:#fff;"><?php esc_html_e( 'Pack Author Documentation & Developer Hub', 'webmcp-nexus' ); ?></h3>
				<p style="margin:2px 0 0; font-size:12px; color:rgba(255,255,255,0.75);"><?php esc_html_e( 'Complete architectural specification, schema reference, lifecycle hooks, and starter boilerplate for custom vertical tool packs.', 'webmcp-nexus' ); ?></p>
			</div>
		</div>
		<span class="wpwm-badge" style="background:rgba(255,255,255,0.15); color:#fff; border:none; padding:4px 10px; font-size:12px;">SDK v1.0.0</span>
	</div>

	<!-- Interactive Tab Navigation -->
	<div class="wpwm-doc-tabs" style="display:flex; border-bottom:1px solid var(--wpwm-border-soft); background:#fcfcfc; padding:0 16px; overflow-x:auto;">
		<button type="button" class="wpwm-doc-tab-btn active" data-tab="tab-overview" style="background:none; border:none; border-bottom:2px solid var(--wpwm-accent); color:var(--wpwm-accent); padding:12px 16px; font-weight:600; font-size:13px; cursor:pointer; display:flex; align-items:center; gap:6px;">
			<span class="dashicons dashicons-dashboard" style="font-size:16px; width:16px; height:16px;"></span>
			<?php esc_html_e( 'Overview & Lifecycle', 'webmcp-nexus' ); ?>
		</button>
		<button type="button" class="wpwm-doc-tab-btn" data-tab="tab-manifest" style="background:none; border:none; border-bottom:2px solid transparent; color:var(--wpwm-text-muted); padding:12px 16px; font-weight:600; font-size:13px; cursor:pointer; display:flex; align-items:center; gap:6px;">
			<span class="dashicons dashicons-media-code" style="font-size:16px; width:16px; height:16px;"></span>
			<?php esc_html_e( 'Manifest Schema (JSON)', 'webmcp-nexus' ); ?>
		</button>
		<button type="button" class="wpwm-doc-tab-btn" data-tab="tab-bootstrap" style="background:none; border:none; border-bottom:2px solid transparent; color:var(--wpwm-text-muted); padding:12px 16px; font-weight:600; font-size:13px; cursor:pointer; display:flex; align-items:center; gap:6px;">
			<span class="dashicons dashicons-rest-api" style="font-size:16px; width:16px; height:16px;"></span>
			<?php esc_html_e( 'Bootstrap & Runner Contract', 'webmcp-nexus' ); ?>
		</button>
		<button type="button" class="wpwm-doc-tab-btn" data-tab="tab-boilerplate" style="background:none; border:none; border-bottom:2px solid transparent; color:var(--wpwm-text-muted); padding:12px 16px; font-weight:600; font-size:13px; cursor:pointer; display:flex; align-items:center; gap:6px;">
			<span class="dashicons dashicons-clipboard" style="font-size:16px; width:16px; height:16px;"></span>
			<?php esc_html_e( 'Starter Boilerplate', 'webmcp-nexus' ); ?>
		</button>
		<button type="button" class="wpwm-doc-tab-btn" data-tab="tab-ai-clients" style="background:none; border:none; border-bottom:2px solid transparent; color:var(--wpwm-text-muted); padding:12px 16px; font-weight:600; font-size:13px; cursor:pointer; display:flex; align-items:center; gap:6px;">
			<span class="dashicons dashicons-share" style="font-size:16px; width:16px; height:16px;"></span>
			<?php esc_html_e( 'Connecting AI Clients', 'webmcp-nexus' ); ?>
		</button>
	</div>

	<!-- Tab Panels -->
	<div class="wpwm-doc-content" style="padding:24px;">

		<!-- TAB 1: Overview & Architecture -->
		<div class="wpwm-doc-tab-pane active" id="tab-overview">
			<h4 style="margin:0 0 10px; font-size:16px; color:var(--wpwm-text);"><?php esc_html_e( 'How Vertical Tool Packs Work', 'webmcp-nexus' ); ?></h4>
			<p style="color:var(--wpwm-text-muted); line-height:1.6; margin-bottom:16px;">
				<?php esc_html_e( 'A Tool Pack is a self-contained WordPress package tailored for an industry niche (e.g. Recipes, Real Estate, Events, Job Board, LMS Courses). Unlike generic plugins, Tool Packs connect three layers simultaneously: your database entities (CPTs & taxonomies), registered MCP tools, and autonomous AI agents.', 'webmcp-nexus' ); ?>
			</p>

			<div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap:16px; margin-bottom:20px;">
				<div style="background:#f8f9fa; border:1px solid var(--wpwm-border-soft); border-radius:6px; padding:16px;">
					<h5 style="margin:0 0 8px; color:var(--wpwm-accent); font-size:13px; display:flex; align-items:center; gap:6px;">
						<span class="dashicons dashicons-category"></span> 1. File Discovery
					</h5>
					<p style="margin:0; font-size:12px; color:var(--wpwm-text-muted); line-height:1.5;">
						Packs live either in <code>wp-content/wp-webmcp-packs/&lt;slug&gt;/</code> (custom user packs) or bundled in the plugin under <code>packs/&lt;slug&gt;/</code>. The SDK automatically detects all valid packs containing a <code>wp-webmcp-pack.json</code> manifest.
					</p>
				</div>
				<div style="background:#f8f9fa; border:1px solid var(--wpwm-border-soft); border-radius:6px; padding:16px;">
					<h5 style="margin:0 0 8px; color:var(--wpwm-success); font-size:13px; display:flex; align-items:center; gap:6px;">
						<span class="dashicons dashicons-admin-settings"></span> 2. Registration & Execution
					</h5>
					<p style="margin:0; font-size:12px; color:var(--wpwm-text-muted); line-height:1.5;">
						When installed, the pack registers its tools in the database with <code>action_type = 'hook'</code> and <code>action_value = '&lt;slug&gt;::&lt;tool_key&gt;'</code>. Calls from Claude Desktop, Cursor, or ChatGPT are routed directly to your pack's runner method with zero overhead.
					</p>
				</div>
				<div style="background:#f8f9fa; border:1px solid var(--wpwm-border-soft); border-radius:6px; padding:16px;">
					<h5 style="margin:0 0 8px; color:var(--wpwm-info); font-size:13px; display:flex; align-items:center; gap:6px;">
						<span class="dashicons dashicons-trash"></span> 3. Clean Lifecycle
					</h5>
					<p style="margin:0; font-size:12px; color:var(--wpwm-text-muted); line-height:1.5;">
						Packs provide safe, idempotent installation and uninstallation. Uninstalling a pack cleans up all associated tool database rows and seeded sample posts tagged with internal meta flags, leaving zero orphan records.
					</p>
				</div>
			</div>

			<h5 style="margin:16px 0 8px; font-size:14px;"><?php esc_html_e( 'Standard Folder Layout', 'webmcp-nexus' ); ?></h5>
			<pre style="background:#1e1e1e; color:#d4d4d4; padding:14px; border-radius:6px; font-size:12px; line-height:1.6; overflow-x:auto;">wp-content/wp-webmcp-packs/my-vertical/
├── wp-webmcp-pack.json     # Declarative metadata, post types, taxonomies & tool schemas
└── bootstrap.php           # PHP class implementing install(), uninstall(), boot(), and run_tool()</pre>
		</div>

		<!-- TAB 2: Manifest Specification -->
		<div class="wpwm-doc-tab-pane" id="tab-manifest" style="display:none;">
			<h4 style="margin:0 0 10px; font-size:16px; color:var(--wpwm-text);"><?php esc_html_e( 'wp-webmcp-pack.json — Top-Level Manifest Schema', 'webmcp-nexus' ); ?></h4>
			<p style="color:var(--wpwm-text-muted); font-size:13px; margin-bottom:16px;">
				<?php esc_html_e( 'The manifest file is parsed and strictly validated by WP_WebMCP_Pack_Manifest::parse_dir(). Missing required fields or schema violations prevent installation to ensure system safety.', 'webmcp-nexus' ); ?>
			</p>

			<table class="wp-list-table widefat striped" style="font-size:12px; margin-bottom:20px; border-radius:4px; overflow:hidden;">
				<thead>
					<tr>
						<th style="font-weight:700;"><?php esc_html_e( 'Field', 'webmcp-nexus' ); ?></th>
						<th style="font-weight:700;"><?php esc_html_e( 'Type', 'webmcp-nexus' ); ?></th>
						<th style="font-weight:700;"><?php esc_html_e( 'Required', 'webmcp-nexus' ); ?></th>
						<th style="font-weight:700;"><?php esc_html_e( 'Description & Rules', 'webmcp-nexus' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><code>name</code></td>
						<td><code>string</code></td>
						<td><span class="wpwm-badge wpwm-badge--error"><?php esc_html_e( 'Yes', 'webmcp-nexus' ); ?></span></td>
						<td><?php esc_html_e( 'Human-readable pack title displayed in the admin UI (e.g. "Real Estate & Properties").', 'webmcp-nexus' ); ?></td>
					</tr>
					<tr>
						<td><code>slug</code></td>
						<td><code>string</code></td>
						<td><span class="wpwm-badge wpwm-badge--error"><?php esc_html_e( 'Yes', 'webmcp-nexus' ); ?></span></td>
						<td><?php esc_html_e( 'Unique identifier [a-z0-9-]. Must exactly match the pack directory name.', 'webmcp-nexus' ); ?></td>
					</tr>
					<tr>
						<td><code>version</code></td>
						<td><code>string</code></td>
						<td><span class="wpwm-badge wpwm-badge--error"><?php esc_html_e( 'Yes', 'webmcp-nexus' ); ?></span></td>
						<td><?php esc_html_e( 'Semantic version string (e.g. "1.0.0"). Used for tracking and upgrade hooks.', 'webmcp-nexus' ); ?></td>
					</tr>
					<tr>
						<td><code>author</code></td>
						<td><code>string</code></td>
						<td><span class="wpwm-badge wpwm-badge--error"><?php esc_html_e( 'Yes', 'webmcp-nexus' ); ?></span></td>
						<td><?php esc_html_e( 'Developer or organization name authoring the pack.', 'webmcp-nexus' ); ?></td>
					</tr>
					<tr>
						<td><code>license</code></td>
						<td><code>string</code></td>
						<td><span class="wpwm-badge wpwm-badge--error"><?php esc_html_e( 'Yes', 'webmcp-nexus' ); ?></span></td>
						<td><?php esc_html_e( 'SPDX license identifier (e.g. "GPL-2.0-or-later").', 'webmcp-nexus' ); ?></td>
					</tr>
					<tr>
						<td><code>description</code></td>
						<td><code>string</code></td>
						<td><span class="wpwm-badge"><?php esc_html_e( 'Optional', 'webmcp-nexus' ); ?></span></td>
						<td><?php esc_html_e( 'Summary of the niche data model and tools provided.', 'webmcp-nexus' ); ?></td>
					</tr>
					<tr>
						<td><code>entry</code></td>
						<td><code>string</code></td>
						<td><span class="wpwm-badge wpwm-badge--error"><?php esc_html_e( 'Yes', 'webmcp-nexus' ); ?></span></td>
						<td><?php esc_html_e( 'PHP entry point file relative to the pack root (default: "bootstrap.php").', 'webmcp-nexus' ); ?></td>
					</tr>
					<tr>
						<td><code>post_types</code></td>
						<td><code>string[]</code></td>
						<td><span class="wpwm-badge"><?php esc_html_e( 'Optional', 'webmcp-nexus' ); ?></span></td>
						<td><?php esc_html_e( 'List of CPT slugs registered by this pack (e.g. ["property_listing"]).', 'webmcp-nexus' ); ?></td>
					</tr>
					<tr>
						<td><code>taxonomies</code></td>
						<td><code>string[]</code></td>
						<td><span class="wpwm-badge"><?php esc_html_e( 'Optional', 'webmcp-nexus' ); ?></span></td>
						<td><?php esc_html_e( 'List of taxonomy slugs registered by this pack (e.g. ["property_type", "property_city"]).', 'webmcp-nexus' ); ?></td>
					</tr>
					<tr>
						<td><code>tools</code></td>
						<td><code>array</code></td>
						<td><span class="wpwm-badge wpwm-badge--error"><?php esc_html_e( 'Yes', 'webmcp-nexus' ); ?></span></td>
						<td><?php esc_html_e( 'List of tool definition objects (1 or more required). See tool schema below.', 'webmcp-nexus' ); ?></td>
					</tr>
				</tbody>
			</table>

			<h4 style="margin:20px 0 10px; font-size:15px; color:var(--wpwm-text);"><?php esc_html_e( 'tools[] — Tool Definition Schema', 'webmcp-nexus' ); ?></h4>
			<table class="wp-list-table widefat striped" style="font-size:12px; border-radius:4px; overflow:hidden;">
				<thead>
					<tr>
						<th style="font-weight:700;"><?php esc_html_e( 'Key', 'webmcp-nexus' ); ?></th>
						<th style="font-weight:700;"><?php esc_html_e( 'Type', 'webmcp-nexus' ); ?></th>
						<th style="font-weight:700;"><?php esc_html_e( 'Description', 'webmcp-nexus' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><code>key</code></td>
						<td><code>string</code></td>
						<td><?php esc_html_e( 'Snake_case identifier passed to your run_tool() method (e.g. "search_properties").', 'webmcp-nexus' ); ?></td>
					</tr>
					<tr>
						<td><code>name</code></td>
						<td><code>string</code></td>
						<td><?php esc_html_e( 'Public tool name exposed to AI clients (e.g. "searchProperties"). Defaults to key if omitted.', 'webmcp-nexus' ); ?></td>
					</tr>
					<tr>
						<td><code>description</code></td>
						<td><code>string</code></td>
						<td><?php esc_html_e( 'Sentence describing what the tool does and when the AI should choose it.', 'webmcp-nexus' ); ?></td>
					</tr>
					<tr>
						<td><code>parameters</code></td>
						<td><code>object</code></td>
						<td><?php esc_html_e( 'Standard JSON Schema object defining input arguments, types, descriptions, and required fields.', 'webmcp-nexus' ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>

		<!-- TAB 3: Bootstrap & Runner Contract -->
		<div class="wpwm-doc-tab-pane" id="tab-bootstrap" style="display:none;">
			<h4 style="margin:0 0 10px; font-size:16px; color:var(--wpwm-text);"><?php esc_html_e( 'bootstrap.php — Implementation Contract', 'webmcp-nexus' ); ?></h4>
			<p style="color:var(--wpwm-text-muted); font-size:13px; line-height:1.6; margin-bottom:16px;">
				<?php esc_html_e( 'Your entry file must define a class named according to the convention WP_WebMCP_Pack_{StudlySlug}. For instance, a pack with slug "real-estate" defines class WP_WebMCP_Pack_RealEstate. The class exposes 4 lifecycle methods:', 'webmcp-nexus' ); ?>
			</p>

			<div style="display:grid; grid-template-columns:1fr; gap:12px; margin-bottom:20px;">
				<div style="border-left:4px solid var(--wpwm-accent); padding:10px 14px; background:#f8f9fa;">
					<strong style="color:var(--wpwm-text);">1. <code>boot(): void</code></strong>
					<p style="margin:4px 0 0; font-size:12px; color:var(--wpwm-text-muted);">
						Called on every request when the pack is installed. Hooks <code>init</code> (at priority 9) to register post types/taxonomies and hooks <code>wpwebmcp_pack_runner_{slug}</code> to receive tool calls.
					</p>
				</div>
				<div style="border-left:4px solid var(--wpwm-success); padding:10px 14px; background:#f8f9fa;">
					<strong style="color:var(--wpwm-text);">2. <code>install( array $manifest ): bool|\WP_Error</code></strong>
					<p style="margin:4px 0 0; font-size:12px; color:var(--wpwm-text-muted);">
						Executed once when the user clicks "Install Pack". Registers post types, seeds demo posts, and inserts tool rows in the database via <code>WP_WebMCP_Tool_Repository::upsert_by_slug()</code>.
					</p>
				</div>
				<div style="border-left:4px solid var(--wpwm-error); padding:10px 14px; background:#f8f9fa;">
					<strong style="color:var(--wpwm-text);">3. <code>uninstall( array $manifest ): bool</code></strong>
					<p style="margin:4px 0 0; font-size:12px; color:var(--wpwm-text-muted);">
						Executed when the user uninstalls the pack. Deletes registered tool rows from the database and cleans up any seeded posts.
					</p>
				</div>
				<div style="border-left:4px solid var(--wpwm-info); padding:10px 14px; background:#f8f9fa;">
					<strong style="color:var(--wpwm-text);">4. <code>run_tool( $default, string $tool_key, array $params ): array|\WP_Error</code></strong>
					<p style="margin:4px 0 0; font-size:12px; color:var(--wpwm-text-muted);">
						Callback for the <code>wpwebmcp_pack_runner_{slug}</code> filter. Receives the dispatched tool key and validated parameters. Returns an associative array of results or <code>\WP_Error</code>.
					</p>
				</div>
			</div>

			<h5 style="margin:16px 0 8px; font-size:14px;"><?php esc_html_e( 'How Tool Dispatching Works (Filter Bridge)', 'webmcp-nexus' ); ?></h5>
			<p style="font-size:12px; color:var(--wpwm-text-muted); line-height:1.5;">
				When an AI agent invokes an MCP tool, the executor triggers the core filter <code>wpwebmcp_tool_call_response</code> with action value <code>{slug}::{tool_key}</code>. The built-in <code>WP_WebMCP_Pack_Filter_Bridge</code> splits this value and invokes <code>wpwebmcp_pack_runner_{slug}</code>, delivering the call directly to your class method!
			</p>
		</div>

		<!-- TAB 4: Copy-Paste Starter Boilerplate -->
		<div class="wpwm-doc-tab-pane" id="tab-boilerplate" style="display:none;">
			<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
				<h4 style="margin:0; font-size:16px; color:var(--wpwm-text);"><?php esc_html_e( 'Starter Boilerplate: wp-webmcp-pack.json', 'webmcp-nexus' ); ?></h4>
				<button type="button" class="button button-secondary wpwm-copy-btn" data-target="code-manifest" style="font-size:12px;">
					<span class="dashicons dashicons-admin-page" style="vertical-align:text-bottom;"></span> <?php esc_html_e( 'Copy Manifest JSON', 'webmcp-nexus' ); ?>
				</button>
			</div>
			<pre id="code-manifest" style="background:#1e1e1e; color:#d4d4d4; padding:14px; border-radius:6px; font-size:12px; line-height:1.5; overflow-x:auto; margin-bottom:24px;">{
  "name": "My Custom Vertical",
  "slug": "my-vertical",
  "version": "1.0.0",
  "author": "My Agency",
  "license": "GPL-2.0-or-later",
  "description": "Custom vertical tool pack for specialized industry content.",
  "min_wp_webmcp_version": "1.0.0",
  "free": true,
  "seed_data": true,
  "post_types": ["custom_entity"],
  "taxonomies": ["entity_category"],
  "entry": "bootstrap.php",
  "tools": [
    {
      "key": "search_entities",
      "name": "searchEntities",
      "description": "Search custom entities by keyword and category.",
      "parameters": {
        "type": "object",
        "properties": {
          "query":    { "type": "string", "description": "Search term." },
          "category": { "type": "string", "description": "Category slug." },
          "max":      { "type": "integer", "description": "Maximum results (default 10)." }
        }
      }
    },
    {
      "key": "get_entity",
      "name": "getEntity",
      "description": "Retrieve full details for an entity by ID.",
      "parameters": {
        "type": "object",
        "properties": {
          "entity_id": { "type": "integer", "description": "Post ID." }
        },
        "required": ["entity_id"]
      }
    }
  ]
}</pre>

			<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
				<h4 style="margin:0; font-size:16px; color:var(--wpwm-text);"><?php esc_html_e( 'Starter Boilerplate: bootstrap.php', 'webmcp-nexus' ); ?></h4>
				<button type="button" class="button button-secondary wpwm-copy-btn" data-target="code-bootstrap" style="font-size:12px;">
					<span class="dashicons dashicons-admin-page" style="vertical-align:text-bottom;"></span> <?php esc_html_e( 'Copy Bootstrap PHP', 'webmcp-nexus' ); ?>
				</button>
			</div>
			<pre id="code-bootstrap" style="background:#1e1e1e; color:#d4d4d4; padding:14px; border-radius:6px; font-size:12px; line-height:1.5; overflow-x:auto;">&lt;?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_WebMCP_Pack_MyVertical {

    public const SLUG      = 'my-vertical';
    public const POST_TYPE = 'custom_entity';

    public static function boot(): void {
        add_action( 'init', array( self::class, 'register_post_type' ), 9 );
        add_filter( 'wpwebmcp_pack_runner_my-vertical', array( self::class, 'run_tool' ), 10, 3 );
    }

    public static function register_post_type(): void {
        register_post_type( self::POST_TYPE, array(
            'labels'       => array( 'name' => 'Entities', 'singular_name' => 'Entity' ),
            'public'       => true,
            'show_in_rest' => true,
            'supports'     => array( 'title', 'editor', 'custom-fields' ),
        ) );
    }

    public static function install( array $manifest ) {
        self::register_post_type();

        foreach ( (array) ( $manifest['tools'] ?? array() ) as $tool ) {
            if ( class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
                WP_WebMCP_Tool_Repository::upsert_by_slug( array(
                    'tool_name'        => (string) ( $tool['name'] ?? $tool['key'] ),
                    'tool_description' => (string) ( $tool['description'] ?? '' ),
                    'tool_type'        => 'read',
                    'tool_scope'       => self::SLUG,
                    'action_type'      => 'hook',
                    'action_value'     => self::SLUG . '::' . (string) $tool['key'],
                    'parameters'       => (array) ( $tool['parameters'] ?? array() ),
                    'status'           => 'active',
                ) );
            }
        }
        return true;
    }

    public static function uninstall( array $manifest ) {
        foreach ( (array) ( $manifest['tools'] ?? array() ) as $tool ) {
            $name = (string) ( $tool['name'] ?? $tool['key'] );
            if ( class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
                $row = WP_WebMCP_Tool_Repository::find_by_slug( $name );
                if ( $row ) {
                    WP_WebMCP_Tool_Repository::delete( (int) $row['id'] );
                }
            }
        }
        return true;
    }

    public static function run_tool( $default, string $tool_key, array $params ) {
        switch ( $tool_key ) {
            case 'search_entities':
                $posts = get_posts( array( 'post_type' => self::POST_TYPE, 's' => $params['query'] ?? '' ) );
                return array( 'count' => count( $posts ), 'items' => $posts );

            case 'get_entity':
                $post = get_post( (int) ( $params['entity_id'] ?? 0 ) );
                return $post ? array( 'entity' => $post ) : array( 'error' => 'Not found' );

            default:
                return $default;
        }
    }
}</pre>
		</div>

		<!-- TAB 5: Connecting AI Clients -->
		<div class="wpwm-doc-tab-pane" id="tab-ai-clients" style="display:none;">
			<h4 style="margin:0 0 10px; font-size:16px; color:var(--wpwm-text);"><?php esc_html_e( 'Connecting AI Assistants & IDEs', 'webmcp-nexus' ); ?></h4>
			<p style="color:var(--wpwm-text-muted); font-size:13px; line-height:1.6; margin-bottom:16px;">
				<?php esc_html_e( 'Once a tool pack is installed, its tools are instantly published to your site\'s MCP endpoint. You can connect any MCP-compatible client directly using your WordPress credentials.', 'webmcp-nexus' ); ?>
			</p>

			<div style="background:#fcfcfc; border:1px solid var(--wpwm-border-soft); border-radius:6px; padding:16px; margin-bottom:18px;">
				<h5 style="margin:0 0 8px; font-size:13px; color:var(--wpwm-text);">Claude Desktop Configuration</h5>
				<p style="margin:0 0 8px; font-size:12px; color:var(--wpwm-text-muted);">
					Add the following to your <code>claude_desktop_config.json</code>:
				</p>
				<pre style="background:#1e1e1e; color:#d4d4d4; padding:12px; border-radius:4px; font-size:12px; line-height:1.45; overflow-x:auto;">{
  "mcpServers": {
    "my-wordpress-site": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/server-everything"
      ],
      "env": {
        "WEBMCP_URL": "<?php echo esc_url( rest_url( 'wpwebmcp/v1' ) ); ?>"
      }
    }
  }
}</pre>
			</div>

			<div style="background:#fcfcfc; border:1px solid var(--wpwm-border-soft); border-radius:6px; padding:16px;">
				<h5 style="margin:0 0 8px; font-size:13px; color:var(--wpwm-text);">Direct REST API Verification (cURL)</h5>
				<p style="margin:0 0 8px; font-size:12px; color:var(--wpwm-text-muted);">
					You can also verify any pack tool directly from your terminal:
				</p>
				<pre style="background:#1e1e1e; color:#d4d4d4; padding:12px; border-radius:4px; font-size:12px; line-height:1.45; overflow-x:auto;">curl -X POST "<?php echo esc_url( rest_url( 'wpwebmcp/v1/tools/call' ) ); ?>" \
  -H "Content-Type: application/json" \
  -d '{"name": "searchProperties", "arguments": {"city": "miami"}}'</pre>
			</div>
		</div>

	</div>
</div>

<script>
(function() {
	// Tab switching logic for Developer Hub.
	var tabButtons = document.querySelectorAll('.wpwm-doc-tab-btn');
	var tabPanes   = document.querySelectorAll('.wpwm-doc-tab-pane');

	tabButtons.forEach(function(btn) {
		btn.addEventListener('click', function() {
			var targetId = this.getAttribute('data-tab');

			tabButtons.forEach(function(b) {
				b.classList.remove('active');
				b.style.borderBottomColor = 'transparent';
				b.style.color = 'var(--wpwm-text-muted)';
			});

			tabPanes.forEach(function(p) {
				p.style.display = 'none';
				p.classList.remove('active');
			});

			this.classList.add('active');
			this.style.borderBottomColor = 'var(--wpwm-accent)';
			this.style.color = 'var(--wpwm-accent)';

			var targetPane = document.getElementById(targetId);
			if (targetPane) {
				targetPane.style.display = 'block';
				targetPane.classList.add('active');
			}
		});
	});

	// Copy to clipboard buttons.
	var copyButtons = document.querySelectorAll('.wpwm-copy-btn');
	copyButtons.forEach(function(btn) {
		btn.addEventListener('click', function() {
			var targetId = this.getAttribute('data-target');
			var codeEl   = document.getElementById(targetId);
			if (!codeEl) return;

			var text = codeEl.innerText || codeEl.textContent;
			navigator.clipboard.writeText(text).then(function() {
				var origText = btn.innerHTML;
				btn.innerHTML = '<span class="dashicons dashicons-yes" style="vertical-align:text-bottom;"></span> Copied!';
				setTimeout(function() {
					btn.innerHTML = origText;
				}, 2000);
			});
		});
	});
})();
</script>
