<?php
// phpcs:disable WordPress.Security.NonceVerification.Recommended -- nonce verified by caller (page handler)

/**
 * Policies admin page partial (A2a — visual policy builder).
 *
 * Shows the existing policy rows, an inline add/edit form, and a
 * friendly notice after save/delete. The page wrapper (header + notice
 * area) is rendered by WP_WebMCP_Admin::render_screen().
 *
 * @package WP_WebMCP
 * @since   1.0.0
 *
 * @var array<int,array<string,mixed>> $policies
 * @var array<string,array<int,string>> $sets
 * @var array<string,mixed>|null       $editing
 * @var string|null                    $wpwebmcp_notice
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Read notice from the GET param too (delete URL handler redirects are
// scoped to the same screen so the PRG pattern isn't strictly required).
if ( ! isset( $wpwebmcp_notice ) && isset( $_GET['notice'] ) ) {
	$wpwebmcp_notice = sanitize_key( (string) wp_unslash( $_GET['notice'] ) );
}
$wpwebmcp_notice_messages = array(
	'saved'         => __( 'Policy saved.', 'webmcp-nexus' ),
	'deleted'       => __( 'Policy deleted.', 'webmcp-nexus' ),
	'invalid_nonce' => __( 'Security check failed — please reload and retry.', 'webmcp-nexus' ),
	'save_error'    => __( 'Could not save policy (invalid input).', 'webmcp-nexus' ),
);

// F2 partial patch marker: dynamic notice keys for PRG redirects.
if ( null !== $wpwebmcp_notice && 0 === strpos( (string) $wpwebmcp_notice, 'seeded_' ) ) {
	$wpwebmcp_parts = explode( '_', (string) $wpwebmcp_notice );
	$wpwebmcp_notice_messages[ $wpwebmcp_notice ] = sprintf(
		/* translators: 1: created count, 2: skipped count */
		__( 'Sample policies: %1$d created, %2$d skipped (already present).', 'webmcp-nexus' ),
		isset( $wpwebmcp_parts[1] ) ? (int) $wpwebmcp_parts[1] : 0,
		isset( $wpwebmcp_parts[2] ) ? (int) $wpwebmcp_parts[2] : 0
	);
}
if ( null !== $wpwebmcp_notice && 0 === strpos( (string) $wpwebmcp_notice, 'deduped_' ) ) {
	$wpwebmcp_notice_messages[ $wpwebmcp_notice ] = sprintf(
		/* translators: %d: removed duplicates count */
		__( 'Removed %d duplicate policy rule(s) — oldest copy kept.', 'webmcp-nexus' ),
		(int) substr( (string) $wpwebmcp_notice, 8 )
	);
}
if ( null !== $wpwebmcp_notice ) {
	$wpwebmcp_extra_notices = array(
		'grace_updated'  => __( 'New-crawler grace setting updated.', 'webmcp-nexus' ),
		'preset_applied' => __( 'Preset applied.', 'webmcp-nexus' ),
		'preset_removed' => __( 'Preset removed.', 'webmcp-nexus' ),
	);
	foreach ( $wpwebmcp_extra_notices as $wpwebmcp_k => $wpwebmcp_m ) {
		if ( ! isset( $wpwebmcp_notice_messages[ $wpwebmcp_k ] ) ) {
			$wpwebmcp_notice_messages[ $wpwebmcp_k ] = $wpwebmcp_m;
		}
	}
}

// Compute preset notice message from transient (set by the apply/remove
// handlers in WP_WebMCP_Policies_Page::maybe_handle_save()).
$wpwebmcp_preset_notice_html = '';
$wpwebmcp_preset_apply_key   = 'wpwebmcp_last_preset_apply_' . get_current_user_id();
$wpwebmcp_preset_remove_key  = 'wpwebmcp_last_preset_remove_' . get_current_user_id();
$wpwebmcp_preset_apply_data  = get_transient( $wpwebmcp_preset_apply_key );
$wpwebmcp_preset_remove_data = get_transient( $wpwebmcp_preset_remove_key );
if ( is_array( $wpwebmcp_preset_apply_data ) ) {
	delete_transient( $wpwebmcp_preset_apply_key );
	$wpwebmcp_created = isset( $wpwebmcp_preset_apply_data['created'] ) ? (int) $wpwebmcp_preset_apply_data['created'] : 0;
	$wpwebmcp_skipped = isset( $wpwebmcp_preset_apply_data['skipped'] ) ? (int) $wpwebmcp_preset_apply_data['skipped'] : 0;
	if ( 0 === $wpwebmcp_created && 0 === $wpwebmcp_skipped ) {
		$wpwebmcp_preset_notice_html = __( 'Preset applied — no changes (empty preset).', 'webmcp-nexus' );
	} elseif ( 0 === $wpwebmcp_skipped ) {
		$wpwebmcp_preset_notice_html = sprintf(
			/* translators: %d: number of policies inserted */
			_n( 'Preset applied — %d policy added to the active list.', 'Preset applied — %d policies added to the active list.', $wpwebmcp_created, 'webmcp-nexus' ),
			$wpwebmcp_created
		);
	} elseif ( 0 === $wpwebmcp_created ) {
		$wpwebmcp_preset_notice_html = sprintf(
			/* translators: %d: number of already-applied rows */
			_n( 'Preset already applied — %d row skipped (idempotent).', 'Preset already applied — %d rows skipped (idempotent).', $wpwebmcp_skipped, 'webmcp-nexus' ),
			$wpwebmcp_skipped
		);
	} else {
		$wpwebmcp_preset_notice_html = sprintf(
			/* translators: %1$d: Created count, %2$d: Skipped count */
			__( 'Preset applied — %1$d new, %2$d already present (idempotent).', 'webmcp-nexus' ),
			$wpwebmcp_created,
			$wpwebmcp_skipped
		);
	}
}
if ( is_array( $wpwebmcp_preset_remove_data ) ) {
	delete_transient( $wpwebmcp_preset_remove_key );
	$wpwebmcp_deleted = isset( $wpwebmcp_preset_remove_data['deleted'] ) ? (int) $wpwebmcp_preset_remove_data['deleted'] : 0;
	$wpwebmcp_preset_notice_html = sprintf(
		/* translators: %d: number of policies removed */
		_n( 'Preset removed — %d policy row deleted.', 'Preset removed — %d policy rows deleted.', $wpwebmcp_deleted, 'webmcp-nexus' ),
		$wpwebmcp_deleted
	);
}
?>
<!-- Educational Guide Card -->
<div class="wpwm-guide-card wpwm-guide-card--featured">
	<div class="wpwm-guide-header">
		<span class="wpwm-guide-icon"><span class="dashicons dashicons-shield" aria-hidden="true"></span></span>
		<div>
			<h2 class="wpwm-guide-title"><?php esc_html_e( 'AI Access & Security Policy Engine', 'webmcp-nexus' ); ?></h2>
			<p class="wpwm-field-helper" style="margin:2px 0 0;"><?php esc_html_e( 'Fine-grained firewall and permissions for AI crawlers, bots, and autonomous agents.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
	<p class="wpwm-guide-desc">
		<?php esc_html_e( 'Policies determine exactly what actions each AI agent can perform on your site. When an AI agent attempts to query a tool or access content, WebMCP Nexus checks your active policies in priority order (lowest priority number evaluates first). The first rule that matches decides whether the request is allowed, rate-limited, field-redacted, or blocked.', 'webmcp-nexus' ); ?>
	</p>
	<div class="wpwm-guide-grid">
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-sort" style="color:var(--wpwm-accent);"></span> <?php esc_html_e( '1. First-Match Priority', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Stack specific agent rules at priority 1-10 and wildcard catch-all rules at priority 100.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-admin-generic" style="color:var(--wpwm-info);"></span> <?php esc_html_e( '2. 4 Enforced Actions', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Allow (full access), Rate-Limit (enforce requests/min), Redact (strip sensitive fields), or Block (HTTP 403).', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-layout" style="color:var(--wpwm-success);"></span> <?php esc_html_e( '3. Instant Presets', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Apply battle-tested policy bundles for search engines, autonomous shoppers, or privacy-first sites.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
</div>

<div class="wpwm-section">
	<h2 class="wpwm-h2"><?php esc_html_e( 'Per-agent access policies', 'webmcp-nexus' ); ?></h2>
	<p class="wpwm-muted"><?php esc_html_e( 'Rules are evaluated in priority order (lowest priority value wins). The first matching policy decides the outcome for the request.', 'webmcp-nexus' ); ?></p>

	<?php if ( null !== $wpwebmcp_notice && isset( $wpwebmcp_notice_messages[ $wpwebmcp_notice ] ) ) : ?>
		<div class="notice notice-<?php echo ( 'invalid_nonce' === $wpwebmcp_notice || 'save_error' === $wpwebmcp_notice ) ? 'error' : 'success'; ?> is-dismissible">
			<p><?php echo esc_html( $wpwebmcp_notice_messages[ $wpwebmcp_notice ] ); ?></p>
		</div>
	<?php endif; ?>

	<form method="post" class="wpwm-form wpwm-form-card">
		<?php echo WP_WebMCP_Policies_Page::nonce_field(); // F2 fix: nonce_field() returns its HTML; without echo the add/edit form had no nonce and every submission failed ?>
		<h3 class="wpwm-h3">
			<?php
			if ( null !== $editing ) {
				echo esc_html(
					sprintf(
						/* translators: %s: policy id */
						__( 'Edit policy %s', 'webmcp-nexus' ),
						(string) ( $editing['id'] ?? '' )
					)
				);
			} else {
				esc_html_e( 'Add policy', 'webmcp-nexus' );
			}
			?>
		</h3>

		<?php if ( null !== $editing ) : ?>
			<input type="hidden" name="id" value="<?php echo esc_attr( (string) ( $editing['id'] ?? '' ) ); ?>">
		<?php endif; ?>

		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row"><label for="wpwm-policy-name"><?php esc_html_e( 'Label', 'webmcp-nexus' ); ?></label></th>
					<td>
						<input id="wpwm-policy-name" name="name" type="text" class="regular-text" value="<?php echo esc_attr( (string) ( $editing['name'] ?? '' ) ); ?>" placeholder="<?php esc_attr_e( 'e.g., GPTBot → read-only', 'webmcp-nexus' ); ?>">
						<p class="description"><?php esc_html_e( 'Human-readable name for this rule.', 'webmcp-nexus' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="wpwm-policy-priority"><?php esc_html_e( 'Priority', 'webmcp-nexus' ); ?></label></th>
					<td>
						<input id="wpwm-policy-priority" name="priority" type="number" min="1" step="1" value="<?php echo esc_attr( (string) ( $editing['priority'] ?? 100 ) ); ?>">
						<p class="description"><?php esc_html_e( 'Lower numbers win. Use 10–20 for specific agents, 100+ for catch-all.', 'webmcp-nexus' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Match', 'webmcp-nexus' ); ?></th>
					<td>
						<fieldset>
							<legend class="screen-reader-text"><?php esc_html_e( 'Match clause', 'webmcp-nexus' ); ?></legend>
							<?php
							$wpwebmcp_current_match = (string) ( $editing['match_type'] ?? 'all' );
							$wpwebmcp_match_options = array(
								'all'            => __( 'All agents (catch-all)', 'webmcp-nexus' ),
								'agent_slug'     => __( 'Specific agent (e.g., GPTBot, ClaudeBot)', 'webmcp-nexus' ),
								'agent_family'   => __( 'Agent family (e.g., gpt, claude)', 'webmcp-nexus' ),
								'unknown_agent'  => __( 'Unknown / unidentified agents', 'webmcp-nexus' ),
								'blocked_agent'  => __( 'Agents blocked via the Agents page', 'webmcp-nexus' ),
							);
							foreach ( $wpwebmcp_match_options as $wpwebmcp_value => $wpwebmcp_label ) :
								?>
								<label style="display:block;margin-bottom:6px;">
									<input type="radio" name="match_type" value="<?php echo esc_attr( $wpwebmcp_value ); ?>" <?php checked( $wpwebmcp_current_match, $wpwebmcp_value ); ?>>
									<?php echo esc_html( $wpwebmcp_label ); ?>
								</label>
							<?php endforeach; ?>
						</fieldset>
						<input name="match_value" type="text" class="regular-text" style="margin-top:6px;" value="<?php echo esc_attr( (string) ( $editing['match_value'] ?? '' ) ); ?>" placeholder="<?php esc_attr_e( 'Agent slug / family (required for agent_slug / agent_family)', 'webmcp-nexus' ); ?>">
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="wpwm-policy-action"><?php esc_html_e( 'Action', 'webmcp-nexus' ); ?></label></th>
					<td>
						<?php $wpwebmcp_current_action = (string) ( $editing['action'] ?? 'allow' ); ?>
						<select id="wpwm-policy-action" name="action">
							<option value="allow" <?php selected( $wpwebmcp_current_action, 'allow' ); ?>><?php esc_html_e( 'Allow (pass-through)', 'webmcp-nexus' ); ?></option>
							<option value="block" <?php selected( $wpwebmcp_current_action, 'block' ); ?>><?php esc_html_e( 'Block (return 403)', 'webmcp-nexus' ); ?></option>
							<option value="rate_limit" <?php selected( $wpwebmcp_current_action, 'rate_limit' ); ?>><?php esc_html_e( 'Rate-limit (return 429)', 'webmcp-nexus' ); ?></option>
							<option value="redact_email" <?php selected( $wpwebmcp_current_action, 'redact_email' ); ?>><?php esc_html_e( 'Allow + redact emails', 'webmcp-nexus' ); ?></option>
						</select>
					</td>
				</tr>
				<tr class="wpwm-policy-rate-row">
					<th scope="row"><label for="wpwm-policy-rpm"><?php esc_html_e( 'Requests / minute', 'webmcp-nexus' ); ?></label></th>
					<td>
						<input id="wpwm-policy-rpm" name="rate_limit_per_minute" type="number" min="1" step="1" value="<?php echo esc_attr( (string) ( $editing['rate_limit_per_minute'] ?? 30 ) ); ?>">
						<p class="description"><?php esc_html_e( 'Used when action = Rate-limit.', 'webmcp-nexus' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="wpwm-policy-msg"><?php esc_html_e( 'Custom block message', 'webmcp-nexus' ); ?></label></th>
					<td>
						<textarea id="wpwm-policy-msg" name="custom_message" rows="3" class="large-text"><?php echo esc_textarea( (string) ( $editing['custom_message'] ?? '' ) ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Shown to the agent when the action is Block.', 'webmcp-nexus' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Options', 'webmcp-nexus' ); ?></th>
					<td>
						<label style="display:block;">
							<input type="checkbox" name="enabled" value="1" <?php checked( ! isset( $editing['enabled'] ) || ! empty( $editing['enabled'] ) ); ?>>
							<?php esc_html_e( 'Enabled (uncheck to suspend this rule without deleting it)', 'webmcp-nexus' ); ?>
						</label>
						<label style="display:block;">
							<input type="checkbox" name="redact_email" value="1" <?php checked( ! empty( $editing['redact_email'] ) ); ?>>
							<?php esc_html_e( 'Always redact emails from the response (even on allow)', 'webmcp-nexus' ); ?>
						</label>
					</td>
				</tr>
			</tbody>
		</table>

		<p class="submit">
			<?php if ( null !== $editing ) : ?>
				<a class="button button-secondary" href="<?php echo esc_url( admin_url( 'admin.php?page=wp-webmcp-policies' ) ); ?>"><?php esc_html_e( 'Cancel edit', 'webmcp-nexus' ); ?></a>
			<?php endif; ?>
			<button type="submit" class="button button-primary"><?php echo null !== $editing ? esc_html__( 'Update policy', 'webmcp-nexus' ) : esc_html__( 'Add policy', 'webmcp-nexus' ); ?></button>
		</p>
	</form>

	<hr/>

	<h2 class="wpwm-h2"><?php esc_html_e( 'Policy templates by segment', 'webmcp-nexus' ); ?></h2>
	<p class="wpwm-muted"><?php esc_html_e( 'Start from a turnkey template tuned for your site\'s vertical. Applying a template appends its rules to the active list with priorities in the 200-299 range — your custom policies (priority 10-99) still win. Re-applying is idempotent.', 'webmcp-nexus' ); ?></p>

	<?php if ( '' !== $wpwebmcp_preset_notice_html ) : ?>
		<div class="notice notice-success is-dismissible">
			<p><?php echo esc_html( $wpwebmcp_preset_notice_html ); ?></p>
		</div>
	<?php endif; ?>

	<?php if ( empty( $presets ) ) : ?>
		<p class="wpwm-muted"><?php esc_html_e( 'Policy preset library is unavailable (WP_WebMCP_Policy_Presets not loaded).', 'webmcp-nexus' ); ?></p>
	<?php else : ?>
		<div class="wpwm-preset-grid">
			<?php foreach ( $presets as $wpwebmcp_preset ) :
				$wpwebmcp_slug         = (string) ( $wpwebmcp_preset['slug'] ?? '' );
				$wpwebmcp_name         = (string) ( $wpwebmcp_preset['name'] ?? $wpwebmcp_slug );
				$wpwebmcp_icon         = (string) ( $wpwebmcp_preset['icon'] ?? '🧩' );
				$wpwebmcp_tagline      = (string) ( $wpwebmcp_preset['tagline'] ?? '' );
				$wpwebmcp_description  = (string) ( $wpwebmcp_preset['description'] ?? '' );
				$wpwebmcp_policy_count = (int) ( $wpwebmcp_preset['policy_count'] ?? 0 );
				$wpwebmcp_applied      = ! empty( $preset_apply_map[ $wpwebmcp_slug ] );
				?>
				<div class="wpwm-preset-card">
					<div class="wpwm-preset-card-head">
						<span class="wpwm-preset-card-icon" aria-hidden="true"><?php echo esc_html( $wpwebmcp_icon ); ?></span>
						<div>
							<h3 class="wpwm-h3 wpwm-preset-card-title"><?php echo esc_html( $wpwebmcp_name ); ?></h3>
							<?php if ( '' !== $wpwebmcp_tagline ) : ?>
								<p class="wpwm-muted wpwm-preset-card-tagline"><?php echo esc_html( $wpwebmcp_tagline ); ?></p>
							<?php endif; ?>
						</div>
					</div>
					<p class="wpwm-preset-card-desc"><?php echo esc_html( $wpwebmcp_description ); ?></p>
					<p class="wpwm-muted wpwm-preset-card-meta">
						<code class="wpwm-mono"><?php echo esc_html( $wpwebmcp_slug ); ?></code>
						&middot;
						<?php
						echo esc_html(
							sprintf(
								/* translators: %d: policy row count */
								_n( '%d policy', '%d policies', $wpwebmcp_policy_count, 'webmcp-nexus' ),
								$wpwebmcp_policy_count
							)
						);
						?>
					</p>
					<p class="wpwm-preset-card-actions">
						<?php if ( $wpwebmcp_applied ) : ?>
							<span class="wpwm-preset-applied-badge" style="color:#006d2c;"><?php esc_html_e( '✓ Applied', 'webmcp-nexus' ); ?></span><?php if ( ! empty( $preset_counts[ $wpwebmcp_slug ] ) ) : ?> <span class="wpwm-muted" style="margin-left:4px;"><?php echo esc_html( sprintf( _n( '%d row', '%d rows', (int) $preset_counts[ $wpwebmcp_slug ], 'webmcp-nexus' ), (int) $preset_counts[ $wpwebmcp_slug ] ) ); ?></span><?php endif; ?>
							<a class="button button-small" href="<?php echo esc_url( WP_WebMCP_Policies_Page::remove_preset_url( $wpwebmcp_slug ) ); ?>" onclick="return confirm('<?php echo esc_js( __( 'Remove all rows from this preset?', 'webmcp-nexus' ) ); ?>');"><?php esc_html_e( 'Remove', 'webmcp-nexus' ); ?></a>
						<?php else : ?>
							<a class="button button-primary button-small" href="<?php echo esc_url( WP_WebMCP_Policies_Page::apply_preset_url( $wpwebmcp_slug ) ); ?>"><?php esc_html_e( 'Apply template', 'webmcp-nexus' ); ?></a>
						<?php endif; ?>
					</p>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<hr/>

	<h2 class="wpwm-h2"><?php esc_html_e( 'Active policies', 'webmcp-nexus' ); ?></h2>
	<p>
		<a class="button button-secondary" href="<?php echo esc_url( WP_WebMCP_Policies_Page::seed_test_policies_url() ); ?>"><?php esc_html_e( 'Seed 3 sample policies (allow+redact / block / rate-limit)', 'webmcp-nexus' ); ?></a>
		<a class="button button-secondary" href="<?php echo esc_url( WP_WebMCP_Policies_Page::clear_test_policies_url() ); ?>" onclick="return confirm('<?php echo esc_js(__( 'Delete all policies?', 'webmcp-nexus' ) ); ?>');"><?php esc_html_e( 'Clear all policies', 'webmcp-nexus' ); ?></a>
		<a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=wp-webmcp-policies&action=dedupe_policies' ), 'wpwebmcp_dedupe_policies' ) ); ?>"><?php esc_html_e( 'Remove duplicate rules', 'webmcp-nexus' ); ?></a>
		<?php $wpwebmcp_grace_on = (bool) get_option( 'wpwebmcp_unknown_grace_enabled', true ); ?>
		<span style="margin-left:8px;" class="wpwm-muted"><?php esc_html_e( 'New-crawler grace:', 'webmcp-nexus' ); ?> <strong><?php echo $wpwebmcp_grace_on ? esc_html__( 'ON', 'webmcp-nexus' ) : esc_html__( 'OFF', 'webmcp-nexus' ); ?></strong> <em>(<?php esc_html_e( 'unknown-agent blocks enforced as 60/min rate limits', 'webmcp-nexus' ); ?>)</em>
		<a class="button button-small" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=wp-webmcp-policies&action=' . ( $wpwebmcp_grace_on ? 'grace_off' : 'grace_on' ) ), 'wpwebmcp_grace_toggle' ) ); ?>"><?php echo $wpwebmcp_grace_on ? esc_html__( 'Turn off', 'webmcp-nexus' ) : esc_html__( 'Turn on', 'webmcp-nexus' ); ?></a></span>
	</p>
	<?php if ( empty( $policies ) ) : ?>
		<p class="wpwm-muted"><?php esc_html_e( 'No policies yet. Add one above to gate specific agents (GPTBot, ClaudeBot, etc.) or to rate-limit unknown callers.', 'webmcp-nexus' ); ?></p>
	<?php else : ?>
		<table class="widefat striped wpwm-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Label', 'webmcp-nexus' ); ?></th>
					<th><?php esc_html_e( 'Priority', 'webmcp-nexus' ); ?></th>
					<th><?php esc_html_e( 'Match', 'webmcp-nexus' ); ?></th>
					<th><?php esc_html_e( 'Action', 'webmcp-nexus' ); ?></th>
					<th><?php esc_html_e( 'Status', 'webmcp-nexus' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'webmcp-nexus' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $policies as $wpwebmcp_policy ) :
					$wpwebmcp_pid          = (string) ( $wpwebmcp_policy['id'] ?? '' );
					$wpwebmcp_match_label  = (string) ( $wpwebmcp_policy['match_type'] ?? '' );
					if ( in_array( $wpwebmcp_match_label, array( 'agent_slug', 'agent_family' ), true ) && ! empty( $wpwebmcp_policy['match_value'] ) ) {
						$wpwebmcp_match_label .= ' = ' . (string) $wpwebmcp_policy['match_value'];
					}
					?>
					<tr>
						<td><strong><?php echo esc_html( (string) ( $wpwebmcp_policy['name'] ?? $wpwebmcp_pid ) ); ?></strong><br/><code class="wpwm-mono"><?php echo esc_html( $wpwebmcp_pid ); ?></code></td>
						<td><?php echo esc_html( (string) ( $wpwebmcp_policy['priority'] ?? 100 ) ); ?></td>
						<td><code class="wpwm-mono"><?php echo esc_html( $wpwebmcp_match_label ); ?></code></td>
						<td><code class="wpwm-mono"><?php echo esc_html( (string) ( $wpwebmcp_policy['action'] ?? '' ) ); ?><?php echo ( 'rate_limit' === ( $wpwebmcp_policy['action'] ?? '' ) && ! empty( $wpwebmcp_policy['rate_limit_per_minute'] ) ) ? ' (' . esc_html( (string) $wpwebmcp_policy['rate_limit_per_minute'] ) . '/m)' : ''; ?></code></td>
						<td><?php echo empty( $wpwebmcp_policy['enabled'] ) ? '<span style="color:#996800;">' . esc_html__( 'disabled', 'webmcp-nexus' ) . '</span>' : '<span style="color:#006d2c;">' . esc_html__( 'enabled', 'webmcp-nexus' ) . '</span>'; ?></td>
						<td>
							<a class="button button-small" href="<?php echo esc_url( WP_WebMCP_Policies_Page::edit_url( $wpwebmcp_pid ) ); ?>"><?php esc_html_e( 'Edit', 'webmcp-nexus' ); ?></a>
							<a class="button button-small button-link-delete" href="<?php echo esc_url( WP_WebMCP_Policies_Page::delete_url( $wpwebmcp_pid ) ); ?>" onclick="return confirm('<?php echo esc_js( __( 'Delete this policy?', 'webmcp-nexus' ) ); ?>');"><?php esc_html_e( 'Delete', 'webmcp-nexus' ); ?></a>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
</div>