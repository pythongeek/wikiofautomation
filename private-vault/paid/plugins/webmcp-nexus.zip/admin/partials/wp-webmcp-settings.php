<?php
/**
 * Settings screen — Doc §5.8 #2.
 *
 * Step 6: full composition. 6 tabs per §5.8②:
 *   General · Tools & Policy · Rate Limits · Integrations · Privacy · Advanced
 * Every field bound to its option with current values server-rendered.
 * Sticky save bar at the tab bottom fires PUT /settings with all fields
 * (admin JS handles the fetch).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Pull live option values for server-rendered defaults.
$wpwebmcp_enabled              = (bool) get_option( 'wpwebmcp_enabled' );
$wpwebmcp_polyfill_enabled     = (bool) get_option( 'wpwebmcp_polyfill_enabled' );
$wpwebmcp_token_optimize       = (bool) get_option( 'wpwebmcp_token_optimize' );
$wpwebmcp_performance_mode     = (bool) get_option( 'wpwebmcp_performance_mode' );
$wpwebmcp_sandbox_mode         = (bool) get_option( 'wpwebmcp_sandbox_mode' );
$wpwebmcp_ga4_enabled          = (bool) get_option( 'wpwebmcp_ga4_enabled' );
$wpwebmcp_log_privacy_mode     = (bool) get_option( 'wpwebmcp_log_privacy_mode' );
$wpwebmcp_wellknown_enabled    = (bool) get_option( 'wpwebmcp_wellknown_enabled' );
$wpwebmcp_markdown_enabled     = (bool) get_option( 'wpwebmcp_markdown_enabled' );
$wpwebmcp_db_optimize_cron     = (bool) get_option( 'wpwebmcp_db_optimize_cron' );
$wpwebmcp_cleanup_uninstall    = (bool) get_option( 'wpwebmcp_cleanup_uninstall' );

// Module 0 M0a: push server state.
$wpwebmcp_push_enabled        = (bool) get_option( 'wpwebmcp_push_enabled', true );
$wpwebmcp_push_token          = (string) get_option( 'wpwebmcp_push_token', '' );
$wpwebmcp_push_max_subs       = (int) get_option( 'wpwebmcp_push_max_subscribers', 50 );
$wpwebmcp_push_heartbeat_s    = (int) get_option( 'wpwebmcp_push_heartbeat_seconds', 15 );
$wpwebmcp_push_ttl_s          = (int) get_option( 'wpwebmcp_push_connection_ttl', 300 );
$wpwebmcp_push_status         = class_exists( 'WP_WebMCP_Push_Server' ) ? WP_WebMCP_Push_Server::get_status() : array( 'subscribers' => 0, 'channels' => array() );
$wpwebmcp_rest_url_push       = trailingslashit( rest_url( 'wpwebmcp/v1/push/subscribe' ) );

$wpwebmcp_custom_post_types     = (array) get_option( 'wpwebmcp_custom_post_types', array( 'post', 'page' ) );
$wpwebmcp_role_access           = (array) get_option( 'wpwebmcp_role_access', array() );
$wpwebmcp_crawler_directives    = (array) get_option( 'wpwebmcp_crawler_directives', array() );
$wpwebmcp_custom_crawlers       = (array) get_option( 'wpwebmcp_custom_crawlers', array() );

$wpwebmcp_rate_limit_read       = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
$wpwebmcp_rate_limit_write      = (int) get_option( 'wpwebmcp_rate_limit_write', 20 );
$wpwebmcp_max_calls_per_session = (int) get_option( 'wpwebmcp_max_calls_per_session', 200 );

$wpwebmcp_log_retention_days    = (int) get_option( 'wpwebmcp_log_retention_days', 30 );
$wpwebmcp_bot_log_retention_days = (int) get_option( 'wpwebmcp_bot_log_retention_days', 90 );

$wpwebmcp_llmstxt_mode          = (string) get_option( 'wpwebmcp_llmstxt_mode', 'auto' );
$wpwebmcp_llmstxt_custom        = (string) get_option( 'wpwebmcp_llmstxt_custom', '' );

$wpwebmcp_alert_email           = (string) get_option( 'wpwebmcp_alert_email', '' );
$wpwebmcp_alerts_enabled        = (bool) get_option( 'wpwebmcp_alerts_enabled' );

// Public post types for the General tab checkboxes.
$wpwebmcp_public_post_types = get_post_types( array( 'public' => true ), 'names' );
?>
<div class="wpwm-tabs" data-wpwm-tabs id="wpwm-settings-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Settings sections', 'webmcp-nexus' ); ?>">
	<button class="wpwm-tab" role="tab" data-tab="general"        aria-controls="wpwm-tab-general"        aria-selected="false"><?php esc_html_e( 'General', 'webmcp-nexus' ); ?></button>
	<button class="wpwm-tab" role="tab" data-tab="tools-policy"   aria-controls="wpwm-tab-tools-policy"   aria-selected="false"><?php esc_html_e( 'Tools & Policy', 'webmcp-nexus' ); ?></button>
	<button class="wpwm-tab" role="tab" data-tab="rate-limits"    aria-controls="wpwm-tab-rate-limits"    aria-selected="false"><?php esc_html_e( 'Rate Limits', 'webmcp-nexus' ); ?></button>
	<button class="wpwm-tab" role="tab" data-tab="integrations"   aria-controls="wpwm-tab-integrations"   aria-selected="false"><?php esc_html_e( 'Integrations', 'webmcp-nexus' ); ?></button>
	<button class="wpwm-tab" role="tab" data-tab="privacy"        aria-controls="wpwm-tab-privacy"        aria-selected="false"><?php esc_html_e( 'Privacy', 'webmcp-nexus' ); ?></button>
	<button class="wpwm-tab" role="tab" data-tab="advanced"       aria-controls="wpwm-tab-advanced"       aria-selected="false"><?php esc_html_e( 'Advanced', 'webmcp-nexus' ); ?></button>
</div>

<form id="wpwm-settings-form" data-wpwm-settings-form onsubmit="return false;">

<!-- ============ General ============ -->
<div class="wpwm-tabpanel" id="wpwm-tab-general" data-wpwm-tabpanel data-group="wpwm-settings-tabs" data-tab="general" hidden>
	<div class="wpwm-card">
		<div class="wpwm-callout wpwm-callout--info" style="margin-top:0;">
			<p><strong><?php esc_html_e( '📌 General Settings Guide:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Configure how WebMCP tools are exposed across your WordPress pages and optimize how AI models consume your site content.', 'webmcp-nexus' ); ?></p>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-enabled"><?php esc_html_e( 'Enable WebMCP sitewide', 'webmcp-nexus' ); ?></label>
			<label class="wpwm-switch">
				<input type="checkbox" id="wpwebmcp-enabled" name="wpwebmcp_enabled" data-wpwm-setting="wpwebmcp_enabled" <?php checked( $wpwebmcp_enabled ); ?>>
				<span class="wpwm-switch-track"></span>
			</label>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Master on/off switch. When turned on, AI agent manifests and tools are registered across your site. Individual posts and pages can still be customized or excluded.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended: ON', 'webmcp-nexus' ); ?></span>
			</div>
		</div>

		<div class="wpwm-field">
			<label><?php esc_html_e( 'Supported Post Types', 'webmcp-nexus' ); ?></label>
			<p class="wpwm-field-helper" style="margin-bottom:8px;"><?php esc_html_e( 'Select which content types should provide AI agent tools and show the WebMCP editor sidebar meta box:', 'webmcp-nexus' ); ?></p>
			<?php foreach ( $wpwebmcp_public_post_types as $wpwebmcp_pt ) : ?>
				<label style="display:inline-block; margin-right: var(--wpwm-sp-3); margin-bottom: 6px;">
					<input type="checkbox" name="wpwebmcp_custom_post_types[]" value="<?php echo esc_attr( $wpwebmcp_pt ); ?>" data-wpwm-setting="wpwebmcp_custom_post_types" <?php checked( in_array( $wpwebmcp_pt, $wpwebmcp_custom_post_types, true ) ); ?>>
					<strong><?php echo esc_html( ucfirst( $wpwebmcp_pt ) ); ?></strong>
				</label>
			<?php endforeach; ?>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Enables per-post tools (e.g. reading full article summaries, fetching comments) and adds the WebMCP override box to the WordPress block/classic editor for these post types.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended: Select all public content types (post, page, product).', 'webmcp-nexus' ); ?></span>
			</div>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-performance"><?php esc_html_e( 'Performance mode (defer tool registration)', 'webmcp-nexus' ); ?></label>
			<label class="wpwm-switch">
				<input type="checkbox" id="wpwebmcp-performance" name="wpwebmcp_performance_mode" data-wpwm-setting="wpwebmcp_performance_mode" <?php checked( $wpwebmcp_performance_mode ); ?>>
				<span class="wpwm-switch-track"></span>
			</label>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Defers computation of complex tool schemas until an AI agent or browser actually requests them, reducing page load overhead for human visitors.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended: ON for busy websites.', 'webmcp-nexus' ); ?></span>
			</div>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-polyfill"><?php esc_html_e( 'Vendored polyfill (Browser compatibility)', 'webmcp-nexus' ); ?></label>
			<label class="wpwm-switch">
				<input type="checkbox" id="wpwebmcp-polyfill" name="wpwebmcp_polyfill_enabled" data-wpwm-setting="wpwebmcp_polyfill_enabled" <?php checked( $wpwebmcp_polyfill_enabled ); ?>>
				<span class="wpwm-switch-track"></span>
			</label>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Provides a lightweight JavaScript fallback so older browser clients and AI agent extensions without native navigator.modelContext support can interact with WebMCP tools flawlessly.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended: ON', 'webmcp-nexus' ); ?></span>
			</div>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-token-optimize"><?php esc_html_e( 'Token-optimize manifests', 'webmcp-nexus' ); ?></label>
			<label class="wpwm-switch">
				<input type="checkbox" id="wpwebmcp-token-optimize" name="wpwebmcp_token_optimize" data-wpwm-setting="wpwebmcp_token_optimize" <?php checked( $wpwebmcp_token_optimize ); ?>>
				<span class="wpwm-switch-track"></span>
			</label>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Minifies JSON tool schemas by removing redundant comments and non-essential schema hints. This saves AI context window tokens and speeds up AI agent processing.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended: ON', 'webmcp-nexus' ); ?></span>
			</div>
		</div>
	</div>
</div>

<!-- ============ Tools & Policy ============ -->
<div class="wpwm-tabpanel" id="wpwm-tab-tools-policy" data-wpwm-tabpanel data-group="wpwm-settings-tabs" data-tab="tools-policy" hidden>
	<div class="wpwm-card">
		<div class="wpwm-callout wpwm-callout--info" style="margin-top:0;">
			<p><strong><?php esc_html_e( '📌 Tools & Policy Guide:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Manage tool execution safety modes and configure instant email alerts for unexpected execution errors.', 'webmcp-nexus' ); ?></p>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-sandbox"><?php esc_html_e( 'Sandbox mode (Dry-run only)', 'webmcp-nexus' ); ?></label>
			<label class="wpwm-switch">
				<input type="checkbox" id="wpwebmcp-sandbox" name="wpwebmcp_sandbox_mode" data-wpwm-setting="wpwebmcp_sandbox_mode" <?php checked( $wpwebmcp_sandbox_mode ); ?>>
				<span class="wpwm-switch-track"></span>
			</label>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'When enabled, write actions (like form submissions or cart additions) simulate execution without making permanent changes to your database.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended: OFF for live stores/sites; ON only during testing.', 'webmcp-nexus' ); ?></span>
			</div>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-alert-email"><?php esc_html_e( 'Administrator Alert Email', 'webmcp-nexus' ); ?></label>
			<input type="email" id="wpwebmcp-alert-email" name="wpwebmcp_alert_email" value="<?php echo esc_attr( $wpwebmcp_alert_email ); ?>" placeholder="admin@example.com" data-wpwm-setting="wpwebmcp_alert_email">
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'The recipient email address for system alerts when tool errors or rate-limit violations occur.', 'webmcp-nexus' ); ?>
			</div>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-alerts-enabled"><?php esc_html_e( 'Send email alerts on tool failures', 'webmcp-nexus' ); ?></label>
			<label class="wpwm-switch">
				<input type="checkbox" id="wpwebmcp-alerts-enabled" name="wpwebmcp_alerts_enabled" data-wpwm-setting="wpwebmcp_alerts_enabled" <?php checked( $wpwebmcp_alerts_enabled ); ?>>
				<span class="wpwm-switch-track"></span>
			</label>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Sends an automated email notification if an agent repeatedly encounters API errors or rate limits.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended: ON', 'webmcp-nexus' ); ?></span>
			</div>
		</div>
	</div>
</div>

<!-- ============ Rate Limits ============ -->
<div class="wpwm-tabpanel" id="wpwm-tab-rate-limits" data-wpwm-tabpanel data-group="wpwm-settings-tabs" data-tab="rate-limits" hidden>
	<div class="wpwm-card">
		<div class="wpwm-callout wpwm-callout--info" style="margin-top:0;">
			<p><strong><?php esc_html_e( '📌 Rate Limits Guide:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Protect your web server CPU and database from aggressive bots by setting maximum allowable requests per minute and per session.', 'webmcp-nexus' ); ?></p>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-rate-limit-read"><?php esc_html_e( 'Read calls per minute (Per IP)', 'webmcp-nexus' ); ?></label>
			<input type="number" id="wpwebmcp-rate-limit-read" min="1" max="10000" name="wpwebmcp_rate_limit_read" value="<?php echo esc_attr( $wpwebmcp_rate_limit_read ); ?>" data-wpwm-setting="wpwebmcp_rate_limit_read">
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Maximum allowable search, article reading, and stock check requests per IP address in a 60-second window.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended default: 60 calls/minute.', 'webmcp-nexus' ); ?></span>
			</div>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-rate-limit-write"><?php esc_html_e( 'Write calls per minute (Per IP)', 'webmcp-nexus' ); ?></label>
			<input type="number" id="wpwebmcp-rate-limit-write" min="1" max="10000" name="wpwebmcp_rate_limit_write" value="<?php echo esc_attr( $wpwebmcp_rate_limit_write ); ?>" data-wpwm-setting="wpwebmcp_rate_limit_write">
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Maximum state-changing actions (submitting comments, updating carts) permitted per minute.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended default: 20 calls/minute.', 'webmcp-nexus' ); ?></span>
			</div>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-max-calls"><?php esc_html_e( 'Max total calls per session', 'webmcp-nexus' ); ?></label>
			<input type="number" id="wpwebmcp-max-calls" min="1" max="100000" name="wpwebmcp_max_calls_per_session" value="<?php echo esc_attr( $wpwebmcp_max_calls_per_session ); ?>" data-wpwm-setting="wpwebmcp_max_calls_per_session">
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Session ceiling that prevents runaway autonomous agent loops from looping indefinitely on your site.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended default: 200 calls/session.', 'webmcp-nexus' ); ?></span>
			</div>
		</div>
	</div>
</div>

<!-- ============ Integrations ============ -->
<div class="wpwm-tabpanel" id="wpwm-tab-integrations" data-wpwm-tabpanel data-group="wpwm-settings-tabs" data-tab="integrations" hidden>
	<div class="wpwm-card">
		<div class="wpwm-callout wpwm-callout--info" style="margin-top:0;">
			<p><strong><?php esc_html_e( '📌 Integrations & Crawler Directives Guide:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Connect Google Analytics 4 event tracking and control access for specific AI web crawlers (like OpenAI GPTBot, Anthropic ClaudeBot, and PerplexityBot).', 'webmcp-nexus' ); ?></p>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-ga4-enabled"><?php esc_html_e( 'Google Analytics 4 (GA4) Telemetry', 'webmcp-nexus' ); ?></label>
			<label class="wpwm-switch">
				<input type="checkbox" id="wpwebmcp-ga4-enabled" name="wpwebmcp_ga4_enabled" data-wpwm-setting="wpwebmcp_ga4_enabled" <?php checked( $wpwebmcp_ga4_enabled ); ?>>
				<span class="wpwm-switch-track"></span>
			</label>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Automatically triggers custom webmcp_tool_call events in Google Analytics 4 when window.gtag is present, allowing you to see agent activity in GA4 reports.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended: ON if your site uses Google Analytics.', 'webmcp-nexus' ); ?></span>
			</div>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-crawler-directives"><?php esc_html_e( 'AI Crawler Directives (JSON Map)', 'webmcp-nexus' ); ?></label>
			<textarea id="wpwebmcp-crawler-directives" name="wpwebmcp_crawler_directives" rows="5" data-wpwm-setting="wpwebmcp_crawler_directives" placeholder='{"GPTBot":"allow","ClaudeBot":"allow","CCBot":"block"}'><?php echo esc_textarea( wp_json_encode( $wpwebmcp_crawler_directives ) ); ?></textarea>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'How to use:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Map bot signatures to "allow", "block", or "default".', 'webmcp-nexus' ); ?><br>
				<code>{"GPTBot":"allow","ClaudeBot":"allow","PerplexityBot":"allow","CCBot":"block"}</code>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Allows reputable AI search engines while blocking aggressive scrapers.', 'webmcp-nexus' ); ?></span>
			</div>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-custom-crawlers"><?php esc_html_e( 'Custom Crawler Signatures (JSON Array)', 'webmcp-nexus' ); ?></label>
			<textarea id="wpwebmcp-custom-crawlers" name="wpwebmcp_custom_crawlers" rows="4" data-wpwm-setting="wpwebmcp_custom_crawlers" placeholder='[{"label":"MyCustomBot","signature":"CustomAgent/1.0","state":"default"}]'><?php echo esc_textarea( wp_json_encode( $wpwebmcp_custom_crawlers ) ); ?></textarea>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Add up to 5 custom bot user-agents you want to monitor specifically in your Bot Analytics screen.', 'webmcp-nexus' ); ?>
			</div>
		</div>
	</div>
</div>

<!-- ============ Privacy ============ -->
<div class="wpwm-tabpanel" id="wpwm-tab-privacy" data-wpwm-tabpanel data-group="wpwm-settings-tabs" data-tab="privacy" hidden>
	<div class="wpwm-card">
		<div class="wpwm-callout wpwm-callout--info" style="margin-top:0;">
			<p><strong><?php esc_html_e( '📌 Privacy & GDPR Compliance Guide:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Protect user privacy, redact sensitive information, and set automatic data expiration periods.', 'webmcp-nexus' ); ?></p>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-log-privacy-mode"><?php esc_html_e( 'Privacy Mode (Hash IP addresses & Redact Data)', 'webmcp-nexus' ); ?></label>
			<label class="wpwm-switch">
				<input type="checkbox" id="wpwebmcp-log-privacy-mode" name="wpwebmcp_log_privacy_mode" data-wpwm-setting="wpwebmcp_log_privacy_mode" <?php checked( $wpwebmcp_log_privacy_mode ); ?>>
				<span class="wpwm-switch-track"></span>
			</label>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Converts visitor IP addresses into irreversible cryptographic hashes and removes sensitive form values (passwords, payment details) before saving to the audit log.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended: ON for GDPR, CCPA, and privacy compliance.', 'webmcp-nexus' ); ?></span>
			</div>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-log-retention"><?php esc_html_e( 'Tool Audit Log Retention (Days)', 'webmcp-nexus' ); ?></label>
			<input type="number" id="wpwebmcp-log-retention" min="1" max="365" name="wpwebmcp_log_retention_days" value="<?php echo esc_attr( $wpwebmcp_log_retention_days ); ?>" data-wpwm-setting="wpwebmcp_log_retention_days">
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Audit log entries older than this number of days are automatically pruned by WordPress cron to keep your database lean.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended default: 30 days.', 'webmcp-nexus' ); ?></span>
			</div>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-bot-retention"><?php esc_html_e( 'AI Bot Crawler Log Retention (Days)', 'webmcp-nexus' ); ?></label>
			<input type="number" id="wpwebmcp-bot-retention" min="1" max="365" name="wpwebmcp_bot_log_retention_days" value="<?php echo esc_attr( $wpwebmcp_bot_log_retention_days ); ?>" data-wpwm-setting="wpwebmcp_bot_log_retention_days">
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'How long AI bot visit records are kept for historical trend reporting.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended default: 90 days.', 'webmcp-nexus' ); ?></span>
			</div>
		</div>
	</div>
</div>

<!-- ============ Advanced ============ -->
<div class="wpwm-tabpanel" id="wpwm-tab-advanced" data-wpwm-tabpanel data-group="wpwm-settings-tabs" data-tab="advanced" hidden>
	<div class="wpwm-card">
		<div class="wpwm-callout wpwm-callout--info" style="margin-top:0;">
			<p><strong><?php esc_html_e( '📌 Advanced Protocols & Maintenance Guide:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Manage open web discovery protocols, alternative content representations for LLMs, and database cleanup.', 'webmcp-nexus' ); ?></p>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-wellknown"><?php esc_html_e( 'Serve .well-known endpoints', 'webmcp-nexus' ); ?></label>
			<label class="wpwm-switch">
				<input type="checkbox" id="wpwebmcp-wellknown" name="wpwebmcp_wellknown_enabled" data-wpwm-setting="wpwebmcp_wellknown_enabled" <?php checked( $wpwebmcp_wellknown_enabled ); ?>>
				<span class="wpwm-switch-track"></span>
			</label>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Publishes /.well-known/webmcp.json discovery endpoints per standardized AI agent protocol specifications.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended: ON', 'webmcp-nexus' ); ?></span>
			</div>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-markdown"><?php esc_html_e( 'Serve Markdown representations for AI Models', 'webmcp-nexus' ); ?></label>
			<label class="wpwm-switch">
				<input type="checkbox" id="wpwebmcp-markdown" name="wpwebmcp_markdown_enabled" data-wpwm-setting="wpwebmcp_markdown_enabled" <?php checked( $wpwebmcp_markdown_enabled ); ?>>
				<span class="wpwm-switch-track"></span>
			</label>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Enables AI agents requesting text/markdown to receive clean, readable markdown without messy navigation or advertising HTML tags.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended: ON', 'webmcp-nexus' ); ?></span>
			</div>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-llmstxt-mode"><?php esc_html_e( 'llms.txt Discovery Standard Mode', 'webmcp-nexus' ); ?></label>
			<select id="wpwebmcp-llmstxt-mode" name="wpwebmcp_llmstxt_mode" data-wpwm-setting="wpwebmcp_llmstxt_mode">
				<option value="auto" <?php selected( $wpwebmcp_llmstxt_mode, 'auto' ); ?>><?php esc_html_e( 'Auto (Dynamically generated from site structure)', 'webmcp-nexus' ); ?></option>
				<option value="custom" <?php selected( $wpwebmcp_llmstxt_mode, 'custom' ); ?>><?php esc_html_e( 'Custom (Use custom markdown below)', 'webmcp-nexus' ); ?></option>
				<option value="off" <?php selected( $wpwebmcp_llmstxt_mode, 'off' ); ?>><?php esc_html_e( 'Off (Disable /llms.txt endpoint)', 'webmcp-nexus' ); ?></option>
			</select>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'The /llms.txt standard provides a concise roadmap of your site for AI models. Auto mode dynamically lists your key pages, archives, and tools.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended: Auto', 'webmcp-nexus' ); ?></span>
			</div>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-llmstxt-custom"><?php esc_html_e( 'Custom llms.txt Content (If mode is Custom)', 'webmcp-nexus' ); ?></label>
			<textarea id="wpwebmcp-llmstxt-custom" name="wpwebmcp_llmstxt_custom" rows="5" data-wpwm-setting="wpwebmcp_llmstxt_custom" placeholder="<?php esc_attr_e( '# My Site\n> AI-ready WordPress site.\n- [Search](/search): Search articles', 'webmcp-nexus' ); ?>"><?php echo esc_textarea( $wpwebmcp_llmstxt_custom ); ?></textarea>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-db-optimize-cron"><?php esc_html_e( 'Automatic Daily Database Optimization', 'webmcp-nexus' ); ?></label>
			<label class="wpwm-switch">
				<input type="checkbox" id="wpwebmcp-db-optimize-cron" name="wpwebmcp_db_optimize_cron" data-wpwm-setting="wpwebmcp_db_optimize_cron" <?php checked( $wpwebmcp_db_optimize_cron ); ?>>
				<span class="wpwm-switch-track"></span>
			</label>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Runs an automated cleanup during scheduled daily cron to optimize database indexes and free unused space.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Recommended: ON', 'webmcp-nexus' ); ?></span>
			</div>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-cleanup-uninstall"><?php esc_html_e( 'Full Cleanup on Plugin Uninstall', 'webmcp-nexus' ); ?></label>
			<label class="wpwm-switch">
				<input type="checkbox" id="wpwebmcp-cleanup-uninstall" name="wpwebmcp_cleanup_uninstall" data-wpwm-setting="wpwebmcp_cleanup_uninstall" <?php checked( $wpwebmcp_cleanup_uninstall ); ?>>
				<span class="wpwm-switch-track"></span>
			</label>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'If enabled, completely drops all WebMCP custom database tables and settings when you uninstall the plugin from WordPress.', 'webmcp-nexus' ); ?>
				<span class="wpwm-field-rec"><?php esc_html_e( '✓ Caution: Only turn this ON if you plan to completely remove the plugin and all its data forever.', 'webmcp-nexus' ); ?></span>
			</div>
		</div>
	</div>

	<div class="wpwm-card">
		<div class="wpwm-callout wpwm-callout--info" style="margin-top:0;">
			<p><strong><?php esc_html_e( '🔔 Push Notifications (SSE):', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Let AI agents subscribe to a live stream of new content events (new posts, post updates, new comments) over Server-Sent Events. They get notified within ~1 second of the event — no polling.', 'webmcp-nexus' ); ?></p>
		</div>

		<div class="wpwm-field">
			<label for="wpwebmcp-push-enabled"><?php esc_html_e( 'Enable Push Server', 'webmcp-nexus' ); ?></label>
			<label class="wpwm-switch">
				<input type="checkbox" id="wpwebmcp-push-enabled" name="wpwebmcp_push_enabled" data-wpwm-setting="wpwebmcp_push_enabled" <?php checked( $wpwebmcp_push_enabled ); ?>>
				<span class="wpwm-switch-track"></span>
			</label>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Exposes the SSE subscribe endpoint at /wp-json/wpwebmcp/v1/push/subscribe. Disable to stop all push notifications immediately.', 'webmcp-nexus' ); ?>
			</div>
		</div>

		<div class="wpwm-field">
			<label><?php esc_html_e( 'Push Token (gates the SSE endpoint)', 'webmcp-nexus' ); ?></label>
			<code id="wpwebmcp-push-token-display" style="display:block; padding:8px 10px; background:#f6f7f7; border:1px solid #dcdcde; border-radius:4px; word-break:break-all; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size:12px;"><?php echo esc_html( '' !== $wpwebmcp_push_token ? $wpwebmcp_push_token : '(will be generated on first request)' ); ?></code>
			<div class="wpwm-field-guide" style="display:flex; gap:8px; align-items:center; margin-top:6px;">
				<button type="button" class="button button-secondary" id="wpwebmcp-push-copy-token"><?php esc_html_e( 'Copy Token', 'webmcp-nexus' ); ?></button>
				<button type="button" class="button button-secondary" id="wpwebmcp-push-rotate-token"><?php esc_html_e( 'Rotate Token (disconnects all subscribers)', 'webmcp-nexus' ); ?></button>
				<span id="wpwebmcp-push-token-status" class="wpwm-field-rec" style="margin-left:8px;"></span>
			</div>
		</div>

		<div class="wpwm-field">
			<label><?php esc_html_e( 'Example subscribe URL', 'webmcp-nexus' ); ?></label>
			<code style="display:block; padding:8px 10px; background:#f6f7f7; border:1px solid #dcdcde; border-radius:4px; word-break:break-all; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size:12px;"><?php echo esc_html( $wpwebmcp_rest_url_push . '?channel=new_post&token=' . $wpwebmcp_push_token ); ?></code>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'Channels:', 'webmcp-nexus' ); ?></strong> <code>new_post</code>, <code>new_post_&lt;type&gt;</code> (e.g. <code>new_post_post</code>), <code>new_post_tax_&lt;tax&gt;_&lt;id&gt;</code>, <code>post_updated</code>, <code>new_comment</code>
			</div>
		</div>

		<div class="wpwm-field">
			<label><?php esc_html_e( 'Live status', 'webmcp-nexus' ); ?></label>
			<p class="wpwm-field-helper">
				<?php
				printf(
					/* translators: %1$d: Active subscriber count, %2$d: Max subscribers, %3$d: Heartbeat in seconds, %4$d: Connection TTL in seconds */
					esc_html__( '%1$d active subscriber(s) (max %2$d). Heartbeat every %3$d s, connection TTL %4$d s.', 'webmcp-nexus' ),
					(int) ( isset( $wpwebmcp_push_status['subscribers'] ) ? $wpwebmcp_push_status['subscribers'] : 0 ),
					(int) $wpwebmcp_push_max_subs,
					(int) $wpwebmcp_push_heartbeat_s,
					(int) $wpwebmcp_push_ttl_s
				);
				?>
			</p>
		</div>

		<?php
		// M0a-debug: server-rendered diagnostics. Visible to admins only
		// (settings page itself requires manage_options). Shows what the
		// DB actually holds — the JS copy button uses textContent.trim()
		// of this exact value, so what you see here is what gets sent.
		$wpwebmcp_db_token_len     = strlen( $wpwebmcp_push_token );
		$wpwebmcp_db_token_sha     = '' !== $wpwebmcp_push_token ? substr( hash( 'sha256', $wpwebmcp_push_token ), 0, 12 ) : '';
		$wpwebmcp_db_token_preview = '' !== $wpwebmcp_push_token
			? substr( $wpwebmcp_push_token, 0, 4 ) . str_repeat( '*', max( 0, $wpwebmcp_db_token_len - 8 ) ) . substr( $wpwebmcp_push_token, -4 )
			: '(empty)';
		?>
		<div class="wpwm-field" style="margin-top:14px; padding:10px 12px; background:#fff8e1; border:1px solid #f0e4b0; border-radius:4px;">
			<label style="color:#8a6d00; font-weight:600;">
				🛠 <?php esc_html_e( 'Push Server Diagnostics (M0a-debug)', 'webmcp-nexus' ); ?>
			</label>
			<p class="wpwm-field-helper" style="font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size:12px; color:#444;">
				<?php
				printf(
					/* translators: %1$d: Stored token length, %2$s: Redacted preview, %3$s: Short sha256 */
					esc_html__( 'DB token length: %1$d chars. Preview: %2$s. sha256[0..12]: %3$s', 'webmcp-nexus' ),
					(int) $wpwebmcp_db_token_len,
					esc_html( $wpwebmcp_db_token_preview ),
					esc_html( $wpwebmcp_db_token_sha )
				);
				?>
				<br>
				<?php esc_html_e( 'Expected: 48 chars from wp_generate_password(48, false). If you see a different length, the option was written by a non-standard path and the rotate button may not have fired JS in your session.', 'webmcp-nexus' ); ?>
			</p>
			<details style="margin-top:8px;">
				<summary style="cursor:pointer; color:#8a6d00; font-weight:600;">
					<?php esc_html_e( 'Force-set / Test roundtrip', 'webmcp-nexus' ); ?>
				</summary>
				<div style="margin-top:8px; padding:8px; background:#fff; border:1px solid #e0d090; border-radius:3px;">
					<p style="margin:0 0 6px; font-size:12px;">
						<?php esc_html_e( 'If length above is NOT 48, paste a fresh token here (alphanumeric, 8..128 chars) and click Set Token. The page will reload and the new value will be saved to the option.', 'webmcp-nexus' ); ?>
					</p>
					<button type="button" class="button button-secondary" id="wpwebmcp-push-set-token-default">
						<?php esc_html_e( 'Set to a fresh 48-char token (no input required)', 'webmcp-nexus' ); ?>
					</button>
					<input type="text" id="wpwebmcp-push-set-token-input" placeholder="paste custom alphanumeric token (8..128 chars)" style="width:380px; margin-left:8px; font-family: ui-monospace, monospace; font-size:11px;">
					<button type="button" class="button button-secondary" id="wpwebmcp-push-set-token-custom">
						<?php esc_html_e( 'Set custom', 'webmcp-nexus' ); ?>
					</button>
					<span id="wpwebmcp-push-set-token-status" style="margin-left:8px; font-size:12px;"></span>
				</div>
			</details>
		</div>
	</div>

	<?php
	// M0b: Aggregator card. Renders the configured child sites and exposes
	// a small test-form for the local site. Save / test are JS-driven.
	$wpwebmcp_agg_enabled = (bool) get_option( 'wpwebmcp_aggregator_enabled', true );
	$wpwebmcp_agg_sites   = class_exists( 'WP_WebMCP_Aggregator' ) ? WP_WebMCP_Aggregator::get_sites() : array();
	$wpwebmcp_is_ms       = is_multisite();
	?>
	<div class="wpwm-card" style="margin-top:14px;">
		<div class="wpwm-callout wpwm-callout--info" style="margin-top:0;">
			<p>
				<strong><?php esc_html_e( '🌐 Multi-site Aggregator (M0b):', 'webmcp-nexus' ); ?></strong>
				<?php esc_html_e( 'Expose a single MCP endpoint that delegates tool calls to per-site executors. Three transports: local, multisite (switch_to_blog), and remote (cross-network REST with bearer token).', 'webmcp-nexus' ); ?>
			</p>
		</div>

		<div class="wpwm-field">
			<label class="wpwm-toggle">
				<input type="checkbox" id="wpwebmcp-aggregator-enabled" <?php checked( $wpwebmcp_agg_enabled, true ); ?>>
				<span class="wpwm-switch-track"></span>
				<?php esc_html_e( 'Enable Aggregator endpoint', 'webmcp-nexus' ); ?>
			</label>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong> <?php esc_html_e( 'Exposes POST /wp-json/wpwebmcp/v1/aggregator/call. Disable to lock the endpoint.', 'webmcp-nexus' ); ?>
			</div>
		</div>

		<div class="wpwm-field" style="margin-top:10px;">
			<label><?php esc_html_e( 'Configured child sites', 'webmcp-nexus' ); ?></label>
			<div id="wpwebmcp-aggregator-sites">
				<?php if ( empty( $wpwebmcp_agg_sites ) ) : ?>
					<p class="wpwm-field-helper"><?php esc_html_e( 'No child sites yet. Add one below.', 'webmcp-nexus' ); ?></p>
				<?php else : ?>
					<table class="widefat striped" style="margin-top:6px;">
						<thead>
							<tr>
								<th><?php esc_html_e( 'ID', 'webmcp-nexus' ); ?></th>
								<th><?php esc_html_e( 'Label', 'webmcp-nexus' ); ?></th>
								<th><?php esc_html_e( 'Mode', 'webmcp-nexus' ); ?></th>
								<th><?php esc_html_e( 'Target', 'webmcp-nexus' ); ?></th>
								<th><?php esc_html_e( 'Auth', 'webmcp-nexus' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $wpwebmcp_agg_sites as $wpwebmcp_row ) :
								$mode = (string) $wpwebmcp_row['mode'];
								$wpwebmcp_target = '';
								if ( 'local' === $mode ) {
									$wpwebmcp_target = '—';
								} elseif ( 'multisite' === $mode ) {
									$wpwebmcp_target = 'site_id=' . (int) ( $wpwebmcp_row['site_id'] ?? 0 );
								} elseif ( 'remote' === $mode ) {
									$wpwebmcp_target = (string) ( $wpwebmcp_row['url'] ?? '' );
								}
								$wpwebmcp_auth  = ( 'remote' === $mode && ! empty( $wpwebmcp_row['auth_token'] ) ) ? '✓ token set' : ( 'remote' === $mode ? '⚠ no token' : 'n/a' );
								?>
								<tr>
									<td><code><?php echo esc_html( (string) ( $wpwebmcp_row['id'] ?? '' ) ); ?></code></td>
									<td><?php echo esc_html( (string) ( $wpwebmcp_row['label'] ?? '' ) ); ?></td>
									<td><code><?php echo esc_html( $mode ); ?></code></td>
									<td style="word-break:break-all;"><?php echo esc_html( $wpwebmcp_target ); ?></td>
									<td><?php echo esc_html( $wpwebmcp_auth ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			</div>
			<div class="wpwm-field-guide">
				<strong><?php esc_html_e( 'What it does:', 'webmcp-nexus' ); ?></strong>
				<?php esc_html_e( 'Each site has an id (used in the API call), a label, a transport mode, and a target (site_id for multisite, base URL for remote). Remote sites need a bearer token (X-WebMCP-Auth) that matches the remote site\'s aggregator auth.', 'webmcp-nexus' ); ?>
			</div>
		</div>

		<details style="margin-top:8px;">
			<summary style="cursor:pointer; color:#2271b1; font-weight:600;"><?php esc_html_e( 'Add / remove child site', 'webmcp-nexus' ); ?></summary>
			<div style="margin-top:8px; padding:8px; background:#fff; border:1px solid #ddd; border-radius:3px;">
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="agg-id"><?php esc_html_e( 'Site id', 'webmcp-nexus' ); ?></label></th>
						<td><input type="text" id="agg-id" placeholder="child-1" class="regular-text"></td>
					</tr>
					<tr>
						<th scope="row"><label for="agg-label"><?php esc_html_e( 'Label', 'webmcp-nexus' ); ?></label></th>
						<td><input type="text" id="agg-label" placeholder="Marketing sub-site" class="regular-text"></td>
					</tr>
					<tr>
						<th scope="row"><label for="agg-mode"><?php esc_html_e( 'Mode', 'webmcp-nexus' ); ?></label></th>
						<td>
							<select id="agg-mode">
								<option value="local">local (this site)</option>
								<?php if ( $wpwebmcp_is_ms ) : ?><option value="multisite">multisite (switch_to_blog)</option><?php endif; ?>
								<option value="remote">remote (cross-network REST)</option>
							</select>
						</td>
					</tr>
					<tr id="agg-row-siteid" style="display:none;">
						<th scope="row"><label for="agg-site-id"><?php esc_html_e( 'Site id (int)', 'webmcp-nexus' ); ?></label></th>
						<td><input type="number" id="agg-site-id" min="1" class="small-text"></td>
					</tr>
					<tr id="agg-row-url" style="display:none;">
						<th scope="row"><label for="agg-url"><?php esc_html_e( 'Base URL', 'webmcp-nexus' ); ?></label></th>
						<td><input type="url" id="agg-url" placeholder="https://other.example.com" class="regular-text"></td>
					</tr>
					<tr id="agg-row-token" style="display:none;">
						<th scope="row"><label for="agg-token"><?php esc_html_e( 'Bearer token', 'webmcp-nexus' ); ?></label></th>
						<td><input type="text" id="agg-token" placeholder="X-WebMCP-Auth value" class="regular-text" autocomplete="off"></td>
					</tr>
					<tr>
						<th scope="row"></th>
						<td>
							<button type="button" class="button button-primary" id="wpwebmcp-aggregator-add"><?php esc_html_e( 'Add site', 'webmcp-nexus' ); ?></button>
							<button type="button" class="button" id="wpwebmcp-aggregator-remove"><?php esc_html_e( 'Remove selected', 'webmcp-nexus' ); ?></button>
							<button type="button" class="button button-secondary" id="wpwebmcp-aggregator-save"><?php esc_html_e( 'Save registry', 'webmcp-nexus' ); ?></button>
							<span id="wpwebmcp-aggregator-status" style="margin-left:8px; font-size:12px;"></span>
						</td>
					</tr>
				</table>
			</div>
		</details>

		<details style="margin-top:8px;">
			<summary style="cursor:pointer; color:#2271b1; font-weight:600;"><?php esc_html_e( 'Live test (M0b aggregator)', 'webmcp-nexus' ); ?></summary>
			<div style="margin-top:8px; padding:8px; background:#fff; border:1px solid #ddd; border-radius:3px;">
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="agg-test-site"><?php esc_html_e( 'Site', 'webmcp-nexus' ); ?></label></th>
						<td>
							<select id="agg-test-site">
								<?php foreach ( $wpwebmcp_agg_sites as $wpwebmcp_row ) : ?>
									<option value="<?php echo esc_attr( (string) $wpwebmcp_row['id'] ); ?>"><?php echo esc_html( (string) $wpwebmcp_row['id'] . ' — ' . (string) ( $wpwebmcp_row['label'] ?? '' ) ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="agg-test-tool"><?php esc_html_e( 'Tool', 'webmcp-nexus' ); ?></label></th>
						<td><input type="text" id="agg-test-tool" value="getSiteInfo" class="regular-text"></td>
					</tr>
					<tr>
						<th scope="row"><label for="agg-test-params"><?php esc_html_e( 'Params (JSON)', 'webmcp-nexus' ); ?></label></th>
						<td><textarea id="agg-test-params" rows="3" class="large-text code" placeholder="{}">{}</textarea></td>
					</tr>
					<tr>
						<th scope="row"></th>
						<td>
							<button type="button" class="button button-primary" id="wpwebmcp-aggregator-test"><?php esc_html_e( 'Run aggregator call', 'webmcp-nexus' ); ?></button>
							<span id="wpwebmcp-aggregator-test-status" style="margin-left:8px; font-size:12px;"></span>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Response', 'webmcp-nexus' ); ?></th>
						<td><pre id="wpwebmcp-aggregator-test-result" style="background:#f6f7f7; padding:8px; max-height:300px; overflow:auto; font-size:11px; border:1px solid #ddd;"></pre></td>
					</tr>
				</table>
			</div>
		</details>
	</div>
</div>

<div class="wpwm-save-bar" data-wpwm-save-bar>
	<button type="button" class="button button-primary" data-wpwm-action="save-settings"><?php esc_html_e( 'Save changes', 'webmcp-nexus' ); ?></button>
	<span class="wpwm-save-status" data-wpwm-save-status></span>
</div>
</form>