<?php
/**
 * Tool Access screen — Doc §5.8 #7.
 *
 * Step 5 shell: roles × (read / write) matrix table skeleton. Save
 * logic arrives in Step 10 (Access_Control).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- Educational Guide Card -->
<div class="wpwm-guide-card wpwm-guide-card--featured">
	<div class="wpwm-guide-header">
		<span class="wpwm-guide-icon"><span class="dashicons dashicons-groups" aria-hidden="true"></span></span>
		<div>
			<h2 class="wpwm-guide-title"><?php esc_html_e( 'Role-Based Tool Permissions Guide', 'webmcp-nexus' ); ?></h2>
			<p class="wpwm-field-helper" style="margin:2px 0 0;"><?php esc_html_e( 'Control which user roles and AI agents can execute Read (safe queries) versus Write (state-changing) tools.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
	<p class="wpwm-guide-desc">
		<?php esc_html_e( 'Security is built into WebMCP Nexus at the protocol level. Tools are divided into two fundamental permission levels: Read tools (querying public info) and Write tools (actions that create or alter data).', 'webmcp-nexus' ); ?>
	</p>
	<div class="wpwm-guide-grid">
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-book" style="color:var(--wpwm-accent);"></span> <?php esc_html_e( 'Read Tools (Safe Queries)', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Searching content, checking stock, reading articles, and viewing event dates. Safe for all roles and public AI search bots.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-edit" style="color:var(--wpwm-warning);"></span> <?php esc_html_e( 'Write Tools (State-Changing)', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Submitting comments, adding items to cart, or triggering webhooks. Recommended for authenticated users only.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="dashicons dashicons-shield" style="color:var(--wpwm-success);"></span> <?php esc_html_e( 'Anonymous Protection', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Anonymous guests and web crawlers are permanently blocked from write operations to keep your site secure.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
</div>

<div class="wpwm-row">
	<div class="wpwm-col">
		<table class="wpwm-table wpwm-access-matrix" data-wpwm-access-matrix>
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Role', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Read tools', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Write tools', 'webmcp-nexus' ); ?></th>
				</tr>
			</thead>
			<tbody data-wpwm-access-body>
				<?php
				$wpwebmcp_roles = array(
					'administrator' => __( 'Administrator', 'webmcp-nexus' ),
					'editor'        => __( 'Editor', 'webmcp-nexus' ),
					'author'        => __( 'Author', 'webmcp-nexus' ),
					'contributor'   => __( 'Contributor', 'webmcp-nexus' ),
					'subscriber'    => __( 'Subscriber', 'webmcp-nexus' ),
					'anonymous'     => __( 'Anonymous', 'webmcp-nexus' ),
				);
				$wpwebmcp_matrix = (array) get_option( 'wpwebmcp_role_access', array() );
				foreach ( $wpwebmcp_roles as $wpwebmcp_role_key => $wpwebmcp_role_label ) :
					$wpwebmcp_can_read  = ! isset( $wpwebmcp_matrix[ $wpwebmcp_role_key ] ) || in_array( 'read', (array) ( $wpwebmcp_matrix[ $wpwebmcp_role_key ] ?? array( 'read' ) ), true );
					$wpwebmcp_can_write = isset( $wpwebmcp_matrix[ $wpwebmcp_role_key ] ) && in_array( 'write', (array) $wpwebmcp_matrix[ $wpwebmcp_role_key ], true );
					?>
					<tr data-role="<?php echo esc_attr( $wpwebmcp_role_key ); ?>">
						<th scope="row"><?php echo esc_html( $wpwebmcp_role_label ); ?></th>
						<td>
							<label class="wpwm-switch">
								<input type="checkbox" data-wpwm-toggle="access_<?php echo esc_attr( $wpwebmcp_role_key ); ?>_read" <?php checked( $wpwebmcp_can_read ); ?> <?php disabled( 'anonymous' === $wpwebmcp_role_key ); ?>>
								<span class="wpwm-switch-track"></span>
							</label>
						</td>
						<td>
							<label class="wpwm-switch">
								<input type="checkbox" data-wpwm-toggle="access_<?php echo esc_attr( $wpwebmcp_role_key ); ?>_write" <?php checked( $wpwebmcp_can_write ); ?><?php if ( 'anonymous' === $wpwebmcp_role_key ) echo ' disabled title="' . esc_attr__( 'Anonymous viewers can never execute write tools.', 'webmcp-nexus' ) . '"'; ?>>
								<span class="wpwm-switch-track"></span>
							</label>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<p class="wpwm-actions-row">
			<button class="button button-primary" data-wpwm-action="save-access"><?php esc_html_e( 'Save', 'webmcp-nexus' ); ?></button>
		</p>
	</div>
</div>