<?php
/**
 * Tool Builder screen — Doc §5.8 #3 + §7.1.
 *
 * Custom tool management interface with table view and interactive
 * creation/edit modal.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$wpwebmcp_total_tools = class_exists( 'WP_WebMCP_Tool_Repository' ) ? WP_WebMCP_Tool_Repository::count( 'active' ) : 0;
?>
<!-- Educational Guide Card -->
<div class="wpwm-guide-card wpwm-guide-card--featured">
	<div class="wpwm-guide-header">
		<span class="wpwm-guide-icon"><span class="dashicons dashicons-admin-tools" aria-hidden="true"></span></span>
		<div>
			<h2 class="wpwm-guide-title"><?php esc_html_e( 'How Custom WebMCP Tools Work — Beginner’s Guide', 'webmcp-nexus' ); ?></h2>
			<p class="wpwm-field-helper" style="margin:2px 0 0;"><?php esc_html_e( 'Extend your WordPress site with custom capabilities for AI assistants without writing complex code.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
	<p class="wpwm-guide-desc">
		<?php esc_html_e( 'While WebMCP Nexus includes over 40 built-in tools automatically, you can create custom tools here to let AI models perform unique actions on your site — like navigating to special checkout funnels, querying private documentation, or triggering custom plugin hooks.', 'webmcp-nexus' ); ?>
	</p>
	<div class="wpwm-guide-grid">
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="wpwm-step-badge">1</span> <?php esc_html_e( 'Choose a Name & Action', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Give your tool a clear name like "findStoreLocation" and pick what it does (e.g. redirect to URL, search, or call a REST endpoint).', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="wpwm-step-badge">2</span> <?php esc_html_e( 'Write the AI Description', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Write 1-2 plain English sentences. AI models read this description to understand exactly when and how to invoke the tool.', 'webmcp-nexus' ); ?></p>
		</div>
		<div class="wpwm-guide-item">
			<p class="wpwm-guide-item-title"><span class="wpwm-step-badge">3</span> <?php esc_html_e( 'Instant Manifest Publishing', 'webmcp-nexus' ); ?></p>
			<p class="wpwm-guide-item-text"><?php esc_html_e( 'Once saved and set to Active, your tool is immediately exposed in the /llms.txt and WebMCP manifest for all AI agents.', 'webmcp-nexus' ); ?></p>
		</div>
	</div>
</div>

<div class="wpwm-row">
	<div class="wpwm-col wpwm-col--wide">
		<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--wpwm-sp-3); flex-wrap: wrap; gap: 8px;">
			<h2 class="wpwm-h2" style="margin: 0;"><?php esc_html_e( 'Your Custom WebMCP Tools', 'webmcp-nexus' ); ?></h2>
			<button type="button" class="button button-primary" data-wpwm-open-modal="#wpwm-tool-modal" data-wpwm-action="new-tool">
				<span class="dashicons dashicons-plus-alt2" style="vertical-align: text-bottom;" aria-hidden="true"></span>
				<?php esc_html_e( 'Add Custom Tool', 'webmcp-nexus' ); ?>
			</button>
		</div>

		<div class="wpwm-empty" data-wpwm-empty-tools <?php if ( $wpwebmcp_total_tools > 0 ) echo 'style="display:none;"'; ?>>
			<span class="dashicons dashicons-admin-generic" aria-hidden="true"></span>
			<p><?php esc_html_e( 'No custom tools created yet. Click below or choose a template to create your first one!', 'webmcp-nexus' ); ?></p>
			<button type="button" class="button button-primary" data-wpwm-open-modal="#wpwm-tool-modal" data-wpwm-action="new-tool"><?php esc_html_e( 'Create Your First Tool', 'webmcp-nexus' ); ?></button>
		</div>

		<table class="wpwm-table" data-wpwm-tools-table <?php if ( $wpwebmcp_total_tools <= 0 ) echo 'style="display:none;"'; ?>>
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Tool Name', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Type', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Scope', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Action', 'webmcp-nexus' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Status', 'webmcp-nexus' ); ?></th>
					<th scope="col" class="wpwm-col-actions"><?php esc_html_e( 'Actions', 'webmcp-nexus' ); ?></th>
				</tr>
			</thead>
			<tbody data-wpwm-tools-body>
				<tr><td colspan="6"><div class="wpwm-skel"></div></td></tr>
			</tbody>
		</table>
	</div>
</div>

<div id="wpwm-tool-modal" class="wpwm-modal" role="dialog" aria-modal="true" aria-labelledby="wpwm-tool-modal-title" aria-hidden="true">
	<div class="wpwm-modal-dialog" style="max-width: 660px; max-height: 90vh; overflow-y: auto;">
		<h2 id="wpwm-tool-modal-title" class="wpwm-modal-title"><?php esc_html_e( 'Custom Tool Editor', 'webmcp-nexus' ); ?></h2>
		
		<div class="wpwm-callout wpwm-callout--tip" style="margin-top:0;">
			<p><strong><?php esc_html_e( '💡 Quick Templates — Click to auto-fill the form:', 'webmcp-nexus' ); ?></strong></p>
			<div class="wpwm-template-chips">
				<button type="button" class="wpwm-template-btn" data-wpwm-preset="search"><span class="dashicons dashicons-search"></span> <?php esc_html_e( 'Custom Search Tool', 'webmcp-nexus' ); ?></button>
				<button type="button" class="wpwm-template-btn" data-wpwm-preset="navigate"><span class="dashicons dashicons-admin-links"></span> <?php esc_html_e( 'Page Navigation Tool', 'webmcp-nexus' ); ?></button>
				<button type="button" class="wpwm-template-btn" data-wpwm-preset="hook"><span class="dashicons dashicons-admin-plugins"></span> <?php esc_html_e( 'PHP Action Hook', 'webmcp-nexus' ); ?></button>
			</div>
		</div>

		<form data-wpwm-tool-form>
			<input type="hidden" name="tool_id" value="">

			<div class="wpwm-form-group" style="margin-bottom: var(--wpwm-sp-3);">
				<label for="wpwm-tool-name" class="wpwm-label"><strong><?php esc_html_e( 'Tool Name (camelCase format)', 'webmcp-nexus' ); ?></strong></label>
				<input type="text" id="wpwm-tool-name" name="tool_name" class="wpwm-input-wide" placeholder="e.g. findStoreLocation" required pattern="[A-Za-z0-9_]+" style="width: 100%;">
				<p class="wpwm-field-helper"><?php esc_html_e( 'Unique identifier with no spaces. Example: searchFaqArticles, getSpecialOffers, bookAppointment.', 'webmcp-nexus' ); ?></p>
			</div>

			<div class="wpwm-form-group" style="margin-bottom: var(--wpwm-sp-3);">
				<label for="wpwm-tool-desc" class="wpwm-label"><strong><?php esc_html_e( 'Description (For AI Model Understanding, ≥20 chars)', 'webmcp-nexus' ); ?></strong></label>
				<textarea id="wpwm-tool-desc" name="tool_description" class="wpwm-input-wide" rows="2" placeholder="<?php esc_attr_e( 'Search frequently asked questions and return matching help center answers...', 'webmcp-nexus' ); ?>" required minlength="20" style="width: 100%;"></textarea>
				<p class="wpwm-field-helper"><?php esc_html_e( 'Be clear and descriptive. The AI reads this exact text to know when this tool is useful.', 'webmcp-nexus' ); ?></p>
			</div>

			<div class="wpwm-row" style="margin-bottom: var(--wpwm-sp-3);">
				<div class="wpwm-col">
					<label for="wpwm-tool-type" class="wpwm-label"><strong><?php esc_html_e( 'Tool Type', 'webmcp-nexus' ); ?></strong></label>
					<select id="wpwm-tool-type" name="tool_type" class="wpwm-input-wide" style="width: 100%;">
						<option value="read"><?php esc_html_e( 'Read (Safe / Querying info)', 'webmcp-nexus' ); ?></option>
						<option value="write"><?php esc_html_e( 'Write (State-changing / Actions)', 'webmcp-nexus' ); ?></option>
					</select>
					<p class="wpwm-field-helper"><?php esc_html_e( 'Read tools are accessible to public AI search crawlers.', 'webmcp-nexus' ); ?></p>
				</div>
				<div class="wpwm-col">
					<label for="wpwm-tool-scope" class="wpwm-label"><strong><?php esc_html_e( 'Where Visible (Scope)', 'webmcp-nexus' ); ?></strong></label>
					<select id="wpwm-tool-scope" name="tool_scope" class="wpwm-input-wide" style="width: 100%;">
						<option value="all"><?php esc_html_e( 'All Pages (Global Sitewide)', 'webmcp-nexus' ); ?></option>
						<option value="homepage"><?php esc_html_e( 'Homepage Only', 'webmcp-nexus' ); ?></option>
						<option value="single"><?php esc_html_e( 'Single Posts / Pages Only', 'webmcp-nexus' ); ?></option>
						<option value="archive"><?php esc_html_e( 'Category / Tag Archives Only', 'webmcp-nexus' ); ?></option>
						<option value="woo"><?php esc_html_e( 'WooCommerce Store Pages Only', 'webmcp-nexus' ); ?></option>
					</select>
				</div>
			</div>

			<div class="wpwm-row" style="margin-bottom: var(--wpwm-sp-3);">
				<div class="wpwm-col">
					<label for="wpwm-action-type" class="wpwm-label"><strong><?php esc_html_e( 'Execution Action Type', 'webmcp-nexus' ); ?></strong></label>
					<select id="wpwm-action-type" name="action_type" class="wpwm-input-wide" style="width: 100%;">
						<option value="navigate"><?php esc_html_e( 'Navigate (Browser URL redirect)', 'webmcp-nexus' ); ?></option>
						<option value="search"><?php esc_html_e( 'Search (Run search query)', 'webmcp-nexus' ); ?></option>
						<option value="rest"><?php esc_html_e( 'REST API (Forward to endpoint)', 'webmcp-nexus' ); ?></option>
						<option value="hook"><?php esc_html_e( 'Action Hook (Trigger PHP do_action)', 'webmcp-nexus' ); ?></option>
					</select>
				</div>
				<div class="wpwm-col">
					<label for="wpwm-action-val" class="wpwm-label"><strong><?php esc_html_e( 'Action Target / Value', 'webmcp-nexus' ); ?></strong></label>
					<input type="text" id="wpwm-action-val" name="action_value" class="wpwm-input-wide" placeholder="/contact or my_custom_hook" style="width: 100%;">
					<p class="wpwm-field-helper"><?php esc_html_e( 'URL path (e.g. /pricing) or PHP action hook name.', 'webmcp-nexus' ); ?></p>
				</div>
			</div>

			<div class="wpwm-form-group" style="margin-bottom: var(--wpwm-sp-3);">
				<label for="wpwm-tool-params" class="wpwm-label"><strong><?php esc_html_e( 'Input Parameters Schema (JSON Format)', 'webmcp-nexus' ); ?></strong></label>
				<textarea id="wpwm-tool-params" name="parameters" class="wpwm-input-wide" rows="4" placeholder='{"type":"object","properties":{"query":{"type":"string","description":"Search query or topic"}},"required":["query"]}' style="width: 100%; font-family: Consolas, Monaco, monospace; font-size: 12px;"></textarea>
				<p class="wpwm-field-helper"><?php esc_html_e( 'Leave empty if your tool requires no parameters, or define properties like query, limit, or ID.', 'webmcp-nexus' ); ?></p>
			</div>

			<div class="wpwm-form-group" style="margin-bottom: var(--wpwm-sp-3);">
				<label for="wpwm-tool-status" class="wpwm-label"><strong><?php esc_html_e( 'Tool Status', 'webmcp-nexus' ); ?></strong></label>
				<select id="wpwm-tool-status" name="status" class="wpwm-input-wide" style="width: 100%;">
					<option value="active"><?php esc_html_e( 'Active (Published live to AI agents)', 'webmcp-nexus' ); ?></option>
					<option value="sandbox"><?php esc_html_e( 'Sandbox (Visible only to logged-in Admins for testing)', 'webmcp-nexus' ); ?></option>
					<option value="disabled"><?php esc_html_e( 'Disabled (Hidden from agents)', 'webmcp-nexus' ); ?></option>
				</select>
			</div>

			<div class="wpwm-modal-actions" style="display: flex; justify-content: flex-end; gap: 8px; margin-top: var(--wpwm-sp-3);">
				<button type="button" class="button" data-wpwm-close-modal><?php esc_html_e( 'Cancel', 'webmcp-nexus' ); ?></button>
				<button type="submit" class="button button-primary" data-wpwm-save-tool><?php esc_html_e( 'Save Custom Tool', 'webmcp-nexus' ); ?></button>
			</div>
		</form>
	</div>
</div>