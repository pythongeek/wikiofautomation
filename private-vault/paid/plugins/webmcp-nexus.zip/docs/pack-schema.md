# wp-webmcp-pack.json — Pack Manifest Schema

A `wp-webmcp-pack.json` file describes a vertical tool pack for WebMCP Nexus.
Packs live under `wp-content/wp-webmcp-packs/<slug>/` (auto-discovered by the
SDK on every request) or, when bundled with the plugin, under
`plugins/wp-webmcp/packs/<slug>/` (auto-seeded into the user directory on
plugin activation).

The manifest is parsed by `WP_WebMCP_Pack_Manifest::parse()` and validated
against the schema below. Parse errors block installation.

## Top-level object

| Field                     | Type            | Required | Notes                                                       |
|---------------------------|-----------------|----------|-------------------------------------------------------------|
| `name`                    | string          | yes      | Human-readable pack name (e.g. "Recipes").                  |
| `slug`                    | string          | yes      | URL-safe identifier (`[a-z0-9-]{1,63}`). Matches folder.    |
| `version`                 | string          | yes      | Semver-ish. Used for upgrade detection.                     |
| `author`                  | string          | yes      | Author / vendor name.                                      |
| `license`                 | string          | yes      | SPDX-style identifier (e.g. `GPL-2.0-or-later`).            |
| `description`             | string          | no       | One-line summary. Shown in marketplace UI.                  |
| `min_wp_webmcp_version`   | string          | no       | Lower-bound semver. Default `0.0.0`.                       |
| `free`                    | bool            | no       | Default `true`. `false` will gate on license (A6b).         |
| `seed_data`               | bool            | no       | If `true`, the bootstrap will seed example content.        |
| `post_types`              | string[]        | no       | CPT slugs the pack registers.                              |
| `taxonomies`              | string[]        | no       | Taxonomy slugs the pack registers.                         |
| `tools`                   | array           | yes      | List of tool definitions (1+ items). See below.             |
| `entry`                   | string          | yes      | PHP file path relative to pack root (default `bootstrap.php`). |

## tools[] — each tool definition

| Field         | Type     | Required | Notes                                                                                  |
|---------------|----------|----------|----------------------------------------------------------------------------------------|
| `key`         | string   | yes      | Snake_case identifier used inside the pack (e.g. `search_recipes`).                    |
| `name`        | string   | no       | Public tool name exposed to agents (default = `key`).                                  |
| `description` | string   | yes      | One-sentence description surfaced to agents.                                            |
| `parameters`  | object   | no       | JSON Schema describing the tool's input parameters.                                    |

The tool's runtime `action_type` is forced to `hook` and `action_value` becomes
`<slug>::<key>` automatically — pack authors don't set those.

## Authoring a pack

1. Create a folder `wp-content/wp-webmcp-packs/<slug>/`.
2. Drop a `wp-webmcp-pack.json` matching this schema.
3. Add a `bootstrap.php` (or whatever `entry` points to) that exposes:
   - `WP_WebMCP_Pack_<StudlySlug>::install( $manifest )` — registers CPTs,
     taxonomies, seeds data, and calls
     `WP_WebMCP_Tool_Repository::upsert_by_slug()` for each tool.
   - `WP_WebMCP_Pack_<StudlySlug>::uninstall( $manifest )` — reverses the install.
   - `WP_WebMCP_Pack_<StudlySlug>::boot()` (or hooked at `init`) — registers the
     `wpwebmcp_pack_runner_<slug>` filter that dispatches tool calls to your
     tool implementations.

### Tool runner contract

The pack's bootstrap hooks:

```php
add_filter( 'wpwebmcp_pack_runner_' . $slug, array( __CLASS__, 'run_tool' ), 10, 3 );
```

`run_tool( $default, $tool_key, $params )` receives the routed tool call. Return
the result array (will be JSON-encoded by the executor) or `$default` to fall
through to the next filter.

### Example run_tool stub

```php
public static function run_tool( $default, $tool_key, $params ) {
    switch ( $tool_key ) {
        case 'search':
            return self::tool_search( $params );
        case 'get':
            return self::tool_get( $params );
        default:
            return $default;
    }
}
```

## Install / Uninstall lifecycle

- **Install**: SDK calls `WP_WebMCP_Pack_Registry::install( $slug )`. The loader
  requires the entry file, calls the pack's `install( $manifest )`, then records
  the pack in the `wpwebmcp_installed_packs` option.
- **Uninstall**: SDK calls `WP_WebMCP_Pack_Registry::uninstall( $slug )`. The
  pack's `uninstall( $manifest )` runs first; then the registry entry is
  removed. CPT/taxonomy rewrites stick around until an admin flushes permalinks.

## Security

- Pack bootstrap files run inside WordPress with whatever privileges the
  current request has. Bundled packs ship with the plugin (trusted). Third-party
  packs in `wp-content/wp-webmcp-packs/` should be vetted before install.
- Tool runners must sanitize all `$params` — packs are not sandboxed.
- Pack tool rows are scoped (`tool_scope = <slug>`) so the A4 audit and A3a
  gap detector see them correctly.

## Future (A6b)

- License-key gating for `free: false` packs.
- Marketplace browse + purchase via WooCommerce products or Stripe Checkout.
- Pack updates (bump version → re-run install routine idempotently).
- Pack deactivation (status=inactive without full uninstall).
