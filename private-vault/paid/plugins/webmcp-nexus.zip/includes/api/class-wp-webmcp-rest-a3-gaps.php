<?php
/**
 * REST_A3_Gaps — Module A A3a (AEO Intelligence — Answer-Gap Detector).
 *
 * Admin-only REST routes for the question-bank gap detector and for
 * one-click creation of the suggested tool from a gap row.
 *
 * Routes:
 *   POST /wp-json/wpwebmcp/v1/a3/gap-scan
 *        body: { vertical?: string, match_floor?: int (1..10, default 2) }
 *        200: { ok, vertical, total, covered, gap_count, gaps: [
 *                 { query, vertical, expected_intent, suggested_tool: {...} } ] }
 *
 *   POST /wp-json/wpwebmcp/v1/a3/gap-apply
 *        body: { vertical?, query, suggested_tool: { slug, name, description, parameters } }
 *        201: { ok, tool_id, slug, query, vertical, edit_url }
 *        409: slug already exists
 *        400: missing/invalid input
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_REST_A3_Gaps {

	public static function register_routes(): void {
		$ns = 'wpwebmcp/v1';

		register_rest_route(
			$ns,
			'/a3/gap-scan',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_scan' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'vertical'    => array(
						'required'          => false,
						'type'              => 'string',
						'default'           => '',
						'sanitize_callback' => 'sanitize_key',
					),
					'match_floor' => array(
						'required'          => false,
						'type'              => 'integer',
						'default'           => 2,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		register_rest_route(
			$ns,
			'/a3/gap-apply',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_apply' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			)
		);
	}

	public static function check_admin(): bool {
		return current_user_can( 'manage_options' );
	}

	public static function handle_scan( WP_REST_Request $request ) {
		$vertical    = (string) $request->get_param( 'vertical' );
		$match_floor = (int) $request->get_param( 'match_floor' );
		if ( $match_floor < 1 ) {
			$match_floor = 2;
		}
		if ( $match_floor > 10 ) {
			$match_floor = 10;
		}

		$result = ( '' === $vertical )
			? WP_WebMCP_Answer_Gap_Detector::detect( null, $match_floor )
			: WP_WebMCP_Answer_Gap_Detector::detect_vertical( $vertical );

		// If a specific vertical was requested, override the floor on the
		// returned object so callers can echo it back in the response.
		$result['match_floor'] = $match_floor;
		$result['ok']           = true;

		return rest_ensure_response( $result );
	}

	public static function handle_apply( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			$body = $request->get_body_params();
		}
		if ( ! is_array( $body ) ) {
			return new WP_Error(
				'wpwebmcp_a3_gap_bad_input',
				__( 'JSON body required.', 'webmcp-nexus' ),
				array( 'status' => 400 )
			);
		}

		$vertical = isset( $body['vertical'] ) ? sanitize_key( (string) $body['vertical'] ) : '';
		$query    = isset( $body['query'] ) ? sanitize_text_field( (string) $body['query'] ) : '';
		$tool     = isset( $body['suggested_tool'] ) && is_array( $body['suggested_tool'] ) ? $body['suggested_tool'] : array();

		if ( '' === $query || empty( $tool ) ) {
			return new WP_Error(
				'wpwebmcp_a3_gap_missing_fields',
				__( 'query and suggested_tool are required.', 'webmcp-nexus' ),
				array( 'status' => 400 )
			);
		}

		$slug = isset( $tool['slug'] ) ? (string) $tool['slug'] : '';
		$name = isset( $tool['name'] ) ? sanitize_text_field( (string) $tool['name'] ) : '';
		$desc = isset( $tool['description'] ) ? (string) $tool['description'] : '';
		if ( '' === $slug || '' === $name || '' === $desc ) {
			return new WP_Error(
				'wpwebmcp_a3_gap_missing_fields',
				__( 'suggested_tool.slug, .name, and .description are required.', 'webmcp-nexus' ),
				array( 'status' => 400 )
			);
		}

		$sanitised_slug = preg_replace( '/[^A-Za-z0-9_]/', '', $slug ) ?? '';
		if ( '' === $sanitised_slug || strlen( $sanitised_slug ) > 100 ) {
			return new WP_Error(
				'wpwebmcp_a3_gap_bad_slug',
				__( 'slug must be camelCase ASCII (letters, digits, underscore) and ≤100 chars.', 'webmcp-nexus' ),
				array( 'status' => 400 )
			);
		}

		if ( class_exists( 'WP_WebMCP_Tool_Repository' )
			&& null !== WP_WebMCP_Tool_Repository::find_by_slug( $sanitised_slug )
		) {
			return new WP_Error(
				'wpwebmcp_a3_gap_slug_exists',
				sprintf(
					/* translators: %s: tool slug */
					__( 'A tool with slug "%s" already exists.', 'webmcp-nexus' ),
					$sanitised_slug
				),
				array(
					'status' => 409,
					'slug'   => $sanitised_slug,
				)
			);
		}

		$payload = array(
			'tool_name'        => $sanitised_slug,
			'tool_description' => $desc,
			'tool_type'        => 'read',
			'tool_scope'       => 'all',
			'action_type'      => 'rest',
			'action_value'     => '',
			'parameters'       => isset( $tool['parameters'] ) && is_array( $tool['parameters'] ) ? $tool['parameters'] : array(),
			'status'           => 'active',
		);

		if ( ! class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			return new WP_Error(
				'wpwebmcp_a3_gap_repo_missing',
				__( 'Tool repository not loaded.', 'webmcp-nexus' ),
				array( 'status' => 500 )
			);
		}

		$tool_id = WP_WebMCP_Tool_Repository::insert( $payload );
		if ( $tool_id <= 0 ) {
			return new WP_Error(
				'wpwebmcp_a3_gap_insert_failed',
				__( 'Failed to insert the tool row.', 'webmcp-nexus' ),
				array( 'status' => 500 )
			);
		}

		return rest_ensure_response(
			array(
				'ok'       => true,
				'tool_id'  => $tool_id,
				'slug'     => $sanitised_slug,
				'name'     => $name,
				'query'    => $query,
				'vertical' => $vertical,
				'edit_url' => admin_url( 'admin.php?page=wp-webmcp-tools&edit=' . $tool_id ),
			)
		);
	}
}
