<?php
/**
 * REST_A3_Schema — Module A A3c (AEO Intelligence — schema-to-tool sync).
 *
 * Admin-only REST surface for scanning schema.org markup across the site
 * and one-click applying the suggested MCP tool definitions into the
 * existing wpwebmcp_tools table via WP_WebMCP_Tool_Repository.
 *
 * Routes:
 *   POST /wp-json/wpwebmcp/v1/a3/schema-scan
 *        body: { max_posts?: int (1..2000, default 500) }
 *        200: { ok, scanned_posts, suggestions: [ { type, label, icon, post_count,
 *                                                   sample_post_ids, sample_json,
 *                                                   threshold, suggested_tool: {...} } ] }
 *
 *   POST /wp-json/wpwebmcp/v1/a3/schema-apply
 *        body: { type, slug, name, description, tool_type?, tool_scope?,
 *                action_type?, action_value?, parameters? }
 *        201: { ok, tool_id, slug, type }
 *        409: slug already exists in wpwebmcp_tools
 *        400: invalid input
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_REST_A3_Schema {

	public static function register_routes(): void {
		$ns = 'wpwebmcp/v1';

		register_rest_route(
			$ns,
			'/a3/schema-scan',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_scan' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'max_posts' => array(
						'required'          => false,
						'type'              => 'integer',
						'default'           => 500,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		register_rest_route(
			$ns,
			'/a3/schema-apply',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_apply' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			)
		);
	}

	public static function check_admin(): bool {
		return current_user_can( 'manage_options' );
	}

	public static function handle_scan( WP_REST_Request $request ) {
		$max_posts = (int) $request->get_param( 'max_posts' );
		if ( $max_posts < 1 ) {
			$max_posts = 500;
		}
		if ( $max_posts > 2000 ) {
			$max_posts = 2000;
		}

		$scan        = WP_WebMCP_Schema_Scanner::scan( $max_posts );
		$suggestions = WP_WebMCP_Schema_Tool_Suggester::suggest( $scan );
		$stats       = WP_WebMCP_Schema_Scanner::scan_stats();

		return rest_ensure_response(
			array(
				'ok'            => true,
				'scanned_posts' => (int) $stats['candidates'],
				'scan_limit'    => (int) $stats['limit'],
				'suggestions'   => $suggestions,
			)
		);
	}

	public static function handle_apply( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			$body = $request->get_body_params();
		}
		if ( ! is_array( $body ) ) {
			return new WP_Error(
				'wpwebmcp_a3_bad_input',
				__( 'JSON body required.', 'webmcp-nexus' ),
				array( 'status' => 400 )
			);
		}

		$type        = isset( $body['type'] ) ? sanitize_key( (string) $body['type'] ) : '';
		$slug        = isset( $body['slug'] ) ? (string) $body['slug'] : '';
		$name        = isset( $body['name'] ) ? sanitize_text_field( (string) $body['name'] ) : '';
		$description = isset( $body['description'] ) ? (string) $body['description'] : '';

		if ( '' === $slug || '' === $name || '' === $description ) {
			return new WP_Error(
				'wpwebmcp_a3_missing_fields',
				__( 'slug, name, and description are required.', 'webmcp-nexus' ),
				array( 'status' => 400 )
			);
		}

		// Slug must be camelCase ASCII — match Tool_Repository::sanitize_slug().
		$sanitised_slug = preg_replace( '/[^A-Za-z0-9_]/', '', $slug ) ?? '';
		if ( '' === $sanitised_slug || strlen( $sanitised_slug ) > 100 ) {
			return new WP_Error(
				'wpwebmcp_a3_bad_slug',
				__( 'slug must be camelCase ASCII (letters, digits, underscore) and ≤100 chars.', 'webmcp-nexus' ),
				array( 'status' => 400 )
			);
		}

		// 409 Conflict: don't double-create.
		if ( class_exists( 'WP_WebMCP_Tool_Repository' )
			&& null !== WP_WebMCP_Tool_Repository::find_by_slug( $sanitised_slug )
		) {
			return new WP_Error(
				'wpwebmcp_a3_slug_exists',
				sprintf(
					/* translators: %s: tool slug */
					__( 'A tool with slug "%s" already exists.', 'webmcp-nexus' ),
					$sanitised_slug
				),
				array(
					'status' => 409,
					'slug'   => $sanitised_slug,
				)
			);
		}

		// Build payload — match WP_WebMCP_Tool_Repository::insert() input shape.
		$tool_type    = isset( $body['tool_type'] ) ? (string) $body['tool_type'] : 'read';
		$tool_scope   = isset( $body['tool_scope'] ) ? (string) $body['tool_scope'] : 'all';
		$action_type  = isset( $body['action_type'] ) ? (string) $body['action_type'] : 'rest';
		$action_value = isset( $body['action_value'] ) ? (string) $body['action_value'] : '';
		$parameters   = isset( $body['parameters'] ) && is_array( $body['parameters'] ) ? $body['parameters'] : array();

		$payload = array(
			'tool_name'        => $sanitised_slug,
			'tool_description' => $description,
			'tool_type'        => $tool_type,
			'tool_scope'       => $tool_scope,
			'action_type'      => $action_type,
			'action_value'     => $action_value,
			'parameters'       => $parameters,
			'status'           => 'active',
		);

		if ( ! class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			return new WP_Error(
				'wpwebmcp_a3_repo_missing',
				__( 'Tool repository not loaded.', 'webmcp-nexus' ),
				array( 'status' => 500 )
			);
		}

		$tool_id = WP_WebMCP_Tool_Repository::insert( $payload );
		if ( $tool_id <= 0 ) {
			return new WP_Error(
				'wpwebmcp_a3_insert_failed',
				__( 'Failed to insert the tool row.', 'webmcp-nexus' ),
				array( 'status' => 500 )
			);
		}

		// Persist which @type created this tool — visible in the Tool Builder later.
		// Stored as post-meta on a synthetic row? No — wpwebmcp_tools has no meta table.
		// Instead, surface it via the REST response only. Future enhancement: dedicated column.
		return rest_ensure_response(
			array(
				'ok'        => true,
				'tool_id'   => $tool_id,
				'slug'      => $sanitised_slug,
				'name'      => $name,
				'type'      => $type,
				'edit_url'  => admin_url( 'admin.php?page=wp-webmcp-tools&edit=' . $tool_id ),
			)
		);
	}
}
