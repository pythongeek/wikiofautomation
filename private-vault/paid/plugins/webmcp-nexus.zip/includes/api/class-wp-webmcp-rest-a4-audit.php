<?php
/**
 * REST_A4_Audit — Module A A4 (AI-Readiness Audit).
 *
 * Admin-only REST routes for per-post AEO score + missing-tool feed + leaderboard.
 *
 * Routes:
 *   POST /wp-json/wpwebmcp/v1/a4/audit-post
 *        body: { post_id: int }
 *        200: { ok, audit: { post_id, post_title, post_type, total, max, grade, breakdown: [...] } }
 *        404: post not found
 *
 *   GET  /wp-json/wpwebmcp/v1/a4/leaderboard
 *        query: ?direction=top|bottom (default top), ?limit=N (1..50, default 10), ?max_posts=N (1..2000, default 500)
 *        200: { ok, direction, limit, rows: [ {post_id, total, grade, ...} ] }
 *
 *   GET  /wp-json/wpwebmcp/v1/a4/missing-tools
 *        query: ?schema_scan_limit=N (1..2000, default 500)
 *        200: { ok, count, breakdown: {schema, gap, total}, rows: [...] }
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_REST_A4_Audit {

	public static function register_routes(): void {
		$ns = 'wpwebmcp/v1';

		register_rest_route(
			$ns,
			'/a4/audit-post',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_audit_post' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'post_id' => array(
						'required'          => true,
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		register_rest_route(
			$ns,
			'/a4/leaderboard',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle_leaderboard' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'direction' => array(
						'required'          => false,
						'type'              => 'string',
						'default'           => 'top',
						'sanitize_callback' => 'sanitize_key',
					),
					'limit'     => array(
						'required'          => false,
						'type'              => 'integer',
						'default'           => 10,
						'sanitize_callback' => 'absint',
					),
					'max_posts' => array(
						'required'          => false,
						'type'              => 'integer',
						'default'           => 500,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		register_rest_route(
			$ns,
			'/a4/missing-tools',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle_missing_tools' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'schema_scan_limit' => array(
						'required'          => false,
						'type'              => 'integer',
						'default'           => 500,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);
	}

	public static function check_admin(): bool {
		return current_user_can( 'manage_options' );
	}

	public static function handle_audit_post( WP_REST_Request $request ) {
		$post_id = (int) $request->get_param( 'post_id' );
		if ( $post_id <= 0 ) {
			return new WP_Error(
				'wpwebmcp_a4_bad_post',
				__( 'post_id is required and must be > 0.', 'webmcp-nexus' ),
				array( 'status' => 400 )
			);
		}
		$audit = WP_WebMCP_Post_Audit::audit_post( $post_id );
		if ( isset( $audit['error'] ) ) {
			return new WP_Error(
				'wpwebmcp_a4_post_not_found',
				__( 'Post not found.', 'webmcp-nexus' ),
				array( 'status' => 404, 'post_id' => $post_id )
			);
		}
		return rest_ensure_response(
			array(
				'ok'    => true,
				'audit' => $audit,
			)
		);
	}

	public static function handle_leaderboard( WP_REST_Request $request ) {
		$direction = (string) $request->get_param( 'direction' );
		if ( ! in_array( $direction, array( 'top', 'bottom' ), true ) ) {
			$direction = 'top';
		}
		$limit     = (int) $request->get_param( 'limit' );
		$max_posts = (int) $request->get_param( 'max_posts' );
		if ( $limit < 1 ) { $limit = 10; }
		if ( $limit > 50 ) { $limit = 50; }
		if ( $max_posts < 1 ) { $max_posts = 500; }
		if ( $max_posts > 2000 ) { $max_posts = 2000; }

		$rows = WP_WebMCP_Post_Audit::leaderboard( $direction, $limit, $max_posts );
		// Trim to the public shape — drop the verbose breakdown from each row
		// to keep the leaderboard payload compact.
		$compact = array();
		foreach ( $rows as $row ) {
			$compact[] = array(
				'post_id'    => (int) ( $row['post_id'] ?? 0 ),
				'post_title' => (string) ( $row['post_title'] ?? '' ),
				'post_type'  => (string) ( $row['post_type'] ?? '' ),
				'total'      => (int) ( $row['total'] ?? 0 ),
				'max'        => (int) ( $row['max'] ?? 100 ),
				'grade'      => (string) ( $row['grade'] ?? '' ),
				'edit_url'   => (int) ( $row['post_id'] ?? 0 ) > 0
					? get_edit_post_link( (int) $row['post_id'], 'raw' )
					: '',
			);
		}
		return rest_ensure_response(
			array(
				'ok'        => true,
				'direction' => $direction,
				'limit'     => $limit,
				'max_posts' => $max_posts,
				'rows'      => $compact,
			)
		);
	}

	public static function handle_missing_tools( WP_REST_Request $request ) {
		$limit = (int) $request->get_param( 'schema_scan_limit' );
		if ( $limit < 1 ) { $limit = 500; }
		if ( $limit > 2000 ) { $limit = 2000; }

		$rows = WP_WebMCP_Missing_Tool_Auditor::collect( $limit );
		return rest_ensure_response(
			array(
				'ok'        => true,
				'count'     => count( $rows ),
				'breakdown' => WP_WebMCP_Missing_Tool_Auditor::count_breakdown(),
				'rows'      => $rows,
			)
		);
	}
}
