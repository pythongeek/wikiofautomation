<?php
/**
 * REST_A5_Trace — Module A A5 (Agent Live Trace).
 *
 * Admin-only REST routes for the agent-inspector diagnostic surface.
 * Every endpoint reads from real log rows, the live agent registry, the
 * real policy evaluator, or re-executes a real logged tool call. Nothing
 * is fabricated or simulated.
 *
 * Routes:
 *   GET  /wp-json/wpwebmcp/v1/a5/recent-calls
 *        query: ?limit=N (1..100, default 20)
 *        200: { ok, rows: [...] }
 *
 *   GET  /wp-json/wpwebmcp/v1/a5/recent-bots
 *        query: ?limit=N, ?days=N (defaults 20 / 30)
 *        200: { ok, rows: [...] }
 *
 *   POST /wp-json/wpwebmcp/v1/a5/resolve-agent
 *        body: { user_agent: string }
 *        200: { ok, agent: {slug, family, is_user, confidence, matched_via, matched_term, registry_rows, ...} }
 *
 *   POST /wp-json/wpwebmcp/v1/a5/preview-policy
 *        body: { agent_slug: string, family?: string }
 *        200: { ok, matched: {policy row} | null, agent, reason }
 *
 *   POST /wp-json/wpwebmcp/v1/a5/rerun-call
 *        body: { call_id: int }
 *        200: { ok, call, current_response, current_execution_ms, current_exception?, is_write, agent }
 *        4xx when call_id missing / log row missing / tool missing / executor missing
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_REST_A5_Trace {

	public static function register_routes(): void {
		$ns = 'wpwebmcp/v1';

		register_rest_route(
			$ns,
			'/a5/recent-calls',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle_recent_calls' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'limit' => array(
						'required'          => false,
						'type'              => 'integer',
						'default'           => 20,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		register_rest_route(
			$ns,
			'/a5/recent-bots',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle_recent_bots' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'limit' => array(
						'required'          => false,
						'type'              => 'integer',
						'default'           => 20,
						'sanitize_callback' => 'absint',
					),
					'days' => array(
						'required'          => false,
						'type'              => 'integer',
						'default'           => 30,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		register_rest_route(
			$ns,
			'/a5/resolve-agent',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_resolve_agent' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'user_agent' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		register_rest_route(
			$ns,
			'/a5/preview-policy',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_preview_policy' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'agent_slug' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_key',
					),
					'family'     => array(
						'required'          => false,
						'type'              => 'string',
						'default'           => '',
						'sanitize_callback' => 'sanitize_key',
					),
				),
			)
		);

		register_rest_route(
			$ns,
			'/a5/rerun-call',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_rerun_call' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'call_id' => array(
						'required'          => true,
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
					),
				),
			)
		);
	}

	public static function check_admin(): bool {
		return current_user_can( 'manage_options' );
	}

	public static function handle_recent_calls( WP_REST_Request $request ) {
		$limit = (int) $request->get_param( 'limit' );
		if ( $limit < 1 ) { $limit = 20; }
		if ( $limit > 100 ) { $limit = 100; }
		$rows = WP_WebMCP_Agent_Inspector::recent_tool_calls( $limit );
		return rest_ensure_response(
			array(
				'ok'    => true,
				'count' => count( $rows ),
				'rows'  => $rows,
			)
		);
	}

	public static function handle_recent_bots( WP_REST_Request $request ) {
		$limit = (int) $request->get_param( 'limit' );
		$days  = (int) $request->get_param( 'days' );
		if ( $limit < 1 ) { $limit = 20; }
		if ( $limit > 100 ) { $limit = 100; }
		if ( $days < 1 ) { $days = 30; }
		if ( $days > 365 ) { $days = 365; }
		$rows = WP_WebMCP_Agent_Inspector::recent_bot_visits_rows( $limit, $days );
		return rest_ensure_response(
			array(
				'ok'    => true,
				'count' => count( $rows ),
				'rows'  => $rows,
			)
		);
	}

	public static function handle_resolve_agent( WP_REST_Request $request ) {
		$ua = (string) $request->get_param( 'user_agent' );
		if ( '' === $ua ) {
			return new WP_Error(
				'wpwebmcp_a5_missing_ua',
				__( 'user_agent is required.', 'webmcp-nexus' ),
				array( 'status' => 400 )
			);
		}
		$agent = WP_WebMCP_Agent_Inspector::resolve_agent( $ua );
		return rest_ensure_response(
			array(
				'ok'    => true,
				'agent' => $agent,
			)
		);
	}

	public static function handle_preview_policy( WP_REST_Request $request ) {
		$slug   = (string) $request->get_param( 'agent_slug' );
		$family = (string) $request->get_param( 'family' );
		if ( '' === $slug ) {
			return new WP_Error(
				'wpwebmcp_a5_missing_agent',
				__( 'agent_slug is required.', 'webmcp-nexus' ),
				array( 'status' => 400 )
			);
		}
		$result = WP_WebMCP_Agent_Inspector::preview_policy( $slug, $family );
		return rest_ensure_response(
			array(
				'ok'      => true,
				'matched' => $result['matched'],
				'agent'   => $result['agent'],
				'reason'  => $result['reason'],
			)
		);
	}

	public static function handle_rerun_call( WP_REST_Request $request ) {
		$call_id = (int) $request->get_param( 'call_id' );
		if ( $call_id <= 0 ) {
			return new WP_Error(
				'wpwebmcp_a5_bad_call_id',
				__( 'call_id is required and must be > 0.', 'webmcp-nexus' ),
				array( 'status' => 400 )
			);
		}
		$result = WP_WebMCP_Agent_Inspector::rerun_call( $call_id );
		if ( empty( $result['ok'] ) ) {
			$code = isset( $result['error'] ) ? (string) $result['error'] : 'unknown';
			$status = ( 'log_row_not_found' === $code ) ? 404 : 400;
			return new WP_Error(
				'wpwebmcp_a5_rerun_failed',
				$code,
				array( 'status' => $status, 'result' => $result )
			);
		}
		return rest_ensure_response( $result );
	}
}
