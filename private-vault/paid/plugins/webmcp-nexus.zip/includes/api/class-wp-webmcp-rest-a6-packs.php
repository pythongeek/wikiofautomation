<?php
/**
 * REST_A6_Packs — A6 (Vertical Tool Packs Marketplace) REST routes.
 *
 * Endpoints (admin-only):
 *   GET  /wp-json/wpwebmcp/v1/a6/packs             -> installed + available catalogs.
 *   POST /wp-json/wpwebmcp/v1/a6/packs/install     body: {slug} -> install a pack.
 *   POST /wp-json/wpwebmcp/v1/a6/packs/uninstall   body: {slug} -> uninstall a pack.
 *   GET  /wp-json/wpwebmcp/v1/a6/packs/<slug>/tools-> list tools belonging to a pack.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_REST_A6_Packs {

	/**
	 * Register the routes on rest_api_init.
	 */
	public static function register(): void {
		$ns = 'wpwebmcp/v1';

		register_rest_route(
			$ns,
			'/a6/packs',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( self::class, 'list_packs' ),
				'permission_callback' => array( self::class, 'can_admin' ),
			)
		);

		register_rest_route(
			$ns,
			'/a6/packs/install',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( self::class, 'install_pack' ),
				'permission_callback' => array( self::class, 'can_admin' ),
				'args'                => array(
					'slug' => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'sanitize_key',
					),
				),
			)
		);

		register_rest_route(
			$ns,
			'/a6/packs/uninstall',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( self::class, 'uninstall_pack' ),
				'permission_callback' => array( self::class, 'can_admin' ),
				'args'                => array(
					'slug' => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'sanitize_key',
					),
				),
			)
		);

		register_rest_route(
			$ns,
			'/a6/packs/(?P<slug>[a-z0-9-]+)/tools',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( self::class, 'list_pack_tools' ),
				'permission_callback' => array( self::class, 'can_admin' ),
				'args'                => array(
					'slug' => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'sanitize_key',
					),
				),
			)
		);
	}

	public static function can_admin(): bool {
		return current_user_can( 'manage_options' );
	}

	public static function list_packs( WP_REST_Request $req ) {
		$installed = array();
		if ( class_exists( 'WP_WebMCP_Pack_Registry' ) ) {
			$installed = WP_WebMCP_Pack_Registry::list_installed();
		}

		$available = array();
		if ( class_exists( 'WP_WebMCP_Pack_Registry' ) ) {
			$available = WP_WebMCP_Pack_Registry::list_available();
		}

		return rest_ensure_response(
			array(
				'installed' => $installed,
				'available' => $available,
				'counts'    => array(
					'installed' => count( $installed ),
					'available' => count( $available ),
				),
			)
		);
	}

	public static function install_pack( WP_REST_Request $req ) {
		$slug = (string) $req->get_param( 'slug' );
		if ( '' === $slug ) {
			return new WP_Error( 'wpwebmcp_a6_no_slug', 'Pack slug is required.', array( 'status' => 400 ) );
		}
		if ( ! class_exists( 'WP_WebMCP_Pack_Registry' ) ) {
			return new WP_Error( 'wpwebmcp_a6_sdk_missing', 'Pack SDK not loaded.', array( 'status' => 500 ) );
		}
		$result = WP_WebMCP_Pack_Registry::install( $slug );
		if ( ! $result['ok'] ) {
			$status = false !== strpos( (string) $result['error'], 'already installed' ) ? 409 : 400;
			return new WP_Error( 'wpwebmcp_a6_install_failed', (string) $result['error'], array( 'status' => $status ) );
		}
		return rest_ensure_response(
			array(
				'ok'       => true,
				'installed'=> WP_WebMCP_Pack_Registry::list_installed(),
				'manifest' => $result['manifest'],
			)
		);
	}

	public static function uninstall_pack( WP_REST_Request $req ) {
		$slug = (string) $req->get_param( 'slug' );
		if ( '' === $slug ) {
			return new WP_Error( 'wpwebmcp_a6_no_slug', 'Pack slug is required.', array( 'status' => 400 ) );
		}
		if ( ! class_exists( 'WP_WebMCP_Pack_Registry' ) ) {
			return new WP_Error( 'wpwebmcp_a6_sdk_missing', 'Pack SDK not loaded.', array( 'status' => 500 ) );
		}
		$result = WP_WebMCP_Pack_Registry::uninstall( $slug );
		if ( ! $result['ok'] ) {
			return new WP_Error( 'wpwebmcp_a6_uninstall_failed', (string) $result['error'], array( 'status' => 400 ) );
		}
		return rest_ensure_response(
			array(
				'ok'           => true,
				'installed'    => WP_WebMCP_Pack_Registry::list_installed(),
			)
		);
	}

	public static function list_pack_tools( WP_REST_Request $req ) {
		$slug = (string) $req->get_param( 'slug' );
		if ( '' === $slug ) {
			return new WP_Error( 'wpwebmcp_a6_no_slug', 'Pack slug is required.', array( 'status' => 400 ) );
		}
		if ( ! class_exists( 'WP_WebMCP_Pack_Registry' ) ) {
			return new WP_Error( 'wpwebmcp_a6_sdk_missing', 'Pack SDK not loaded.', array( 'status' => 500 ) );
		}
		$installed = WP_WebMCP_Pack_Registry::get_installed();
		if ( ! isset( $installed[ $slug ] ) ) {
			return new WP_Error( 'wpwebmcp_a6_not_installed', sprintf( 'Pack "%s" is not installed.', $slug ), array( 'status' => 404 ) );
		}
		$manifest = $installed[ $slug ]['manifest'];
		$tools    = isset( $manifest['tools'] ) ? (array) $manifest['tools'] : array();

		// Enrich with the actual tool rows so callers can see status.
		$enriched = array();
		foreach ( $tools as $t ) {
			$tool_name = (string) ( $t['name'] ?? $t['key'] ?? '' );
			$row       = class_exists( 'WP_WebMCP_Tool_Repository' ) ? WP_WebMCP_Tool_Repository::find_by_slug( $tool_name ) : null;
			$enriched[] = array(
				'key'         => (string) ( $t['key'] ?? '' ),
				'name'        => $tool_name,
				'description' => (string) ( $t['description'] ?? '' ),
				'parameters'  => isset( $t['parameters'] ) ? (array) $t['parameters'] : array(),
				'status'      => $row ? (string) ( $row['status'] ?? 'unknown' ) : 'missing',
				'action_type' => $row ? (string) ( $row['action_type'] ?? '' ) : '',
				'action_value'=> $row ? (string) ( $row['action_value'] ?? '' ) : '',
			);
		}

		return rest_ensure_response(
			array(
				'slug'  => $slug,
				'name'  => (string) ( $manifest['name'] ?? $slug ),
				'count' => count( $enriched ),
				'tools' => $enriched,
			)
		);
	}
}
