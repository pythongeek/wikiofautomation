<?php
/**
 * REST route for the Citation leaderboard (A2b / A1d follow-up).
 *
 * Public read of the leaderboard snapshot so dashboards / monitoring
 * tooling can pull the same numbers the admin page shows.
 *
 *   GET /wpwebmcp/v1/citation-leaderboard   [public]
 *     -> { ok, totals, rows, recent_citations, recent_tool_calls, generated_at, _meta }
 *
 * No mutation routes — the leaderboard is a read-only aggregation.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_REST_Citation_Leaderboard {

	/**
	 * Default leaderboard cap.
	 */
	public const DEFAULT_TOP_AGENTS = 50;

	/**
	 * Default totals window (days).
	 */
	public const DEFAULT_WINDOW_DAYS = 30;

	public static function register_routes(): void {
		if ( ! class_exists( 'WP_WebMCP_Citation_Leaderboard' ) ) {
			return;
		}
		register_rest_route(
			'wpwebmcp/v1',
			'/citation-leaderboard',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'days'  => array(
						'type'              => 'integer',
						'default'           => self::DEFAULT_WINDOW_DAYS,
						'sanitize_callback' => 'absint',
					),
					'limit' => array(
						'type'              => 'integer',
						'default'           => self::DEFAULT_TOP_AGENTS,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);
	}

	public static function handle( WP_REST_Request $request ) {
		$days  = (int) $request->get_param( 'days' );
		$limit = (int) $request->get_param( 'limit' );
		if ( $days < 1 ) { $days = self::DEFAULT_WINDOW_DAYS; }
		if ( $days > 365 ) { $days = 365; }
		if ( $limit < 1 ) { $limit = self::DEFAULT_TOP_AGENTS; }
		if ( $limit > 100 ) { $limit = 100; }

		$rows          = WP_WebMCP_Citation_Leaderboard::get_rows();
		$totals        = WP_WebMCP_Citation_Leaderboard::get_totals( $days );
		$recent_visits = WP_WebMCP_Citation_Leaderboard::get_recent_citations( 20 );
		$recent_calls  = WP_WebMCP_Citation_Leaderboard::get_recent_tool_calls( 20 );

		if ( is_array( $rows ) && count( $rows ) > $limit ) {
			$rows = array_slice( $rows, 0, $limit );
		}

		return rest_ensure_response(
			array(
				'ok'                => true,
				'totals'            => $totals,
				'rows'              => $rows,
				'recent_citations'  => $recent_visits,
				'recent_tool_calls' => $recent_calls,
				'generated_at_gmt'  => gmdate( 'c' ),
				'_meta'             => array(
					'scope'            => 'last ' . $days . ' day(s)',
					'top_agents_shown' => is_array( $rows ) ? count( $rows ) : 0,
				),
			)
		);
	}
}
