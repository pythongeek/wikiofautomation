<?php
/**
 * REST API Fallback & 404 Rescue Router.
 *
 * Ensures all WebMCP Nexus REST endpoints (/wp-json/wpwebmcp/v1/...) are 100%
 * accessible across all WordPress environments, including:
 *   1. Plain permalinks (?p=123) where /wp-json/ is not handled by default rewrites.
 *   2. Nginx/Apache servers without AllowOverride or try_files rewrites.
 *   3. Missing or stale .htaccess rewrite rules.
 *   4. Subdirectory WordPress installations.
 *   5. Browser and AI agent CORS OPTIONS preflight requests.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_REST_Fallback {

	/**
	 * Namespace for WebMCP endpoints.
	 */
	public const NAMESPACE = 'wpwebmcp/v1';

	/**
	 * Boot the fallback handler.
	 */
	public static function init(): void {
		// Hook early in init and parse_request to normalize rest_route.
		add_action( 'init', array( __CLASS__, 'normalize_request' ), 1 );
		add_action( 'parse_request', array( __CLASS__, 'on_parse_request' ), 1 );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_intercept_rest' ), 1 );
	}

	/**
	 * Detect if incoming request is targeting WebMCP endpoints.
	 *
	 * @return string|null Endpoint subpath (e.g. '/wpwebmcp/v1/manifest') or null if not WebMCP.
	 */
	public static function get_target_route(): ?string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Route routing inspection for REST fallback, not form processing.
		if ( ! empty( $_GET['rest_route'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$raw_route = sanitize_text_field( wp_unslash( $_GET['rest_route'] ) );
			$route     = '/' . ltrim( $raw_route, '/' );
			if ( 0 === strpos( $route, '/wpwebmcp/' ) ) {
				return $route;
			}
		}

		$uri = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
		if ( '' === $uri ) {
			return null;
		}

		$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
		if ( '' === $path ) {
			return null;
		}

		// Look for /wp-json/wpwebmcp/ or custom rest prefix/wpwebmcp/.
		$rest_prefix = function_exists( 'rest_get_url_prefix' ) ? rest_get_url_prefix() : 'wp-json';
		$needle      = '/' . $rest_prefix . '/wpwebmcp/';
		$pos         = strpos( $path, $needle );

		if ( false !== $pos ) {
			return substr( $path, $pos + strlen( '/' . $rest_prefix ) );
		}

		// Also check direct /wp-json/wpwebmcp/
		$pos2 = strpos( $path, '/wp-json/wpwebmcp/' );
		if ( false !== $pos2 ) {
			return substr( $path, $pos2 + 8 );
		}

		// Also check bare /wpwebmcp/v1/
		$pos3 = strpos( $path, '/wpwebmcp/' );
		if ( false !== $pos3 ) {
			return substr( $path, $pos3 );
		}

		return null;
	}

	/**
	 * Normalize request early so WordPress core treats it as a REST request.
	 */
	public static function normalize_request(): void {
		$route = self::get_target_route();
		if ( null === $route ) {
			return;
		}

		// Handle OPTIONS preflight immediately with CORS headers to avoid 404/401 preflight errors.
		$method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET';
		if ( 'OPTIONS' === $method ) {
			self::send_preflight_cors();
			exit;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Setting rest_route fallback for public REST API.
		if ( empty( $_GET['rest_route'] ) ) {
			$_GET['rest_route']     = $route;
			$_SERVER['REST_ROUTE'] = $route;
		}

		// Register rest prefix rewrite rule if pretty permalinks are on but rest rules weren't flushed.
		if ( function_exists( 'add_rewrite_rule' ) && get_option( 'permalink_structure' ) ) {
			$prefix = function_exists( 'rest_get_url_prefix' ) ? rest_get_url_prefix() : 'wp-json';
			add_rewrite_rule( '^' . $prefix . '/(wpwebmcp/.*)?', 'index.php?rest_route=/$matches[1]', 'top' );
		}
	}

	/**
	 * Parse request fallback: if WordPress parse_request didn't match rest_route, populate it.
	 *
	 * @param WP $wp WordPress environment object.
	 */
	public static function on_parse_request( $wp ): void {
		$route = self::get_target_route();
		if ( null === $route ) {
			return;
		}

		if ( empty( $wp->query_vars['rest_route'] ) ) {
			$wp->query_vars['rest_route'] = $route;
		}
	}

	/**
	 * Fallback rescue in template_redirect:
	 * If WordPress is on a 404 page or unhandled route but the request is for WebMCP REST API,
	 * intercept and serve the REST request directly!
	 */
	public static function maybe_intercept_rest(): void {
		$route = self::get_target_route();
		if ( null === $route ) {
			return;
		}

		// If headers were already sent or it's not a 404/unhandled state, only intervene if rest server didn't run.
		if ( did_action( 'rest_api_init' ) && ! is_404() ) {
			return;
		}

		// Ensure REST API is initialized.
		if ( ! did_action( 'rest_api_init' ) ) {
			if ( function_exists( 'rest_api_init' ) ) {
				rest_api_init();
			} else {
				// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Fires core WordPress action if uninitialized in REST fallback handler.
				do_action( 'rest_api_init' );
			}
		}

		// Serve using WP_REST_Server.
		if ( function_exists( 'rest_get_server' ) ) {
			$server = rest_get_server();
			$server->serve_request( $route );
			exit;
		}
	}

	/**
	 * Send permissive CORS headers for OPTIONS requests.
	 */
	public static function send_preflight_cors(): void {
		$origin = isset( $_SERVER['HTTP_ORIGIN'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_ORIGIN'] ) ) : '*';
		header( 'Access-Control-Allow-Origin: ' . ( '' !== $origin ? $origin : '*' ) );
		header( 'Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS, HEAD' );
		header( 'Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce, X-WC-Nonce, Mcp-Session-Id, Cache-Control, Pragma, Accept, X-Requested-With' );
		header( 'Access-Control-Allow-Credentials: true' );
		header( 'Access-Control-Max-Age: 86400' );
		status_header( 200 );
	}
}
