<?php
/**
 * REST routes for the Freshness ping protocol (Module A A1c).
 *
 * Public surface:
 *   GET  /wpwebmcp/v1/freshness/status    -> enabled/queue/last-submit
 *   GET  /wpwebmcp/v1/freshness/stream    -> SSE (content_updated events)
 *
 * Admin surface (manage_options):
 *   POST /wpwebmcp/v1/freshness/settings  -> update enabled/key/endpoint
 *   GET  /wpjson/wpwebmcp/v1/freshness/log -> last N ping log rows
 *   POST /wpjson/wpwebmcp/v1/freshness/flush -> manual flush (cron bypass)
 *   POST /wpjson/wpwebmcp/v1/freshness/enqueue -> manually enqueue a URL
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_REST_Freshness {

	/**
	 * Singleton entry — wired from WP_WebMCP::define_api_hooks().
	 */
	public static function register_routes(): void {
		if ( ! class_exists( 'WP_WebMCP_Freshness_Pinger' ) ) {
			return;
		}
		$ns = 'wpwebmcp/v1';

		register_rest_route(
			$ns,
			'/freshness/status',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle_status' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			$ns,
			'/freshness/stream',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle_stream' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			$ns,
			'/freshness/settings',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_settings' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			)
		);

		register_rest_route(
			$ns,
			'/freshness/log',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle_log' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			)
		);

		register_rest_route(
			$ns,
			'/freshness/flush',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_flush' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			)
		);

		register_rest_route(
			$ns,
			'/freshness/enqueue',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_enqueue' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'url'     => array( 'required' => true,  'type' => 'string' ),
					'post_id' => array( 'required' => false, 'type' => 'integer' ),
					'action'  => array( 'required' => false, 'type' => 'string', 'default' => 'manual' ),
				),
			)
		);
	}

	public static function check_admin(): bool {
		return current_user_can( 'manage_options' );
	}

	public static function handle_status() {
		$stats = WP_WebMCP_Freshness_Pinger::get_stats();
		return rest_ensure_response(
			array(
				'ok'                  => true,
				'enabled'             => WP_WebMCP_Freshness_Pinger::is_enabled(),
				'has_key'             => '' !== WP_WebMCP_Freshness_Pinger::get_key(),
				'queue_count'         => WP_WebMCP_Freshness_Pinger::get_queue_count(),
				'endpoint'            => WP_WebMCP_Freshness_Pinger::get_endpoint(),
				'last_submitted_at'   => $stats['last_submitted_at'],
				'last_submitted_url'  => $stats['last_submitted_url'],
				'submitted_today'     => (int) $stats['submitted_today'],
				'total_submitted'     => (int) $stats['total_submitted'],
				'daily_cap'           => 8000,
				'stream_url'          => rest_url( 'wpwebmcp/v1/freshness/stream' ),
			)
		);
	}

	public static function handle_settings( WP_REST_Request $req ) {
		$enabled  = (bool) ( $req->get_param( 'enabled' ) ?? false );
		$key      = (string) ( $req->get_param( 'indexnow_key' ) ?? '' );
		$endpoint = (string) ( $req->get_param( 'endpoint' ) ?? '' );

		// Validate key shape: 32 hex chars or empty.
		if ( '' !== $key && ! preg_match( '/^[a-f0-9]{8,128}$/i', $key ) ) {
			return new WP_Error( 'wpwebmcp_invalid_key', 'IndexNow key must be 8-128 hex chars.', array( 'status' => 400 ) );
		}
		// Validate endpoint URL.
		if ( '' !== $endpoint && ! wp_http_validate_url( $endpoint ) ) {
			return new WP_Error( 'wpwebmcp_invalid_endpoint', 'Endpoint must be a valid HTTPS URL.', array( 'status' => 400 ) );
		}

		update_option( WP_WebMCP_Freshness_Pinger::OPTION_ENABLED, $enabled, false );
		if ( '' !== $key ) {
			update_option( WP_WebMCP_Freshness_Pinger::OPTION_KEY, $key, false );
		}
		if ( '' !== $endpoint ) {
			update_option( WP_WebMCP_Freshness_Pinger::OPTION_ENDPOINT, esc_url_raw( $endpoint ), false );
		}

		return rest_ensure_response(
			array(
				'ok'      => true,
				'enabled' => $enabled,
				'has_key' => '' !== WP_WebMCP_Freshness_Pinger::get_key(),
			)
		);
	}

	public static function handle_log( WP_REST_Request $req ) {
		$limit = max( 1, min( 50, (int) ( $req->get_param( 'limit' ) ?? 25 ) ) );
		return rest_ensure_response(
			array(
				'ok'  => true,
				'log' => WP_WebMCP_Freshness_Pinger::get_log( $limit ),
			)
		);
	}

	public static function handle_flush() {
		$result = WP_WebMCP_Freshness_Pinger::flush_queue( true );
		return rest_ensure_response( array_merge( array( 'ok' => $result['ok'] ), $result ) );
	}

	public static function handle_enqueue( WP_REST_Request $req ) {
		$url     = (string) $req->get_param( 'url' );
		$post_id = (int) $req->get_param( 'post_id' );
		$action  = (string) $req->get_param( 'action' );
		$ok      = WP_WebMCP_Freshness_Pinger::enqueue( $url, $post_id, $action );
		return rest_ensure_response(
			array(
				'ok'      => $ok,
				'queue'   => WP_WebMCP_Freshness_Pinger::get_queue_count(),
			)
		);
	}

	/**
	 * SSE stream — emits the last 20 enqueue events on connect, then
	 * keeps the connection open and emits a heartbeat every 15s plus any
	 * new content_updated events as they happen.
	 */
	public static function handle_stream() {
		// Disable any output buffering that WP or the SAPI may have enabled.
		// SSE requires byte-level control — every `echo` must reach the wire
		// immediately or the EventSource client times out waiting for it.
		while ( ob_get_level() > 0 ) {
			@ob_end_clean();
		}

		// Headers must be sent before any WP output.
		if ( ! headers_sent() ) {
			status_header( 200 );
			header( 'Content-Type: text/event-stream; charset=utf-8' );
			header( 'Cache-Control: no-cache, no-store, must-revalidate' );
			header( 'Connection: keep-alive' );
			header( 'X-Accel-Buffering: no' ); // disable nginx proxy buffering
			header( 'Access-Control-Allow-Origin: *' );
		}

		// 1) Initial snapshot — replay the last 20 log entries as `history` events.
		$log = WP_WebMCP_Freshness_Pinger::get_log( 20 );
		echo "event: hello\n";
		echo 'data: ' . wp_json_encode(
			array(
				'enabled' => WP_WebMCP_Freshness_Pinger::is_enabled(),
				'queue'   => WP_WebMCP_Freshness_Pinger::get_queue_count(),
				'history' => $log,
				'stream_at_gmt' => gmdate( 'c' ),
			)
		) . "\n\n";

		// Push the hello event to the wire BEFORE entering the loop.
		// Do NOT call fastcgi_finish_request — we're keeping the connection open.
		if ( function_exists( 'fastcgi_finish_request' ) ) {
			@ob_flush();
			@flush();
		} else {
			@flush();
		}

		// 2) Live loop — emit heartbeats and any new content_updated events.
		// 30s max runtime to stay under shared-host proxy timeouts (Litespeed
		// default is 60s; LSCache can be more aggressive).
		$last_heartbeat = time();
		$last_event_ts  = '';
		$max_runtime    = 30;   // seconds — clients reconnect after.
		$start          = time();

		while ( time() - $start < $max_runtime ) {
			// Heartbeat every 5s (short enough that proxies won't kill the conn).
			if ( time() - $last_heartbeat >= 5 ) {
				echo "event: heartbeat\n";
				echo 'data: ' . wp_json_encode(
					array(
						'ts_gmt' => gmdate( 'c' ),
						'queue'  => WP_WebMCP_Freshness_Pinger::get_queue_count(),
					)
				) . "\n\n";
				@ob_flush();
				@flush();
				$last_heartbeat = time();
			}

			// Pull the most recent log entry; if it changed since last tick, emit it.
			$current = WP_WebMCP_Freshness_Pinger::get_log( 1 );
			if ( ! empty( $current ) ) {
				$latest_ts = (string) $current[0]['ts'];
				if ( '' !== $latest_ts && $latest_ts !== $last_event_ts ) {
					$last_event_ts = $latest_ts;
					echo "event: content_updated\n";
					echo 'data: ' . wp_json_encode( $current[0] ) . "\n\n";
					@ob_flush();
					@flush();
				}
			}

			// Don't spin at 100% CPU — sleep 500ms between ticks.
			usleep( 500000 );
		}

		// Graceful close — clients reconnect.
		echo "event: bye\n";
		echo 'data: ' . wp_json_encode( array( 'reason' => 'max_runtime', 'ts_gmt' => gmdate( 'c' ) ) ) . "\n\n";
		@ob_flush();
		@flush();
		exit;
	}
}
