<?php
/**
 * REST_Log — Doc §7.4.
 *
 * Three endpoints:
 *   - GET    /wpwebmcp/v1/log          (admin) — args validated, per_page ≤100
 *   - DELETE /wpwebmcp/v1/log          (admin) — requires `confirm=1` else 400
 *   - admin-post.php?action=wpwebmcp_log_csv  (admin) — nonce wpwebmcp_log_csv,
 *                                                500-row chunked CSV stream,
 *                                                exact headers from §7.4
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Log {

	/** Max per_page allowed by Doc §7.4. */
	private const MAX_PER_PAGE = 100;

	/** CSV row chunk size (Doc §7.4). */
	private const CSV_CHUNK_SIZE = 500;

	/**
	 * Singleton hook entry. Wires the 2 REST routes + 1 admin-post handler.
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		WP_WebMCP_Loader::register_action( 'admin_post_wpwebmcp_log_csv', array( __CLASS__, 'stream_csv' ) );
	}

	public static function register_routes(): void {
		$ns = 'wpwebmcp/v1';

		register_rest_route( $ns, '/log', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_log' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'per_page'  => array( 'type' => 'integer', 'default' => 50, 'minimum' => 1, 'maximum' => self::MAX_PER_PAGE ),
					'offset'    => array( 'type' => 'integer', 'default' => 0,  'minimum' => 0 ),
					'tool_name' => array( 'type' => 'string' ),
					'status'    => array( 'type' => 'string', 'enum' => array( 'success', 'error', 'rate_limited', 'auth_failed' ) ),
					'date_from' => array( 'type' => 'string' ),
					'date_to'   => array( 'type' => 'string' ),
				),
			),
			array(
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => array( __CLASS__, 'clear_log' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(),
			),
		) );

		register_rest_route( $ns, '/write-log', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_write_log' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'per_page'  => array( 'type' => 'integer', 'default' => 50, 'minimum' => 1, 'maximum' => self::MAX_PER_PAGE ),
					'offset'    => array( 'type' => 'integer', 'default' => 0,  'minimum' => 0 ),
					'status'    => array( 'type' => 'string' ),
					'date_from' => array( 'type' => 'string' ),
					'date_to'   => array( 'type' => 'string' ),
				),
			),
		) );
	}

	public static function check_admin(): bool {
		return current_user_can( 'manage_options' );
	}

	/* ============================================================
	 *  GET /log
	 * ============================================================ */

	public static function get_log( WP_REST_Request $request ) {
		$args = array(
			'per_page'  => (int) $request->get_param( 'per_page' ),
			'offset'    => (int) $request->get_param( 'offset' ),
			'tool_name' => (string) $request->get_param( 'tool_name' ),
			'status'    => (string) $request->get_param( 'status' ),
			'date_from' => (string) $request->get_param( 'date_from' ),
			'date_to'   => (string) $request->get_param( 'date_to' ),
		);
		if ( $args['per_page'] <= 0 ) { $args['per_page'] = 50; }
		if ( $args['per_page'] > self::MAX_PER_PAGE ) { $args['per_page'] = self::MAX_PER_PAGE; }
		if ( $args['tool_name'] ) {
			$args['tool_name'] = sanitize_text_field( $args['tool_name'] );
		}
		$args['status']    = sanitize_text_field( $args['status'] );
		$args['date_from'] = sanitize_text_field( $args['date_from'] );
		$args['date_to']   = sanitize_text_field( $args['date_to'] );

		$entries = class_exists( 'WP_WebMCP_Log_Repository' )
			? WP_WebMCP_Log_Repository::find( $args )
			: array();
		$total = class_exists( 'WP_WebMCP_Log_Repository' )
			? (int) WP_WebMCP_Log_Repository::count( $args )
			: 0;

		return rest_ensure_response(
			array(
				'entries' => $entries,
				'total'   => $total,
				'page'    => $args,
			)
		);
	}

	/* ============================================================
	 *  GET /write-log
	 * ============================================================ */

	public static function get_write_log( WP_REST_Request $request ) {
		global $wpdb;
		$args = array(
			'per_page'  => (int) $request->get_param( 'per_page' ),
			'offset'    => (int) $request->get_param( 'offset' ),
			'status'    => (string) $request->get_param( 'status' ),
			'date_from' => (string) $request->get_param( 'date_from' ),
			'date_to'   => (string) $request->get_param( 'date_to' ),
		);
		if ( $args['per_page'] <= 0 ) { $args['per_page'] = 50; }
		if ( $args['per_page'] > self::MAX_PER_PAGE ) { $args['per_page'] = self::MAX_PER_PAGE; }

		$table = $wpdb->prefix . 'wpwebmcp_write_log';
		$cache_key    = 'wpwebmcp_write_log_table_exists';
		$table_exists = wp_cache_get( $cache_key, 'wpwebmcp' );
		if ( false === $table_exists ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table check is cached to minimize queries.
			$table_exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table );
			wp_cache_set( $cache_key, (bool) $table_exists, 'wpwebmcp', HOUR_IN_SECONDS );
		}

		if ( ! $table_exists ) {
			return rest_ensure_response(
				array(
					'entries' => array(),
					'total'   => 0,
					'page'    => $args,
				)
			);
		}

		$where = array( '1=1' );
		$values = array();

		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$values[] = sanitize_text_field( $args['status'] );
		}
		if ( ! empty( $args['date_from'] ) ) {
			$where[]  = 'created_at >= %s';
			$values[] = sanitize_text_field( $args['date_from'] );
		}
		if ( ! empty( $args['date_to'] ) ) {
			$where[]  = 'created_at <= %s';
			$values[] = sanitize_text_field( $args['date_to'] );
		}

		$where_clause = implode( ' AND ', $where );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Real-time audit log queries constructed with parameterized placeholders.
		if ( ! empty( $values ) ) {
			$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}wpwebmcp_write_log WHERE {$where_clause}", $values ) );
		} else {
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}wpwebmcp_write_log WHERE {$where_clause}" );
		}

		$query_values = array_merge( $values, array( $args['per_page'], $args['offset'] ) );
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}wpwebmcp_write_log WHERE {$where_clause} ORDER BY created_at DESC LIMIT %d OFFSET %d",
				$query_values
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber,PluginCheck.Security.DirectDB.UnescapedDBParameter

		$entries = array();
		if ( is_array( $rows ) ) {
			foreach ( $rows as $row ) {
				$row['kind'] = 'write';
				$entries[] = $row;
			}
		}

		return rest_ensure_response(
			array(
				'entries' => $entries,
				'total'   => $total,
				'page'    => $args,
			)
		);
	}

	/* ============================================================
	 *  DELETE /log (requires confirm=1)
	 * ============================================================ */

	public static function clear_log( WP_REST_Request $request ) {
		$confirm = (int) $request->get_param( 'confirm' );
		if ( 1 !== $confirm ) {
			return new WP_Error(
				'wpwebmcp_confirm_required',
				__( 'Pass confirm=1 to clear the audit log.', 'webmcp-nexus' ),
				array( 'status' => 400 )
			);
		}
		if ( class_exists( 'WP_WebMCP_Log_Repository' ) ) {
			WP_WebMCP_Log_Repository::truncate();
		}
		/**
		 * Fires after the audit log is cleared.
		 */
		do_action( 'wpwebmcp_log_cleared' );

		return rest_ensure_response(
			array(
				'ok'   => true,
				'detail' => __( 'Audit log cleared.', 'webmcp-nexus' ),
			)
		);
	}

	/* ============================================================
	 *  admin-post.php?action=wpwebmcp_log_csv — chunked CSV stream
	 * ============================================================ */

	public static function stream_csv(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Forbidden.', 'webmcp-nexus' ), esc_html__( 'WebMCP Nexus', 'webmcp-nexus' ), array( 'response' => 403 ) );
		}
		check_admin_referer( 'wpwebmcp_log_csv', '_wpwebmcp_log_csv_nonce' );

		// Read filters from $_GET so the same URL pattern works.
		$args = array(
			'tool_name' => isset( $_GET['tool_name'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['tool_name'] ) ) : '',
			'status'    => isset( $_GET['status'] )    ? sanitize_text_field( wp_unslash( (string) $_GET['status'] ) )    : '',
			'date_from' => isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['date_from'] ) ) : '',
			'date_to'   => isset( $_GET['date_to'] )   ? sanitize_text_field( wp_unslash( (string) $_GET['date_to'] ) )   : '',
			'per_page'  => 0,
			'offset'    => 0,
		);

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		$today = gmdate( 'Y-m-d' );
		header( 'Content-Disposition: attachment; filename="wp-webmcp-log-' . $today . '.csv"' );

		$out = fopen( 'php://output', 'w' );
		// Header row.
		fputcsv(
			$out,
			array( 'id', 'tool_name', 'status', 'user_id', 'ip_hashed', 'execution_ms', 'params', 'error_message', 'logged_at' )
		);

		$offset = 0;
		$max_rows = 0; // no upper bound — chunked by self::CSV_CHUNK_SIZE.
		while ( true ) {
			$batch_args            = $args;
			$batch_args['per_page'] = self::CSV_CHUNK_SIZE;
			$batch_args['offset']   = $offset;
			$rows = class_exists( 'WP_WebMCP_Log_Repository' )
				? WP_WebMCP_Log_Repository::find( $batch_args )
				: array();
			if ( empty( $rows ) ) {
				break;
			}
			foreach ( $rows as $r ) {
				fputcsv(
					$out,
					array(
						(int) $r['id'],
						(string) $r['tool_name'],
						(string) $r['status'],
						(int) $r['user_id'],
						(string) $r['ip_hashed'],
						(int) $r['execution_ms'],
						is_array( $r['params'] ) ? wp_json_encode( $r['params'] ) : (string) $r['params'],
						(string) $r['error_message'],
						(string) $r['logged_at'],
					)
				);
			}
			$offset += self::CSV_CHUNK_SIZE;
			$max_rows += count( $rows );
			// Safety net — cap at 10,000 rows for sanity.
			if ( $max_rows > 10000 ) {
				break;
			}
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- log export CSV stream close; WP_Filesystem does not support stream resources
		@fclose( $out );
		exit;
	}
}