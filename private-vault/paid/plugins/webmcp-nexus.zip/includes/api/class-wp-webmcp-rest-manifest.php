<?php
/**
 * REST_Manifest — Doc §7.3.
 *
 * Owner of the public GET /wpwebmcp/v1/manifest route per Doc §7.1
 * (manifest row in the route ownership table). Public but role-filtered:
 * the tools returned for the caller are filtered by Access_Control
 * (the schema builder uses the same filter, so this endpoint stays in
 * sync with what the head renderer would produce).
 *
 * Query args:
 *   - post_id (int, optional) — preview a specific post's manifest.
 *     Anonymous: 404 always (no draft preview). Authenticated: allowed
 *     only for posts the caller can edit_post on, otherwise 404.
 *   - format (string, optional) — `format=mcp` wraps as JSON-RPC 2.0
 *     and strips every `x-webmcp-*` extension key per Doc §7.3.
 *
 * Response shape: same as `WP_WebMCP_Schema_Builder::build()` for the
 * default format; `format=mcp` wraps to `{ "jsonrpc": "2.0", "result":
 * { "tools": [...] } }`.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_REST_Manifest {

	/** Capability required to *manage* the plugin. Public route — no cap needed. */
	private const CAPABILITY_MANAGE = 'manage_options';

	/**
	 * Singleton hook entry. Called from WP_WebMCP::define_api_hooks().
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Register the GET /manifest route.
	 */
	public static function register_routes(): void {
		register_rest_route(
			'wpwebmcp/v1',
			'/manifest',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_manifest' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'post_id' => array(
						'type'              => 'integer',
						'required'          => false,
						'sanitize_callback' => 'absint',
					),
					'format' => array(
						'type'              => 'string',
						'required'          => false,
						'default'           => '',
						'enum'              => array( '', 'mcp' ),
					),
				),
			)
		);
	}

	/**
	 * GET /manifest handler — public but role-filtered per Doc §7.3.
	 *
	 * Flow:
	 *   1. If ?post_id=N present:
	 *      - Anonymous caller → 404 (no draft preview per spec).
	 *      - Logged-in but no `edit_post` on N → 404.
	 *      - Otherwise pass `current_screen=admin-post-id-N` so the schema
	 *        builder uses the single-post context.
	 *   2. Resolve role via `WP_WebMCP_Access_Control::get_current_role()`
	 *      and pull the saved `wpwebmcp_role_access` matrix to feed the
	 *      schema builder.
	 *   3. Build the manifest via `WP_WebMCP_Schema_Builder::build()`
	 *      with that role filter applied.
	 *   4. If `format=mcp`: wrap as JSON-RPC and strip x-webmcp-* keys.
	 */
	public static function get_manifest( WP_REST_Request $request ) {
		$post_id = (int) $request->get_param( 'post_id' );
		$format   = (string) $request->get_param( 'format' );

		// ---- 1. post_id gating ----
		if ( $post_id > 0 ) {
			if ( ! is_user_logged_in() ) {
				return new WP_REST_Response( null, 404 );
			}
			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				return new WP_REST_Response( null, 404 );
			}
		}

		// ---- 2. role + access matrix ----
		$role     = self::resolve_role();
		$matrix   = (array) get_option( 'wpwebmcp_role_access', array() );
		$built    = self::build_filtered( $role, $matrix, $post_id );

		// ---- 4. format=mcp wrapper ----
		if ( 'mcp' === $format ) {
			$built = self::strip_extensions( $built );
			return rest_ensure_response(
				array(
					'jsonrpc' => '2.0',
					'result'  => $built,
				)
			);
		}

		return rest_ensure_response( $built );
	}

	/**
	 * Resolve the current caller's role key (Step 10 owns this officially;
	 * here we inline a minimal resolver so Step 7 doesn't depend on Step 10).
	 *
	 * @return string
	 */
	private static function resolve_role(): string {
		if ( ! is_user_logged_in() ) {
			return 'anonymous';
		}
		$user = wp_get_current_user();
		if ( empty( $user->roles ) || ! is_array( $user->roles ) ) {
			return 'anonymous';
		}
		return (string) $user->roles[0];
	}

	/**
	 * Build the manifest with the role filter applied.
	 *
	 * @param string $role
	 * @param array<string, array<int, string>> $matrix wpwebmcp_role_access.
	 * @param int $post_id 0 for current page context, >0 for preview.
	 *
	 * @return array<string,mixed>
	 */
	private static function build_filtered( string $role, array $matrix, int $post_id ): array {
		if ( $post_id > 0 ) {
			return WP_WebMCP_Schema_Builder::build( 'single', $post_id, $role );
		} elseif ( is_home() || is_front_page() ) {
			return WP_WebMCP_Schema_Builder::build( 'homepage', 0, $role );
		} elseif ( is_search() ) {
			return WP_WebMCP_Schema_Builder::build( 'search', 0, $role );
		} elseif ( is_404() ) {
			return WP_WebMCP_Schema_Builder::build( '404', 0, $role );
		} elseif ( is_archive() ) {
			return WP_WebMCP_Schema_Builder::build( 'archive', 0, $role );
		} elseif ( function_exists( 'is_product' ) && ( is_product() || ( function_exists( 'is_shop' ) && is_shop() ) ) ) {
			return WP_WebMCP_Schema_Builder::build( 'woo', 0, $role );
		} elseif ( is_singular() ) {
			return WP_WebMCP_Schema_Builder::build( 'single', 0, $role );
		} else {
			return WP_WebMCP_Schema_Builder::build( 'homepage', 0, $role );
		}
	}

	/**
	 * Closure factory for the role filter.
	 */
	private static function role_filter_callback( string $role ): callable {
		return static function () use ( $role ) {
			return $role;
		};
	}

	/**
	 * Closure factory for the option pre-filter.
	 *
	 * @param array $matrix
	 */
	private static function option_filter_callback( array $matrix ): callable {
		return static function () use ( $matrix ) {
			return $matrix;
		};
	}

	/**
	 * Strip every `x-webmcp-*` extension key from the manifest. Used for
	 * the JSON-RPC `format=mcp` shape per Doc §7.3.
	 *
	 * @param array<string,mixed> $manifest
	 * @return array<string,mixed>
	 */
	private static function strip_extensions( array $manifest ): array {
		if ( isset( $manifest['tools'] ) && is_array( $manifest['tools'] ) ) {
			foreach ( $manifest['tools'] as &$tool ) {
				if ( ! is_array( $tool ) ) {
					continue;
				}
				foreach ( array_keys( $tool ) as $k ) {
					if ( is_string( $k ) && 0 === strpos( $k, 'x-webmcp-' ) ) {
						unset( $tool[ $k ] );
					}
				}
			}
			unset( $tool );
		}
		if ( isset( $manifest['site'] ) && is_array( $manifest['site'] ) ) {
			foreach ( array_keys( $manifest['site'] ) as $k ) {
				if ( is_string( $k ) && 0 === strpos( $k, 'x-webmcp-' ) ) {
					unset( $manifest['site'][ $k ] );
				}
			}
		}
		return $manifest;
	}
}