<?php
/**
 * REST_Policies — Module A A2a (Visual policy builder).
 *
 * Admin-only REST routes to manage per-agent access policies. The visual
 * policy-builder page on top of these routes is purely UI sugar over the
 * same shape — admins can also script policy changes from wp-cli or any
 * REST client.
 *
 * Routes:
 *   GET    /wp-json/wpwebmcp/v1/policies
 *          200: { ok, policies: [{id, name, ...}], option_sets: {match_types, actions} }
 *
 *   POST   /wp-json/wpwebmcp/v1/policies
 *          body: { id?, name, enabled?, priority?, match_type, match_value?, action,
 *                  rate_limit_per_minute?, custom_message?, redact_email? }
 *          201: { ok, policy: { ... } }
 *
 *   POST   /wp-json/wpwebmcp/v1/policies/delete
 *          body: { id }
 *          200: { ok, deleted: true }   or   { ok, deleted: false, reason: 'not_found' }
 *
 *   POST   /wp-json/wpwebmcp/v1/policies/evaluate
 *          body: { agent_slug: string, family: string }
 *          200: { ok, matched: { ... } | null }
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_REST_Policies {

	public static function register_routes(): void {
		$ns = 'wpwebmcp/v1';

		register_rest_route(
			$ns,
			'/policies',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle_list' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			)
		);

		register_rest_route(
			$ns,
			'/policies',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_save' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			)
		);

		register_rest_route(
			$ns,
			'/policies/delete',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_delete' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'id' => array( 'required' => true, 'type' => 'string' ),
				),
			)
		);

		register_rest_route(
			$ns,
			'/policies/evaluate',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_evaluate' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'agent_slug' => array( 'required' => false, 'type' => 'string', 'default' => '' ),
					'family'     => array( 'required' => false, 'type' => 'string', 'default' => '' ),
				),
			)
		);
	}

	public static function check_admin(): bool {
		return current_user_can( 'manage_options' );
	}

	public static function handle_list() {
		return rest_ensure_response(
			array(
				'ok'          => true,
				'policies'    => WP_WebMCP_Policy::all(),
				'option_sets' => WP_WebMCP_Policy::option_sets(),
			)
		);
	}

	public static function handle_save( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			$body = $request->get_body_params();
		}
		if ( ! is_array( $body ) ) {
			return new WP_Error( 'wpwebmcp_policy_bad_input', __( 'JSON body required.', 'webmcp-nexus' ), array( 'status' => 400 ) );
		}
		$saved = WP_WebMCP_Policy::save( $body );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}
		return rest_ensure_response(
			array(
				'ok'      => true,
				'policy'  => $saved,
			)
		);
	}

	public static function handle_delete( WP_REST_Request $request ) {
		$id = (string) $request->get_param( 'id' );
		$deleted = WP_WebMCP_Policy::delete( $id );
		return rest_ensure_response(
			array(
				'ok'      => true,
				'deleted' => $deleted,
				'id'      => $id,
			)
		);
	}

	public static function handle_evaluate( WP_REST_Request $request ) {
		$agent_slug = (string) $request->get_param( 'agent_slug' );
		$family     = (string) $request->get_param( 'family' );
		// Synthesize the agent array shape that WP_WebMCP_Agent_Identity would
		// produce — admins can dry-run the gate against any agent slug/family
		// without actually issuing a tool call.
		$is_known = '' !== $agent_slug && 'unknown' !== $agent_slug;
		$agent    = array(
			'slug'      => $agent_slug,
			'family'    => $family,
			'is_user'   => false,
			'confidence'=> $is_known ? 'medium' : 'none',
		);
		$matched = WP_WebMCP_Policy::evaluate_for_agent( $agent );
		return rest_ensure_response(
			array(
				'ok'      => true,
				'matched' => $matched,
			)
		);
	}
}
