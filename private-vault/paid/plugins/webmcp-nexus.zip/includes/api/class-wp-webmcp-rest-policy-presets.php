<?php
/**
 * REST_Policy_Presets — Module A A2c (Policy template library).
 *
 * Admin-only REST routes that expose the policy-preset library.
 * Reuses WP_WebMCP_Policy_Presets for the data and WP_WebMCP_Policy for
 * the underlying save path, so the visual policy builder picks up applied
 * rows automatically.
 *
 * Routes:
 *   GET    /wp-json/wpwebmcp/v1/policy-presets
 *          200: { ok, presets: [ {slug, name, icon, tagline, description, policy_count} ] }
 *
 *   GET    /wp-json/wpwebmcp/v1/policy-presets/{slug}
 *          200: { ok, preset: { slug, name, icon, tagline, description, policies: [ ... ] } }
 *          404: when slug not found
 *
 *   POST   /wp-json/wpwebmcp/v1/policy-presets/apply
 *          body: { slug: string }
 *          200: { ok, created, skipped, inserted_ids }
 *          400: when slug missing or unknown
 *
 *   POST   /wp-json/wpwebmcp/v1/policy-presets/remove
 *          body: { slug: string }
 *          200: { ok, deleted }
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_REST_Policy_Presets {

	public static function register_routes(): void {
		$ns = 'wpwebmcp/v1';

		register_rest_route(
			$ns,
			'/policy-presets',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle_list' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			)
		);

		register_rest_route(
			$ns,
			'/policy-presets/(?P<slug>[a-z0-9_\-]+)',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle_get' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'slug' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_key',
					),
				),
			)
		);

		register_rest_route(
			$ns,
			'/policy-presets/apply',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_apply' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'slug' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_key',
					),
				),
			)
		);

		register_rest_route(
			$ns,
			'/policy-presets/remove',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_remove' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'slug' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_key',
					),
				),
			)
		);
	}

	public static function check_admin(): bool {
		return current_user_can( 'manage_options' );
	}

	public static function handle_list() {
		return rest_ensure_response(
			array(
				'ok'      => true,
				'presets' => WP_WebMCP_Policy_Presets::get_summary(),
			)
		);
	}

	public static function handle_get( WP_REST_Request $request ) {
		$slug   = (string) $request->get_param( 'slug' );
		$preset = WP_WebMCP_Policy_Presets::get( $slug );
		if ( null === $preset ) {
			return new WP_Error(
				'wpwebmcp_policy_preset_unknown',
				__( 'Unknown policy preset slug.', 'webmcp-nexus' ),
				array( 'status' => 404 )
			);
		}
		return rest_ensure_response(
			array(
				'ok'     => true,
				'preset' => $preset,
			)
		);
	}

	public static function handle_apply( WP_REST_Request $request ) {
		$slug = (string) $request->get_param( 'slug' );
		$result = WP_WebMCP_Policy_Presets::apply( $slug );
		if ( empty( $result['ok'] ) ) {
			$reason = isset( $result['error'] ) ? (string) $result['error'] : 'unknown';
			$status = ( 'unknown_preset' === $reason ) ? 404 : 500;
			return new WP_Error(
				'wpwebmcp_policy_preset_apply_failed',
				$reason,
				array( 'status' => $status, 'reason' => $reason )
			);
		}
		return rest_ensure_response( $result );
	}

	public static function handle_remove( WP_REST_Request $request ) {
		$slug = (string) $request->get_param( 'slug' );
		if ( null === WP_WebMCP_Policy_Presets::get( $slug ) ) {
			return new WP_Error(
				'wpwebmcp_policy_preset_unknown',
				__( 'Unknown policy preset slug.', 'webmcp-nexus' ),
				array( 'status' => 404 )
			);
		}
		$deleted = WP_WebMCP_Policy_Presets::remove( $slug );
		return rest_ensure_response(
			array(
				'ok'      => true,
				'slug'    => $slug,
				'deleted' => $deleted,
			)
		);
	}
}
