<?php
/**
 * REST_Tools — Doc §7.1/§7.2/§7.5 + Part 8.
 *
 * 5-stage pipeline for `POST /wpwebmcp/v1/call/{slug}` (Doc §7.2 EXACTLY):
 *   1. Sanitize slug + 16 KB body cap  →  413 if over.
 *   2. Rate limit                       →  429 + Retry-After:60 + rate_limited log.
 *   3. Write-tool auth (3 proofs)       →  401 + auth_failed log if all fail.
 *   4. Role gate                        →  403 if matrix denies.
 *   5. Executor resolve                →  404 if unknown.
 *      Execute → sanitize → success log → 200 with wpwebmcp_tool_call_response filter.
 *
 * Also owns:
 *   - GET /wpwebmcp/v1/health  → 200 { version, score, counts } for admin.
 *   - record_analytics()      → POST /wpwebmcp/v1/analytics soft-throttle
 *     (30/min/IP-hash, transient counter; over → 202 + no DB write).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.NonceVerification.Recommended,WordPress.PHP.DevelopmentFunctions.error_log_error_log -- HTTP_ORIGIN is for CORS validation (header, not user input); form processing uses wp_ajax_* nonce check; error_log is admin debugging only
final class WP_WebMCP_Tools {

	/** Body cap (Doc §7.2). */
	private const MAX_BODY_BYTES = 16 * 1024;

	/** Soft-throttle window (Doc §7.5). */
	private const ANALYTICS_LIMIT_PER_MIN = 30;

	/**
	 * Singleton hook entry — wired from WP_WebMCP::define_api_hooks().
	 *
	 * Registers `POST /call/{slug}`, `POST /analytics`, `GET /health`.
	 * The per-tool permission_callback returns true (public reads per
	 * §7.3) and the write-auth check happens inside `execute_tool()`.
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		WP_WebMCP_Loader::register_filter( 'rest_pre_serve_request', array( __CLASS__, 'send_cors_headers' ), 10, 4 );
		WP_WebMCP_Loader::register_filter( 'rest_pre_eager_response', array( __CLASS__, 'agent_identity_headers' ), 10, 1 );
	}

	public static function register_routes(): void {
		$ns = 'wpwebmcp/v1';

		// /call/{slug} — GET (read tools) & POST (all tools).
		register_rest_route(
			$ns,
			'/call/(?P<slug>[A-Za-z0-9_\-]+)',
			array(
				'methods'             => array( 'GET', 'POST' ),
				'callback'            => array( __CLASS__, 'execute_tool' ),
				'permission_callback' => '__return_true',
				'args'                => array(),
			)
		);

		// /tools — GET: List all available tools with metadata & schemas
		register_rest_route(
			$ns,
			'/tools',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_tools_index' ),
				'permission_callback' => '__return_true',
			)
		);

		// /mcp & /rpc — POST & OPTIONS: Official Model Context Protocol JSON-RPC 2.0 endpoint
		register_rest_route(
			$ns,
			'/mcp',
			array(
				'methods'             => array( 'POST', 'OPTIONS' ),
				'callback'            => array( __CLASS__, 'execute_mcp_rpc' ),
				'permission_callback' => '__return_true',
			)
		);
		register_rest_route(
			$ns,
			'/rpc',
			array(
				'methods'             => array( 'POST', 'OPTIONS' ),
				'callback'            => array( __CLASS__, 'execute_mcp_rpc' ),
				'permission_callback' => '__return_true',
			)
		);

		// /sse & /mcp/sse — GET: Standard MCP Server-Sent Events transport endpoint
		register_rest_route(
			$ns,
			'/sse',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'serve_sse' ),
				'permission_callback' => '__return_true',
			)
		);
		register_rest_route(
			$ns,
			'/mcp/sse',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'serve_sse' ),
				'permission_callback' => '__return_true',
			)
		);

		// /analytics — POST ONLY per Doc §7.5.
		register_rest_route(
			$ns,
			'/analytics',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'record_analytics' ),
				'permission_callback' => '__return_true',
			)
		);

		// /health — GET (admin).
		register_rest_route(
			$ns,
			'/health',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_health' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			)
		);

		// /health/validate — POST (admin).
		register_rest_route(
			$ns,
			'/health/validate',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'validate_health' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			)
		);
	}

	public static function check_admin(): bool {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Automatically add CORS headers for WebMCP REST endpoints and handle OPTIONS preflights.
	 *
	 * @param bool             $served  Whether the request has already been served.
	 * @param WP_REST_Response $result  The response result.
	 * @param WP_REST_Request  $request The request object.
	 * @param WP_REST_Server   $server  Server instance.
	 * @return bool
	 */
	public static function send_cors_headers( $served, $result, $request, $server ) {
		$origin = isset( $_SERVER['HTTP_ORIGIN'] ) ? (string) $_SERVER['HTTP_ORIGIN'] : '*';
		header( 'Access-Control-Allow-Origin: ' . ( '' !== $origin ? $origin : '*' ) );
		header( 'Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS, HEAD' );
		header( 'Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce, X-WC-Nonce, Mcp-Session-Id, Cache-Control, Pragma, Accept, X-Requested-With' );
		header( 'Access-Control-Allow-Credentials: true' );
		header( 'Access-Control-Expose-Headers: Link, X-WebMCP, X-ModelContextProtocol, X-MCP-Server, Retry-After' );
		if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'OPTIONS' === $_SERVER['REQUEST_METHOD'] ) {
			status_header( 200 );
			exit;
		}
		return $served;
	}

	/* ============================================================
	 *  POST /call/{slug} & GET /call/{slug} — 5-stage pipeline
	 * ============================================================ */

	public static function execute_tool( WP_REST_Request $request ) {
		$t0 = microtime( true );

		try {
			// ---- Stage 1: sanitize slug + 16 KB body cap ----
			$slug = sanitize_text_field( (string) $request->get_param( 'slug' ) );
			if ( '' === $slug ) {
				return new WP_Error( 'wpwebmcp_bad_params', __( 'Missing tool slug.', 'webmcp-nexus' ), array( 'status' => 400 ) );
			}
			$body = (string) $request->get_body();
			if ( strlen( $body ) > self::MAX_BODY_BYTES ) {
				return new WP_Error( 'wpwebmcp_payload_too_large', __( 'Request body exceeds 16 KB.', 'webmcp-nexus' ), array( 'status' => 413 ) );
			}

			// Gather params from all request sources (JSON body, POST body, GET query params)
			$query_params = (array) $request->get_query_params();
			$json_params  = (array) $request->get_json_params();
			$body_params  = (array) $request->get_body_params();
			$params       = array_merge( $query_params, $body_params, $json_params );

			if ( isset( $params['params'] ) && is_array( $params['params'] ) ) {
				$nested = $params['params'];
				unset( $params['params'] );
				$params = array_merge( $params, $nested );
			}
			if ( isset( $params['arguments'] ) && is_array( $params['arguments'] ) ) {
				$nested = $params['arguments'];
				unset( $params['arguments'] );
				$params = array_merge( $params, $nested );
			}

			// ---- Resolve the tool + read its write-ness BEFORE rate limit so
			// the limiter sees the correct tool-type cap. ----
			$tool = class_exists( 'WP_WebMCP_Tool_Executor' )
				? WP_WebMCP_Tool_Executor::resolve( $slug )
				: null;
			if ( null === $tool ) {
				// Unknown tool — log as error + 404.
				if ( class_exists( 'WP_WebMCP_Logger' ) ) {
					WP_WebMCP_Logger::write( $slug, $params, 'error', 'Unknown tool', get_current_user_id(), 0 );
				}
				return new WP_Error( 'wpwebmcp_unknown_tool', __( 'Unknown tool.', 'webmcp-nexus' ), array( 'status' => 404 ) );
			}
			$is_write = (bool) $tool['is_write'];

			// Write tools require POST
			if ( $is_write && 'GET' === $request->get_method() ) {
				return new WP_Error(
					'wpwebmcp_method_not_allowed',
					__( 'Write tools must be executed via POST requests.', 'webmcp-nexus' ),
					array( 'status' => 405 )
				);
			}

			// ---- Stage 1.5 (M0c): agent identity resolve + blocklist ----
			$agent_id = (bool) get_option( 'wpwebmcp_agent_identity_enabled', true )
				? ( class_exists( 'WP_WebMCP_Agent_Identity' ) ? WP_WebMCP_Agent_Identity::resolve() : null )
				: null;
			if ( is_array( $agent_id ) ) {
				$agent_slug = (string) ( $agent_id['slug'] ?? 'unknown' );

				// Blocklist (UA substring match). Hard reject before rate limit.
				$blocklist = (array) get_option( 'wpwebmcp_agent_blocklist', array() );
				if ( ! empty( $blocklist ) ) {
					$ua_lower = strtolower( (string) ( $agent_id['ua'] ?? '' ) );
					foreach ( $blocklist as $frag ) {
						if ( '' !== $frag && false !== strpos( $ua_lower, strtolower( (string) $frag ) ) ) {
							if ( class_exists( 'WP_WebMCP_Logger' ) ) {
								WP_WebMCP_Logger::write( $slug, $params, 'auth_failed', 'Agent blocklist hit: ' . (string) $frag, get_current_user_id(), 0, $agent_slug );
							}
							return new WP_Error(
								'wpwebmcp_agent_blocked',
								__( 'Caller is on the agent blocklist.', 'webmcp-nexus' ),
								array( 'status' => 403 )
							);
						}
					}
				}

				// Per-agent admin toggle (enabled=false -> deny).
				if ( class_exists( 'WP_WebMCP_Rate_Limiter' ) && ! WP_WebMCP_Rate_Limiter::agent_allowed( $agent_slug ) ) {
					if ( class_exists( 'WP_WebMCP_Logger' ) ) {
						WP_WebMCP_Logger::write( $slug, $params, 'auth_failed', 'Agent disabled by admin: ' . $agent_slug, get_current_user_id(), 0, $agent_slug );
					}
					return new WP_Error(
						'wpwebmcp_agent_disabled',
						__( 'This agent has been disabled by the site administrator.', 'webmcp-nexus' ),
						array( 'status' => 403 )
					);
				}

				// Per-agent rate limit (M0c). Falls through when no override is set.
				if ( class_exists( 'WP_WebMCP_Rate_Limiter' ) && ! WP_WebMCP_Rate_Limiter::check_limit_for_agent( $slug, $agent_slug ) ) {
					if ( class_exists( 'WP_WebMCP_Logger' ) ) {
						WP_WebMCP_Logger::write( $slug, $params, 'rate_limited', 'Per-agent limit: ' . $agent_slug, get_current_user_id(), 0, $agent_slug );
					}
					return new WP_Error(
						'wpwebmcp_agent_rate_limited',
						__( 'Per-agent rate limit exceeded.', 'webmcp-nexus' ),
						array( 'status' => 429, 'retry_after' => 60 )
					);
				}
			}

			// Normalize agent_slug so downstream stages (A2a policy eval) always see a value.
			if ( ! isset( $agent_slug ) || ! is_string( $agent_slug ) || '' === $agent_slug ) {
				$agent_slug = 'unknown';
			}

			// ---- Stage 1.7 (A2a): visual policy builder ----
			// Evaluates per-agent rules (allow / block / rate_limit / redact_email)
			// sorted by priority ascending. First match wins.
			if ( class_exists( 'WP_WebMCP_Policy' ) ) {
				$matched_policy = WP_WebMCP_Policy::evaluate_for_agent( $agent_id );
				if ( is_array( $matched_policy ) ) {
					$policy_action = (string) ( $matched_policy['action'] ?? 'allow' );

					if ( 'block' === $policy_action ) {
						if ( class_exists( 'WP_WebMCP_Logger' ) ) {
							WP_WebMCP_Logger::write( $slug, $params, 'auth_failed', 'Policy block: ' . (string) ( $matched_policy['id'] ?? '' ) . ' (' . (string) ( $matched_policy['label'] ?? '' ) . ')', get_current_user_id(), 0, $agent_slug );
						}
						return new WP_Error(
							'wpwebmcp_policy_blocked',
							(string) ( $matched_policy['block_message'] ?? __( 'Access denied by site policy.', 'webmcp-nexus' ) ),
							array(
								'status'      => 403,
								'policy_id'   => (string) ( $matched_policy['id'] ?? '' ),
								'policy_name' => (string) ( $matched_policy['label'] ?? '' ),
								'claim_url'   => (string) ( $matched_policy['claim_url'] ?? ( function_exists( 'home_url' ) ? home_url( '/wp-admin/admin.php?page=wp-webmcp-agents&action=claim' ) : '' ) ),
							)
						);
					}

					if ( 'rate_limit' === $policy_action && class_exists( 'WP_WebMCP_Rate_Limiter' ) ) {
						$policy_limit = isset( $matched_policy['rate_limit_per_minute'] ) ? (int) $matched_policy['rate_limit_per_minute'] : 0;
						if ( $policy_limit > 0 && ! WP_WebMCP_Rate_Limiter::check_limit_for_agent( $slug, 'policy:' . (string) ( $matched_policy['id'] ?? 'unknown' ), $policy_limit ) ) {
							if ( class_exists( 'WP_WebMCP_Logger' ) ) {
								WP_WebMCP_Logger::write( $slug, $params, 'rate_limited', 'Policy rate-limit: ' . (string) ( $matched_policy['id'] ?? '' ), get_current_user_id(), 0, $agent_slug );
							}
							return new WP_Error(
								'wpwebmcp_policy_rate_limited',
								__( 'Policy rate limit exceeded.', 'webmcp-nexus' ),
								array(
									'status'      => 429,
									'retry_after' => 60,
									'policy_id'   => (string) ( $matched_policy['id'] ?? '' ),
								)
							);
						}
					}

					// 'allow' and 'redact_email' fall through; redaction is applied in Stage 6.
				}
			}

			// ---- Stage 2: rate limit ----
			if ( class_exists( 'WP_WebMCP_Rate_Limiter' ) && ! WP_WebMCP_Rate_Limiter::check_limit( $slug ) ) {
				// 429 + Retry-After header (filter on rest_pre_eager_response).
				WP_WebMCP_Loader::register_filter( 'rest_pre_eager_response', array( __CLASS__, 'rate_limit_headers' ), 10, 1 );
				if ( class_exists( 'WP_WebMCP_Logger' ) ) {
					$agent_log = is_array( $agent_id ) ? (string) ( $agent_id['slug'] ?? 'unknown' ) : 'unknown';
					WP_WebMCP_Logger::write( $slug, $params, 'rate_limited', 'Global rate limit', get_current_user_id(), 0, $agent_log );
				}
				return new WP_Error(
					'wpwebmcp_rate_limited',
					__( 'Rate limit exceeded.', 'webmcp-nexus' ),
					array( 'status' => 429, 'retry_after' => 60 )
				);
			}

			// ---- Stage 3: write-tool auth (3 proofs) ----
			if ( $is_write && ! self::can_execute_write_tool( $slug ) ) {
				if ( class_exists( 'WP_WebMCP_Logger' ) ) {
					WP_WebMCP_Logger::write( $slug, $params, 'auth_failed', 'Write tool denied', get_current_user_id(), 0 );
				}
				return new WP_Error(
					'wpwebmcp_auth_required',
					__( 'Write tool requires authentication.', 'webmcp-nexus' ),
					array( 'status' => 401 )
				);
			}

			// ---- Stage 4: role gate (Access_Control) ----
			$type = $is_write ? 'write' : 'read';
			if ( class_exists( 'WP_WebMCP_Access_Control' ) && ! WP_WebMCP_Access_Control::current_role_can( $type ) ) {
				return new WP_Error(
					'wpwebmcp_forbidden',
					__( 'Role does not permit this tool type.', 'webmcp-nexus' ),
					array( 'status' => 403 )
				);
			}

			// ---- Stage 5: execute → sanitize → log success → 200 ----
			$result = (array) call_user_func( $tool['runner'], $params );

			// Sanitize (Step 12 lands — guard with class_exists + method_exists).
			// A2b: thread request headers so the citation gate can verify
			// X-Provide-Citation-Proof / X-Premium-Receipt tokens.
			if ( class_exists( 'WP_WebMCP_Sanitizer' ) && method_exists( 'WP_WebMCP_Sanitizer', 'clean_result' ) ) {
				$result = WP_WebMCP_Sanitizer::clean_result( $result, $request->get_headers() );
			}

			// A2a: policy redact_email — applied AFTER sanitize so redaction
			// pattern isn't accidentally stripped by content sanitization.
			if ( class_exists( 'WP_WebMCP_Policy' ) ) {
				$matched_policy_redact = WP_WebMCP_Policy::evaluate_for_agent( $agent_id );
				if ( is_array( $matched_policy_redact ) && 'redact_email' === (string) ( $matched_policy_redact['action'] ?? '' ) ) {
					$result = WP_WebMCP_Policy::apply_redactions( $result, $matched_policy_redact );
				}
			}

			$ms = (int) round( ( microtime( true ) - $t0 ) * 1000 );
			if ( class_exists( 'WP_WebMCP_Logger' ) ) {
				$agent_log = is_array( $agent_id ) ? (string) ( $agent_id['slug'] ?? 'unknown' ) : 'unknown';
				WP_WebMCP_Logger::write( $slug, $params, 'success', '', get_current_user_id(), $ms, $agent_log );
			}

			/**
			 * Filter the final tool-call response. Step 9 spec gives this filter
			 * name in the pipeline.
			 *
			 * @param array  $result  Tool executor output.
			 * @param string $slug    Tool slug.
			 * @param array  $params  Sanitized input params.
			 */
			$result = (array) apply_filters( 'wpwebmcp_tool_call_response', $result, $slug, $params );

			// Return shape mirrors the schema-builder's "ok"-wrapped payloads.
			if ( 'mcp' === $request->get_param( 'format' ) ) {
				$text_content = wp_json_encode( $result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
				return rest_ensure_response(
					array(
						'jsonrpc' => '2.0',
						'result'  => array(
							'content'           => array(
								array(
									'type' => 'text',
									'text' => $text_content,
								),
							),
							'isError'           => ( isset( $result['ok'] ) && false === $result['ok'] ),
							'structuredContent' => $result,
						),
					)
				);
			}

			return rest_ensure_response(
				array_merge( array( 'ok' => true, 'tool' => $slug, 'ms' => $ms ), $result )
			);
		} catch ( Throwable $e ) {
			$slug_log = isset( $slug ) ? $slug : 'unknown';
			$params_log = isset( $params ) ? $params : array();
			if ( class_exists( 'WP_WebMCP_Logger' ) ) {
				WP_WebMCP_Logger::write( $slug_log, $params_log, 'error', $e->getMessage(), get_current_user_id(), 0 );
			}
			if ( class_exists( 'WP_WebMCP_Alerts' ) ) {
				try {
					$alerts = new WP_WebMCP_Alerts();
					if ( method_exists( $alerts, 'send_error_alert' ) ) {
						$alerts->send_error_alert( $slug_log, $e->getMessage() );
					}
				} catch ( Throwable $ignore ) {
					// alerts is best-effort; never break the caller.
				}
			}
			$error_data = array( 'status' => 500 );
			if ( ( defined( 'WP_DEBUG' ) && WP_DEBUG ) || isset( $_REQUEST['debug'] ) ) {
				$error_data['debug_file'] = $e->getFile();
				$error_data['debug_line'] = $e->getLine();
				$error_data['debug_trace'] = $e->getTraceAsString();
			}
			return new WP_Error(
				'wpwebmcp_execution_failed',
				$e->getMessage(),
				$error_data
			);
		}
	}

	/**
	 * Official Model Context Protocol JSON-RPC 2.0 handler.
	 *
	 * Supports: initialize, notifications/initialized, ping, tools/list,
	 * tools/call, resources/list, resources/read, prompts/list, prompts/get.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public static function execute_mcp_rpc( WP_REST_Request $request ) {
		$json = $request->get_json_params();
		if ( ! is_array( $json ) ) {
			return rest_ensure_response(
				array(
					'jsonrpc' => '2.0',
					'id'      => null,
					'error'   => array(
						'code'    => -32700,
						'message' => 'Parse error: Invalid JSON payload',
					),
				)
			);
		}

		$id     = $json['id'] ?? 1;
		$method = (string) ( $json['method'] ?? '' );
		$params = is_array( $json['params'] ?? null ) ? $json['params'] : array();

		switch ( $method ) {
			case 'initialize':
				return rest_ensure_response(
					array(
						'jsonrpc' => '2.0',
						'id'      => $id,
						'result'  => array(
							'protocolVersion' => '2024-11-05',
							'capabilities'    => array(
								'tools'     => array( 'listChanged' => false ),
								'resources' => array( 'listChanged' => false ),
								'prompts'   => array( 'listChanged' => false ),
							),
							'serverInfo'      => array(
								'name'    => 'WebMCP Nexus',
								'version' => defined( 'WEBMCP_NEXUS_VERSION' ) ? WEBMCP_NEXUS_VERSION : '1.0.0',
							),
							'instructions'    => sprintf(
								'WebMCP Nexus Model Context Protocol tool server for %s (%s). Provides content search, site navigation, post discovery, metadata retrieval, media queries, and tools execution.',
								(string) get_bloginfo( 'name' ),
								(string) home_url()
							),
						),
					)
				);

			case 'notifications/initialized':
				return rest_ensure_response( array( 'jsonrpc' => '2.0', 'result' => true ) );

			case 'ping':
				return rest_ensure_response(
					array(
						'jsonrpc' => '2.0',
						'id'      => $id,
						'result'  => new stdClass(),
					)
				);

			case 'tools/list':
				$all_tools = class_exists( 'WP_WebMCP_Schema_Builder' )
					? WP_WebMCP_Schema_Builder::get_all_tools()
					: array();

				$tools_list = array();
				foreach ( $all_tools as $tool ) {
					$schema = isset( $tool['inputSchema'] ) && is_array( $tool['inputSchema'] )
						? $tool['inputSchema']
						: array( 'type' => 'object', 'properties' => new stdClass() );

					$tools_list[] = array(
						'name'        => (string) $tool['name'],
						'description' => (string) ( $tool['description'] ?? '' ),
						'inputSchema' => $schema,
					);
				}

				return rest_ensure_response(
					array(
						'jsonrpc' => '2.0',
						'id'      => $id,
						'result'  => array(
							'tools' => $tools_list,
						),
					)
				);

			case 'tools/call':
				$tool_name = (string) ( $params['name'] ?? '' );
				$tool_args = is_array( $params['arguments'] ?? null ) ? $params['arguments'] : ( is_array( $params['params'] ?? null ) ? $params['params'] : array() );

				if ( '' === $tool_name ) {
					return rest_ensure_response(
						array(
							'jsonrpc' => '2.0',
							'id'      => $id,
							'error'   => array(
								'code'    => -32602,
								'message' => 'Invalid params: Missing tool name',
							),
						)
					);
				}

				$resolved = class_exists( 'WP_WebMCP_Tool_Executor' )
					? WP_WebMCP_Tool_Executor::resolve( $tool_name )
					: null;

				if ( ! $resolved ) {
					return rest_ensure_response(
						array(
							'jsonrpc' => '2.0',
							'id'      => $id,
							'error'   => array(
								'code'    => -32601,
								'message' => sprintf( 'Tool "%s" not found', $tool_name ),
							),
						)
					);
				}

				// Check rate limit
				if ( class_exists( 'WP_WebMCP_Rate_Limiter' ) && ! WP_WebMCP_Rate_Limiter::check_limit( $tool_name ) ) {
					return rest_ensure_response(
						array(
							'jsonrpc' => '2.0',
							'id'      => $id,
							'error'   => array(
								'code'    => -32000,
								'message' => 'Rate limit exceeded. Please retry in 60 seconds.',
							),
						)
					);
				}

				// Check write-tool auth if write
				if ( ! empty( $resolved['is_write'] ) && ! self::can_execute_write_tool( $tool_name ) ) {
					return rest_ensure_response(
						array(
							'jsonrpc' => '2.0',
							'id'      => $id,
							'error'   => array(
								'code'    => -32001,
								'message' => 'Write tool requires authentication.',
							),
						)
					);
				}

				$t0 = microtime( true );
				try {
					$result = (array) call_user_func( $resolved['runner'], $tool_args );
					if ( class_exists( 'WP_WebMCP_Sanitizer' ) && method_exists( 'WP_WebMCP_Sanitizer', 'clean_result' ) ) {
						// A2b: forward the REST request headers so the citation
						// gate can verify the cited / premium tokens.
						$result = WP_WebMCP_Sanitizer::clean_result( $result, $request->get_headers() );
					}
					$ms = (int) round( ( microtime( true ) - $t0 ) * 1000 );
					if ( class_exists( 'WP_WebMCP_Logger' ) ) {
						WP_WebMCP_Logger::write( $tool_name, $tool_args, 'success', '', get_current_user_id(), $ms );
					}

					$text = wp_json_encode( $result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
					$is_err = ( isset( $result['ok'] ) && false === $result['ok'] );

					return rest_ensure_response(
						array(
							'jsonrpc' => '2.0',
							'id'      => $id,
							'result'  => array(
								'content'           => array(
									array(
										'type' => 'text',
										'text' => $text,
									),
								),
								'isError'           => $is_err,
								'structuredContent' => $result,
							),
						)
					);
				} catch ( Throwable $ex ) {
					return rest_ensure_response(
						array(
							'jsonrpc' => '2.0',
							'id'      => $id,
							'result'  => array(
								'content' => array(
									array(
										'type' => 'text',
										'text' => 'Execution error: ' . $ex->getMessage(),
									),
								),
								'isError' => true,
							),
						)
					);
				}

			case 'resources/list':
				$resources = array(
					array(
						'uri'         => 'wp://siteinfo',
						'name'        => 'Site Information',
						'description' => 'Current WordPress site metadata and configuration',
						'mimeType'    => 'application/json',
					),
					array(
						'uri'         => 'wp://sitemap',
						'name'        => 'Site Map',
						'description' => 'Index of all public URLs and post permalinks',
						'mimeType'    => 'application/json',
					),
				);

				$posts = get_posts(
					array(
						'post_type'      => array( 'post', 'page' ),
						'post_status'    => 'publish',
						'posts_per_page' => 10,
						'orderby'        => 'date',
						'order'          => 'DESC',
					)
				);
				foreach ( $posts as $p ) {
					$resources[] = array(
						'uri'         => sprintf( 'wp://post/%d', (int) $p->ID ),
						'name'        => (string) $p->post_title,
						'description' => (string) wp_trim_words( wp_strip_all_tags( $p->post_content ), 20 ),
						'mimeType'    => 'text/markdown',
					);
				}

				return rest_ensure_response(
					array(
						'jsonrpc' => '2.0',
						'id'      => $id,
						'result'  => array( 'resources' => $resources ),
					)
				);

			case 'resources/read':
				$uri = (string) ( $params['uri'] ?? '' );
				if ( 'wp://siteinfo' === $uri ) {
					$info = WP_WebMCP_Tool_Executor::builtin_get_site_info();
					return rest_ensure_response(
						array(
							'jsonrpc' => '2.0',
							'id'      => $id,
							'result'  => array(
								'contents' => array(
									array(
										'uri'      => $uri,
										'mimeType' => 'application/json',
										'text'     => wp_json_encode( $info, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ),
									),
								),
							),
						)
					);
				}
				if ( 'wp://sitemap' === $uri ) {
					$map = WP_WebMCP_Tool_Executor::builtin_get_site_map();
					return rest_ensure_response(
						array(
							'jsonrpc' => '2.0',
							'id'      => $id,
							'result'  => array(
								'contents' => array(
									array(
										'uri'      => $uri,
										'mimeType' => 'application/json',
										'text'     => wp_json_encode( $map, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ),
									),
								),
							),
						)
					);
				}
				if ( preg_match( '/^wp:\/\/post\/(\d+)$/', $uri, $m ) ) {
					$pid = (int) $m[1];
					$content = WP_WebMCP_Tool_Executor::builtin_get_post_content( array( 'post_id' => $pid ) );
					return rest_ensure_response(
						array(
							'jsonrpc' => '2.0',
							'id'      => $id,
							'result'  => array(
								'contents' => array(
									array(
										'uri'      => $uri,
										'mimeType' => 'text/markdown',
										'text'     => (string) ( $content['content'] ?? '' ),
									),
								),
							),
						)
					);
				}

				return rest_ensure_response(
					array(
						'jsonrpc' => '2.0',
						'id'      => $id,
						'error'   => array( 'code' => -32602, 'message' => "Unknown resource URI: {$uri}" ),
					)
				);

			case 'prompts/list':
				return rest_ensure_response(
					array(
						'jsonrpc' => '2.0',
						'id'      => $id,
						'result'  => array(
							'prompts' => array(
								array(
									'name'        => 'summarize-site',
									'description' => 'Generate an executive summary of this site based on its homepage content and sitemap.',
								),
								array(
									'name'        => 'search-content',
									'description' => 'Search and synthesize articles matching a topic.',
									'arguments'   => array(
										array( 'name' => 'topic', 'description' => 'Topic to search for', 'required' => true ),
									),
								),
							),
						),
					)
				);

			default:
				return rest_ensure_response(
					array(
						'jsonrpc' => '2.0',
						'id'      => $id,
						'error'   => array(
							'code'    => -32601,
							'message' => sprintf( 'Method "%s" not supported', $method ),
						),
					)
				);
		}
	}

	/**
	 * Server-Sent Events (SSE) stream for Model Context Protocol transport.
	 */
	public static function serve_sse() {
		if ( ! headers_sent() ) {
			status_header( 200 );
			header( 'Content-Type: text/event-stream; charset=utf-8' );
			header( 'Cache-Control: no-cache, no-store, must-revalidate' );
			header( 'Connection: keep-alive' );
			header( 'X-Accel-Buffering: no' );
			header( 'Access-Control-Allow-Origin: *' );
		}

		$endpoint_url = rest_url( 'wpwebmcp/v1/mcp' );
		echo "event: endpoint\n";
		echo 'data: ' . esc_url_raw( $endpoint_url ) . "\n\n";
		if ( function_exists( 'fastcgi_finish_request' ) ) {
			fastcgi_finish_request();
		} else {
			flush();
		}
		exit;
	}

	/**
	 * GET /wpwebmcp/v1/tools — Full tool directory.
	 */
	public static function get_tools_index() {
		$tools = class_exists( 'WP_WebMCP_Schema_Builder' )
			? WP_WebMCP_Schema_Builder::get_all_tools()
			: array();

		return rest_ensure_response(
			array(
				'ok'          => true,
				'schema'      => '1.0',
				'count'       => count( $tools ),
				'server'      => 'WebMCP Nexus',
				'mcpEndpoint' => rest_url( 'wpwebmcp/v1/mcp' ),
				'sseEndpoint' => rest_url( 'wpwebmcp/v1/sse' ),
				'tools'       => $tools,
			)
		);
	}

	/**
	 * Filter hook to add the Retry-After header for 429 responses.
	 *
	 * @param WP_REST_Response|null $response
	 * @return WP_REST_Response
	 */
	public static function rate_limit_headers( $response ) {
		if ( $response instanceof WP_REST_Response ) {
			$response->header( 'Retry-After', '60' );
		}
		return $response;
	}

	/**
	 * M0c — Stamp every WebMCP REST response with the resolved agent
	 * identity so agents can see exactly how they were identified
	 * (slug;confidence). Runs on rest_pre_eager_response which fires
	 * for both success and error responses.
	 *
	 * @param WP_REST_Response|null $response
	 * @return WP_REST_Response|null
	 */
	public static function agent_identity_headers( $response ) {
		if ( ! $response instanceof WP_REST_Response ) {
			return $response;
		}
		if ( ! (bool) get_option( 'wpwebmcp_agent_identity_enabled', true ) ) {
			return $response;
		}
		if ( ! class_exists( 'WP_WebMCP_Agent_Identity' ) ) {
			return $response;
		}
		try {
			$value = WP_WebMCP_Agent_Identity::header_value(); // "slug;confidence"
			$response->header( 'X-WebMCP-Agent-Resolved', $value );
			$id = WP_WebMCP_Agent_Identity::resolve();
			if ( ! empty( $id['family'] ) ) {
				$response->header( 'X-WebMCP-Agent-Family', (string) $id['family'] );
			}
			if ( ! empty( $id['label'] ) ) {
				$response->header( 'X-WebMCP-Agent-Label', (string) $id['label'] );
			}
		} catch ( Throwable $e ) {
			// Never let the header injection break a response.
			error_log( '[WP_WebMCP_Tools] agent_identity_headers failed: ' . $e->getMessage() );
		}
		return $response;
	}

	/* ============================================================
	 *  Write-tool auth: 3 proofs in order (Doc §9.4)
	 *  ① Session + valid X-WP-Nonce
	 *  ② Application Password (WP core authenticates; role must allow write)
	 *  ③ X-WC-Nonce + Woo active + cart tool (Step 14 wiring)
	 * ============================================================ */

	public static function can_execute_write_tool( string $slug ): bool {
		// ① Cookie session + nonce (X-WP-Nonce).
		if ( is_user_logged_in() ) {
			$nonce = isset( $_SERVER['HTTP_X_WP_NONCE'] )
				? sanitize_text_field( wp_unslash( (string) $_SERVER['HTTP_X_WP_NONCE'] ) )
				: ( isset( $_REQUEST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( (string) $_REQUEST['_wpnonce'] ) ) : '' );
			if ( '' !== $nonce && wp_verify_nonce( $nonce, 'wp_rest' ) ) {
				if ( class_exists( 'WP_WebMCP_Access_Control' ) && WP_WebMCP_Access_Control::current_role_can( 'write' ) ) {
					return true;
				}
			}
		}

		// ② Application Password — WordPress already authenticated the request
		// (basic auth). Verify the resolved user has write role.
		if ( is_user_logged_in() && class_exists( 'WP_WebMCP_Access_Control' ) ) {
			if ( WP_WebMCP_Access_Control::current_role_can( 'write' ) ) {
				return true;
			}
		}

		// ③ X-WC-Nonce — only for cart-scoped Woo tools.
		$wc_nonce = isset( $_SERVER['HTTP_X_WC_NONCE'] )
			? sanitize_text_field( wp_unslash( (string) $_SERVER['HTTP_X_WC_NONCE'] ) )
			: '';
		if ( '' !== $wc_nonce && class_exists( 'WooCommerce' ) && function_exists( 'wc_store_api' ) ) {
			$cart_tools = array( 'addToCart', 'updateQuantity', 'removeItem', 'applyCoupon' );
			if ( in_array( $slug, $cart_tools, true ) ) {
				// Woo authenticates the X-WC-Nonce against wc_store_api internally;
				// we trust core here and just gate by role.
				if ( class_exists( 'WP_WebMCP_Access_Control' ) && WP_WebMCP_Access_Control::current_role_can( 'write' ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/* ============================================================
	 *  POST /analytics (Doc §7.5)
	 * ============================================================ */

	public static function record_analytics( WP_REST_Request $request ) {
		// Body cap (1 KB per spec).
		$body = (string) $request->get_body();
		if ( strlen( $body ) > 1024 ) {
			return new WP_Error( 'wpwebmcp_payload_too_large', __( 'Analytics body exceeds 1 KB.', 'webmcp-nexus' ), array( 'status' => 413 ) );
		}
		$params = $request->get_json_params();
		$tool   = isset( $params['tool'] )   ? sanitize_text_field( (string) $params['tool'] )   : '';
		$post_id = isset( $params['post_id'] ) ? absint( (int) $params['post_id'] )                 : 0;
		if ( '' === $tool || strlen( $tool ) > 64 ) {
			return new WP_Error( 'wpwebmcp_bad_params', __( 'Invalid tool name.', 'webmcp-nexus' ), array( 'status' => 400 ) );
		}

		// Soft throttle — IP-hash counter via transient.
		$ip       = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '';
		$salt     = defined( 'AUTH_SALT' ) ? (string) AUTH_SALT : ( defined( 'LOGGED_IN_SALT' ) ? (string) LOGGED_IN_SALT : 'wpwebmcp_default_salt' );
		$iphash   = substr( hash( 'sha256', $ip . $salt ), 0, 16 );
		$key       = 'wpwm_analytics_' . $iphash;
		$counter   = (int) get_transient( $key );

		if ( $counter >= self::ANALYTICS_LIMIT_PER_MIN ) {
			// Over-limit → 202, NO DB write, Cache-Control: no-store.
			$response = rest_ensure_response(
				array(
					'ok'    => false,
					'error' => 'rate_limited',
					'retry' => 60,
				)
			);
			if ( $response instanceof WP_REST_Response ) {
				$response->header( 'Cache-Control', 'no-store' );
			}
			return $response;
		}

		// Persist + increment.
		set_transient( $key, $counter + 1, MINUTE_IN_SECONDS );
		if ( class_exists( 'WP_WebMCP_Logger' ) ) {
			WP_WebMCP_Logger::write( 'analytics.' . $tool, array( 'post_id' => $post_id ), 'success', '', get_current_user_id(), 0 );
		}

		// Cache-Control: no-store for success too (spec).
		$response = rest_ensure_response(
			array(
				'ok'      => true,
				'tool'    => $tool,
				'post_id' => $post_id,
			)
		);
		if ( $response instanceof WP_REST_Response ) {
			$response->header( 'Cache-Control', 'no-store' );
		}
		return $response;
	}

	/* ============================================================
	 *  GET /health (admin)
	 * ============================================================ */

	public static function get_health() {
		$score = class_exists( 'WP_WebMCP_Validator' ) ? (int) WP_WebMCP_Validator::get_cached_score() : null;
		$counts = array(
			'tools_active'   => class_exists( 'WP_WebMCP_Tool_Repository' ) ? (int) WP_WebMCP_Tool_Repository::count( 'active' ) : 0,
			'calls_today'    => class_exists( 'WP_WebMCP_Log_Repository' ) ? (int) WP_WebMCP_Log_Repository::count_today() : 0,
			'errors_today'   => class_exists( 'WP_WebMCP_Log_Repository' ) ? (int) WP_WebMCP_Log_Repository::count(
				array(
					'date_from' => gmdate( 'Y-m-d 00:00:00' ),
					'date_to'   => gmdate( 'Y-m-d 23:59:59' ),
					'status'    => 'error',
				)
			) : 0,
		);
		return rest_ensure_response(
			array(
				'version'         => defined( 'WEBMCP_NEXUS_VERSION' ) ? WEBMCP_NEXUS_VERSION : '1.0.0',
				'score'           => $score,
				'counts'          => $counts,
				'tables_present'  => class_exists( 'WP_WebMCP_Health' ) ? WP_WebMCP_Health::tables_present() : 0,
			)
		);
	}

	/**
	 * POST /health/validate (admin)
	 * Forces re-calculation of the health score and returns the fresh score.
	 */
	public static function validate_health() {
		$score = class_exists( 'WP_WebMCP_Validator' ) ? (int) WP_WebMCP_Validator::calculate_health_score() : 100;
		return rest_ensure_response(
			array(
				'ok'    => true,
				'score' => $score,
			)
		);
	}
}