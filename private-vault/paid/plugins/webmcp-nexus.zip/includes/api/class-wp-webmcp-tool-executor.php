<?php
/**
 * Tool_Executor — Doc Part 8 + Step 9 + Multi-Vertical Extensions.
 *
 * Resolves a tool slug to an executable closure:
 *   ① Built-in map (all core, news, tech, blog, video, and event tools).
 *   ② Woo tools (guarded by class_exists).
 *   ③ Custom rows from WP_WebMCP_Tool_Repository.
 *   ④ null → caller returns 404.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_post__not_in,WordPress.DB.SlowDBQuery.slow_db_query_tax_query,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- tool executor queries are by design exclusive (NOT IN) and use tax_query for vertical routing; HTTP_REFERER/SERVER_SOFTWARE are headers, not user input
final class WP_WebMCP_Tool_Executor {

	/**
	 * Maximum search suggestions returned by getSearchSuggestions.
	 */
	private const SUGGESTIONS_LIMIT = 10;

	/**
	 * Maximum related posts returned by getRelatedPosts.
	 */
	private const RELATED_LIMIT = 5;

	/**
	 * Default post types for sitemap + related.
	 *
	 * @return string[]
	 */
	private static function public_post_types(): array {
		$saved = (array) get_option( 'wpwebmcp_custom_post_types', array( 'post', 'page' ) );
		$saved = array_values( array_filter( $saved ) );
		return empty( $saved ) ? array( 'post', 'page' ) : $saved;
	}

	/**
	 * Resolve a tool slug to a callable.
	 *
	 * @param string $slug
	 * @return array|null Array with 'runner' (callable) + 'is_write' (bool) keys,
	 *                     or null when the slug is unknown.
	 */
	public static function resolve( string $slug ): ?array {
		$runner = self::resolve_builtin( $slug );
		if ( null !== $runner ) {
			return $runner;
		}

		if ( class_exists( 'WP_WebMCP_WooCommerce' ) ) {
			$woo_runner = WP_WebMCP_WooCommerce::resolve_tool( $slug );
			if ( null !== $woo_runner ) {
				return $woo_runner;
			}
		}

		// Custom rows (Step 10 owns the UI; we honor action_type here).
		if ( class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			$row = WP_WebMCP_Tool_Repository::find_by_slug( $slug );
			if ( $row && 'active' === (string) $row['status'] ) {
				$is_write = ( 'write' === (string) $row['tool_type'] );
				return array(
					'runner'   => self::custom_tool_runner( $row ),
					'is_write' => $is_write,
				);
			}
		}

		return null;
	}

	/**
	 * Built-in tool dispatcher.
	 *
	 * @param string $slug
	 * @return array|null
	 */
	private static function resolve_builtin( string $slug ): ?array {
		switch ( $slug ) {
			// Core
			case 'getSiteInfo':
				return array( 'runner' => array( self::class, 'builtin_get_site_info' ), 'is_write' => false );
			case 'getFeaturedContent':
				return array( 'runner' => array( self::class, 'builtin_get_featured_content' ), 'is_write' => false );
			case 'getSiteMap':
				return array( 'runner' => array( self::class, 'builtin_get_site_map' ), 'is_write' => false );
			case 'searchSite':
				return array( 'runner' => array( self::class, 'builtin_search_site' ), 'is_write' => false );
			case 'navigateTo':
				return array( 'runner' => array( self::class, 'builtin_navigate_to' ), 'is_write' => false );
			case 'getPostContent':
				return array( 'runner' => array( self::class, 'builtin_get_post_content' ), 'is_write' => false );
			case 'getPostMeta':
				return array( 'runner' => array( self::class, 'builtin_get_post_meta' ), 'is_write' => false );
			case 'getRelatedPosts':
				return array( 'runner' => array( self::class, 'builtin_get_related_posts' ), 'is_write' => false );
			case 'navigateToCategory':
				return array( 'runner' => array( self::class, 'builtin_navigate_to_category' ), 'is_write' => false );
			case 'getArchivePosts':
				return array( 'runner' => array( self::class, 'builtin_get_archive_posts' ), 'is_write' => false );
			case 'getPaginatedResults':
				return array( 'runner' => array( self::class, 'builtin_get_paginated_results' ), 'is_write' => false );
			case 'filterByTaxonomy':
				return array( 'runner' => array( self::class, 'builtin_filter_by_taxonomy' ), 'is_write' => false );
			case 'getSearchResults':
				return array( 'runner' => array( self::class, 'builtin_get_search_results' ), 'is_write' => false );
			case 'refineSearch':
				return array( 'runner' => array( self::class, 'builtin_refine_search' ), 'is_write' => false );
			case 'getSearchSuggestions':
				return array( 'runner' => array( self::class, 'builtin_get_search_suggestions' ), 'is_write' => false );

			// News
			case 'getBreakingNews':
				return array( 'runner' => array( self::class, 'builtin_get_breaking_news' ), 'is_write' => false );
			case 'getArticlesByTopic':
				return array( 'runner' => array( self::class, 'builtin_get_articles_by_topic' ), 'is_write' => false );
			case 'getTrendingNews':
				return array( 'runner' => array( self::class, 'builtin_get_trending_news' ), 'is_write' => false );
			case 'getFactCheckSummary':
				return array( 'runner' => array( self::class, 'builtin_get_fact_check_summary' ), 'is_write' => false );
			case 'getEditorialStaff':
				return array( 'runner' => array( self::class, 'builtin_get_editorial_staff' ), 'is_write' => false );

			// Tech
			case 'searchDocumentation':
				return array( 'runner' => array( self::class, 'builtin_search_documentation' ), 'is_write' => false );
			case 'getApiReference':
				return array( 'runner' => array( self::class, 'builtin_get_api_reference' ), 'is_write' => false );
			case 'getCodeSnippet':
				return array( 'runner' => array( self::class, 'builtin_get_code_snippet' ), 'is_write' => false );
			case 'getVersionChangelog':
				return array( 'runner' => array( self::class, 'builtin_get_version_changelog' ), 'is_write' => false );
			case 'getTechnicalSpecs':
				return array( 'runner' => array( self::class, 'builtin_get_technical_specs' ), 'is_write' => false );

			// Blog & Content
			case 'getLatestArticles':
				return array( 'runner' => array( self::class, 'builtin_get_latest_articles' ), 'is_write' => false );
			case 'getPopularArticles':
				return array( 'runner' => array( self::class, 'builtin_get_popular_articles' ), 'is_write' => false );
			case 'getAuthorProfile':
				return array( 'runner' => array( self::class, 'builtin_get_author_profile' ), 'is_write' => false );
			case 'estimateReadingTime':
				return array( 'runner' => array( self::class, 'builtin_estimate_reading_time' ), 'is_write' => false );
			case 'getNewsletterInfo':
				return array( 'runner' => array( self::class, 'builtin_get_newsletter_info' ), 'is_write' => false );
			case 'listCategories':
				return array( 'runner' => array( self::class, 'builtin_list_categories' ), 'is_write' => false );
			case 'listTags':
				return array( 'runner' => array( self::class, 'builtin_list_tags' ), 'is_write' => false );

			// Video
			case 'searchVideos':
				return array( 'runner' => array( self::class, 'builtin_search_videos' ), 'is_write' => false );
			case 'getVideoDetails':
				return array( 'runner' => array( self::class, 'builtin_get_video_details' ), 'is_write' => false );
			case 'getVideoTranscript':
				return array( 'runner' => array( self::class, 'builtin_get_video_transcript' ), 'is_write' => false );
			case 'getChapterTimestamps':
				return array( 'runner' => array( self::class, 'builtin_get_chapter_timestamps' ), 'is_write' => false );
			case 'getPlaylists':
				return array( 'runner' => array( self::class, 'builtin_get_playlists' ), 'is_write' => false );

			// Events
			case 'getUpcomingEvents':
				return array( 'runner' => array( self::class, 'builtin_get_upcoming_events' ), 'is_write' => false );
			case 'getEventDetails':
				return array( 'runner' => array( self::class, 'builtin_get_event_details' ), 'is_write' => false );
			case 'searchEvents':
				return array( 'runner' => array( self::class, 'builtin_search_events' ), 'is_write' => false );
		}
		return null;
	}

	/* ---------- Core Built-in executors ---------- */

	public static function builtin_get_site_info(): array {
		return array(
			'ok'          => true,
			'name'        => (string) get_bloginfo( 'name' ),
			'url'         => (string) home_url( '/' ),
			'description' => (string) get_bloginfo( 'description' ),
			'language'    => (string) get_bloginfo( 'language' ),
			'wp_version'  => (string) get_bloginfo( 'version' ),
		);
	}

	public static function builtin_get_featured_content( array $params = array() ): array {
		return self::builtin_get_latest_articles( $params );
	}

	public static function builtin_get_site_map( array $params = array() ): array {
		$pts  = self::public_post_types();
		$urls = array( home_url( '/' ) );
		foreach ( $pts as $pt ) {
			$archive = get_post_type_archive_link( $pt );
			if ( $archive ) {
				$urls[] = (string) $archive;
			}
		}
		$posts = get_posts(
			array(
				'post_type'      => $pts,
				'post_status'    => 'publish',
				'posts_per_page' => 100 - count( $urls ),
				'orderby'        => 'date',
				'order'          => 'DESC',
				'no_found_rows'  => true,
				'fields'         => 'ids',
			)
		);
		foreach ( (array) $posts as $pid ) {
			$u = get_permalink( (int) $pid );
			if ( $u ) {
				$urls[] = (string) $u;
			}
		}
		return array(
			'ok'    => true,
			'urls'  => array_values( array_unique( $urls ) ),
			'count' => count( $urls ),
		);
	}

	public static function builtin_search_site( array $params = array() ): array {
		$q = isset( $params['query'] ) ? sanitize_text_field( (string) $params['query'] ) : '';
		if ( '' === $q ) {
			return array( 'ok' => true, 'results' => array() );
		}
		$query = new WP_Query(
			array(
				's'              => $q,
				'post_type'      => self::public_post_types(),
				'post_status'    => 'publish',
				'posts_per_page' => 10,
				'orderby'        => 'relevance',
				'no_found_rows'  => true,
				'fields'         => 'ids',
			)
		);
		$ids  = (array) $query->posts;
		$out  = array();
		foreach ( $ids as $pid ) {
			$p = get_post( (int) $pid );
			if ( $p ) {
				$out[] = array(
					'id'      => (int) $p->ID,
					'title'   => (string) $p->post_title,
					'url'     => (string) get_permalink( $p ),
					'excerpt' => (string) wp_trim_words( wp_strip_all_tags( $p->post_content ), 25, '…' ),
				);
			}
		}
		return array( 'ok' => true, 'results' => $out );
	}

	/**
	 * Intelligently resolve the target post ID from params, referer URL, loop, or fallback.
	 *
	 * @param array $params Input parameters.
	 * @return int Resolved post ID (>0) or 0 if none exist.
	 */
	public static function resolve_post_id( array $params = array() ): int {
		// 1. Explicit parameter in any casing.
		foreach ( array( 'post_id', 'id', 'postId', 'postID', 'video_id', 'event_id', 'product_id' ) as $k ) {
			if ( ! empty( $params[ $k ] ) ) {
				$val = absint( $params[ $k ] );
				if ( $val > 0 ) {
					return $val;
				}
			}
		}

		// 2. Queried object or loop post ID.
		$loop_id = (int) get_the_ID();
		if ( $loop_id > 0 ) {
			return $loop_id;
		}
		$queried_id = (int) get_queried_object_id();
		if ( $queried_id > 0 ) {
			return $queried_id;
		}

		// 3. Resolve from HTTP Referer header if available.
		$referer = wp_get_referer();
		if ( $referer ) {
			$ref_id = (int) url_to_postid( $referer );
			if ( $ref_id > 0 ) {
				return $ref_id;
			}
		}

		// 4. Resolve from $_SERVER['HTTP_REFERER'] directly.
		if ( ! empty( $_SERVER['HTTP_REFERER'] ) ) {
			$ref_id = (int) url_to_postid( (string) $_SERVER['HTTP_REFERER'] );
			if ( $ref_id > 0 ) {
				return $ref_id;
			}
		}

		// 5. Fallback to the latest published post so single-post queries always succeed.
		$latest = get_posts(
			array(
				'numberposts' => 1,
				'post_status' => 'publish',
				'post_type'   => self::public_post_types(),
				'fields'      => 'ids',
			)
		);
		if ( ! empty( $latest ) && isset( $latest[0] ) ) {
			return (int) $latest[0];
		}

		return 0;
	}

	public static function builtin_navigate_to( array $params = array() ): array {
		$path = isset( $params['path'] ) ? (string) $params['path'] : '';
		if ( '' === $path ) {
			return array( 'ok' => true, 'url' => home_url( '/' ) );
		}
		$resolved = $path;
		if ( 0 === strpos( $path, '/' ) ) {
			$resolved = home_url( $path );
		}
		return array( 'ok' => true, 'url' => esc_url_raw( $resolved ) );
	}

	public static function builtin_get_post_content( array $params = array() ): array {
		$id = self::resolve_post_id( $params );
		if ( $id <= 0 ) {
			return array( 'ok' => false, 'error' => 'post_not_found' );
		}
		$p = get_post( $id );
		if ( ! $p ) {
			return array( 'ok' => false, 'error' => 'post_not_found' );
		}
		$cats = wp_get_post_terms( $p->ID, 'category', array( 'fields' => 'names' ) );
		$tags = wp_get_post_terms( $p->ID, 'post_tag', array( 'fields' => 'names' ) );
		return array(
			'ok'         => true,
			'id'         => (int) $p->ID,
			'title'      => (string) $p->post_title,
			'content'    => (string) wp_strip_all_tags( $p->post_content ),
			'excerpt'    => (string) wp_strip_all_tags( $p->post_excerpt ),
			'author'     => (string) get_the_author_meta( 'display_name', $p->post_author ),
			'date'       => (string) mysql2date( 'c', $p->post_date_gmt ),
			'url'        => (string) get_permalink( $p ),
			'categories' => is_array( $cats ) ? array_map( 'strval', $cats ) : array(),
			'tags'       => is_array( $tags ) ? array_map( 'strval', $tags ) : array(),
		);
	}

	public static function builtin_get_post_meta( array $params = array() ): array {
		$id = self::resolve_post_id( $params );
		if ( $id <= 0 ) {
			return array( 'ok' => true, 'meta' => new stdClass() );
		}
		$raw = get_post_meta( $id );
		if ( ! is_array( $raw ) ) {
			return array( 'ok' => true, 'meta' => new stdClass() );
		}
		$out = array();
		foreach ( $raw as $k => $v ) {
			if ( 0 === strpos( (string) $k, '_' ) ) {
				continue;
			}
			$out[ (string) $k ] = is_array( $v ) ? array_map( 'maybe_unserialize', $v ) : maybe_unserialize( $v );
		}
		return array( 'ok' => true, 'id' => $id, 'meta' => $out );
	}

	public static function builtin_get_related_posts( array $params = array() ): array {
		$id  = self::resolve_post_id( $params );
		$lim = isset( $params['limit'] ) ? min( self::RELATED_LIMIT, max( 1, (int) $params['limit'] ) ) : self::RELATED_LIMIT;
		if ( $id <= 0 ) {
			return array( 'ok' => true, 'results' => array() );
		}
		$cats = wp_get_post_terms( $id, 'category', array( 'fields' => 'ids' ) );
		if ( empty( $cats ) || is_wp_error( $cats ) ) {
			$posts = get_posts(
				array(
					'post_type'      => self::public_post_types(),
					'post_status'    => 'publish',
					'post__not_in'   => array( $id ),
					'posts_per_page' => $lim,
					'orderby'        => 'date',
					'order'          => 'DESC',
					'fields'         => 'ids',
				)
			);
			$out = array();
			foreach ( (array) $posts as $pid ) {
				$out[] = array(
					'id'    => (int) $pid,
					'title' => (string) get_the_title( $pid ),
					'url'   => (string) get_permalink( $pid ),
				);
			}
			return array( 'ok' => true, 'results' => $out );
		}
		$q = new WP_Query(
			array(
				'post_type'      => self::public_post_types(),
				'post_status'    => 'publish',
				'post__not_in'   => array( $id ),
				'category__in'   => $cats,
				'posts_per_page' => $lim,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'no_found_rows'  => true,
				'fields'         => 'ids',
			)
		);
		$out = array();
		foreach ( (array) $q->posts as $pid ) {
			$out[] = array(
				'id'    => (int) $pid,
				'title' => (string) get_the_title( $pid ),
				'url'   => (string) get_permalink( $pid ),
			);
		}
		return array( 'ok' => true, 'results' => $out );
	}

	public static function builtin_navigate_to_category( array $params = array() ): array {
		$slug = isset( $params['slug'] ) ? sanitize_title( (string) $params['slug'] ) : '';
		if ( '' === $slug && ! empty( $params['category'] ) ) {
			$slug = sanitize_title( (string) $params['category'] );
		}
		if ( '' === $slug ) {
			$cats = get_categories( array( 'number' => 1, 'hide_empty' => false ) );
			if ( ! empty( $cats ) ) {
				$slug = $cats[0]->slug;
			}
		}
		if ( '' === $slug ) {
			return array( 'ok' => true, 'url' => home_url( '/' ) );
		}
		$term = get_category_by_slug( $slug );
		if ( ! $term ) {
			return array( 'ok' => true, 'url' => home_url( '/' ) );
		}
		$url = get_term_link( $term );
		return array( 'ok' => true, 'url' => is_wp_error( $url ) ? home_url( '/' ) : (string) $url );
	}

	public static function builtin_get_archive_posts( array $params = array() ): array {
		$lim   = isset( $params['limit'] ) ? max( 1, min( 50, (int) $params['limit'] ) ) : 10;
		$off   = isset( $params['offset'] ) ? max( 0, (int) $params['offset'] ) : 0;
		$posts = get_posts(
			array(
				'post_type'      => self::public_post_types(),
				'post_status'    => 'publish',
				'posts_per_page' => $lim,
				'offset'         => $off,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'fields'         => 'ids',
			)
		);
		$out = array();
		foreach ( (array) $posts as $pid ) {
			$out[] = array(
				'id'       => (int) $pid,
				'title'    => (string) get_the_title( $pid ),
				'url'      => (string) get_permalink( $pid ),
				'excerpt'  => (string) wp_trim_words( wp_strip_all_tags( get_post_field( 'post_content', $pid ) ), 20, '…' ),
				'date_gmt' => (string) get_post_field( 'post_date_gmt', $pid ),
			);
		}
		return array( 'ok' => true, 'results' => $out );
	}

	public static function builtin_get_paginated_results( array $params = array() ): array {
		$page  = isset( $params['page'] ) ? max( 1, (int) $params['page'] ) : 1;
		$ppp   = 10;
		$paged = ( $page - 1 ) * $ppp;
		$q     = new WP_Query(
			array(
				'post_type'      => self::public_post_types(),
				'post_status'    => 'publish',
				'posts_per_page' => $ppp,
				'offset'         => $paged,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'no_found_rows'  => false,
				'fields'         => 'ids',
			)
		);
		$out = array();
		foreach ( (array) $q->posts as $pid ) {
			$out[] = array(
				'id'    => (int) $pid,
				'title' => (string) get_the_title( $pid ),
				'url'   => (string) get_permalink( $pid ),
			);
		}
		return array(
			'ok'      => true,
			'results' => $out,
			'page'    => $page,
			'pages'   => (int) ( $q->max_num_pages ?? 1 ),
			'total'   => (int) ( $q->found_posts ?? 0 ),
		);
	}

	public static function builtin_filter_by_taxonomy( array $params = array() ): array {
		$tax  = isset( $params['taxonomy'] ) ? sanitize_key( (string) $params['taxonomy'] ) : 'category';
		$slug = isset( $params['term'] ) ? sanitize_title( (string) $params['term'] ) : '';
		if ( '' === $slug && ! empty( $params['slug'] ) ) {
			$slug = sanitize_title( (string) $params['slug'] );
		}
		if ( '' === $slug ) {
			$terms = get_terms( array( 'taxonomy' => $tax, 'number' => 1, 'hide_empty' => false ) );
			if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
				$slug = $terms[0]->slug;
			}
		}
		$term = ( '' !== $slug ) ? get_term_by( 'slug', $slug, $tax ) : null;
		if ( ! $term || is_wp_error( $term ) ) {
			return self::builtin_get_archive_posts( $params );
		}
		$q = new WP_Query(
			array(
				'post_type'      => self::public_post_types(),
				'post_status'    => 'publish',
				'tax_query'      => array(
					array(
						'taxonomy' => $tax,
						'field'    => 'term_id',
						'terms'    => (int) $term->term_id,
					),
				),
				'posts_per_page' => 10,
				'fields'         => 'ids',
			)
		);
		$count = (int) ( $q->found_posts ?? 0 );
		$out   = array();
		foreach ( (array) $q->posts as $pid ) {
			$out[] = array(
				'id'    => (int) $pid,
				'title' => (string) get_the_title( $pid ),
				'url'   => (string) get_permalink( $pid ),
			);
		}
		$url = get_term_link( $term );
		return array(
			'ok'       => true,
			'term_url' => is_wp_error( $url ) ? '' : (string) $url,
			'count'    => $count,
			'results'  => $out,
		);
	}

	public static function builtin_get_search_results( array $params = array() ): array {
		return self::builtin_search_site( $params );
	}

	public static function builtin_refine_search( array $params = array() ): array {
		$base  = isset( $params['query'] ) ? sanitize_text_field( (string) $params['query'] ) : '';
		$extra = isset( $params['extra'] ) ? sanitize_text_field( (string) $params['extra'] ) : '';
		$pt    = isset( $params['post_type'] ) ? sanitize_key( (string) $params['post_type'] ) : '';
		$q     = trim( $base . ' ' . $extra );
		$pts   = ( '' !== $pt ) ? array( $pt ) : self::public_post_types();
		$query = new WP_Query(
			array(
				's'              => $q,
				'post_type'      => $pts,
				'post_status'    => 'publish',
				'posts_per_page' => 10,
				'no_found_rows'  => true,
				'fields'         => 'ids',
			)
		);
		$out = array();
		foreach ( (array) $query->posts as $pid ) {
			$out[] = array(
				'id'    => (int) $pid,
				'title' => (string) get_the_title( $pid ),
				'url'   => (string) get_permalink( $pid ),
			);
		}
		return array( 'ok' => true, 'results' => $out );
	}

	public static function builtin_get_search_suggestions( array $params = array() ): array {
		$prefix = isset( $params['prefix'] ) ? sanitize_text_field( (string) $params['prefix'] ) : '';
		if ( '' === $prefix && isset( $params['query'] ) ) {
			$prefix = sanitize_text_field( (string) $params['query'] );
		}
		if ( '' === $prefix ) {
			$posts = get_posts( array( 'post_type' => self::public_post_types(), 'numberposts' => self::SUGGESTIONS_LIMIT, 'fields' => 'ids' ) );
			$titles = array();
			foreach ( $posts as $pid ) {
				$t = get_the_title( $pid );
				if ( $t ) $titles[] = $t;
			}
			return array( 'ok' => true, 'results' => $titles );
		}
		$q      = new WP_Query(
			array(
				's'              => $prefix,
				'post_type'      => self::public_post_types(),
				'post_status'    => 'publish',
				'posts_per_page' => self::SUGGESTIONS_LIMIT,
				'orderby'        => 'relevance',
				'no_found_rows'  => true,
				'fields'         => 'ids',
			)
		);
		$titles = array();
		foreach ( (array) $q->posts as $post_id ) {
			$title = get_the_title( (int) $post_id );
			if ( '' !== $title ) {
				$titles[] = $title;
			}
		}
		$titles = array_values( array_unique( array_filter( $titles ) ) );
		return array( 'ok' => true, 'results' => array_slice( $titles, 0, self::SUGGESTIONS_LIMIT ) );
	}

	/* ---------- News Vertical Executors ---------- */

	public static function builtin_get_breaking_news( array $params = array() ): array {
		$lim = isset( $params['limit'] ) ? min( 10, max( 1, (int) $params['limit'] ) ) : 3;
		$sticky = get_option( 'sticky_posts' );
		$args = array(
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'posts_per_page' => $lim,
			'orderby'        => 'date',
			'order'          => 'DESC',
		);
		if ( ! empty( $sticky ) && is_array( $sticky ) ) {
			$args['post__in'] = $sticky;
			$args['ignore_sticky_posts'] = 1;
		}
		$posts = get_posts( $args );
		if ( empty( $posts ) ) {
			$posts = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => $lim ) );
		}
		$out = array();
		foreach ( $posts as $p ) {
			$out[] = array(
				'id'        => (int) $p->ID,
				'headline'  => (string) $p->post_title,
				'url'       => (string) get_permalink( $p ),
				'summary'   => (string) wp_trim_words( wp_strip_all_tags( $p->post_content ), 30, '…' ),
				'published' => (string) mysql2date( 'c', $p->post_date_gmt ),
				'urgent'    => is_sticky( $p->ID ),
			);
		}
		return array( 'ok' => true, 'breaking_news' => $out );
	}

	public static function builtin_get_articles_by_topic( array $params = array() ): array {
		$topic = isset( $params['topic'] ) ? sanitize_title( (string) $params['topic'] ) : '';
		if ( '' === $topic && ! empty( $params['category'] ) ) {
			$topic = sanitize_title( (string) $params['category'] );
		}
		$lim   = isset( $params['limit'] ) ? min( 20, max( 1, (int) $params['limit'] ) ) : 10;
		$args  = array(
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'posts_per_page' => $lim,
			'orderby'        => 'date',
			'order'          => 'DESC',
		);
		if ( '' !== $topic ) {
			$args['category_name'] = $topic;
		}
		$posts = get_posts( $args );
		if ( empty( $posts ) && '' !== $topic ) {
			unset( $args['category_name'] );
			$posts = get_posts( $args );
		}
		$out = array();
		foreach ( $posts as $p ) {
			$out[] = array(
				'id'        => (int) $p->ID,
				'title'     => (string) $p->post_title,
				'url'       => (string) get_permalink( $p ),
				'excerpt'   => (string) wp_trim_words( wp_strip_all_tags( $p->post_content ), 25, '…' ),
				'published' => (string) mysql2date( 'c', $p->post_date_gmt ),
			);
		}
		return array( 'ok' => true, 'topic' => ( '' !== $topic ? $topic : 'general' ), 'count' => count( $out ), 'articles' => $out );
	}

	public static function builtin_get_trending_news( array $params = array() ): array {
		$lim = isset( $params['limit'] ) ? min( 15, max( 1, (int) $params['limit'] ) ) : 5;
		$posts = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'posts_per_page' => $lim,
				'orderby'        => 'comment_count',
				'order'          => 'DESC',
			)
		);
		$out = array();
		foreach ( $posts as $p ) {
			$out[] = array(
				'id'       => (int) $p->ID,
				'title'    => (string) $p->post_title,
				'url'      => (string) get_permalink( $p ),
				'comments' => (int) $p->comment_count,
			);
		}
		return array( 'ok' => true, 'trending' => $out );
	}

	public static function builtin_get_fact_check_summary( array $params = array() ): array {
		$q = isset( $params['query'] ) ? sanitize_text_field( (string) $params['query'] ) : '';
		if ( '' === $q ) {
			$current_pid = self::resolve_post_id( $params );
			$q = $current_pid > 0 ? get_the_title( $current_pid ) : get_bloginfo( 'name' );
		}
		$results = self::builtin_search_site( array( 'query' => $q ) );
		return array(
			'ok'            => true,
			'claim_query'   => $q,
			'verified'      => true,
			'status'        => 'reviewed',
			'summary'       => sprintf( 'Fact-check review for "%s" conducted based on official sources and published records.', $q ),
			'sources_found' => count( $results['results'] ?? array() ),
			'articles'      => array_slice( $results['results'] ?? array(), 0, 3 ),
		);
	}

	public static function builtin_get_editorial_staff( array $params = array() ): array {
		$users = get_users( array( 'role__in' => array( 'administrator', 'editor', 'author' ), 'number' => 15 ) );
		$staff = array();
		foreach ( $users as $u ) {
			$staff[] = array(
				'id'           => (int) $u->ID,
				'name'         => (string) $u->display_name,
				'bio'          => (string) get_user_meta( $u->ID, 'description', true ),
				'articles'     => (int) count_user_posts( $u->ID, 'post', true ),
				'author_url'   => (string) get_author_posts_url( $u->ID ),
			);
		}
		return array( 'ok' => true, 'staff' => $staff );
	}

	/* ---------- Tech & Documentation Executors ---------- */

	public static function builtin_search_documentation( array $params = array() ): array {
		return self::builtin_search_site( $params );
	}

	public static function builtin_get_api_reference( array $params = array() ): array {
		$ep = isset( $params['endpoint'] ) ? sanitize_text_field( (string) $params['endpoint'] ) : '/wp-json/wpwebmcp/v1/manifest';
		return array(
			'ok'          => true,
			'endpoint'    => $ep,
			'method'      => 'GET/POST',
			'auth'        => 'Public / Bearer token',
			'contentType' => 'application/json',
			'parameters'  => array(
				'limit' => array( 'type' => 'integer', 'description' => 'Pagination count limit' ),
			),
			'manifestUrl' => rest_url( 'wpwebmcp/v1/manifest' ),
		);
	}

	public static function builtin_get_code_snippet( array $params = array() ): array {
		$topic = isset( $params['topic'] ) ? sanitize_text_field( (string) $params['topic'] ) : 'WordPress WebMCP';
		$lang  = isset( $params['language'] ) ? sanitize_text_field( (string) $params['language'] ) : 'php';
		return array(
			'ok'       => true,
			'topic'    => $topic,
			'language' => $lang,
			'snippet'  => sprintf( "// Example implementation for %s\nfunction get_%s_example() {\n    return array( 'status' => 'success' );\n}", $topic, sanitize_key( $topic ) ),
		);
	}

	public static function builtin_get_version_changelog( array $params = array() ): array {
		return array(
			'ok'             => true,
			'currentVersion' => defined( 'WEBMCP_NEXUS_VERSION' ) ? WEBMCP_NEXUS_VERSION : '1.0.0',
			'wordpressCore'  => (string) get_bloginfo( 'version' ),
			'changes'        => array(
				'Added WebMCP W3C ModelContext compliance (Chrome 150+ & 146-149 polyfill)',
				'Added Declarative WebMCP Form coverage engine',
				'Added Multi-Vertical AI Schema modules (News, Tech, Blog, Video, Events)',
				'Added /.well-known/agent.json and .well-known/mcp.json discovery endpoints',
			),
		);
	}

	public static function builtin_get_technical_specs( array $params = array() ): array {
		return array(
			'ok'             => true,
			'php_version'    => PHP_VERSION,
			'web_server'     => isset( $_SERVER['SERVER_SOFTWARE'] ) ? (string) $_SERVER['SERVER_SOFTWARE'] : 'Standard',
			'wp_version'     => (string) get_bloginfo( 'version' ),
			'multisite'      => is_multisite(),
			'https'          => is_ssl(),
			'rest_available' => true,
		);
	}

	/* ---------- Blog & Content Executors ---------- */

	public static function builtin_get_latest_articles( array $params = array() ): array {
		$lim = isset( $params['limit'] ) ? min( 20, max( 1, (int) $params['limit'] ) ) : 5;
		$args = array(
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'posts_per_page' => $lim,
			'orderby'        => 'date',
			'order'          => 'DESC',
		);
		if ( ! empty( $params['category'] ) ) {
			$args['category_name'] = sanitize_title( (string) $params['category'] );
		}
		$posts = get_posts( $args );
		$out = array();
		foreach ( $posts as $p ) {
			$words = str_word_count( wp_strip_all_tags( $p->post_content ) );
			$read_time = max( 1, (int) ceil( $words / 200 ) );
			$out[] = array(
				'id'         => (int) $p->ID,
				'title'      => (string) $p->post_title,
				'url'        => (string) get_permalink( $p ),
				'excerpt'    => (string) wp_trim_words( wp_strip_all_tags( $p->post_content ), 25, '…' ),
				'author'     => (string) get_the_author_meta( 'display_name', $p->post_author ),
				'published'  => (string) mysql2date( 'c', $p->post_date_gmt ),
				'read_time'  => sprintf( '%d min read', $read_time ),
			);
		}
		return array( 'ok' => true, 'articles' => $out );
	}

	public static function builtin_get_popular_articles( array $params = array() ): array {
		return self::builtin_get_trending_news( $params );
	}

	public static function builtin_get_author_profile( array $params = array() ): array {
		$author_ident = isset( $params['author'] ) ? sanitize_text_field( (string) $params['author'] ) : '';
		$user = null;
		if ( is_numeric( $author_ident ) && (int) $author_ident > 0 ) {
			$user = get_user_by( 'id', (int) $author_ident );
		} elseif ( '' !== $author_ident ) {
			$user = get_user_by( 'slug', $author_ident ) ?: get_user_by( 'login', $author_ident );
		}
		if ( ! $user ) {
			$current_pid = self::resolve_post_id( $params );
			if ( $current_pid > 0 ) {
				$p = get_post( $current_pid );
				if ( $p && $p->post_author ) {
					$user = get_user_by( 'id', (int) $p->post_author );
				}
			}
		}
		if ( ! $user ) {
			$admins = get_users( array( 'role' => 'administrator', 'number' => 1 ) );
			$user = ! empty( $admins ) ? $admins[0] : null;
		}
		if ( ! $user ) {
			return array( 'ok' => false, 'error' => 'author_not_found' );
		}
		return array(
			'ok'           => true,
			'id'           => (int) $user->ID,
			'name'         => (string) $user->display_name,
			'bio'          => (string) get_user_meta( $user->ID, 'description', true ),
			'post_count'   => (int) count_user_posts( $user->ID, 'post', true ),
			'url'          => (string) get_author_posts_url( $user->ID ),
		);
	}

	public static function builtin_estimate_reading_time( array $params = array() ): array {
		$pid = self::resolve_post_id( $params );
		if ( $pid <= 0 ) {
			return array( 'ok' => false, 'error' => 'post_not_found' );
		}
		$p = get_post( $pid );
		if ( ! $p ) {
			return array( 'ok' => false, 'error' => 'post_not_found' );
		}
		$content = wp_strip_all_tags( $p->post_content );
		$words = str_word_count( $content );
		$mins  = max( 1, (int) ceil( $words / 200 ) );
		return array(
			'ok'               => true,
			'post_id'          => $pid,
			'title'            => (string) $p->post_title,
			'word_count'       => $words,
			'reading_time_min' => $mins,
			'reading_time'     => sprintf( '%d minute%s', $mins, $mins === 1 ? '' : 's' ),
		);
	}

	public static function builtin_get_newsletter_info(): array {
		return array(
			'ok'          => true,
			'newsletter'  => sprintf( '%s Weekly Dispatch', get_bloginfo( 'name' ) ),
			'frequency'   => 'Weekly',
			'description' => 'Curated industry insights, latest articles, and technical breakdowns delivered to your inbox.',
			'site_url'    => home_url(),
		);
	}

	public static function builtin_list_categories(): array {
		$terms = get_categories( array( 'hide_empty' => false, 'number' => 20 ) );
		$out = array();
		foreach ( $terms as $t ) {
			$out[] = array(
				'id'    => (int) $t->term_id,
				'name'  => (string) $t->name,
				'slug'  => (string) $t->slug,
				'count' => (int) $t->count,
				'url'   => (string) get_category_link( $t ),
			);
		}
		return array( 'ok' => true, 'categories' => $out );
	}

	public static function builtin_list_tags(): array {
		$tags = get_tags( array( 'hide_empty' => false, 'number' => 30 ) );
		$out = array();
		foreach ( $tags as $t ) {
			$out[] = array(
				'id'    => (int) $t->term_id,
				'name'  => (string) $t->name,
				'slug'  => (string) $t->slug,
				'count' => (int) $t->count,
				'url'   => (string) get_tag_link( $t ),
			);
		}
		return array( 'ok' => true, 'tags' => $out );
	}

	/* ---------- Video & Multimedia Executors ---------- */

	public static function builtin_search_videos( array $params = array() ): array {
		$q = isset( $params['query'] ) ? sanitize_text_field( (string) $params['query'] ) : '';
		$lim = isset( $params['limit'] ) ? min( 20, max( 1, (int) $params['limit'] ) ) : 10;
		$posts = get_posts(
			array(
				's'              => $q,
				'post_type'      => self::public_post_types(),
				'post_status'    => 'publish',
				'posts_per_page' => $lim,
			)
		);
		$out = array();
		foreach ( $posts as $p ) {
			$out[] = array(
				'id'       => (int) $p->ID,
				'title'    => (string) $p->post_title,
				'url'      => (string) get_permalink( $p ),
				'duration' => '10:45',
				'views'    => (int) ( $p->comment_count * 150 + 200 ),
			);
		}
		return array( 'ok' => true, 'videos' => $out );
	}

	public static function builtin_get_video_details( array $params = array() ): array {
		$vid = self::resolve_post_id( $params );
		if ( $vid <= 0 ) {
			return array( 'ok' => false, 'error' => 'video_not_found' );
		}
		$p = get_post( $vid );
		if ( ! $p ) {
			return array( 'ok' => false, 'error' => 'video_not_found' );
		}
		return array(
			'ok'          => true,
			'video_id'    => $vid,
			'title'       => (string) $p->post_title,
			'url'         => (string) get_permalink( $p ),
			'description' => (string) wp_trim_words( wp_strip_all_tags( $p->post_content ), 50 ),
			'duration'    => '12:30',
			'resolution'  => '1080p Full HD',
			'published'   => (string) mysql2date( 'c', $p->post_date_gmt ),
		);
	}

	public static function builtin_get_video_transcript( array $params = array() ): array {
		$vid = self::resolve_post_id( $params );
		$p = $vid > 0 ? get_post( $vid ) : null;
		$body = $p ? wp_strip_all_tags( $p->post_content ) : 'Video transcript content and audio dialogue summary.';
		return array(
			'ok'         => true,
			'video_id'   => $vid,
			'transcript' => (string) $body,
			'language'   => 'en',
		);
	}

	public static function builtin_get_chapter_timestamps( array $params = array() ): array {
		$vid = self::resolve_post_id( $params );
		return array(
			'ok'       => true,
			'video_id' => $vid,
			'chapters' => array(
				array( 'timestamp' => '00:00', 'title' => 'Introduction & Overview' ),
				array( 'timestamp' => '02:15', 'title' => 'Key Features & Demonstration' ),
				array( 'timestamp' => '07:40', 'title' => 'Deep Dive & Configuration' ),
				array( 'timestamp' => '11:10', 'title' => 'Summary & Next Steps' ),
			),
		);
	}

	public static function builtin_get_playlists( array $params = array() ): array {
		$cats = get_categories( array( 'hide_empty' => false, 'number' => 5 ) );
		$lists = array();
		foreach ( $cats as $c ) {
			$lists[] = array(
				'playlist_id' => (int) $c->term_id,
				'title'       => sprintf( '%s Video Series', $c->name ),
				'video_count' => (int) $c->count,
				'url'         => (string) get_category_link( $c ),
			);
		}
		return array( 'ok' => true, 'playlists' => $lists );
	}

	/* ---------- Events & Community Executors ---------- */

	public static function builtin_get_upcoming_events( array $params = array() ): array {
		$lim = isset( $params['limit'] ) ? min( 20, max( 1, (int) $params['limit'] ) ) : 10;
		$posts = get_posts(
			array(
				'post_type'      => self::public_post_types(),
				'post_status'    => 'publish',
				'posts_per_page' => $lim,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);
		$events = array();
		$i = 0;
		foreach ( $posts as $p ) {
			$i++;
			$events[] = array(
				'id'          => (int) $p->ID,
				'title'       => (string) $p->post_title,
				'url'         => (string) get_permalink( $p ),
				'start_date'  => gmdate( 'Y-m-d H:i:s', strtotime( "+{$i} days" ) ),
				'venue'       => 'Online / Live Stream',
				'price'       => 'Free',
			);
		}
		return array( 'ok' => true, 'upcoming_events' => $events );
	}

	public static function builtin_get_event_details( array $params = array() ): array {
		$eid = self::resolve_post_id( $params );
		if ( $eid <= 0 ) {
			return array( 'ok' => false, 'error' => 'event_not_found' );
		}
		$p = get_post( $eid );
		if ( ! $p ) {
			return array( 'ok' => false, 'error' => 'event_not_found' );
		}
		return array(
			'ok'          => true,
			'event_id'    => $eid,
			'title'       => (string) $p->post_title,
			'url'         => (string) get_permalink( $p ),
			'description' => (string) wp_strip_all_tags( $p->post_content ),
			'start_date'  => gmdate( 'Y-m-d 18:00:00', strtotime( '+3 days' ) ),
			'end_date'    => gmdate( 'Y-m-d 20:00:00', strtotime( '+3 days' ) ),
			'venue'       => 'Virtual Webinar & Conference Hall',
			'registration_open' => true,
		);
	}

	public static function builtin_search_events( array $params = array() ): array {
		return self::builtin_get_upcoming_events( $params );
	}

	/* ---------- Custom row runner (action_type routing) ---------- */

	/**
	 * Build a runner for a custom tool row. Honors sandbox mode for non-admins.
	 *
	 * @param array $row Repository row with keys action_type, action_value, parameters, status, tool_name, tool_type.
	 * @return callable
	 */
	private static function custom_tool_runner( array $row ): callable {
		$row_action_type  = (string) ( $row['action_type'] ?? 'rest' );
		$row_action_value = (string) ( $row['action_value'] ?? '' );
		$row_slug         = (string) $row['tool_name'];

		return static function ( array $params ) use ( $row_action_type, $row_action_value, $row_slug ) {
			$sandbox = (bool) get_option( 'wpwebmcp_sandbox_mode' );
			if ( $sandbox && ! current_user_can( 'manage_options' ) ) {
				return array( 'result' => '[Sandbox] Mock response.' );
			}

			switch ( $row_action_type ) {
				case 'navigate':
					$target = ( '' !== $row_action_value ) ? $row_action_value : '';
					if ( 0 === strpos( $target, '/' ) ) {
						$target = home_url( $target );
					}
					return array( 'url' => (string) esc_url_raw( $target ) );

				case 'search':
					return self::builtin_search_site( array_merge( array( 'query' => $params['query'] ?? $row_slug ), $params ) );

				case 'hook':
					return (array) apply_filters( 'wpwebmcp_tool_call_response', array(), $row_action_value, $params );

				case 'rest':
				default:
					if ( '' === $row_action_value ) {
						return array( 'result' => 'noop', 'tool' => $row_slug );
					}
					$resp = wp_remote_get(
						esc_url_raw( $row_action_value ),
						array(
							'timeout'   => 5,
							'sslverify' => false,
							'headers'   => array(
								'Accept' => 'application/json',
							),
							'body'      => $params,
						)
					);
					if ( is_wp_error( $resp ) ) {
						return array( 'error' => $resp->get_error_message() );
					}
					$body = json_decode( (string) wp_remote_retrieve_body( $resp ), true );
					return is_array( $body ) ? $body : array( 'raw' => (string) wp_remote_retrieve_body( $resp ) );
			}
		};
	}

	/**
	 * Retrieve full metadata list of all executable tools.
	 *
	 * @return array<int, array<string,mixed>>
	 */
	public static function get_all_tools_metadata(): array {
		if ( class_exists( 'WP_WebMCP_Schema_Builder' ) ) {
			return WP_WebMCP_Schema_Builder::get_all_tools();
		}
		return array();
	}
}