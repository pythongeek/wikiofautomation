<?php
/**
 * Activator — full activation contract per Doc §2.4, §4.4, Part 16, §4.7.
 *
 * Activation order (per blog or single site):
 *   1. create/upgrade 3 tables via dbDelta()  (Doc §4.4)
 *   2. seed 32 default options                (Part 16; add_option only — never overwrite)
 *   3. set wpwebmcp_db_version = WEBMCP_NEXUS_DB_VERSION
 *   4. schedule 4 cron events                  (Doc §4.7)
 *   5. flush rewrite rules                     (so llms.txt / well-known register on init first)
 *   6. .htaccess marker attempt                (XF04 amendment)
 *
 * Multisite-aware: loops `get_sites()`, switches to each blog, runs steps 1-6,
 * restores, caps the pass at 100 sites (remainder flagged in network admin by
 * the multisite integration class).
 *
 * Rules: never touches content, never echoes, every failure degrades silently
 * (no fatal — Doc Part 3 rule 10).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_WebMCP_Activator {

	/**
	 * Multisite site cap per activation pass (Doc §4.10).
	 */
	private const SITES_PER_PASS = 100;

	/**
	 * Hook called by register_activation_hook in wp-webmcp.php.
	 */
	public static function activate( bool $network_wide = false ): void {
		if ( ! defined( 'WEBMCP_NEXUS_DB_VERSION' ) ) {
			// Fallback if main file did not load — should not happen in practice.
			return;
		}

		if ( is_multisite() && $network_wide ) {
			self::activate_network_wide();
		} else {
			self::activate_single_site();
		}
	}

	/* ============================================================
	 * Single-site activation
	 * ============================================================ */

	private static function activate_single_site(): void {
		self::create_tables();
		self::seed_options();
		self::set_db_version();
		self::schedule_crons();
		self::maybe_write_htaccess_marker();
		flush_rewrite_rules( false );
	}

	/* ============================================================
	 * Network-wide activation (multisite)
	 * ============================================================ */

	private static function activate_network_wide(): void {
		// Network-level options (§4.10 + Part 16 #25-26).
		self::add_option_if_absent( 'wpwebmcp_network_enabled', true );
		self::add_option_if_absent( 'wpwebmcp_network_excluded_ids', array() );

		$blog_ids = self::collect_blog_ids( self::SITES_PER_PASS );
		foreach ( $blog_ids as $blog_id ) {
			switch_to_blog( $blog_id );
			self::activate_single_site();
			restore_current_blog();
		}
	}

	private static function collect_blog_ids( int $limit ): array {
		// WordPress 4.6+ — sites are returned as WP_Site objects.
		if ( function_exists( 'get_sites' ) ) {
			$sites = get_sites( array( 'number' => $limit, 'fields' => 'ids' ) );
			return is_array( $sites ) ? array_map( 'intval', $sites ) : array();
		}
		// Legacy fallback.
		$ids = array();
		$rows = get_site_option( 'wpwebmcp_pending_blog_ids' ); // not used today; placeholder.
		unset( $rows );
		return $ids;
	}

	/* ============================================================
	 * Step 1 — Tables (Doc §4.4, verbatim DDL)
	 * ============================================================ */

	public static function create_tables(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset_collate = $wpdb->get_charset_collate();

		$tools_sql = "CREATE TABLE {$wpdb->prefix}wpwebmcp_tools (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			tool_name VARCHAR(100) NOT NULL,
			tool_description TEXT NOT NULL,
			tool_type VARCHAR(10) NOT NULL DEFAULT 'read',
			tool_scope VARCHAR(20) NOT NULL DEFAULT 'all',
			action_type VARCHAR(20) NOT NULL,
			action_value TEXT NOT NULL,
			parameters LONGTEXT NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY uq_tool_name (tool_name),
			KEY idx_status (status)
		) {$charset_collate};";

		$log_sql = "CREATE TABLE {$wpdb->prefix}wpwebmcp_log (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			tool_name VARCHAR(100) NOT NULL,
			params TEXT NULL,
			status VARCHAR(20) NOT NULL,
			error_message TEXT NULL,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			ip_address VARCHAR(45) NULL,
			ip_hashed VARCHAR(64) NULL,
			execution_ms INT UNSIGNED NOT NULL DEFAULT 0,
			agent_slug VARCHAR(50) NULL DEFAULT NULL,
			logged_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY idx_logged_at (logged_at),
			KEY idx_tool_status (tool_name, status),
			KEY idx_user (user_id),
			KEY idx_agent_slug (agent_slug)
		) {$charset_collate};";

		$bot_sql = "CREATE TABLE {$wpdb->prefix}wpwebmcp_bot_log (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			bot_name VARCHAR(100) NOT NULL,
			bot_category VARCHAR(50) NOT NULL DEFAULT '',
			post_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			ip_hash VARCHAR(64) NOT NULL DEFAULT '',
			hits INT UNSIGNED NOT NULL DEFAULT 1,
			logged_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY uq_bot_post (bot_name, post_id),
			KEY idx_logged_at (logged_at)
		) {$charset_collate};";

		$write_sql = "CREATE TABLE {$wpdb->prefix}wpwebmcp_write_log (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			event_type VARCHAR(40) NOT NULL,
			target_key VARCHAR(190) NOT NULL,
			target_id BIGINT UNSIGNED NULL DEFAULT NULL,
			actor VARCHAR(60) NOT NULL DEFAULT 'system',
			ip_hash VARCHAR(64) NULL DEFAULT NULL,
			before_json LONGTEXT NULL,
			after_json LONGTEXT NULL,
			diff_summary VARCHAR(255) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'applied',
			rollback_of BIGINT UNSIGNED NULL DEFAULT NULL,
			rolled_back_id BIGINT UNSIGNED NULL DEFAULT NULL,
			note TEXT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY idx_created_at (created_at),
			KEY idx_target_key (target_key),
			KEY idx_status (status),
			KEY idx_event_type (event_type)
		) {$charset_collate};";

		dbDelta( $tools_sql );
		dbDelta( $log_sql );
		dbDelta( $bot_sql );
		dbDelta( $write_sql );
	}

	/**
	 * Default site options (30 canonical options per Doc Part 16).
	 */
	public const DEFAULT_OPTIONS = array(
		// 1
		'wpwebmcp_enabled'                  => true,
		// 2
		'wpwebmcp_excluded_ids'             => array(),
		// 3 — role × tool-type matrix. Default: admins = read+write, others = read, anon = read.
		'wpwebmcp_role_access'              => array(
			'administrator' => array( 'read', 'write' ),
			'editor'        => array( 'read' ),
			'author'        => array( 'read' ),
			'contributor'   => array( 'read' ),
			'subscriber'    => array( 'read' ),
			'anonymous'     => array( 'read' ),
		),
		// 4
		'wpwebmcp_rate_limit_read'          => 60,
		// 5
		'wpwebmcp_rate_limit_write'         => 20,
		// 6
		'wpwebmcp_log_privacy_mode'         => false,
		// 7
		'wpwebmcp_log_retention_days'       => 30,
		// 8
		'wpwebmcp_token_optimize'           => false,
		// 9
		'wpwebmcp_polyfill_enabled'         => true,
		// 10
		'wpwebmcp_woo_enabled'              => true,
		// 11
		'wpwebmcp_analytics_enabled'        => true,
		// 12
		'wpwebmcp_bot_detection_enabled'    => true,
		// 13
		'wpwebmcp_performance_mode'         => false,
		// 14
		'wpwebmcp_max_calls_per_session'    => 200,
		// 15
		'wpwebmcp_llmstxt_mode'             => 'auto',
		// 16
		'wpwebmcp_llmstxt_custom'           => '',
		// 17
		'wpwebmcp_markdown_enabled'         => true,
		// 18
		'wpwebmcp_wellknown_enabled'        => true,
		// 19
		'wpwebmcp_sandbox_mode'             => false,
		// 20
		'wpwebmcp_alerts_enabled'           => false,
		// 21
		'wpwebmcp_alert_email'              => '',
		// 22
		'wpwebmcp_custom_post_types'        => array( 'post', 'page' ),
		// 23 — uninstall gate (default off = light uninstall path).
		'wpwebmcp_cleanup_uninstall'        => false,
		// 24 — db version lives here, no autoload.
		'wpwebmcp_db_version'               => 0,
		// 27
		'wpwebmcp_bot_log_retention_days'   => 90,
		// 28
		'wpwebmcp_ga4_enabled'              => false,
		// 29
		'wpwebmcp_crawler_directives'       => array(),
		// 30
		'wpwebmcp_custom_crawlers'          => array(),
		// 31 — runtime-only flag, never exported.
		'wpwebmcp_htaccess_notice'          => false,
		// 32
		'wpwebmcp_db_optimize_cron'         => false,
		// 33 — Module 0 M0a: SSE pub/sub push tools
		'wpwebmcp_push_enabled'             => true,
		// 34 — per-site push token, generated lazily on first push-server init.
		'wpwebmcp_push_token'               => '',
		// 35 — max concurrent SSE subscribers per site (Litespeed / shared-host guard).
		'wpwebmcp_push_max_subscribers'     => 50,
		// 36 — default SSE connection lifetime in seconds (client must reconnect after).
		'wpwebmcp_push_connection_ttl'      => 300,
		// 37 — heartbeat interval in seconds (keeps proxies from killing the connection).
		'wpwebmcp_push_heartbeat_seconds'   => 15,
		// 38 — Module 0 M0b: aggregator master toggle.
		'wpwebmcp_aggregator_enabled'       => true,
		// 39 — Module 0 M0b: child site registry (local / multisite / remote).
		'wpwebmcp_aggregator_sites'         => array(),
		// 40 — Module 0 M0c: agent identity resolver master toggle.
		'wpwebmcp_agent_identity_enabled'   => true,
		// 41 — Module 0 M0c: per-agent admin toggles.
		//      shape: [ 'gptbot' => [ 'enabled' => true, 'per_minute_limit' => 60 ], ... ]
		//      falls back to global read/write limit when the per-agent entry is absent
		//      or when 'per_minute_limit' is 0 / empty.
		'wpwebmcp_agent_settings'           => array(),
		// 42 — Module 0 M0c: block list of UA fragments (case-insensitive substring).
		//      any caller whose User-Agent contains any of these is rejected with 403
		//      before rate limit / audit even run.
		'wpwebmcp_agent_blocklist'          => array(),
		// 43 — Module 0 M0d: write-tool audit log retention window in days.
		//      Valid range 1-365. 0 = keep forever. Daily cron prunes.
		'wpwebmcp_write_log_retention_days' => 30,
		// 44 — Module 0 M0d: master toggle for write-log capture + rollback UI.
		//      When false, option changes are NOT snapshotted and the Rollback
		//      button stays hidden.
		'wpwebmcp_write_log_enabled'        => true,
		// 45 — Module A A1a: site-wide default license string attached to
		//      every citation emitted by a tool response (AEO layer). Empty
		//      string = unspecified; common values include "CC-BY-4.0",
		//      "CC-BY-SA-4.0", "all-rights-reserved".
		'wpwebmcp_default_license'          => '',
		// 46 — Module A A2b: HMAC secret used to sign citation-proof and
		//      premium-receipt tokens. Empty placeholder; lazily generated
		//      on first use by WP_WebMCP_Exposure_Tier::secret() and stored
		//      non-autoloaded so it stays out of the alloptions cache.
		'wpwebmcp_exposure_secret'          => '',
		// 47 — Module A A2a: per-agent access policies (visual policy builder).
		//      Stored as an array of policy rows; empty by default so admins
		//      build policies via the admin UI or the REST routes.
		'wpwebmcp_policies'                 => array(),
		// 48 — Module A A1c: master toggle for the freshness ping protocol
		//      (IndexNow-style pings + SSE content_updated events).
		'wpwebmcp_freshness_enabled'        => false,
		// 49 — Module A A1c: IndexNow API key (8-128 hex chars). Generate at
		//      https://www.indexnow.org/ and upload <key>.txt to the site root.
		'wpwebmcp_indexnow_key'             => '',
		// 50 — Module A A1c: IndexNow submission endpoint. Default fans out to
		//      Bing + Yandex + Seznam + Naver via the shared API.
		'wpwebmcp_indexnow_endpoint'        => 'https://api.indexnow.org/indexnow',
	);

	public static function seed_options(): void {
		foreach ( self::DEFAULT_OPTIONS as $key => $default ) {
			self::add_option_if_absent( $key, $default );
		}

		// Network options (#25, #26) — only when actually multisite.
		if ( is_multisite() ) {
			self::add_site_option_if_absent( 'wpwebmcp_network_enabled', true );
			self::add_site_option_if_absent( 'wpwebmcp_network_excluded_ids', array() );
		}
	}

	private static function add_option_if_absent( string $key, mixed $default ): void {
		if ( false === get_option( $key, false ) ) {
			// autoload=no for db_version + backup slots; yes for everything else.
			$autoload = ( 'wpwebmcp_db_version' === $key ) ? 'no' : 'yes';
			add_option( $key, $default, '', $autoload );
		}
	}

	/**
	 * Helper for network options. `add_site_option` itself is idempotent in WP,
	 * but we wrap it for symmetry with the site-option helper.
	 */
	private static function add_site_option_if_absent( string $key, mixed $default ): void {
		if ( false === get_site_option( $key, false ) ) {
			add_site_option( $key, $default );
		}
	}

	/* ============================================================
	 * Step 3 — db version marker
	 * ============================================================ */

	public static function set_db_version(): void {
		update_option( 'wpwebmcp_db_version', (int) WEBMCP_NEXUS_DB_VERSION, false );
	}

	/* ============================================================
	 * Step 4 — Cron events (Doc §4.7)
	 * ============================================================ */

	public static function schedule_crons(): void {
		if ( ! function_exists( 'wp_schedule_event' ) ) {
			return;
		}

		// Daily log purge.
		if ( ! wp_next_scheduled( 'wpwebmcp_log_purge' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'wpwebmcp_log_purge' );
		}
		// Daily bot analytics rollup.
		if ( ! wp_next_scheduled( 'wpwebmcp_bot_analytics_rollup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'wpwebmcp_bot_analytics_rollup' );
		}
		// Weekly schema validation.
		if ( ! wp_next_scheduled( 'wpwebmcp_schema_validation' ) ) {
			wp_schedule_event( time() + DAY_IN_SECONDS, 'weekly', 'wpwebmcp_schema_validation' );
		}
		// Daily write-log prune (Module 0 M0d). Retains snapshot rows for
		// `wpwebmcp_write_log_retention_days` (default 30, range 1-365).
		if ( ! wp_next_scheduled( 'wpwebmcp_write_log_prune' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'wpwebmcp_write_log_prune' );
		}
	}

	/* ============================================================
	 * Step 5 — rewrite flush (llms.txt / well-known register on init first)
	 * ============================================================ */
	// Implemented inline in activate_single_site via flush_rewrite_rules(false).

	/* ============================================================
	 * Step 6 — .htaccess marker attempt (XF04 amendment)
	 *
	 * Best-effort: writes a guarded BEGIN/END block to .htaccess so the
	 * llms.txt and well-known rewrites survive permalink resets. Sets
	 * wpwebmcp_htaccess_notice=true on any failure for the admin to surface.
	 * ============================================================ */

	public static function maybe_write_htaccess_marker(): void {
		// Step 12 will own the actual insert; here we only set the notice flag
		// when the environment can't be written to. This keeps the contract
		// honest (the option exists at activation time per Part 16 #31) without
		// duplicating Step 12's logic.
		if ( ! function_exists( 'insert_with_markers' ) ) {
			require_once ABSPATH . 'wp-admin/includes/misc.php';
		}
		// Actual marker write happens in WP_WebMCP_LlmsTxt / WP_WebMCP_Well_Known (Step 12)
		// once those classes exist and we have a real rewrite rule to anchor.
		// No-op here. The notice stays false until Step 12 flips it.
	}
}
