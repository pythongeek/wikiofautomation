<?php
/**
 * Deactivator — per Doc §2.4.
 *
 * Clears the 3 cron events, flushes rewrite rules. Data, options, tables stay.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_WebMCP_Deactivator {

	/**
	 * Hook called by register_deactivation_hook in wp-webmcp.php.
	 */
	public static function deactivate(): void {
		self::clear_crons();
		flush_rewrite_rules( false );
	}

	/**
	 * Unschedule the 3 plugin cron events. wp_unschedule_event is a no-op
	 * when the event isn't scheduled — safe to call unconditionally.
	 */
	private static function clear_crons(): void {
		$hooks = array(
			'wpwebmcp_log_purge',
			'wpwebmcp_bot_analytics_rollup',
			'wpwebmcp_schema_validation',
		);

		foreach ( $hooks as $hook ) {
			$timestamp = wp_next_scheduled( $hook );
			if ( false !== $timestamp ) {
				wp_unschedule_event( $timestamp, $hook );
			}
		}
	}
}
