<?php
/**
 * Design — Doc §5.9.
 *
 * Emits the design-token :root block as inline CSS on plugin screens
 * (and on the meta-box path so the post editor picks up the same
 * variables). Bound to `admin_head` so it lands inside <head> before
 * the stylesheet is parsed — tokens then resolve correctly.
 *
 * Tokens themselves live in admin/css/wp-webmcp-admin.css as the
 * canonical copy. This class mirrors the same block to support the
 * meta-box inline-style path per §5.9. Doc §5.2 is explicit: ONE
 * :root block — no hardcoded hex outside it and the component specs.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Design {

	/** Capability required. */
	private const CAPABILITY = 'manage_options';

	/**
	 * Hook `admin_head` to emit the token block on plugin screens only.
	 *
	 * Wired from WP_WebMCP::define_admin_hooks() at priority 10.
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'admin_head', array( __CLASS__, 'emit_tokens' ), 10, 0 );
	}

	/**
	 * Print the canonical :root block inside the admin <head>.
	 *
	 * Gate: only on wp-admin screens that the plugin owns. Detection
	 * uses WP_WebMCP_Admin::hook_suffixes() which is populated after
	 * admin_menu fires; before that point, the gate allows no output
	 * (safe default).
	 */
	public static function emit_tokens(): void {
		if ( ! is_admin() ) {
			return;
		}

		$screen = get_current_screen();
		if ( ! $screen || ! isset( $screen->id ) ) {
			return;
		}

		// Allow-list: the 8 plugin screens + the post editor (for the meta box).
		$allowed = self::allowed_screens( $screen->id );
		if ( ! $allowed ) {
			return;
		}

		// Capability check (defence in depth — nonces still gate POST).
		if ( ! current_user_can( self::CAPABILITY ) && 'post' !== $screen->base ) {
			return;
		}

		?>
		<style id="wp-webmcp-design-tokens">
		<?php echo wp_strip_all_tags( self::css_root_block() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS stylesheet tokens stripped of all tags and safe for style tag. ?>
		</style>
		<?php
	}

	/**
	 * Build the allowed-screen list. Public so a future meta-box
	 * helper can reuse it without touching the private gate.
	 *
	 * @return string[] Pattern list matching WP_Screen::id values.
	 */
	public static function allowed_screens( string $current_id ): bool {
		// Meta box path: post edit screens for our supported post types.
		// Doc §5.8 #10 spec'd the meta box on all public post types.
		if ( false !== strpos( $current_id, 'post' ) && in_array( $current_id, array( 'post', 'page' ), true ) ) {
			return true;
		}
		// Or any of the 8 plugin screens (id matches the parent slug or sub-slug).
		foreach ( WP_WebMCP_Admin::hook_suffixes() as $suffix ) {
			// The suffix is the second arg returned by add_menu_page / add_submenu_page.
			// WP translates that to a screen id of the form "toplevel_page_$slug"
			// or "${parent}_page_$slug". We use the suffixes we know about.
			$expected = 'toplevel_page_' . WP_WebMCP_Admin::PARENT_SLUG;
			if ( $current_id === $expected ) {
				return true;
			}
			if ( false !== strpos( $current_id, WP_WebMCP_Admin::PARENT_SLUG ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * The canonical :root block — copied EXACTLY from Doc §5.2.
	 *
	 * This must stay byte-for-byte identical to the Doc (and to the
	 * top of admin/css/wp-webmcp-admin.css). If the Doc changes, both
	 * copies update together.
	 *
	 * @return string CSS body (no <style> wrapper).
	 */
	public static function css_root_block(): string {
		return <<<'CSS'
:root {
  /* color */
  --wpwm-accent:        #5b5fef;  /* indigo — links, primary buttons, active states */
  --wpwm-accent-hover:  #4a4de0;
  --wpwm-accent-soft:   #eef0ff;  /* tinted backgrounds, badge fills */
  --wpwm-success:       #00a32a;
  --wpwm-warning:       #dba617;
  --wpwm-error:         #d63638;
  --wpwm-info:          #2271b1;
  --wpwm-bg:            #f0f0f1;  /* wp-admin gray */
  --wpwm-surface:       #ffffff;
  --wpwm-border:        #c3c4c7;
  --wpwm-border-soft:   #e2e4e7;
  --wpwm-text:          #1d2327;
  --wpwm-text-muted:    #646970;
  /* type (inherit WP core stack) */
  --wpwm-font:          -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --wpwm-fs-xs: 11px; --wpwm-fs-sm: 12px; --wpwm-fs-md: 13px;
  --wpwm-fs-lg: 15px; --wpwm-fs-xl: 20px; --wpwm-fs-2xl: 28px;
  /* spacing scale (4px base) */
  --wpwm-sp-1: 4px;  --wpwm-sp-2: 8px;  --wpwm-sp-3: 12px;
  --wpwm-sp-4: 16px; --wpwm-sp-5: 24px; --wpwm-sp-6: 32px;
  /* shape & elevation */
  --wpwm-radius: 6px;
  --wpwm-shadow: 0 1px 2px rgba(0,0,0,.06);
  --wpwm-shadow-pop: 0 4px 16px rgba(0,0,0,.12);
  /* layout */
  --wpwm-maxw: 1200px;
  --wpwm-ring-size: 132px;
}
CSS;
	}
}