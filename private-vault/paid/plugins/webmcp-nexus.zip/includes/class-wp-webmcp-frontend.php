<?php
/**
 * Frontend — public-facing hook layer per Doc Part 6.
 *
 * Responsibilities (§6.1 + §6.2 + §6.3):
 *   - Five-gate enable chain (Doc §6.1, exact order; exclusions beat overrides).
 *   - Enqueue the register.js + optional polyfill.js (defer, only when enabled).
 *   - Render the <head> output (policy meta + ONE manifest script tag).
 *   - Expose exactly 8 localized vars to JS (Doc §6.3).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- frontend shortcode form posts are validated via wp_nonce_field() in the shortcode template, not in this class
final class WP_WebMCP_Frontend {

	/** Script handle for the browser-side registration runner. */
	private const HANDLE_REGISTER = 'wp-webmcp-register';

	/** Script handle for the MCP-B polyfill (loaded only when wpwebmcp_polyfill_enabled). */
	private const HANDLE_POLYFILL = 'wp-webmcp-polyfill';

	/**
	 * Hook all frontend actions. Called from WP_WebMCP::define_public_hooks().
	 */
	public static function init(): void {
		// Use init priority 10 so CPT/scope resolution is ready.
		WP_WebMCP_Loader::register_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_scripts' ) );
		WP_WebMCP_Loader::register_action( 'wp_head',            array( __CLASS__, 'render_head' ), 99 );
		WP_WebMCP_Loader::register_action( 'send_headers',       array( __CLASS__, 'send_http_headers' ) );
	}

	/**
	 * Five-gate enable chain per Doc §6.1. Exact order; exclusions beat overrides.
	 *
	 * @param int|null $post_id Optional explicit post ID; defaults to current.
	 * @return bool
	 */
	public static function is_enabled_for_current_page( ?int $post_id = null ): bool {
		if ( null === $post_id ) {
			$post_id = (int) get_queried_object_id();
			if ( $post_id <= 0 ) {
				$post_id = (int) get_the_ID();
			}
		}

		// Gate 1: multisite but not network-enabled → false.
		if ( is_multisite() ) {
			$network_enabled = (bool) get_site_option( 'wpwebmcp_network_enabled', true );
			if ( ! $network_enabled ) {
				$result = false;
				return (bool) apply_filters( 'wpwebmcp_is_page_enabled', $result, $post_id );
			}

			// Gate 2: multisite post ∈ network_excluded_ids → false.
			$excluded = (array) get_site_option( 'wpwebmcp_network_excluded_ids', array() );
			$excluded = array_map( 'absint', $excluded );
			if ( in_array( $post_id, $excluded, true ) ) {
				$result = false;
				return (bool) apply_filters( 'wpwebmcp_is_page_enabled', $result, $post_id );
			}
		}

		// Gate 3: post ∈ site wpwebmcp_excluded_ids → false (exclusions beat overrides).
		$site_excluded = (array) get_option( 'wpwebmcp_excluded_ids', array() );
		$site_excluded = array_map( 'absint', $site_excluded );
		if ( in_array( $post_id, $site_excluded, true ) ) {
			$result = false;
			return (bool) apply_filters( 'wpwebmcp_is_page_enabled', $result, $post_id );
		}

		// Gate 4: post meta _wpwebmcp_override overrides sitewide setting.
		if ( $post_id > 0 ) {
			$override = (string) get_post_meta( $post_id, '_wpwebmcp_override', true );
			if ( 'off' === $override ) {
				$result = false;
				return (bool) apply_filters( 'wpwebmcp_is_page_enabled', $result, $post_id );
			}
			if ( 'on' === $override ) {
				$result = true;
				return (bool) apply_filters( 'wpwebmcp_is_page_enabled', $result, $post_id );
			}
		}

		// Gate 5: sitewide setting (default = true).
		$result = (bool) get_option( 'wpwebmcp_enabled', true );

		/**
		 * Final filter on the enable decision. The 5 gates above cannot be
		 * reordered; this filter runs last and lets third parties make a final
		 * yes/no without touching the chain.
		 *
		 * @param bool $result   Computed enable state.
		 * @param int  $post_id  The post being evaluated (0 if none).
		 */
		return (bool) apply_filters( 'wpwebmcp_is_page_enabled', $result, $post_id );
	}

	/**
	 * Resolve the current page context for the manifest builder.
	 *
	 * Returns one of: homepage, single, archive, search, 404, woo.
	 */
	private static function current_context(): string {
		if ( is_404() ) {
			return '404';
		}
		if ( is_search() ) {
			return 'search';
		}
		if ( is_singular( array( 'product' ) ) ) {
			return 'woo';
		}
		if ( function_exists( 'is_shop' ) && is_shop() ) {
			return 'woo';
		}
		if ( is_singular() ) {
			return 'single';
		}
		if ( is_home() || is_front_page() ) {
			return 'homepage';
		}
		if ( is_archive() ) {
			return 'archive';
		}
		return 'homepage';
	}

	/**
	 * Resolve the resolved role key for the current viewer.
	 *
	 * Step 10's Access_Control will own this for real; for now we mirror its
	 * shape so the role-aware policy meta works.
	 */
	private static function current_role(): string {
		if ( ! is_user_logged_in() ) {
			return 'anonymous';
		}
		$user = wp_get_current_user();
		if ( empty( $user->roles ) || ! is_array( $user->roles ) ) {
			return 'anonymous';
		}
		// Use the first role (WP convention).
		return (string) $user->roles[0];
	}

	/**
	 * Enqueue register.js (and polyfill if enabled). No output if chain says off.
	 */
	public static function enqueue_scripts(): void {
		$post_id = (int) get_queried_object_id();
		if ( ! self::is_enabled_for_current_page( $post_id ) ) {
			return;
		}

		// Polyfill — only when wpwebmcp_polyfill_enabled = true and file is present.
		$polyfill_on = (bool) get_option( 'wpwebmcp_polyfill_enabled', true );
		if ( $polyfill_on && file_exists( WEBMCP_NEXUS_PATH . 'public/js/wp-webmcp-polyfill.js' ) ) {
			wp_register_script(
				self::HANDLE_POLYFILL,
				WEBMCP_NEXUS_URL . 'public/js/wp-webmcp-polyfill.js',
				array(),
				WEBMCP_NEXUS_VERSION,
				true
			);
			wp_script_add_data( self::HANDLE_POLYFILL, 'strategy', 'defer' );
			wp_enqueue_script( self::HANDLE_POLYFILL );
			$deps = array( self::HANDLE_POLYFILL );
		} else {
			$deps = array();
		}

		// Register.js — always loaded when chain is on.
		wp_register_script(
			self::HANDLE_REGISTER,
			WEBMCP_NEXUS_URL . 'public/js/wp-webmcp-register.js',
			$deps,
			WEBMCP_NEXUS_VERSION,
			true
		);
		wp_script_add_data( self::HANDLE_REGISTER, 'strategy', 'defer' );

		// Localize EXACTLY 8 keys per Doc §6.3.
		$page_type = self::current_context();
		$rest_url  = rest_url( 'wpwebmcp/v1/call/' );

		// Nonce is wp_create_nonce('wp_rest') — used as X-WP-Nonce header in fetch().
		wp_localize_script(
			self::HANDLE_REGISTER,
			'WPWEBMCP',
			array(
				'restUrl'         => $rest_url,
				'nonce'           => wp_create_nonce( 'wp_rest' ),
				'analyticsUrl'    => rest_url( 'wpwebmcp/v1/analytics' ),
				'mcpUrl'          => rest_url( 'wpwebmcp/v1/mcp' ),
				'sseUrl'          => rest_url( 'wpwebmcp/v1/sse' ),
				'manifestUrl'     => rest_url( 'wpwebmcp/v1/manifest' ),
				'toolsUrl'        => rest_url( 'wpwebmcp/v1/tools' ),
				'postId'          => max( 0, $post_id ),
				'pageType'        => $page_type,
				'userRole'        => self::current_role(),
				'performanceMode' => (bool) get_option( 'wpwebmcp_performance_mode', false ),
				'ga4Enabled'      => (bool) get_option( 'wpwebmcp_ga4_enabled', false ),
			)
		);

		wp_enqueue_script( self::HANDLE_REGISTER );

		// Frontend Agent HUD & Live Inspector Deck (Admin / Preview / Enabled mode).
		$hud_mode = (string) get_option( 'wpwebmcp_frontend_hud', 'admin_only' );
		$can_view_hud = ( 'all' === $hud_mode )
			|| ( 'admin_only' === $hud_mode && current_user_can( 'manage_options' ) )
			|| ( isset( $_GET['webmcp_inspect'] ) && current_user_can( 'manage_options' ) );

		if ( 'off' !== $hud_mode && $can_view_hud ) {
			wp_enqueue_style(
				'wp-webmcp-hud',
				WEBMCP_NEXUS_URL . 'public/css/wp-webmcp-hud.css',
				array(),
				WEBMCP_NEXUS_VERSION
			);
			wp_enqueue_script(
				'wp-webmcp-hud',
				WEBMCP_NEXUS_URL . 'public/js/wp-webmcp-hud.js',
				array( self::HANDLE_REGISTER ),
				WEBMCP_NEXUS_VERSION,
				true
			);
		}
	}

	/**
	 * Send standardized HTTP headers for AI bots, scrapers, MCP clients, and browser tools.
	 */
	public static function send_http_headers(): void {
		if ( is_admin() ) {
			return;
		}
		$post_id = (int) get_queried_object_id();
		if ( ! self::is_enabled_for_current_page( $post_id ) ) {
			return;
		}
		if ( ! headers_sent() ) {
			header( 'X-WebMCP: 1.0' );
			header( 'X-ModelContextProtocol: 1.0' );
			header( 'X-MCP-Server: ' . rest_url( 'wpwebmcp/v1/mcp' ) );
			header( 'Link: <' . rest_url( 'wpwebmcp/v1/manifest' ) . '>; rel="model-context-protocol"', false );
			header( 'Link: <' . rest_url( 'wpwebmcp/v1/manifest' ) . '>; rel="mcp"', false );
			header( 'Link: <' . rest_url( 'wpwebmcp/v1/mcp' ) . '>; rel="mcp-server"', false );
			header( 'Link: <' . rest_url( 'wpwebmcp/v1/sse' ) . '>; rel="model-context-protocol-sse"', false );
		}
	}

	/**
	 * Render the <head> output: policy meta, MCP discovery links, and the manifest script tag.
	 */
	public static function render_head(): void {
		$post_id = (int) get_queried_object_id();
		if ( ! self::is_enabled_for_current_page( $post_id ) ) {
			return;
		}

		$manifest = WP_WebMCP_Schema_Builder::build(
			self::current_context(),
			$post_id,
			self::current_role()
		);

		// Token optimize is off by default; honor the user setting so the
		// frontend mirrors the /manifest REST endpoint.
		if ( (bool) get_option( 'wpwebmcp_token_optimize', false ) ) {
			$manifest['tools'] = WP_WebMCP_Schema_Builder::apply_token_optimize( $manifest['tools'] );
		}

		$policy       = self::policy_directives( self::current_role() );
		$manifest_url = rest_url( 'wpwebmcp/v1/manifest' );
		$mcp_url      = rest_url( 'wpwebmcp/v1/mcp' );
		$sse_url      = rest_url( 'wpwebmcp/v1/sse' );

		$md_url       = add_query_arg( 'format', 'markdown' );

		// Policy meta + Discovery tags for DevTools and AI clients
		printf( '<meta name="webmcp-policy" content="%s">' . "\n", esc_attr( $policy ) );
		printf( '<meta name="model-context-protocol" content="%s">' . "\n", esc_url( $manifest_url ) );
		printf( '<meta name="mcp-server" content="%s">' . "\n", esc_url( $mcp_url ) );
		printf( '<meta name="webmcp-version" content="1.0">' . "\n" );
		printf( '<meta name="ai-agent-priority" content="high">' . "\n" );
		printf( '<meta name="ai-content-format" content="markdown">' . "\n" );
		printf( '<link rel="model-context-protocol" href="%s" type="application/json">' . "\n", esc_url( $manifest_url ) );
		printf( '<link rel="mcp" href="%s" type="application/json">' . "\n", esc_url( $manifest_url ) );
		printf( '<link rel="webmcp" href="%s" type="application/json">' . "\n", esc_url( $manifest_url ) );
		printf( '<link rel="model-context-protocol-sse" href="%s">' . "\n", esc_url( $sse_url ) );
		printf( '<link rel="alternate" type="application/json" href="%s" title="WebMCP Manifest">' . "\n", esc_url( $manifest_url ) );
		printf( '<link rel="alternate" type="text/markdown" href="%s" title="Clean Semantic Markdown for AI Agents">' . "\n", esc_url( $md_url ) );
		printf( '<link rel="ai-content" type="text/markdown" href="%s">' . "\n", esc_url( $md_url ) );
		printf( '<script type="application/json" id="webmcp-manifest">%s</script>' . "\n", wp_json_encode( $manifest, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) );

		// Semantic JSON-LD schema with potentialAction linked to WebMCP tools
		$schema_ld = array(
			'@context' => 'https://schema.org',
			'@type'    => is_singular() ? 'Article' : 'WebSite',
			'name'     => is_singular() ? get_the_title( $post_id ) : get_bloginfo( 'name' ),
			'url'      => is_singular() ? get_permalink( $post_id ) : home_url(),
			'potentialAction' => array(
				'@type'       => 'Action',
				'name'        => 'WebMCP Agent Execution',
				'target'      => rest_url( 'wpwebmcp/v1/call/{tool}' ),
				'description' => 'Interact with this website via Model Context Protocol tools.',
			),
		);
		printf( '<script type="application/ld+json" id="webmcp-jsonld">%s</script>' . "\n", wp_json_encode( $schema_ld, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) );
	}

	/**
	 * Build the policy meta value. Role-aware per Doc §6.2:
	 *   - editors+ (administrator, editor): allow=read-tools write-tools, NO deny.
	 *   - authors/contributors/subscribers/anonymous: allow=read-tools, deny=write-tools.
	 *
	 * Includes the global session cap + crawl-delay from options.
	 *
	 * Filter `wpwebmcp_policy_directives` allows third parties to amend.
	 *
	 * @param string $role Resolved role key.
	 * @return string The `content` attribute (without the meta tag wrapper).
	 */
	private static function policy_directives( string $role ): string {
		$can_write = in_array( $role, array( 'administrator', 'editor' ), true );

		$parts = array();
		if ( $can_write ) {
			$parts[] = 'allow=read-tools write-tools';
		} else {
			$parts[] = 'allow=read-tools';
			$parts[] = 'deny=write-tools';
		}
		// Doc §6.2 example values. Not Part 16 options — these are part of the
		// policy meta format. Customization via wpwebmcp_policy_directives filter.
		$parts[] = 'max-calls-per-session=200';
		$parts[] = 'crawl-delay=1';

		/**
		 * Filter the assembled policy directive parts (array of "k=v" strings).
		 *
		 * @param string[] $parts Policy parts.
		 * @param string   $role  Resolved role key.
		 */
		$parts = (array) apply_filters( 'wpwebmcp_policy_directives', $parts, $role );

		return implode( '; ', $parts );
	}
}