<?php
/**
 * Internationalization (i18n) loader — Doc §15.
 *
 * Loads the plugin textdomain from languages/ directory.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_I18n {

	/**
	 * Load the plugin text domain for translation.
	 */
	public static function load(): void {
		$rel_path = defined( 'WEBMCP_NEXUS_BASENAME' )
			? dirname( WEBMCP_NEXUS_BASENAME ) . '/languages/'
			: 'wp-webmcp/languages/';

		// load_plugin_textdomain() disabled - WP 4.6+ auto-loads for .org-hosted plugins.
		// Original call:
		// load_plugin_textdomain('webmcp-nexus', false, $rel_path);
	}
}
