<?php
/**
 * Loader — single source of truth for hook registration.
 *
 * Owns the only add_action / add_filter calls in the plugin for
 * cross-cutting concerns. Per-step classes append their registration
 * lines to the matching define_*_hooks() method on WP_WebMCP and
 * instantiate themselves in WP_WebMCP::load_dependencies().
 *
 * Architecture (post Step-17 refactor):
 *   - The Loader is a FORWARDING pass-through. add_action() / add_filter()
 *     on the Loader register with WordPress immediately, so the Loader is
 *     the single point of registration. run() is retained for backwards
 *     compat but is effectively a no-op.
 *   - A static `current` pointer lets per-class init() methods that fire
 *     LATER (after WP's `init` action) route their hook registrations
 *     through the Loader via the static register_action() / register_filter()
 *     facades. This is what gives us "Loader-only hooks" guarantee
 *     (Doc Part 3 Rule 7) even when hooks are registered at runtime
 *     rather than at plugin boot.
 *   - If no current loader is set (e.g. very early in the WP lifecycle),
 *     the facades fall back to direct add_action/add_filter. The spec
 *     invariant is still maintained because the plugin only sets up
 *     per-class hooks after the singleton has run().
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_WebMCP_Loader {

	/**
	 * The currently-active Loader instance. Set by WP_WebMCP::run()
	 * before any define_*_hooks() call. Per-class init() methods that
	 * fire later via WP's `init` action can route through this.
	 *
	 * @var WP_WebMCP_Loader|null
	 */
	private static ?WP_WebMCP_Loader $current = null;

	/**
	 * Each list is an array of [hook, callable, priority, accepted_args].
	 * Kept for backwards compat with the original collector pattern; the
	 * instance add_action() / add_filter() methods now register with WP
	 * directly so the run() loop is a no-op.
	 *
	 * @var array<int, array{0:string,1:callable,2:int,3:int}>
	 */
	private array $actions = array();

	/**
	 * @var array<int, array{0:string,1:callable,2:int,3:int}>
	 */
	private array $filters = array();

	/**
	 * @var array<int, callable>
	 */
	private array $shortcodes = array();

	/* ============================================================
	 * Static facade — routes through current() so per-class init()
	 * methods (which fire later via WP's init) can use the Loader
	 * without holding an instance reference.
	 * ============================================================ */

	public static function set_current( ?WP_WebMCP_Loader $loader ): void {
		self::$current = $loader;
	}

	public static function current(): ?WP_WebMCP_Loader {
		return self::$current;
	}

	/**
	 * Static facade: register an action hook through the current Loader.
	 * Falls back to direct add_action() if no Loader is active.
	 *
	 * @param string   $hook
	 * @param callable $callback
	 * @param int      $priority
	 * @param int      $accepted_args
	 */
	public static function register_action( string $hook, callable $callback, int $priority = 10, int $accepted_args = 1 ): void {
		if ( self::$current instanceof WP_WebMCP_Loader ) {
			self::$current->add_action( $hook, $callback, $priority, $accepted_args );
			return;
		}
		\add_action( $hook, $callback, $priority, $accepted_args );
	}

	/**
	 * Static facade: register a filter hook through the current Loader.
	 */
	public static function register_filter( string $hook, callable $callback, int $priority = 10, int $accepted_args = 1 ): void {
		if ( self::$current instanceof WP_WebMCP_Loader ) {
			self::$current->add_filter( $hook, $callback, $priority, $accepted_args );
			return;
		}
		\add_filter( $hook, $callback, $priority, $accepted_args );
	}

	public static function register_shortcode( string $tag, callable $callback ): void {
		if ( self::$current instanceof WP_WebMCP_Loader ) {
			self::$current->add_shortcode( $tag, $callback );
			return;
		}
		\add_shortcode( $tag, $callback );
	}

	/* ============================================================
	 * Instance API — collects AND registers with WP immediately.
	 * ============================================================ */

	public function add_action( string $hook, callable $callback, int $priority = 10, int $accepted_args = 1 ): void {
		$this->actions[] = array( $hook, $callback, $priority, $accepted_args );
		// Forward to WordPress immediately. This is the registration point
		// for the whole plugin — per Doc Part 3 Rule 7 there should be no
		// bare add_action() anywhere else.
		\add_action( $hook, $callback, $priority, $accepted_args );
	}

	public function add_filter( string $hook, callable $callback, int $priority = 10, int $accepted_args = 1 ): void {
		$this->filters[] = array( $hook, $callback, $priority, $accepted_args );
		\add_filter( $hook, $callback, $priority, $accepted_args );
	}

	public function add_shortcode( string $tag, callable $callback ): void {
		$this->shortcodes[ $tag ] = $callback;
		\add_shortcode( $tag, $callback );
	}

	/**
	 * Apply collected actions. Retained for backwards compat with the
	 * original collector pattern; the instance add_action() / add_filter()
	 * methods already register with WordPress directly, so this loop is
	 * a no-op for the new path. It is still safe to call: WP's add_action
	 * is idempotent for identical (hook, callback, priority, args) tuples.
	 */
	public function run(): void {
		// Self::set_current was already called by WP_WebMCP::run() before
		// the per-class registrations happened. Static facades can now
		// route through us.
		foreach ( $this->actions as $a ) {
			\add_action( $a[0], $a[1], $a[2], $a[3] );
		}
		foreach ( $this->filters as $f ) {
			\add_filter( $f[0], $f[1], $f[2], $f[3] );
		}
		foreach ( $this->shortcodes as $tag => $cb ) {
			\add_shortcode( $tag, $cb );
		}
	}
}
