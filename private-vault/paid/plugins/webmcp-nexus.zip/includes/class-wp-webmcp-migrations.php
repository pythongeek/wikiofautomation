<?php
/**
 * Migration framework — per Doc §4.6.
 *
 * Run on `plugins_loaded` priority 1 (before anything queries the 3 tables).
 * Every step must be idempotent. The version is bumped only when the schema
 * changes.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery -- migrations run once on plugin activation/update
final class WP_WebMCP_Migrations {

	/**
	 * Hook called at plugins_loaded priority 1 from WP_WebMCP::run().
	 *
	 * Compares `wpwebmcp_db_version` to WEBMCP_NEXUS_DB_VERSION; runs each step
	 * whose target version is newer than what's installed. Each step is
	 * individually idempotent (dbDelta is diff-safe).
	 */
	public static function maybe_upgrade(): void {
		if ( ! defined( 'WEBMCP_NEXUS_DB_VERSION' ) ) {
			return;
		}

		$installed = (int) get_option( 'wpwebmcp_db_version', 0 );
		global $wpdb;
		$tools_table  = $wpdb->prefix . 'wpwebmcp_tools';
		$table_exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $tools_table ) ) === $tools_table );

		if ( $installed >= (int) WEBMCP_NEXUS_DB_VERSION && $table_exists ) {
			return;
		}

		foreach ( self::steps() as $version => $callback ) {
			if ( $installed < (int) $version || ! $table_exists ) {
				$callback();
				// autoload=no per §4.6.
				update_option( 'wpwebmcp_db_version', (int) $version, false );
			}
		}
	}

	/**
	 * Ordered list of [target_version => callable]. dbDelta is diff-safe so
	 * running step 1 on a fresh install is the same as running it on a
	 * partially-installed site.
	 *
	 * @return array<int, callable>
	 */
	private static function steps(): array {
		return array(
			1 => array( 'WP_WebMCP_Activator', 'create_tables' ),
			2 => array( self::class,           'migrate_to_2' ),
			3 => array( self::class,           'migrate_to_3' ),
		);
	}

	/**
	 * Migration v2 (M0c): add the agent_slug column + index on
	 * wpwebmcp_log so per-agent analytics stay cheap.
	 *
	 * Idempotent — dbDelta diff-checks against existing schema and
	 * skips if the column already exists.
	 */
	public static function migrate_to_2(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset_collate = $wpdb->get_charset_collate();
		$log_sql = "CREATE TABLE {$wpdb->prefix}wpwebmcp_log (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			tool_name VARCHAR(100) NOT NULL,
			params TEXT NULL,
			status VARCHAR(20) NOT NULL,
			error_message TEXT NULL,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			ip_address VARCHAR(45) NULL,
			ip_hashed VARCHAR(64) NULL,
			execution_ms INT UNSIGNED NOT NULL DEFAULT 0,
			agent_slug VARCHAR(50) NULL DEFAULT NULL,
			logged_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY idx_logged_at (logged_at),
			KEY idx_tool_status (tool_name, status),
			KEY idx_user (user_id),
			KEY idx_agent_slug (agent_slug)
		) {$charset_collate};";
		dbDelta( $log_sql );
	}

	/**
	 * Migration v3 (M0d): create wpwebmcp_write_log for the write-tool
	 * audit + rollback UI. Every change to a wpwebmcp_* option is
	 * snapshotted with before/after JSON; the Audit Log UI shows the
	 * snapshot rows alongside tool-call rows and offers a one-click
	 * Rollback button that restores the prior option value.
	 *
	 * Idempotent — dbDelta is diff-safe.
	 */
	public static function migrate_to_3(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset_collate = $wpdb->get_charset_collate();
		$write_sql = "CREATE TABLE {$wpdb->prefix}wpwebmcp_write_log (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			event_type VARCHAR(40) NOT NULL,
			target_key VARCHAR(190) NOT NULL,
			target_id BIGINT UNSIGNED NULL DEFAULT NULL,
			actor VARCHAR(60) NOT NULL DEFAULT 'system',
			ip_hash VARCHAR(64) NULL DEFAULT NULL,
			before_json LONGTEXT NULL,
			after_json LONGTEXT NULL,
			diff_summary VARCHAR(255) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'applied',
			rollback_of BIGINT UNSIGNED NULL DEFAULT NULL,
			rolled_back_id BIGINT UNSIGNED NULL DEFAULT NULL,
			note TEXT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY idx_created_at (created_at),
			KEY idx_target_key (target_key),
			KEY idx_status (status),
			KEY idx_event_type (event_type)
		) {$charset_collate};";
		dbDelta( $write_sql );
	}
// phpcs:enable WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery
}
