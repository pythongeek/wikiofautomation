<?php
/**
 * WP_WebMCP — singleton. Owns dependency loading and ALL hook registration
 * via the Loader. Per-step classes register hooks by appending to the
 * matching define_*_hooks() method and instantiating themselves in
 * load_dependencies() in the order dictated by Doc §2.2.
 *
 * Bootstrap order: loader → data → utilities → schema → features
 *   → api → tools → integrations → cli → cross-cutting → admin.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_WebMCP {

	/**
	 * Singleton instance.
	 */
	private static ?WP_WebMCP $instance = null;

	/**
	 * The registered hook collector.
	 */
	public WP_WebMCP_Loader $loader;

	/**
	 * @var array<string, object> Lazily-instantiated collaborators.
	 */
	private array $components = array();

	/**
	 * @var array<string> Missing file paths if any failed during upload/extraction.
	 */
	private static array $missing_files = array();

	public function __construct() {
		$this->loader = new WP_WebMCP_Loader();
	}

	public static function instance(): WP_WebMCP {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Safely load a required PHP file with file_exists guard.
	 *
	 * @param string $rel_path Relative path from plugin root.
	 * @return bool True if file loaded, false if missing.
	 */
	private function load_file( string $rel_path ): bool {
		$full_path = WEBMCP_NEXUS_PATH . $rel_path;
		if ( file_exists( $full_path ) ) {
			require_once $full_path;
			return true;
		}
		self::$missing_files[] = $rel_path;
		return false;
	}

	/**
	 * Require every class file in the dependency order mandated by Doc §2.2.
	 */
	public function load_dependencies(): void {
		// --- Activator + Deactivator ---
		$this->load_file( 'includes/class-wp-webmcp-activator.php' );
		$this->load_file( 'includes/class-wp-webmcp-deactivator.php' );

		// --- Data (3 repositories — free build) ---
		// Pro-only repository kept in the paid SKU: write-audit (M0d).
		$this->load_file( 'includes/data/class-wp-webmcp-tool-repository.php' );
		$this->load_file( 'includes/data/class-wp-webmcp-log-repository.php' );
		$this->load_file( 'includes/data/class-wp-webmcp-bot-log-repository.php' );

		// --- Utilities ---
		// Pro-only utility kept in the paid SKU: content-credentials (A1b).
		$this->load_file( 'includes/utilities/class-wp-webmcp-logger.php' );
		$this->load_file( 'includes/utilities/class-wp-webmcp-rate-limiter.php' );
		$this->load_file( 'includes/utilities/class-wp-webmcp-validator.php' );
		$this->load_file( 'includes/utilities/class-wp-webmcp-sanitizer.php' );
		$this->load_file( 'includes/utilities/class-wp-webmcp-citation.php' );
		$this->load_file( 'includes/utilities/class-wp-webmcp-exposure-tier.php' );
		$this->load_file( 'includes/utilities/class-wp-webmcp-alerts.php' );
		$this->load_file( 'includes/utilities/class-wp-webmcp-conflict-detector.php' );
		$this->load_file( 'includes/utilities/class-wp-webmcp-cron.php' );
		$this->load_file( 'includes/utilities/class-wp-webmcp-health.php' );

		// --- Schema ---
		$this->load_file( 'includes/schema/class-wp-webmcp-schema-builder.php' );
		$this->load_file( 'includes/schema/class-wp-webmcp-schema-homepage.php' );
		$this->load_file( 'includes/schema/class-wp-webmcp-schema-single.php' );
		$this->load_file( 'includes/schema/class-wp-webmcp-schema-archive.php' );
		$this->load_file( 'includes/schema/class-wp-webmcp-schema-search.php' );
		$this->load_file( 'includes/schema/class-wp-webmcp-schema-404.php' );
		$this->load_file( 'includes/schema/class-wp-webmcp-schema-woo.php' );
		$this->load_file( 'includes/schema/class-wp-webmcp-schema-news.php' );
		$this->load_file( 'includes/schema/class-wp-webmcp-schema-tech.php' );
		$this->load_file( 'includes/schema/class-wp-webmcp-schema-blog.php' );
		$this->load_file( 'includes/schema/class-wp-webmcp-schema-video.php' );
		$this->load_file( 'includes/schema/class-wp-webmcp-schema-events.php' );

		// --- Features ---
		$this->load_file( 'includes/features/class-wp-webmcp-llmstxt.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-markdown.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-well-known.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-bot-analytics.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-crawler-manager.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-push-server.php' );
		// Pro-only features kept in the paid SKU: aggregator (M0b), agent-identity (M0c), write-audit (M0d).
		$this->load_file( 'includes/features/class-wp-webmcp-import-export.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-forms.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-presets.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-policy.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-policy-presets.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-freshness-pinger.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-citation-leaderboard.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-schema-scanner.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-schema-tool-suggester.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-question-bank.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-answer-gap-detector.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-post-audit.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-missing-tool-auditor.php' );
		$this->load_file( 'includes/features/class-wp-webmcp-agent-inspector.php' );

		// --- SDK (Vertical Tool Packs Marketplace — A6) ---
		$this->load_file( 'includes/sdk/class-wp-webmcp-pack-manifest.php' );
		$this->load_file( 'includes/sdk/class-wp-webmcp-pack-registry.php' );
		$this->load_file( 'includes/sdk/class-wp-webmcp-pack-filter-bridge.php' );
		$this->load_file( 'includes/sdk/class-wp-webmcp-pack-loader.php' );

		// --- Frontend & Shortcodes ---
		$this->load_file( 'includes/frontend/class-wp-webmcp-shortcodes.php' );

		// --- API ---
		$this->load_file( 'includes/api/class-wp-webmcp-rest-fallback.php' );
		$this->load_file( 'includes/api/class-wp-webmcp-rest-manifest.php' );
		$this->load_file( 'includes/api/class-wp-webmcp-rest-tools.php' );
		$this->load_file( 'includes/api/class-wp-webmcp-rest-log.php' );
		// Pro-only REST routes kept in the paid SKU: write-log (M0d), exposure-tier (A2b full).
		$this->load_file( 'includes/api/class-wp-webmcp-rest-policies.php' );
		$this->load_file( 'includes/api/class-wp-webmcp-rest-policy-presets.php' );
		$this->load_file( 'includes/api/class-wp-webmcp-rest-freshness.php' );
		$this->load_file( 'includes/api/class-wp-webmcp-rest-citation-leaderboard.php' );
		$this->load_file( 'includes/api/class-wp-webmcp-rest-a3-schema.php' );
		$this->load_file( 'includes/api/class-wp-webmcp-rest-a3-gaps.php' );
		$this->load_file( 'includes/api/class-wp-webmcp-rest-a4-audit.php' );
		$this->load_file( 'includes/api/class-wp-webmcp-rest-a5-trace.php' );
		$this->load_file( 'includes/api/class-wp-webmcp-rest-a6-packs.php' );
		$this->load_file( 'includes/api/class-wp-webmcp-tool-executor.php' );

		// --- Tools ---
		$this->load_file( 'includes/tools/class-wp-webmcp-settings.php' );
		$this->load_file( 'includes/tools/class-wp-webmcp-meta-box.php' );
		$this->load_file( 'includes/tools/class-wp-webmcp-audit-meta-box.php' );
		$this->load_file( 'includes/tools/class-wp-webmcp-exclusions.php' );
		$this->load_file( 'includes/tools/class-wp-webmcp-access-control.php' );
		$this->load_file( 'includes/tools/class-wp-webmcp-tool-builder.php' );

		// --- Integrations ---
		$this->load_file( 'includes/integrations/class-wp-webmcp-woocommerce.php' );
		$this->load_file( 'includes/integrations/class-wp-webmcp-acf.php' );
		$this->load_file( 'includes/integrations/class-wp-webmcp-multisite.php' );
		$this->load_file( 'includes/integrations/class-wp-webmcp-privacy.php' );

		// --- CLI ---
		$this->load_file( 'includes/cli/class-wp-webmcp-cli.php' );

		// --- Cross-cutting ---
		$this->load_file( 'includes/class-wp-webmcp-migrations.php' );
		$this->load_file( 'includes/class-wp-webmcp-i18n.php' );
		$this->load_file( 'includes/class-wp-webmcp-design.php' );
		$this->load_file( 'includes/class-wp-webmcp-frontend.php' );

		// --- Admin ---
		$this->load_file( 'admin/class-wp-webmcp-admin.php' );
		$this->load_file( 'admin/class-wp-webmcp-agents-page.php' );
		$this->load_file( 'admin/class-wp-webmcp-policies-page.php' );
		$this->load_file( 'admin/class-wp-webmcp-freshness-page.php' );
		$this->load_file( 'admin/class-wp-webmcp-citation-leaderboard-page.php' );
		$this->load_file( 'admin/class-wp-webmcp-packs-page.php' );
	}

	/**
	 * Public/site hooks.
	 */
	public function define_public_hooks(): void {
		if ( class_exists( 'WP_WebMCP_I18n' ) ) $this->loader->add_action( 'init', array( 'WP_WebMCP_I18n', 'load' ), 1, 0 );
		if ( class_exists( 'WP_WebMCP_Frontend' ) ) $this->loader->add_action( 'init', array( 'WP_WebMCP_Frontend', 'init' ), 10, 0 );
		if ( class_exists( 'WP_WebMCP_LlmsTxt' ) ) $this->loader->add_action( 'init', array( 'WP_WebMCP_LlmsTxt', 'init' ), 10, 0 );
		if ( class_exists( 'WP_WebMCP_Markdown' ) ) $this->loader->add_action( 'init', array( 'WP_WebMCP_Markdown', 'init' ), 10, 0 );
		if ( class_exists( 'WP_WebMCP_Well_Known' ) ) $this->loader->add_action( 'init', array( 'WP_WebMCP_Well_Known', 'init' ), 10, 0 );
		if ( class_exists( 'WP_WebMCP_Bot_Analytics' ) ) $this->loader->add_action( 'init', array( 'WP_WebMCP_Bot_Analytics', 'init' ), 5, 0 );
		if ( class_exists( 'WP_WebMCP_Crawler_Manager' ) ) $this->loader->add_action( 'init', array( 'WP_WebMCP_Crawler_Manager', 'init' ), 10, 0 );
		if ( class_exists( 'WP_WebMCP_Alerts' ) ) $this->loader->add_action( 'init', array( 'WP_WebMCP_Alerts', 'init' ), 10, 0 );
		if ( class_exists( 'WP_WebMCP_Health' ) ) $this->loader->add_action( 'init', array( 'WP_WebMCP_Health', 'init' ), 10, 0 );
		if ( class_exists( 'WP_WebMCP_ACF' ) ) $this->loader->add_action( 'init', array( 'WP_WebMCP_ACF', 'init' ), 10, 0 );
		if ( class_exists( 'WP_WebMCP_Multisite' ) ) $this->loader->add_action( 'init', array( 'WP_WebMCP_Multisite', 'init' ), 10, 0 );
		if ( class_exists( 'WP_WebMCP_Forms' ) ) $this->loader->add_action( 'init', array( 'WP_WebMCP_Forms', 'init' ), 10, 0 );
		if ( class_exists( 'WP_WebMCP_Shortcodes' ) ) $this->loader->add_action( 'init', array( 'WP_WebMCP_Shortcodes', 'init' ), 10, 0 );
		// A1b: content credentials chain — public hook (save_post fires on
		// every post write, not just admin).
		if ( class_exists( 'WP_WebMCP_Content_Credentials' ) ) {
			$this->loader->add_action( 'init', array( 'WP_WebMCP_Content_Credentials', 'init' ), 10, 0 );
		}
	}

	/**
	 * Admin UI hooks.
	 */
	public function define_admin_hooks(): void {
		if ( class_exists( 'WP_WebMCP_Admin' ) ) {
			$this->loader->add_action( 'admin_menu',             array( 'WP_WebMCP_Admin',  'register_menus' ),       10, 0 );
			$this->loader->add_action( 'admin_enqueue_scripts', array( 'WP_WebMCP_Admin',  'enqueue_admin_scripts' ), 10, 1 );
			$this->loader->add_action( 'wp_ajax_wpwebmcp_dismiss_onboarding', array( 'WP_WebMCP_Admin', 'dismiss_onboarding' ) );
			$this->loader->add_action( 'wp_ajax_wpwebmcp_apply_preset',       array( 'WP_WebMCP_Admin', 'ajax_apply_preset' ) );
		}
		if ( class_exists( 'WP_WebMCP_Write_Audit' ) ) {
			$this->loader->add_action( 'init', array( 'WP_WebMCP_Write_Audit', 'init' ), 10, 0 );
			$this->loader->add_action( 'wp_ajax_wpwebmcp_rollback', array( 'WP_WebMCP_Write_Audit', 'ajax_rollback' ) );
		}
		if ( class_exists( 'WP_WebMCP_Design' ) ) {
			$this->loader->add_action( 'admin_head',             array( 'WP_WebMCP_Design', 'emit_tokens' ),           10, 0 );
		}
		if ( class_exists( 'WP_WebMCP_Meta_Box' ) ) {
			$this->loader->add_action( 'init',                  array( 'WP_WebMCP_Meta_Box', 'init' ),                  10, 0 );
		}
		if ( class_exists( 'WP_WebMCP_Audit_Meta_Box' ) ) {
			$this->loader->add_action( 'init', array( 'WP_WebMCP_Audit_Meta_Box', 'init' ), 10, 0 );
		}
		// A6: Packs admin page — admin-post handlers + notices.
		if ( class_exists( 'WP_WebMCP_Packs_Page' ) ) {
			$this->loader->add_action( 'admin_init', array( 'WP_WebMCP_Packs_Page', 'register' ), 10, 0 );
		}
	}

	/**
	 * REST API hooks & Tools controllers.
	 */
	public function define_api_hooks(): void {
		if ( class_exists( 'WP_WebMCP_REST_Fallback' ) ) {
			$this->loader->add_action( 'init', array( 'WP_WebMCP_REST_Fallback', 'init' ), 1, 0 );
			$this->loader->add_action( 'template_redirect', array( 'WP_WebMCP_REST_Fallback', 'maybe_intercept_rest' ), 1, 0 );
		}
		if ( class_exists( 'WP_WebMCP_Tools' ) ) {
			WP_WebMCP_Tools::init();
			$this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_Tools', 'register_routes' ), 10, 0 );
		}
		if ( class_exists( 'WP_WebMCP_Settings' ) ) {
			$this->loader->add_action( 'init', array( 'WP_WebMCP_Settings', 'init' ), 10, 0 );
			$this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_Settings', 'register_routes' ), 10, 0 );
		}
		if ( class_exists( 'WP_WebMCP_Exclusions' ) ) {
			$this->loader->add_action( 'init', array( 'WP_WebMCP_Exclusions', 'init' ), 10, 0 );
			$this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_Exclusions', 'register_routes' ), 10, 0 );
		}
		if ( class_exists( 'WP_WebMCP_REST_Manifest' ) ) $this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_REST_Manifest', 'register_routes' ), 10, 0 );
		if ( class_exists( 'WP_WebMCP_Access_Control' ) ) {
			$this->loader->add_action( 'init', array( 'WP_WebMCP_Access_Control', 'init' ), 10, 0 );
			$this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_Access_Control', 'register_routes' ), 10, 0 );
		}
		if ( class_exists( 'WP_WebMCP_Privacy' ) )        $this->loader->add_action( 'init', array( 'WP_WebMCP_Privacy',        'init' ), 10, 0 );
		if ( class_exists( 'WP_WebMCP_Log' ) ) $this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_Log', 'register_routes' ), 10, 0 );
		if ( class_exists( 'WP_WebMCP_Write_Log' ) ) $this->loader->add_action( 'init', array( 'WP_WebMCP_Write_Log', 'init' ), 10, 0 );
		// A2b: exposure-tier REST routes (generate-proof / generate-receipt / get-tier, admin-only).
		if ( class_exists( 'WP_WebMCP_REST_Exposure' ) ) $this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_REST_Exposure', 'register_routes' ), 10, 0 );
		// A2a: policy REST routes (list / save / delete / evaluate, admin-only).
		if ( class_exists( 'WP_WebMCP_REST_Policies' ) ) $this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_REST_Policies', 'register_routes' ), 10, 0 );
		// A2c: policy preset REST routes (list / get / apply / remove, admin-only).
		if ( class_exists( 'WP_WebMCP_REST_Policy_Presets' ) ) $this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_REST_Policy_Presets', 'register_routes' ), 10, 0 );
		// A3c: schema-to-tool sync REST routes (scan / apply, admin-only).
		if ( class_exists( 'WP_WebMCP_REST_A3_Schema' ) ) $this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_REST_A3_Schema', 'register_routes' ), 10, 0 );
		// A3a: answer-gap detector REST routes (scan / apply, admin-only).
		if ( class_exists( 'WP_WebMCP_REST_A3_Gaps' ) ) $this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_REST_A3_Gaps', 'register_routes' ), 10, 0 );
		// A4: AI-readiness audit REST routes (audit-post / leaderboard / missing-tools, admin-only).
		if ( class_exists( 'WP_WebMCP_REST_A4_Audit' ) ) $this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_REST_A4_Audit', 'register_routes' ), 10, 0 );
		// A5: agent live trace REST routes (recent-calls / recent-bots / resolve-agent / preview-policy / rerun-call, admin-only).
		if ( class_exists( 'WP_WebMCP_REST_A5_Trace' ) ) $this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_REST_A5_Trace', 'register_routes' ), 10, 0 );
		// A6: Vertical Tool Packs Marketplace REST routes (list / install / uninstall / list-tools, admin-only).
		if ( class_exists( 'WP_WebMCP_REST_A6_Packs' ) ) $this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_REST_A6_Packs', 'register' ), 10, 0 );
		// A6: SDK pack loader — discovers + bootstraps installed packs on every request.
		if ( class_exists( 'WP_WebMCP_Pack_Loader' ) ) { WP_WebMCP_Pack_Loader::init(); } // F3 wiring fix: direct call — the previous queued plugins_loaded action raced the hook it was registered on
		// A1c: freshness ping REST routes (status / stream public, settings/log/flush/enqueue admin-only).
		if ( class_exists( 'WP_WebMCP_REST_Freshness' ) ) $this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_REST_Freshness', 'register_routes' ), 10, 0 );
		// A1d: citation leaderboard REST route (public read-only).
		if ( class_exists( 'WP_WebMCP_REST_Citation_Leaderboard' ) ) $this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_REST_Citation_Leaderboard', 'register_routes' ), 10, 0 );
		if ( class_exists( 'WP_WebMCP_Tool_Builder' ) ) {
			$this->loader->add_action( 'init', array( 'WP_WebMCP_Tool_Builder', 'init' ), 10, 0 );
			$this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_Tool_Builder', 'register_routes' ), 10, 0 );
		}
		if ( class_exists( 'WP_WebMCP_Import_Export' ) ) {
			$this->loader->add_action( 'init', array( 'WP_WebMCP_Import_Export', 'init' ), 10, 0 );
			$this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_Import_Export', 'register_routes' ), 10, 0 );
		}
		if ( class_exists( 'WP_WebMCP_Push_Server' ) ) {
			$this->loader->add_action( 'init', array( 'WP_WebMCP_Push_Server', 'init' ), 10, 0 );
			$this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_Push_Server', 'register_routes' ), 10, 0 );
		}
		if ( class_exists( 'WP_WebMCP_Bot_Analytics' ) ) {
			$this->loader->add_action( 'rest_api_init', array( 'WP_WebMCP_Bot_Analytics', 'register_routes' ), 10, 0 );
		}
		if ( class_exists( 'WP_WebMCP_Aggregator' ) ) $this->loader->add_action( 'init', array( 'WP_WebMCP_Aggregator', 'init' ), 10, 0 );
		// A1c: freshness pinger — content hooks + cron schedule + REST hooks.
		if ( class_exists( 'WP_WebMCP_Freshness_Pinger' ) ) {
			$this->loader->add_action( 'init', array( 'WP_WebMCP_Freshness_Pinger', 'init' ), 10, 0 );
			$this->loader->add_filter( 'cron_schedules', array( 'WP_WebMCP_Freshness_Pinger', 'register_schedule' ) );
		}
	}

	/**
	 * WP-Cron hooks.
	 */
	public function define_cron_hooks(): void {
		if ( class_exists( 'WP_WebMCP_Cron' ) ) {
			$this->loader->add_action( 'wpwebmcp_log_purge',            array( 'WP_WebMCP_Cron', 'purge_log' ) );
			$this->loader->add_action( 'wpwebmcp_bot_analytics_rollup', array( 'WP_WebMCP_Cron', 'rollup_bot_analytics' ) );
			$this->loader->add_action( 'wpwebmcp_schema_validation',    array( 'WP_WebMCP_Cron', 'run_schema_validation' ) );
		}
	}

	/**
	 * WP-CLI command registrations.
	 */
	public function define_cli_commands(): void {
		if ( defined( 'WP_CLI' ) && WP_CLI && class_exists( 'WP_WebMCP_CLI' ) ) {
			WP_WebMCP_CLI::register();
		}
	}

	/**
	 * Wires public + admin + api + cron hook registrations to the loader,
	 * then runs the loader. Called on plugins_loaded from wp-webmcp.php.
	 */
	public function run(): void {
		// Mark this loader as the active one so per-class init() methods
		// that fire later (via WP's `init` action) can register their hooks
		// through the static Loader::register_action / register_filter
		// facades. See class-wp-webmcp-loader.php for the contract.
		if ( class_exists( 'WP_WebMCP_Loader' ) ) {
			WP_WebMCP_Loader::set_current( $this->loader );
		}

		$this->load_dependencies();

		if ( ! empty( self::$missing_files ) ) {
			add_action(
				'admin_notices',
				static function () {
					echo '<div class="notice notice-error"><p>';
					echo sprintf(
						'<strong>WebMCP Nexus Warning:</strong> The plugin upload appears to be incomplete. Missing file(s): <code>%s</code>. Please re-upload the complete plugin zip.',
						esc_html( implode( ', ', array_slice( self::$missing_files, 0, 5 ) ) )
					);
					echo '</p></div>';
				}
			);
		}

		// Migrations & options must run BEFORE any other code queries the tables/options.
		if ( class_exists( 'WP_WebMCP_Migrations' ) ) {
			WP_WebMCP_Migrations::maybe_upgrade();
		}
		if ( class_exists( 'WP_WebMCP_Activator' ) ) {
			WP_WebMCP_Activator::seed_options();
		}

		$this->define_public_hooks();
		$this->define_admin_hooks();
		$this->define_api_hooks();
		$this->define_cron_hooks();
		$this->define_cli_commands();
		$this->loader->run();
	}
}
