<?php
/**
 * WP-CLI Commands for WebMCP Nexus — Doc Part 12.
 *
 * Implements `wp webmcp` subcommands:
 *   - status
 *   - enable / disable
 *   - exclude / include
 *   - validate
 *   - manifest
 *   - log
 *   - export
 *   - cache-purge
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) {
	return;
}

/**
 * Manage WebMCP Nexus configuration, tools, and telemetry from the command line.
 */
class WP_WebMCP_CLI {

	/**
	 * Register commands with WP-CLI.
	 */
	public static function register(): void {
		WP_CLI::add_command( 'webmcp', __CLASS__ );
	}

	/**
	 * Show current WebMCP Nexus status, counts, and readiness score.
	 *
	 * ## EXAMPLES
	 *
	 *     wp webmcp status
	 *
	 * @subcommand status
	 */
	public function status( $args, $assoc_args ): void {
		$enabled = (bool) get_option( 'wpwebmcp_enabled', true );
		$score   = class_exists( 'WP_WebMCP_Validator' )
			? WP_WebMCP_Validator::calculate_health_score()
			: 100;
		$tools   = class_exists( 'WP_WebMCP_Tool_Repository' )
			? (int) WP_WebMCP_Tool_Repository::count( 'active' )
			: 0;
		$calls   = class_exists( 'WP_WebMCP_Log_Repository' )
			? (int) WP_WebMCP_Log_Repository::count_today()
			: 0;

		WP_CLI::line( WP_CLI::colorize( '%G=== WebMCP Nexus Status ===%n' ) );
		WP_CLI::line( sprintf( 'Status:          %s', $enabled ? WP_CLI::colorize( '%gEnabled%n' ) : WP_CLI::colorize( '%rDisabled%n' ) ) );
		WP_CLI::line( sprintf( 'Readiness Score: %d/100', $score ) );
		WP_CLI::line( sprintf( 'Active Tools:    %d', $tools ) );
		WP_CLI::line( sprintf( 'Calls Today:     %d', $calls ) );
		WP_CLI::line( sprintf( 'Version:         %s', defined( 'WEBMCP_NEXUS_VERSION' ) ? WEBMCP_NEXUS_VERSION : '1.0.0' ) );
	}

	/**
	 * Enable WebMCP Nexus sitewide.
	 *
	 * ## EXAMPLES
	 *
	 *     wp webmcp enable
	 *
	 * @subcommand enable
	 */
	public function enable( $args, $assoc_args ): void {
		update_option( 'wpwebmcp_enabled', true );
		WP_CLI::success( 'WebMCP Nexus has been enabled sitewide.' );
	}

	/**
	 * Disable WebMCP Nexus sitewide.
	 *
	 * ## EXAMPLES
	 *
	 *     wp webmcp disable
	 *
	 * @subcommand disable
	 */
	public function disable( $args, $assoc_args ): void {
		update_option( 'wpwebmcp_enabled', false );
		WP_CLI::success( 'WebMCP Nexus has been disabled sitewide.' );
	}

	/**
	 * Exclude a post or page by ID from agent tool exposure.
	 *
	 * ## OPTIONS
	 *
	 * <post_id>
	 * : The ID of the post or page to exclude.
	 *
	 * ## EXAMPLES
	 *
	 *     wp webmcp exclude 42
	 *
	 * @subcommand exclude
	 */
	public function exclude( $args, $assoc_args ): void {
		$post_id = isset( $args[0] ) ? absint( $args[0] ) : 0;
		if ( $post_id <= 0 ) {
			WP_CLI::error( 'Please provide a valid numeric post ID.' );
		}

		$excluded = (array) get_option( 'wpwebmcp_excluded_ids', array() );
		if ( in_array( $post_id, $excluded, true ) ) {
			WP_CLI::warning( sprintf( 'Post %d is already excluded.', $post_id ) );
			return;
		}

		$excluded[] = $post_id;
		update_option( 'wpwebmcp_excluded_ids', array_values( array_unique( $excluded ) ) );
		WP_CLI::success( sprintf( 'Post %d added to exclusions.', $post_id ) );
	}

	/**
	 * Remove a post or page from the exclusions list.
	 *
	 * ## OPTIONS
	 *
	 * <post_id>
	 * : The ID of the post or page to include.
	 *
	 * ## EXAMPLES
	 *
	 *     wp webmcp include 42
	 *
	 * @subcommand include
	 */
	public function wp_include( $args, $assoc_args ): void {
		$post_id = isset( $args[0] ) ? absint( $args[0] ) : 0;
		if ( $post_id <= 0 ) {
			WP_CLI::error( 'Please provide a valid numeric post ID.' );
		}

		$excluded = (array) get_option( 'wpwebmcp_excluded_ids', array() );
		$clean    = array_values( array_diff( $excluded, array( $post_id ) ) );

		update_option( 'wpwebmcp_excluded_ids', $clean );
		WP_CLI::success( sprintf( 'Post %d removed from exclusions.', $post_id ) );
	}

	/**
	 * Run agent readiness validation rules and print the calculated score.
	 *
	 * ## EXAMPLES
	 *
	 *     wp webmcp validate
	 *
	 * @subcommand validate
	 */
	public function validate( $args, $assoc_args ): void {
		if ( ! class_exists( 'WP_WebMCP_Validator' ) ) {
			WP_CLI::error( 'Validator class not available.' );
		}

		$score = WP_WebMCP_Validator::calculate_health_score();
		if ( $score >= 80 ) {
			WP_CLI::success( sprintf( 'Validation complete. Agent Readiness Score: %d/100 (Optimal)', $score ) );
		} else {
			WP_CLI::warning( sprintf( 'Validation complete. Agent Readiness Score: %d/100 (Review Dashboard for issues)', $score ) );
		}
	}

	/**
	 * Output the rendered WebMCP JSON manifest for a given context.
	 *
	 * ## OPTIONS
	 *
	 * [--post_id=<id>]
	 * : Target post ID.
	 *
	 * [--role=<role>]
	 * : Caller role (e.g. anonymous, administrator).
	 *
	 * ## EXAMPLES
	 *
	 *     wp webmcp manifest --role=anonymous
	 *
	 * @subcommand manifest
	 */
	public function manifest( $args, $assoc_args ): void {
		$post_id = isset( $assoc_args['post_id'] ) ? absint( $assoc_args['post_id'] ) : 0;
		$role    = isset( $assoc_args['role'] ) ? sanitize_key( $assoc_args['role'] ) : 'anonymous';

		$context = $post_id > 0 ? 'single' : 'homepage';
		$data    = WP_WebMCP_Schema_Builder::build( $context, $post_id, $role );

		WP_CLI::line( wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) );
	}

	/**
	 * View recent tool execution logs.
	 *
	 * ## OPTIONS
	 *
	 * [--limit=<n>]
	 * : Number of log entries to display. Default 20.
	 *
	 * [--format=<table|json|csv>]
	 * : Output format. Default table.
	 *
	 * ## EXAMPLES
	 *
	 *     wp webmcp log --limit=10
	 *
	 * @subcommand log
	 */
	public function log( $args, $assoc_args ): void {
		$limit  = isset( $assoc_args['limit'] ) ? absint( $assoc_args['limit'] ) : 20;
		$format = isset( $assoc_args['format'] ) ? sanitize_key( $assoc_args['format'] ) : 'table';

		$rows = class_exists( 'WP_WebMCP_Log_Repository' )
			? WP_WebMCP_Log_Repository::find( array( 'per_page' => $limit ) )
			: array();

		if ( empty( $rows ) ) {
			WP_CLI::line( 'No log entries found.' );
			return;
		}

		$display = array();
		foreach ( $rows as $r ) {
			$display[] = array(
				'id'        => $r['id'] ?? 0,
				'tool'      => $r['tool_name'] ?? '',
				'status'    => $r['status'] ?? '',
				'ms'        => $r['execution_ms'] ?? 0,
				'created_at' => $r['created_at'] ?? '',
			);
		}

		WP_CLI\Utils\format_items( $format, $display, array( 'id', 'tool', 'status', 'ms', 'created_at' ) );
	}

	/**
	 * Export all WebMCP settings and custom tools to JSON.
	 *
	 * ## OPTIONS
	 *
	 * [--file=<path>]
	 * : Destination file path. If omitted, outputs to stdout.
	 *
	 * ## EXAMPLES
	 *
	 *     wp webmcp export --file=webmcp-backup.json
	 *
	 * @subcommand export
	 */
	public function export( $args, $assoc_args ): void {
		if ( ! class_exists( 'WP_WebMCP_Import_Export' ) ) {
			WP_CLI::error( 'Import/Export handler not available.' );
		}

		$payload = WP_WebMCP_Import_Export::build_export_payload();
		$json    = wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );

		if ( ! empty( $assoc_args['file'] ) ) {
			$file = sanitize_text_field( $assoc_args['file'] );
			file_put_contents( $file, $json );
			WP_CLI::success( sprintf( 'Export written to %s', $file ) );
		} else {
			WP_CLI::line( $json );
		}
	}

	/**
	 * Flush all WebMCP cached transient data and scores.
	 *
	 * ## EXAMPLES
	 *
	 *     wp webmcp cache-purge
	 *
	 * @subcommand cache-purge
	 */
	public function cache_purge( $args, $assoc_args ): void {
		delete_transient( 'wpwebmcp_health_score' );
		delete_transient( 'wpwebmcp_bot_stats_30d' );
		wp_cache_flush();
		WP_CLI::success( 'WebMCP transients and object caches purged.' );
	}

	/**
	 * F3 Phase 4: generate a niche/industry pack from the bundled catalogue.
	 *
	 * ## OPTIONS
	 *
	 * <slug>
	 * : Catalogue slug: restaurants | fitness-classes | travel-tours
	 *
	 * ## EXAMPLES
	 *
	 *     wp webmcp pack-generate restaurants
	 *
	 * @subcommand pack-generate
	 */
	public function pack_generate( $args, $assoc_args ): void {
		if ( empty( $args[0] ) ) {
			WP_CLI::error( 'Usage: wp webmcp pack-generate <slug> (restaurants | fitness-classes | travel-tours)' );
		}
		if ( ! class_exists( 'WP_WebMCP_Pack_Registry' ) ) {
			WP_CLI::error( 'Pack registry not loaded.' );
		}
		$result = WP_WebMCP_Pack_Registry::write_pack_files( (string) $args[0] );
		if ( empty( $result['ok'] ) ) {
			WP_CLI::error( (string) ( $result['error'] ?? 'Pack generation failed.' ) );
		}
		WP_CLI::success( sprintf( 'Pack "%s" generated into wp-content/wp-webmcp-packs/. Install it from WebMCP > Tool Packs.', (string) $args[0] ) );
	}
}
