<?php
/**
 * Bot log repository — all SQL for the `wpwebmcp_bot_log` table.
 *
 * Per Doc §4.5. The upsert is the DB-1 fix: `post_id` is always passed as
 * an unsigned int (absint) and defaults to 0 for non-post URLs, so the
 * UNIQUE KEY uq_bot_post (bot_name, post_id) never sees NULL and
 * `INSERT … ON DUPLICATE KEY UPDATE` actually increments.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery,PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- `$table` is a hardcoded `$wpdb->prefix . "wpwebmcp_bot_log"` literal; bot visits are real-time and must not be cached
final class WP_WebMCP_Bot_Log_Repository {

	/**
	 * Upsert a bot hit (DB-1 safe).
	 *
	 * @param string $bot       Bot label (≤100 chars).
	 * @param string $category  Bot category (training / search / user-agent / …).
	 * @param int    $post_id   Post id or 0 for non-post URLs. absint()'d here.
	 * @param string $ip_hash   sha256-hashed IP (≤64 chars).
	 */
	public static function upsert_hit( string $bot, string $category, int $post_id, string $ip_hash ): void {
		global $wpdb;
		$table = self::table();

		$bot      = self::normalize_bot( $bot );
		$category = self::normalize_category( $category );
		$post_id  = absint( $post_id );            // DB-1: never NULL.
		$ip_hash  = self::normalize_hash( $ip_hash );
		$now_gmt  = current_time( 'mysql', true );

		// Ensure table exists
		static $checked_table = false;
		if ( ! $checked_table ) {
			$checked_table = true;
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
				if ( class_exists( 'WP_WebMCP_Activator' ) ) {
					WP_WebMCP_Activator::create_tables();
				}
			}
		}

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery -- upsert requires direct SQL.
		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$wpdb->prefix}wpwebmcp_bot_log (bot_name, bot_category, post_id, ip_hash, hits, logged_at)
				 VALUES (%s, %s, %d, %s, 1, %s)
				 ON DUPLICATE KEY UPDATE
				   hits = hits + 1,
				   bot_category = VALUES(bot_category),
				   ip_hash = VALUES(ip_hash),
				   logged_at = VALUES(logged_at)",
				$bot,
				$category,
				$post_id,
				$ip_hash,
				$now_gmt
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery

		delete_transient( 'wpwebmcp_bot_stats_30d' );
	}

	/**
	 * Find bot visits. $args keys: per_page, offset, bot_name, post_id, days.
	 */
	public static function find( array $args ): array {
		global $wpdb;

		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['bot_name'] ) ) {
			$where[]  = 'bot_name = %s';
			$params[] = self::normalize_bot( (string) $args['bot_name'] );
		}
		if ( isset( $args['post_id'] ) ) {
			$where[]  = 'post_id = %d';
			$params[] = absint( $args['post_id'] );
		}
		if ( ! empty( $args['days'] ) ) {
			$where[]  = 'logged_at >= %s';
			$days     = max( 1, (int) $args['days'] );
			$params[] = gmdate( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) );
		}

		$per_page = isset( $args['per_page'] ) ? max( 1, (int) $args['per_page'] ) : 50;
		$offset   = isset( $args['offset'] ) ? max( 0, (int) $args['offset'] ) : 0;

		$where_sql = implode( ' AND ', $where );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $where_sql constructed with placeholders and sanitized values.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}wpwebmcp_bot_log WHERE {$where_sql} ORDER BY hits DESC, logged_at DESC LIMIT %d OFFSET %d",
				array_merge( $params, array( $per_page, $offset ) )
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

		return (array) $rows;
	}

	/**
	 * Aggregate hits per bot over the last N days.
	 *
	 * @return array<int, array{bot_name:string, hits:int}>
	 */
	public static function stats_by_bot( int $days ): array {
		global $wpdb;
		$table = self::table();
		$days  = max( 1, $days );
		$since = gmdate( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT bot_name, SUM(hits) AS hits FROM {$wpdb->prefix}wpwebmcp_bot_log WHERE logged_at >= %s GROUP BY bot_name ORDER BY hits DESC",
				$since
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery

		return (array) $rows;
	}

	/**
	 * Per-day hits over the last N days.
	 *
	 * @return array<int, array{day:string, hits:int}>
	 */
	public static function stats_by_day( int $days ): array {
		global $wpdb;
		$days  = max( 1, $days );
		$since = gmdate( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DATE(logged_at) AS day, SUM(hits) AS hits FROM {$wpdb->prefix}wpwebmcp_bot_log WHERE logged_at >= %s GROUP BY DATE(logged_at) ORDER BY day ASC",
				$since
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery

		return (array) $rows;
	}

	/**
	 * Top pages visited by bots over the last N days (excludes post_id=0 = "non-post").
	 *
	 * @return array<int, array{post_id:int, hits:int}>
	 */
	public static function top_pages( int $days, int $limit = 10 ): array {
		global $wpdb;
		$days  = max( 1, $days );
		$since = gmdate( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) );
		$limit = max( 1, $limit );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_id, SUM(hits) AS hits FROM {$wpdb->prefix}wpwebmcp_bot_log WHERE post_id > 0 AND logged_at >= %s GROUP BY post_id ORDER BY hits DESC LIMIT %d",
				$since,
				$limit
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery

		return (array) $rows;
	}

	/**
	 * Delete rows last-seen before the given datetime.
	 *
	 * @return int Number of rows deleted.
	 */
	public static function purge_before( string $datetime ): int {
		global $wpdb;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
		$count = (int) $wpdb->query(
			$wpdb->prepare( "DELETE FROM {$wpdb->prefix}wpwebmcp_bot_log WHERE logged_at < %s", $datetime )
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery

		return $count;
	}

	/* ---------- internals ---------- */

	private static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'wpwebmcp_bot_log';
	}

	private static function normalize_bot( string $bot ): string {
		$bot = trim( $bot );
		$bot = preg_replace( '/[^A-Za-z0-9 _\-]/', '', $bot ) ?? '';
		return substr( $bot, 0, 100 );
	}

	private static function normalize_category( string $category ): string {
		$category = trim( $category );
		$category = preg_replace( '/[^A-Za-z0-9 _\-]/', '', $category ) ?? '';
		return substr( $category, 0, 50 );
	}

	private static function normalize_hash( string $hash ): string {
		return substr( preg_replace( '/[^A-Fa-f0-9]/', '', $hash ) ?? '', 0, 64 );
	}
// phpcs:enable WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery,PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}
