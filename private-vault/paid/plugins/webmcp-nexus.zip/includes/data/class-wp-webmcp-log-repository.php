<?php
/**
 * Log repository — all SQL for the `wpwebmcp_log` table (tool-call audit log).
 *
 * Per Doc §4.5 + §9.2 (param redaction at the writer side, not here) +
 * §9.6 (anonymize_user is the privacy eraser).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- `$table` is hardcoded `$wpdb->prefix . "wpwebmcp_log"` literal; tool-call audit log is real-time
final class WP_WebMCP_Log_Repository {

	/**
	 * Insert a single audit row.
	 *
	 * Expected keys: tool_name, params (JSON-string or array), status,
	 *                error_message, user_id, ip_address, ip_hashed,
	 *                execution_ms.
	 * Returns inserted id; 0 on failure.
	 */
	public static function insert( array $row ): int {
		global $wpdb;
		$table = self::table();

		$tool_name = self::normalize_name( (string) ( $row['tool_name'] ?? '' ) );
		if ( '' === $tool_name ) {
			return 0;
		}

		$params = $row['params'] ?? null;
		if ( is_array( $params ) ) {
			$params = wp_json_encode( $params );
		}

		$payload = array(
			'tool_name'    => $tool_name,
			'params'       => null === $params ? null : (string) $params,
			'status'       => self::normalize_status( (string) ( $row['status'] ?? 'error' ) ),
			'error_message' => isset( $row['error_message'] ) ? (string) $row['error_message'] : null,
			'user_id'      => isset( $row['user_id'] ) ? absint( $row['user_id'] ) : 0,
			'ip_address'   => isset( $row['ip_address'] ) ? (string) $row['ip_address'] : null,
			'ip_hashed'    => isset( $row['ip_hashed'] ) ? (string) $row['ip_hashed'] : null,
			'execution_ms' => isset( $row['execution_ms'] ) ? (int) $row['execution_ms'] : 0,
			'agent_slug'   => isset( $row['agent_slug'] ) && '' !== (string) $row['agent_slug']
				? self::normalize_slug( (string) $row['agent_slug'] )
				: null,
		);

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery -- repository layer.
		$ok = $wpdb->insert(
			$table,
			$payload,
			array( '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%s' )
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery

		return $ok ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * Find audit rows with filters.
	 *
	 * $args keys:
	 *   per_page, offset, tool_name, status, date_from, date_to, orderby, order.
	 */
	public static function find( array $args ): array {
		global $wpdb;
		$table = self::table();

		$where  = array( '1=1' );
		$params = array();
		// F8: internal cron maintenance rows are hidden from default reads.
		// Pass 'include_internal' => true to include them (debug views).
		if ( empty( $args['include_internal'] ) ) {
			$where[] = "tool_name NOT LIKE 'cron%'";
		}

		if ( ! empty( $args['tool_name'] ) ) {
			$where[]  = 'tool_name = %s';
			$params[] = self::normalize_name( (string) $args['tool_name'] );
		}
		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$params[] = self::normalize_status( (string) $args['status'] );
		}
		if ( ! empty( $args['date_from'] ) ) {
			$where[]  = 'logged_at >= %s';
			$params[] = (string) $args['date_from'];
		}
		if ( ! empty( $args['date_to'] ) ) {
			$where[]  = 'logged_at <= %s';
			$params[] = (string) $args['date_to'];
		}
		if ( ! empty( $args['agent_slug'] ) ) {
			$where[]  = 'agent_slug = %s';
			$params[] = self::normalize_slug( (string) $args['agent_slug'] );
		}

		// Resolve orderby/order with proper fallbacks. The previous version
		// evaluated `( $args['orderby'] ?? 'logged_at' )` inside in_array() but
		// then cast the *original* `$args['orderby']` (possibly null) to string,
		// which raised "Undefined array key" notices on callers that did not
		// pass 'orderby'.
		$orderby_raw = isset( $args['orderby'] ) ? (string) $args['orderby'] : 'logged_at';
		$orderby     = in_array( $orderby_raw, array( 'logged_at', 'id', 'tool_name', 'status', 'agent_slug' ), true )
			? $orderby_raw
			: 'logged_at';
		$order       = strtoupper( isset( $args['order'] ) ? (string) $args['order'] : 'DESC' ) === 'ASC' ? 'ASC' : 'DESC';

		$per_page = isset( $args['per_page'] ) ? max( 1, (int) $args['per_page'] ) : 20;
		$offset   = isset( $args['offset'] ) ? max( 0, (int) $args['offset'] ) : 0;

		$where_sql = implode( ' AND ', $where );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- Query constructed with placeholders and sanitized values.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}wpwebmcp_log WHERE {$where_sql} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d",
				array_merge( $params, array( $per_page, $offset ) )
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

		return array_map( array( self::class, 'decode_row' ), (array) $rows );
	}

	/**
	 * Same filter keys as find() but returns the matching count.
	 */
	public static function count( array $args = array() ): int {
		global $wpdb;

		$where  = array( '1=1' );
		$params = array();
		// F8: internal cron maintenance rows are hidden from default reads.
		// Pass 'include_internal' => true to include them (debug views).
		if ( empty( $args['include_internal'] ) ) {
			$where[] = "tool_name NOT LIKE 'cron%'";
		}
		if ( ! empty( $args['tool_name'] ) ) {
			$where[]  = 'tool_name = %s';
			$params[] = self::normalize_name( (string) $args['tool_name'] );
		}
		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$params[] = self::normalize_status( (string) $args['status'] );
		}
		if ( ! empty( $args['date_from'] ) ) {
			$where[]  = 'logged_at >= %s';
			$params[] = (string) $args['date_from'];
		}
		if ( ! empty( $args['date_to'] ) ) {
			$where[]  = 'logged_at <= %s';
			$params[] = (string) $args['date_to'];
		}
		if ( ! empty( $args['agent_slug'] ) ) {
			$where[]  = 'agent_slug = %s';
			$params[] = self::normalize_slug( (string) $args['agent_slug'] );
		}

		$where_sql = implode( ' AND ', $where );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Query constructed with placeholders and sanitized values.
		if ( empty( $params ) ) {
			$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}wpwebmcp_log WHERE {$where_sql}" );
		} else {
			$count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}wpwebmcp_log WHERE {$where_sql}", $params ) );
		}
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

		return $count;
	}

	/**
	 * Per-agent call counts (M0c). Returns array keyed by agent_slug
	 * (value 'unknown' is included so the UI can render a single row for it).
	 *
	 * @return array<string, int>
	 */
	public static function counts_by_agent(): array {
		global $wpdb;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
		$rows = (array) $wpdb->get_results(
			"SELECT agent_slug, COUNT(*) AS n FROM {$wpdb->prefix}wpwebmcp_log GROUP BY agent_slug",
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery

		$out = array();
		foreach ( $rows as $row ) {
			$slug = isset( $row['agent_slug'] ) && (string) $row['agent_slug'] !== ''
				? (string) $row['agent_slug']
				: 'unknown';
			$out[ $slug ] = (int) ( $row['n'] ?? 0 );
		}
		return $out;
	}

	/**
	 * Most recent tool call timestamp per agent (M0c). Used by the
	 * Agents admin page to show "last seen" freshness.
	 *
	 * @return array<string, string> Map of agent_slug -> MySQL datetime.
	 */
	public static function last_seen_by_agent(): array {
		global $wpdb;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
		$rows = (array) $wpdb->get_results(
			"SELECT agent_slug, MAX(logged_at) AS last_seen FROM {$wpdb->prefix}wpwebmcp_log GROUP BY agent_slug",
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery

		$out = array();
		foreach ( $rows as $row ) {
			$slug = isset( $row['agent_slug'] ) && (string) $row['agent_slug'] !== ''
				? (string) $row['agent_slug']
				: 'unknown';
			$out[ $slug ] = (string) ( $row['last_seen'] ?? '' );
		}
		return $out;
	}

	public static function count_today(): int {
		return self::count(
			array(
				'date_from' => gmdate( 'Y-m-d 00:00:00' ),
				'date_to'   => gmdate( 'Y-m-d 23:59:59' ),
			)
		);
	}

	/**
	 * Delete rows logged before the given MySQL datetime.
	 *
	 * @return int Number of rows deleted.
	 */
	public static function purge_before( string $datetime ): int {
		global $wpdb;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
		$count = (int) $wpdb->query(
			$wpdb->prepare( "DELETE FROM {$wpdb->prefix}wpwebmcp_log WHERE logged_at < %s", $datetime )
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery

		return $count;
	}

	/**
	 * Wipe the whole log. Caller must hold `manage_options` + a confirmed nonce.
	 */
	public static function truncate(): void {
		global $wpdb;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Static truncate query on hardcoded plugin table.
		$wpdb->query( "DELETE FROM {$wpdb->prefix}wpwebmcp_log" );
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery
	}

	/**
	 * Privacy eraser (WP Privacy API §9.6).
	 * user_id → 0, ip_address → NULL. ip_hashed is dropped too so the row
	 * can never be re-attributed to the erased user.
	 *
	 * @return int Rows anonymized.
	 */
	public static function anonymize_user( int $user_id ): int {
		global $wpdb;
		$uid   = absint( $user_id );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
		$count = (int) $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$wpdb->prefix}wpwebmcp_log SET user_id = 0, ip_address = NULL, ip_hashed = NULL, agent_slug = 'unknown' WHERE user_id = %d",
				$uid
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery

		return $count;
	}

	/* ---------- internals ---------- */

	private static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'wpwebmcp_log';
	}

	private static function normalize_name( string $name ): string {
		$name = trim( $name );
		$name = preg_replace( '/[^A-Za-z0-9_\-]/', '', $name ) ?? '';
		return substr( $name, 0, 100 );
	}

	private static function normalize_slug( string $slug ): string {
		$s = strtolower( trim( $slug ) );
		$s = preg_replace( '/[^a-z0-9_\-]/', '', $s ) ?? '';
		return substr( $s, 0, 50 );
	}

	private static function normalize_status( string $status ): string {
		$allowed = array( 'success', 'error', 'rate_limited', 'auth_failed' );
		return in_array( $status, $allowed, true ) ? $status : 'error';
	}

	private static function decode_row( array $row ): array {
		if ( isset( $row['params'] ) && is_string( $row['params'] ) && '' !== $row['params'] ) {
			$decoded = json_decode( $row['params'], true );
			$row['params'] = ( null === $decoded ) ? array() : $decoded;
		}
		return $row;
	}
// phpcs:enable WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}
