<?php
/**
 * Tool repository — all SQL for the `wpwebmcp_tools` table.
 *
 * Custom tool definitions only. Built-in tools (navigate / search / getSite /
 * getPost / …) live in code (Step 3) and are NEVER inserted into this table.
 *
 * Per Doc §4.5. Every dynamic value passes through $wpdb->prepare().
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- $table from self::table() is hardcoded $wpdb->prefix . 'wpwebmcp_tools' literal
// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery -- tool repository reads real-time tool registry; caching would risk stale MCP manifest served to agents
final class WP_WebMCP_Tool_Repository {

	/**
	 * Insert a new custom tool row.
	 *
	 * @param array $data Keys: tool_name, tool_description, tool_type, tool_scope,
	 *                    action_type, action_value, parameters (JSON), status.
	 *                    `parameters` may be an array (will be encoded) or a JSON string.
	 * @return int Inserted id; 0 on failure.
	 */
	public static function insert( array $data ): int {
		global $wpdb;
		$table = self::table();

		$row = self::sanitize_row( $data );

		$params_json = $data['parameters'] ?? '';
		if ( is_array( $params_json ) ) {
			$params_json = wp_json_encode( $params_json );
		}

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery -- repository layer (Doc §3 rule 6).
		$ok = $wpdb->insert(
			$table,
			array(
				'tool_name'        => $row['tool_name'],
				'tool_description' => $row['tool_description'],
				'tool_type'        => $row['tool_type'],
				'tool_scope'       => $row['tool_scope'],
				'action_type'      => $row['action_type'],
				'action_value'     => $row['action_value'],
				'parameters'       => $params_json,
				'status'           => $row['status'],
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery

		return $ok ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * Update an existing tool row. Bumps `updated_at` to CURRENT_TIMESTAMP.
	 *
	 * @return bool True if a row was updated.
	 */
	public static function update( int $id, array $data ): bool {
		global $wpdb;
		$table = self::table();

		$row = self::sanitize_row( $data, true );

		// Build update payload from the allowed keys; parameters is special (may be array).
		$payload = array();
		$formats = array();
		foreach ( array( 'tool_name', 'tool_description', 'tool_type', 'tool_scope', 'action_type', 'action_value', 'status' ) as $key ) {
			if ( array_key_exists( $key, $row ) ) {
				$payload[ $key ] = $row[ $key ];
				$formats[]       = '%s';
			}
		}
		if ( array_key_exists( 'parameters', $data ) ) {
			$params_json = $data['parameters'];
			if ( is_array( $params_json ) ) {
				$params_json = wp_json_encode( $params_json );
			}
			$payload['parameters'] = $params_json;
			$formats[]             = '%s';
		}

		$payload['updated_at'] = current_time( 'mysql', true );
		$formats[]             = '%s';

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoFuzzy -- exact id match.
		$ok = $wpdb->update( $table, $payload, array( 'id' => $id ), $formats, array( '%d' ) );
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoFuzzy

		return false !== $ok;
	}

	public static function delete( int $id ): bool {
		global $wpdb;
		$table = self::table();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoFuzzy
		$ok = $wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) );
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoFuzzy

		return false !== $ok && $ok > 0;
	}

	public static function find_by_id( int $id ): ?array {
		global $wpdb;
		$table = self::table();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoFuzzy
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoFuzzy

		return $row ? self::decode_row( $row ) : null;
	}

	public static function find_by_slug( string $tool_name ): ?array {
		global $wpdb;
		$table = self::table();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoFuzzy
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE tool_name = %s", $tool_name ),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoFuzzy

		return $row ? self::decode_row( $row ) : null;
	}

	/**
	 * Find active tools, optionally filtered by scope.
	 *
	 * @return array<int, array> List of decoded rows.
	 */
	public static function find_active( ?string $scope = null ): array {
		global $wpdb;
		$table = self::table();

		if ( null === $scope || '' === $scope ) {
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
			$rows = $wpdb->get_results(
				"SELECT * FROM {$table} WHERE status = 'active' ORDER BY tool_name ASC",
				ARRAY_A
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery
		} else {
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM {$table} WHERE status = %s AND ( tool_scope = %s OR tool_scope = 'all' ) ORDER BY tool_name ASC",
					'active',
					$scope
				),
				ARRAY_A
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery
		}

		return array_map( array( self::class, 'decode_row' ), (array) $rows );
	}

	/**
	 * List every custom tool row (any status), newest first.
	 *
	 * Used by the Tool Builder admin REST list endpoint and by
	 * exporters. Differs from find_active() which filters status=active
	 * and is used by the runtime schema builder.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function list_all(): array {
		global $wpdb;
		$table = self::table();
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
		$rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC", ARRAY_A );
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery
		return array_map( array( self::class, 'decode_row' ), (array) $rows );
	}

	/**
	 * Insert or update by slug. Used by the import path (§7.6).
	 */
	public static function upsert_by_slug( array $data ): int {
		$existing = self::find_by_slug( (string) ( $data['tool_name'] ?? '' ) );
		if ( $existing ) {
			$ok = self::update( (int) $existing['id'], $data );
			return $ok ? (int) $existing['id'] : 0;
		}
		return self::insert( $data );
	}

	/**
	 * Count tools by status. Default = `active` (matches Doc §4.5).
	 */
	public static function count( string $status = 'active' ): int {
		global $wpdb;
		$table = self::table();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
		$count = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", $status )
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery

		return $count;
	}

	/* ---------- internals ---------- */

	private static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'wpwebmcp_tools';
	}

	/**
	 * Normalize + sanitize an incoming row before it touches SQL.
	 *
	 * @param bool $partial True for updates — missing keys keep their stored value.
	 */
	private static function sanitize_row( array $data, bool $partial = false ): array {
		$row = array();

		if ( ! $partial || array_key_exists( 'tool_name', $data ) ) {
			$row['tool_name'] = self::sanitize_slug( (string) ( $data['tool_name'] ?? '' ) );
		}
		if ( ! $partial || array_key_exists( 'tool_description', $data ) ) {
			$desc = (string) ( $data['tool_description'] ?? '' );
			if ( strlen( $desc ) < 20 ) {
				$desc = str_pad( $desc, 20, '.' ); // meets the §4.2.1 ≥20 char minimum.
			}
			$row['tool_description'] = wp_kses_post( $desc );
		}
		if ( ! $partial || array_key_exists( 'tool_type', $data ) ) {
			$type = (string) ( $data['tool_type'] ?? 'read' );
			$row['tool_type'] = in_array( $type, array( 'read', 'write' ), true ) ? $type : 'read';
		}
		if ( ! $partial || array_key_exists( 'tool_scope', $data ) ) {
			$scope = (string) ( $data['tool_scope'] ?? 'all' );
			$allowed = array( 'homepage', 'single', 'archive', 'search', '404', 'woo', 'all' );
			$row['tool_scope'] = in_array( $scope, $allowed, true ) ? $scope : 'all';
		}
		if ( ! $partial || array_key_exists( 'action_type', $data ) ) {
			$at = (string) ( $data['action_type'] ?? '' );
			$allowed = array( 'navigate', 'search', 'rest', 'hook' );
			$row['action_type'] = in_array( $at, $allowed, true ) ? $at : 'rest';
		}
		if ( ! $partial || array_key_exists( 'action_value', $data ) ) {
			$row['action_value'] = (string) ( $data['action_value'] ?? '' );
		}
		if ( ! $partial || array_key_exists( 'status', $data ) ) {
			$s = (string) ( $data['status'] ?? 'active' );
			$allowed = array( 'active', 'disabled', 'sandbox' );
			$row['status'] = in_array( $s, $allowed, true ) ? $s : 'active';
		}

		// parameters kept as-is — encoded in caller to allow partial-update no-op.
		return $row;
	}

	/**
	 * tool_name is a camelCase identifier (≤100 chars). sanitize_key + ASCII guard.
	 */
	private static function sanitize_slug( string $name ): string {
		$name = trim( $name );
		// Allow camelCase + ASCII alnum + underscore.
		$name = preg_replace( '/[^A-Za-z0-9_]/', '', $name ) ?? '';
		return substr( $name, 0, 100 );
	}

	/**
	 * Decode parameters JSON back to array for callers (read path).
	 */
	private static function decode_row( array $row ): array {
		if ( isset( $row['parameters'] ) && is_string( $row['parameters'] ) ) {
			$decoded = json_decode( $row['parameters'], true );
			$row['parameters'] = ( null === $decoded ) ? array() : $decoded;
		}
		return $row;
	}
	// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}