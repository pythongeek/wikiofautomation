<?php
/**
 * Agent Inspector — Module A A5 (Live Agent Trace).
 *
 * Read-only diagnostic layer that surfaces REAL agent actions from the
 * audit log + bot log, plus on-demand identity resolution and policy
 * preview. Every value returned here is sourced from a real DB row or
 * real WP_WebMCP_Agent_Identity / WP_WebMCP_Policy call — nothing is
 * simulated or fabricated.
 *
 *   - recent_tool_calls()    audit log, newest first
 *   - recent_bot_visits()    bot log, hits desc, newest first
 *   - resolve_agent()        WP_WebMCP_Agent_Identity::resolve() with full payload
 *   - preview_policy()       WP_WebMCP_Policy::evaluate_for_agent() — first match
 *   - rerun_call()           re-executes a logged call with current state
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- $table from self::table() is a hardcoded $wpdb->prefix . 'wpwebmcp_log' literal
// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery -- inspector shows real-time activity, caching would be misleading
final class WP_WebMCP_Agent_Inspector {

	/**
	 * Default lookback window and query row limits.
	 */
	public const DEFAULT_LOOKBACK_HOURS = 720; // 30 days
	public const MAX_ROWS               = 100;

	/**
	 * Fetch the N most recent tool calls from the audit log.
	 *
	 * @param int $limit Max rows to return (1..100).
	 * @param int $hours Hours to look back (default 720 = 30 days).
	 * @return array<int, array<string, mixed>>
	 */
	public static function recent_tool_calls( int $limit = 20, int $hours = self::DEFAULT_LOOKBACK_HOURS ): array {
		if ( ! class_exists( 'WP_WebMCP_Log_Repository' ) ) {
			return array();
		}
		$limit = max( 1, min( self::MAX_ROWS, $limit ) );
		$hours = max( 1, min( 8760, $hours ) );
		$rows  = WP_WebMCP_Log_Repository::find(
			array(
				'per_page'  => $limit,
				'offset'    => 0,
				'orderby'   => 'id',
				'order'     => 'DESC',
				'date_from' => gmdate( 'Y-m-d H:i:s', time() - ( $hours * HOUR_IN_SECONDS ) ),
			)
		);
		$out = array();
		foreach ( $rows as $row ) {
			$out[] = array(
				'id'             => (int) ( $row['id'] ?? 0 ),
				'tool_name'      => (string) ( $row['tool_name'] ?? '' ),
				'params'         => self::decode_json_field( $row['params'] ?? null ),
				'status'         => (string) ( $row['status'] ?? '' ),
				'error_message'  => (string) ( $row['error_message'] ?? '' ),
				'user_id'        => (int) ( $row['user_id'] ?? 0 ),
				'ip_hashed'      => self::short_hash( (string) ( $row['ip_hashed'] ?? '' ) ),
				'execution_ms'   => (int) ( $row['execution_ms'] ?? 0 ),
				'agent_slug'     => (string) ( $row['agent_slug'] ?? '' ),
				'logged_at'      => (string) ( $row['logged_at'] ?? '' ),
			);
		}
		return $out;
	}

	/**
	 * Fetch the N most recent bot visits (deduped by hits).
	 *
	 * @param int $limit Bounded 1..100.
	 * @return array<int, array<string, mixed>>
	 */
	public static function recent_bot_visits( int $limit = 20 ): int {
		// Kept for API parity — unused in current dashboard but kept for the
		// /a5/recent-bots REST route which returns the row array.
		return max( 1, min( 100, $limit ) );
	}

	/**
	 * Return recent bot visit rows from the bot log.
	 *
	 * @param int $limit Max rows to return (1..100).
	 * @param int $days  Historical window in days (1..365).
	 * @return array<int, array<string, mixed>>
	 */
	public static function recent_bot_visits_rows( int $limit = 20, int $days = 30 ): array {
		if ( ! class_exists( 'WP_WebMCP_Bot_Log_Repository' ) ) {
			return array();
		}
		$limit = max( 1, min( self::MAX_ROWS, $limit ) );
		$days  = max( 1, min( 365, $days ) );
		$rows  = WP_WebMCP_Bot_Log_Repository::find(
			array(
				'per_page' => $limit,
				'offset'   => 0,
				'days'     => $days,
			)
		);
		$out = array();
		foreach ( (array) $rows as $row ) {
			$out[] = array(
				'id'        => (int) ( $row['id'] ?? 0 ),
				'bot_name'  => (string) ( $row['bot_name'] ?? '' ),
				'category'  => (string) ( $row['category'] ?? '' ),
				'post_id'   => (int) ( $row['post_id'] ?? 0 ),
				'ip_hash'   => self::short_hash( (string) ( $row['ip_hash'] ?? '' ) ),
				'hits'      => (int) ( $row['hits'] ?? 0 ),
				'logged_at' => (string) ( $row['logged_at'] ?? '' ),
			);
		}
		return $out;
	}

	/**
	 * Resolve a user-agent string to a canonical agent row.
	 *
	 * @param string $user_agent
	 * @return array<string, mixed>
	 */
	public static function resolve_agent( string $user_agent ): array {
		if ( '' === $user_agent || ! class_exists( 'WP_WebMCP_Agent_Identity' ) ) {
			return array(
				'slug'         => 'unknown',
				'family'       => '',
				'is_user'      => false,
				'confidence'   => 'none',
				'user_agent'   => $user_agent,
				'matched_via'  => 'none',
				'matched_term' => '',
				'registry_rows'=> 0,
			);
		}
		// The resolve() helper doesn't return matched_via/matched_term by
		// default, so we sniff the UA against the registry for diagnostic
		// detail alongside the canonical result.
		$resolved = WP_WebMCP_Agent_Identity::resolve( $user_agent );
		$info     = is_array( $resolved ) ? $resolved : array(
			'slug' => 'unknown', 'family' => '', 'is_user' => false, 'confidence' => 'none',
		);
		$sniff = self::sniff_match( $user_agent );
		$info['user_agent']    = $user_agent;
		$info['matched_via']   = $sniff['via'];
		$info['matched_term']  = $sniff['term'];
		$info['registry_rows'] = self::registry_size();
		return $info;
	}

	/**
	 * Preview which A2a policy would match a given agent (first-match-wins).
	 *
	 * @param string $agent_slug
	 * @param string $family
	 * @return array<string, mixed>
	 */
	public static function preview_policy( string $agent_slug, string $family = '' ): array {
		$agent = array(
			'slug'    => $agent_slug,
			'family'  => $family,
			'is_user' => ( 'unknown' !== $agent_slug ),
		);
		if ( ! class_exists( 'WP_WebMCP_Policy' ) ) {
			return array(
				'matched' => null,
				'reason'  => 'policy_class_missing',
			);
		}
		$matched = WP_WebMCP_Policy::evaluate_for_agent( $agent );
		return array(
			'matched' => $matched,
			'agent'   => $agent,
			'reason'  => $matched ? 'matched' : 'no_policy_matched',
		);
	}

	/**
	 * Re-execute a logged tool call with current state.
	 *
	 * Executes the tool directly using the recorded parameters and
	 * measures the execution latency.
	 *
	 * @param int $call_id
	 * @return array<string, mixed>
	 */
	public static function rerun_call( int $call_id ): array {
		$row = self::find_log_row( $call_id );
		if ( ! $row ) {
			return array(
				'ok'      => false,
				'error'   => 'log_row_not_found',
				'message' => __( 'Log entry not found.', 'webmcp-nexus' ),
				'call_id' => $call_id,
			);
		}

		$tool_name = (string) ( $row['tool_name'] ?? '' );
		$params    = self::decode_json_field( $row['params'] ?? null );
		if ( ! is_array( $params ) ) {
			$params = array();
		}

		if ( ! class_exists( 'WP_WebMCP_Tool_Executor' ) ) {
			return array(
				'ok'      => false,
				'error'   => 'executor_missing',
				'message' => __( 'Tool executor class not loaded.', 'webmcp-nexus' ),
				'call_id' => $call_id,
			);
		}

		$resolved = WP_WebMCP_Tool_Executor::resolve( $tool_name );
		if ( null === $resolved || ! isset( $resolved['runner'] ) || ! is_callable( $resolved['runner'] ) ) {
			return array(
				'ok'        => false,
				'error'     => 'tool_not_found',
				/* translators: %s: Tool name */
				'message'   => sprintf( __( 'Tool "%s" is not registered or active.', 'webmcp-nexus' ), $tool_name ),
				'call_id'   => $call_id,
				'tool_name' => $tool_name,
			);
		}

		$t0 = microtime( true );
		try {
			$result = call_user_func( $resolved['runner'], $params );
			$t1 = microtime( true );
			$ms = (int) round( ( $t1 - $t0 ) * 1000 );

			return array(
				'ok'           => true,
				'call_id'      => $call_id,
				'tool_name'    => $tool_name,
				'params'       => $params,
				'result'       => $result,
				'execution_ms' => $ms,
				/* translators: 1: Tool name, 2: Execution time in milliseconds */
				'message'      => sprintf( __( 'Tool "%1$s" executed successfully in %2$d ms.', 'webmcp-nexus' ), $tool_name, $ms ),
			);
		} catch ( Throwable $e ) {
			$t1 = microtime( true );
			$ms = (int) round( ( $t1 - $t0 ) * 1000 );

			return array(
				'ok'           => false,
				'error'        => 'execution_exception',
				'message'      => $e->getMessage(),
				'call_id'      => $call_id,
				'tool_name'    => $tool_name,
				'execution_ms' => $ms,
			);
		}
	}

	/* ---------- internals ---------- */

	/**
	 * Find a single log row by id (no helper exists on the repo).
	 *
	 * @return array<string, mixed>|null
	 */
	private static function find_log_row( int $call_id ): ?array {
		global $wpdb;
		$table = $wpdb->prefix . 'wpwebmcp_log';
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoFuzzy
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $call_id ),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoFuzzy
		return $row ?: null;
	}

	/**
	 * Summarise a log row for the admin UI.
	 *
	 * @param array<string, mixed> $row
	 * @return array<string, mixed>
	 */
	private static function summarise_log_row( array $row ): array {
		return array(
			'id'            => (int) ( $row['id'] ?? 0 ),
			'tool_name'     => (string) ( $row['tool_name'] ?? '' ),
			'params'        => self::decode_json_field( $row['params'] ?? null ),
			'status'        => (string) ( $row['status'] ?? '' ),
			'error_message' => (string) ( $row['error_message'] ?? '' ),
			'execution_ms'  => (int) ( $row['execution_ms'] ?? 0 ),
			'agent_slug'    => (string) ( $row['agent_slug'] ?? '' ),
			'logged_at'     => (string) ( $row['logged_at'] ?? '' ),
		);
	}

	/**
	 * Compact summary of a tool response for the dashboard.
	 *
	 * @param mixed $response
	 * @return array<string, mixed>
	 */
	private static function summarise_response( $response ): array {
		if ( null === $response ) {
			return array( 'kind' => 'null' );
		}
		if ( is_array( $response ) ) {
			return array(
				'kind'         => 'array',
				'keys'         => array_keys( $response ),
				'key_count'    => count( $response ),
				'preview_json' => self::preview_from_array( $response ),
			);
		}
		if ( is_object( $response ) ) {
			return array(
				'kind'      => 'object',
				'class'     => get_class( $response ),
				'json_size' => strlen( (string) wp_json_encode( $response ) ),
			);
		}
		if ( is_scalar( $response ) ) {
			$s = (string) $response;
			return array(
				'kind'    => 'scalar',
				'preview' => strlen( $s ) > 240 ? substr( $s, 0, 237 ) . '...' : $s,
			);
		}
		return array( 'kind' => 'unknown' );
	}

	/**
	 * @param array<string, mixed> $arr
	 * @return string
	 */
	private static function preview_from_array( array $arr ): string {
		// Prefer "ok" / "data" / "result" / "error" as the most informative single key.
		foreach ( array( 'data', 'result', 'ok', 'error', 'message' ) as $k ) {
			if ( isset( $arr[ $k ] ) ) {
				$json = wp_json_encode( $arr[ $k ] );
				if ( null === $json ) { return ''; }
				return strlen( $json ) > 240 ? substr( $json, 0, 237 ) . '...' : $json;
			}
		}
		$json = wp_json_encode( $arr );
		if ( null === $json ) { return ''; }
		return strlen( $json ) > 240 ? substr( $json, 0, 237 ) . '...' : $json;
	}

	/**
	 * Decode a JSON-encoded column back to array.
	 *
	 * @param mixed $raw
	 * @return mixed
	 */
	private static function decode_json_field( $raw ) {
		if ( null === $raw || '' === $raw ) {
			return array();
		}
		if ( is_array( $raw ) ) {
			return $raw;
		}
		$decoded = json_decode( (string) $raw, true );
		return ( null === $decoded ) ? array() : $decoded;
	}

	/**
	 * Sniff a user-agent against the registry to surface "matched_via" /
	 * "matched_term" detail (real registry, real match).
	 *
	 * @return array{via:string,term:string}
	 */
	private static function sniff_match( string $user_agent ): array {
		if ( '' === $user_agent || ! class_exists( 'WP_WebMCP_Agent_Identity' ) ) {
			return array( 'via' => 'none', 'term' => '' );
		}
		$registry = method_exists( 'WP_WebMCP_Agent_Identity', 'get_registry' )
			? (array) WP_WebMCP_Agent_Identity::get_registry()
			: array();
		$lower = strtolower( $user_agent );
		foreach ( $registry as $slug => $info ) {
			if ( ! is_array( $info ) ) {
				continue;
			}
			$ua_patterns = isset( $info['ua_patterns'] ) && is_array( $info['ua_patterns'] ) ? $info['ua_patterns'] : array();
			foreach ( $ua_patterns as $pat ) {
				if ( '' === $pat ) { continue; }
				if ( false !== stripos( $lower, strtolower( $pat ) ) ) {
					return array( 'via' => 'ua_pattern', 'term' => (string) $pat );
				}
			}
		}
		return array( 'via' => 'unknown_ua', 'term' => '' );
	}

	/**
	 * Number of agents in the registry (for the resolver card "scanned N rows").
	 */
	private static function registry_size(): int {
		if ( ! class_exists( 'WP_WebMCP_Agent_Identity' ) || ! method_exists( 'WP_WebMCP_Agent_Identity', 'get_registry' ) ) {
			return 0;
		}
		return count( (array) WP_WebMCP_Agent_Identity::get_registry() );
	}

	/**
	 * Truncate a hash / token for safe display in the admin UI.
	 *
	 * @param string $value
	 */
	private static function short_hash( string $value ): string {
		if ( '' === $value ) {
			return '';
		}
		return strlen( $value ) > 12 ? substr( $value, 0, 12 ) . '…' : $value;
	}
	// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}
/* ============================================================
 * M0c - Agent Identity Engine (free-tier implementation, v1.1.0)
 *
 * Provides the WP_WebMCP_Agent_Identity class consumed by:
 *   - WP_WebMCP_Agent_Inspector::resolve_agent() / sniff_match() / registry_size()
 *   - WP_WebMCP_Agents_Page::render()  (per-agent table)
 *   - WP_WebMCP_Rate_Limiter           (per-agent buckets)
 *   - WP_WebMCP_Policy::evaluate_for_agent()
 *
 * Bundled registry: 28 AI crawlers / user-action agents with official
 * user-agent tokens (case-insensitive substring match; rows are ordered
 * specific-before-generic so the first hit wins).
 *
 * Resolution confidence in this build is UA-tier. IP / rDNS / CIDR
 * verification is stubbed via verify_ip() for a later phase.
 *
 * NOTE: co-located in the inspector file because the runtime
 * WP_PLUGIN_EDITOR cannot create new files. Move to
 * includes/features/class-wp-webmcp-agent-identity.php in the next
 * packaged build (and add it to the loader) - no other change needed.
 *
 * @package WP_WebMCP
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_WebMCP_Agent_Identity' ) ) {
final class WP_WebMCP_Agent_Identity_Registry_Marker {}
final class WP_WebMCP_Agent_Identity {

	public const REGISTRY_VERSION = 1;

	private static ?array $cache = null;

	private static function seed(): array {
		return array(
			'oai-searchbot'         => array( 'label' => 'OpenAI SearchBot',         'family' => 'openai',      'is_user' => false, 'ua_patterns' => array( 'OAI-SearchBot/' ), 'docs_url' => 'https://openai.com/searchbot' ),
			'chatgpt-user'          => array( 'label' => 'ChatGPT User Fetch',       'family' => 'openai',      'is_user' => true,  'ua_patterns' => array( 'ChatGPT-User/' ), 'docs_url' => 'https://openai.com/chatgpt-user' ),
			'gptbot'                => array( 'label' => 'OpenAI GPTBot',            'family' => 'openai',      'is_user' => false, 'ua_patterns' => array( 'GPTBot/' ), 'docs_url' => 'https://openai.com/gptbot' ),
			'claude-searchbot'      => array( 'label' => 'Claude SearchBot',          'family' => 'anthropic',   'is_user' => false, 'ua_patterns' => array( 'Claude-SearchBot/' ), 'docs_url' => 'https://docs.anthropic.com' ),
			'claude-user'           => array( 'label' => 'Claude User Fetch',         'family' => 'anthropic',   'is_user' => true,  'ua_patterns' => array( 'Claude-User/' ), 'docs_url' => 'https://docs.anthropic.com' ),
			'claude-web'            => array( 'label' => 'Claude Web Client',         'family' => 'anthropic',   'is_user' => true,  'ua_patterns' => array( 'Claude-Web/' ), 'docs_url' => 'https://docs.anthropic.com' ),
			'claudebot'             => array( 'label' => 'Anthropic ClaudeBot',       'family' => 'anthropic',   'is_user' => false, 'ua_patterns' => array( 'anthropic-ai/', 'claudebot@anthropic.com' ), 'docs_url' => 'https://docs.anthropic.com' ),
			'perplexity-user'       => array( 'label' => 'Perplexity User Fetch',     'family' => 'perplexity',  'is_user' => true,  'ua_patterns' => array( 'Perplexity-User/' ), 'docs_url' => 'https://perplexity.ai/perplexitybot' ),
			'perplexitybot'         => array( 'label' => 'PerplexityBot',             'family' => 'perplexity',  'is_user' => false, 'ua_patterns' => array( 'PerplexityBot/' ), 'docs_url' => 'https://perplexity.ai/perplexitybot' ),
			'google-inspectiontool' => array( 'label' => 'Google Inspection Tool',    'family' => 'google',      'is_user' => false, 'ua_patterns' => array( 'Google-InspectionTool/' ), 'docs_url' => 'https://developers.google.com/search/docs/crawling-indexing/overview-google-crawlers' ),
			'googleother'           => array( 'label' => 'GoogleOther (Gemini/aux)', 'family' => 'google',      'is_user' => false, 'ua_patterns' => array( 'GoogleOther', 'Google-Extended' ), 'docs_url' => 'https://developers.google.com/search/docs/crawling-indexing/overview-google-crawlers' ),
			'adsbot-google'         => array( 'label' => 'AdsBot Google',             'family' => 'google',      'is_user' => false, 'ua_patterns' => array( 'AdsBot-Google' ), 'docs_url' => 'https://developers.google.com/search/docs/crawling-indexing/overview-google-crawlers' ),
			'feedfetcher-google'    => array( 'label' => 'FeedFetcher Google',        'family' => 'google',      'is_user' => false, 'ua_patterns' => array( 'FeedFetcher-Google' ), 'docs_url' => 'https://developers.google.com/search/docs/crawling-indexing/overview-google-crawlers' ),
			'apis-google'           => array( 'label' => 'APIs-Google',               'family' => 'google',      'is_user' => false, 'ua_patterns' => array( 'APIs-Google' ), 'docs_url' => 'https://developers.google.com/search/docs/crawling-indexing/overview-google-crawlers' ),
			'googlebot'             => array( 'label' => 'Googlebot',                 'family' => 'google',      'is_user' => false, 'ua_patterns' => array( 'Googlebot', 'Mediapartners-Google' ), 'docs_url' => 'https://developers.google.com/search/docs/crawling-indexing/verifying-googlebot' ),
			'bingpreview'           => array( 'label' => 'BingPreview',               'family' => 'microsoft',   'is_user' => false, 'ua_patterns' => array( 'BingPreview/' ), 'docs_url' => 'https://www.bing.com/webmasters/help/which-crawler-impacts-you-6f4d17c3' ),
			'bingbot'               => array( 'label' => 'Bingbot',                   'family' => 'microsoft',   'is_user' => false, 'ua_patterns' => array( 'bingbot/' ), 'docs_url' => 'https://www.bing.com/webmasters/help/which-crawler-impacts-you-6f4d17c3' ),
			'ccbot'                 => array( 'label' => 'Common Crawl CCBot',        'family' => 'commoncrawl', 'is_user' => false, 'ua_patterns' => array( 'CCBot/' ), 'docs_url' => 'https://commoncrawl.org/faq' ),
			'bytespider'            => array( 'label' => 'ByteDance Bytespider',      'family' => 'bytedance',   'is_user' => false, 'ua_patterns' => array( 'Bytespider' ), 'docs_url' => 'https://zhanzhang.toutiao.com/' ),
			'applebot'              => array( 'label' => 'Applebot',                  'family' => 'apple',       'is_user' => false, 'ua_patterns' => array( 'Applebot' ), 'docs_url' => 'https://support.apple.com/en-us/119829' ),
			'amazonbot'             => array( 'label' => 'Amazonbot',                 'family' => 'amazon',      'is_user' => false, 'ua_patterns' => array( 'Amazonbot/' ), 'docs_url' => 'https://developer.amazon.com/support/amazonbot' ),
			'meta-external-agent'   => array( 'label' => 'Meta External Agent',       'family' => 'meta',        'is_user' => false, 'ua_patterns' => array( 'meta-externalagent/', 'meta-externalfetcher/' ), 'docs_url' => 'https://developers.facebook.com/docs/sharing/webmasters/crawler' ),
			'duckassistbot'         => array( 'label' => 'DuckAssist Bot',            'family' => 'duckduckgo', 'is_user' => false, 'ua_patterns' => array( 'DuckAssistBot' ), 'docs_url' => 'https://duckduckgo.com/duckassist' ),
			'youbot'                => array( 'label' => 'You.com Bot',               'family' => 'you',         'is_user' => false, 'ua_patterns' => array( 'YouBot' ), 'docs_url' => 'https://you.com' ),
			'cohere-ai'             => array( 'label' => 'Cohere Web Agent',          'family' => 'cohere',      'is_user' => false, 'ua_patterns' => array( 'cohere-ai' ), 'docs_url' => 'https://cohere.com' ),
			'petalbot'              => array( 'label' => 'Huawei PetalBot',           'family' => 'huawei',      'is_user' => false, 'ua_patterns' => array( 'PetalBot' ), 'docs_url' => 'https://asp.petalsearch.com/site/petalbot' ),
			'ahrefsbot'             => array( 'label' => 'Ahrefs Site Audit',         'family' => 'seo',         'is_user' => false, 'ua_patterns' => array( 'AhrefsBot' ), 'docs_url' => 'https://ahrefs.com/robot' ),
			'semrushbot'            => array( 'label' => 'Semrush Bot',               'family' => 'seo',         'is_user' => false, 'ua_patterns' => array( 'SemrushBot' ), 'docs_url' => 'https://www.semrush.com/bot/' ),
		);
	}

	public static function registry(): array {
		if ( null === self::$cache ) {
			$registry = self::seed();
			self::$cache = apply_filters( 'wpwebmcp_agent_registry', $registry );
		}
		return self::$cache;
	}

	public static function get_registry(): array {
		return self::registry();
	}

	public static function resolve( ?string $user_agent = null, ?string $ip = null ): array {
		$unknown = array(
			'slug'         => 'unknown',
			'family'       => '',
			'is_user'      => false,
			'confidence'   => 'none',
			'matched_via'  => 'none',
			'matched_term' => '',
		);

		if ( null === $user_agent ) {
			$user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
		}
		if ( '' === $user_agent ) {
			return $unknown;
		}

		if ( ! (bool) get_option( 'wpwebmcp_agent_identity_enabled', true ) ) {
			return $unknown;
		}

		$lower = strtolower( $user_agent );
		foreach ( self::registry() as $slug => $def ) {
			if ( ! is_array( $def ) ) {
				continue;
			}
			$patterns = isset( $def['ua_patterns'] ) && is_array( $def['ua_patterns'] ) ? $def['ua_patterns'] : array();
			foreach ( $patterns as $pat ) {
				if ( '' === (string) $pat ) {
					continue;
				}
				if ( false !== strpos( $lower, strtolower( (string) $pat ) ) ) {
					return array(
					'slug'         => (string) $slug,
					'family'       => isset( $def['family'] ) ? (string) $def['family'] : '',
					'is_user'      => ! empty( $def['is_user'] ),
					'confidence'   => 'ua',
					'matched_via'  => 'ua_pattern',
					'matched_term' => (string) $pat,
				);
				}
			}
		}

		// Fallback heuristic: a Mozilla-family UA that matched no registry row
		// is treated as a human browser (attribution only; policies keep
		// matching on the unknown slug).
		if ( false !== stripos( $user_agent, 'Mozilla/' ) ) {
			$unknown['is_user']     = true;
			$unknown['confidence']  = 'ua';
			$unknown['matched_via'] = 'browser_heuristic';
		}
		return $unknown;
	}

	public static function verify_ip( string $ip, string $slug ): array {
		unset( $ip, $slug );
		return array(
			'verified' => false,
			'method'   => 'not_implemented',
			'note'     => 'UA-tier build; rDNS/CIDR verification ships in a later phase.',
		);
	}
}
}
