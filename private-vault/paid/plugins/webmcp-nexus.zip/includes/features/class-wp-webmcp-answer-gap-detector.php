<?php
/**
 * Answer-Gap Detector — Module A A3a (AEO Intelligence).
 *
 * Cross-references the question bank against the existing MCP tool
 * inventory (built-in tools across all contexts + custom tools from
 * WP_WebMCP_Tool_Repository) and emits a "gap" for every question that
 * doesn't have a reasonable existing match.
 *
 * Match algorithm (intentionally simple + deterministic):
 *   1. Tokenise the expected_intent into a bag of lowercase words.
 *   2. Strip stop words.
 *   3. For each existing tool, build a corpus from name + description +
 *      parameter names (JSON-decoded).
 *   4. Score = number of intent tokens present in the tool corpus.
 *   5. If best score >= floor (default 2), the question is COVERED.
 *      Otherwise it is a GAP.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Answer_Gap_Detector {

	/** Minimum number of intent tokens that must match an existing tool's corpus. */
	private const MATCH_FLOOR = 2;

	/** Stop words removed from intent strings before matching. */
	private const STOP_WORDS = array(
		'a', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'do', 'for', 'from',
		'has', 'have', 'how', 'i', 'in', 'is', 'it', 'me', 'my', 'of', 'on',
		'or', 'show', 'tell', 'that', 'the', 'this', 'to', 'was', 'we', 'what',
		'when', 'where', 'which', 'who', 'why', 'will', 'with', 'you', 'your',
		'i\'d', 'i\'m', 'i\'ve',
	);

	/**
	 * Run the detector across every question in the bank.
	 *
	 * @param string|null $vertical Optional vertical filter (null = all).
	 * @param int         $match_floor Optional floor override (default 2).
	 * @return array<string, mixed>  { vertical, total, covered, gaps }
	 */
	public static function detect( ?string $vertical = null, int $match_floor = self::MATCH_FLOOR ): array {
		$tool_corpus  = self::build_tool_corpus();
		$questions    = null === $vertical
			? WP_WebMCP_Question_Bank::all_questions()
			: WP_WebMCP_Question_Bank::questions_for( $vertical );

		$covered = 0;
		$gaps    = array();
		foreach ( $questions as $q ) {
			$matched_tool = self::match_intent_to_tools( (string) $q['expected_intent'], $tool_corpus, $match_floor );
			if ( null !== $matched_tool ) {
				++$covered;
				continue;
			}
			$gaps[] = array(
				'query'           => (string) $q['query'],
				'vertical'        => (string) $q['vertical'],
				'expected_intent' => (string) $q['expected_intent'],
				'suggested_tool'  => isset( $q['suggested_tool'] ) && is_array( $q['suggested_tool'] ) ? $q['suggested_tool'] : array(),
			);
		}

		return array(
			'vertical'  => $vertical ?: 'all',
			'total'     => count( $questions ),
			'covered'   => $covered,
			'gap_count' => count( $gaps ),
			'gaps'      => $gaps,
		);
	}

	/**
	 * Convenience: detect for one specific vertical.
	 *
	 * @return array<string, mixed>
	 */
	public static function detect_vertical( string $vertical ): array {
		return self::detect( $vertical );
	}

	/**
	 * Per-vertical summary — returns just the counts so the dashboard can
	 * render a coverage matrix without paying the cost of full gap payloads.
	 *
	 * @return array<string, array{vertical:string,total:int,covered:int,gap_count:int}>
	 */
	public static function coverage_by_vertical(): array {
		$out = array();
		foreach ( WP_WebMCP_Question_Bank::verticals() as $vertical ) {
			$r = self::detect( $vertical );
			$out[] = array(
				'vertical'  => $vertical,
				'total'     => (int) $r['total'],
				'covered'   => (int) $r['covered'],
				'gap_count' => (int) $r['gap_count'],
			);
		}
		return $out;
	}

	/* ---------- internals ---------- */

	/**
	 * Build a corpus of [slug => "tokens"] from every existing tool.
	 *
	 * Uses WP_WebMCP_Schema_Builder::get_all_tools() which already merges
	 * built-in + Woo + custom DB tools.
	 *
	 * @return array<string, string[]>  Map of tool slug to its token list.
	 */
	private static function build_tool_corpus(): array {
		if ( ! class_exists( 'WP_WebMCP_Schema_Builder' ) ) {
			return array();
		}
		$tools  = WP_WebMCP_Schema_Builder::get_all_tools();
		$corpus = array();
		foreach ( $tools as $t ) {
			$slug = isset( $t['name'] ) ? (string) $t['name'] : '';
			if ( '' === $slug ) {
				continue;
			}
			$blob = $slug;
			if ( isset( $t['description'] ) && is_string( $t['description'] ) ) {
				$blob .= ' ' . $t['description'];
			}
			if ( isset( $t['inputSchema'] ) ) {
				if ( is_array( $t['inputSchema'] ) && isset( $t['inputSchema']['properties'] ) && is_array( $t['inputSchema']['properties'] ) ) {
					$blob .= ' ' . implode( ' ', array_keys( $t['inputSchema']['properties'] ) );
				}
			}
			$corpus[ $slug ] = self::tokenise( $blob );
		}
		return $corpus;
	}

	/**
	 * Match an intent string against the tool corpus. Returns the best-matching
	 * tool slug, or null when the best score is below the floor.
	 */
	private static function match_intent_to_tools( string $intent, array $corpus, int $floor ): ?string {
		$intent_tokens = self::tokenise( $intent );
		if ( empty( $intent_tokens ) ) {
			return null;
		}
		$best_slug  = null;
		$best_score = 0;
		foreach ( $corpus as $slug => $tool_tokens ) {
			$score = self::intersection_count( $intent_tokens, $tool_tokens );
			if ( $score > $best_score ) {
				$best_score = $score;
				$best_slug  = $slug;
			}
		}
		return ( $best_score >= $floor ) ? $best_slug : null;
	}

	/**
	 * Lowercase + word-boundary split + stop word removal.
	 *
	 * @return string[]
	 */
	private static function tokenise( string $blob ): array {
		$blob  = strtolower( $blob );
		$parts = preg_split( '/[^a-z0-9_]+/u', $blob, -1, PREG_SPLIT_NO_EMPTY );
		if ( ! is_array( $parts ) ) {
			return array();
		}
		$stop = array_flip( self::STOP_WORDS );
		$out  = array();
		foreach ( $parts as $p ) {
			if ( '' === $p || isset( $stop[ $p ] ) ) {
				continue;
			}
			$out[] = $p;
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * @param string[] $a
	 * @param string[] $b
	 */
	private static function intersection_count( array $a, array $b ): int {
		if ( empty( $a ) || empty( $b ) ) {
			return 0;
		}
		$b_set = array_flip( $b );
		$hits  = 0;
		foreach ( $a as $tok ) {
			if ( isset( $b_set[ $tok ] ) ) {
				++$hits;
			}
		}
		return $hits;
	}
}
