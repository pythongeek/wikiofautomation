<?php
/**
 * Bot Analytics Telemetry — Doc §2.1 + §4.2.3 + §7.5 + Part 11.
 *
 * Detects AI search bots and LLM scrapers visiting site URLs, records visits
 * in the database repository, serves the REST analytics stats endpoint,
 * and maintains aggregated rollups.
 *
 * Enriched with comprehensive AI agent signatures (Google Gemini, OpenAI, Claude,
 * Perplexity, Cursor, Antigravity, Apple Intelligence) and contextual header/query triggers.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- reading HTTP headers from $_SERVER is intentional for bot detection; headers are validated against known bot UA patterns
final class WP_WebMCP_Bot_Analytics {

	/** Transient key for 30-day cached rollup stats. */
	public const TRANSIENT_KEY = 'wpwebmcp_bot_stats_30d';

	/** Known AI bot signatures with display label and classification category. */
	private const KNOWN_BOTS = array(
		'Google-Extended'     => array( 'label' => 'Google-Extended (Gemini)', 'category' => 'training' ),
		'GoogleOther'         => array( 'label' => 'Google AI / Gemini',       'category' => 'search' ),
		'Google-Gemini'       => array( 'label' => 'Google Gemini Agent',      'category' => 'search' ),
		'Gemini'              => array( 'label' => 'Google Gemini Crawler',    'category' => 'search' ),
		'VertexAI'            => array( 'label' => 'Google Vertex AI',         'category' => 'search' ),
		'Googlebot'           => array( 'label' => 'Googlebot (Search/AI)',    'category' => 'search' ),
		'antigravity'         => array( 'label' => 'Antigravity AI Agent',     'category' => 'search' ),
		'GPTBot'              => array( 'label' => 'GPTBot (OpenAI)',          'category' => 'training' ),
		'ChatGPT-User'        => array( 'label' => 'ChatGPT User (OpenAI)',    'category' => 'search' ),
		'OAI-SearchBot'       => array( 'label' => 'SearchBot (OpenAI)',       'category' => 'search' ),
		'ClaudeBot'           => array( 'label' => 'ClaudeBot (Anthropic)',    'category' => 'training' ),
		'Claude-Web'          => array( 'label' => 'Claude Web (Anthropic)',   'category' => 'search' ),
		'anthropic-ai'        => array( 'label' => 'Anthropic AI',             'category' => 'training' ),
		'PerplexityBot'       => array( 'label' => 'PerplexityBot',            'category' => 'search' ),
		'Perplexity'          => array( 'label' => 'Perplexity AI',            'category' => 'search' ),
		'Cursor'              => array( 'label' => 'Cursor AI IDE',           'category' => 'search' ),
		'Applebot-Extended'   => array( 'label' => 'Applebot-Extended',        'category' => 'training' ),
		'Applebot'            => array( 'label' => 'Apple Intelligence',       'category' => 'search' ),
		'Amazonbot'           => array( 'label' => 'Amazonbot',                'category' => 'crawler' ),
		'Bytespider'          => array( 'label' => 'Bytespider (ByteDance)',   'category' => 'crawler' ),
		'CCBot'               => array( 'label' => 'CCBot (Common Crawl)',     'category' => 'training' ),
		'cohere-ai'           => array( 'label' => 'Cohere AI',                'category' => 'training' ),
		'Meta-ExternalAgent'  => array( 'label' => 'Meta AI Crawler',          'category' => 'crawler' ),
		'FacebookBot'         => array( 'label' => 'FacebookBot',              'category' => 'crawler' ),
		'Diffbot'             => array( 'label' => 'Diffbot',                  'category' => 'crawler' ),
		'bingbot'             => array( 'label' => 'Bingbot / Copilot',        'category' => 'search' ),
		'Copilot'             => array( 'label' => 'Microsoft Copilot',        'category' => 'search' ),
		'LangChain'           => array( 'label' => 'LangChain Agent',          'category' => 'custom' ),
		'LlamaIndex'          => array( 'label' => 'LlamaIndex Agent',         'category' => 'custom' ),
		'python-requests'     => array( 'label' => 'Python AI Client',         'category' => 'custom' ),
		'aiohttp'             => array( 'label' => 'Async AI Scraper',         'category' => 'custom' ),
		'httpx'               => array( 'label' => 'HTTPX AI Client',          'category' => 'custom' ),
		'axios'               => array( 'label' => 'Node.js AI Agent',         'category' => 'custom' ),
		'node-fetch'          => array( 'label' => 'Node.js Fetch Agent',      'category' => 'custom' ),
		'Postman'             => array( 'label' => 'Postman AI Client',        'category' => 'custom' ),
		'curl'                => array( 'label' => 'cURL Agent Client',        'category' => 'custom' ),
	);

	/**
	 * Initialize Bot Analytics hooks.
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'init',          array( __CLASS__, 'detect' ), 5 );
		WP_WebMCP_Loader::register_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Detect bot visits on incoming HTTP requests.
	 */
	public static function detect(): void {
		$enabled = (bool) get_option( 'wpwebmcp_analytics_enabled', true ) && (bool) get_option( 'wpwebmcp_bot_detection_enabled', true );
		if ( ! $enabled && ! (bool) get_option( 'wpwebmcp_bot_analytics_enabled', true ) ) {
			return;
		}

		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : '';
		$matched = self::match_bot( $ua );

		// Check contextual AI triggers if User-Agent didn't match directly
		if ( null === $matched ) {
			$client_hdr = isset( $_SERVER['HTTP_X_WEBMCP_CLIENT'] ) ? (string) wp_unslash( $_SERVER['HTTP_X_WEBMCP_CLIENT'] ) : '';
			$ai_hdr     = isset( $_SERVER['HTTP_X_AI_AGENT'] ) ? (string) wp_unslash( $_SERVER['HTTP_X_AI_AGENT'] ) : '';
			$accept_hdr = isset( $_SERVER['HTTP_ACCEPT'] ) ? (string) wp_unslash( $_SERVER['HTTP_ACCEPT'] ) : '';
			$format_get = isset( $_GET['format'] ) ? sanitize_key( wp_unslash( $_GET['format'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$uri        = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';

			if ( '' !== $client_hdr ) {
				$matched = array( 'label' => sprintf( 'WebMCP Client (%s)', sanitize_text_field( $client_hdr ) ), 'category' => 'search' );
			} elseif ( '' !== $ai_hdr ) {
				$matched = array( 'label' => sprintf( 'AI Agent (%s)', sanitize_text_field( $ai_hdr ) ), 'category' => 'search' );
			} elseif ( false !== stripos( $accept_hdr, 'text/markdown' ) || in_array( $format_get, array( 'markdown', 'ai', 'md' ), true ) ) {
				$matched = array( 'label' => 'AI Search (Markdown Stream)', 'category' => 'search' );
			} elseif ( false !== stripos( $uri, 'llms.txt' ) || false !== stripos( $uri, 'llms-full.txt' ) ) {
				$matched = array( 'label' => 'AI Agent (/llms.txt Catalog)', 'category' => 'search' );
			} elseif ( false !== stripos( $uri, '.well-known/mcp' ) || false !== stripos( $uri, '.well-known/ai-plugin' ) ) {
				$matched = array( 'label' => 'MCP Discovery Client', 'category' => 'search' );
			}
		}

		if ( null === $matched ) {
			return;
		}

		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '';
		$salt = defined( 'AUTH_SALT' ) ? (string) AUTH_SALT : 'wpwebmcp_salt';
		$ip_hash = '' !== $ip ? hash( 'sha256', $ip . $salt ) : '';

		$post_id = 0;
		if ( isset( $_SERVER['REQUEST_URI'] ) ) {
			$uri = (string) wp_unslash( $_SERVER['REQUEST_URI'] );
			$url = home_url( $uri );
			if ( function_exists( 'url_to_postid' ) ) {
				$post_id = (int) url_to_postid( $url );
			}
		}

		if ( class_exists( 'WP_WebMCP_Bot_Log_Repository' ) ) {
			WP_WebMCP_Bot_Log_Repository::upsert_hit(
				$matched['label'],
				$matched['category'],
				$post_id,
				$ip_hash
			);
		}
	}

	/**
	 * Match User-Agent against known signatures or custom crawlers.
	 *
	 * @param string $ua
	 * @return array{label: string, category: string}|null
	 */
	private static function match_bot( string $ua ): ?array {
		if ( '' === trim( $ua ) ) {
			return null;
		}

		foreach ( self::KNOWN_BOTS as $needle => $info ) {
			if ( false !== stripos( $ua, $needle ) ) {
				return $info;
			}
		}

		$custom = (array) get_option( 'wpwebmcp_custom_crawlers', array() );
		foreach ( $custom as $c ) {
			$name = isset( $c['name'] ) ? trim( (string) $c['name'] ) : '';
			$sig  = isset( $c['signature'] ) ? trim( (string) $c['signature'] ) : '';
			if ( '' !== $sig && false !== stripos( $ua, $sig ) ) {
				return array(
					'label'    => '' !== $name ? $name : $sig,
					'category' => 'custom',
				);
			}
		}

		return null;
	}

	/**
	 * Register REST routes for Analytics.
	 */
	public static function register_routes(): void {
		register_rest_route(
			'wpwebmcp/v1',
			'/analytics/stats',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'rest_stats' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			)
		);

		// Ping / simulation endpoint for testing
		register_rest_route(
			'wpwebmcp/v1',
			'/analytics/simulate-ping',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'rest_simulate_ping' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			)
		);
	}

	/**
	 * Permission check.
	 */
	public static function check_admin(): bool {
		return current_user_can( 'manage_options' );
	}

	/**
	 * REST handler for GET /wpwebmcp/v1/analytics/stats.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public static function rest_stats( WP_REST_Request $request ) {
		$days = (int) ( $request->get_param( 'days' ) ?? 30 );
		$days = max( 1, min( 90, $days ) );

		$data = self::compile_stats( $days );
		return rest_ensure_response( $data );
	}

	/**
	 * REST handler to simulate an AI agent ping for instant testing.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public static function rest_simulate_ping( WP_REST_Request $request ) {
		$bot = sanitize_text_field( (string) ( $request->get_param( 'bot' ) ?? 'Google-Extended (Gemini)' ) );
		$cat = 'search';

		if ( class_exists( 'WP_WebMCP_Bot_Log_Repository' ) ) {
			WP_WebMCP_Bot_Log_Repository::upsert_hit(
				$bot,
				$cat,
				0,
				hash( 'sha256', 'simulation' )
			);
		}

		delete_transient( self::TRANSIENT_KEY );

		/* translators: %s: Bot identifier */
		$wpwebmcp_hit_label = sprintf( __( 'Simulated hit for %s recorded successfully!', 'webmcp-nexus' ), $bot );

		return rest_ensure_response(
			array(
				'ok'      => true,
				'bot'     => $bot,
				'message' => $wpwebmcp_hit_label,
			)
		);
	}

	/**
	 * Compile telemetry statistics for given days.
	 *
	 * @param int $days
	 * @return array<string,mixed>
	 */
	public static function compile_stats( int $days ): array {
		if ( ! class_exists( 'WP_WebMCP_Bot_Log_Repository' ) ) {
			return array(
				'days'          => $days,
				'total_hits'    => 0,
				'by_bot'        => array(),
				'by_day'        => array(),
				'top_pages'     => array(),
			);
		}

		$by_bot    = WP_WebMCP_Bot_Log_Repository::stats_by_bot( $days );
		$by_day    = WP_WebMCP_Bot_Log_Repository::stats_by_day( $days );
		$top_pages = WP_WebMCP_Bot_Log_Repository::top_pages( $days, 10 );

		$total = 0;
		if ( is_array( $by_bot ) ) {
			$total = (int) array_sum( wp_list_pluck( $by_bot, 'hits' ) );
		}

		// Enrich top pages with titles.
		$enriched_pages = array();
		if ( is_array( $top_pages ) ) {
			foreach ( $top_pages as $p ) {
				$pid = (int) ( $p['post_id'] ?? 0 );
				$enriched_pages[] = array(
					'post_id' => $pid,
					'title'   => ( 0 === $pid ) ? __( 'Homepage / llms.txt Catalog', 'webmcp-nexus' ) : ( get_the_title( $pid ) ?: sprintf( '#%d', $pid ) ),
					'url'     => ( 0 === $pid ) ? home_url( '/' ) : ( get_permalink( $pid ) ?: home_url( "/?p={$pid}" ) ),
					'hits'    => (int) ( $p['hits'] ?? 0 ),
				);
			}
		}

		return array(
			'days'          => $days,
			'total_hits'    => $total,
			'by_bot'        => $by_bot ?: array(),
			'by_day'        => $by_day ?: array(),
			'top_pages'     => $enriched_pages,
		);
	}

	/**
	 * Daily cron rollup handler.
	 */
	public static function rollup(): void {
		$stats = self::compile_stats( 30 );
		set_transient( self::TRANSIENT_KEY, $stats, DAY_IN_SECONDS );

		// Purge records older than 90 days.
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( 90 * DAY_IN_SECONDS ) );
		if ( class_exists( 'WP_WebMCP_Bot_Log_Repository' ) ) {
			WP_WebMCP_Bot_Log_Repository::purge_before( $cutoff );
		}
	}
	// phpcs:enable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
}