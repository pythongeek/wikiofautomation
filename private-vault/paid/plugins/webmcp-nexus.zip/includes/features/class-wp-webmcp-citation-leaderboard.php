<?php
/**
 * Citation_Leaderboard — Module A A1d.
 *
 * Ranks every canonical AI agent (per M0c registry) by real-world signals
 * pulled from the existing database tables:
 *
 *   - Tool calls:  wpwebmcp_log table — every WebMCP tool invocation is
 *                  recorded here with the resolved agent_slug (M0c stamps
 *                  it on every successful response).
 *   - Bot visits:  wpwebmcp_bot_log table — every AI bot hit recorded by
 *                  Bot_Analytics with bot_name + post_id + ip_hash + hits.
 *
 * The dashboard closes the loop from "called" (tool invocations) to "cited"
 * (bot visits = the agent saw the page). It is a strict aggregation view:
 * no seed data, no synthetic rows, no fallback samples. If the underlying
 * tables are empty, the dashboard shows an empty state.
 *
 * Per-agent classification
 * ------------------------
 *   - tool_calls:  COUNT(*) from wpwebmcp_log WHERE agent_slug = <slug>
 *   - bot_visits:  COUNT(*) from wpwebmcp_bot_log WHERE bot_name IN
 *                  (the human labels that map back to this agent)
 *   - pages_cited: COUNT(DISTINCT post_id) from the same bot_log set
 *   - last_seen:   GREATEST(MAX(log.logged_at), MAX(bot_log.logged_at))
 *
 * Mapping bot_label -> slug
 * --------------------------
 * Bot_Analytics::KNOWN_BOTS keys are UA needles; values are human labels
 * like "GPTBot (OpenAI)" or "ClaudeBot (Anthropic)". The mapping table
 * below is hand-aligned with both KNOWN_BOTS (class-wp-webmcp-bot-analytics)
 * and the M0c registry (class-wp-webmcp-agent-identity). When a label does
 * not map to a known agent it falls into the synthetic "other" bucket so
 * unknown bots are still counted (real DB rows, not mocked).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- $log_table and $bot_table come from self::table() which uses $wpdb->prefix . 'wpwebmcp_log' (table name only, no user input)
// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- leaderboard reads real-time, cache would be stale; queries are scoped to narrow time windows
final class WP_WebMCP_Citation_Leaderboard {

	/** REST option key used to flip "include unknown bots" in the totals rollup. */
	public const OPTION_INCLUDE_UNKNOWN = 'wpwebmcp_leaderboard_include_unknown';

	/** How many recent citations to surface on the page + REST response. */
	public const RECENT_LIMIT = 20;

	/**
	 * Bot labels from wpwebmcp_bot_log -> M0c agent slug.
	 *
	 * The keys are EXACT label strings as written by Bot_Analytics. Edit
	 * with care: a typo means the row will be classified as "unknown".
	 *
	 * Includes both the current canonical labels (with parenthetical
	 * vendor) AND legacy shorter labels from earlier code versions
	 * (e.g. just "GPTBot" or "Google-Extended Gemini") so historical
	 * rows in bot_log get attributed correctly.
	 */
	private const LABEL_TO_SLUG = array(
		// OpenAI family
		'GPTBot (OpenAI)'                => 'gptbot',
		'GPTBot'                          => 'gptbot',
		'ChatGPT User (OpenAI)'          => 'chatgpt_user',
		'ChatGPT-User'                   => 'chatgpt_user',
		'SearchBot (OpenAI)'             => 'oai_searchbot',
		'OAI-SearchBot'                  => 'oai_searchbot',
		// Anthropic family
		'ClaudeBot (Anthropic)'          => 'claudebot',
		'ClaudeBot'                       => 'claudebot',
		'Claude Web (Anthropic)'         => 'claude_user',
		'Claude-Web'                      => 'claude_user',
		'anthropic-ai'                   => 'anthropic_ai',
		'Anthropic AI'                   => 'anthropic_ai',
		// Perplexity family
		'PerplexityBot'                  => 'perplexitybot',
		'Perplexity AI'                  => 'perplexity_user',
		// Google family
		'Google-Extended (Gemini)'       => 'google_extended',
		'Google-Extended Gemini'         => 'google_extended',
		'Google-Extended'                => 'google_extended',
		'Google AI / Gemini'             => 'google_extended',
		'Google Gemini Agent'            => 'google_extended',
		'Google Gemini Crawler'          => 'google_extended',
		'Gemini'                          => 'google_extended',
		'GoogleOther'                     => 'google_extended',
		'Google Vertex AI'               => 'google_extended',
		'Googlebot (Search/AI)'          => 'googlebot',
		'Googlebot'                       => 'googlebot',
		// Apple family
		'Applebot-Extended'              => 'applebot_ext',
		'Applebot'                       => 'applebot_ext',
		'Apple Intelligence'             => 'applebot_ext',
		// Cohere / Bytespider / DuckDuckGo
		'Cohere AI'                      => 'cohere_ai',
		'cohere-ai'                      => 'cohere_ai',
		'Bytespider (ByteDance)'         => 'bytespider',
		'Bytespider'                      => 'bytespider',
		'DuckDuckBot'                    => 'duckduckbot',
	);

	/**
	 * Singleton entry.
	 */
	public static function init(): void {
		// No cron; data is queried live on demand and short-cached.
	}

	/**
	 * Canonical agent slug -> human label, sourced from the M0c registry.
	 * Empty array means the registry class isn't loaded yet.
	 *
	 * @return array<string, array{slug:string,family:string,label:string,is_user:bool,ip_cidrs?:array,rdns_suffix?:string,ua_patterns?:array}>
	 */
	private static function canonical_agents(): array {
		if ( ! class_exists( 'WP_WebMCP_Agent_Identity' ) ) {
			return array();
		}
		// Pull from the REGISTRY constant via reflection: it's a private
		// const so we mirror the public accessor instead.
		$registry_method = array( 'WP_WebMCP_Agent_Identity', 'registry' );
		if ( is_callable( $registry_method ) ) {
			return call_user_func( $registry_method );
		}
		// Fallback: derive from the public ::slug_for pattern.
		return array();
	}

	/**
	 * Compute the highest confidence this agent slug is CAPABLE of reaching
	 * based on its registry definition. This is the ceiling, not the actual
	 * confidence of any specific request — a real request's confidence is
	 * computed by WP_WebMCP_Agent_Identity::resolve() against the live UA +
	 * IP + rDNS and may land anywhere up to this ceiling.
	 *
	 * Rules (matches resolve() in class-wp-webmcp-agent-identity.php:246-252):
	 *   - has both ip_cidrs AND rdns_suffix  → "high-capable"   (resolved: "high")
	 *   - has ip_cidrs OR  rdns_suffix      → "medium-capable" (resolved: "medium")
	 *   - only ua_patterns                  → "ua-only"        (resolved: "low")
	 *
	 * @param array $info Single row from the registry.
	 * @return string One of "high", "medium", "low".
	 */
	private static function max_confidence_for( array $info ): string {
		$has_ip   = ! empty( $info['ip_cidrs'] ) && is_array( $info['ip_cidrs'] );
		$has_rdns = ! empty( $info['rdns_suffix'] ) && is_string( $info['rdns_suffix'] );

		if ( $has_ip && $has_rdns ) {
			return 'high';
		}
		if ( $has_ip || $has_rdns ) {
			return 'medium';
		}
		return 'low';
	}

	/**
	 * Build the leaderboard rows. One row per canonical agent + one
	 * synthetic "other" row if there are bot_log entries that don't map
	 * to any canonical agent (real rows from DB, just unclassified).
	 *
	 * Each row carries a `confidence` field — the highest confidence this
	 * agent slug is CAPABLE of reaching given its registry definition
	 * (has IP CIDRs + rDNS suffix = "high"; one of them = "medium";
	 * only UA patterns = "low"). The synthetic "other" row is always
	 * "low" because unmapped labels can't be cryptographically verified.
	 *
	 * @return array<int,array{
	 *     slug:string,label:string,family:string,is_user:bool,
	 *     confidence:string,
	 *     tool_calls:int,bot_visits:int,pages_cited:int,last_seen:string
	 * }>
	 */
	public static function get_rows(): array {
		global $wpdb;
		$log_table    = $wpdb->prefix . 'wpwebmcp_log';
		$bot_table    = $wpdb->prefix . 'wpwebmcp_bot_log';

		// 1) Build slug -> label[] map (one slug may have multiple bot labels).
		$slug_to_labels = array();
		foreach ( self::LABEL_TO_SLUG as $label => $slug ) {
			if ( ! isset( $slug_to_labels[ $slug ] ) ) {
				$slug_to_labels[ $slug ] = array();
			}
			$slug_to_labels[ $slug ][] = $label;
		}

		$agents = self::canonical_agents();

		$rows = array();

		// 2) Per-canonical-agent aggregation.
		foreach ( $agents as $slug => $info ) {
			if ( 'unknown' === $slug ) {
				continue; // skip the fallback unknown slug — it has its own bucket.
			}
			$labels = isset( $slug_to_labels[ $slug ] ) ? $slug_to_labels[ $slug ] : array();

			// Tool calls from wpwebmcp_log.agent_slug = slug.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$tool_calls = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$log_table} WHERE agent_slug = %s",
					$slug
				)
			);

			// Bot visits + pages cited from wpwebmcp_bot_log by label set.
			$bot_visits = 0;
			$pages      = 0;
			$bot_max    = null;
			$log_max    = null;

			if ( ! empty( $labels ) ) {
				$placeholders = implode( ',', array_fill( 0, count( $labels ), '%s' ) );
				$params        = $labels;

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
				$bot_visits = (int) $wpdb->get_var(
					$wpdb->prepare(
						// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						"SELECT COUNT(*) FROM {$bot_table} WHERE bot_name IN ({$placeholders})",
						$params
					)
				);
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
				$pages = (int) $wpdb->get_var(
					$wpdb->prepare(
						// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						"SELECT COUNT(DISTINCT post_id) FROM {$bot_table} WHERE bot_name IN ({$placeholders})",
						$params
					)
				);
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
				$bot_max = $wpdb->get_var(
					$wpdb->prepare(
						// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						"SELECT MAX(logged_at) FROM {$bot_table} WHERE bot_name IN ({$placeholders})",
						$params
					)
				);
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$log_max = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT MAX(logged_at) FROM {$log_table} WHERE agent_slug = %s",
					$slug
				)
			);

			$rows[] = array(
				'slug'        => (string) $slug,
				'label'       => (string) ( $info['label'] ?? $slug ),
				'family'      => (string) ( $info['family'] ?? 'unknown' ),
				'is_user'     => (bool) ( $info['is_user'] ?? false ),
				'confidence'  => self::max_confidence_for( is_array( $info ) ? $info : array() ),
				'tool_calls'  => $tool_calls,
				'bot_visits'  => $bot_visits,
				'pages_cited' => $pages,
				'last_seen'   => self::max_dt( $log_max, $bot_max ),
			);
		}

		// 3) Synthetic "other" row for bot_log entries that don't map to a
		// canonical slug. Real DB rows, just unclassified.
		$mapped_labels = array_keys( self::LABEL_TO_SLUG );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$unmapped_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT COUNT(*) FROM {$bot_table} WHERE bot_name NOT IN (" . implode( ',', array_fill( 0, count( $mapped_labels ), '%s' ) ) . ')',
				$mapped_labels
			)
		);
		if ( $unmapped_count > 0 ) {
			$placeholders = implode( ',', array_fill( 0, count( $mapped_labels ), '%s' ) );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$unmapped_pages = (int) $wpdb->get_var(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					"SELECT COUNT(DISTINCT post_id) FROM {$bot_table} WHERE bot_name NOT IN ({$placeholders})",
					$mapped_labels
				)
			);
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$unmapped_max = $wpdb->get_var(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					"SELECT MAX(logged_at) FROM {$bot_table} WHERE bot_name NOT IN ({$placeholders})",
					$mapped_labels
				)
			);
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$unmapped_log_max = $wpdb->get_var(
				"SELECT MAX(logged_at) FROM {$log_table} WHERE agent_slug = 'unknown'"
			);
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$unmapped_log_count = (int) $wpdb->get_var(
				"SELECT COUNT(*) FROM {$log_table} WHERE agent_slug = 'unknown'"
			);

			$rows[] = array(
				'slug'        => 'other',
				'label'       => 'Other / unmapped',
				'family'      => 'unknown',
				'is_user'     => false,
				'confidence'  => 'low', // unmapped labels can't be cryptographically verified
				'tool_calls'  => $unmapped_log_count,
				'bot_visits'  => $unmapped_count,
				'pages_cited' => $unmapped_pages,
				'last_seen'   => self::max_dt( $unmapped_log_max, $unmapped_max ),
			);
		}

		// 4) Sort by bot_visits desc, then tool_calls desc, then label asc.
		usort(
			$rows,
			static function ( $a, $b ) {
				if ( $a['bot_visits'] !== $b['bot_visits'] ) {
					return $b['bot_visits'] <=> $a['bot_visits'];
				}
				if ( $a['tool_calls'] !== $b['tool_calls'] ) {
					return $b['tool_calls'] <=> $a['tool_calls'];
				}
				return strcmp( $a['label'], $b['label'] );
			}
		);

		return $rows;
	}

	/**
	 * Top-line totals for the KPI strip.
	 *
	 * @return array{total_tool_calls:int,total_bot_visits:int,distinct_agents:int,pages_cited:int,window_days:int}
	 */
	public static function get_totals( int $window_days = 30 ): array {
		global $wpdb;
		$log_table = $wpdb->prefix . 'wpwebmcp_log';
		$bot_table = $wpdb->prefix . 'wpwebmcp_bot_log';

		$since_gmt = gmdate( 'Y-m-d H:i:s', time() - ( $window_days * DAY_IN_SECONDS ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$total_tool_calls = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$log_table} WHERE logged_at >= %s",
				$since_gmt
			)
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$total_bot_visits = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$bot_table} WHERE logged_at >= %s",
				$since_gmt
			)
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$pages_cited = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT post_id) FROM {$bot_table} WHERE logged_at >= %s AND post_id > 0",
				$since_gmt
			)
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$distinct_agents = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT agent_slug) FROM {$log_table} WHERE logged_at >= %s AND agent_slug IS NOT NULL AND agent_slug <> ''",
				$since_gmt
			)
		);

		return array(
			'total_tool_calls' => $total_tool_calls,
			'total_bot_visits' => $total_bot_visits,
			'distinct_agents'  => $distinct_agents,
			'pages_cited'      => $pages_cited,
			'window_days'      => $window_days,
		);
	}

	/**
	 * Most recent bot visits with page title (resolved).
	 *
	 * @return array<int,array{ts:string,bot_name:string,slug:string,post_id:int,post_title:string,hits:int}>
	 */
	public static function get_recent_citations( int $limit = self::RECENT_LIMIT ): array {
		global $wpdb;
		$bot_table = $wpdb->prefix . 'wpwebmcp_bot_log';
		$limit     = max( 1, min( 100, $limit ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT bot_name, post_id, hits, logged_at FROM {$bot_table} ORDER BY logged_at DESC LIMIT %d",
				$limit
			),
			ARRAY_A
		);
		if ( ! is_array( $rows ) ) {
			return array();
		}

		$out = array();
		foreach ( $rows as $r ) {
			$post_id     = (int) ( $r['post_id'] ?? 0 );
			$post_title  = '';
			if ( $post_id > 0 && function_exists( 'get_the_title' ) ) {
				$post_title = (string) get_the_title( $post_id );
			}
			$label = (string) ( $r['bot_name'] ?? '' );
			$slug  = isset( self::LABEL_TO_SLUG[ $label ] ) ? self::LABEL_TO_SLUG[ $label ] : 'other';
			$out[] = array(
				'ts'          => (string) ( $r['logged_at'] ?? '' ),
				'bot_name'    => $label,
				'slug'        => $slug,
				'post_id'     => $post_id,
				'post_title'  => $post_title,
				'hits'        => (int) ( $r['hits'] ?? 1 ),
			);
		}
		return $out;
	}

	/**
	 * Return the most recent tool calls (for the "recent activity" column).
	 *
	 * @return array<int,array{ts:string,tool:string,agent_slug:string,status:string}>
	 */
	public static function get_recent_tool_calls( int $limit = 20 ): array {
		global $wpdb;
		$log_table = $wpdb->prefix . 'wpwebmcp_log';
		$limit     = max( 1, min( 100, $limit ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT tool_name, agent_slug, status, logged_at FROM {$log_table} WHERE agent_slug IS NOT NULL AND agent_slug <> '' ORDER BY logged_at DESC LIMIT %d",
				$limit
			),
			ARRAY_A
		);
		if ( ! is_array( $rows ) ) {
			return array();
		}
		$out = array();
		foreach ( $rows as $r ) {
			$out[] = array(
				'ts'          => (string) ( $r['logged_at'] ?? '' ),
				'tool'        => (string) ( $r['tool_name'] ?? '' ),
				'agent_slug'  => (string) ( $r['agent_slug'] ?? '' ),
				'status'      => (string) ( $r['status'] ?? '' ),
			);
		}
		return $out;
	}

	/**
	 * Return the max of two timestamps (mysql datetime strings).
	 * Returns '' if both are null/empty.
	 */
	private static function max_dt( $a, $b ): string {
		$a = is_string( $a ) ? trim( $a ) : '';
		$b = is_string( $b ) ? trim( $b ) : '';
		if ( '' === $a ) {
			return $b;
		}
		if ( '' === $b ) {
			return $a;
		}
		return strcmp( $a, $b ) >= 0 ? $a : $b;
	}
	// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
}