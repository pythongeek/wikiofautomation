<?php
/**
 * AI Crawler Manager (robots.txt) — Doc Part 10 (XF12).
 *
 * Appends granular allow/block rules to dynamic robots.txt output via the
 * WordPress do_robots action, giving administrators full control over
 * which AI bots and LLM scrapers can index or train on site content.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Crawler_Manager {

	/** 12 default AI bots managed out-of-the-box. */
	public const MANAGED_BOTS = array(
		'GPTBot'             => 'GPTBot (OpenAI Training)',
		'ChatGPT-User'       => 'ChatGPT-User (OpenAI Search/Browse)',
		'ClaudeBot'          => 'ClaudeBot (Anthropic Training)',
		'Claude-Web'         => 'Claude-Web (Anthropic Search/Browse)',
		'anthropic-ai'       => 'anthropic-ai (Anthropic General)',
		'PerplexityBot'      => 'PerplexityBot (Perplexity AI)',
		'Google-Extended'    => 'Google-Extended (Gemini & Vertex AI)',
		'Applebot-Extended'  => 'Applebot-Extended (Apple Intelligence)',
		'Amazonbot'          => 'Amazonbot (Amazon AI)',
		'Bytespider'         => 'Bytespider (ByteDance/TikTok AI)',
		'CCBot'              => 'CCBot (Common Crawl Data Extraction)',
		'Meta-ExternalAgent' => 'Meta-ExternalAgent (Meta AI)',
	);

	/**
	 * Initialize Crawler Manager hooks.
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'do_robots', array( __CLASS__, 'append_robots_rules' ), 100 );
	}

	/**
	 * Append AI crawler rules to robots.txt output.
	 */
	public static function append_robots_rules(): void {
		if ( ! (bool) get_option( 'wpwebmcp_crawler_manager_enabled', true ) ) {
			return;
		}

		$policies = (array) get_option( 'wpwebmcp_crawlers_policy', array() );
		$rules    = array();

		// 1. Process managed bots.
		foreach ( self::MANAGED_BOTS as $sig => $label ) {
			$policy = isset( $policies[ $sig ] ) ? (string) $policies[ $sig ] : 'default';
			if ( 'block' === $policy ) {
				$rules[] = "User-agent: {$sig}\nDisallow: /";
			} elseif ( 'allow' === $policy ) {
				$rules[] = "User-agent: {$sig}\nAllow: /";
			}
		}

		// 2. Process custom bots.
		$custom = (array) get_option( 'wpwebmcp_custom_crawlers', array() );
		foreach ( $custom as $c ) {
			$sig    = isset( $c['signature'] ) ? trim( (string) $c['signature'] ) : '';
			$policy = isset( $c['policy'] ) ? (string) $c['policy'] : 'block';
			if ( '' !== $sig ) {
				if ( 'block' === $policy ) {
					$rules[] = "User-agent: {$sig}\nDisallow: /";
				} elseif ( 'allow' === $policy ) {
					$rules[] = "User-agent: {$sig}\nAllow: /";
				}
			}
		}

		echo "\n# WebMCP Nexus AI Agent & LLM Discovery\n";
		echo "Allow: /llms.txt\n";
		echo "Allow: /llms-full.txt\n";
		echo "Allow: /.well-known/agent.json\n";
		echo "Allow: /.well-known/mcp.json\n";
		echo "Allow: /wp-json/wpwebmcp/\n\n";

		if ( ! empty( $rules ) ) {
			echo "# WebMCP Nexus AI Crawler Directives\n";
			echo esc_textarea( implode( "\n\n", $rules ) ) . "\n\n";
		}
	}
}
