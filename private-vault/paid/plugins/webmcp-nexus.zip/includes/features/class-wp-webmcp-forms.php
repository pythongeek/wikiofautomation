<?php
/**
 * Declarative WebMCP Form Annotations Engine — W3C WebMCP & Chrome Early Preview Program.
 *
 * Implements the WebMCP Declarative Form specification to ensure 100% form coverage
 * for AI agent interactions and Google PageSpeed Insights / Lighthouse audits.
 *
 * Automatically decorates WordPress forms with:
 *   - toolname="..."
 *   - tooldescription="..."
 *   - toolautosubmit (for direct search & query forms)
 *   - toolparamdescription="..." on input, textarea, and select elements
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- reading REQUEST_URI for form action URL is intentional
final class WP_WebMCP_Forms {

	/**
	 * Track whether output buffering was initiated.
	 */
	private static bool $buffer_started = false;

	/**
	 * Initialize declarative form hooks.
	 */
	public static function init(): void {
		if ( is_admin() ) {
			return;
		}

		// 1. WordPress search forms (Classic & Gutenberg block)
		WP_WebMCP_Loader::register_filter( 'get_search_form', array( __CLASS__, 'filter_search_form' ), 20, 2 );
		WP_WebMCP_Loader::register_filter( 'render_block_core/search', array( __CLASS__, 'filter_search_block' ), 20, 2 );

		// 2. WordPress comment form
		WP_WebMCP_Loader::register_filter( 'comment_form_defaults', array( __CLASS__, 'filter_comment_form_defaults' ), 20, 1 );
		WP_WebMCP_Loader::register_filter( 'comment_form_fields', array( __CLASS__, 'filter_comment_form_fields' ), 20, 1 );

		// 3. WooCommerce forms (when active)
		WP_WebMCP_Loader::register_filter( 'get_product_search_form', array( __CLASS__, 'filter_product_search_form' ), 20, 1 );
		WP_WebMCP_Loader::register_action( 'woocommerce_before_add_to_cart_form', array( __CLASS__, 'start_woo_form_buffer' ), 1 );
		WP_WebMCP_Loader::register_action( 'woocommerce_after_add_to_cart_form', array( __CLASS__, 'end_woo_form_buffer' ), 99 );

		// 4. Global page output buffer for 100% WebMCP form coverage across third-party forms
		WP_WebMCP_Loader::register_action( 'template_redirect', array( __CLASS__, 'start_page_buffer' ), 1 );
	}

	/**
	 * Start page buffer on frontend requests.
	 */
	public static function start_page_buffer(): void {
		if ( is_admin() || is_feed() || wp_is_json_request() || ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) || ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) ) {
			return;
		}

		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return;
		}

		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
		if ( false !== strpos( $uri, '/wp-json/' ) || false !== strpos( $uri, 'wp-admin' ) || false !== strpos( $uri, 'admin-ajax.php' ) ) {
			return;
		}

		if ( ! (bool) get_option( 'wpwebmcp_enabled', true ) ) {
			return;
		}

		if ( ! self::$buffer_started && ! ob_get_level() ) {
			self::$buffer_started = true;
			ob_start( array( __CLASS__, 'filter_html_forms' ) );
		}
	}

	/**
	 * Inject attribute into an HTML element before closing > or />.
	 *
	 * @param string $tag_html
	 * @param string $attr_name
	 * @param string $attr_val
	 * @return string
	 */
	private static function inject_attr( string $tag_html, string $attr_name, string $attr_val = '' ): string {
		if ( false !== strpos( $tag_html, $attr_name . '=' ) ) {
			return $tag_html;
		}
		$fragment = '' === $attr_val ? ' ' . $attr_name : ' ' . $attr_name . '="' . esc_attr( $attr_val ) . '"';
		if ( preg_match( '/\s*\/>$/i', $tag_html ) ) {
			return preg_replace( '/\s*\/>$/i', $fragment . ' />', $tag_html );
		}
		if ( preg_match( '/>$/i', $tag_html ) ) {
			return preg_replace( '/>$/i', $fragment . '>', $tag_html );
		}
		return $tag_html . $fragment;
	}

	/**
	 * Annotate search form HTML with WebMCP declarative attributes.
	 *
	 * @param string $form
	 * @param array  $args
	 * @return string
	 */
	public static function filter_search_form( string $form, $args = array() ): string {
		if ( false !== strpos( $form, 'toolname=' ) ) {
			return $form;
		}

		$tool_name = 'searchSite';
		$tool_desc = esc_attr__( 'Search site content for posts, pages, and articles', 'webmcp-nexus' );

		// Inject attributes into <form>
		$form = preg_replace_callback(
			'/<form\b(?![^>]*\btoolname=)([^>]*)>/i',
			static function ( $m ) use ( $tool_name, $tool_desc ) {
				$attrs = $m[1];
				return '<form' . $attrs . ' toolname="' . $tool_name . '" tooldescription="' . $tool_desc . '" toolautosubmit>';
			},
			$form,
			1
		);

		// Inject toolparamdescription into the search input
		$form = preg_replace_callback(
			'/<input\b([^>]*\bname=[\'"]s[\'"][^>]*)>/i',
			static function ( $m ) {
				return self::inject_attr( $m[0], 'toolparamdescription', __( 'Search query keywords', 'webmcp-nexus' ) );
			},
			$form,
			1
		);

		return $form;
	}

	/**
	 * Annotate Gutenberg core/search block.
	 *
	 * @param string $block_content
	 * @param array  $block
	 * @return string
	 */
	public static function filter_search_block( string $block_content, array $block = array() ): string {
		return self::filter_search_form( $block_content );
	}

	/**
	 * Annotate WooCommerce product search form.
	 *
	 * @param string $form
	 * @return string
	 */
	public static function filter_product_search_form( string $form ): string {
		if ( false !== strpos( $form, 'toolname=' ) ) {
			return $form;
		}

		$tool_name = 'searchProducts';
		$tool_desc = esc_attr__( 'Search store catalog for products, categories, and inventory', 'webmcp-nexus' );

		$form = preg_replace_callback(
			'/<form\b(?![^>]*\btoolname=)([^>]*)>/i',
			static function ( $m ) use ( $tool_name, $tool_desc ) {
				$attrs = $m[1];
				return '<form' . $attrs . ' toolname="' . $tool_name . '" tooldescription="' . $tool_desc . '" toolautosubmit>';
			},
			$form,
			1
		);

		$form = preg_replace_callback(
			'/<input\b([^>]*\bname=[\'"]s[\'"][^>]*)>/i',
			static function ( $m ) {
				return self::inject_attr( $m[0], 'toolparamdescription', __( 'Product search keywords or SKU', 'webmcp-nexus' ) );
			},
			$form,
			1
		);

		return $form;
	}

	/**
	 * Annotate comment form defaults.
	 *
	 * @param array $defaults
	 * @return array
	 */
	public static function filter_comment_form_defaults( array $defaults ): array {
		if ( isset( $defaults['comment_field'] ) ) {
			$defaults['comment_field'] = preg_replace_callback(
				'/<textarea\b(?![^>]*\btoolparamdescription=)([^>]*)>/i',
				static function ( $m ) {
					return self::inject_attr( $m[0], 'toolparamdescription', __( 'Comment text or feedback', 'webmcp-nexus' ) );
				},
				$defaults['comment_field']
			);
		}

		return $defaults;
	}

	/**
	 * Annotate comment form input fields (author, email, url).
	 *
	 * @param array $fields
	 * @return array
	 */
	public static function filter_comment_form_fields( array $fields ): array {
		if ( isset( $fields['author'] ) ) {
			$fields['author'] = preg_replace_callback(
				'/<input\b(?![^>]*\btoolparamdescription=)([^>]*)>/i',
				static function ( $m ) {
					return self::inject_attr( $m[0], 'toolparamdescription', __( 'Author full name or display name', 'webmcp-nexus' ) );
				},
				$fields['author']
			);
		}
		if ( isset( $fields['email'] ) ) {
			$fields['email'] = preg_replace_callback(
				'/<input\b(?![^>]*\btoolparamdescription=)([^>]*)>/i',
				static function ( $m ) {
					return self::inject_attr( $m[0], 'toolparamdescription', __( 'Author email address for notifications', 'webmcp-nexus' ) );
				},
				$fields['email']
			);
		}
		if ( isset( $fields['url'] ) ) {
			$fields['url'] = preg_replace_callback(
				'/<input\b(?![^>]*\btoolparamdescription=)([^>]*)>/i',
				static function ( $m ) {
					return self::inject_attr( $m[0], 'toolparamdescription', __( 'Author website or profile URL', 'webmcp-nexus' ) );
				},
				$fields['url']
			);
		}
		return $fields;
	}

	/**
	 * Buffer single WooCommerce add to cart form.
	 */
	public static function start_woo_form_buffer(): void {
		ob_start();
	}

	/**
	 * End and annotate single WooCommerce add to cart form.
	 */
	public static function end_woo_form_buffer(): void {
		$form = ob_get_clean();
		if ( empty( $form ) ) {
			return;
		}

		if ( false === strpos( $form, 'toolname=' ) ) {
			$tool_name = 'addToCart';
			$tool_desc = esc_attr__( 'Add this product to the shopping cart with specified quantity and options', 'webmcp-nexus' );

			$form = preg_replace_callback(
				'/<form\b(?![^>]*\btoolname=)([^>]*)>/i',
				static function ( $m ) use ( $tool_name, $tool_desc ) {
					return '<form' . $m[1] . ' toolname="' . $tool_name . '" tooldescription="' . $tool_desc . '">';
				},
				$form,
				1
			);

			$form = preg_replace_callback(
				'/<input\b([^>]*\bname=[\'"]quantity[\'"][^>]*)>/i',
				static function ( $m ) {
					return self::inject_attr( $m[0], 'toolparamdescription', __( 'Quantity of product to purchase', 'webmcp-nexus' ) );
				},
				$form,
				1
			);
		}

		echo $form; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * HTML filter callback for full-page buffer.
	 * Scans for any remaining unannotated forms and decorates them with valid WebMCP attributes.
	 *
	 * @param string $html Full page HTML.
	 * @return string Enriched HTML with WebMCP form coverage.
	 */
	public static function filter_html_forms( string $html ): string {
		if ( empty( $html ) || false === stripos( $html, '<form' ) ) {
			return $html;
		}

		// Process all <form ...>...</form> blocks
		$pattern = '/(<form\b(?![^>]*\btoolname=)([^>]*)>)(.*?)(<\/form>)/is';

		return preg_replace_callback(
			$pattern,
			static function ( $matches ) {
				$form_attrs     = $matches[2];
				$form_body      = $matches[3];
				$form_tag_close = $matches[4];

				// Determine toolname and description
				$tool_name   = 'submitForm';
				$tool_desc   = 'Submit form';
				$auto_submit = false;

				if ( preg_match( '/\b(search|s)\b/i', $form_attrs ) || preg_match( '/<input[^>]*\bname=[\'"]s[\'"]/i', $form_body ) ) {
					$tool_name   = 'searchSite';
					$tool_desc   = 'Search site content';
					$auto_submit = true;
				} elseif ( preg_match( '/\bcomment\b/i', $form_attrs ) || preg_match( '/<textarea[^>]*\bname=[\'"]comment[\'"]/i', $form_body ) ) {
					$tool_name = 'postComment';
					$tool_desc = 'Post comment on article';
				} elseif ( preg_match( '/\b(login|user_login|log)\b/i', $form_body ) ) {
					$tool_name = 'loginUser';
					$tool_desc = 'User authentication login';
				} elseif ( preg_match( '/\b(subscribe|newsletter|email-signup)\b/i', $form_attrs . ' ' . $form_body ) ) {
					$tool_name = 'subscribeNewsletter';
					$tool_desc = 'Subscribe to newsletter';
				} elseif ( preg_match( '/\b(cart|add-to-cart)\b/i', $form_attrs . ' ' . $form_body ) ) {
					$tool_name = 'addToCart';
					$tool_desc = 'Add product to shopping cart';
				} elseif ( preg_match( '/\bid=[\'"]([a-zA-Z0-9_-]+)[\'"]/i', $form_attrs, $id_match ) ) {
					$clean_id  = sanitize_key( str_replace( array( '-', '_' ), ' ', $id_match[1] ) );
					$tool_name = lcfirst( str_replace( ' ', '', ucwords( $clean_id ) ) );
					$tool_desc = sprintf( 'Submit %s form', esc_html( $clean_id ) );
				}

				$new_form_tag = '<form' . $form_attrs . ' toolname="' . esc_attr( $tool_name ) . '" tooldescription="' . esc_attr( $tool_desc ) . '"' . ( $auto_submit ? ' toolautosubmit' : '' ) . '>';

				// Annotate inputs inside form_body if they lack toolparamdescription
				$form_body = preg_replace_callback(
					'/<(input|textarea|select)\b(?![^>]*\btoolparamdescription=)([^>]*)(\/?)>/i',
					static function ( $input_matches ) {
						$tag         = $input_matches[1];
						$attrs       = $input_matches[2];
						$self_closing = $input_matches[3];

						$type = 'text';
						if ( preg_match( '/\btype=[\'"]([^\'"]+)[\'"]/i', $attrs, $tm ) ) {
							$type = strtolower( $tm[1] );
						}

						// Skip hidden, submit, button, reset
						if ( in_array( $type, array( 'hidden', 'submit', 'button', 'reset', 'image' ), true ) ) {
							return '<' . $tag . $attrs . ( $self_closing ? ' /' : '' ) . '>';
						}

						$name = '';
						if ( preg_match( '/\bname=[\'"]([^\'"]+)[\'"]/i', $attrs, $nm ) ) {
							$name = $nm[1];
						}

						$param_desc = ! empty( $name ) ? sprintf( 'Input parameter for %s', esc_attr( $name ) ) : 'Form input value';

						return '<' . $tag . $attrs . ' toolparamdescription="' . esc_attr( $param_desc ) . '"' . ( $self_closing ? ' /' : '' ) . '>';
					},
					$form_body
				);

				return $new_form_tag . $form_body . $form_tag_close;
			},
			$html
		);
	}
	// phpcs:enable WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
}