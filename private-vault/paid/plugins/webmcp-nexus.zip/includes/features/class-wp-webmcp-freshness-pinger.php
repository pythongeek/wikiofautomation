<?php
/**
 * Freshness_Pinger — Module A A1c: Freshness ping protocol.
 *
 * Sends IndexNow-style pings whenever a piece of content changes
 * (publish / update / delete) so search engines and AI agents don't
 * cite stale versions. Backed by a per-site queue flushed every 5
 * minutes via WP-Cron. Also fires an internal SSE event so any
 * agent already holding a long-lived stream gets notified in near
 * real time.
 *
 * Architecture:
 *   - Storage:
 *       wpwebmcp_freshness_queue (option, autoload=no)  — pending URLs
 *       wpwebmcp_freshness_log   (option, autoload=no)  — last 50 pings
 *       wpwebmcp_freshness_stats (option, autoload=no)  — counters
 *   - Hooks:
 *       wp_after_insert_post        (publish + update)   -> enqueue
 *       before_delete_post          (delete)             -> enqueue
 *       wpwebmcp_flush_freshness_queue (cron, 5 min)     -> submit batch
 *       wpwebmcp_freshness_event    (custom action)      -> SSE emit
 *   - IndexNow payload (per IndexNow spec):
 *       POST {host}/indexnow
 *         { host, key, keyLocation, urlList: [...] }
 *       We default to https://api.indexnow.org/indexnow (which fans out
 *       to Bing, Yandex, Seznam, Naver). Admins can override the endpoint.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- self::ACTION_EVENT is the plugin's own dynamic hook, fired via do_action( self::ACTION_EVENT, ... )
final class WP_WebMCP_Freshness_Pinger {

	/** Option keys — defined as constants so they stay consistent with the activator list. */
	public const OPTION_ENABLED  = 'wpwebmcp_freshness_enabled';
	public const OPTION_KEY      = 'wpwebmcp_indexnow_key';
	public const OPTION_ENDPOINT = 'wpwebmcp_indexnow_endpoint';
	public const OPTION_LOG      = 'wpwebmcp_freshness_log';
	public const OPTION_QUEUE    = 'wpwebmcp_freshness_queue';
	public const OPTION_STATS    = 'wpwebmcp_freshness_stats';

	/** Internal action name — fired after every successful enqueue / submit. */
	public const ACTION_EVENT = 'wpwebmcp_freshness_event';

	/** Cron hooks. */
	public const CRON_FLUSH   = 'wpwebmcp_flush_freshness_queue';
	public const CRON_PRUNE   = 'wpwebmcp_freshness_prune_log';

	/** Log retention — keep last 50 pings forever. */
	private const LOG_LIMIT = 50;

	/** Queue retention — flush anything older than 24h as a safety net. */
	private const QUEUE_MAX_AGE_SECONDS = 86400;

	/** Daily IndexNow soft cap (Bing allows up to 10k/day; we stay well below). */
	private const INDEXNOW_DAILY_CAP = 8000;

	/**
	 * Singleton entry — wired from WP_WebMCP::define_api_hooks().
	 */
	public static function init(): void {
		// Hook content transitions. wp_after_insert_post fires on every
		// insert + update (status transitions + meta writes). We filter
		// by post_type + post_status inside on_post_change().
		WP_WebMCP_Loader::register_action( 'wp_after_insert_post', array( __CLASS__, 'on_post_change' ), 10, 4 );
		WP_WebMCP_Loader::register_action( 'before_delete_post',  array( __CLASS__, 'on_post_delete' ), 10, 2 );

		// Cron: flush queue + prune log.
		WP_WebMCP_Loader::register_action( self::CRON_FLUSH, array( __CLASS__, 'flush_queue' ) );
		WP_WebMCP_Loader::register_action( self::CRON_PRUNE, array( __CLASS__, 'prune_log' ) );

		if ( function_exists( 'wp_schedule_event' ) ) {
			if ( ! wp_next_scheduled( self::CRON_FLUSH ) ) {
				wp_schedule_event( time() + 60, 'wpwebmcp_five_minutes', self::CRON_FLUSH );
			}
			if ( ! wp_next_scheduled( self::CRON_PRUNE ) ) {
				wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON_PRUNE );
			}
		}
	}

	/**
	 * Register the custom 5-minute cron schedule (Doc Part 4 §4.7
	 * mentions wpwebmcp_cron, this slots in alongside it).
	 */
	public static function register_schedule( $schedules ) {
		if ( ! is_array( $schedules ) ) {
			return $schedules;
		}
		if ( ! isset( $schedules['wpwebmcp_five_minutes'] ) ) {
			$schedules['wpwebmcp_five_minutes'] = array(
				'interval' => 300,
				'display'  => __( 'Every 5 Minutes (WebMCP Freshness)', 'webmcp-nexus' ),
			);
		}
		return $schedules;
	}

	/* ============================================================
	 * Public read API (used by REST + admin + SSE)
	 * ============================================================ */

	public static function is_enabled(): bool {
		return (bool) get_option( self::OPTION_ENABLED, false );
	}

	public static function get_key(): string {
		return (string) get_option( self::OPTION_KEY, '' );
	}

	public static function get_endpoint(): string {
		$ep = (string) get_option( self::OPTION_ENDPOINT, '' );
		return '' !== $ep ? $ep : 'https://api.indexnow.org/indexnow';
	}

	public static function get_queue_count(): int {
		$q = get_option( self::OPTION_QUEUE, array() );
		return is_array( $q ) ? count( $q ) : 0;
	}

	public static function get_log( int $limit = 25 ): array {
		$log = get_option( self::OPTION_LOG, array() );
		if ( ! is_array( $log ) ) {
			return array();
		}
		if ( $limit > 0 && count( $log ) > $limit ) {
			$log = array_slice( $log, 0, $limit );
		}
		return $log;
	}

	public static function get_stats(): array {
		$defaults = array(
			'total_submitted'    => 0,
			'submitted_today'    => 0,
			'submitted_day_date' => '',
			'last_submitted_at'  => '',
			'last_submitted_url' => '',
			'last_error_at'      => '',
			'last_error_message' => '',
			'last_queue_flush'   => '',
		);
		$saved = get_option( self::OPTION_STATS, array() );
		return is_array( $saved ) ? array_merge( $defaults, $saved ) : $defaults;
	}

	/* ============================================================
	 * Content-change hooks
	 * ============================================================ */

	/**
	 * Fires on wp_after_insert_post for every insert + update.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @param bool    $update  Whether this is an update.
	 * @param WP_Post $post_before Previous post object (null on insert).
	 */
	public static function on_post_change( $post_id, $post, $update, $post_before ): void {
		if ( ! self::is_enabled() ) {
			return;
		}
		if ( ! $post instanceof WP_Post ) {
			return;
		}
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}
		// Only publish / future / private trigger IndexNow; drafts are noise.
		if ( ! in_array( $post->post_status, array( 'publish', 'future', 'private' ), true ) ) {
			return;
		}
		// Only public post types (configurable).
		$allowed_types = apply_filters( 'wpwebmcp_freshness_post_types', array( 'post', 'page' ) );
		if ( ! in_array( $post->post_type, (array) $allowed_types, true ) ) {
			return;
		}
		$url = get_permalink( $post_id );
		if ( ! is_string( $url ) || '' === $url ) {
			return;
		}
		$action = $update ? 'update' : 'publish';
		self::enqueue( $url, $post_id, $action );
	}

	/**
	 * Fires on before_delete_post.
	 *
	 * @param int     $post_id Post ID being deleted.
	 * @param WP_Post $post    Post object.
	 */
	public static function on_post_delete( $post_id, $post ): void {
		if ( ! self::is_enabled() ) {
			return;
		}
		if ( ! $post instanceof WP_Post ) {
			return;
		}
		$allowed_types = apply_filters( 'wpwebmcp_freshness_post_types', array( 'post', 'page' ) );
		if ( ! in_array( $post->post_type, (array) $allowed_types, true ) ) {
			return;
		}
		// Prefer the post's last known URL — at delete time the permalink
		// may have already been cleared by WP, so we build from post_name.
		$url = self::build_url_for_deleted_post( $post );
		if ( '' === $url ) {
			return;
		}
		self::enqueue( $url, $post_id, 'delete' );
	}

	/**
	 * Manual enqueue (exposed via REST for the admin "Ping now" button).
	 */
	public static function enqueue( string $url, int $post_id = 0, string $action = 'manual' ): bool {
		$url = esc_url_raw( $url );
		if ( '' === $url ) {
			return false;
		}
		$queue   = get_option( self::OPTION_QUEUE, array() );
		if ( ! is_array( $queue ) ) {
			$queue = array();
		}
		// Dedup on URL — keep earliest action + ts.
		$now = time();
		$found = false;
		foreach ( $queue as &$row ) {
			if ( isset( $row['url'] ) && $row['url'] === $url ) {
				$row['ts']    = $now;
				$row['count'] = (int) ( $row['count'] ?? 1 ) + 1;
				$row['action'] = $action;
				$row['post_id'] = $post_id;
				$found = true;
				break;
			}
		}
		unset( $row );
		if ( ! $found ) {
			$queue[] = array(
				'url'     => $url,
				'post_id' => (int) $post_id,
				'action'  => $action,
				'ts'      => $now,
				'count'   => 1,
			);
		}
		// Hard cap on queue size (defensive).
		if ( count( $queue ) > 500 ) {
			$queue = array_slice( $queue, -500 );
		}
		update_option( self::OPTION_QUEUE, $queue, false );

		// Fire SSE event so live subscribers see the enqueue.
		do_action(
			self::ACTION_EVENT,
			array(
				'type'        => 'content_updated',
				'url'         => $url,
				'post_id'     => (int) $post_id,
				'action'      => $action,
				'queued_at'   => $now,
				'queued_at_gmt' => gmdate( 'c', $now ),
			)
		);
		return true;
	}

	/* ============================================================
	 * Cron: flush queue + prune log
	 * ============================================================ */

	/**
	 * Flushes the queue via IndexNow. Triggered every 5 minutes by cron
	 * OR can be invoked synchronously by an admin "Ping now" button.
	 *
	 * @param bool $force When true, ignores the daily cap (admin override).
	 * @return array{ok:bool, submitted:int, urls:array, error:string}
	 */
	public static function flush_queue( bool $force = false ): array {
		$key      = self::get_key();
		$endpoint = self::get_endpoint();
		$host     = wp_parse_url( home_url(), PHP_URL_HOST );

		$result = array(
			'ok'        => false,
			'submitted' => 0,
			'urls'      => array(),
			'error'     => '',
		);

		if ( '' === $key ) {
			$result['error'] = 'indexnow_key_missing';
			return $result;
		}

		$queue = get_option( self::OPTION_QUEUE, array() );
		if ( ! is_array( $queue ) || empty( $queue ) ) {
			$result['ok'] = true;
			$result['error'] = 'empty_queue';
			// Still record a flush event for observability.
			$stats = self::get_stats();
			$stats['last_queue_flush'] = gmdate( 'c' );
			update_option( self::OPTION_STATS, $stats, false );
			return $result;
		}

		// Respect daily cap unless forced.
		$stats = self::get_stats();
		$today = gmdate( 'Y-m-d' );
		if ( ! $force && (string) $stats['submitted_day_date'] === $today && (int) $stats['submitted_today'] >= self::INDEXNOW_DAILY_CAP ) {
			$result['error'] = 'daily_cap_reached';
			return $result;
		}

		// Strip stale entries (> 24h) defensively.
		$cutoff = time() - self::QUEUE_MAX_AGE_SECONDS;
		$fresh  = array_values(
			array_filter(
				$queue,
				static function ( $row ) use ( $cutoff ) {
					return isset( $row['ts'] ) && (int) $row['ts'] >= $cutoff;
				}
			)
		);

		if ( empty( $fresh ) ) {
			update_option( self::OPTION_QUEUE, array(), false );
			$result['ok'] = true;
			$result['error'] = 'all_stale';
			return $result;
		}

		// Cap batch size to 10000 (IndexNow's per-call limit).
		$batch = array_slice( $fresh, 0, 10000 );
		$urls  = array_values(
			array_map(
				static function ( $row ) {
					return (string) ( $row['url'] ?? '' );
				},
				$batch
			)
		);
		$urls = array_values( array_filter( $urls, static function ( $u ) { return '' !== $u; } ) );
		if ( empty( $urls ) ) {
			update_option( self::OPTION_QUEUE, array(), false );
			$result['ok'] = true;
			$result['error'] = 'no_valid_urls';
			return $result;
		}

		$payload = array(
			'host'        => (string) $host,
			'key'         => $key,
			'keyLocation' => trailingslashit( home_url() ) . $key . '.txt',
			'urlList'     => $urls,
		);

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout' => 15,
				'headers' => array( 'Content-Type' => 'application/json; charset=utf-8' ),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			$result['error'] = 'http_error: ' . $response->get_error_message();
			self::record_log( 'error', $result['error'], $urls, $stats );
			$stats['last_error_at']      = gmdate( 'c' );
			$stats['last_error_message'] = $result['error'];
			update_option( self::OPTION_STATS, $stats, false );
			return $result;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		// IndexNow: 200 = OK, 202 = accepted (will process), 4xx = key/format error.
		if ( $code >= 200 && $code < 300 ) {
			$result['ok']        = true;
			$result['submitted'] = count( $urls );
			$result['urls']      = $urls;

			// Remove submitted URLs from queue.
			$remaining = array_values(
				array_filter(
					$fresh,
					static function ( $row ) use ( $urls ) {
						return ! in_array( (string) ( $row['url'] ?? '' ), $urls, true );
					}
				)
			);
			update_option( self::OPTION_QUEUE, $remaining, false );

			// Update stats.
			if ( (string) $stats['submitted_day_date'] !== $today ) {
				$stats['submitted_today']    = 0;
				$stats['submitted_day_date'] = $today;
			}
			$stats['total_submitted']   += count( $urls );
			$stats['submitted_today']   += count( $urls );
			$stats['last_submitted_at']  = gmdate( 'c' );
			$stats['last_submitted_url'] = (string) reset( $urls );
			$stats['last_queue_flush']   = gmdate( 'c' );
			update_option( self::OPTION_STATS, $stats, false );

			self::record_log( 'success', sprintf( 'submitted %d URLs (HTTP %d)', count( $urls ), $code ), $urls, $stats );
			do_action(
				self::ACTION_EVENT,
				array(
					'type'       => 'freshness_submitted',
					'count'      => count( $urls ),
					'status'     => $code,
					'endpoint'   => $endpoint,
					'submitted_at_gmt' => gmdate( 'c' ),
				)
			);
		} else {
			$body = (string) wp_remote_retrieve_body( $response );
			$result['error'] = 'http_' . $code . ': ' . substr( $body, 0, 200 );
			self::record_log( 'error', $result['error'], $urls, $stats );
			$stats['last_error_at']      = gmdate( 'c' );
			$stats['last_error_message'] = $result['error'];
			update_option( self::OPTION_STATS, $stats, false );
		}

		return $result;
	}

	public static function prune_log(): void {
		$log = get_option( self::OPTION_LOG, array() );
		if ( ! is_array( $log ) ) {
			return;
		}
		if ( count( $log ) > self::LOG_LIMIT ) {
			$log = array_slice( $log, 0, self::LOG_LIMIT );
			update_option( self::OPTION_LOG, $log, false );
		}
	}

	/* ============================================================
	 * Helpers
	 * ============================================================ */

	private static function record_log( string $status, string $message, array $urls, array $stats ): void {
		$log   = get_option( self::OPTION_LOG, array() );
		if ( ! is_array( $log ) ) {
			$log = array();
		}
		array_unshift(
			$log,
			array(
				'ts'        => gmdate( 'c' ),
				'status'    => $status,
				'message'   => $message,
				'count'     => count( $urls ),
				'urls'      => array_slice( $urls, 0, 5 ), // store first 5 to keep option small
				'today_total' => (int) ( $stats['submitted_today'] ?? 0 ),
			)
		);
		if ( count( $log ) > self::LOG_LIMIT ) {
			$log = array_slice( $log, 0, self::LOG_LIMIT );
		}
		update_option( self::OPTION_LOG, $log, false );
	}

	private static function build_url_for_deleted_post( WP_Post $post ): string {
		// Try permalink first; if cleared, build from post_name + post_type.
		$url = get_permalink( $post->ID );
		if ( is_string( $url ) && '' !== $url ) {
			return $url;
		}
		if ( '' === (string) $post->post_name ) {
			return '';
		}
		$home = trailingslashit( home_url() );
		if ( 'page' === $post->post_type ) {
			return $home . (string) $post->post_name . '/';
		}
		return $home . '?p=' . (int) $post->ID;
	}
// phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound
}
