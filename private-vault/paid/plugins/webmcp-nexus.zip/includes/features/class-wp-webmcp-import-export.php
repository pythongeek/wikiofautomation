<?php
/**
 * Configuration Import, Export & Snapshot Backups — Doc §4.8 + §7.6.
 *
 * Implements:
 *   - JSON snapshot export stream (admin-post.php?action=wpwebmcp_export)
 *   - REST settings import (POST /wpwebmcp/v1/settings/import) with pre-import backup
 *   - Backup snapshot restore (admin-post.php?action=wpwebmcp_restore_backup)
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- $table from self::table() is hardcoded $wpdb->prefix . 'wpwebmcp_tools' literal
final class WP_WebMCP_Import_Export {

	/** Capability required. */
	private const CAPABILITY = 'manage_options';

	/** Max backup snapshots to retain in wp_options. */
	private const MAX_BACKUPS = 5;

	/**
	 * Initialize Import / Export handlers.
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'admin_post_wpwebmcp_export',         array( __CLASS__, 'stream_export' ) );
		WP_WebMCP_Loader::register_action( 'admin_post_wpwebmcp_restore_backup', array( __CLASS__, 'restore_backup' ) );
		WP_WebMCP_Loader::register_action( 'rest_api_init',                      array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Register REST routes for import.
	 */
	public static function register_routes(): void {
		register_rest_route(
			'wpwebmcp/v1',
			'/settings/import',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'rest_import' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			)
		);
	}

	/**
	 * Permission check.
	 */
	public static function check_admin(): bool {
		return current_user_can( self::CAPABILITY );
	}

	/**
	 * Build export payload containing all options and custom tools.
	 *
	 * @return array<string,mixed>
	 */
	public static function build_export_payload(): array {
		$options = array();
		if ( class_exists( 'WP_WebMCP_Activator' ) ) {
			foreach ( array_keys( WP_WebMCP_Activator::DEFAULT_OPTIONS ) as $opt_key ) {
				$options[ $opt_key ] = get_option( $opt_key );
			}
		}

		global $wpdb;
		$tools_table = $wpdb->prefix . 'wpwebmcp_tools';
		$tools = $wpdb->get_results( "SELECT * FROM {$tools_table} ORDER BY id ASC", ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		return array(
			'generator'    => 'WebMCP Nexus',
			'version'      => defined( 'WEBMCP_NEXUS_VERSION' ) ? WEBMCP_NEXUS_VERSION : '1.0.0',
			'exported_at'  => current_time( 'mysql', true ),
			'site_url'     => home_url(),
			'options'      => $options,
			'custom_tools' => is_array( $tools ) ? $tools : array(),
		);
	}

	/**
	 * Handle file download export.
	 */
	public static function stream_export(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'webmcp-nexus' ) );
		}

		check_admin_referer( 'wpwebmcp_export_action', 'wpwebmcp_export_nonce' );

		$payload  = self::build_export_payload();
		$json     = wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		$filename = sprintf( 'webmcp-export-%s-%s.json', sanitize_title( get_bloginfo( 'name' ) ), gmdate( 'Ymd-His' ) );

		header( 'Content-Type: application/json; charset=utf-8' );
		header( "Content-Disposition: attachment; filename={$filename}" );
		header( 'Cache-Control: no-cache, no-store, must-revalidate' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );

		echo $json; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	/**
	 * REST handler for POST /wpwebmcp/v1/settings/import.
	 */
	public static function rest_import( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		if ( ! is_array( $body ) || empty( $body['options'] ) ) {
			return new WP_Error( 'wpwebmcp_invalid_import', __( 'Invalid or empty export file.', 'webmcp-nexus' ), array( 'status' => 400 ) );
		}

		// 1. Create automatic pre-import backup.
		self::create_backup( __( 'Pre-import automatic snapshot', 'webmcp-nexus' ) );

		// 2. Restore options.
		$imported_options = $body['options'];
		if ( class_exists( 'WP_WebMCP_Activator' ) ) {
			foreach ( WP_WebMCP_Activator::DEFAULT_OPTIONS as $opt_key => $default_val ) {
				if ( array_key_exists( $opt_key, $imported_options ) ) {
					update_option( $opt_key, $imported_options[ $opt_key ] );
				}
			}
		}

		// 3. Restore custom tools.
		$custom_tools = $body['custom_tools'] ?? array();
		if ( is_array( $custom_tools ) && class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			foreach ( $custom_tools as $tool_row ) {
				if ( ! empty( $tool_row['tool_name'] ) ) {
					WP_WebMCP_Tool_Repository::upsert_by_slug( $tool_row );
				}
			}
		}

		wp_cache_flush();
		delete_transient( 'wpwebmcp_health_score' );

		return rest_ensure_response(
			array(
				'ok'     => true,
				'detail' => __( 'Configuration imported successfully.', 'webmcp-nexus' ),
			)
		);
	}

	/**
	 * Create a backup snapshot in wp_options.
	 */
	public static function create_backup( string $label = '' ): string {
		$snapshot_key = 'wpwebmcp_backup_' . gmdate( 'Ymd_His' );
		$payload = self::build_export_payload();
		$payload['backup_label'] = $label ?: __( 'Manual snapshot', 'webmcp-nexus' );

		update_option( $snapshot_key, $payload, false );
		self::rotate_backups();

		return $snapshot_key;
	}

	/**
	 * Rotate backups to maintain at most MAX_BACKUPS.
	 */
	private static function rotate_backups(): void {
		global $wpdb;
		$table = $wpdb->options;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results(
			"SELECT option_name FROM {$table} WHERE option_name LIKE 'wpwebmcp_backup_%' ORDER BY option_name DESC",
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery

		if ( is_array( $rows ) && count( $rows ) > self::MAX_BACKUPS ) {
			$to_delete = array_slice( $rows, self::MAX_BACKUPS );
			foreach ( $to_delete as $row ) {
				delete_option( $row['option_name'] );
			}
		}
	}

	/**
	 * List all stored backup snapshots.
	 *
	 * @return array<int, array{key: string, label: string, created_at: string}>
	 */
	public static function list_backups(): array {
		global $wpdb;
		$table = $wpdb->options;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results(
			"SELECT option_name, option_value FROM {$table} WHERE option_name LIKE 'wpwebmcp_backup_%' ORDER BY option_name DESC",
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery

		$list = array();
		if ( is_array( $rows ) ) {
			foreach ( $rows as $row ) {
				$val = maybe_unserialize( $row['option_value'] );
				$list[] = array(
					'key'        => $row['option_name'],
					'label'      => is_array( $val ) && ! empty( $val['backup_label'] ) ? (string) $val['backup_label'] : __( 'Snapshot', 'webmcp-nexus' ),
					'created_at' => is_array( $val ) && ! empty( $val['exported_at'] ) ? (string) $val['exported_at'] : '',
				);
			}
		}

		return $list;
	}

	/**
	 * Restore a backup snapshot.
	 */
	public static function restore_backup(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'webmcp-nexus' ) );
		}

		check_admin_referer( 'wpwebmcp_restore_backup_action', 'wpwebmcp_restore_nonce' );

		$key = isset( $_POST['backup_key'] ) ? sanitize_key( (string) $_POST['backup_key'] ) : '';
		$backup = get_option( $key );

		if ( is_array( $backup ) && ! empty( $backup['options'] ) ) {
			foreach ( $backup['options'] as $opt_key => $opt_val ) {
				update_option( $opt_key, $opt_val );
			}
			if ( ! empty( $backup['custom_tools'] ) && is_array( $backup['custom_tools'] ) ) {
				foreach ( $backup['custom_tools'] as $tool_row ) {
					if ( ! empty( $tool_row['tool_name'] ) ) {
						WP_WebMCP_Tool_Repository::upsert_by_slug( $tool_row );
					}
				}
			}
			wp_cache_flush();
			delete_transient( 'wpwebmcp_health_score' );
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'     => 'wp-webmcp-import-export',
					'restored' => '1',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
	// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}