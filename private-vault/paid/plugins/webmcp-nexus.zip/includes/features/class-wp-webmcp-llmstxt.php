<?php
/**
 * llms.txt & llms-full.txt Content Generator — Doc Part 10 (XF01).
 *
 * Serves /llms.txt and /llms-full.txt standardized plain-text discovery files
 * for LLMs and AI agents per the /llms.txt specification.
 *
 * Enriched with clean Markdown priority URLs, active vertical tool suites,
 * and Model Context Protocol server endpoints.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- reading REQUEST_URI for content routing is intentional
final class WP_WebMCP_LlmsTxt {

	/**
	 * Initialize llms.txt router.
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'init', array( __CLASS__, 'add_rewrite_rules' ) );
		WP_WebMCP_Loader::register_filter( 'query_vars', array( __CLASS__, 'add_query_vars' ) );
		WP_WebMCP_Loader::register_action( 'template_redirect', array( __CLASS__, 'serve' ), 1 );
	}

	/**
	 * Register URL rewrite rules for /llms.txt and /llms-full.txt.
	 */
	public static function add_rewrite_rules(): void {
		add_rewrite_rule( '^llms\.txt$', 'index.php?wpwebmcp_llmstxt=summary', 'top' );
		add_rewrite_rule( '^llms-full\.txt$', 'index.php?wpwebmcp_llmstxt=full', 'top' );
	}

	/**
	 * Register custom query var.
	 *
	 * @param array $vars
	 * @return array
	 */
	public static function add_query_vars( array $vars ): array {
		$vars[] = 'wpwebmcp_llmstxt';
		return $vars;
	}

	/**
	 * Serve llms.txt or llms-full.txt if requested.
	 */
	public static function serve(): void {
		$qv = get_query_var( 'wpwebmcp_llmstxt' );
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$path = trim( (string) wp_parse_url( $uri, PHP_URL_PATH ), '/' );

		$is_llms = ( 'summary' === $qv || 'llms.txt' === $path || preg_match( '/(^|\/)llms\.txt$/i', $path ) );
		$is_full = ( 'full' === $qv || 'llms-full.txt' === $path || preg_match( '/(^|\/)llms-full\.txt$/i', $path ) );

		if ( ! $is_llms && ! $is_full ) {
			return;
		}

		$mode = (string) get_option( 'wpwebmcp_llmstxt_mode', 'auto' );
		if ( 'off' === $mode ) {
			return;
		}

		$type = $is_full ? 'full' : 'summary';

		if ( 'custom' === $mode ) {
			$content = (string) get_option( 'wpwebmcp_llmstxt_custom', '' );
		} else {
			$content = self::generate_content( $is_full );
		}

		/**
		 * Filter llms.txt output content before sending.
		 *
		 * @param string $content
		 * @param string $type ('summary' or 'full')
		 */
		$content = apply_filters( 'wpwebmcp_llmstxt_content', $content, $type );

		if ( ! headers_sent() ) {
			status_header( 200 );
			header( 'Content-Type: text/plain; charset=utf-8' );
			header( 'X-Robots-Tag: all, follow' );
			header( 'X-WebMCP-Priority: high' );
			header( 'Access-Control-Allow-Origin: *' );
			header( 'Cache-Control: public, max-age=3600' );
		}

		echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	/**
	 * Generate auto-mode markdown content for llms.txt.
	 *
	 * @param bool $full Whether to include full descriptions.
	 * @return string
	 */
	public static function generate_content( bool $full = false ): string {
		$site_title = (string) get_bloginfo( 'name' );
		if ( '' === $site_title ) {
			$site_title = 'WordPress Site';
		}
		$tagline  = (string) get_bloginfo( 'description' );
		$site_url = (string) home_url();

		$lines   = array();
		$lines[] = "# {$site_title}";
		$lines[] = '';
		if ( '' !== $tagline ) {
			$lines[] = "> {$tagline}";
			$lines[] = '';
		}
		$lines[] = "Welcome to {$site_title}. This website provides structured tools, clean semantic markdown streams, and real-time execution contracts for AI agents (Claude, Cursor, Perplexity, ChatGPT, Gemini).";
		$lines[] = '';

		// Section 1: Core Pages.
		$lines[] = '## Core Pages';
		$wpwebmcp_excluded_pages = class_exists( 'WP_WebMCP_Exclusions' ) ? WP_WebMCP_Exclusions::get_excluded_ids() : array(); // F6: honor exclusions in Core Pages
		$pages = get_pages( array( 'number' => 15, 'post_status' => 'publish', 'exclude' => $wpwebmcp_excluded_pages ) );
		if ( is_array( $pages ) && ! empty( $pages ) ) {
			foreach ( $pages as $page ) {
				$permalink = get_permalink( $page->ID );
				$md_link   = add_query_arg( 'format', 'markdown', $permalink );
				$raw_desc  = ! empty( $page->post_excerpt ) ? strip_shortcodes( $page->post_excerpt ) : wp_trim_words( strip_shortcodes( $page->post_content ), 20 ); // F6: strip shortcodes
				$desc      = trim( wp_strip_all_tags( (string) $raw_desc ) );
				if ( '' !== $desc ) {
					$lines[] = "- [{$page->post_title}]({$permalink}) ([AI Markdown]({$md_link})): {$desc}";
				} else {
					$lines[] = "- [{$page->post_title}]({$permalink}) ([AI Markdown]({$md_link}))";
				}
			}
		} else {
			$lines[] = "- [Home]({$site_url}): Official homepage ([AI Markdown]({$site_url}/?format=markdown)).";
		}
		$lines[] = '';

		// Section 2: Recent Posts / Articles.
		// F3 llms.txt pack content fix: include installed packs' post types so vertical
		// content (recipes, menu items, classes, events...) is AI-discoverable here.
		$content_types = array( 'post' );
		if ( class_exists( 'WP_WebMCP_Pack_Registry' ) ) {
			foreach ( (array) WP_WebMCP_Pack_Registry::get_installed() as $pack ) {
				foreach ( (array) ( $pack['manifest']['post_types'] ?? array() ) as $pt ) {
					if ( is_string( $pt ) && '' !== $pt && ! in_array( $pt, $content_types, true ) ) { $content_types[] = $pt; }
				}
			}
		}
		// F6 llms.txt exclusion guard: excluded posts never appear in the AI discovery feed.
		$wpwebmcp_excluded = class_exists( 'WP_WebMCP_Exclusions' ) ? WP_WebMCP_Exclusions::get_excluded_ids() : array();
				$posts = get_posts( array( 'numberposts' => 30, 'post_status' => 'publish', 'post_type' => $content_types, 'orderby' => 'date', 'order' => 'DESC', 'post__not_in' => $wpwebmcp_excluded ) );
		if ( is_array( $posts ) && ! empty( $posts ) ) {
			$lines[] = '## Published Articles & Content';
			foreach ( $posts as $post ) {
				$permalink = get_permalink( $post->ID );
				$md_link   = add_query_arg( 'format', 'markdown', $permalink );
				$raw_excerpt = ! empty( $post->post_excerpt ) ? strip_shortcodes( $post->post_excerpt ) : wp_trim_words( strip_shortcodes( $post->post_content ), 30 ); // F6: strip shortcodes (no raw [woocommerce_my_account] leaks)
				$excerpt   = wp_strip_all_tags( (string) $raw_excerpt );
				if ( $full ) {
					$lines[] = "### [{$post->post_title}]({$permalink}) — [Clean Markdown for AI]({$md_link})";
					$lines[] = $excerpt;
					$lines[] = '';
				} else {
					$lines[] = "- [{$post->post_title}]({$permalink}) ([AI Markdown]({$md_link})): {$excerpt}";
				}
			}
			$lines[] = '';
		}

		// Section 3: WebMCP & Model Context Protocol Tools.
		$lines[] = '## WebMCP & Model Context Protocol Tools';
		$lines[] = 'AI agents can discover and execute live tools on this website via Chrome `document.modelContext` or remote MCP JSON-RPC (`/wp-json/wpwebmcp/v1/mcp`):';
		$all_tools = class_exists( 'WP_WebMCP_Schema_Builder' ) ? WP_WebMCP_Schema_Builder::get_all_tools() : array();
		foreach ( $all_tools as $t ) {
			$t_name = $t['name'] ?? '';
			$t_desc = $t['description'] ?? '';
			$t_type = $t['x-webmcp-type'] ?? 'read';
			$lines[] = "- `{$t_name}` ({$t_type}): {$t_desc}";
		}
		$lines[] = '';

		// Section 4: Machine Discovery Endpoints.
		$lines[] = '## AI Agent Protocol Endpoints';
		if ( ! $full ) {
			$lines[] = "- [Full Content Index (llms-full.txt)]({$site_url}/llms-full.txt): Complete detailed text index of all site content.";
		}
		$lines[] = "- [WebMCP Agent Manifest]({$site_url}/wp-json/wpwebmcp/v1/manifest): Machine-readable JSON tool schemas.";
		$lines[] = "- [Model Context Protocol Server]({$site_url}/wp-json/wpwebmcp/v1/mcp): Standard JSON-RPC 2.0 endpoint.";
		$lines[] = "- [Model Context Protocol SSE]({$site_url}/wp-json/wpwebmcp/v1/sse): Server-Sent Events stream.";
		$lines[] = "- [MCP Well-Known Discovery]({$site_url}/.well-known/mcp.json): Model Context Protocol configuration.";
		$lines[] = "- [OpenAI Plugin Discovery]({$site_url}/.well-known/ai-plugin.json): OpenAI Assistant plugin manifest.";
		$lines[] = '';

		return implode( "\n", $lines );
	}
	// phpcs:enable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
}