<?php
/**
 * Markdown Content Negotiation & AI Priority Content Stream.
 *
 * Serves clean Markdown text representations of WordPress posts, pages, and archives
 * when requested via `Accept: text/markdown` or direct URL parameters `?format=markdown` / `?format=ai`.
 *
 * Enriched with YAML frontmatter, AI agent priority metadata, and available WebMCP tool references
 * to maximize discoverability by Perplexity, ChatGPT, Claude, Gemini, and autonomous agents.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- reading HTTP_ACCEPT header is intentional for content negotiation
final class WP_WebMCP_Markdown {

	/**
	 * Initialize Markdown content negotiation.
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'template_redirect', array( __CLASS__, 'serve_if_requested' ), 2 );
	}

	/**
	 * Serve clean markdown if requested via Accept header or query parameter.
	 */
	public static function serve_if_requested(): void {
		if ( ! (bool) get_option( 'wpwebmcp_markdown_negotiation', true ) ) {
			return;
		}

		$format_param = isset( $_GET['format'] ) ? sanitize_key( wp_unslash( $_GET['format'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$is_param_req = in_array( $format_param, array( 'markdown', 'md', 'ai', 'txt' ), true );

		$accept = isset( $_SERVER['HTTP_ACCEPT'] ) ? (string) wp_unslash( $_SERVER['HTTP_ACCEPT'] ) : '';
		$is_accept_req = ( false !== stripos( $accept, 'text/markdown' ) || false !== stripos( $accept, 'text/x-markdown' ) );

		if ( ! $is_param_req && ! $is_accept_req ) {
			return;
		}

		$post = get_queried_object();

		// F6: excluded posts are never served as AI markdown streams.
		if ( $post instanceof WP_Post && class_exists( 'WP_WebMCP_Exclusions' ) && in_array( (int) $post->ID, WP_WebMCP_Exclusions::get_excluded_ids(), true ) ) {
			return;
		}

		if ( $post instanceof WP_Post ) {
			self::serve_singular( $post );
		} elseif ( is_home() || is_front_page() ) {
			self::serve_homepage();
		} elseif ( is_archive() || is_category() || is_tag() ) {
			self::serve_archive();
		}
	}

	/**
	 * Serve singular post/page as clean markdown with YAML frontmatter.
	 *
	 * @param WP_Post $post
	 */
	private static function serve_singular( WP_Post $post ): void {
		$title      = get_the_title( $post );
		$date       = get_the_date( 'Y-m-d', $post );
		$author     = get_the_author_meta( 'display_name', $post->post_author );
		$url        = get_permalink( $post );
		$categories = wp_get_post_categories( $post->ID, array( 'fields' => 'names' ) );
		$tags       = wp_get_post_tags( $post->ID, array( 'fields' => 'names' ) );
		$word_count = str_word_count( wp_strip_all_tags( $post->post_content ) );
		$read_time  = max( 1, (int) ceil( $word_count / 200 ) );

		// Tools available on this page
		$manifest   = class_exists( 'WP_WebMCP_Schema_Builder' )
			? WP_WebMCP_Schema_Builder::build( 'single', $post->ID )
			: array( 'tools' => array() );
		$tool_names = wp_list_pluck( $manifest['tools'] ?? array(), 'name' );

		$output   = array();
		$output[] = '---';
		$output[] = 'title: ' . wp_json_encode( $title );
		$output[] = 'url: ' . wp_json_encode( $url );
		$output[] = 'date: ' . wp_json_encode( $date );
		$output[] = 'author: ' . wp_json_encode( $author );
		$output[] = 'reading_time_minutes: ' . $read_time;
		$output[] = 'categories: ' . wp_json_encode( $categories );
		$output[] = 'tags: ' . wp_json_encode( $tags );
		$output[] = 'ai_agent_priority: high';
		$output[] = 'webmcp_tools_available: ' . wp_json_encode( $tool_names );
		$output[] = '---';
		$output[] = '';
		$output[] = "# {$title}";
		$output[] = '';
		$output[] = self::html_to_markdown( $post->post_content );
		$output[] = '';
		$output[] = '---';
		$output[] = sprintf( '*Source: [%s](%s) | Processed by WebMCP Nexus Priority Stream*', esc_html( get_bloginfo( 'name' ) ), esc_url( $url ) );

		self::send_markdown( implode( "\n", $output ) );
	}

	/**
	 * Serve homepage markdown index.
	 */
	private static function serve_homepage(): void {
		$site_title = (string) get_bloginfo( 'name' );
		$site_desc  = (string) get_bloginfo( 'description' );
		$site_url   = (string) home_url();

		$recent_posts = get_posts( array( 'posts_per_page' => 10, 'post_status' => 'publish' ) );

		$output   = array();
		$output[] = '---';
		$output[] = 'title: ' . wp_json_encode( $site_title );
		$output[] = 'description: ' . wp_json_encode( $site_desc );
		$output[] = 'url: ' . wp_json_encode( $site_url );
		$output[] = 'ai_agent_priority: high';
		$output[] = 'llms_txt_url: ' . wp_json_encode( home_url( '/llms.txt' ) );
		$output[] = 'mcp_endpoint: ' . wp_json_encode( rest_url( 'wpwebmcp/v1/mcp' ) );
		$output[] = '---';
		$output[] = '';
		$output[] = "# {$site_title}";
		$output[] = "> {$site_desc}";
		$output[] = '';
		$output[] = '## Latest Content';
		$output[] = '';

		foreach ( $recent_posts as $p ) {
			$p_title = get_the_title( $p );
			$p_url   = get_permalink( $p );
			$p_md    = add_query_arg( 'format', 'markdown', $p_url );
			$p_date  = get_the_date( 'Y-m-d', $p );
			$output[] = "- [{$p_title}]({$p_url}) ({$p_date}) — [Clean Markdown for AI]({$p_md})";
		}

		self::send_markdown( implode( "\n", $output ) );
	}

	/**
	 * Serve archive as markdown.
	 */
	private static function serve_archive(): void {
		$term_name = single_term_title( '', false ) ?: 'Archive';
		$site_url  = (string) home_url();

		$posts = get_posts(
			array(
				'posts_per_page' => 15,
				'post_status'    => 'publish',
				'category'       => is_category() ? (int) get_queried_object_id() : 0,
			)
		);

		$output   = array();
		$output[] = "# Archive: {$term_name}";
		$output[] = '';

		foreach ( $posts as $p ) {
			$p_title = get_the_title( $p );
			$p_url   = get_permalink( $p );
			$p_md    = add_query_arg( 'format', 'markdown', $p_url );
			$output[] = "- [{$p_title}]({$p_url}) — [AI Markdown]({$p_md})";
		}

		self::send_markdown( implode( "\n", $output ) );
	}

	/**
	 * Send clean markdown response with headers.
	 *
	 * @param string $content
	 */
	private static function send_markdown( string $content ): void {
		if ( ! headers_sent() ) {
			status_header( 200 );
			header( 'Content-Type: text/markdown; charset=utf-8' );
			header( 'Vary: Accept' );
			header( 'X-WebMCP-Format: markdown' );
			header( 'X-AI-Content-Type: text/markdown' );
			header( 'X-Robots-Tag: all, follow' );
			header( 'X-WebMCP-Priority: high' );
			header( 'Access-Control-Allow-Origin: *' );
			header( 'Cache-Control: public, max-age=1800' );
		}

		echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	/**
	 * HTML / Gutenberg blocks to clean Markdown converter.
	 *
	 * @param string $html
	 * @return string
	 */
	public static function html_to_markdown( string $html ): string {
		$content = do_blocks( $html );
		$content = wpautop( $content );

		// Headings
		$content = preg_replace( '/<h1[^>]*>(.*?)<\/h1>/is', "\n# $1\n", $content );
		$content = preg_replace( '/<h2[^>]*>(.*?)<\/h2>/is', "\n## $1\n", $content );
		$content = preg_replace( '/<h3[^>]*>(.*?)<\/h3>/is', "\n### $1\n", $content );
		$content = preg_replace( '/<h4[^>]*>(.*?)<\/h4>/is', "\n#### $1\n", $content );

		// Paragraphs and breaks
		$content = preg_replace( '/<p[^>]*>(.*?)<\/p>/is', "$1\n\n", $content );
		$content = preg_replace( '/<br\s*\/?>/i', "\n", $content );

		// Links and formatting
		$content = preg_replace( '/<a[^>]+href="([^"]+)"[^>]*>(.*?)<\/a>/is', '[$2]($1)', $content );
		$content = preg_replace( '/<(strong|b)[^>]*>(.*?)<\/(strong|b)>/is', '**$2**', $content );
		$content = preg_replace( '/<(em|i)[^>]*>(.*?)<\/(em|i)>/is', '*$2*', $content );
		$content = preg_replace( '/<code[^>]*>(.*?)<\/code>/is', '`$1`', $content );

		// Lists
		$content = preg_replace( '/<li[^>]*>(.*?)<\/li>/is', "- $1\n", $content );

		// Clean tags
		$content = wp_strip_all_tags( $content );
		$content = html_entity_decode( $content, ENT_QUOTES, 'UTF-8' );

		return trim( $content );
	}
	// phpcs:enable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
}