<?php
/**
 * Missing-Tool Auditor — Module A A4 (AI-Readiness Audit).
 *
 * Unified "tools your site should have but doesn't" feed that aggregates:
 *   - A3c schema-to-tool sync: posts have @type X but no matching tool
 *   - A3a answer-gap detector: bank questions with no matching tool
 *
 * Output is de-duplicated by target slug and ranked by impact (post_count
 * for schema-driven, intent-priority for question-driven).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Missing_Tool_Auditor {

	/**
	 * Build the unified missing-tool feed.
	 *
	 * @param int $schema_scan_limit Bounded scan cap (default 500).
	 * @return array<int, array<string, mixed>>
	 */
	public static function collect( int $schema_scan_limit = 500 ): array {
		$out = array();

		// ---- A3c source: schema-detected ----
		if ( class_exists( 'WP_WebMCP_Schema_Scanner' ) && class_exists( 'WP_WebMCP_Schema_Tool_Suggester' ) ) {
			$scan        = WP_WebMCP_Schema_Scanner::scan( $schema_scan_limit );
			$suggestions = WP_WebMCP_Schema_Tool_Suggester::suggest( $scan );
			foreach ( $suggestions as $sug ) {
				$slug = isset( $sug['suggested_tool']['slug'] ) ? (string) $sug['suggested_tool']['slug'] : '';
				if ( '' === $slug ) {
					continue;
				}
				$out[] = array(
					'source'         => 'schema',
					'type'           => (string) ( $sug['type'] ?? '' ),
					'label'          => (string) ( $sug['label'] ?? '' ),
					'icon'           => (string) ( $sug['icon'] ?? '📄' ),
					'slug'           => $slug,
					'name'           => (string) ( $sug['suggested_tool']['name'] ?? $slug ),
					'description'    => (string) ( $sug['suggested_tool']['description'] ?? '' ),
					'parameters'     => isset( $sug['suggested_tool']['parameters'] ) ? $sug['suggested_tool']['parameters'] : array(),
					'evidence_count' => (int) ( $sug['post_count'] ?? 0 ),
					'sample_ids'     => isset( $sug['sample_post_ids'] ) && is_array( $sug['sample_post_ids'] )
						? array_map( 'intval', $sug['sample_post_ids'] )
						: array(),
					'priority'       => 100 + (int) ( $sug['post_count'] ?? 0 ),
				);
			}
		}

		// ---- A3a source: question-bank gaps ----
		if ( class_exists( 'WP_WebMCP_Answer_Gap_Detector' ) ) {
			$gap_result = WP_WebMCP_Answer_Gap_Detector::detect( null, 2 );
			$gaps       = isset( $gap_result['gaps'] ) && is_array( $gap_result['gaps'] ) ? $gap_result['gaps'] : array();
			// Stable per-vertical priority weights — higher = more important.
			$vert_priority = array(
				'ecommerce'      => 80,
				'tech_docs'      => 70,
				'local_business' => 65,
				'news'           => 60,
				'blog'           => 50,
				'video'          => 45,
				'events'         => 40,
			);
			foreach ( $gaps as $gap ) {
				$tool = isset( $gap['suggested_tool'] ) && is_array( $gap['suggested_tool'] ) ? $gap['suggested_tool'] : array();
				$slug = isset( $tool['slug'] ) ? (string) $tool['slug'] : '';
				if ( '' === $slug ) {
					continue;
				}
				$out[] = array(
					'source'         => 'gap',
					'type'           => '',
					'label'          => '',
					'icon'           => '❓',
					'slug'           => $slug,
					'name'           => isset( $tool['name'] ) ? (string) $tool['name'] : $slug,
					'description'    => isset( $tool['description'] ) ? (string) $tool['description'] : '',
					'parameters'     => isset( $tool['parameters'] ) ? $tool['parameters'] : array(),
					'evidence_count' => 1,
					'sample_ids'     => array(),
					'query'          => (string) ( $gap['query'] ?? '' ),
					'vertical'       => (string) ( $gap['vertical'] ?? '' ),
					'priority'       => (int) ( $vert_priority[ (string) ( $gap['vertical'] ?? '' ) ] ?? 30 ),
				);
			}
		}

		// ---- De-dupe by slug, keeping highest-priority entry ----
		$by_slug = array();
		foreach ( $out as $row ) {
			$slug = (string) $row['slug'];
			if ( '' === $slug ) {
				continue;
			}
			if ( ! isset( $by_slug[ $slug ] ) || (int) $row['priority'] > (int) $by_slug[ $slug ]['priority'] ) {
				$by_slug[ $slug ] = $row;
			}
		}

		// Filter out slugs that already exist in the tool repo.
		if ( class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			foreach ( array_keys( $by_slug ) as $slug ) {
				if ( null !== WP_WebMCP_Tool_Repository::find_by_slug( $slug ) ) {
					unset( $by_slug[ $slug ] );
				}
			}
		}

		// Sort by priority desc, then slug asc.
		$rows = array_values( $by_slug );
		usort(
			$rows,
			static function ( $a, $b ) {
				$pa = (int) $a['priority']; $pb = (int) $b['priority'];
				if ( $pa === $pb ) { return strcmp( (string) $a['slug'], (string) $b['slug'] ); }
				return $pb <=> $pa;
			}
		);

		return $rows;
	}

	/**
	 * Convenience: just counts.
	 *
	 * @return array{schema:int,gap:int,total:int}
	 */
	public static function count_breakdown(): array {
		$rows   = self::collect();
		$schema = 0;
		$gap    = 0;
		foreach ( $rows as $row ) {
			if ( 'schema' === (string) ( $row['source'] ?? '' ) ) {
				++$schema;
			} else {
				++$gap;
			}
		}
		return array(
			'schema' => $schema,
			'gap'    => $gap,
			'total'  => count( $rows ),
		);
	}
}
