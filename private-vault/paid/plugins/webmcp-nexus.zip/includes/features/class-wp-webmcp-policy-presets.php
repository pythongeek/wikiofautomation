<?php
/**
 * Policy Presets — Module A A2c (Policy template library by segment).
 *
 * Pre-packages sets of A2a policies tuned for common verticals:
 *   1. News / Magazine / Media      (slug: news)
 *   2. E-Commerce (WooCommerce)     (slug: ecommerce)
 *   3. SaaS / Tech Documentation    (slug: tech_docs)
 *   4. Local Business               (slug: local_business)
 *
 * Each preset is an ordered list of A2a policy rows in the same shape that
 * WP_WebMCP_Policy::save() accepts. Applying a preset appends those rows
 * to the active policy list (it does NOT delete existing custom policies).
 *
 * Rows are tagged via the `name` prefix `[<preset_slug>]` so re-applying a
 * preset is idempotent — already-applied rows are skipped on re-apply.
 *
 * Priorities for preset rows use the 200-299 range so they slot in BELOW
 * typical user policies (10-99) but above catch-all rules (300+). Admins
 * can still edit / disable / delete them after applying.
 *
 * Storage: rows land in the `wpwebmcp_policies` option via the normal
 * WP_WebMCP_Policy save path, so the existing visual policy builder sees
 * them with no extra wiring.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Policy_Presets {

	/**
	 * The four segment presets. Keys are the public preset slugs (referenced
	 * by the REST API + admin UI). Each value is a structured descriptor.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function get_presets(): array {
		return array(
			'news' => array(
				'name'        => __( 'News / Magazine / Media', 'webmcp-nexus' ),
				'icon'        => '📰',
				'description' => __( 'Optimised for citation visibility: allow canonical AI bots to crawl freely, redact editorial-staff emails, rate-limit unidentified callers. Good default for content sites that want to be cited.', 'webmcp-nexus' ),
				'tagline'     => __( 'Citation-friendly with light abuse protection', 'webmcp-nexus' ),
				'policies'    => array(
					array(
						'name'                  => '[news] Rate-limit unknown agents at 30/min',
						'priority'              => 200,
						'enabled'               => true,
						'match_type'            => 'unknown_agent',
						'match_value'           => '',
						'action'                => 'rate_limit',
						'rate_limit_per_minute' => 30,
						'custom_message'        => '',
						'redact_email'          => false,
					),
					array(
						'name'           => '[news] Always redact emails for Anthropic family',
						'priority'       => 210,
						'enabled'        => true,
						'match_type'     => 'agent_family',
						'match_value'    => 'anthropic',
						'action'         => 'redact_email',
						'custom_message' => '',
						'redact_email'   => true,
					),
					array(
						'name'           => '[news] Allow Googlebot (citation)',
						'priority'       => 220,
						'enabled'        => true,
						'match_type'     => 'agent_family',
						'match_value'    => 'google',
						'action'         => 'allow',
						'custom_message' => '',
						'redact_email'   => false,
					),
				),
			),
			'ecommerce' => array(
				'name'        => __( 'E-Commerce (WooCommerce)', 'webmcp-nexus' ),
				'icon'        => '🛒',
				'description' => __( 'Strict protection for stores: block unidentified callers, rate-limit user-action agents to protect checkout flows, redact customer emails universally. Designed for sites where agent misuse = lost revenue.', 'webmcp-nexus' ),
				'tagline'     => __( 'Strict — protects checkout and customer PII', 'webmcp-nexus' ),
				'policies'    => array(
					array(
						'name'           => '[ecommerce] Block all unknown agents',
						'priority'       => 200,
						'enabled'        => true,
						'match_type'     => 'unknown_agent',
						'match_value'    => '',
						'action'         => 'block',
						'custom_message' => __( 'This store only grants WebMCP tool access to verified AI agents. Please contact the site owner to negotiate access.', 'webmcp-nexus' ),
						'redact_email'   => false,
					),
					array(
						'name'                  => '[ecommerce] Rate-limit user-action agents at 60/min',
						'priority'              => 210,
						'enabled'               => true,
						'match_type'            => 'agent_family',
						'match_value'           => 'openai',
						'action'                => 'rate_limit',
						'rate_limit_per_minute' => 60,
						'custom_message'        => '',
						'redact_email'          => false,
					),
					array(
						'name'                  => '[ecommerce] Rate-limit Anthropic user-action at 60/min',
						'priority'              => 215,
						'enabled'               => true,
						'match_type'            => 'agent_family',
						'match_value'           => 'anthropic',
						'action'                => 'rate_limit',
						'rate_limit_per_minute' => 60,
						'custom_message'        => '',
						'redact_email'          => false,
					),
					array(
						'name'           => '[ecommerce] Always redact customer emails',
						'priority'       => 220,
						'enabled'        => true,
						'match_type'     => 'all',
						'match_value'    => '',
						'action'         => 'redact_email',
						'custom_message' => '',
						'redact_email'   => true,
					),
				),
			),
			'tech_docs' => array(
				'name'        => __( 'SaaS / Tech Documentation', 'webmcp-nexus' ),
				'icon'        => '💻',
				'description' => __( 'Developer-friendly: allow IDE-style user-action agents (Cursor, Claude Desktop, ChatGPT), rate-limit unidentified callers. Optimised for code-snippet retrieval use-cases where over-restriction breaks IDE workflows.', 'webmcp-nexus' ),
				'tagline'     => __( 'IDE-friendly — minimal restrictions on dev agents', 'webmcp-nexus' ),
				'policies'    => array(
					array(
						'name'                  => '[tech_docs] Rate-limit unknown agents at 60/min',
						'priority'              => 200,
						'enabled'               => true,
						'match_type'            => 'unknown_agent',
						'match_value'           => '',
						'action'                => 'rate_limit',
						'rate_limit_per_minute' => 60,
						'custom_message'        => '',
						'redact_email'          => false,
					),
					array(
						'name'           => '[tech_docs] Allow all OpenAI user-action agents',
						'priority'       => 210,
						'enabled'        => true,
						'match_type'     => 'agent_family',
						'match_value'    => 'openai',
						'action'         => 'allow',
						'custom_message' => '',
						'redact_email'   => false,
					),
					array(
						'name'           => '[tech_docs] Allow all Anthropic user-action agents',
						'priority'       => 215,
						'enabled'        => true,
						'match_type'     => 'agent_family',
						'match_value'    => 'anthropic',
						'action'         => 'allow',
						'custom_message' => '',
						'redact_email'   => false,
					),
					array(
						'name'           => '[tech_docs] Allow Perplexity user-action agents',
						'priority'       => 220,
						'enabled'        => true,
						'match_type'     => 'agent_family',
						'match_value'    => 'perplexity',
						'action'         => 'allow',
						'custom_message' => '',
						'redact_email'   => false,
					),
				),
			),
			'local_business' => array(
				'name'        => __( 'Local Business', 'webmcp-nexus' ),
				'icon'        => '🏪',
				'description' => __( 'Lead-generation focus: block common scrapers, rate-limit user-action agents so legitimate AI agents can still query your hours/menu/services without overwhelming the backend, always redact customer emails.', 'webmcp-nexus' ),
				'tagline'     => __( 'Lead-gen friendly with sensible scraper blocking', 'webmcp-nexus' ),
				'policies'    => array(
					array(
						'name'                  => '[local_business] Rate-limit unknown agents at 30/min',
						'priority'              => 200,
						'enabled'               => true,
						'match_type'            => 'unknown_agent',
						'match_value'           => '',
						'action'                => 'rate_limit',
						'rate_limit_per_minute' => 30,
						'custom_message'        => '',
						'redact_email'          => false,
					),
					array(
						'name'                  => '[local_business] Rate-limit OpenAI user-action at 30/min',
						'priority'              => 210,
						'enabled'               => true,
						'match_type'            => 'agent_family',
						'match_value'           => 'openai',
						'action'                => 'rate_limit',
						'rate_limit_per_minute' => 30,
						'custom_message'        => '',
						'redact_email'          => false,
					),
					array(
						'name'           => '[local_business] Always redact emails (PII protection)',
						'priority'       => 220,
						'enabled'        => true,
						'match_type'     => 'all',
						'match_value'    => '',
						'action'         => 'redact_email',
						'custom_message' => '',
						'redact_email'   => true,
					),
				),
			),
		);
	}

	/**
	 * Read a single preset by slug. Returns null when not found.
	 *
	 * @return array<string,mixed>|null
	 */
	public static function get( string $slug ): ?array {
		$all = self::get_presets();
		return isset( $all[ $slug ] ) ? $all[ $slug ] : null;
	}

	/**
	 * Summary list — for the admin UI cards and the REST list endpoint.
	 * Strips the full `policies` array (replaced with policy_count) so the
	 * list payload stays small.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_summary(): array {
		$out = array();
		foreach ( self::get_presets() as $slug => $preset ) {
			$policies = isset( $preset['policies'] ) && is_array( $preset['policies'] ) ? $preset['policies'] : array();
			$out[]    = array(
				'slug'         => $slug,
				'name'         => isset( $preset['name'] ) ? (string) $preset['name'] : $slug,
				'icon'         => isset( $preset['icon'] ) ? (string) $preset['icon'] : '🧩',
				'tagline'      => isset( $preset['tagline'] ) ? (string) $preset['tagline'] : '',
				'description'  => isset( $preset['description'] ) ? (string) $preset['description'] : '',
				'policy_count' => count( $policies ),
			);
		}
		return $out;
	}

	/**
	 * Apply a preset — appends its policy rows to the active policy list.
	 *
	 * Idempotency: rows are tagged with the preset slug prefix `[slug]` in
	 * the `name` field. Re-applying a preset skips rows whose name already
	 * starts with that tag (matched against the existing option rows).
	 *
	 * Returns a structured result describing what happened:
	 *   - ok           (bool)        — operation succeeded
	 *   - created      (int)         — number of new rows inserted
	 *   - skipped      (int)         — number of rows skipped (already applied)
	 *   - inserted_ids (string[])    — policy ids of newly inserted rows
	 *
	 * @return array<string, mixed>
	 */
	public static function apply( string $slug ): array {
		$preset = self::get( $slug );
		if ( null === $preset ) {
			return array(
				'ok'      => false,
				'created' => 0,
				'skipped' => 0,
				'inserted_ids' => array(),
				'error'   => 'unknown_preset',
			);
		}
		if ( ! class_exists( 'WP_WebMCP_Policy' ) ) {
			return array(
				'ok'      => false,
				'created' => 0,
				'skipped' => 0,
				'inserted_ids' => array(),
				'error'   => 'policy_class_missing',
			);
		}

		$tag         = '[' . $slug . ']';
		$existing    = WP_WebMCP_Policy::all();
		$have_names  = array();
		foreach ( $existing as $row ) {
			if ( isset( $row['name'] ) && is_string( $row['name'] ) && strpos( $row['name'], $tag ) === 0 ) {
				$have_names[] = (string) $row['name'];
			}
		}

		$created      = 0;
		$skipped      = 0;
		$inserted_ids = array();
		$policies     = isset( $preset['policies'] ) && is_array( $preset['policies'] ) ? $preset['policies'] : array();
		foreach ( $policies as $row ) {
			$row_name = isset( $row['name'] ) ? (string) $row['name'] : '';
			if ( '' !== $row_name && in_array( $row_name, $have_names, true ) ) {
				++$skipped;
				continue;
			}
			$saved = WP_WebMCP_Policy::save( $row );
			if ( is_wp_error( $saved ) ) {
				continue;
			}
			++$created;
			if ( isset( $saved['id'] ) ) {
				$inserted_ids[] = (string) $saved['id'];
			}
		}

		return array(
			'ok'           => true,
			'created'      => $created,
			'skipped'      => $skipped,
			'inserted_ids' => $inserted_ids,
		);
	}

	/**
	 * Remove every policy row whose `name` starts with the preset slug tag.
	 * Symmetric inverse of apply() — useful for "Reset preset" UI affordances.
	 *
	 * @return int Number of rows deleted.
	 */
	public static function remove( string $slug ): int {
		if ( ! class_exists( 'WP_WebMCP_Policy' ) ) {
			return 0;
		}
		$tag      = '[' . $slug . ']';
		$deleted  = 0;
		foreach ( WP_WebMCP_Policy::all() as $row ) {
			if ( ! isset( $row['id'], $row['name'] ) ) {
				continue;
			}
			if ( is_string( $row['name'] ) && strpos( $row['name'], $tag ) === 0 ) {
				if ( WP_WebMCP_Policy::delete( (string) $row['id'] ) ) {
					++$deleted;
				}
			}
		}
		return $deleted;
	}
}
