<?php
/**
 * Policy — Module A A2a (Visual policy builder).
 *
 * Per-agent access policies. Each policy has a match clause (which agent /
 * agent family / unknown / blocked) and an action (allow / block /
 * rate_limit / redact_email). Policies are evaluated in priority order
 * (lowest priority value wins) and the FIRST match is applied.
 *
 * Storage: `wpwebmcp_policies` option as an array of policy rows. Empty
 * by default — admins build policies via the visual policy-builder page
 * or the REST routes.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Policy {

	public const OPTION_KEY = 'wpwebmcp_policies';

	/** Match clauses — determine which requests a policy applies to. */
	public const MATCH_ALL            = 'all';
	public const MATCH_AGENT_SLUG     = 'agent_slug';
	public const MATCH_AGENT_FAMILY   = 'agent_family';
	public const MATCH_UNKNOWN_AGENT  = 'unknown_agent';
	public const MATCH_BLOCKED_AGENT = 'blocked_agent';

	private const ALLOWED_MATCH_TYPES = array(
		self::MATCH_ALL,
		self::MATCH_AGENT_SLUG,
		self::MATCH_AGENT_FAMILY,
		self::MATCH_UNKNOWN_AGENT,
		self::MATCH_BLOCKED_AGENT,
	);

	/** Actions — what to do when a policy matches. */
	public const ACTION_ALLOW        = 'allow';
	public const ACTION_BLOCK        = 'block';
	public const ACTION_RATE_LIMIT   = 'rate_limit';
	public const ACTION_REDACT_EMAIL = 'redact_email';

	private const ALLOWED_ACTIONS = array(
		self::ACTION_ALLOW,
		self::ACTION_BLOCK,
		self::ACTION_RATE_LIMIT,
		self::ACTION_REDACT_EMAIL,
	);

	/**
	 * Read all policies sorted by priority (lowest priority value = highest precedence).
	 *
	 * @return array<int, array<string,mixed>>
	 */
	public static function all(): array {
		$raw = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$out = array_values( array_filter( $raw, 'is_array' ) );
		usort(
			$out,
			static function ( $a, $b ) {
				$pa = isset( $a['priority'] ) ? (int) $a['priority'] : 100;
				$pb = isset( $b['priority'] ) ? (int) $b['priority'] : 100;
				if ( $pa === $pb ) {
					$ca = isset( $a['created_at'] ) ? (string) $a['created_at'] : '';
					$cb = isset( $b['created_at'] ) ? (string) $b['created_at'] : '';
					return strcmp( $ca, $cb );
				}
				return $pa <=> $pb;
			}
		);
		return $out;
	}

	/**
	 * Read one policy by id, or null if not found.
	 *
	 * @return array<string,mixed>|null
	 */
	public static function get( string $id ): ?array {
		foreach ( self::all() as $p ) {
			if ( isset( $p['id'] ) && (string) $p['id'] === $id ) {
				return $p;
			}
		}
		return null;
	}

	/**
	 * Create or update a policy. Normalises fields and validates the match/action
	 * whitelist. Returns the persisted policy on success or WP_Error on failure.
	 *
	 * @param array<string,mixed> $input Raw input from REST or admin form.
	 * @return array<string,mixed>|WP_Error
	 */
	public static function save( array $input ) {
		$match_type = isset( $input['match_type'] ) ? sanitize_key( (string) $input['match_type'] ) : self::MATCH_ALL;
		if ( ! in_array( $match_type, self::ALLOWED_MATCH_TYPES, true ) ) {
			return new WP_Error( 'wpwebmcp_policy_bad_match', __( 'Invalid match_type.', 'webmcp-nexus' ) );
		}
		$action = isset( $input['action'] ) ? sanitize_key( (string) $input['action'] ) : self::ACTION_ALLOW;
		if ( ! in_array( $action, self::ALLOWED_ACTIONS, true ) ) {
			return new WP_Error( 'wpwebmcp_policy_bad_action', __( 'Invalid action.', 'webmcp-nexus' ) );
		}
		// match_value is required for agent_slug / agent_family, otherwise ignored.
		$match_value = isset( $input['match_value'] ) ? sanitize_text_field( (string) $input['match_value'] ) : '';
		if ( in_array( $match_type, array( self::MATCH_AGENT_SLUG, self::MATCH_AGENT_FAMILY ), true ) && '' === $match_value ) {
			return new WP_Error( 'wpwebmcp_policy_match_value_required', __( 'match_value is required for agent_slug and agent_family match types.', 'webmcp-nexus' ) );
		}
		$now           = time();
		$existing_id   = isset( $input['id'] ) ? sanitize_text_field( (string) $input['id'] ) : '';
		$existing      = '' !== $existing_id ? self::get( $existing_id ) : null;
		$id            = $existing ? (string) $existing['id'] : self::mint_id();
		$rate_limit    = isset( $input['rate_limit_per_minute'] ) ? max( 0, (int) $input['rate_limit_per_minute'] ) : 0;
		$custom_message = isset( $input['custom_message'] ) ? sanitize_text_field( (string) $input['custom_message'] ) : '';
		$enabled       = isset( $input['enabled'] ) ? ! empty( $input['enabled'] ) : true;

		$row = array(
			'id'                    => $id,
			'name'                  => isset( $input['name'] ) ? sanitize_text_field( (string) $input['name'] ) : ( $existing['name'] ?? 'Policy ' . $id ),
			'enabled'               => $enabled,
			'priority'              => isset( $input['priority'] ) ? (int) $input['priority'] : ( $existing['priority'] ?? 100 ),
			'match_type'            => $match_type,
			'match_value'           => $match_value,
			'action'                => $action,
			'rate_limit_per_minute' => $rate_limit,
			'custom_message'        => $custom_message,
			'redact_email'          => ! empty( $input['redact_email'] ),
			'created_at'            => $existing ? (string) $existing['created_at'] : gmdate( 'c', $now ),
			'updated_at'            => gmdate( 'c', $now ),
		);

		$all = self::all();
		$found = false;
		foreach ( $all as $i => $existing_row ) {
			if ( isset( $existing_row['id'] ) && (string) $existing_row['id'] === $id ) {
				$all[ $i ] = $row;
				$found = true;
				break;
			}
		}
		if ( ! $found ) {
			$all[] = $row;
		}
		update_option( self::OPTION_KEY, $all, false );

		return $row;
	}

	/**
	 * Delete a policy by id. Returns true on success, false if not found.
	 */
	public static function delete( string $id ): bool {
		$all = self::all();
		$kept = array();
		$deleted = false;
		foreach ( $all as $row ) {
			if ( isset( $row['id'] ) && (string) $row['id'] === $id ) {
				$deleted = true;
				continue;
			}
			$kept[] = $row;
		}
		if ( $deleted ) {
			update_option( self::OPTION_KEY, $kept, false );
		}
		return $deleted;
	}

	/**
	 * Mint a short unique id for a new policy.
	 */
	private static function mint_id(): string {
		return 'pol_' . bin2hex( random_bytes( 6 ) );
	}

	/**
	 * Evaluate policies for a request. Returns the first matching policy as
	 * an array, or null when no policy matches (default = allow).
	 *
	 * @param array<string,mixed>|null $agent The resolved agent from
	 *        WP_WebMCP_Agent_Identity (has 'slug', 'family', 'is_user', 'confidence').
	 * @return array<string,mixed>|null  null when no policy matches.
	 */
	public static function evaluate_for_agent( $agent ): ?array {
		$agent_slug = is_array( $agent ) && isset( $agent['slug'] ) ? (string) $agent['slug'] : '';
		$family     = is_array( $agent ) && isset( $agent['family'] ) ? (string) $agent['family'] : '';
		$is_known   = is_array( $agent ) && isset( $agent['slug'] ) && 'unknown' !== (string) $agent['slug'];

		foreach ( self::all() as $policy ) {
			if ( empty( $policy['enabled'] ) ) {
				continue;
			}
			$match_type  = isset( $policy['match_type'] ) ? (string) $policy['match_type'] : self::MATCH_ALL;
			$match_value = isset( $policy['match_value'] ) ? (string) $policy['match_value'] : '';
			$hit         = false;

			switch ( $match_type ) {
				case self::MATCH_ALL:
					$hit = true;
					break;
				case self::MATCH_AGENT_SLUG:
					$hit = ( '' !== $agent_slug && $agent_slug === $match_value );
					break;
				case self::MATCH_AGENT_FAMILY:
					$hit = ( '' !== $family && $family === $match_value );
					break;
				case self::MATCH_UNKNOWN_AGENT:
					$hit = ! $is_known;
					break;
				case self::MATCH_BLOCKED_AGENT:
					// matches when the per-agent admin toggle in M0c is off — i.e. the agent is in the blocklist.
					$blocked = self::is_agent_blocked_via_agent_settings( $agent_slug );
					$hit     = ( null !== $blocked && false === $blocked );
					break;
			}
			if ( $hit ) {
				$action = isset( $policy['action'] ) ? (string) $policy['action'] : '';
			
				// F2 D4 trust rail: an allow rule may not bypass an
				// unknown-agent block on UA-tier identity alone. UA headers
				// are client-controlled; only verified/cidr confidence
				// (IP / DNS verification) may carry an allow past a block.
				if ( self::ACTION_ALLOW === $action && self::has_unknown_block() ) {
					$confidence = is_array( $agent ) && isset( $agent['confidence'] ) ? (string) $agent['confidence'] : 'ua';
					if ( 'verified' !== $confidence && 'cidr' !== $confidence ) {
						continue;
					}
				}
			
				// F2 D4 new-crawler grace: when enabled (default), an
				// unknown-agent block is enforced as a 60 req/min rate limit
				// so legitimate crawlers missing from the registry are
				// throttled, not locked out.
				if ( self::ACTION_BLOCK === $action && self::MATCH_UNKNOWN_AGENT === $match_type && (bool) get_option( 'wpwebmcp_unknown_grace_enabled', true ) ) {
					$grace = $policy;
					$grace['action'] = self::ACTION_RATE_LIMIT;
					$grace['rate_limit_per_minute'] = 60;
					$grace['grace_applied'] = true;
					return $grace;
				}
			
				return $policy;
			}
		}
		return null;
	}

	/**
	 * Whether an enabled unknown-agent block policy is currently in force.
	 * Used by the F2 trust rail to decide if UA-tier allow rules may fire.
	 */
	private static function has_unknown_block(): bool {
		foreach ( self::all() as $policy ) {
			if ( empty( $policy['enabled'] ) ) {
				continue;
			}
			$mt = isset( $policy['match_type'] ) ? (string) $policy['match_type'] : '';
			$ac = isset( $policy['action'] ) ? (string) $policy['action'] : '';
			if ( self::MATCH_UNKNOWN_AGENT === $mt && self::ACTION_BLOCK === $ac ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Check WP_WebMCP_Agent_Identity per-agent setting to see if an agent is blocked.
	 * Returns null when no per-agent setting exists (unblocked by default).
	 * Returns true when per-agent setting says blocked.
	 * Returns false when per-agent setting says enabled.
	 *
	 * @return bool|null
	 */
	private static function is_agent_blocked_via_agent_settings( string $agent_slug ): ?bool {
		if ( '' === $agent_slug ) {
			return null;
		}
		$settings = get_option( 'wpwebmcp_agent_settings', array() );
		if ( ! is_array( $settings ) || ! isset( $settings[ $agent_slug ] ) ) {
			return null;
		}
		return empty( $settings[ $agent_slug ]['enabled'] );
	}

	/**
	 * Apply a policy's redact_email flag to a tool result array.
	 *
	 * @param array<string,mixed> $result Tool result before policy redaction.
	 * @return array<string,mixed>        Result with email-like substrings replaced.
	 */
	public static function apply_redactions( array $result, array $policy ): array {
		if ( empty( $policy['redact_email'] ) ) {
			return $result;
		}
		$walk = static function ( $node ) use ( &$walk ) {
			if ( is_string( $node ) ) {
				return preg_replace( '/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/', '[redacted-email]', $node );
			}
			if ( is_array( $node ) ) {
				foreach ( $node as $k => $v ) {
					$node[ $k ] = $walk( $v );
				}
			}
			return $node;
		};
		return $walk( $result );
	}

	/**
	 * Surface API for the admin UI: the set of valid match types / actions.
	 *
	 * @return array<string, array<int, string>>
	 */
	public static function option_sets(): array {
		return array(
			'match_types' => self::ALLOWED_MATCH_TYPES,
			'actions'     => self::ALLOWED_ACTIONS,
		);
	}
}
