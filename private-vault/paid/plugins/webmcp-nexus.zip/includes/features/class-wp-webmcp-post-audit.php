<?php
/**
 * Post Audit — Module A A4 (AI-Readiness Audit — per-post AEO score).
 *
 * Computes a 0-100 AEO-readiness score for any WordPress post. The score is
 * the sum of weighted contributions from real, inspectable facts:
 *
 *   JSON-LD presence +20
 *   FAQ / HowTo schema present +20
 *   Article schema with author + datePublished +10
 *   Freshness metadata stored (A1c)  +10
 *   Exposure tier explicitly set       +15
 *   Excerpt / meta description filled +15
 *   Featured image set                +10
 *
 * Max possible = 100. Each contribution is a boolean, so the score is
 * always a sum of the constants above. The breakdown is returned alongside
 * the total so the dashboard / meta box can render actionable guidance.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery -- audit scores are cached separately via transient with 1h TTL
final class WP_WebMCP_Post_Audit {

	/**
	 * Audit a single post. Returns `{post_id, total, max, breakdown: [...], grade}`.
	 *
	 * @param int $post_id WordPress post ID.
	 * @return array<string, mixed>
	 */
	public static function audit_post( int $post_id ): array {
		$post_id = (int) $post_id;
		$post    = ( $post_id > 0 ) ? get_post( $post_id ) : null;
		if ( ! $post ) {
			return array(
				'post_id'   => $post_id,
				'total'      => 0,
				'max'        => 100,
				'grade'      => 'unknown',
				'breakdown'  => array(),
				'error'      => 'post_not_found',
			);
		}

		$content = (string) $post->post_content;
		$has_jsonld   = false !== stripos( $content, 'application/ld+json' );
		$jsonld_types = self::extract_jsonld_types( $content );

		$has_faq_or_howto = self::contains_any_type( $jsonld_types, array( 'FAQPage', 'HowTo', 'QAPage' ) );
		$has_article      = self::contains_any_type( $jsonld_types, array( 'Article', 'NewsArticle', 'BlogPosting', 'TechArticle' ) );
		$article_author_date = $has_article
			? self::article_node_has_author_and_date( $content )
			: false;

		// A1c freshness metadata — written by freshness pinger when a post is updated.
		$has_freshness = ( '' !== (string) get_post_meta( $post_id, '_wpwebmcp_last_freshness_at', true ) );

		// A2b exposure tier explicitly set (not the default 'public').
		$tier          = (string) get_post_meta( $post_id, '_wpwebmcp_exposure_tier', true );
		$tier_explicit = in_array( $tier, array( 'cited', 'premium' ), true );

		$has_excerpt = '' !== trim( (string) ( $post->post_excerpt ?: '' ) );
		if ( ! $has_excerpt ) {
			// Fallback: meta description from common SEO plugins (Yoast / RankMath).
			$yoast_desc = (string) get_post_meta( $post_id, '_yoast_wpseo_metadesc', true );
			$rank_desc  = (string) get_post_meta( $post_id, 'rank_math_description', true );
			$has_excerpt = ( '' !== $yoast_desc || '' !== $rank_desc );
		}

		$has_featured = has_post_thumbnail( $post_id );

		$breakdown = array(
			array(
				'label'  => __( 'JSON-LD markup present', 'webmcp-nexus' ),
				'passes' => $has_jsonld,
				'points' => 20,
				'hint'   => $has_jsonld
					? sprintf(
						/* translators: %s: comma-separated @type list */
						__( 'Detected @types: %s', 'webmcp-nexus' ),
						implode( ', ', $jsonld_types )
					)
					: __( 'Add <script type="application/ld+json">…</script> blocks to your post content.', 'webmcp-nexus' ),
			),
			array(
				'label'  => __( 'FAQPage / HowTo schema present', 'webmcp-nexus' ),
				'passes' => $has_faq_or_howto,
				'points' => 20,
				'hint'   => $has_faq_or_howto
					? __( 'Agents can extract structured FAQ / how-to steps directly.', 'webmcp-nexus' )
					: __( 'Add an FAQPage or HowTo block — these are the highest-citation schemas.', 'webmcp-nexus' ),
			),
			array(
				'label'  => __( 'Article schema with author + datePublished', 'webmcp-nexus' ),
				'passes' => $article_author_date,
				'points' => 10,
				'hint'   => $article_author_date
					? __( 'E-E-A-T signals present.', 'webmcp-nexus' )
					: __( 'Add author.name and datePublished to your Article schema block.', 'webmcp-nexus' ),
			),
			array(
				'label'  => __( 'Freshness ping metadata stored', 'webmcp-nexus' ),
				'passes' => $has_freshness,
				'points' => 10,
				'hint'   => $has_freshness
					? __( 'IndexNow pings will fire on update.', 'webmcp-nexus' )
					: __( 'Update the post once — A1c will stamp it.', 'webmcp-nexus' ),
			),
			array(
				'label'  => __( 'Exposure tier explicitly set (cited / premium)', 'webmcp-nexus' ),
				'passes' => $tier_explicit,
				'points' => 15,
				'hint'   => $tier_explicit
					? sprintf(
						/* translators: %s: tier name */
						__( 'Tier: %s', 'webmcp-nexus' ),
						$tier
					)
					: __( 'Mark this post as "Cited only" or "Premium" if the citation must require proof.', 'webmcp-nexus' ),
			),
			array(
				'label'  => __( 'Excerpt / meta description filled', 'webmcp-nexus' ),
				'passes' => $has_excerpt,
				'points' => 15,
				'hint'   => $has_excerpt
					? __( 'Quoted snippet available for agents.', 'webmcp-nexus' )
					: __( 'Fill the post excerpt or Yoast / RankMath meta description.', 'webmcp-nexus' ),
			),
			array(
				'label'  => __( 'Featured image set', 'webmcp-nexus' ),
				'passes' => $has_featured,
				'points' => 10,
				'hint'   => $has_featured
					? __( 'ImageObject schema available.', 'webmcp-nexus' )
					: __( 'Set a featured image for richer citation cards.', 'webmcp-nexus' ),
			),
		);

		$total = 0;
		foreach ( $breakdown as $row ) {
			if ( $row['passes'] ) {
				$total += (int) $row['points'];
			}
		}

		return array(
			'post_id'    => $post_id,
			'post_title' => (string) $post->post_title,
			'post_type'  => (string) $post->post_type,
			'total'      => (int) $total,
			'max'        => 100,
			'grade'      => self::grade( (int) $total ),
			'breakdown'  => $breakdown,
		);
	}

	/**
	 * Build a per-post leaderboard — top N (default 10) by score, descending
	 * or ascending. Bounded scan (default 500 posts) for performance.
	 *
	 * @param string $direction 'top' (highest first) or 'bottom' (lowest first).
	 * @param int    $limit      Number of rows to return.
	 * @param int    $max_posts  Hard cap on posts scanned.
	 * @return array<int, array<string, mixed>>
	 */
	public static function leaderboard( string $direction = 'top', int $limit = 10, int $max_posts = 500 ): array {
		global $wpdb;
		$limit      = max( 1, min( 50, $limit ) );
		$max_posts  = max( 1, min( 2000, $max_posts ) );
		$direction  = ( 'bottom' === $direction ) ? 'bottom' : 'top';

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoFuzzy
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ('post', 'page') ORDER BY ID DESC LIMIT %d",
				$max_posts
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoFuzzy

		$rows = array();
		foreach ( (array) $ids as $id ) {
			$audit = self::audit_post( (int) $id );
			if ( isset( $audit['error'] ) ) {
				continue;
			}
			$rows[] = $audit;
		}

		if ( 'bottom' === $direction ) {
			usort(
				$rows,
				static function ( $a, $b ) {
					$ta = (int) $a['total']; $tb = (int) $b['total'];
					if ( $ta === $tb ) { return (int) $b['post_id'] <=> (int) $a['post_id']; }
					return $ta <=> $tb;
				}
			);
		} else {
			usort(
				$rows,
				static function ( $a, $b ) {
					$ta = (int) $a['total']; $tb = (int) $b['total'];
					if ( $ta === $tb ) { return (int) $b['post_id'] <=> (int) $a['post_id']; }
					return $tb <=> $ta;
				}
			);
		}

		return array_slice( $rows, 0, $limit );
	}

	/* ---------- internals ---------- */

	/**
	 * Extract @type list from inline JSON-LD blocks in post content.
	 *
	 * @return string[]
	 */
	private static function extract_jsonld_types( string $content ): array {
		if ( '' === $content || false === stripos( $content, 'application/ld+json' ) ) {
			return array();
		}
		$found = preg_match_all(
			'#<script[^>]+type\s*=\s*["\']application/ld\+json["\'][^>]*>(.*?)</script>#is',
			$content,
			$m
		);
		if ( ! $found ) {
			return array();
		}
		$types = array();
		foreach ( $m[1] as $raw ) {
			$trim = trim( $raw );
			if ( '' === $trim || ( '{' !== substr( $trim, 0, 1 ) && '[' !== substr( $trim, 0, 1 ) ) ) {
				continue;
			}
			$decoded = json_decode( $trim, true );
			if ( ! is_array( $decoded ) ) {
				continue;
			}
			self::collect_types_recursive( $decoded, $types );
		}
		return array_values( array_unique( $types ) );
	}

	/**
	 * @param mixed $node
	 * @param string[] $types
	 */
	private static function collect_types_recursive( $node, array &$types ): void {
		if ( ! is_array( $node ) ) {
			return;
		}
		if ( isset( $node['@type'] ) ) {
			$t = $node['@type'];
			if ( is_string( $t ) ) {
				$types[] = $t;
			} elseif ( is_array( $t ) ) {
				foreach ( $t as $sub ) {
					if ( is_string( $sub ) ) {
						$types[] = $sub;
					}
				}
			}
		}
		if ( isset( $node['@graph'] ) && is_array( $node['@graph'] ) ) {
			foreach ( $node['@graph'] as $child ) {
				self::collect_types_recursive( $child, $types );
			}
		}
	}

	/**
	 * @param string[] $haystack
	 * @param string[] $needles
	 */
	private static function contains_any_type( array $haystack, array $needles ): bool {
		foreach ( $needles as $n ) {
			if ( in_array( $n, $haystack, true ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Look for an Article-class node inside the JSON-LD and confirm it
	 * carries author.name and datePublished.
	 */
	private static function article_node_has_author_and_date( string $content ): bool {
		if ( '' === $content ) {
			return false;
		}
		$found = preg_match_all(
			'#<script[^>]+type\s*=\s*["\']application/ld\+json["\'][^>]*>(.*?)</script>#is',
			$content,
			$m
		);
		if ( ! $found ) {
			return false;
		}
		foreach ( $m[1] as $raw ) {
			$decoded = json_decode( trim( $raw ), true );
			if ( ! is_array( $decoded ) ) {
				continue;
			}
			$node = self::find_first_node_with_type( $decoded, array( 'Article', 'NewsArticle', 'BlogPosting', 'TechArticle' ) );
			if ( null === $node ) {
				continue;
			}
			$has_author = isset( $node['author'] );
			$has_date   = isset( $node['datePublished'] );
			if ( $has_author && $has_date ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param array<string, mixed> $root
	 * @param string[] $types
	 * @return array<string, mixed>|null
	 */
	private static function find_first_node_with_type( array $root, array $types ): ?array {
		if ( isset( $root['@type'] ) ) {
			$t = $root['@type'];
			$match = is_string( $t ) ? in_array( $t, $types, true ) : ( is_array( $t ) && array_intersect( $t, $types ) );
			if ( $match ) {
				return $root;
			}
		}
		if ( isset( $root['@graph'] ) && is_array( $root['@graph'] ) ) {
			foreach ( $root['@graph'] as $child ) {
				if ( is_array( $child ) ) {
					$found = self::find_first_node_with_type( $child, $types );
					if ( null !== $found ) {
						return $found;
					}
				}
			}
		}
		return null;
	}

	/**
	 * Map a numeric score to a human-readable grade band.
	 */
	private static function grade( int $total ): string {
		if ( $total >= 90 ) { return 'A'; }
		if ( $total >= 75 ) { return 'B'; }
		if ( $total >= 50 ) { return 'C'; }
		if ( $total >= 25 ) { return 'D'; }
		if ( $total >  0 )  { return 'F'; }
		return 'F0';
	}
// phpcs:enable WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery
}
