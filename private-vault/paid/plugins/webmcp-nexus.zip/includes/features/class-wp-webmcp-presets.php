<?php
/**
 * Done-For-You (DFY) Industry Vertical Presets Engine.
 *
 * Pre-packages complete, turnkey tool suites and settings for 8 major industry verticals:
 *   1. E-Commerce & Store (WooCommerce)
 *   2. News, Magazine & Media
 *   3. SaaS & Tech Documentation
 *   4. Blog & Editorial Content
 *   5. Video, Podcast & Course LMS
 *   6. Events, Venues & Communities
 *   7. Agency, Services & Lead Generation
 *   8. Real Estate & Listings Directory
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Presets {

	/**
	 * Available DFY Presets.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function get_presets(): array {
		return array(
			'ecommerce' => array(
				'name'        => __( 'E-Commerce & Store (WooCommerce)', 'webmcp-nexus' ),
				'icon'        => '🛒',
				'description' => __( 'Turn your store into an AI-powered shopping assistant. Allows agents to search products, check stock, verify coupons, manage carts, and assist customers.', 'webmcp-nexus' ),
				'vertical'    => 'woo',
				'tools'       => array( 'getProductDetails', 'searchProducts', 'checkStock', 'getCartContents', 'addToCart', 'updateQuantity', 'removeItem', 'applyCoupon' ),
				'prompts'     => array( 'find-best-deal', 'compare-products', 'cart-summary' ),
				'options'     => array(
					'wpwebmcp_default_context'   => 'woo',
					'wpwebmcp_token_optimize'    => true,
					'wpwebmcp_max_calls_session' => 300,
					'wpwebmcp_markdown_negotiation' => true,
				),
				'sample_agent_prompt' => __( 'Find wireless headphones under $100 in stock and add the highest rated to my cart.', 'webmcp-nexus' ),
			),
			'news' => array(
				'name'        => __( 'News, Magazine & Media', 'webmcp-nexus' ),
				'icon'        => '📰',
				'description' => __( 'Empower AI search engines and readers with instant breaking news summaries, topic deep dives, fact-checking citations, and editorial staff verification.', 'webmcp-nexus' ),
				'vertical'    => 'news',
				'tools'       => array( 'getBreakingNews', 'getArticlesByTopic', 'getTrendingNews', 'getFactCheckSummary', 'getEditorialStaff' ),
				'prompts'     => array( 'morning-digest', 'topic-analysis', 'fact-check-article' ),
				'options'     => array(
					'wpwebmcp_default_context'   => 'news',
					'wpwebmcp_token_optimize'    => false,
					'wpwebmcp_max_calls_session' => 500,
					'wpwebmcp_markdown_negotiation' => true,
				),
				'sample_agent_prompt' => __( 'Give me a 3-bullet briefing on today\'s top breaking tech news from this site.', 'webmcp-nexus' ),
			),
			'tech_docs' => array(
				'name'        => __( 'SaaS & Tech Documentation', 'webmcp-nexus' ),
				'icon'        => '💻',
				'description' => __( 'Connect developer IDEs (Cursor, Claude Desktop) directly to your docs. Enables live code snippet retrieval, API reference lookups, and changelog diffs.', 'webmcp-nexus' ),
				'vertical'    => 'tech',
				'tools'       => array( 'searchDocumentation', 'getApiReference', 'getCodeSnippet', 'getVersionChangelog', 'getTechnicalSpecs' ),
				'prompts'     => array( 'extract-code-example', 'explain-api-endpoint', 'troubleshoot-error' ),
				'options'     => array(
					'wpwebmcp_default_context'   => 'tech',
					'wpwebmcp_token_optimize'    => true,
					'wpwebmcp_max_calls_session' => 400,
					'wpwebmcp_markdown_negotiation' => true,
				),
				'sample_agent_prompt' => __( 'Find the Python code snippet for authenticating with the API from these docs.', 'webmcp-nexus' ),
			),
			'blog' => array(
				'name'        => __( 'Blog & Editorial Content', 'webmcp-nexus' ),
				'icon'        => '📚',
				'description' => __( 'Boost your blog\'s AI discoverability. Generates executive TL;DRs, reading time calculations, author profile queries, and category browsing.', 'webmcp-nexus' ),
				'vertical'    => 'blog',
				'tools'       => array( 'getLatestArticles', 'getPopularArticles', 'getAuthorProfile', 'estimateReadingTime', 'getNewsletterInfo', 'listCategories', 'listTags' ),
				'prompts'     => array( 'summarize-post', 'extract-key-takeaways', 'recommend-reading' ),
				'options'     => array(
					'wpwebmcp_default_context'   => 'blog',
					'wpwebmcp_token_optimize'    => true,
					'wpwebmcp_max_calls_session' => 200,
					'wpwebmcp_markdown_negotiation' => true,
				),
				'sample_agent_prompt' => __( 'Summarize the 5 main takeaways from the latest article on this blog.', 'webmcp-nexus' ),
			),
			'video' => array(
				'name'        => __( 'Video, Podcast & Course LMS', 'webmcp-nexus' ),
				'icon'        => '🎥',
				'description' => __( 'Make multimedia content conversational. Agents can search transcripts, jump to specific chapter timestamps, and explore course playlists.', 'webmcp-nexus' ),
				'vertical'    => 'video',
				'tools'       => array( 'searchVideos', 'getVideoDetails', 'getVideoTranscript', 'getChapterTimestamps', 'getPlaylists' ),
				'prompts'     => array( 'search-transcript', 'find-chapter-by-topic' ),
				'options'     => array(
					'wpwebmcp_default_context'   => 'video',
					'wpwebmcp_token_optimize'    => false,
					'wpwebmcp_max_calls_session' => 300,
					'wpwebmcp_markdown_negotiation' => true,
				),
				'sample_agent_prompt' => __( 'What timestamp in this tutorial explains database migrations?', 'webmcp-nexus' ),
			),
			'events' => array(
				'name'        => __( 'Events, Venues & Communities', 'webmcp-nexus' ),
				'icon'        => '📅',
				'description' => __( 'Help attendees discover upcoming conferences, workshops, and meetup sessions with speaker bios and ticket availability.', 'webmcp-nexus' ),
				'vertical'    => 'events',
				'tools'       => array( 'getUpcomingEvents', 'getEventDetails', 'searchEvents' ),
				'prompts'     => array( 'find-events-by-date', 'speaker-schedule' ),
				'options'     => array(
					'wpwebmcp_default_context'   => 'events',
					'wpwebmcp_token_optimize'    => true,
					'wpwebmcp_max_calls_session' => 200,
					'wpwebmcp_markdown_negotiation' => true,
				),
				'sample_agent_prompt' => __( 'Find all upcoming design workshops in Berlin next month.', 'webmcp-nexus' ),
			),
			'leadgen' => array(
				'name'        => __( 'Agency, Services & Lead Gen', 'webmcp-nexus' ),
				'icon'        => '🏢',
				'description' => __( 'Convert AI interactions into qualified leads. Includes automatic consultation scheduling, quote requests, and service inquiry tools.', 'webmcp-nexus' ),
				'vertical'    => 'homepage',
				'tools'       => array( 'getSiteInfo', 'searchSite', 'navigateTo' ),
				'prompts'     => array( 'schedule-consultation', 'request-quote', 'list-services' ),
				'options'     => array(
					'wpwebmcp_default_context'   => 'homepage',
					'wpwebmcp_token_optimize'    => true,
					'wpwebmcp_max_calls_session' => 250,
					'wpwebmcp_markdown_negotiation' => true,
				),
				'sample_agent_prompt' => __( 'What services does this agency offer, and how can I schedule an introductory call?', 'webmcp-nexus' ),
			),
			'real_estate' => array(
				'name'        => __( 'Real Estate & Listings Directory', 'webmcp-nexus' ),
				'icon'        => '🏡',
				'description' => __( 'Help buyers and renters find matching properties by location, price range, bedrooms, and schedule viewing appointments.', 'webmcp-nexus' ),
				'vertical'    => 'homepage',
				'tools'       => array( 'getSiteInfo', 'searchSite', 'getFeaturedContent', 'navigateTo' ),
				'prompts'     => array( 'find-properties', 'schedule-viewing' ),
				'options'     => array(
					'wpwebmcp_default_context'   => 'homepage',
					'wpwebmcp_token_optimize'    => true,
					'wpwebmcp_max_calls_session' => 300,
					'wpwebmcp_markdown_negotiation' => true,
				),
				'sample_agent_prompt' => __( 'Find 2-bedroom apartments for rent under $2,500/month on this site.', 'webmcp-nexus' ),
			),
		);
	}

	/**
	 * Apply a DFY preset to the active WordPress installation.
	 *
	 * @param string $preset_key
	 * @return bool
	 */
	public static function apply_preset( string $preset_key ): bool {
		$presets = self::get_presets();
		if ( ! isset( $presets[ $preset_key ] ) ) {
			return false;
		}

		$preset = $presets[ $preset_key ];

		// Update options
		if ( isset( $preset['options'] ) && is_array( $preset['options'] ) ) {
			foreach ( $preset['options'] as $opt_key => $opt_val ) {
				update_option( $opt_key, $opt_val );
			}
		}

		update_option( 'wpwebmcp_active_preset', $preset_key );
		update_option( 'wpwebmcp_enabled', true );

		// Flush rewrite rules for llms.txt & endpoints
		flush_rewrite_rules();

		return true;
	}

	/**
	 * Get current active preset key.
	 *
	 * @return string
	 */
	public static function get_active_preset(): string {
		$preset = (string) get_option( 'wpwebmcp_active_preset', '' );
		if ( '' !== $preset ) {
			return $preset;
		}

		// Auto-detect based on active plugins
		if ( class_exists( 'WooCommerce' ) ) {
			return 'ecommerce';
		}

		return 'blog';
	}
}
