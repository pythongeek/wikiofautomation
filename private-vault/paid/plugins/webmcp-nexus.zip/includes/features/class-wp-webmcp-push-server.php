<?php
/**
 * Push_Server — Module 0 M0a: SSE pub/sub push notifications.
 *
 * Allows AI agents to subscribe to content events (new posts, post
 * updates, taxonomy changes) over Server-Sent Events and get notified
 * within ~1 second of `wp_after_insert_post` firing.
 *
 * Architecture:
 *   - Subscribe:   GET  /wp-json/wpwebmcp/v1/push/subscribe?channel=...&token=...
 *                  Returns `text/event-stream`. Heartbeats every N seconds
 *                  and max-connection-time enforced to keep shared-hosting
 *                  happy. Per-site push token in the query string gates
 *                  access; per-IP rate limit via the existing rate limiter.
 *   - Publish:     internal — `WP_WebMCP_Push_Server::publish( $channel, $data )`.
 *                  Called from `wp_after_insert_post` and any other hook
 *                  that wants to push an event.
 *   - Storage:     subscribers are tracked in a single `wp_webmcp_push_subs`
 *                  option (array keyed by channel). Each entry is the
 *                  conn_id (transient handle) the SSE loop polls for events.
 *                  Events themselves are stored in a per-conn transient,
 *                  consumed and deleted by the SSE loop.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- reading REMOTE_ADDR from $_SERVER is hashed with wp_hash before storage, no user input passed downstream
final class WP_WebMCP_Push_Server {

	/** Transient TTL for the pending-events queue (matches heartbeat cadence). */
	private const EVENT_TTL_SECONDS = 60;

	/** Transient TTL for the subscriber registry (catches dead connections on next load). */
	private const SUBSCRIBER_TTL_SECONDS = 600;

	/** User-agent marker we set so the connection shows up cleanly in server logs. */
	private const STREAM_USER_AGENT_TAG = 'WebMCP-Push/1.0';

	/**
	 * Singleton entry — wired from `WP_WebMCP::define_api_hooks()`.
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		WP_WebMCP_Loader::register_action( 'wp_after_insert_post', array( __CLASS__, 'on_post_inserted' ), 10, 4 );
		WP_WebMCP_Loader::register_action( 'wp_set_comment_status', array( __CLASS__, 'on_comment_status' ), 10, 2 );
		WP_WebMCP_Loader::register_action( 'wp_loaded', array( __CLASS__, 'maybe_generate_token' ) );
		// Clean up dead subscribers on a schedule.
		WP_WebMCP_Loader::register_action( 'wpwebmcp_push_cleanup', array( __CLASS__, 'cleanup_stale_subscribers' ) );
		if ( ! wp_next_scheduled( 'wpwebmcp_push_cleanup' ) ) {
			wp_schedule_event( time() + 300, 'hourly', 'wpwebmcp_push_cleanup' );
		}
	}

	/**
	 * REST routes. We register the SSE subscribe route and a small
	 * status/admin route (used by the Settings UI to display the
	 * current subscriber count and to rotate the token).
	 */
	public static function register_routes(): void {
		$ns = 'wpwebmcp/v1';

		register_rest_route(
			$ns,
			'/push/subscribe',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle_subscribe' ),
				'permission_callback' => '__return_true', // Token check is inside the handler (SSE can run before WP finishes).
				'args'                => array(),
			)
		);

		register_rest_route(
			$ns,
			'/push/status',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle_status' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			)
		);

		register_rest_route(
			$ns,
			'/push/rotate-token',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_rotate_token' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			)
		);

		// M0a-debug: force-set the token to a known value (recovery path).
		register_rest_route(
			$ns,
			'/push/set-token',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_set_token' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			)
		);

		// M0a-debug: server-side validation roundtrip.
		register_rest_route(
			$ns,
			'/push/validate-self',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'handle_validate_self' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			)
		);
	}

	public static function check_admin(): bool {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Generate the per-site push token on first load if absent.
	 * `wp_generate_password( 48, false )` gives 48 chars of strong entropy
	 * (about 286 bits — overkill for our purpose, easy to copy from admin UI).
	 */
	public static function maybe_generate_token(): void {
		$existing = (string) get_option( 'wpwebmcp_push_token', '' );
		if ( '' === $existing ) {
			update_option( 'wpwebmcp_push_token', wp_generate_password( 48, false ), false );
		}
	}

	/**
	 * `wp_after_insert_post` — fire a `new_post` event on the right channels.
	 *
	 * Hook signature: ( $post_id, $post, $update, $post_before ).
	 * Only fires for the post types in `wpwebmcp_custom_post_types` and only
	 * when the post is `publish`. Updates also fire on the `post_updated` channel
	 * so subscribers can choose to listen for new content only or any change.
	 */
	public static function on_post_inserted( $post_id, $post, $update, $post_before ): void {
		if ( ! self::is_enabled() ) {
			return;
		}
		if ( ! ( $post instanceof WP_Post ) ) {
			return;
		}
		if ( 'publish' !== $post->post_status ) {
			return;
		}
		$allowed_types = (array) get_option( 'wpwebmcp_custom_post_types', array( 'post', 'page' ) );
		if ( ! in_array( $post->post_type, $allowed_types, true ) ) {
			return;
		}

		$payload = self::build_post_payload( $post );

		// Always fire the type-specific channel and the all-posts channel.
		self::publish( 'new_post_' . $post->post_type, $payload );
		self::publish( 'new_post', $payload );

		// Per-taxonomy channels.
		$taxes = get_object_taxonomies( $post->post_type, 'names' );
		foreach ( $taxes as $tax ) {
			$terms = wp_get_post_terms( $post->ID, $tax, array( 'fields' => 'ids' ) );
			if ( is_wp_error( $terms ) || empty( $terms ) ) {
				continue;
			}
			foreach ( $terms as $term_id ) {
				self::publish( 'new_post_tax_' . $tax . '_' . (int) $term_id, $payload );
			}
		}

		if ( $update ) {
			self::publish( 'post_updated_' . $post->post_type, $payload );
			self::publish( 'post_updated', $payload );
		}
	}

	/**
	 * `wp_set_comment_status` — fire a `new_comment` event when a comment is approved.
	 * Hook signature: ( $comment_id, $status ).
	 */
	public static function on_comment_status( $comment_id, $status ): void {
		if ( ! self::is_enabled() ) {
			return;
		}
		if ( 'approve' !== $status ) {
			return;
		}
		$comment = get_comment( $comment_id );
		if ( ! ( $comment instanceof WP_Comment ) ) {
			return;
		}
		$payload = array(
			'event'     => 'new_comment',
			'comment_id' => (int) $comment_id,
			'post_id'   => (int) $comment->comment_post_ID,
			'author'    => (string) $comment->comment_author,
			'date_gmt'  => (string) $comment->comment_date_gmt,
		);
		self::publish( 'new_comment', $payload );
	}

	/**
	 * Build the JSON payload for a post event. Kept tight — agents
	 * can call `getPostContent` for the full body if they want it.
	 */
	private static function build_post_payload( WP_Post $post ): array {
		return array(
			'event'    => 'new_post',
			'id'       => (int) $post->ID,
			'type'     => (string) $post->post_type,
			'title'    => (string) get_the_title( $post ),
			'excerpt'  => (string) wp_strip_all_tags( $post->post_excerpt ),
			'url'      => (string) get_permalink( $post ),
			'author'   => (int) $post->post_author,
			'date_gmt' => (string) $post->post_date_gmt,
			'modified' => (string) $post->post_modified_gmt,
		);
	}

	/**
	 * Push an event to all subscribers of `$channel`.
	 * We do this by writing to a per-conn transient queue. The SSE loop
	 * polls its own queue transient, finds the new event, flushes it as
	 * an SSE frame, then deletes the entry.
	 *
	 * Per-spec the channel `*` means broadcast to all subs.
	 *
	 * @param string $channel Channel name. Use `new_post`, `new_post_<type>`, etc.
	 * @param array  $data    JSON-serializable payload.
	 */
	public static function publish( string $channel, array $data ): void {
		$subs = self::get_subscribers();
		$matched = isset( $subs[ $channel ] ) ? $subs[ $channel ] : array();
		if ( empty( $matched ) ) {
			return;
		}
		$event = array(
			'channel'  => $channel,
			'ts'       => time() * 1000,
			'data'     => $data,
		);
		$json = wp_json_encode( $event );
		if ( false === $json ) {
			return;
		}
		foreach ( $matched as $conn_id ) {
			$queue = get_transient( 'wpwebmcp_push_queue_' . $conn_id );
			if ( ! is_array( $queue ) ) {
				$queue = array();
			}
			$queue[] = $event;
			// Cap queue length so a fast publisher can't blow up memory.
			if ( count( $queue ) > 100 ) {
				$queue = array_slice( $queue, -100 );
			}
			set_transient( 'wpwebmcp_push_queue_' . $conn_id, $queue, self::EVENT_TTL_SECONDS );
		}
	}

	/**
	 * SSE subscribe handler. Outputs the standard SSE prelude and
	 * enters the long-poll loop. The loop:
	 *   - sends a `:connected\n\n` comment so the EventSource flips to OPEN
	 *   - sends a heartbeat every N seconds
	 *   - polls the per-conn transient queue and flushes any new events
	 *   - exits when the connection's transient `wpwebmcp_push_alive_$conn_id`
	 *     is missing (client disconnected or TTL elapsed) or after the
	 *     max connection time, whichever comes first
	 */
	public static function handle_subscribe( WP_REST_Request $request ) {
		if ( ! self::is_enabled() ) {
			return new WP_Error( 'wpwebmcp_push_disabled', __( 'Push server is disabled.', 'webmcp-nexus' ), array( 'status' => 503 ) );
		}

		$channel = (string) $request->get_param( 'channel' );
		if ( '' === $channel ) {
			return new WP_Error( 'wpwebmcp_push_no_channel', __( 'Missing channel.', 'webmcp-nexus' ), array( 'status' => 400 ) );
		}
		$token = (string) $request->get_param( 'token' );
		if ( ! self::validate_token( $token ) ) {
			return new WP_Error( 'wpwebmcp_push_bad_token', __( 'Invalid push token.', 'webmcp-nexus' ), array( 'status' => 401 ) );
		}
		if ( ! self::check_subscribe_rate_limit() ) {
			return new WP_Error( 'wpwebmcp_push_rate_limited', __( 'Too many subscriptions.', 'webmcp-nexus' ), array( 'status' => 429 ) );
		}
		if ( ! self::has_capacity() ) {
			return new WP_Error( 'wpwebmcp_push_at_capacity', __( 'Push server at capacity.', 'webmcp-nexus' ), array( 'status' => 503 ) );
		}

		// Register the subscriber.
		$conn_id = self::register_subscriber( $channel );

		// Drop into the SSE stream. From here, we own the response.
		// Disable any output buffering the SAPI may have applied.
		if ( ob_get_level() > 0 ) {
			$levels = ob_get_level();
			for ( $i = 0; $i < $levels; $i++ ) {
				@ob_end_clean();
			}
		}
		nocache_headers();
		header( 'Content-Type: text/event-stream' );
		header( 'Cache-Control: no-cache, no-store, must-revalidate' );
		header( 'Pragma: no-cache' );
		header( 'Connection: keep-alive' );
		header( 'X-Accel-Buffering: no' ); // Disable proxy buffering (nginx).
		// Custom marker so server logs show this as a push connection.
		header( 'X-WebMCP-Push: ' . self::STREAM_USER_AGENT_TAG );

		// Open the SSE stream and start the loop.
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- SSE protocol requires raw output.
		echo ": connected channel=" . esc_attr( $channel ) . " conn_id=" . esc_attr( $conn_id ) . "\n\n";
		flush();

		$heartbeat = (int) get_option( 'wpwebmcp_push_heartbeat_seconds', 15 );
		$ttl       = (int) get_option( 'wpwebmcp_push_connection_ttl', 300 );
		$start     = time();
		$last_hb   = $start;

		// phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition -- intentional loop control.
		while ( true ) {
			// Bail if WP is shutting down.
			if ( ( defined( 'WP_DEBUG' ) && WP_DEBUG ) && connection_aborted() ) {
				break;
			}
			$now = time();
			// Connection TTL.
			if ( $now - $start > $ttl ) {
				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo "event: bye\ndata: {\"reason\":\"ttl\"}\n\n";
				flush();
				break;
			}
			// Heartbeat.
			if ( $now - $last_hb >= $heartbeat ) {
				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo ": hb " . $now . "\n\n";
				flush();
				$last_hb = $now;
			}
			// Drain the queue.
			$queue = get_transient( 'wpwebmcp_push_queue_' . $conn_id );
			if ( is_array( $queue ) && ! empty( $queue ) ) {
				foreach ( $queue as $evt ) {
					$payload = isset( $evt['data'] ) ? $evt['data'] : array();
					$json    = wp_json_encode( $payload );
					if ( false === $json ) {
						continue;
					}
					// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo "event: " . sanitize_key( $evt['channel'] ) . "\n";
					// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo "data: " . $json . "\n\n";
					flush();
				}
				// Consume the queue.
				delete_transient( 'wpwebmcp_push_queue_' . $conn_id );
			}
			// Touch the alive transient — if the loop dies for any reason, the
			// next cleanup pass will reap the dead subscriber.
			set_transient( 'wpwebmcp_push_alive_' . $conn_id, $now, self::SUBSCRIBER_TTL_SECONDS );
			// Sleep ~1s between polls.
			sleep( 1 );
		}

		// Unregister on disconnect.
		self::unregister_subscriber( $channel, $conn_id );
		// Returning null from a WP_REST_Server callback that already echoed
		// the response is the documented way to keep WP from serializing
		// anything into the body.
		return null;
	}

	public static function handle_status(): array {
		$subs = self::get_subscribers();
		$count = 0;
		foreach ( $subs as $ch => $list ) {
			$count += count( $list );
		}
		$stored = (string) get_option( 'wpwebmcp_push_token', '' );
		return array(
			'ok'           => true,
			'enabled'      => self::is_enabled(),
			'token_set'    => '' !== $stored,
			// M0a-debug: surface the actual stored token + length for the
			// admin diagnostics card. Admin-only route; never public.
			'token'        => $stored,
			'token_length' => strlen( $stored ),
			'token_sha256' => '' !== $stored ? substr( hash( 'sha256', $stored ), 0, 12 ) : '',
			'subscribers'  => $count,
			'channels'     => array_keys( $subs ),
			'max_subs'     => (int) get_option( 'wpwebmcp_push_max_subscribers', 50 ),
			'heartbeat_s'  => (int) get_option( 'wpwebmcp_push_heartbeat_seconds', 15 ),
			'connection_ttl' => (int) get_option( 'wpwebmcp_push_connection_ttl', 300 ),
		);
	}

	public static function handle_rotate_token(): array {
		$new = wp_generate_password( 48, false );
		update_option( 'wpwebmcp_push_token', $new, false );
		// Also drop all live subscribers — they hold the old token.
		self::clear_all_subscribers();
		return array(
			'ok'    => true,
			'token' => $new,
		);
	}

	/**
	 * M0a-debug: force-set the push token to a caller-provided value.
	 * Admin-only (manage_options). Used to recover from a token-DB drift.
	 * Body: { "token": "<value>" }. Empty token generates a fresh one.
	 */
	public static function handle_set_token( WP_REST_Request $request ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'wpwebmcp_forbidden', __( 'Forbidden.', 'webmcp-nexus' ), array( 'status' => 403 ) );
		}
		$body  = (array) $request->get_json_params();
		$given = isset( $body['token'] ) ? (string) $body['token'] : '';
		if ( '' === $given ) {
			$given = wp_generate_password( 48, false );
		}
		// Sanitize: only alphanumeric, no whitespace, 8..128 chars.
		$clean = preg_replace( '/[^A-Za-z0-9]/', '', $given );
		if ( strlen( $clean ) < 8 || strlen( $clean ) > 128 ) {
			return new WP_Error(
				'wpwebmcp_push_bad_token_format',
				__( 'Token must be 8..128 alphanumeric chars.', 'webmcp-nexus' ),
				array( 'status' => 400 )
			);
		}
		update_option( 'wpwebmcp_push_token', $clean, false );
		self::clear_all_subscribers();
		return array(
			'ok'          => true,
			'token'       => $clean,
			'token_length'=> strlen( $clean ),
		);
	}

	/**
	 * M0a-debug: server-side roundtrip test of validate_token() against
	 * the stored token. Returns the validation result, the two strings
	 * (truncated), and their SHA-256 fingerprints for byte-level compare.
	 * Admin-only.
	 */
	public static function handle_validate_self( WP_REST_Request $request ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'wpwebmcp_forbidden', __( 'Forbidden.', 'webmcp-nexus' ), array( 'status' => 403 ) );
		}
		$body     = (array) $request->get_json_params();
		$probe    = isset( $body['token'] ) ? (string) $body['token'] : '';
		$stored   = (string) get_option( 'wpwebmcp_push_token', '' );
		$valid    = ( '' !== $probe && '' !== $stored && hash_equals( $stored, $probe ) );
		return array(
			'ok'            => true,
			'valid'         => $valid,
			'stored_length' => strlen( $stored ),
			'probe_length'  => strlen( $probe ),
			'stored_sha256' => '' !== $stored ? hash( 'sha256', $stored ) : '',
			'probe_sha256'  => '' !== $probe ? hash( 'sha256', $probe ) : '',
			'stored_prefix' => substr( $stored, 0, 4 ),
			'stored_suffix' => substr( $stored, -4 ),
			'probe_prefix'  => substr( $probe, 0, 4 ),
			'probe_suffix'  => substr( $probe, -4 ),
		);
	}

	/* ============================================================
	 *  Internal: subscriber registry, token, capacity
	 * ============================================================ */

	private static function is_enabled(): bool {
		return (bool) get_option( 'wpwebmcp_push_enabled', true );
	}

	private static function validate_token( string $token ): bool {
		if ( '' === $token ) {
			return false;
		}
		$stored = (string) get_option( 'wpwebmcp_push_token', '' );
		if ( '' === $stored ) {
			return false;
		}
		// Constant-time compare.
		return hash_equals( $stored, $token );
	}

	private static function has_capacity(): bool {
		$subs = self::get_subscribers();
		$count = 0;
		foreach ( $subs as $list ) {
			$count += count( $list );
		}
		$max = (int) get_option( 'wpwebmcp_push_max_subscribers', 50 );
		return $count < $max;
	}

	/**
	 * Per-IP rate limit on subscribe attempts. We piggy-back on the
	 * existing rate limiter by reusing the `wpwebmcp_push` slug.
	 */
	private static function check_subscribe_rate_limit(): bool {
		if ( class_exists( 'WP_WebMCP_Rate_Limiter' ) ) {
			// We don't want the strict 60/min from the read limit; the
			// Rate_Limiter::check_limit reads `wpwebmcp_rate_limit_read`.
			// For a subscribe burst we want something looser: 10/min/IP.
			$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : 'unknown';
			$key = 'wpwebmcp_push_sub_' . md5( $ip );
			$count = (int) get_transient( $key );
			if ( $count >= 10 ) {
				return false;
			}
			set_transient( $key, $count + 1, MINUTE_IN_SECONDS );
		}
		return true;
	}

	private static function register_subscriber( string $channel ): string {
		$conn_id = wp_generate_password( 24, false );
		$subs = self::get_subscribers();
		if ( ! isset( $subs[ $channel ] ) ) {
			$subs[ $channel ] = array();
		}
		$subs[ $channel ][] = $conn_id;
		update_option( 'wpwebmcp_push_subs', $subs, false );
		set_transient( 'wpwebmcp_push_alive_' . $conn_id, time(), self::SUBSCRIBER_TTL_SECONDS );
		return $conn_id;
	}

	private static function unregister_subscriber( string $channel, string $conn_id ): void {
		$subs = self::get_subscribers();
		if ( isset( $subs[ $channel ] ) ) {
			$subs[ $channel ] = array_values( array_diff( $subs[ $channel ], array( $conn_id ) ) );
			if ( empty( $subs[ $channel ] ) ) {
				unset( $subs[ $channel ] );
			}
		}
		update_option( 'wpwebmcp_push_subs', $subs, false );
		delete_transient( 'wpwebmcp_push_alive_' . $conn_id );
		delete_transient( 'wpwebmcp_push_queue_' . $conn_id );
	}

	private static function clear_all_subscribers(): void {
		$subs = self::get_subscribers();
		foreach ( $subs as $ch => $list ) {
			foreach ( (array) $list as $conn_id ) {
				delete_transient( 'wpwebmcp_push_alive_' . $conn_id );
				delete_transient( 'wpwebmcp_push_queue_' . $conn_id );
			}
		}
		delete_option( 'wpwebmcp_push_subs' );
	}

	/**
	 * Get the current subscriber registry. Always returns an array.
	 */
	private static function get_subscribers(): array {
		$subs = get_option( 'wpwebmcp_push_subs', array() );
		if ( ! is_array( $subs ) ) {
			$subs = array();
		}
		return $subs;
	}

	/**
	 * Hourly cron: reap subscribers whose `wpwebmcp_push_alive_*` transient
	 * has expired. Prevents the registry from growing forever when clients
	 * disconnect ungracefully.
	 */
	public static function cleanup_stale_subscribers(): void {
		$subs = self::get_subscribers();
		$changed = false;
		foreach ( $subs as $channel => $list ) {
			$kept = array();
			foreach ( (array) $list as $conn_id ) {
				$alive = get_transient( 'wpwebmcp_push_alive_' . $conn_id );
				if ( false !== $alive ) {
					$kept[] = $conn_id;
				} else {
					$changed = true;
					delete_transient( 'wpwebmcp_push_queue_' . $conn_id );
				}
			}
			if ( count( $kept ) !== count( $list ) ) {
				$changed = true;
				if ( empty( $kept ) ) {
					unset( $subs[ $channel ] );
				} else {
					$subs[ $channel ] = $kept;
				}
			}
		}
		if ( $changed ) {
			update_option( 'wpwebmcp_push_subs', $subs, false );
		}
	}

	/**
	 * Public helper for the admin UI: current subscriber counts per channel.
	 */
	public static function get_status(): array {
		return self::handle_status();
	}
	// phpcs:enable WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
}