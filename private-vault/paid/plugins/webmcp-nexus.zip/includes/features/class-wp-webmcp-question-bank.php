<?php
/**
 * Question Bank — Module A A3a (AEO Intelligence — Answer-Gap Detector).
 *
 * Static, per-vertical question catalogue used as the input set for the
 * gap detector. Each entry maps a real-world user query to:
 *   - expected_intent: which tool family the query SHOULD be answerable by
 *     (free-text, matched fuzzily against existing tool names + descriptions).
 *   - suggested_tool: ready-to-create tool template if no match is found
 *     (same shape as WP_WebMCP_Schema_Tool_Suggester::TEMPLATES entries).
 *
 * Bank is curated, not generated. Real users actually ask these questions
 * — the bank's purpose is to surface "I have no tool for this query" so the
 * admin can either accept the suggestion or refine the question.
 *
 * Adding new verticals: append a key to QUESTION_BANK with a non-empty list
 * of {query, expected_intent, suggested_tool} entries.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Question_Bank {

	/**
	 * Vertical list — used by the REST endpoint and admin UI to populate the
	 * segment filter dropdown.
	 *
	 * @return string[]
	 */
	public static function verticals(): array {
		return array( 'news', 'ecommerce', 'tech_docs', 'blog', 'video', 'events', 'local_business' );
	}

	/**
	 * Display labels per vertical.
	 *
	 * @return array<string, string>
	 */
	public static function vertical_labels(): array {
		return array(
			'news'            => __( 'News / Magazine', 'webmcp-nexus' ),
			'ecommerce'       => __( 'E-Commerce / WooCommerce', 'webmcp-nexus' ),
			'tech_docs'       => __( 'SaaS / Tech Docs', 'webmcp-nexus' ),
			'blog'            => __( 'Blog / Editorial', 'webmcp-nexus' ),
			'video'           => __( 'Video / Podcast / LMS', 'webmcp-nexus' ),
			'events'          => __( 'Events / Venues', 'webmcp-nexus' ),
			'local_business'  => __( 'Local Business', 'webmcp-nexus' ),
		);
	}

	/**
	 * The full question catalogue. Each entry:
	 *   - query           natural-language user question (lowercase, no punctuation)
	 *   - expected_intent free-text hint matched against tool name + description
	 *   - suggested_tool  template suggested if no match (same shape as A3c templates)
	 *
	 * @return array<string, array<int, array<string, mixed>>>
	 */
	public static function QUESTION_BANK(): array {
		return array(
			'news' => array(
				array(
					'query'           => 'what is the top breaking news right now',
					'expected_intent' => 'breaking news headlines urgent',
					'suggested_tool'  => array(
						'slug'         => 'getBreakingNews',
						'name'         => 'Get Breaking News',
						'description'  => 'Returns the latest breaking news headlines for AI agents that ask for current urgent stories.',
						'parameters'   => array(
							'limit' => array( 'type' => 'integer', 'description' => 'Maximum number of headlines to return.', 'required' => false ),
						),
					),
				),
				array(
					'query'           => 'show me articles about a specific topic',
					'expected_intent' => 'articles topic category filter',
					'suggested_tool'  => array(
						'slug'         => 'getArticlesByTopic',
						'name'         => 'Get Articles by Topic',
						'description'  => 'Returns articles filtered by topic, category, or tag.',
						'parameters'   => array(
							'topic' => array( 'type' => 'string', 'description' => 'Topic, category, or tag slug.', 'required' => true ),
						),
					),
				),
				array(
					'query'           => 'what stories are trending on this site',
					'expected_intent' => 'trending news popular',
					'suggested_tool'  => array(
						'slug'         => 'getTrendingNews',
						'name'         => 'Get Trending News',
						'description'  => 'Returns the most-read / most-shared stories on this site in the last 7 days.',
						'parameters'   => array(
							'window_days' => array( 'type' => 'integer', 'description' => 'Look-back window in days (default 7).', 'required' => false ),
						),
					),
				),
				array(
					'query'           => 'is this claim fact checked',
					'expected_intent' => 'fact check verify claim citation',
					'suggested_tool'  => array(
						'slug'         => 'getFactCheckSummary',
						'name'         => 'Get Fact-Check Summary',
						'description'  => 'Returns the fact-check status and source citations for a claim or article.',
						'parameters'   => array(
							'claim' => array( 'type' => 'string', 'description' => 'Claim text or article ID.', 'required' => true ),
						),
					),
				),
				array(
					'query'           => 'who wrote this article and what are their credentials',
					'expected_intent' => 'editorial staff journalist byline author',
					'suggested_tool'  => array(
						'slug'         => 'getEditorialStaff',
						'name'         => 'Get Editorial Staff',
						'description'  => 'Returns the editorial team for a publication with bios, beats, and credentials.',
						'parameters'   => array(
							'staff_id' => array( 'type' => 'integer', 'description' => 'Optional staff member ID.', 'required' => false ),
						),
					),
				),
			),

			'ecommerce' => array(
				array(
					'query'           => 'show me product details for a specific sku',
					'expected_intent' => 'product details sku price stock',
					'suggested_tool'  => array(
						'slug'         => 'getProductDetails',
						'name'         => 'Get Product Details',
						'description'  => 'Returns full product details by SKU, slug, or post ID.',
						'parameters'   => array(
							'identifier' => array( 'type' => 'string', 'description' => 'Product SKU, slug, or post ID.', 'required' => true ),
						),
					),
				),
				array(
					'query'           => 'search products by keyword',
					'expected_intent' => 'search products catalog query',
					'suggested_tool'  => array(
						'slug'         => 'searchProducts',
						'name'         => 'Search Products',
						'description'  => 'Full-text search across the WooCommerce product catalog.',
						'parameters'   => array(
							'query' => array( 'type' => 'string', 'description' => 'Search query.', 'required' => true ),
							'limit' => array( 'type' => 'integer', 'description' => 'Maximum number of results (default 20).', 'required' => false ),
						),
					),
				),
				array(
					'query'           => 'is this product in stock',
					'expected_intent' => 'stock availability inventory',
					'suggested_tool'  => array(
						'slug'         => 'checkStock',
						'name'         => 'Check Stock',
						'description'  => 'Returns current stock status and quantity for a product.',
						'parameters'   => array(
							'product_id' => array( 'type' => 'integer', 'description' => 'Product post ID.', 'required' => true ),
						),
					),
				),
				array(
					'query'           => 'what is in my cart right now',
					'expected_intent' => 'cart contents items',
					'suggested_tool'  => array(
						'slug'         => 'getCartContents',
						'name'         => 'Get Cart Contents',
						'description'  => 'Returns the items currently in the user\'s shopping cart.',
						'parameters'   => array(),
					),
				),
				array(
					'query'           => 'add this product to my cart',
					'expected_intent' => 'add to cart line item',
					'suggested_tool'  => array(
						'slug'         => 'addToCart',
						'name'         => 'Add to Cart',
						'description'  => 'Adds a product to the user\'s cart with optional quantity.',
						'parameters'   => array(
							'product_id' => array( 'type' => 'integer', 'description' => 'Product post ID.', 'required' => true ),
							'quantity'   => array( 'type' => 'integer', 'description' => 'Quantity to add (default 1).', 'required' => false ),
						),
					),
				),
				array(
					'query'           => 'apply coupon code X',
					'expected_intent' => 'coupon discount code apply',
					'suggested_tool'  => array(
						'slug'         => 'applyCoupon',
						'name'         => 'Apply Coupon',
						'description'  => 'Applies a coupon code to the current cart.',
						'parameters'   => array(
							'code' => array( 'type' => 'string', 'description' => 'Coupon code.', 'required' => true ),
						),
					),
				),
				array(
					'query'           => 'what is your return policy',
					'expected_intent' => 'return policy refund terms',
					'suggested_tool'  => array(
						'slug'         => 'getReturnPolicy',
						'name'         => 'Get Return Policy',
						'description'  => 'Returns the store return / refund policy details.',
						'parameters'   => array(),
					),
				),
			),

			'tech_docs' => array(
				array(
					'query'           => 'search the documentation for a feature',
					'expected_intent' => 'search documentation docs knowledge',
					'suggested_tool'  => array(
						'slug'         => 'searchDocumentation',
						'name'         => 'Search Documentation',
						'description'  => 'Full-text search across the site\'s technical documentation.',
						'parameters'   => array(
							'query' => array( 'type' => 'string', 'description' => 'Search query.', 'required' => true ),
						),
					),
				),
				array(
					'query'           => 'show me the api reference for an endpoint',
					'expected_intent' => 'api reference endpoint schema',
					'suggested_tool'  => array(
						'slug'         => 'getApiReference',
						'name'         => 'Get API Reference',
						'description'  => 'Returns API endpoint schema, parameters, and response shape.',
						'parameters'   => array(
							'endpoint' => array( 'type' => 'string', 'description' => 'API endpoint path or slug.', 'required' => true ),
						),
					),
				),
				array(
					'query'           => 'show me a code example in python',
					'expected_intent' => 'code snippet example language',
					'suggested_tool'  => array(
						'slug'         => 'getCodeSnippet',
						'name'         => 'Get Code Snippet',
						'description'  => 'Returns a working code snippet in the requested language for a documented topic.',
						'parameters'   => array(
							'topic'    => array( 'type' => 'string', 'description' => 'Topic or feature name.', 'required' => true ),
							'language' => array( 'type' => 'string', 'description' => 'Programming language (e.g. python, javascript, go).', 'required' => false ),
						),
					),
				),
				array(
					'query'           => 'what changed in the latest version',
					'expected_intent' => 'changelog release history version',
					'suggested_tool'  => array(
						'slug'         => 'getVersionChangelog',
						'name'         => 'Get Version Changelog',
						'description'  => 'Returns the changelog between two version tags, or the latest N releases.',
						'parameters'   => array(
							'limit' => array( 'type' => 'integer', 'description' => 'Number of recent releases (default 5).', 'required' => false ),
						),
					),
				),
				array(
					'query'           => 'what server and php versions do you support',
					'expected_intent' => 'technical specs requirements environment',
					'suggested_tool'  => array(
						'slug'         => 'getTechnicalSpecs',
						'name'         => 'Get Technical Specs',
						'description'  => 'Returns supported PHP / WordPress / server requirements and current runtime.',
						'parameters'   => array(),
					),
				),
				array(
					'query'           => 'how do i troubleshoot error code XYZ',
					'expected_intent' => 'troubleshoot error debug fix',
					'suggested_tool'  => array(
						'slug'         => 'troubleshootError',
						'name'         => 'Troubleshoot Error',
						'description'  => 'Returns known fixes for a documented error code or message.',
						'parameters'   => array(
							'error_code' => array( 'type' => 'string', 'description' => 'Error code or message text.', 'required' => true ),
						),
					),
				),
			),

			'blog' => array(
				array(
					'query'           => 'show me your latest articles',
					'expected_intent' => 'latest articles recent posts',
					'suggested_tool'  => array(
						'slug'         => 'getLatestArticles',
						'name'         => 'Get Latest Articles',
						'description'  => 'Returns the most recent articles with read time.',
						'parameters'   => array(
							'limit' => array( 'type' => 'integer', 'description' => 'Maximum number of articles (default 10).', 'required' => false ),
						),
					),
				),
				array(
					'query'           => 'what are your most popular articles',
					'expected_intent' => 'popular articles top commented',
					'suggested_tool'  => array(
						'slug'         => 'getPopularArticles',
						'name'         => 'Get Popular Articles',
						'description'  => 'Returns the top commented / most-read articles.',
						'parameters'   => array(
							'limit' => array( 'type' => 'integer', 'description' => 'Maximum number of articles (default 10).', 'required' => false ),
						),
					),
				),
				array(
					'query'           => 'who is the author and what is their bio',
					'expected_intent' => 'author profile contributor bio',
					'suggested_tool'  => array(
						'slug'         => 'getAuthorProfile',
						'name'         => 'Get Author Profile',
						'description'  => 'Returns author bios and archive links.',
						'parameters'   => array(
							'author_id' => array( 'type' => 'integer', 'description' => 'Author user ID.', 'required' => true ),
						),
					),
				),
				array(
					'query'           => 'how long will this article take to read',
					'expected_intent' => 'reading time estimate minutes',
					'suggested_tool'  => array(
						'slug'         => 'estimateReadingTime',
						'name'         => 'Estimate Reading Time',
						'description'  => 'Returns the word count and estimated minutes for an article.',
						'parameters'   => array(
							'post_id' => array( 'type' => 'integer', 'description' => 'Post ID.', 'required' => true ),
						),
					),
				),
				array(
					'query'           => 'summarize this article into 3 key takeaways',
					'expected_intent' => 'summary takeaways tldr',
					'suggested_tool'  => array(
						'slug'         => 'summarizePost',
						'name'         => 'Summarize Post',
						'description'  => 'Returns a 3-bullet summary / key takeaways for a post.',
						'parameters'   => array(
							'post_id' => array( 'type' => 'integer', 'description' => 'Post ID.', 'required' => true ),
						),
					),
				),
			),

			'video' => array(
				array(
					'query'           => 'search videos by keyword',
					'expected_intent' => 'search videos catalog query',
					'suggested_tool'  => array(
						'slug'         => 'searchVideos',
						'name'         => 'Search Videos',
						'description'  => 'Full-text search across the video catalog.',
						'parameters'   => array(
							'query' => array( 'type' => 'string', 'description' => 'Search query.', 'required' => true ),
						),
					),
				),
				array(
					'query'           => 'show me the transcript for this video',
					'expected_intent' => 'transcript subtitles captions',
					'suggested_tool'  => array(
						'slug'         => 'getVideoTranscript',
						'name'         => 'Get Video Transcript',
						'description'  => 'Returns the full transcript for a video.',
						'parameters'   => array(
							'video_id' => array( 'type' => 'integer', 'description' => 'Video post ID.', 'required' => true ),
						),
					),
				),
				array(
					'query'           => 'jump to the chapter about database migrations',
					'expected_intent' => 'chapter timestamps markers topic',
					'suggested_tool'  => array(
						'slug'         => 'getChapterTimestamps',
						'name'         => 'Get Chapter Timestamps',
						'description'  => 'Returns chapter markers / timestamps for a video, optionally filtered by topic.',
						'parameters'   => array(
							'video_id' => array( 'type' => 'integer', 'description' => 'Video post ID.', 'required' => true ),
							'topic'    => array( 'type' => 'string', 'description' => 'Optional topic keyword.', 'required' => false ),
						),
					),
				),
				array(
					'query'           => 'list the playlists on this site',
					'expected_intent' => 'playlists collections',
					'suggested_tool'  => array(
						'slug'         => 'getPlaylists',
						'name'         => 'Get Playlists',
						'description'  => 'Returns curated video playlists / collections.',
						'parameters'   => array(),
					),
				),
			),

			'events' => array(
				array(
					'query'           => 'what events are coming up',
					'expected_intent' => 'upcoming events schedule',
					'suggested_tool'  => array(
						'slug'         => 'getUpcomingEvents',
						'name'         => 'Get Upcoming Events',
						'description'  => 'Returns upcoming events / webinars scheduled in the future.',
						'parameters'   => array(
							'limit' => array( 'type' => 'integer', 'description' => 'Maximum number of events (default 20).', 'required' => false ),
						),
					),
				),
				array(
					'query'           => 'show me details for a specific event',
					'expected_intent' => 'event details agenda location',
					'suggested_tool'  => array(
						'slug'         => 'getEventDetails',
						'name'         => 'Get Event Details',
						'description'  => 'Returns full event details including agenda, speakers, and registration.',
						'parameters'   => array(
							'event_id' => array( 'type' => 'integer', 'description' => 'Event post ID.', 'required' => true ),
						),
					),
				),
				array(
					'query'           => 'find events in Berlin next month',
					'expected_intent' => 'search events location date topic',
					'suggested_tool'  => array(
						'slug'         => 'searchEvents',
						'name'         => 'Search Events',
						'description'  => 'Searches events by topic, venue, city, or date range.',
						'parameters'   => array(
							'query'    => array( 'type' => 'string', 'description' => 'Free-text query (topic, venue, city).', 'required' => false ),
							'location' => array( 'type' => 'string', 'description' => 'City / venue name.', 'required' => false ),
							'from'     => array( 'type' => 'string', 'description' => 'Start date (YYYY-MM-DD).', 'required' => false ),
							'to'       => array( 'type' => 'string', 'description' => 'End date (YYYY-MM-DD).', 'required' => false ),
						),
					),
				),
			),

			'local_business' => array(
				array(
					'query'           => 'what are your business hours',
					'expected_intent' => 'business hours opening times',
					'suggested_tool'  => array(
						'slug'         => 'getBusinessHours',
						'name'         => 'Get Business Hours',
						'description'  => 'Returns the operating hours for the business, broken down by day.',
						'parameters'   => array(
							'day' => array( 'type' => 'string', 'description' => 'Optional day of week (e.g. monday).', 'required' => false ),
						),
					),
				),
				array(
					'query'           => 'where are you located and what is your address',
					'expected_intent' => 'address location directions',
					'suggested_tool'  => array(
						'slug'         => 'getBusinessLocation',
						'name'         => 'Get Business Location',
						'description'  => 'Returns the physical address, map coordinates, and directions link.',
						'parameters'   => array(),
					),
				),
				array(
					'query'           => 'how can i contact you',
					'expected_intent' => 'contact phone email',
					'suggested_tool'  => array(
						'slug'         => 'getContactInfo',
						'name'         => 'Get Contact Info',
						'description'  => 'Returns phone, email, and contact form URL for the business.',
						'parameters'   => array(),
					),
				),
				array(
					'query'           => 'do you have parking and is it accessible',
					'expected_intent' => 'parking accessibility amenities',
					'suggested_tool'  => array(
						'slug'         => 'getAmenities',
						'name'         => 'Get Amenities',
						'description'  => 'Returns amenities: parking, wifi, accessibility, pet-friendliness, etc.',
						'parameters'   => array(),
					),
				),
				array(
					'query'           => 'is this restaurant open right now',
					'expected_intent' => 'open status current hours now',
					'suggested_tool'  => array(
						'slug'         => 'isOpenNow',
						'name'         => 'Is Open Now',
						'description'  => 'Returns whether the business is currently open based on declared hours + timezone.',
						'parameters'   => array(),
					),
				),
			),
		);
	}

	/**
	 * Flat accessor — return all questions across all verticals.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function all_questions(): array {
		$out = array();
		foreach ( self::QUESTION_BANK() as $vertical => $questions ) {
			foreach ( $questions as $q ) {
				$q['vertical'] = $vertical;
				$out[]         = $q;
			}
		}
		return $out;
	}

	/**
	 * Questions for a single vertical.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function questions_for( string $vertical ): array {
		$all = self::QUESTION_BANK();
		if ( ! isset( $all[ $vertical ] ) ) {
			return array();
		}
		$out = array();
		foreach ( $all[ $vertical ] as $q ) {
			$q['vertical'] = $vertical;
			$out[]         = $q;
		}
		return $out;
	}
}
