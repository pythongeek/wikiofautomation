<?php
/**
 * Schema Scanner — Module A A3c (AEO Intelligence — schema-to-tool sync).
 *
 * Pure-PHP JSON-LD parser. Scans `<script type="application/ld+json">` blocks
 * from published content and groups occurrences by schema.org `@type`. Output
 * is consumed by WP_WebMCP_Schema_Tool_Suggester to propose matching MCP
 * tools.
 *
 * Design principles:
 *   - No external dependencies (no DOMDocument).
 *   - Never fabricates data — every count links to real wp_posts.ID rows.
 *   - Capped scan (default 500 posts) for performance on large sites.
 *   - Resilient: malformed JSON-LD blocks are skipped, not fatal.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- intentional: 1 placeholder for the cache_key in the SQL
// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery -- scanner is admin-only with manual cache invalidation
final class WP_WebMCP_Schema_Scanner {

	/**
	 * Schema.org types we recognise when proposing tools.
	 * Keys are the canonical @type strings. Values are display metadata
	 * for the suggester + admin UI. Keep this list aligned with
	 * WP_WebMCP_Schema_Tool_Suggester::TEMPLATES.
	 *
	 * @return array<string, array<string, string>>
	 */
	public static function recognised_types(): array {
		return array(
			'Product'        => array( 'label' => 'Product',         'icon' => '🛍️' ),
			'FAQPage'        => array( 'label' => 'FAQ Page',        'icon' => '❓' ),
			'Recipe'         => array( 'label' => 'Recipe',          'icon' => '🍲' ),
			'LocalBusiness'  => array( 'label' => 'Local Business',  'icon' => '🏪' ),
			'HowTo'          => array( 'label' => 'HowTo',           'icon' => '🛠️' ),
			'Event'          => array( 'label' => 'Event',           'icon' => '📅' ),
			'Course'         => array( 'label' => 'Course',          'icon' => '🎓' ),
			'Article'        => array( 'label' => 'Article',         'icon' => '📰' ),
			'Organization'   => array( 'label' => 'Organization',    'icon' => '🏢' ),
			'Person'         => array( 'label' => 'Person',          'icon' => '👤' ),
			'BreadcrumbList' => array( 'label' => 'Breadcrumb List', 'icon' => '🔗' ),
		);
	}

	/**
	 * Run a scan across published post types. Returns counts per @type plus
	 * sample post ids and sample JSON.
	 *
	 * @param int  $max_posts   Hard cap on posts scanned (default 500). Keep low
	 *                          for first paint; admins can re-run.
	 * @param array $post_types Post types to scan. Default = all public types.
	 * @return array<string, array<string, mixed>>  keyed by @type
	 */
	public static function scan( int $max_posts = 500, ?array $post_types = null ): array {
		global $wpdb;

		if ( null === $post_types || empty( $post_types ) ) {
			$post_types = self::default_post_types();
		}

		// Build the placeholders + escaped post-type list for the IN clause.
		$placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );
		$like         = '%' . $wpdb->esc_like( 'application/ld+json' ) . '%';
		$params       = array_merge( $post_types, array( $like, $max_posts ) );

		// Single query — pulls post_content for published posts only.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoFuzzy -- bounded LIMIT, indexed columns.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $placeholders is built from %s above, no user SQL reaches here.
				"SELECT ID, post_type, post_content FROM {$wpdb->posts} WHERE post_type IN ($placeholders) AND post_status = 'publish' AND post_content LIKE %s ORDER BY ID DESC LIMIT %d",
				$params
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoFuzzy

		$types = array();
		$rows  = is_array( $rows ) ? $rows : array();

		foreach ( $rows as $row ) {
			$post_id = (int) $row['ID'];
			$blocks  = self::extract_jsonld_blocks( (string) $row['post_content'] );
			foreach ( $blocks as $block ) {
				$decoded = json_decode( $block, true );
				if ( ! is_array( $decoded ) ) {
					continue;
				}
				$found_types = self::collect_types( $decoded );
				foreach ( $found_types as $t ) {
					if ( ! isset( $types[ $t ] ) ) {
						$types[ $t ] = array(
							'count'           => 0,
							'sample_post_ids' => array(),
							'sample_json'     => null,
							'icon'            => self::icon_for( $t ),
							'label'           => self::label_for( $t ),
						);
					}
					$types[ $t ]['count']++;
					if ( count( $types[ $t ]['sample_post_ids'] ) < 5 ) {
						$types[ $t ]['sample_post_ids'][] = $post_id;
					}
					if ( null === $types[ $t ]['sample_json'] ) {
						$types[ $t ]['sample_json'] = self::summarise_jsonld( $decoded, $t );
					}
				}
			}
		}

		// Sort by count descending for predictable UI rendering.
		uasort(
			$types,
			static function ( $a, $b ) {
				return $b['count'] <=> $a['count'];
			}
		);

		return $types;
	}

	/**
	 * Total posts scanned (for the dashboard footer).
	 */
	public static function scan_stats( ?array $post_types = null ): array {
		global $wpdb;
		if ( null === $post_types || empty( $post_types ) ) {
			$post_types = self::default_post_types();
		}
		$placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );
		$like         = '%' . $wpdb->esc_like( 'application/ld+json' ) . '%';
		$params       = array_merge( $post_types, array( $like ) );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
		$total = (int) $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type IN ($placeholders) AND post_status = 'publish' AND post_content LIKE %s",
				$params
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery
		return array(
			'candidates' => $total,
			'limit'      => 500,
		);
	}

	/* ---------- internals ---------- */

	/**
	 * Public post types — skip attachments, revisions, nav items, etc.
	 *
	 * @return string[]
	 */
	private static function default_post_types(): array {
		$all = get_post_types( array( 'public' => true ) );
		$skip = array( 'attachment' );
		$out  = array();
		foreach ( $all as $pt ) {
			if ( ! in_array( $pt, $skip, true ) ) {
				$out[] = $pt;
			}
		}
		return empty( $out ) ? array( 'post', 'page' ) : array_values( $out );
	}

	/**
	 * Pull JSON-LD blocks out of arbitrary HTML.
	 *
	 * Regex is intentional here: JSON-LD is always wrapped in a fixed
	 * `<script type="application/ld+json">` tag, so a single non-greedy
	 * match is sufficient and avoids the DOMDocument overhead.
	 *
	 * @return string[] raw JSON strings (one per block).
	 */
	private static function extract_jsonld_blocks( string $html ): array {
		$blocks = array();
		if ( '' === $html || false === stripos( $html, 'application/ld+json' ) ) {
			return $blocks;
		}
		// phpcs:ignore WordPress.PHP.NoSilencedErrors -- @ suppresses libxml warning noise; we re-validate via json_decode.
		$found = preg_match_all(
			'#<script[^>]+type\s*=\s*["\']application/ld\+json["\'][^>]*>(.*?)</script>#is',
			$html,
			$m
		);
		if ( ! $found ) {
			return $blocks;
		}
		foreach ( $m[1] as $raw ) {
			$trim = trim( $raw );
			// Defensive: ensure it looks like JSON before bothering with decode.
			if ( '' !== $trim && ( '{' === substr( $trim, 0, 1 ) || '[' === substr( $trim, 0, 1 ) ) ) {
				$blocks[] = $trim;
			}
		}
		return $blocks;
	}

	/**
	 * Recursively collect every `@type` string from a decoded JSON-LD object.
	 * Handles both top-level `@type` (string or array) and `@graph` arrays.
	 *
	 * @param mixed $node
	 * @return string[]
	 */
	private static function collect_types( $node ): array {
		$out = array();
		if ( ! is_array( $node ) ) {
			return $out;
		}
		if ( isset( $node['@type'] ) ) {
			$t = $node['@type'];
			if ( is_string( $t ) ) {
				$out[] = $t;
			} elseif ( is_array( $t ) ) {
				foreach ( $t as $sub ) {
					if ( is_string( $sub ) ) {
						$out[] = $sub;
					}
				}
			}
		}
		if ( isset( $node['@graph'] ) && is_array( $node['@graph'] ) ) {
			foreach ( $node['@graph'] as $child ) {
				$out = array_merge( $out, self::collect_types( $child ) );
			}
		}
		// De-dupe while preserving order.
		return array_values( array_unique( $out ) );
	}

	/**
	 * Build a small, admin-friendly summary of a JSON-LD block for the
	 * "View details" disclosure on the dashboard.
	 *
	 * @return array<string, mixed>
	 */
	private static function summarise_jsonld( array $decoded, string $focus_type ): array {
		$node = self::find_first_node_with_type( $decoded, $focus_type );
		if ( null === $node ) {
			$node = $decoded;
		}
		// Surface the most informative fields; cap everything else.
		$interesting = array( 'name', 'headline', 'sku', 'price', 'priceCurrency', 'availability', 'aggregateRating', 'author', 'datePublished', 'description' );
		$summary     = array();
		foreach ( $interesting as $k ) {
			if ( isset( $node[ $k ] ) ) {
				$summary[ $k ] = self::scalarise( $node[ $k ] );
			}
		}
		return $summary;
	}

	/**
	 * Walk the decoded tree and return the first node whose `@type` matches.
	 *
	 * @return array<string, mixed>|null
	 */
	private static function find_first_node_with_type( array $node, string $type ): ?array {
		if ( isset( $node['@type'] ) ) {
			$t = $node['@type'];
			if ( ( is_string( $t ) && $t === $type ) || ( is_array( $t ) && in_array( $type, $t, true ) ) ) {
				return $node;
			}
		}
		if ( isset( $node['@graph'] ) && is_array( $node['@graph'] ) ) {
			foreach ( $node['@graph'] as $child ) {
				if ( is_array( $child ) ) {
					$found = self::find_first_node_with_type( $child, $type );
					if ( null !== $found ) {
						return $found;
					}
				}
			}
		}
		return null;
	}

	/**
	 * Convert nested arrays/scalars into a short, human-readable string for the UI.
	 *
	 * @param mixed $v
	 */
	private static function scalarise( $v ): string {
		if ( is_scalar( $v ) ) {
			$s = (string) $v;
			return strlen( $s ) > 120 ? substr( $s, 0, 117 ) . '...' : $s;
		}
		if ( is_array( $v ) ) {
			// JSON-encode for predictability; cap length.
			$json = wp_json_encode( $v );
			if ( null === $json ) {
				return '';
			}
			return strlen( $json ) > 120 ? substr( $json, 0, 117 ) . '...' : $json;
		}
		return '';
	}

	private static function icon_for( string $type ): string {
		$map = self::recognised_types();
		return isset( $map[ $type ]['icon'] ) ? $map[ $type ]['icon'] : '📄';
	}

	private static function label_for( string $type ): string {
		$map = self::recognised_types();
		return isset( $map[ $type ]['label'] ) ? $map[ $type ]['label'] : $type;
	}
	// phpcs:enable WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
}