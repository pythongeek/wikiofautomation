<?php
/**
 * Schema Tool Suggester — Module A A3c (AEO Intelligence — schema-to-tool sync).
 *
 * Given a scan result from WP_WebMCP_Schema_Scanner, produces ready-to-insert
 * MCP tool definitions for every @type that clears its minimum-occurrence
 * threshold. Suggestions are deterministic and bound to real content (the
 * scan row count and sample post ids travel through to the admin UI).
 *
 * No fabricated suggestions: every entry in the suggestion list traces back
 * to ≥ threshold real wp_posts rows.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Schema_Tool_Suggester {

	/**
	 * Template catalogue. Each entry describes:
	 *   - threshold: minimum number of posts that must contain this @type.
	 *   - slug:      proposed tool_name (camelCase).
	 *   - name:      human-readable tool name.
	 *   - description: tool description (must be ≥20 chars per Tool Repository).
	 *   - tool_type: 'read' (default) or 'write'.
	 *   - tool_scope: 'all' (default) or vertical-specific ('woo' / 'single' etc.).
	 *   - action_type: 'rest' (default — wire to a callback) or other.
	 *   - action_value: callable identifier.
	 *   - parameters: associative array of parameter name → descriptor.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public const TEMPLATES = array(
		'Product'       => array(
			'threshold'     => 3,
			'slug'          => 'getProductDetails',
			'name'          => 'Get Product Details',
			'description'   => 'Returns details for a WooCommerce product by SKU, slug, or post ID. Backed by the Product schema.org markup already present in your content.',
			'tool_type'     => 'read',
			'tool_scope'    => 'all',
			'action_type'   => 'rest',
			'action_value'  => 'wpwebmcp/v1/products/get',
			'parameters'    => array(
				'identifier' => array(
					'type'        => 'string',
					'description' => 'Product SKU, slug, or post ID.',
					'required'    => true,
				),
			),
		),
		'FAQPage'       => array(
			'threshold'     => 3,
			'slug'          => 'getFAQsByPost',
			'name'          => 'Get FAQs by Post',
			'description'   => 'Returns FAQ schema questions and answers for a given post. Backed by FAQPage JSON-LD already in your content.',
			'tool_type'     => 'read',
			'tool_scope'    => 'all',
			'action_type'   => 'rest',
			'action_value'  => 'wpwebmcp/v1/faqs/get',
			'parameters'    => array(
				'post_id' => array(
					'type'        => 'integer',
					'description' => 'WordPress post ID containing FAQPage schema.',
					'required'    => true,
				),
			),
		),
		'Recipe'        => array(
			'threshold'     => 3,
			'slug'          => 'getRecipeByTitle',
			'name'          => 'Get Recipe by Title',
			'description'   => 'Returns full Recipe schema (ingredients, steps, nutrition) for a recipe post by title.',
			'tool_type'     => 'read',
			'tool_scope'    => 'all',
			'action_type'   => 'rest',
			'action_value'  => 'wpwebmcp/v1/recipes/get',
			'parameters'    => array(
				'title' => array(
					'type'        => 'string',
					'description' => 'Recipe title or slug.',
					'required'    => true,
				),
			),
		),
		'LocalBusiness' => array(
			'threshold'     => 1,
			'slug'          => 'getBusinessInfo',
			'name'          => 'Get Business Info',
			'description'   => 'Returns structured Local Business information (hours, address, phone, geo) for AI agents.',
			'tool_type'     => 'read',
			'tool_scope'    => 'all',
			'action_type'   => 'rest',
			'action_value'  => 'wpwebmcp/v1/business/get',
			'parameters'    => array(
				'field' => array(
					'type'        => 'string',
					'description' => 'Optional field name to return (e.g. "hours", "address"). Omit for full payload.',
					'required'    => false,
				),
			),
		),
		'HowTo'         => array(
			'threshold'     => 3,
			'slug'          => 'getHowToSteps',
			'name'          => 'Get HowTo Steps',
			'description'   => 'Returns ordered steps from a HowTo schema block for a given post ID.',
			'tool_type'     => 'read',
			'tool_scope'    => 'all',
			'action_type'   => 'rest',
			'action_value'  => 'wpwebmcp/v1/howtos/get',
			'parameters'    => array(
				'post_id' => array(
					'type'        => 'integer',
					'description' => 'Post ID containing HowTo schema.',
					'required'    => true,
				),
			),
		),
		'Event'         => array(
			'threshold'     => 3,
			'slug'          => 'getEventDetails',
			'name'          => 'Get Event Details',
			'description'   => 'Returns structured Event schema (date, location, performer, ticket info) for a given event post.',
			'tool_type'     => 'read',
			'tool_scope'    => 'all',
			'action_type'   => 'rest',
			'action_value'  => 'wpwebmcp/v1/events/get',
			'parameters'    => array(
				'event_id' => array(
					'type'        => 'integer',
					'description' => 'Event post ID.',
					'required'    => true,
				),
			),
		),
		'Course'        => array(
			'threshold'     => 3,
			'slug'          => 'getCourseInfo',
			'name'          => 'Get Course Info',
			'description'   => 'Returns Course schema (provider, syllabus, prerequisites) for a given course post.',
			'tool_type'     => 'read',
			'tool_scope'    => 'all',
			'action_type'   => 'rest',
			'action_value'  => 'wpwebmcp/v1/courses/get',
			'parameters'    => array(
				'course_id' => array(
					'type'        => 'integer',
					'description' => 'Course post ID.',
					'required'    => true,
				),
			),
		),
		'Article'       => array(
			'threshold'     => 5,
			'slug'          => 'getArticleSummary',
			'name'          => 'Get Article Summary',
			'description'   => 'Returns a structured summary (headline, author, datePublished) from Article schema for a post ID.',
			'tool_type'     => 'read',
			'tool_scope'    => 'single',
			'action_type'   => 'rest',
			'action_value'  => 'wpwebmcp/v1/articles/get',
			'parameters'    => array(
				'post_id' => array(
					'type'        => 'integer',
					'description' => 'Article post ID.',
					'required'    => true,
				),
			),
		),
	);

	/**
	 * Build suggestion list from a scan result.
	 *
	 * @param array<string, array<string, mixed>> $scan Output of Scanner::scan().
	 * @return array<int, array<string, mixed>>  One entry per qualifying @type.
	 */
	public static function suggest( array $scan ): array {
		$out = array();
		foreach ( self::TEMPLATES as $type => $template ) {
			if ( ! isset( $scan[ $type ] ) ) {
				continue;
			}
			$row = $scan[ $type ];
			$count = (int) ( $row['count'] ?? 0 );
			if ( $count < (int) $template['threshold'] ) {
				continue;
			}
			$out[] = array(
				'type'           => $type,
				'label'          => isset( $row['label'] ) ? (string) $row['label'] : $type,
				'icon'           => isset( $row['icon'] ) ? (string) $row['icon'] : '📄',
				'post_count'     => $count,
				'sample_post_ids'=> isset( $row['sample_post_ids'] ) && is_array( $row['sample_post_ids'] ) ? array_values( array_map( 'intval', $row['sample_post_ids'] ) ) : array(),
				'sample_json'    => isset( $row['sample_json'] ) && is_array( $row['sample_json'] ) ? $row['sample_json'] : array(),
				'threshold'      => (int) $template['threshold'],
				'suggested_tool' => array(
					'slug'         => (string) $template['slug'],
					'name'         => (string) $template['name'],
					'description'  => (string) $template['description'],
					'tool_type'    => (string) $template['tool_type'],
					'tool_scope'   => (string) $template['tool_scope'],
					'action_type'  => (string) $template['action_type'],
					'action_value' => (string) $template['action_value'],
					'parameters'   => isset( $template['parameters'] ) ? $template['parameters'] : array(),
				),
			);
		}
		return $out;
	}

	/**
	 * Build the Tool_Repository insert payload for one suggestion.
	 *
	 * @return array<string, mixed>
	 */
	public static function tool_row_payload( array $suggestion ): array {
		$t = isset( $suggestion['suggested_tool'] ) && is_array( $suggestion['suggested_tool'] ) ? $suggestion['suggested_tool'] : array();
		return array(
			'tool_name'        => isset( $t['slug'] ) ? (string) $t['slug'] : '',
			'tool_description' => isset( $t['description'] ) ? (string) $t['description'] : '',
			'tool_type'        => isset( $t['tool_type'] ) ? (string) $t['tool_type'] : 'read',
			'tool_scope'       => isset( $t['tool_scope'] ) ? (string) $t['tool_scope'] : 'all',
			'action_type'      => isset( $t['action_type'] ) ? (string) $t['action_type'] : 'rest',
			'action_value'     => isset( $t['action_value'] ) ? (string) $t['action_value'] : '',
			'parameters'       => isset( $t['parameters'] ) ? $t['parameters'] : array(),
			'status'           => 'active',
		);
	}

	/**
	 * Stable id for this suggester (used by the dashboard UI as a nonce context).
	 */
	public static function slug_already_exists( string $slug ): bool {
		if ( ! class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			return false;
		}
		return null !== WP_WebMCP_Tool_Repository::find_by_slug( $slug );
	}
}
