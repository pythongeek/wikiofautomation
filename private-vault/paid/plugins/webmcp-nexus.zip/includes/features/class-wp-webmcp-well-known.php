<?php
/**
 * .well-known Discovery Endpoints — Doc Part 10 (XF03).
 *
 * Serves standardized AI discovery JSON documents:
 *   - /.well-known/ai-plugin.json
 *   - /.well-known/mcp.json
 *   - /.well-known/agent.json
 *   - /.well-known/web-mcp.json
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- reading REQUEST_URI for content-type routing is intentional
final class WP_WebMCP_Well_Known {

	/**
	 * Initialize well-known discovery router.
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'init', array( __CLASS__, 'add_rewrite_rules' ) );
		WP_WebMCP_Loader::register_filter( 'query_vars', array( __CLASS__, 'add_query_vars' ) );
		WP_WebMCP_Loader::register_action( 'template_redirect', array( __CLASS__, 'serve' ), 1 );
	}

	/**
	 * Register URL rewrite rules for .well-known endpoints.
	 */
	public static function add_rewrite_rules(): void {
		add_rewrite_rule( '^\.well-known/ai-plugin\.json$', 'index.php?wpwebmcp_wellknown=ai-plugin', 'top' );
		add_rewrite_rule( '^\.well-known/mcp\.json$', 'index.php?wpwebmcp_wellknown=mcp', 'top' );
		add_rewrite_rule( '^\.well-known/mcp$', 'index.php?wpwebmcp_wellknown=mcp', 'top' );
		add_rewrite_rule( '^\.well-known/model-context-protocol\.json$', 'index.php?wpwebmcp_wellknown=mcp', 'top' );
		add_rewrite_rule( '^\.well-known/model-context-protocol$', 'index.php?wpwebmcp_wellknown=mcp', 'top' );
		add_rewrite_rule( '^\.well-known/agent\.json$', 'index.php?wpwebmcp_wellknown=agent', 'top' );
		add_rewrite_rule( '^\.well-known/webmcp\.json$', 'index.php?wpwebmcp_wellknown=agent', 'top' );
		add_rewrite_rule( '^\.well-known/webmcp$', 'index.php?wpwebmcp_wellknown=agent', 'top' );
	}

	/**
	 * Add custom query var.
	 *
	 * @param array $vars
	 * @return array
	 */
	public static function add_query_vars( array $vars ): array {
		$vars[] = 'wpwebmcp_wellknown';
		return $vars;
	}

	/**
	 * Intercept incoming requests for .well-known files.
	 */
	public static function serve(): void {
		$qv   = (string) get_query_var( 'wpwebmcp_wellknown' );
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$path = trim( (string) wp_parse_url( $uri, PHP_URL_PATH ), '/' );

		if ( 'ai-plugin' === $qv || '.well-known/ai-plugin.json' === $path || preg_match( '/(^|\/)\.well-known\/ai-plugin\.json$/i', $path ) ) {
			self::serve_ai_plugin();
		} elseif ( 'mcp' === $qv || in_array( $path, array( '.well-known/mcp', '.well-known/mcp.json', '.well-known/model-context-protocol', '.well-known/model-context-protocol.json' ), true ) || preg_match( '/(^|\/)\.well-known\/(mcp|model-context-protocol)(\.json)?$/i', $path ) ) {
			self::serve_mcp_json();
		} elseif ( 'agent' === $qv || in_array( $path, array( '.well-known/agent.json', '.well-known/web-mcp.json', '.well-known/webmcp.json', '.well-known/webmcp', '.well-known/web-mcp' ), true ) || preg_match( '/(^|\/)\.well-known\/(agent|web-mcp|webmcp)(\.json)?$/i', $path ) ) {
			self::serve_agent_json();
		}
	}

	/**
	 * Output /.well-known/ai-plugin.json
	 */
	public static function serve_ai_plugin(): void {
		$site_title = (string) get_bloginfo( 'name' );
		if ( '' === $site_title ) {
			$site_title = 'WordPress Site';
		}
		$site_url = (string) home_url();
		$slug     = sanitize_key( $site_title ) ?: 'site';

		$payload = array(
			'schema_version'        => 'v1',
			'name_for_human'        => sprintf( '%s Assistant', $site_title ),
			'name_for_model'        => sprintf( 'webmcp_%s', $slug ),
			'description_for_human' => sprintf( 'Interact with %s via WebMCP tools.', $site_title ),
			'description_for_model' => sprintf( 'Allows AI models to search and interact with content on %s using the WebMCP Nexus protocol.', $site_title ),
			'auth'                  => array( 'type' => 'none' ),
			'api'                   => array(
				'type' => 'openapi',
				'url'  => rest_url( 'wpwebmcp/v1/manifest' ),
			),
			'logo_url'              => get_site_icon_url( 192 ) ?: ( WEBMCP_NEXUS_URL . 'admin/images/icon-128.png' ),
			'contact_email'         => get_option( 'admin_email' ),
			'legal_info_url'        => $site_url,
		);

		self::send_json( $payload );
	}

	/**
	 * Output /.well-known/mcp.json & /.well-known/mcp
	 */
	public static function serve_mcp_json(): void {
		$site_title = (string) get_bloginfo( 'name' );
		$payload = array(
			'protocolVersion' => '2024-11-05',
			'mcpVersion'      => '1.0.0',
			'serverInfo'      => array(
				'name'        => 'WebMCP Nexus',
				'version'     => defined( 'WEBMCP_NEXUS_VERSION' ) ? WEBMCP_NEXUS_VERSION : '1.0.0',
				'description' => sprintf( 'Model Context Protocol Server for %s', '' !== $site_title ? $site_title : 'WordPress' ),
			),
			'capabilities'    => array(
				'tools'       => array( 'listChanged' => false ),
				'resources'   => array( 'listChanged' => false ),
				'prompts'     => array( 'listChanged' => false ),
			),
			'endpoint'        => rest_url( 'wpwebmcp/v1/mcp' ),
			'rpcEndpoint'     => rest_url( 'wpwebmcp/v1/mcp' ),
			'sseEndpoint'     => rest_url( 'wpwebmcp/v1/sse' ),
			'toolsEndpoint'   => rest_url( 'wpwebmcp/v1/tools' ),
			'manifestUrl'     => rest_url( 'wpwebmcp/v1/manifest' ),
			'healthUrl'       => rest_url( 'wpwebmcp/v1/health' ),
		);

		self::send_json( $payload );
	}

	/**
	 * Output /.well-known/agent.json, /.well-known/webmcp.json & /.well-known/web-mcp.json
	 */
	public static function serve_agent_json(): void {
		$site_title = (string) get_bloginfo( 'name' );
		$site_url   = (string) home_url();

		$payload = array(
			'name'        => $site_title,
			'url'         => $site_url,
			'version'     => defined( 'WEBMCP_NEXUS_VERSION' ) ? WEBMCP_NEXUS_VERSION : '1.0.0',
			'protocols'   => array(
				'webmcp' => array(
					'version'     => '1.0',
					'manifestUrl' => rest_url( 'wpwebmcp/v1/manifest' ),
					'callUrl'     => rest_url( 'wpwebmcp/v1/call' ),
					'toolsUrl'    => rest_url( 'wpwebmcp/v1/tools' ),
					'policy'      => 'allow=read-tools; max-calls-per-session=200',
				),
				'mcp'    => array(
					'version'     => '2024-11-05',
					'endpoint'    => rest_url( 'wpwebmcp/v1/mcp' ),
					'rpc'         => rest_url( 'wpwebmcp/v1/mcp' ),
					'sse'         => rest_url( 'wpwebmcp/v1/sse' ),
				),
				'llmstxt' => array(
					'summary' => home_url( '/llms.txt' ),
					'full'    => home_url( '/llms-full.txt' ),
				),
			),
		);

		self::send_json( $payload );
	}

	/**
	 * Send JSON response with CORS & cache headers.
	 *
	 * @param array $data
	 */
	private static function send_json( array $data ): void {
		if ( ! headers_sent() ) {
			status_header( 200 );
			header( 'Content-Type: application/json; charset=utf-8' );
			header( 'Access-Control-Allow-Origin: *' );
			header( 'Access-Control-Allow-Methods: GET, POST, OPTIONS, HEAD' );
			header( 'Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce, X-WC-Nonce, Mcp-Session-Id, Cache-Control, Pragma, Accept' );
			header( 'Access-Control-Expose-Headers: Link, X-WebMCP, X-ModelContextProtocol, X-MCP-Server' );
			header( 'Cache-Control: public, max-age=3600' );
		}

		echo wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		exit;
	}
	// phpcs:enable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
}