<?php
/**
 * Done-For-You (DFY) Shortcodes & AI Frontend Widgets.
 *
 * Provides ready-to-use drop-in shortcodes for site owners:
 *   1. `[webmcp_form]` - Renders responsive HTML form annotated for AI agents with `toolname` & `tooldescription`.
 *   2. `[webmcp_badge]` - Renders sleek "AI Agent Ready (WebMCP 1.0)" visual badge.
 *   3. `[webmcp_summary]` - Renders an AI Summary box with quick highlights on posts.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Shortcodes {

	/**
	 * Register all WebMCP shortcodes.
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_shortcode( 'webmcp_form', array( __CLASS__, 'render_form' ) );
		WP_WebMCP_Loader::register_shortcode( 'webmcp_badge', array( __CLASS__, 'render_badge' ) );
		WP_WebMCP_Loader::register_shortcode( 'webmcp_summary', array( __CLASS__, 'render_summary' ) );
	}

	/**
	 * Render `[webmcp_form name="..." title="..." description="..." fields="..."]`
	 *
	 * @param array<string, mixed> $atts
	 * @return string
	 */
	public static function render_form( array $atts = array() ): string {
		$atts = shortcode_atts(
			array(
				'name'        => 'contactInquiry',
				'title'       => __( 'Send an Inquiry', 'webmcp-nexus' ),
				'description' => __( 'Submit a message or inquiry to our team.', 'webmcp-nexus' ),
				'fields'      => 'name,email,subject,message',
				'button_text' => __( 'Submit Message', 'webmcp-nexus' ),
				'autosubmit'  => 'false',
			),
			$atts,
			'webmcp_form'
		);

		$tool_name    = sanitize_key( $atts['name'] );
		$tool_desc    = sanitize_text_field( $atts['description'] );
		$title        = sanitize_text_field( $atts['title'] );
		$btn_text     = sanitize_text_field( $atts['button_text'] );
		$auto_submit  = 'true' === $atts['autosubmit'] ? ' toolautosubmit' : '';
		$field_keys   = array_filter( array_map( 'trim', explode( ',', (string) $atts['fields'] ) ) );

		ob_start();
		?>
		<div class="wpwm-form-container" style="background:#1e1e2e; border:1px solid #313244; border-radius:12px; padding:24px; max-width:540px; margin:20px auto; color:#cdd6f4; font-family:system-ui,sans-serif; box-shadow:0 10px 25px rgba(0,0,0,0.3);">
			<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px;">
				<h3 style="margin:0; font-size:18px; color:#cdd6f4;"><?php echo esc_html( $title ); ?></h3>
				<span style="background:rgba(99,102,241,0.2); color:#818cf8; border:1px solid rgba(99,102,241,0.4); padding:2px 8px; border-radius:10px; font-size:11px; font-weight:bold;">⚡ WebMCP AI Tool</span>
			</div>
			<p style="margin:0 0 16px; font-size:13px; color:#a6adc8;"><?php echo esc_html( $tool_desc ); ?></p>
			<form toolname="<?php echo esc_attr( $tool_name ); ?>" tooldescription="<?php echo esc_attr( $tool_desc ); ?>"<?php echo esc_attr( $auto_submit ); ?> method="POST" action="<?php echo esc_url( rest_url( 'wpwebmcp/v1/call/' . $tool_name ) ); ?>" style="display:flex; flex-direction:column; gap:12px;">
				<?php
				foreach ( $field_keys as $key ) {
					$label = ucwords( str_replace( array( '_', '-' ), ' ', $key ) );
					$type  = 'text';
					if ( false !== stripos( $key, 'email' ) ) $type = 'email';
					if ( false !== stripos( $key, 'phone' ) || false !== stripos( $key, 'tel' ) ) $type = 'tel';
					if ( false !== stripos( $key, 'date' ) ) $type = 'date';
					if ( false !== stripos( $key, 'number' ) || false !== stripos( $key, 'budget' ) || false !== stripos( $key, 'price' ) ) $type = 'number';

					/* translators: %s: Lowercase placeholder label */
					$wpwebmcp_label_placeholder = sprintf( __( 'Enter %s...', 'webmcp-nexus' ), strtolower( $label ) );

					if ( 'message' === $key || 'details' === $key || 'comments' === $key ) {
						?>
						<div>
							<label style="display:block; font-size:12px; font-weight:bold; margin-bottom:4px; color:#bac2de;"><?php echo esc_html( $label ); ?> *</label>
							<textarea name="<?php echo esc_attr( $key ); ?>" placeholder="<?php echo esc_attr( $wpwebmcp_label_placeholder ); ?>" toolparamdescription="<?php echo esc_attr( $label ); ?>" required rows="3" style="width:100%; background:#181825; border:1px solid #45475a; border-radius:6px; padding:8px 12px; color:#cdd6f4; font-size:14px; box-sizing:border-box;"></textarea>
						</div>
						<?php
					} else {
						?>
						<div>
							<label style="display:block; font-size:12px; font-weight:bold; margin-bottom:4px; color:#bac2de;"><?php echo esc_html( $label ); ?> *</label>
							<input type="<?php echo esc_attr( $type ); ?>" name="<?php echo esc_attr( $key ); ?>" placeholder="<?php echo esc_attr( $wpwebmcp_label_placeholder ); ?>" toolparamdescription="<?php echo esc_attr( $label ); ?>" required style="width:100%; background:#181825; border:1px solid #45475a; border-radius:6px; padding:8px 12px; color:#cdd6f4; font-size:14px; box-sizing:border-box;" />
						</div>
						<?php
					}
				}
				?>
				<button type="submit" style="background:#6366f1; color:#fff; border:none; border-radius:6px; padding:10px 16px; font-weight:bold; font-size:14px; cursor:pointer; margin-top:8px; transition:background 0.2s ease;">
					<?php echo esc_html( $btn_text ); ?>
				</button>
			</form>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Render `[webmcp_badge text="..."]`
	 *
	 * @param array<string, mixed> $atts
	 * @return string
	 */
	public static function render_badge( array $atts = array() ): string {
		$atts = shortcode_atts(
			array(
				'text'  => __( '⚡ AI Agent Ready (WebMCP 1.0)', 'webmcp-nexus' ),
				'link'  => home_url( '/llms.txt' ),
				'style' => 'inline',
			),
			$atts,
			'webmcp_badge'
		);

		return sprintf(
			'<a href="%s" target="_blank" rel="noopener" class="wpwm-badge" style="display:inline-flex; align-items:center; gap:6px; background:#1e1e2e; color:#a6e3a1; border:1px solid #a6e3a1; border-radius:20px; padding:4px 12px; font-size:12px; font-weight:bold; text-decoration:none; font-family:system-ui,sans-serif; box-shadow:0 2px 8px rgba(166,227,161,0.2); transition:transform 0.15s ease;">%s</a>',
			esc_url( $atts['link'] ),
			esc_html( $atts['text'] )
		);
	}

	/**
	 * Render `[webmcp_summary]` (AI-Powered Takeaways Box)
	 *
	 * @param array<string, mixed> $atts
	 * @return string
	 */
	public static function render_summary( array $atts = array() ): string {
		if ( ! is_singular() ) {
			return '';
		}

		$post = get_queried_object();
		if ( ! ( $post instanceof WP_Post ) ) {
			return '';
		}

		$title    = get_the_title( $post );
		$url      = get_permalink( $post );
		$md_url   = add_query_arg( 'format', 'markdown', $url );
		$raw_desc = ! empty( $post->post_excerpt ) ? $post->post_excerpt : wp_trim_words( $post->post_content, 35 );

		ob_start();
		?>
		<div class="wpwm-summary-card" style="background:#181825; border-left:4px solid #89b4fa; border-radius:0 8px 8px 0; padding:16px 20px; margin:20px 0; color:#cdd6f4; font-family:system-ui,sans-serif;">
			<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
				<strong style="color:#89b4fa; font-size:14px; display:flex; align-items:center; gap:6px;">
					<span>🤖</span> <?php esc_html_e( 'AI Summary & Key Takeaways', 'webmcp-nexus' ); ?>
				</strong>
				<a href="<?php echo esc_url( $md_url ); ?>" target="_blank" style="font-size:11px; color:#a6adc8; text-decoration:underline;">
					<?php esc_html_e( 'View Semantic Markdown', 'webmcp-nexus' ); ?> &rarr;
				</a>
			</div>
			<p style="margin:0; font-size:13px; line-height:1.6; color:#bac2de;">
				<?php echo esc_html( wp_strip_all_tags( (string) $raw_desc ) ); ?>
			</p>
		</div>
		<?php
		return (string) ob_get_clean();
	}
}
