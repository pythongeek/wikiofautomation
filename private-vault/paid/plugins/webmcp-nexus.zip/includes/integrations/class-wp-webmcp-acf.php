<?php
/**
 * Advanced Custom Fields (ACF) Integration — Doc §11.2.
 *
 * Automatically detects ACF Pro / Free and enriches getPostContent
 * tool results and schema with post custom fields when active.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_ACF {

	/**
	 * Initialize ACF integration hooks.
	 */
	public static function init(): void {
		if ( ! self::is_active() ) {
			return;
		}

		WP_WebMCP_Loader::register_filter( 'wpwebmcp_tool_schema',               array( __CLASS__, 'filter_tool_schema' ), 10, 2 );
		WP_WebMCP_Loader::register_filter( 'wpwebmcp_get_post_content_result',   array( __CLASS__, 'append_acf_fields' ), 10, 2 );
	}

	/**
	 * Check if ACF is active and enabled for WebMCP.
	 */
	public static function is_active(): bool {
		if ( ! function_exists( 'get_field_objects' ) && ! function_exists( 'acf_get_field_groups' ) ) {
			return false;
		}
		return (bool) get_option( 'wpwebmcp_acf_enabled', true );
	}

	/**
	 * Append ACF field values to getPostContent tool response.
	 *
	 * @param array $result Current tool result.
	 * @param array $params Request parameters containing post_id.
	 * @return array Enriched tool result.
	 */
	public static function append_acf_fields( array $result, array $params ): array {
		if ( ! self::is_active() ) {
			return $result;
		}

		$post_id = isset( $params['post_id'] ) ? absint( $params['post_id'] ) : 0;
		if ( $post_id <= 0 ) {
			return $result;
		}

		if ( function_exists( 'get_fields' ) ) {
			$fields = get_fields( $post_id );
			if ( is_array( $fields ) && ! empty( $fields ) ) {
				$result['acf'] = $fields;
			}
		} elseif ( function_exists( 'get_field_objects' ) ) {
			$objects = get_field_objects( $post_id );
			if ( is_array( $objects ) && ! empty( $objects ) ) {
				$formatted = array();
				foreach ( $objects as $key => $obj ) {
					$formatted[ $key ] = $obj['value'] ?? null;
				}
				$result['acf'] = $formatted;
			}
		}

		return $result;
	}

	/**
	 * Enforce ACF documentation in getPostContent tool schema.
	 *
	 * @param array  $schema Tool schema array.
	 * @param string $slug   Tool slug.
	 * @return array
	 */
	public static function filter_tool_schema( array $schema, string $slug ): array {
		if ( 'getPostContent' === $slug && self::is_active() ) {
			if ( ! isset( $schema['outputSchema'] ) ) {
				$schema['outputSchema'] = array(
					'type'       => 'object',
					'properties' => array(
						'acf' => array(
							'type'        => 'object',
							'description' => __( 'Custom fields managed by Advanced Custom Fields (ACF).', 'webmcp-nexus' ),
						),
					),
				);
			}
		}
		return $schema;
	}
}
