<?php
/**
 * WordPress Multisite integration — Doc §11.3.
 *
 * Provides network admin menu, network-level settings enforcement,
 * and per-site override policies across multisite networks.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Multisite {

	/**
	 * Capability required for network admin actions.
	 */
	private const NETWORK_CAPABILITY = 'manage_network_options';

	/**
	 * Initialize Multisite hooks if in multisite context.
	 */
	public static function init(): void {
		if ( ! is_multisite() ) {
			return;
		}

		WP_WebMCP_Loader::register_action( 'network_admin_menu',        array( __CLASS__, 'register_network_menu' ) );
		WP_WebMCP_Loader::register_action( 'admin_post_wpwebmcp_network_save', array( __CLASS__, 'save_network_settings' ) );
	}

	/**
	 * Register network admin menu under Settings.
	 */
	public static function register_network_menu(): void {
		add_submenu_page(
			'settings.php',
			__( 'WebMCP Nexus Network Settings', 'webmcp-nexus' ),
			__( 'WebMCP Nexus', 'webmcp-nexus' ),
			self::NETWORK_CAPABILITY,
			'wp-webmcp-network',
			array( __CLASS__, 'render_network_page' )
		);
	}

	/**
	 * Render network admin screen.
	 */
	public static function render_network_page(): void {
		if ( ! current_user_can( self::NETWORK_CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'webmcp-nexus' ) );
		}

		$partial = WEBMCP_NEXUS_PATH . 'admin/partials/wp-webmcp-network-admin.php';
		if ( file_exists( $partial ) ) {
			include $partial;
		}
	}

	/**
	 * Handle network settings form submission.
	 */
	public static function save_network_settings(): void {
		if ( ! current_user_can( self::NETWORK_CAPABILITY ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'webmcp-nexus' ) );
		}

		check_admin_referer( 'wpwebmcp_network_save_action', 'wpwebmcp_network_nonce' );

		$network_enabled = isset( $_POST['wpwebmcp_network_enabled'] ) ? 1 : 0;
		$force_sitewide  = isset( $_POST['wpwebmcp_force_sitewide'] ) ? 1 : 0;

		update_site_option( 'wpwebmcp_network_enabled', $network_enabled );
		update_site_option( 'wpwebmcp_force_sitewide', $force_sitewide );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => 'wp-webmcp-network',
					'updated' => 'true',
				),
				network_admin_url( 'settings.php' )
			)
		);
		exit;
	}

	/**
	 * Check if network mode enforces WebMCP globally.
	 */
	public static function is_globally_enforced(): bool {
		if ( ! is_multisite() ) {
			return false;
		}
		return (bool) get_site_option( 'wpwebmcp_force_sitewide', false );
	}
}
