<?php
/**
 * Privacy — WP Privacy API integration (GDPR / CCPA).
 *
 * Registers eraser and exporter callbacks so that WebMCP Nexus data
 * is fully covered by Tools → Export Personal Data and Tools →
 * Erase Personal Data in the WordPress admin.
 *
 * Coverage:
 *   - wpwebmcp_log           — tool-call audit rows (by user_id, fallback by ip_hashed)
 *   - wpwebmcp_bot_log       — AI bot visit rows (by ip_hashed)
 *   - user meta keys         — wpwebmcp_onboarding_dismissed, wpwebmcp_preview_seen
 *   - post meta key          — _wpwebmcp_override (per-post override flag)
 *
 * Wires in via WP_WebMCP::load_dependencies() + init() call.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- privacy exporter/eraser runs once per user request; `$table` is hardcoded `$wpdb->prefix` literal
final class WP_WebMCP_Privacy {

	/** Eraser + exporter array key used in the WP Privacy API responses. */
	private const DATA_KEY = 'webmcp-nexus';

	/**
	 * Hook registration. Called from WP_WebMCP::define_api_hooks() or init.
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_filter( 'wp_privacy_personal_data_eraser',  array( __CLASS__, 'register_eraser' ) );
		WP_WebMCP_Loader::register_filter( 'wp_privacy_personal_data_exporter', array( __CLASS__, 'register_exporter' ) );
	}

	/* ============================================================
	 * Eraser
	 * ============================================================ */

	/**
	 * Add our eraser to the WP Privacy API registry.
	 *
	 * @param array<int,array<string,mixed>> $erasers
	 * @return array<int,array<string,mixed>>
	 */
	public static function register_eraser( array $erasers ): array {
		$erasers[ self::DATA_KEY ] = array(
			'eraser_friendly_name' => __( 'WebMCP Nexus Eraser', 'webmcp-nexus' ),
			'callback'             => array( __CLASS__, 'erase' ),
		);
		return $erasers;
	}

	/**
	 * Erase every WebMCP personal-data row tied to the given email address.
	 *
	 * @param string $email_address
	 * @param int    $page           Pagination cursor.
	 * @return array{items_removed:bool,items_retained:bool,messages:array,done:bool}
	 */
	public static function erase( string $email_address, int $page = 1 ): array {
		global $wpdb;
		$items_removed = false;
		$messages      = array();
		$page          = max( 1, (int) $page );

		// Resolve user from email (if any).
		$user = get_user_by( 'email', $email_address );
		$user_id = $user ? (int) $user->ID : 0;

		// 1. Log rows — by user_id first.
		if ( $user_id > 0 ) {
			$log_table = $wpdb->prefix . 'wpwebmcp_log';
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
			$deleted = $wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$log_table} WHERE user_id = %d",
					$user_id
				)
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery
			if ( false !== $deleted && $deleted > 0 ) {
				$items_removed = true;
				$messages[]    = sprintf(
					/* translators: %d: number of rows */
					__( 'WebMCP: erased %d tool-call audit row(s) by user_id.', 'webmcp-nexus' ),
					(int) $deleted
				);
			}
		}

		// 2. Bot log rows — by ip_hashed. WordPress does not give us the
		//    IP at this layer; we can only zero out the hash by email.
		//    We drop the ip_hash column value where the user_id resolution
		//    is impossible, so we skip those rows (data retained, no link).
		//    Per Doc §9.6 + GDPR, IP-hash rows that cannot be linked to a
		//    verified user are NOT personal data and are kept for the
		//    bot analytics retention window.

		// 3. User meta.
		$meta_keys = array( 'wpwebmcp_onboarding_dismissed', 'wpwebmcp_preview_seen' );
		foreach ( $meta_keys as $key ) {
			if ( $user_id > 0 ) {
				$removed = delete_user_meta( $user_id, $key );
				if ( $removed ) {
					$items_removed = true;
					$messages[]    = sprintf(
						/* translators: %s: meta key */
						__( 'WebMCP: erased user meta "%s".', 'webmcp-nexus' ),
						$key
					);
				}
			}
		}

		// 4. Post meta (_wpwebmcp_override) on posts authored by this user.
		if ( $user_id > 0 ) {
			$postmeta_table = $wpdb->postmeta;
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
			$deleted = $wpdb->query(
				$wpdb->prepare(
					"DELETE pm FROM {$postmeta_table} pm
					 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
					 WHERE pm.meta_key = '_wpwebmcp_override' AND p.post_author = %d",
					$user_id
				)
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery
			if ( false !== $deleted && $deleted > 0 ) {
				$items_removed = true;
				$messages[]    = sprintf(
					/* translators: %d: number of rows */
					__( 'WebMCP: erased %d _wpwebmcp_override post meta row(s).', 'webmcp-nexus' ),
					(int) $deleted
				);
			}
		}

		return array(
			'items_removed'  => $items_removed,
			'items_retained' => false,
			'messages'       => $messages,
			'done'           => true,
		);
	}

	/* ============================================================
	 * Exporter
	 * ============================================================ */

	/**
	 * Add our exporter to the WP Privacy API registry.
	 *
	 * @param array<int,array<string,mixed>> $exporters
	 * @return array<int,array<string,mixed>>
	 */
	public static function register_exporter( array $exporters ): array {
		$exporters[ self::DATA_KEY ] = array(
			'exporter_friendly_name' => __( 'WebMCP Nexus Exporter', 'webmcp-nexus' ),
			'callback'               => array( __CLASS__, 'export' ),
		);
		return $exporters;
	}

	/**
	 * Export every WebMCP personal-data row tied to the given email address.
	 *
	 * @param string $email_address
	 * @param int    $page           Pagination cursor.
	 * @return array{data:array, done:bool}
	 */
	public static function export( string $email_address, int $page = 1 ): array {
		global $wpdb;
		$page = max( 1, (int) $page );
		$user = get_user_by( 'email', $email_address );
		$user_id = $user ? (int) $user->ID : 0;

		$export_items = array();

		// 1. Log rows by user_id.
		if ( $user_id > 0 ) {
			$log_table = $wpdb->prefix . 'wpwebmcp_log';
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT tool_name, params, status, error_message, execution_ms, logged_at
					 FROM {$log_table} WHERE user_id = %d ORDER BY logged_at DESC LIMIT 500",
					$user_id
				),
				ARRAY_A
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery
			if ( is_array( $rows ) ) {
				foreach ( $rows as $row ) {
					$export_items[] = array(
						'group_id'    => self::DATA_KEY,
						'group_label' => __( 'WebMCP Nexus', 'webmcp-nexus' ),
						'item_id'     => 'webmcp-log-' . md5( (string) ( $row['logged_at'] ?? '' ) . (string) ( $row['tool_name'] ?? '' ) ),
						'data'        => array(
							array(
								'name'  => __( 'Tool name', 'webmcp-nexus' ),
								'value' => (string) ( $row['tool_name'] ?? '' ),
							),
							array(
								'name'  => __( 'Status', 'webmcp-nexus' ),
								'value' => (string) ( $row['status'] ?? '' ),
							),
							array(
								'name'  => __( 'Error message', 'webmcp-nexus' ),
								'value' => (string) ( $row['error_message'] ?? '' ),
							),
							array(
								'name'  => __( 'Logged at (UTC)', 'webmcp-nexus' ),
								'value' => (string) ( $row['logged_at'] ?? '' ),
							),
						),
					);
				}
			}

			// 2. User meta.
			foreach ( array( 'wpwebmcp_onboarding_dismissed', 'wpwebmcp_preview_seen' ) as $key ) {
				$val = get_user_meta( $user_id, $key, true );
				if ( '' !== $val && false !== $val ) {
					$export_items[] = array(
						'group_id'    => self::DATA_KEY,
						'group_label' => __( 'WebMCP Nexus', 'webmcp-nexus' ),
						'item_id'     => 'webmcp-usermeta-' . $key,
						'data'        => array(
							array(
								'name'  => $key,
								'value' => (string) $val,
							),
						),
					);
				}
			}
		}

		return array(
			'data' => $export_items,
			'done' => true,
		);
	}
// phpcs:enable WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}
