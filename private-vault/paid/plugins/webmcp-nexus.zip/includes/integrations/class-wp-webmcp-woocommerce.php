<?php
/**
 * WooCommerce integration — Doc Part 8 + §11.1.
 *
 * Exposes tool runners for WooCommerce read and write tools.
 * Single entry point `WP_WebMCP_WooCommerce::resolve_tool( $slug )`.
 *
 * Tools supported:
 *   - Read: getProductDetails, searchProducts, checkStock, getCartContents, getRelatedProducts
 *   - Write: addToCart, updateQuantity, removeItem, applyCoupon
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- woocommerce_session_handler is a WooCommerce core hook (3rd-party plugin hook); not owned by us, cannot be renamed
final class WP_WebMCP_WooCommerce {

	/**
	 * Map of supported tools to runner method and write status.
	 *
	 * @var array<string, array{method: string, is_write: bool}>
	 */
	private const TOOLS = array(
		'getProductDetails'  => array( 'method' => 'execute_get_product_details',  'is_write' => false ),
		'searchProducts'     => array( 'method' => 'execute_search_products',      'is_write' => false ),
		'checkStock'         => array( 'method' => 'execute_check_stock',          'is_write' => false ),
		'getCartContents'    => array( 'method' => 'execute_get_cart_contents',    'is_write' => false ),
		'getRelatedProducts' => array( 'method' => 'execute_get_related_products', 'is_write' => false ),
		'addToCart'          => array( 'method' => 'execute_add_to_cart',          'is_write' => true ),
		'updateQuantity'     => array( 'method' => 'execute_update_quantity',      'is_write' => true ),
		'removeItem'         => array( 'method' => 'execute_remove_item',          'is_write' => true ),
		'applyCoupon'        => array( 'method' => 'execute_apply_coupon',         'is_write' => true ),
	);

	/**
	 * Resolve a tool slug to a runner callable and write-status.
	 *
	 * @param string $slug Tool slug.
	 * @return array{runner: callable, is_write: bool}|null
	 */
	public static function resolve_tool( string $slug ): ?array {
		if ( ! self::is_active() ) {
			return null;
		}

		if ( ! isset( self::TOOLS[ $slug ] ) ) {
			return null;
		}

		$def = self::TOOLS[ $slug ];
		return array(
			'runner'   => array( __CLASS__, $def['method'] ),
			'is_write' => $def['is_write'],
		);
	}

	/**
	 * Check if WooCommerce is installed and enabled for WebMCP.
	 *
	 * @return bool
	 */
	public static function is_active(): bool {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return false;
		}
		return (bool) get_option( 'wpwebmcp_woo_enabled', true );
	}

	/**
	 * Ensure WooCommerce session and cart are loaded during REST requests.
	 */
	public static function ensure_cart(): void {
		if ( ! function_exists( 'WC' ) || ! WC() ) {
			return;
		}

		if ( null === WC()->session ) {
			$session_class = apply_filters( 'woocommerce_session_handler', 'WC_Session_Handler' );
			if ( class_exists( $session_class ) ) {
				WC()->session = new $session_class();
				WC()->session->init();
			}
		}

		if ( null === WC()->customer && class_exists( 'WC_Customer' ) ) {
			WC()->customer = new WC_Customer( get_current_user_id(), true );
		}

		if ( null === WC()->cart && class_exists( 'WC_Cart' ) ) {
			WC()->cart = new WC_Cart();
		}
	}

	/* ============================================================
	 * Tool Executors — Read
	 * ============================================================ */

	/**
	 * getProductDetails executor.
	 */
	public static function execute_get_product_details( array $params ): array {
		$product_id = isset( $params['product_id'] ) ? absint( $params['product_id'] ) : 0;
		if ( $product_id <= 0 ) {
			return array( 'error' => __( 'Missing or invalid product_id.', 'webmcp-nexus' ) );
		}

		if ( ! function_exists( 'wc_get_product' ) ) {
			return array( 'error' => __( 'WooCommerce function wc_get_product not available.', 'webmcp-nexus' ) );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return array( 'error' => __( 'Product not found.', 'webmcp-nexus' ) );
		}

		$categories = array();
		$terms = get_the_terms( $product_id, 'product_cat' );
		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$categories[] = $term->name;
			}
		}

		return array(
			'ok'                => true,
			'id'                => $product->get_id(),
			'name'              => $product->get_name(),
			'slug'              => $product->get_slug(),
			'permalink'         => $product->get_permalink(),
			'price'             => $product->get_price(),
			'regular_price'     => $product->get_regular_price(),
			'sale_price'        => $product->get_sale_price(),
			'on_sale'           => $product->is_on_sale(),
			'in_stock'          => $product->is_in_stock(),
			'stock_status'      => $product->get_stock_status(),
			'stock_quantity'    => $product->get_stock_quantity(),
			'short_description' => wp_strip_all_tags( $product->get_short_description() ),
			'description'       => wp_strip_all_tags( $product->get_description() ),
			'categories'        => $categories,
		);
	}

	/**
	 * searchProducts executor.
	 */
	public static function execute_search_products( array $params ): array {
		if ( ! function_exists( 'wc_get_products' ) ) {
			return array( 'error' => __( 'WooCommerce function wc_get_products not available.', 'webmcp-nexus' ) );
		}

		$args = array(
			'limit'  => 10,
			'status' => 'publish',
		);

		if ( ! empty( $params['query'] ) ) {
			$args['s'] = sanitize_text_field( (string) $params['query'] );
		}

		if ( ! empty( $params['category'] ) ) {
			$args['category'] = array( sanitize_title( (string) $params['category'] ) );
		}

		if ( isset( $params['min_price'] ) && is_numeric( $params['min_price'] ) ) {
			$args['min_price'] = (float) $params['min_price'];
		}

		if ( isset( $params['max_price'] ) && is_numeric( $params['max_price'] ) ) {
			$args['max_price'] = (float) $params['max_price'];
		}

		if ( ! empty( $params['in_stock'] ) ) {
			$args['stock_status'] = 'instock';
		}

		$products = wc_get_products( $args );
		$results  = array();

		foreach ( $products as $product ) {
			$results[] = array(
				'id'           => $product->get_id(),
				'name'         => $product->get_name(),
				'price'        => $product->get_price(),
				'stock_status' => $product->get_stock_status(),
				'url'          => $product->get_permalink(),
			);
		}

		return array(
			'ok'      => true,
			'count'   => count( $results ),
			'results' => $results,
		);
	}

	/**
	 * checkStock executor.
	 */
	public static function execute_check_stock( array $params ): array {
		$product_id = isset( $params['product_id'] ) ? absint( $params['product_id'] ) : 0;
		if ( $product_id <= 0 ) {
			return array( 'error' => __( 'Missing or invalid product_id.', 'webmcp-nexus' ) );
		}

		if ( ! function_exists( 'wc_get_product' ) ) {
			return array( 'error' => __( 'WooCommerce function wc_get_product not available.', 'webmcp-nexus' ) );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return array( 'error' => __( 'Product not found.', 'webmcp-nexus' ) );
		}

		return array(
			'ok'             => true,
			'product_id'     => $product->get_id(),
			'in_stock'       => $product->is_in_stock(),
			'stock_status'   => $product->get_stock_status(),
			'stock_quantity' => $product->get_stock_quantity(),
		);
	}

	/**
	 * getCartContents executor.
	 */
	public static function execute_get_cart_contents( array $params = array() ): array {
		self::ensure_cart();

		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return array( 'error' => __( 'WooCommerce cart not initialized.', 'webmcp-nexus' ) );
		}

		$cart       = WC()->cart;
		$items      = array();
		$cart_items = $cart->get_cart();

		foreach ( $cart_items as $key => $item ) {
			$product = $item['data'] ?? null;
			$items[] = array(
				'cart_item_key' => $key,
				'product_id'    => (int) $item['product_id'],
				'name'          => $product ? $product->get_name() : '',
				'quantity'      => (int) $item['quantity'],
				'line_total'    => (float) ( $item['line_total'] ?? 0 ),
				'line_tax'      => (float) ( $item['line_tax'] ?? 0 ),
			);
		}

		return array(
			'ok'            => true,
			'items'         => $items,
			'item_count'    => (int) $cart->get_cart_contents_count(),
			'total'         => (float) $cart->get_total( 'edit' ),
			'subtotal'      => (float) $cart->get_subtotal(),
			'tax_total'     => (float) $cart->get_total_tax(),
			'applied_coupons' => $cart->get_applied_coupons(),
		);
	}

	/**
	 * getRelatedProducts executor.
	 */
	public static function execute_get_related_products( array $params ): array {
		$product_id = isset( $params['product_id'] ) ? absint( $params['product_id'] ) : 0;
		if ( $product_id <= 0 ) {
			return array( 'error' => __( 'Missing or invalid product_id.', 'webmcp-nexus' ) );
		}

		$limit = isset( $params['limit'] ) ? max( 1, min( 6, (int) $params['limit'] ) ) : 6;

		if ( ! function_exists( 'wc_get_related_products' ) || ! function_exists( 'wc_get_product' ) ) {
			return array( 'error' => __( 'WooCommerce functions not available.', 'webmcp-nexus' ) );
		}

		$related_ids = wc_get_related_products( $product_id, $limit );
		$results     = array();

		foreach ( $related_ids as $rel_id ) {
			$prod = wc_get_product( $rel_id );
			if ( $prod ) {
				$results[] = array(
					'id'           => $prod->get_id(),
					'name'         => $prod->get_name(),
					'price'        => $prod->get_price(),
					'stock_status' => $prod->get_stock_status(),
					'url'          => $prod->get_permalink(),
				);
			}
		}

		return array(
			'ok'      => true,
			'count'   => count( $results ),
			'results' => $results,
		);
	}

	/* ============================================================
	 * Tool Executors — Write
	 * ============================================================ */

	/**
	 * addToCart executor.
	 */
	public static function execute_add_to_cart( array $params ): array {
		self::ensure_cart();

		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return array( 'error' => __( 'WooCommerce cart not initialized.', 'webmcp-nexus' ) );
		}

		$product_id = isset( $params['product_id'] ) ? absint( $params['product_id'] ) : 0;
		$quantity   = isset( $params['quantity'] ) ? max( 1, min( 99, (int) $params['quantity'] ) ) : 1;

		if ( $product_id <= 0 ) {
			return array( 'error' => __( 'Missing or invalid product_id.', 'webmcp-nexus' ) );
		}

		$cart_key = WC()->cart->add_to_cart( $product_id, $quantity );
		if ( ! $cart_key ) {
			$notices = function_exists( 'wc_get_notices' ) ? wc_get_notices( 'error' ) : array();
			$err_msg = ! empty( $notices ) ? implode( ' ', wp_list_pluck( $notices, 'notice' ) ) : __( 'Could not add product to cart.', 'webmcp-nexus' );
			if ( function_exists( 'wc_clear_notices' ) ) {
				wc_clear_notices();
			}
			return array( 'error' => wp_strip_all_tags( $err_msg ) );
		}

		return array(
			'ok'            => true,
			'cart_item_key' => $cart_key,
			'product_id'    => $product_id,
			'quantity'      => $quantity,
			'cart_count'    => (int) WC()->cart->get_cart_contents_count(),
			'cart_total'    => (float) WC()->cart->get_total( 'edit' ),
		);
	}

	/**
	 * updateQuantity executor.
	 */
	public static function execute_update_quantity( array $params ): array {
		self::ensure_cart();

		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return array( 'error' => __( 'WooCommerce cart not initialized.', 'webmcp-nexus' ) );
		}

		$cart_key = isset( $params['cart_item_key'] ) ? sanitize_text_field( (string) $params['cart_item_key'] ) : '';
		if ( '' === $cart_key ) {
			return array( 'error' => __( 'Missing cart_item_key.', 'webmcp-nexus' ) );
		}

		$quantity = isset( $params['quantity'] ) ? max( 0, min( 99, (int) $params['quantity'] ) ) : 1;

		$updated = WC()->cart->set_quantity( $cart_key, $quantity, true );
		if ( ! $updated && 0 !== $quantity ) {
			return array( 'error' => __( 'Could not update cart quantity.', 'webmcp-nexus' ) );
		}

		return array(
			'ok'            => true,
			'cart_item_key' => $cart_key,
			'new_quantity'  => $quantity,
			'cart_count'    => (int) WC()->cart->get_cart_contents_count(),
			'cart_total'    => (float) WC()->cart->get_total( 'edit' ),
		);
	}

	/**
	 * removeItem executor.
	 */
	public static function execute_remove_item( array $params ): array {
		self::ensure_cart();

		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return array( 'error' => __( 'WooCommerce cart not initialized.', 'webmcp-nexus' ) );
		}

		$cart_key = isset( $params['cart_item_key'] ) ? sanitize_text_field( (string) $params['cart_item_key'] ) : '';
		if ( '' === $cart_key ) {
			return array( 'error' => __( 'Missing cart_item_key.', 'webmcp-nexus' ) );
		}

		$removed = WC()->cart->remove_cart_item( $cart_key );
		if ( ! $removed ) {
			return array( 'error' => __( 'Item not found in cart.', 'webmcp-nexus' ) );
		}

		return array(
			'ok'            => true,
			'removed_key'   => $cart_key,
			'cart_count'    => (int) WC()->cart->get_cart_contents_count(),
			'cart_total'    => (float) WC()->cart->get_total( 'edit' ),
		);
	}

	/**
	 * applyCoupon executor.
	 */
	public static function execute_apply_coupon( array $params ): array {
		self::ensure_cart();

		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return array( 'error' => __( 'WooCommerce cart not initialized.', 'webmcp-nexus' ) );
		}

		$code = isset( $params['code'] ) ? sanitize_text_field( (string) $params['code'] ) : '';
		if ( '' === $code ) {
			return array( 'error' => __( 'Missing coupon code.', 'webmcp-nexus' ) );
		}

		$applied = WC()->cart->apply_coupon( $code );
		if ( ! $applied ) {
			$notices = function_exists( 'wc_get_notices' ) ? wc_get_notices( 'error' ) : array();
			$err_msg = ! empty( $notices ) ? implode( ' ', wp_list_pluck( $notices, 'notice' ) ) : __( 'Invalid coupon code.', 'webmcp-nexus' );
			if ( function_exists( 'wc_clear_notices' ) ) {
				wc_clear_notices();
			}
			return array( 'error' => wp_strip_all_tags( $err_msg ) );
		}

		return array(
			'ok'              => true,
			'coupon_code'     => $code,
			'applied_coupons' => WC()->cart->get_applied_coupons(),
			'cart_total'      => (float) WC()->cart->get_total( 'edit' ),
		);
	}
// phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
}
