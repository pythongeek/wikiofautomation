<?php
/**
 * 404 context tools — Doc Part 8.
 *
 * Tools in scope: getSiteMap, searchSite, navigateTo.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Schema_404 {

	/**
	 * Build the 404-context tool list.
	 *
	 * @return array<int, array<string,mixed>> Tool definitions.
	 */
	public static function get_tools(): array {
		$read_limit  = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$write_limit = (int) get_option( 'wpwebmcp_rate_limit_write', 20 );

		$page_count = (int) wp_count_posts( 'page' )->publish;
		$post_count = (int) wp_count_posts( 'post' )->publish;

		$tools = array(
			array(
				'name'        => 'getSiteMap',
				'description' => sprintf(
					'Get a sitemap of up to 100 in-site URLs (home, pages, post archive, public CPT archives) to help recover from a 404. Currently %d published posts and %d pages.',
					$post_count,
					$page_count
				),
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => new stdClass(),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => '404',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'searchSite',
				'description' => 'Search public content for a query string when the requested URL was not found, returning up to 10 results with title, URL, excerpt.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'query' => array(
							'type'        => 'string',
							'description' => 'Search query (1-200 chars).',
							'minLength'   => 1,
							'maxLength'   => 200,
						),
					),
					'required' => array( 'query' ),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => '404',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'navigateTo',
				'description' => 'Navigate the browser to a known in-site URL: home page, posts page, archives, or any public post permalink. Same-origin only.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'path' => array(
							'type'        => 'string',
							'description' => 'In-site path or absolute URL starting with the site origin.',
							'minLength'   => 1,
							'maxLength'   => 500,
						),
					),
					'required' => array( 'path' ),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'all',
				'x-webmcp-rate-limit' => $read_limit,
			),
		);

		$tools = array_merge( $tools, self::custom_rows( '404' ) );

		foreach ( $tools as $i => $tool ) {
			$tools[ $i ] = (array) apply_filters( 'wpwebmcp_tool_schema_' . $tool['name'], $tool );
		}
		$tools = (array) apply_filters( 'wpwebmcp_tool_parameters', $tools, '404' );

		unset( $write_limit );

		return $tools;
	}

	private static function custom_rows( string $scope ): array {
		if ( ! class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			return array();
		}
		$read_limit  = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$write_limit = (int) get_option( 'wpwebmcp_rate_limit_write', 20 );
		$rows = WP_WebMCP_Tool_Repository::find_active( $scope );
		$out  = array();
		foreach ( $rows as $r ) {
			$is_write = ( 'write' === ( $r['tool_type'] ?? 'read' ) );
			$params   = self::decode_params( $r['parameters'] ?? '' );
			$out[]    = array(
				'name'              => (string) $r['tool_name'],
				'description'       => (string) $r['tool_description'],
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => $params ?: new stdClass(),
				),
				'x-webmcp-type'      => $is_write ? 'write' : 'read',
				'x-webmcp-scope'     => (string) $r['tool_scope'],
				'x-webmcp-rate-limit' => $is_write ? $write_limit : $read_limit,
				'x-webmcp-action'    => (string) $r['action_type'],
				'x-webmcp-action-value' => (string) $r['action_value'],
			);
		}
		return $out;
	}

	private static function decode_params( mixed $params ): array {
		if ( is_array( $params ) ) {
			return $params;
		}
		if ( is_string( $params ) && '' !== $params ) {
			$d = json_decode( $params, true );
			return is_array( $d ) ? $d : array();
		}
		return array();
	}
}
