<?php
/**
 * Archive context tools — Doc Part 8.
 *
 * Tools in scope: getArchivePosts, getPaginatedResults, filterByTaxonomy, navigateTo.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Schema_Archive {

	/**
	 * Build the archive-context tool list.
	 *
	 * @param array $archive_data Optional context data: 'queried_object' (WP_Term), 'queried_object_id', 'post_count', 'max_num_pages'.
	 * @return array<int, array<string,mixed>> Tool definitions.
	 */
	public static function get_tools( array $archive_data = array() ): array {
		$read_limit  = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$write_limit = (int) get_option( 'wpwebmcp_rate_limit_write', 20 );

		$archive_label = 'the current archive';
		$post_count    = (int) ( $archive_data['post_count'] ?? 0 );
		$max_pages     = (int) ( $archive_data['max_num_pages'] ?? 1 );
		$qo            = $archive_data['queried_object'] ?? null;
		if ( is_object( $qo ) && ! empty( $qo->name ) ) {
			$archive_label = (string) $qo->name;
		}

		$tools = array(
			array(
				'name'        => 'getArchivePosts',
				'description' => sprintf(
					'Get posts from the current archive (%s, %d posts across %d page(s)). Returns title, URL, excerpt, publish date.',
					$archive_label,
					$post_count,
					$max_pages
				),
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'limit' => array(
							'type'        => 'integer',
							'description' => 'Max posts to return (1-50).',
							'minimum'     => 1,
							'maximum'     => 50,
							'default'     => 10,
						),
						'offset' => array(
							'type'        => 'integer',
							'description' => 'Posts to skip from start of archive.',
							'minimum'     => 0,
							'default'     => 0,
						),
					),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'archive',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getPaginatedResults',
				'description' => sprintf(
					'Get a specific page from the current archive (%s). Total pages available: %d.',
					$archive_label,
					$max_pages
				),
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'page' => array(
							'type'        => 'integer',
							'description' => 'Page number to fetch (1-based, must be ≤ max_num_pages).',
							'minimum'     => 1,
							'default'     => 1,
						),
					),
					'required' => array( 'page' ),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'archive',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'filterByTaxonomy',
				'description' => 'Filter the current archive by a taxonomy term slug. Returns the resolved term archive URL and post count in that term.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'taxonomy' => array(
							'type'        => 'string',
							'description' => 'Taxonomy slug (e.g. "category", "post_tag", or a custom taxonomy).',
							'minLength'   => 1,
							'maxLength'   => 100,
						),
						'term' => array(
							'type'        => 'string',
							'description' => 'Term slug within that taxonomy.',
							'minLength'   => 1,
							'maxLength'   => 200,
						),
					),
					'required' => array( 'taxonomy', 'term' ),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'archive',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'navigateTo',
				'description' => 'Navigate the browser to a known in-site URL: home page, posts page, archives, or any public post permalink. Same-origin only.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'path' => array(
							'type'        => 'string',
							'description' => 'In-site path or absolute URL starting with the site origin.',
							'minLength'   => 1,
							'maxLength'   => 500,
						),
					),
					'required' => array( 'path' ),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'all',
				'x-webmcp-rate-limit' => $read_limit,
			),
		);

		$tools = array_merge( $tools, self::custom_rows( 'archive' ) );

		foreach ( $tools as $i => $tool ) {
			$tools[ $i ] = (array) apply_filters( 'wpwebmcp_tool_schema_' . $tool['name'], $tool );
		}
		$tools = (array) apply_filters( 'wpwebmcp_tool_parameters', $tools, 'archive' );

		unset( $write_limit );

		return $tools;
	}

	private static function custom_rows( string $scope ): array {
		if ( ! class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			return array();
		}
		$read_limit  = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$write_limit = (int) get_option( 'wpwebmcp_rate_limit_write', 20 );
		$rows = WP_WebMCP_Tool_Repository::find_active( $scope );
		$out  = array();
		foreach ( $rows as $r ) {
			$is_write = ( 'write' === ( $r['tool_type'] ?? 'read' ) );
			$params   = self::decode_params( $r['parameters'] ?? '' );
			$out[]    = array(
				'name'              => (string) $r['tool_name'],
				'description'       => (string) $r['tool_description'],
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => $params ?: new stdClass(),
				),
				'x-webmcp-type'      => $is_write ? 'write' : 'read',
				'x-webmcp-scope'     => (string) $r['tool_scope'],
				'x-webmcp-rate-limit' => $is_write ? $write_limit : $read_limit,
				'x-webmcp-action'    => (string) $r['action_type'],
				'x-webmcp-action-value' => (string) $r['action_value'],
			);
		}
		return $out;
	}

	private static function decode_params( mixed $params ): array {
		if ( is_array( $params ) ) {
			return $params;
		}
		if ( is_string( $params ) && '' !== $params ) {
			$d = json_decode( $params, true );
			return is_array( $d ) ? $d : array();
		}
		return array();
	}
}
