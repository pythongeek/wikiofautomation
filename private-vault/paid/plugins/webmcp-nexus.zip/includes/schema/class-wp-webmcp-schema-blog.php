<?php
/**
 * Content & Blog Site context tools — WebMCP Nexus.
 *
 * Tools in scope:
 *   - getLatestArticles: Paginated blog posts with clean excerpts, categories, and read times.
 *   - getPopularArticles: Most viewed, shared, and commented articles.
 *   - getAuthorProfile: Contributor bio, avatar, social handles, and post archive.
 *   - estimateReadingTime: Estimated reading minutes and word count for an article.
 *   - getNewsletterInfo: Newsletter schedule, topics, and subscription information.
 *   - listCategories: Browse category hierarchy and post counts.
 *   - listTags: View content tags.
 *   - searchSite, navigateTo.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Schema_Blog {

	/**
	 * Build the blog & content site tool list.
	 *
	 * @return array<int, array<string,mixed>> Tool definitions.
	 */
	public static function get_tools(): array {
		$read_limit = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$site_name  = (string) get_bloginfo( 'name' );

		$tools = array(
			array(
				'name'        => 'getLatestArticles',
				'description' => sprintf(
					'Get the latest published blog articles on %s with clean summary, author, and publication date.',
					$site_name !== '' ? $site_name : 'this blog'
				),
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'limit'    => array(
							'type'        => 'integer',
							'description' => 'Maximum number of articles (1-20).',
							'minimum'     => 1,
							'maximum'     => 20,
							'default'     => 5,
						),
						'category' => array(
							'type'        => 'string',
							'description' => 'Optional category slug filter.',
						),
					),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'blog',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getPopularArticles',
				'description' => 'Retrieve most popular and commented blog posts across the site.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'limit' => array(
							'type'        => 'integer',
							'description' => 'Maximum number of popular articles (1-10).',
							'minimum'     => 1,
							'maximum'     => 10,
							'default'     => 5,
						),
					),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'blog',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getAuthorProfile',
				'description' => 'Get author biography, credentials, social links, and recent published posts. Defaults to current post author or administrator when omitted.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'author' => array(
							'type'        => 'string',
							'description' => 'Author username, display name, or numeric ID. Defaults to current post author when omitted.',
							'minLength'   => 1,
						),
					),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'blog',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'estimateReadingTime',
				'description' => 'Calculate estimated reading time in minutes and total word count for an article. Defaults to current post when omitted.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id' => array(
							'type'        => 'integer',
							'description' => 'WordPress post ID. Defaults to current post when omitted.',
							'minimum'     => 1,
						),
					),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'blog',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getNewsletterInfo',
				'description' => 'Get newsletter publication schedule, topics covered, and subscriber overview.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'blog',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'listCategories',
				'description' => 'Explore the taxonomy categories with post counts and hierarchy links.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'blog',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'listTags',
				'description' => 'View popular content tags used across published articles.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'blog',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'searchSite',
				'description' => 'Search all blog articles and pages by keyword query.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'query' => array(
							'type'        => 'string',
							'description' => 'Search query (1-200 chars).',
							'minLength'   => 1,
							'maxLength'   => 200,
						),
					),
					'required'   => array( 'query' ),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'all',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'navigateTo',
				'description' => 'Navigate the browser to any article, category archive, or author page.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'path' => array(
							'type'        => 'string',
							'description' => 'In-site path or absolute URL starting with site origin.',
							'minLength'   => 1,
							'maxLength'   => 500,
						),
					),
					'required'   => array( 'path' ),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'all',
				'x-webmcp-rate-limit' => $read_limit,
			),
		);

		return $tools;
	}
}
