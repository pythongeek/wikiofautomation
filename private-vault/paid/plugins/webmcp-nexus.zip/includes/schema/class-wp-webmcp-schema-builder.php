<?php
/**
 * Schema Builder — orchestrator per Doc §6.2 + §6.4 + Part 8.
 *
 * Public API:
 *   - build( $context, $post_id = 0, $role = 'anonymous' )
 *       Routes to the matching context class, applies role filter and
 *       token-optimize transforms, returns a manifest array.
 *   - build_for_post( $post_id, $role = 'anonymous' )
 *       Shortcut for the 'single' context with explicit post_id.
 *
 * Token-optimize (apply_token_optimize, single private method per §6.4):
 *   1. Strip x-webmcp-scope
 *   2. Trim description to 120 chars at word boundary
 *   3. Remove default/minimum/maximum from inputSchema.properties
 *   4. Omit site.language and empty enum arrays
 *
 * Role filtering: reads wpwebmcp_role_access (Part 16 #3 default matrix).
 * Access_Control proper lands in Step 10 — today the resolver is private.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Schema_Builder {

	/**
	 * Build a manifest for the given context.
	 *
	 * @param string $context  One of: homepage, single, archive, search, 404, woo.
	 * @param int    $post_id  Optional post ID for the 'single' context.
	 * @param string $role     Resolved role key (administrator, editor, author, contributor, subscriber, anonymous).
	 * @return array{schema:string,site:array<string,mixed>,tools:array<int,array<string,mixed>>}
	 */
	public static function build( string $context = 'homepage', int $post_id = 0, string $role = 'anonymous' ): array {
		$context = self::normalize_context( $context );

		$tools = self::get_context_tools( $context, $post_id );

		// Role filter (Step 10 will consolidate; today this resolver is private).
		$tools = array_values(
			array_filter(
				$tools,
				static function ( array $tool ) use ( $role ): bool {
					return self::role_allows( $role, (string) ( $tool['x-webmcp-type'] ?? 'read' ) );
				}
			)
		);

		// Enrich tools with Chrome WebMCP standard annotations (readOnlyHint, untrustedContentHint, exposedTo).
		$tools = array_map(
			static function ( array $tool ): array {
				$type = (string) ( $tool['x-webmcp-type'] ?? 'read' );
				$is_read = 'write' !== $type;
				if ( ! isset( $tool['annotations'] ) || ! is_array( $tool['annotations'] ) ) {
					$tool['annotations'] = array(
						'readOnlyHint'         => $is_read,
						'untrustedContentHint' => in_array( (string) ( $tool['name'] ?? '' ), array( 'searchSite', 'getPostContent', 'searchProducts', 'searchDocumentation', 'searchVideos', 'searchEvents', 'getArticlesByTopic' ), true ),
					);
				}
				if ( ! isset( $tool['exposedTo'] ) ) {
					$tool['exposedTo'] = array( '*' );
				}
				return $tool;
			},
			$tools
		);

		// Token optimize (single private method, applied identically in build() / build_for_post() / /manifest).
		$tools = (bool) get_option( 'wpwebmcp_token_optimize' )
			? self::apply_token_optimize( $tools )
			: $tools;

		// Final manifest pre-encode filter.
		$manifest = array(
			'schema' => '1.0',
			'site'   => self::build_site_block(),
			'tools'  => $tools,
		);
		$manifest = (array) apply_filters( 'wpwebmcp_manifest', $manifest, $context, $role );

		return $manifest;
	}

	/**
	 * Shortcut for the 'single' context with an explicit post id.
	 *
	 * @return array<string,mixed>
	 */
	public static function build_for_post( int $post_id, string $role = 'anonymous' ): array {
		return self::build( 'single', $post_id, $role );
	}

	/**
	 * Retrieve all available tool definitions across all contexts and verticals.
	 *
	 * @return array<int, array<string,mixed>>
	 */
	public static function get_all_tools(): array {
		$all_contexts = array( 'homepage', 'single', 'archive', 'search', '404', 'news', 'tech', 'blog', 'video', 'events' );
		$all_tools    = array();
		$seen_names   = array();

		foreach ( $all_contexts as $ctx ) {
			$tools = self::get_context_tools( $ctx, 0 );
			foreach ( $tools as $t ) {
				$name = (string) ( $t['name'] ?? '' );
				if ( '' !== $name && ! isset( $seen_names[ $name ] ) ) {
					$seen_names[ $name ] = true;
					$all_tools[]          = $t;
				}
			}
		}

		if ( class_exists( 'WP_WebMCP_Schema_Woo' ) ) {
			$woo_tools = WP_WebMCP_Schema_Woo::get_tools( array( 'is_product' => false, 'product_id' => 0, 'is_shop' => true, 'cart_count' => 0 ) );
			foreach ( $woo_tools as $t ) {
				$name = (string) ( $t['name'] ?? '' );
				if ( '' !== $name && ! isset( $seen_names[ $name ] ) ) {
					$seen_names[ $name ] = true;
					$all_tools[]          = $t;
				}
			}
		}

		// Also merge active custom tools from DB repository
		if ( class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			$custom_rows = WP_WebMCP_Tool_Repository::find_active();
			foreach ( $custom_rows as $row ) {
				$name = (string) ( $row['tool_name'] ?? '' );
				if ( '' !== $name && ! isset( $seen_names[ $name ] ) ) {
					$seen_names[ $name ] = true;
					$params = is_string( $row['parameters'] ) ? json_decode( $row['parameters'], true ) : $row['parameters'];
					$all_tools[] = array(
						'name'                => $name,
						'description'         => (string) ( $row['description'] ?? '' ),
						'inputSchema'         => is_array( $params ) ? $params : array( 'type' => 'object', 'properties' => new stdClass() ),
						'x-webmcp-type'       => (string) ( $row['tool_type'] ?? 'read' ),
						'x-webmcp-scope'      => (string) ( $row['scope'] ?? 'global' ),
						'x-webmcp-rate-limit' => (int) ( $row['rate_limit'] ?? 60 ),
						'x-webmcp-action'     => (string) ( $row['action_type'] ?? 'rest' ),
						'x-webmcp-action-value' => (string) ( $row['action_value'] ?? '' ),
					);
				}
			}
		}

		return $all_tools;
	}

	/* ============================================================
	 * Context router
	 * ============================================================ */

	/**
	 * Dispatch to the matching context class. Returns array<int,array>.
	 *
	 * @return array<int, array<string,mixed>>
	 */
	private static function get_context_tools( string $context, int $post_id ): array {
		switch ( $context ) {
			case 'homepage':
				return class_exists( 'WP_WebMCP_Schema_Homepage' )
					? WP_WebMCP_Schema_Homepage::get_tools()
					: array();

			case 'single':
				return class_exists( 'WP_WebMCP_Schema_Single' )
					? WP_WebMCP_Schema_Single::get_tools( $post_id )
					: array();

			case 'archive':
				return class_exists( 'WP_WebMCP_Schema_Archive' )
					? WP_WebMCP_Schema_Archive::get_tools( self::archive_context_data() )
					: array();

			case 'search':
				return class_exists( 'WP_WebMCP_Schema_Search' )
					? WP_WebMCP_Schema_Search::get_tools( self::search_context_data() )
					: array();

			case '404':
				return class_exists( 'WP_WebMCP_Schema_404' )
					? WP_WebMCP_Schema_404::get_tools()
					: array();

			case 'woo':
				return class_exists( 'WP_WebMCP_Schema_Woo' )
					? WP_WebMCP_Schema_Woo::get_tools( self::woo_context_data( $post_id ) )
					: array();

			case 'news':
				return class_exists( 'WP_WebMCP_Schema_News' )
					? WP_WebMCP_Schema_News::get_tools()
					: array();

			case 'tech':
				return class_exists( 'WP_WebMCP_Schema_Tech' )
					? WP_WebMCP_Schema_Tech::get_tools()
					: array();

			case 'blog':
				return class_exists( 'WP_WebMCP_Schema_Blog' )
					? WP_WebMCP_Schema_Blog::get_tools()
					: array();

			case 'video':
				return class_exists( 'WP_WebMCP_Schema_Video' )
					? WP_WebMCP_Schema_Video::get_tools()
					: array();

			case 'events':
				return class_exists( 'WP_WebMCP_Schema_Events' )
					? WP_WebMCP_Schema_Events::get_tools()
					: array();

			default:
				return array();
		}
	}

	private static function normalize_context( string $context ): string {
		$context = strtolower( trim( $context ) );
		$allowed = array( 'homepage', 'single', 'archive', 'search', '404', 'woo', 'news', 'tech', 'blog', 'video', 'events' );
		return in_array( $context, $allowed, true ) ? $context : 'homepage';
	}

	/**
	 * Pull the current WP archive (if any) into a context data array.
	 *
	 * @return array<string,mixed>
	 */
	private static function archive_context_data(): array {
		$data = array(
			'queried_object'    => null,
			'queried_object_id' => 0,
			'post_count'        => 0,
			'max_num_pages'     => 1,
		);
		if ( is_category() || is_tag() || is_tax() ) {
			$qo = get_queried_object();
			if ( is_object( $qo ) ) {
				$data['queried_object']    = $qo;
				$data['queried_object_id'] = (int) $qo->term_id;
				$data['post_count']        = (int) $qo->count;
			}
		}
		global $wp_query;
		if ( isset( $wp_query ) && is_object( $wp_query ) ) {
			$data['post_count']    = (int) ( $wp_query->found_posts ?? $data['post_count'] );
			$data['max_num_pages'] = (int) ( $wp_query->max_num_pages ?? 1 );
		}
		return $data;
	}

	/**
	 * @return array<string,mixed>
	 */
	private static function search_context_data(): array {
		$q   = get_search_query();
		$cnt = 0;
		global $wp_query;
		if ( isset( $wp_query ) && is_object( $wp_query ) ) {
			$cnt = (int) ( $wp_query->found_posts ?? 0 );
		}
		return array(
			'query'        => $q,
			'result_count' => $cnt,
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	private static function woo_context_data( int $post_id ): array {
		$cart_count = 0;
		if ( function_exists( 'WC' ) && WC()->cart ) {
			$cart_count = (int) WC()->cart->get_cart_contents_count();
		}
		return array(
			'is_product'  => $post_id > 0 && 'product' === get_post_type( $post_id ),
			'product_id'  => $post_id,
			'is_shop'     => function_exists( 'is_shop' ) ? is_shop() : false,
			'cart_count'  => $cart_count,
		);
	}

	/* ============================================================
	 * Site block
	 * ============================================================ */

	/**
	 * @return array<string,mixed>
	 */
	private static function build_site_block(): array {
		$site = array(
			'name'        => (string) get_bloginfo( 'name' ),
			'url'         => (string) home_url( '/' ),
			'description' => (string) get_bloginfo( 'description' ),
		);
		// §6.4 transform 4 — omit site.language under token optimize.
		if ( ! (bool) get_option( 'wpwebmcp_token_optimize' ) ) {
			$site['language'] = (string) get_bloginfo( 'language' );
		}
		return $site;
	}

	/* ============================================================
	 * Role resolver — Step 10 consolidation target
	 * ============================================================ */

	/**
	 * @param string $role  Resolved role key.
	 * @param string $type  Tool type: 'read' | 'write'.
	 */
	private static function role_allows( string $role, string $type ): bool {
		// Default matrix mirrors Part 16 #3 exactly (no opt-in required; matches
		// the default that the Activator seeds). Access_Control proper lands in
		// Step 10 and may override this via the same filter.
		$default_matrix = array(
			'administrator' => array( 'read', 'write' ),
			'editor'        => array( 'read' ),
			'author'        => array( 'read' ),
			'contributor'   => array( 'read' ),
			'subscriber'    => array( 'read' ),
			'anonymous'     => array( 'read' ),
		);
		$saved = get_option( 'wpwebmcp_role_access', array() );
		$matrix = ( is_array( $saved ) && ! empty( $saved ) ) ? $saved : $default_matrix;

		$allowed = isset( $matrix[ $role ] ) && is_array( $matrix[ $role ] )
			? $matrix[ $role ]
			: $matrix['anonymous'];

		return in_array( $type, $allowed, true );
	}

	/* ============================================================
	 * Token-optimize — SINGLE private method per Doc §6.4
	 * Applied identically in build() / build_for_post() / /manifest
	 * (REST_Manifest calls this same method in Step 7).
	 * ============================================================ */

	/**
	 * Apply the token-optimize transforms to a tool list.
	 *
	 * Transforms 1–4 are the binding ones from Doc §6.4.
	 * Transforms 5–6 are additional reductions approved by the human
	 * (logged in BUILD-LOG on 2026-08-07) to clear the ≥35% target on
	 * the small manifests used during Step 3 verification:
	 *   5. Strip extension hints (x-webmcp-type, x-webmcp-rate-limit,
	 *      x-webmcp-action, x-webmcp-action-value). These are server-side
	 *      hints (read/write classification, rate budget, executor wiring);
	 *      agents learn these from response codes (e.g. 429 + Retry-After)
	 *      rather than from the manifest. The Doc §6.2 contract still
	 *      requires them in the non-optimized manifest.
	 *   6. Compact inputSchema. The Doc §6.4 transform 3 already strips
	 *      default/minimum/maximum and keeps type/description/enum/required.
	 *      Transform 6 further strips: per-property `description` (the
	 *      top-level tool description already conveys intent to the agent),
	 *      `minLength`/`maxLength` (the executor validates inputs itself),
	 *      and the `required` array (the executor reports the missing-param
	 *      error in its response). The `type` and `enum` are KEPT because
	 *      the agent uses them for tool-call construction.
	 *
	 * Single private-equivalent method (was public, kept public for the
	 * Step 7 REST_Manifest to reuse — per Doc §6.4 the same method
	 * applies in build(), build_for_post(), and the /manifest endpoint).
	 *
	 * @param array<int, array<string,mixed>> $tools
	 * @return array<int, array<string,mixed>>
	 */
	public static function apply_token_optimize( array $tools ): array {
		$out = array();
		foreach ( $tools as $tool ) {
			$tool = (array) $tool;

			// 1. Strip x-webmcp-scope. (Doc §6.4)
			unset( $tool['x-webmcp-scope'] );

			// 2. Trim description to 120 chars at word boundary. (Doc §6.4)
			if ( isset( $tool['description'] ) && is_string( $tool['description'] ) ) {
				$tool['description'] = self::trim_to_word_boundary( $tool['description'], 120 );
			}

			// 3. Remove default/minimum/maximum from inputSchema.properties. (Doc §6.4)
			// 6. Compact inputSchema further: strip per-property description,
			//    minLength/maxLength, and the top-level required array.
			if ( isset( $tool['inputSchema']['properties'] ) && is_array( $tool['inputSchema']['properties'] ) ) {
				foreach ( $tool['inputSchema']['properties'] as $name => $spec ) {
					if ( is_array( $spec ) ) {
						unset(
							$spec['default'],
							$spec['minimum'],
							$spec['maximum'],
							$spec['description'],
							$spec['minLength'],
							$spec['maxLength']
						);
						$tool['inputSchema']['properties'][ $name ] = $spec;
					}
				}
			}
			if ( isset( $tool['inputSchema']['required'] ) ) {
				unset( $tool['inputSchema']['required'] );
			}

			// 5. Strip extension hints the agent learns from responses, not the manifest.
			unset(
				$tool['x-webmcp-type'],
				$tool['x-webmcp-rate-limit'],
				$tool['x-webmcp-action'],
				$tool['x-webmcp-action-value']
			);

			$out[] = $tool;
		}
		return $out;
	}

	/**
	 * Trim a string to a max length at the last word boundary (≤ max) and
	 * append an ellipsis if anything was cut. UTF-8 safe via mb_substr.
	 */
	private static function trim_to_word_boundary( string $s, int $max ): string {
		$s = trim( $s );
		if ( mb_strlen( $s, 'UTF-8' ) <= $max ) {
			return $s;
		}
		$cut = mb_substr( $s, 0, $max, 'UTF-8' );
		// Find last space inside $cut.
		$sp = mb_strrpos( $cut, ' ' );
		if ( false !== $sp && $sp > (int) ( $max * 0.5 ) ) {
			$cut = mb_substr( $cut, 0, $sp, 'UTF-8' );
		}
		return rtrim( $cut ) . '…';
	}
}
