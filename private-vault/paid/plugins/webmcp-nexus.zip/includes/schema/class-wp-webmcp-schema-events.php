<?php
/**
 * Events & Community Site context tools — WebMCP Nexus.
 *
 * Tools in scope:
 *   - getUpcomingEvents: Scheduled webinars, meetups, conferences, and dates.
 *   - getEventDetails: Agenda, speakers, location/virtual link, and registration.
 *   - searchEvents: Search events by topic, date, or location.
 *   - searchSite, navigateTo.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Schema_Events {

	/**
	 * Build the events & community tool list.
	 *
	 * @return array<int, array<string,mixed>> Tool definitions.
	 */
	public static function get_tools(): array {
		$read_limit = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$site_name  = (string) get_bloginfo( 'name' );

		$tools = array(
			array(
				'name'        => 'getUpcomingEvents',
				'description' => sprintf(
					'Get scheduled upcoming events, webinars, workshops, and conferences on %s.',
					$site_name !== '' ? $site_name : 'this site'
				),
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'limit' => array(
							'type'        => 'integer',
							'description' => 'Maximum number of events to return (1-20).',
							'minimum'     => 1,
							'maximum'     => 20,
							'default'     => 10,
						),
					),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'events',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getEventDetails',
				'description' => 'Get full details for a specific event: dates, venue/URL, organizer, agenda, ticket price, and registration. Defaults to current post when omitted.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'event_id' => array(
							'type'        => 'integer',
							'description' => 'WordPress post or event ID. Defaults to current post when omitted.',
							'minimum'     => 1,
						),
					),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'events',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'searchEvents',
				'description' => 'Search and filter events by topic, date, venue location, or keyword.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'query'    => array(
							'type'        => 'string',
							'description' => 'Event search keyword or city/topic.',
							'minLength'   => 1,
							'maxLength'   => 200,
						),
						'category' => array(
							'type'        => 'string',
							'description' => 'Event category slug.',
						),
					),
					'required'   => array( 'query' ),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'events',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'searchSite',
				'description' => 'Search all site content and event archives.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'query' => array(
							'type'        => 'string',
							'description' => 'Search query (1-200 chars).',
							'minLength'   => 1,
							'maxLength'   => 200,
						),
					),
					'required'   => array( 'query' ),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'all',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'navigateTo',
				'description' => 'Navigate the browser to any event page or calendar URL.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'path' => array(
							'type'        => 'string',
							'description' => 'In-site path or absolute URL starting with site origin.',
							'minLength'   => 1,
							'maxLength'   => 500,
						),
					),
					'required'   => array( 'path' ),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'all',
				'x-webmcp-rate-limit' => $read_limit,
			),
		);

		return $tools;
	}
}
