<?php
/**
 * Homepage context tools — Doc Part 8.
 *
 * Tools in scope: getSiteInfo, getFeaturedContent, navigateTo, searchSite.
 * Plus any custom rows from Tool_Repository::find_active( 'homepage' ) OR
 * rows whose scope is 'all'.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Schema_Homepage {

	/**
	 * Build the homepage-context tool list.
	 *
	 * @return array<int, array<string,mixed>> Tool definitions.
	 */
	public static function get_tools(): array {
		$read_limit  = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$write_limit = (int) get_option( 'wpwebmcp_rate_limit_write', 20 );

		// Live data samples used in description text (so descriptions are "≥20 chars, LIVE data").
		$site_name        = (string) get_bloginfo( 'name' );
		$post_count_label = self::human_count( wp_count_posts()->publish ?? 0 );
		$featured_titles  = self::recent_titles_for_description( 3 );

		$tools = array(
			array(
				'name'        => 'getSiteInfo',
				'description' => sprintf(
					'Get metadata about this site: %s. Returns name, description, URL, language, admin URL, post count (%s), and active theme.',
					$site_name !== '' ? $site_name : 'this WordPress site',
					$post_count_label
				),
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => new stdClass(),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'homepage',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getFeaturedContent',
				'description' => sprintf(
					'Get the latest posts published on %s, up to 20 entries with title, URL, excerpt and publish date. Most recent titles include: %s.',
					$site_name !== '' ? $site_name : 'this site',
					$featured_titles
				),
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'limit' => array(
							'type'        => 'integer',
							'description' => 'Maximum number of posts to return (1-20).',
							'minimum'     => 1,
							'maximum'     => 20,
							'default'     => 5,
						),
					),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'homepage',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'searchSite',
				'description' => 'Search public content across the site for a query string, returning up to 10 results with title, URL, excerpt.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'query' => array(
							'type'        => 'string',
							'description' => 'Search query (1-200 chars).',
							'minLength'   => 1,
							'maxLength'   => 200,
						),
					),
					'required' => array( 'query' ),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'homepage',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'navigateTo',
				'description' => 'Navigate the browser to a known in-site URL: home page, posts page, archives, or any public post permalink. Same-origin only.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'path' => array(
							'type'        => 'string',
							'description' => 'In-site path or absolute URL starting with the site origin. Examples: "/", "/about/", "/category/news/".',
							'minLength'   => 1,
							'maxLength'   => 500,
						),
					),
					'required' => array( 'path' ),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'all',
				'x-webmcp-rate-limit' => $read_limit,
			),
		);

		// Merge active custom rows whose scope is 'homepage' or 'all'.
		$tools = array_merge( $tools, self::custom_rows( 'homepage' ) );

		/**
		 * Filters a single homepage-context tool definition.
		 *
		 * @param array $tool Tool definition.
		 */
		foreach ( $tools as $i => $tool ) {
			$tools[ $i ] = (array) apply_filters( 'wpwebmcp_tool_schema_' . $tool['name'], $tool );
		}

		/**
		 * Filters the homepage tool list (after per-tool filters).
		 *
		 * @param array $tools Tool definitions.
		 */
		$tools = (array) apply_filters( 'wpwebmcp_tool_parameters', $tools, 'homepage' );

		return $tools;
	}

	/* ---------- internals ---------- */

	private static function custom_rows( string $scope ): array {
		if ( ! class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			return array();
		}
		$read_limit  = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$write_limit = (int) get_option( 'wpwebmcp_rate_limit_write', 20 );

		$rows     = WP_WebMCP_Tool_Repository::find_active( $scope );
		$out      = array();
		foreach ( $rows as $r ) {
			$is_write  = ( 'write' === ( $r['tool_type'] ?? 'read' ) );
			$params    = self::decode_params( $r['parameters'] ?? '' );
			$out[]     = array(
				'name'              => (string) $r['tool_name'],
				'description'       => (string) $r['tool_description'],
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => $params ?: new stdClass(),
				),
				'x-webmcp-type'      => $is_write ? 'write' : 'read',
				'x-webmcp-scope'     => (string) $r['tool_scope'],
				'x-webmcp-rate-limit' => $is_write ? $write_limit : $read_limit,
				'x-webmcp-action'    => (string) $r['action_type'],
				'x-webmcp-action-value' => (string) $r['action_value'],
			);
		}
		return $out;
	}

	private static function decode_params( mixed $params ): array {
		if ( is_array( $params ) ) {
			return $params;
		}
		if ( is_string( $params ) && '' !== $params ) {
			$d = json_decode( $params, true );
			return is_array( $d ) ? $d : array();
		}
		return array();
	}

	private static function recent_titles_for_description( int $count ): string {
		$posts = get_posts(
			array(
				'post_type'        => 'post',
				'post_status'      => 'publish',
				'numberposts'      => $count,
				'orderby'          => 'date',
				'order'            => 'DESC',
				'suppress_filters' => false,
			)
		);
		if ( empty( $posts ) ) {
			return 'no posts yet';
		}
		$titles = array();
		foreach ( $posts as $p ) {
			if ( is_object( $p ) && isset( $p->post_title ) ) {
				$titles[] = (string) $p->post_title;
			} elseif ( is_numeric( $p ) ) {
				$titles[] = get_the_title( (int) $p );
			}
		}
		return ! empty( $titles ) ? implode( ', ', $titles ) : 'no posts yet';
	}

	private static function human_count( int $n ): string {
		if ( $n < 1000 ) {
			return (string) $n;
		}
		if ( $n < 10000 ) {
			return round( $n / 1000, 1 ) . 'k';
		}
		return round( $n / 1000 ) . 'k';
	}
}
