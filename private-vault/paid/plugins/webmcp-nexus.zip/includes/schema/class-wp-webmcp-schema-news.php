<?php
/**
 * News & Media Site context tools — WebMCP Nexus.
 *
 * Tools in scope:
 *   - getBreakingNews: Retrieve urgent breaking news flashes, alerts, and timestamps.
 *   - getArticlesByTopic: Query news stories filtered by category/topic and date.
 *   - getTrendingNews: Top read/trending stories based on engagement and recent velocity.
 *   - getFactCheckSummary: Fact-checking verdicts, claim reviews, and verified sources.
 *   - getEditorialStaff: Journalists, columnists, beat reporters, and author biographies.
 *   - searchSite, navigateTo.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Schema_News {

	/**
	 * Build the news-context tool list.
	 *
	 * @return array<int, array<string,mixed>> Tool definitions.
	 */
	public static function get_tools(): array {
		$read_limit = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$site_name  = (string) get_bloginfo( 'name' );

		$tools = array(
			array(
				'name'        => 'getBreakingNews',
				'description' => sprintf(
					'Retrieve urgent breaking news flashes, headlines, and live coverage from %s.',
					$site_name !== '' ? $site_name : 'this news portal'
				),
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'limit' => array(
							'type'        => 'integer',
							'description' => 'Maximum number of breaking news alerts to return (1-10).',
							'minimum'     => 1,
							'maximum'     => 10,
							'default'     => 3,
						),
					),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'news',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getArticlesByTopic',
				'description' => 'Query news articles filtered by editorial category, topic slug, or section.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'topic' => array(
							'type'        => 'string',
							'description' => 'Topic or category slug (e.g. "politics", "business", "technology", "world", "sports"). Defaults to all or top category when omitted.',
							'minLength'   => 1,
							'maxLength'   => 100,
						),
						'limit' => array(
							'type'        => 'integer',
							'description' => 'Maximum number of articles to return (1-20).',
							'minimum'     => 1,
							'maximum'     => 20,
							'default'     => 10,
						),
					),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'news',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getTrendingNews',
				'description' => 'Retrieve top trending and most discussed news stories based on reader velocity and comments.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'limit' => array(
							'type'        => 'integer',
							'description' => 'Maximum number of trending stories to return (1-15).',
							'minimum'     => 1,
							'maximum'     => 15,
							'default'     => 5,
						),
					),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'news',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getFactCheckSummary',
				'description' => 'Retrieve fact-checking verdicts, claim reviews, and primary sources on specified topics or claims.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'query' => array(
							'type'        => 'string',
							'description' => 'Topic, claim statement, or headline keyword to check for verified claims.',
							'minLength'   => 1,
							'maxLength'   => 200,
						),
					),
					'required'   => array( 'query' ),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'news',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getEditorialStaff',
				'description' => 'Get journalist, editor, and columnist profiles, beat topics, and recent publication bylines.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'role' => array(
							'type'        => 'string',
							'description' => 'Optional filter for editorial role (e.g. "editor", "author", "columnist").',
						),
					),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'news',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'searchSite',
				'description' => 'Search all published articles, archives, and reporting by keyword query.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'query' => array(
							'type'        => 'string',
							'description' => 'Search query (1-200 chars).',
							'minLength'   => 1,
							'maxLength'   => 200,
						),
					),
					'required'   => array( 'query' ),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'all',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'navigateTo',
				'description' => 'Navigate the browser to any news section, article URL, or category page.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'path' => array(
							'type'        => 'string',
							'description' => 'In-site path or absolute URL starting with site origin.',
							'minLength'   => 1,
							'maxLength'   => 500,
						),
					),
					'required'   => array( 'path' ),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'all',
				'x-webmcp-rate-limit' => $read_limit,
			),
		);

		return $tools;
	}
}
