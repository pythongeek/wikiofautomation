<?php
/**
 * Search context tools — Doc Part 8.
 *
 * Tools in scope: getSearchResults, refineSearch, getSearchSuggestions, navigateTo.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Schema_Search {

	/**
	 * Build the search-context tool list.
	 *
	 * @param array $search_data Optional context data: 'query' (current search string), 'result_count'.
	 * @return array<int, array<string,mixed>> Tool definitions.
	 */
	public static function get_tools( array $search_data = array() ): array {
		$read_limit  = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$write_limit = (int) get_option( 'wpwebmcp_rate_limit_write', 20 );

		$query_label = '';
		if ( ! empty( $search_data['query'] ) ) {
			$query_label = ' Current query: "' . (string) $search_data['query'] . '" (' . (int) ( $search_data['result_count'] ?? 0 ) . ' results).';
		}

		$tools = array(
			array(
				'name'        => 'getSearchResults',
				'description' => 'Run a full search query across public post types and return up to 10 matching posts with title, URL, excerpt.' . $query_label,
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'query' => array(
							'type'        => 'string',
							'description' => 'Search query (1-200 chars).',
							'minLength'   => 1,
							'maxLength'   => 200,
						),
						'page' => array(
							'type'        => 'integer',
							'description' => 'Page number (1-based).',
							'minimum'     => 1,
							'default'     => 1,
						),
					),
					'required' => array( 'query' ),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'search',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'refineSearch',
				'description' => 'Refine a search by adding extra terms or restricting to a specific post type. Returns the new result set.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'query' => array(
							'type'        => 'string',
							'description' => 'Base search query (1-200 chars).',
							'minLength'   => 1,
							'maxLength'   => 200,
						),
						'extra' => array(
							'type'        => 'string',
							'description' => 'Additional terms to AND with the base query.',
							'maxLength'   => 200,
						),
						'post_type' => array(
							'type'        => 'string',
							'description' => 'Restrict to a public post type slug (e.g. "post", "page").',
							'maxLength'   => 100,
						),
					),
					'required' => array( 'query' ),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'search',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getSearchSuggestions',
				'description' => 'Get up to 10 title-prefix suggestions matching the prefix. Useful for type-ahead completion.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'prefix' => array(
							'type'        => 'string',
							'description' => 'Prefix to match against post titles (1-100 chars).',
							'minLength'   => 1,
							'maxLength'   => 100,
						),
					),
					'required' => array( 'prefix' ),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'search',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'navigateTo',
				'description' => 'Navigate the browser to a known in-site URL: home page, posts page, archives, or any public post permalink. Same-origin only.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'path' => array(
							'type'        => 'string',
							'description' => 'In-site path or absolute URL starting with the site origin.',
							'minLength'   => 1,
							'maxLength'   => 500,
						),
					),
					'required' => array( 'path' ),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'all',
				'x-webmcp-rate-limit' => $read_limit,
			),
		);

		$tools = array_merge( $tools, self::custom_rows( 'search' ) );

		foreach ( $tools as $i => $tool ) {
			$tools[ $i ] = (array) apply_filters( 'wpwebmcp_tool_schema_' . $tool['name'], $tool );
		}
		$tools = (array) apply_filters( 'wpwebmcp_tool_parameters', $tools, 'search' );

		unset( $write_limit );

		return $tools;
	}

	private static function custom_rows( string $scope ): array {
		if ( ! class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			return array();
		}
		$read_limit  = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$write_limit = (int) get_option( 'wpwebmcp_rate_limit_write', 20 );
		$rows = WP_WebMCP_Tool_Repository::find_active( $scope );
		$out  = array();
		foreach ( $rows as $r ) {
			$is_write = ( 'write' === ( $r['tool_type'] ?? 'read' ) );
			$params   = self::decode_params( $r['parameters'] ?? '' );
			$out[]    = array(
				'name'              => (string) $r['tool_name'],
				'description'       => (string) $r['tool_description'],
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => $params ?: new stdClass(),
				),
				'x-webmcp-type'      => $is_write ? 'write' : 'read',
				'x-webmcp-scope'     => (string) $r['tool_scope'],
				'x-webmcp-rate-limit' => $is_write ? $write_limit : $read_limit,
				'x-webmcp-action'    => (string) $r['action_type'],
				'x-webmcp-action-value' => (string) $r['action_value'],
			);
		}
		return $out;
	}

	private static function decode_params( mixed $params ): array {
		if ( is_array( $params ) ) {
			return $params;
		}
		if ( is_string( $params ) && '' !== $params ) {
			$d = json_decode( $params, true );
			return is_array( $d ) ? $d : array();
		}
		return array();
	}
}
