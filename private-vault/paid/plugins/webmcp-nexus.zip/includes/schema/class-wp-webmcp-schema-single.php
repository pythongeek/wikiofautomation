<?php
/**
 * Single-post context tools — Doc Part 8.
 *
 * Tools in scope: getPostContent, getPostMeta, getRelatedPosts,
 * navigateToCategory, navigateTo.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Schema_Single {

	/**
	 * Build the single-context tool list.
	 *
	 * @param int $post_id The current post ID (used to populate LIVE descriptions).
	 * @return array<int, array<string,mixed>> Tool definitions.
	 */
	public static function get_tools( int $post_id = 0 ): array {
		$read_limit  = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$write_limit = (int) get_option( 'wpwebmcp_rate_limit_write', 20 );

		$live_title = '';
		$live_cats  = '';
		if ( $post_id > 0 ) {
			$p = get_post( $post_id );
			if ( $p ) {
				$live_title = (string) $p->post_title;
				$cats       = wp_get_post_terms( $post_id, 'category', array( 'fields' => 'names' ) );
				$live_cats  = is_array( $cats ) ? implode( ', ', $cats ) : '';
			}
		}

		$tools = array(
			array(
				'name'        => 'getPostContent',
				'description' => sprintf(
					'Get the full content of a post by ID, returning plain-text title, content, excerpt, author, publish date, categories and tags%s.',
					$live_title !== '' ? ". Current page: \"{$live_title}\"" : ''
				),
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'post_id' => array(
							'type'        => 'integer',
							'description' => 'Post ID to retrieve. Defaults to the current post when omitted.',
							'minimum'     => 1,
						),
					),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'single',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getPostMeta',
				'description' => 'Get public (non-underscored) post meta fields for a given post. Defaults to current post when omitted.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'post_id' => array(
							'type'        => 'integer',
							'description' => 'Post ID. Defaults to current post when omitted.',
							'minimum'     => 1,
						),
					),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'single',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getRelatedPosts',
				'description' => sprintf(
					'Get up to 10 posts that share at least one category with the current post%s, excluding the post itself.',
					$live_cats !== '' ? " (categories: {$live_cats})" : ''
				),
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'post_id' => array(
							'type'        => 'integer',
							'description' => 'Reference post ID. Defaults to current post.',
							'minimum'     => 1,
						),
						'limit' => array(
							'type'        => 'integer',
							'description' => 'Maximum related posts to return (1-10).',
							'minimum'     => 1,
							'maximum'     => 10,
							'default'     => 5,
						),
					),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'single',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'navigateToCategory',
				'description' => 'Navigate the browser to a category archive page by slug. Returns the resolved term URL.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'slug' => array(
							'type'        => 'string',
							'description' => 'Category slug (lowercase, no spaces).',
							'minLength'   => 1,
							'maxLength'   => 200,
						),
					),
					'required' => array( 'slug' ),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'single',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'navigateTo',
				'description' => 'Navigate the browser to a known in-site URL: home page, posts page, archives, or any public post permalink. Same-origin only.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'path' => array(
							'type'        => 'string',
							'description' => 'In-site path or absolute URL starting with the site origin.',
							'minLength'   => 1,
							'maxLength'   => 500,
						),
					),
					'required' => array( 'path' ),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'all',
				'x-webmcp-rate-limit' => $read_limit,
			),
		);

		// Merge active custom rows whose scope is 'single' or 'all'.
		$tools = array_merge( $tools, self::custom_rows( 'single' ) );

		foreach ( $tools as $i => $tool ) {
			$tools[ $i ] = (array) apply_filters( 'wpwebmcp_tool_schema_' . $tool['name'], $tool );
		}
		$tools = (array) apply_filters( 'wpwebmcp_tool_parameters', $tools, 'single' );

		// Unused write_limit warning suppression (kept for parity with other contexts).
		unset( $write_limit );

		return $tools;
	}

	private static function custom_rows( string $scope ): array {
		if ( ! class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			return array();
		}
		$read_limit  = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$write_limit = (int) get_option( 'wpwebmcp_rate_limit_write', 20 );

		$rows = WP_WebMCP_Tool_Repository::find_active( $scope );
		$out  = array();
		foreach ( $rows as $r ) {
			$is_write = ( 'write' === ( $r['tool_type'] ?? 'read' ) );
			$params   = self::decode_params( $r['parameters'] ?? '' );
			$out[]    = array(
				'name'              => (string) $r['tool_name'],
				'description'       => (string) $r['tool_description'],
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => $params ?: new stdClass(),
				),
				'x-webmcp-type'      => $is_write ? 'write' : 'read',
				'x-webmcp-scope'     => (string) $r['tool_scope'],
				'x-webmcp-rate-limit' => $is_write ? $write_limit : $read_limit,
				'x-webmcp-action'    => (string) $r['action_type'],
				'x-webmcp-action-value' => (string) $r['action_value'],
			);
		}
		return $out;
	}

	private static function decode_params( mixed $params ): array {
		if ( is_array( $params ) ) {
			return $params;
		}
		if ( is_string( $params ) && '' !== $params ) {
			$d = json_decode( $params, true );
			return is_array( $d ) ? $d : array();
		}
		return array();
	}
}
