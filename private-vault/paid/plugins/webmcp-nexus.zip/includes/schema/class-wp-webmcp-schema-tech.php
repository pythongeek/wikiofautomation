<?php
/**
 * Tech & Documentation Site context tools — WebMCP Nexus.
 *
 * Tools in scope:
 *   - searchDocumentation: Technical documentation, guides, FAQs, and manual search.
 *   - getApiReference: API endpoints, parameters, models, headers, and responses.
 *   - getCodeSnippet: Copy-pasteable code examples by programming language.
 *   - getVersionChangelog: Release notes, new features, bugfixes, and breaking changes.
 *   - getTechnicalSpecs: Environment requirements, dependencies, and compatibility matrices.
 *   - searchSite, navigateTo.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Schema_Tech {

	/**
	 * Build the tech & documentation tool list.
	 *
	 * @return array<int, array<string,mixed>> Tool definitions.
	 */
	public static function get_tools(): array {
		$read_limit = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$site_name  = (string) get_bloginfo( 'name' );

		$tools = array(
			array(
				'name'        => 'searchDocumentation',
				'description' => sprintf(
					'Search developer documentation, technical manuals, tutorials, and knowledge base on %s.',
					$site_name !== '' ? $site_name : 'this tech site'
				),
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'query'   => array(
							'type'        => 'string',
							'description' => 'Technical search query keywords, error messages, or function names.',
							'minLength'   => 1,
							'maxLength'   => 200,
						),
						'section' => array(
							'type'        => 'string',
							'description' => 'Optional documentation section or category filter.',
						),
					),
					'required'   => array( 'query' ),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'tech',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getApiReference',
				'description' => 'Get structured API endpoints, methods, parameters, request body schemas, and response formats. Defaults to WebMCP Manifest endpoint when omitted.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'endpoint' => array(
							'type'        => 'string',
							'description' => 'API endpoint path or operation name (e.g. "/v1/users", "createOrder"). Defaults to /wp-json/wpwebmcp/v1/manifest when omitted.',
							'minLength'   => 1,
							'maxLength'   => 200,
						),
					),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'tech',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getCodeSnippet',
				'description' => 'Retrieve verified, copy-pasteable code examples filtered by programming language and topic.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'topic'    => array(
							'type'        => 'string',
							'description' => 'Topic or function to get code sample for. Defaults to general example when omitted.',
							'minLength'   => 1,
							'maxLength'   => 150,
						),
						'language' => array(
							'type'        => 'string',
							'description' => 'Programming language (e.g. "php", "javascript", "python", "bash", "json").',
						),
					),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'tech',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getVersionChangelog',
				'description' => 'Retrieve release notes, version history, new features, bug fixes, and breaking changes.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'version' => array(
							'type'        => 'string',
							'description' => 'Optional specific version string (e.g. "2.1.0" or "latest").',
						),
					),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'tech',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getTechnicalSpecs',
				'description' => 'Extract technical specifications, server requirements, hardware requirements, and compatibility tables.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'subject' => array(
							'type'        => 'string',
							'description' => 'Product or software topic to get technical specifications for.',
						),
					),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'tech',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'searchSite',
				'description' => 'Search all public technical articles, guides, and documentation by keyword.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'query' => array(
							'type'        => 'string',
							'description' => 'Search query (1-200 chars).',
							'minLength'   => 1,
							'maxLength'   => 200,
						),
					),
					'required'   => array( 'query' ),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'all',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'navigateTo',
				'description' => 'Navigate the browser to any guide, documentation section, or reference URL.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'path' => array(
							'type'        => 'string',
							'description' => 'In-site path or absolute URL starting with site origin.',
							'minLength'   => 1,
							'maxLength'   => 500,
						),
					),
					'required'   => array( 'path' ),
				),
				'x-webmcp-type'       => 'read',
				'x-webmcp-scope'      => 'all',
				'x-webmcp-rate-limit' => $read_limit,
			),
		);

		return $tools;
	}
}
