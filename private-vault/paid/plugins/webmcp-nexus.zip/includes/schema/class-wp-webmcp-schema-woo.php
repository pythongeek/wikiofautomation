<?php
/**
 * Woo context tools — Doc Part 8.
 *
 * Tools in scope: getProductDetails, searchProducts, checkStock, getCartContents,
 * getRelatedProducts (read); addToCart, updateQuantity, removeItem, applyCoupon (write).
 *
 * No-op when WooCommerce is not active OR `wpwebmcp_woo_enabled` is false
 * (Doc Part 8 "guarded no-op" + Step 3 hard rule).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Schema_Woo {

	/**
	 * Build the Woo-context tool list.
	 *
	 * Returns an empty array when Woo is unavailable — the orchestrator treats
	 * `woo` like any other scope (no special handling needed).
	 *
	 * @param array $woo_data Optional context data: 'is_product', 'product_id', 'is_shop', 'cart_count'.
	 * @return array<int, array<string,mixed>> Tool definitions.
	 */
	public static function get_tools( array $woo_data = array() ): array {
		if ( ! self::is_woo_active() ) {
			return array();
		}

		$read_limit  = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$write_limit = (int) get_option( 'wpwebmcp_rate_limit_write', 20 );

		$is_product = ! empty( $woo_data['is_product'] );
		$product_id = (int) ( $woo_data['product_id'] ?? 0 );
		$cart_count = (int) ( $woo_data['cart_count'] ?? 0 );

		$live_label = '';
		if ( $is_product && $product_id > 0 ) {
			$p = get_post( $product_id );
			if ( $p ) {
				$live_label = '. Current product: "' . (string) $p->post_title . '"';
			}
		}

		$tools = array(
			array(
				'name'        => 'getProductDetails',
				'description' => sprintf(
					'Get full product details by ID: name, price, stock status, attributes, permalink%s.',
					$live_label
				),
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'product_id' => array(
							'type'        => 'integer',
							'description' => 'WooCommerce product ID.',
							'minimum'     => 1,
						),
					),
					'required' => array( 'product_id' ),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'woo',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'searchProducts',
				'description' => 'Search products by free-text query with optional category, price-range, and stock filters. Returns up to 10 products with title, price, stock status, URL.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'query'      => array(
							'type'        => 'string',
							'description' => 'Product search query (1-200 chars).',
							'maxLength'   => 200,
						),
						'category'   => array(
							'type'        => 'string',
							'description' => 'Restrict to a product category slug.',
							'maxLength'   => 100,
						),
						'min_price'  => array(
							'type'        => 'number',
							'description' => 'Minimum price (inclusive).',
						),
						'max_price'  => array(
							'type'        => 'number',
							'description' => 'Maximum price (inclusive).',
						),
						'in_stock'   => array(
							'type'        => 'boolean',
							'description' => 'Only return in-stock products.',
						),
					),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'woo',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'checkStock',
				'description' => 'Check the current stock status and quantity for a given product ID.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'product_id' => array(
							'type'        => 'integer',
							'description' => 'WooCommerce product ID.',
							'minimum'     => 1,
						),
					),
					'required' => array( 'product_id' ),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'woo',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getCartContents',
				'description' => sprintf(
					'Get the current cart contents as structured JSON (items, quantities, line totals, coupons). Current item count: %d.',
					$cart_count
				),
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => new stdClass(),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'woo',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'getRelatedProducts',
				'description' => 'Get up to 6 products related to a given product by category and tag overlap.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'product_id' => array(
							'type'        => 'integer',
							'description' => 'WooCommerce product ID.',
							'minimum'     => 1,
						),
						'limit'      => array(
							'type'        => 'integer',
							'description' => 'Maximum related products (1-6).',
							'minimum'     => 1,
							'maximum'     => 6,
							'default'     => 6,
						),
					),
					'required' => array( 'product_id' ),
				),
				'x-webmcp-type'      => 'read',
				'x-webmcp-scope'     => 'woo',
				'x-webmcp-rate-limit' => $read_limit,
			),
			array(
				'name'        => 'addToCart',
				'description' => 'Add a product to the cart by product ID and quantity. Write tool — requires authentication.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'product_id' => array(
							'type'        => 'integer',
							'description' => 'WooCommerce product ID.',
							'minimum'     => 1,
						),
						'quantity'   => array(
							'type'        => 'integer',
							'description' => 'Quantity to add (1-99).',
							'minimum'     => 1,
							'maximum'     => 99,
							'default'     => 1,
						),
					),
					'required' => array( 'product_id' ),
				),
				'x-webmcp-type'      => 'write',
				'x-webmcp-scope'     => 'woo',
				'x-webmcp-rate-limit' => $write_limit,
			),
			array(
				'name'        => 'updateQuantity',
				'description' => 'Set the quantity of an existing cart item. Write tool — requires authentication.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'cart_item_key' => array(
							'type'        => 'string',
							'description' => 'Cart item key (as returned by getCartContents).',
							'minLength'   => 1,
							'maxLength'   => 100,
						),
						'quantity' => array(
							'type'        => 'integer',
							'description' => 'New quantity (0-99). 0 removes the item.',
							'minimum'     => 0,
							'maximum'     => 99,
						),
					),
					'required' => array( 'cart_item_key', 'quantity' ),
				),
				'x-webmcp-type'      => 'write',
				'x-webmcp-scope'     => 'woo',
				'x-webmcp-rate-limit' => $write_limit,
			),
			array(
				'name'        => 'removeItem',
				'description' => 'Remove a cart item by its key. Write tool — requires authentication.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'cart_item_key' => array(
							'type'        => 'string',
							'description' => 'Cart item key to remove.',
							'minLength'   => 1,
							'maxLength'   => 100,
						),
					),
					'required' => array( 'cart_item_key' ),
				),
				'x-webmcp-type'      => 'write',
				'x-webmcp-scope'     => 'woo',
				'x-webmcp-rate-limit' => $write_limit,
			),
			array(
				'name'        => 'applyCoupon',
				'description' => 'Apply a coupon code to the cart. Write tool — requires authentication.',
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => array(
						'code' => array(
							'type'        => 'string',
							'description' => 'Coupon code (uppercase recommended).',
							'minLength'   => 1,
							'maxLength'   => 100,
						),
					),
					'required' => array( 'code' ),
				),
				'x-webmcp-type'      => 'write',
				'x-webmcp-scope'     => 'woo',
				'x-webmcp-rate-limit' => $write_limit,
			),
		);

		// Merge active custom rows whose scope is 'woo' or 'all'.
		$tools = array_merge( $tools, self::custom_rows( 'woo' ) );

		foreach ( $tools as $i => $tool ) {
			$tools[ $i ] = (array) apply_filters( 'wpwebmcp_tool_schema_' . $tool['name'], $tool );
		}
		$tools = (array) apply_filters( 'wpwebmcp_tool_parameters', $tools, 'woo' );

		return $tools;
	}

	/**
	 * Whether Woo tools should be exposed.
	 */
	public static function is_woo_active(): bool {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return false;
		}
		// wpwebmcp_woo_enabled is seeded as bool(true) but stored as "" — coerce.
		return (bool) get_option( 'wpwebmcp_woo_enabled', true );
	}

	private static function custom_rows( string $scope ): array {
		if ( ! class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			return array();
		}
		$read_limit  = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$write_limit = (int) get_option( 'wpwebmcp_rate_limit_write', 20 );
		$rows = WP_WebMCP_Tool_Repository::find_active( $scope );
		$out  = array();
		foreach ( $rows as $r ) {
			$is_write = ( 'write' === ( $r['tool_type'] ?? 'read' ) );
			$params   = self::decode_params( $r['parameters'] ?? '' );
			$out[]    = array(
				'name'              => (string) $r['tool_name'],
				'description'       => (string) $r['tool_description'],
				'inputSchema'       => array(
					'type'       => 'object',
					'properties' => $params ?: new stdClass(),
				),
				'x-webmcp-type'      => $is_write ? 'write' : 'read',
				'x-webmcp-scope'     => (string) $r['tool_scope'],
				'x-webmcp-rate-limit' => $is_write ? $write_limit : $read_limit,
				'x-webmcp-action'    => (string) $r['action_type'],
				'x-webmcp-action-value' => (string) $r['action_value'],
			);
		}
		return $out;
	}

	private static function decode_params( mixed $params ): array {
		if ( is_array( $params ) ) {
			return $params;
		}
		if ( is_string( $params ) && '' !== $params ) {
			$d = json_decode( $params, true );
			return is_array( $d ) ? $d : array();
		}
		return array();
	}
}
