<?php
/**
 * Pack_Filter_Bridge — adapter that routes pack tool calls through the executor's
 * "hook" action_type.
 *
 * SDK part of A6 (Vertical Tool Packs Marketplace). When a pack tool is registered
 * via WP_WebMCP_Tool_Repository with action_type='hook' and action_value='<pack_slug>::<tool_key>',
 * the executor's custom_tool_runner() invokes the wpwebmcp_tool_call_response filter
 * with that action_value. This bridge listens on that filter and dispatches to the
 * matching pack's runner if one is registered.
 *
 * Pattern for pack authors (in bootstrap.php):
 *
 *   add_filter( 'wpwebmcp_pack_runner_recipes', array( __CLASS__, 'run_tool' ), 10, 3 );
 *
 *   public static function run_tool( $default, $tool_key, $params ) {
 *       switch ( $tool_key ) {
 *           case 'search_recipes': return self::search( $params );
 *           case 'get_recipe':     return self::get( $params );
 *       }
 *       return $default;
 *   }
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- $filter_name is a per-pack filter name built from pack manifest data
final class WP_WebMCP_Pack_Filter_Bridge {

	/**
	 * Hook into the executor's "hook" action_type.
	 *
	 * Hooked on plugins_loaded so the pack bootstrap has a chance to register its
	 * own filter first (priorities: pack registers at default 10, this dispatches
	 * at default 10 too — but the dispatch happens AFTER pack filters because the
	 * executor runs at tools call time, well after plugins_loaded).
	 */
	public static function init(): void {
		add_filter( 'wpwebmcp_tool_call_response', array( self::class, 'dispatch' ), 20, 3 );
	}

	/**
	 * Dispatch a tool call to the appropriate pack runner.
	 *
	 * Expected action_value format: "<pack_slug>::<tool_key>".
	 * Falls through (returns the original $response unchanged) for action_values
	 * that do not match this pattern, so other "hook" consumers keep working.
	 *
	 * @param mixed  $response     Default response (array) or null from prior filters.
	 * @param string $action_value The action_value stored in the tool row.
	 * @param array  $params       Tool call parameters.
	 * @return mixed
	 */
	public static function dispatch( $response, string $action_value, array $params ) {
		if ( '' === $action_value || false === strpos( $action_value, '::' ) ) {
			return $response;
		}

		list( $pack_slug, $tool_key ) = explode( '::', $action_value, 2 );
		$pack_slug = trim( $pack_slug );
		$tool_key  = trim( $tool_key );

		if ( '' === $pack_slug || '' === $tool_key ) {
			return $response;
		}

		$filter_name = 'wpwebmcp_pack_runner_' . sanitize_key( $pack_slug );

		/**
		 * Filter: wpwebmcp_pack_runner_{slug}.
		 *
		 * Pack authors hook this filter in their bootstrap.php to receive tool calls.
		 * Receives ($default_response, $tool_key, $params). Return the tool result
		 * array — or $default_response to fall through.
		 *
		 * @since 1.0.0
		 * @param array  $response     Default response from prior filters.
		 * @param string $tool_key     Tool key inside the pack (snake_case).
		 * @param array  $params       Tool call parameters.
		 */
		$dispatched = apply_filters( $filter_name, $response, $tool_key, $params );

		return $dispatched;
	}
// phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound
}
