<?php
/**
 * Pack_Loader — discovers packs and bootstraps installed ones on every request.
 *
 * SDK part of A6 (Vertical Tool Packs Marketplace). On plugins_loaded this loader:
 *   1. Ensures wp-content/wp-webmcp-packs/ exists.
 *   2. For each installed pack, loads its bootstrap.php (registers CPTs/taxonomies
 *      and tools via WP_WebMCP_Tool_Repository).
 *   3. Initializes the filter bridge that routes tool calls to the right pack.
 *
 * Bootstraps are idempotent: install/uninstall is admin-driven, and the loader
 * only runs each bootstrap for packs present in the registry.
 *
 * On plugin activation, bundled packs are copied into the user's pack directory
 * (idempotent — does not overwrite if already present).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Pack_Loader {

	/**
	 * Hook the loader. Called from the plugin's main bootstrap.
	 */
	public static function init(): void {
		// F3 loader fix: init() itself is now invoked directly from
		// WP_WebMCP::run() rather than queued onto plugins_loaded (which had
		// already fired, so the sub-hooks below raced priorities that never
		// ran and installed packs were never booted on later requests).
		self::seed_bundled_packs();
		add_action( 'init', array( self::class, 'load_installed_packs' ), 5 );
		add_action( 'plugins_loaded', array( 'WP_WebMCP_Pack_Filter_Bridge', 'init' ), 40 );
	}

	/**
	 * Copy bundled packs from the plugin directory into the user's pack directory.
	 *
	 * Idempotent: only copies when the destination doesn't exist. Runs at
	 * plugin activation time.
	 *
	 * @return void
	 */
	public static function seed_bundled_packs(): void {
		$bundled_root = trailingslashit( WEBMCP_NEXUS_PATH ) . 'packs';
		if ( ! is_dir( $bundled_root ) ) {
			return;
		}

		$dest_root = WP_WebMCP_Pack_Registry::packs_root();
		if ( ! is_dir( $dest_root ) ) {
			@wp_mkdir_p( $dest_root );
		}

		if ( ! is_dir( $dest_root ) || ! wp_is_writable( $dest_root ) ) {
			// If destination cannot be created or written to (e.g. read-only filesystem),
			// WP_WebMCP_Pack_Registry will discover and run bundled packs directly.
			return;
		}

		$dh = @opendir( $bundled_root );
		if ( ! $dh ) {
			return;
		}

		while ( false !== ( $entry = readdir( $dh ) ) ) {
			if ( '.' === $entry || '..' === $entry ) {
				continue;
			}
			$src = trailingslashit( $bundled_root ) . $entry;
			$dst = trailingslashit( $dest_root ) . $entry;
			if ( is_dir( $src ) && ! is_dir( $dst ) ) {
				self::xcopy( $src, $dst );
			}
		}
		closedir( $dh );
	}

	/**
	 * Load bootstrap.php for each installed pack and invoke boot().
	 *
	 * Bootstraps are responsible for idempotent CPT/taxonomy registration and
	 * tool row registration. Boot invokes the init action for CPTs and registers
	 * the wpwebmcp_pack_runner_{slug} filter for tool execution routing.
	 */
	public static function load_installed_packs(): void {
		if ( ! class_exists( 'WP_WebMCP_Pack_Registry' ) ) {
			return;
		}
		if ( ! class_exists( 'WP_WebMCP_Pack_Manifest' ) ) {
			return;
		}

		$installed = WP_WebMCP_Pack_Registry::get_installed();
		if ( empty( $installed ) ) {
			return;
		}

		foreach ( $installed as $slug => $meta ) {
			$pack_dir   = WP_WebMCP_Pack_Registry::pack_dir( $slug );
			$entry      = (string) ( $meta['manifest']['entry'] ?? 'bootstrap.php' );
			$entry_file = trailingslashit( $pack_dir ) . $entry;

			if ( '' === $entry_file || ! file_exists( $entry_file ) ) {
				continue;
			}

			// phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.UsingVariable -- pack author owns this file.
			require_once $entry_file;

			// Invoke boot() on the pack class.
			$studly           = WP_WebMCP_Pack_Registry::studly( $slug );
			$class_candidates = array(
				'WP_WebMCP_Pack_' . $studly,
				'WP_WebMCP_Pack_Registry_' . $studly,
			);

			$booted = false;
			foreach ( $class_candidates as $cls ) {
				if ( class_exists( $cls ) && is_callable( array( $cls, 'boot' ) ) ) {
					call_user_func( array( $cls, 'boot' ) );
					$booted = true;
					break;
				}
			}

			if ( ! $booted ) {
				$fallback = 'wpwebmcp_pack_boot_' . $slug;
				if ( function_exists( $fallback ) ) {
					call_user_func( $fallback );
				}
			}
		}
	}

	/**
	 * Recursive copy. Used for seeded bundled packs on first activation.
	 *
	 * @param string $src Source directory.
	 * @param string $dst Destination directory.
	 */
	private static function xcopy( string $src, string $dst ): void {
		if ( ! is_dir( $dst ) ) {
			wp_mkdir_p( $dst );
		}
		$dh = @opendir( $src );
		if ( ! $dh ) {
			return;
		}
		while ( false !== ( $e = readdir( $dh ) ) ) {
			if ( '.' === $e || '..' === $e ) {
				continue;
			}
			$s = trailingslashit( $src ) . $e;
			$d = trailingslashit( $dst ) . $e;
			if ( is_dir( $s ) ) {
				self::xcopy( $s, $d );
			} else {
				// phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.UsingVariable
				copy( $s, $d );
			}
		}
		closedir( $dh );
	}
}
