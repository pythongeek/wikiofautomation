<?php
/**
 * Pack_Manifest — parses a wp-webmcp-pack.json file into a typed array.
 *
 * SDK part of A6 (Vertical Tool Packs Marketplace). Pure data layer: read a
 * pack manifest, validate required fields, return a normalized array.
 *
 * Manifest schema (author-facing, mirrored in docs/pack-schema.md):
 * {
 *   "name":         "Recipes",            // required, human-readable
 *   "slug":         "recipes",            // required, [a-z0-9-]
 *   "version":      "1.0.0",              // required, semver-ish
 *   "author":       "WebWebMCP Nexus",       // required
 *   "license":      "GPL-2.0-or-later",   // required
 *   "description":  "...",                // optional, 1-line
 *   "min_wp_webmcp_version": "1.0.0",     // optional, semver lower-bound
 *   "tools": [                            // required, 1+ items
 *     {
 *       "key":          "search_recipes",  // required, snake_case
 *       "name":         "searchRecipes",   // optional, public tool name (default = key)
 *       "description":  "...",            // required, 1-line for agents
 *       "parameters":   {...}             // optional, JSON Schema object
 *     }
 *   ],
 *   "taxonomies":   ["cuisine", "dietary"],   // optional, list of taxonomy slugs the pack registers
 *   "post_types":   ["recipe"],               // optional, list of CPT slugs the pack registers
 *   "seed_data":    true,                     // optional, hint that bootstrap seeds example posts
 *   "entry":        "bootstrap.php",          // required, PHP file relative to pack root
 *   "free":         true                      // optional, default true (paid gating lands in A6b)
 * }
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Pack_Manifest {

	/**
	 * The schema version this parser understands. Bump when adding/removing required keys.
	 */
	public const SCHEMA_VERSION = 1;

	/**
	 * Parse + validate a manifest JSON string.
	 *
	 * @param string $json Raw JSON contents of wp-webmcp-pack.json.
	 * @return array{
	 *     ok: bool,
	 *     manifest: ?array,
	 *     errors: array<int, string>
	 * }
	 */
	public static function parse( string $json ): array {
		$errors = array();

		if ( '' === trim( $json ) ) {
			return array(
				'ok'       => false,
				'manifest' => null,
				'errors'   => array( 'Manifest is empty.' ),
			);
		}

		$decoded = json_decode( $json, true );
		if ( null === $decoded && JSON_ERROR_NONE !== json_last_error() ) {
			return array(
				'ok'       => false,
				'manifest' => null,
				'errors'   => array( 'Invalid JSON: ' . json_last_error_msg() ),
			);
		}
		if ( ! is_array( $decoded ) ) {
			return array(
				'ok'       => false,
				'manifest' => null,
				'errors'   => array( 'Manifest must be a JSON object.' ),
			);
		}

		// Required scalar fields.
		foreach ( array( 'name', 'slug', 'version', 'author', 'license', 'entry' ) as $key ) {
			if ( empty( $decoded[ $key ] ) || ! is_string( $decoded[ $key ] ) ) {
				$errors[] = sprintf( 'Missing required field "%s".', $key );
			}
		}

		// Slug shape.
		if ( ! empty( $decoded['slug'] ) ) {
			$slug = (string) $decoded['slug'];
			if ( ! preg_match( '/^[a-z0-9][a-z0-9-]{0,62}$/', $slug ) ) {
				$errors[] = sprintf( 'Slug "%s" must be lowercase letters/digits/hyphens, 1-63 chars, starting with alnum.', $slug );
			}
		}

		// Tools array — at least one tool required.
		if ( ! isset( $decoded['tools'] ) || ! is_array( $decoded['tools'] ) || empty( $decoded['tools'] ) ) {
			$errors[] = 'Field "tools" must be a non-empty array.';
		} else {
			$seen_keys = array();
			foreach ( $decoded['tools'] as $i => $tool ) {
				if ( ! is_array( $tool ) ) {
					$errors[] = sprintf( 'tools[%d] must be an object.', $i );
					continue;
				}
				if ( empty( $tool['key'] ) || ! is_string( $tool['key'] ) ) {
					$errors[] = sprintf( 'tools[%d].key is required.', $i );
				} else {
					if ( ! preg_match( '/^[a-z][a-z0-9_]{0,62}$/', $tool['key'] ) ) {
						$errors[] = sprintf( 'tools[%d].key "%s" must be snake_case, starting with a letter.', $i, (string) $tool['key'] );
					}
					if ( isset( $seen_keys[ $tool['key'] ] ) ) {
						$errors[] = sprintf( 'Duplicate tool key "%s".', $tool['key'] );
					}
					$seen_keys[ $tool['key'] ] = true;
				}
				if ( empty( $tool['description'] ) || ! is_string( $tool['description'] ) ) {
					$errors[] = sprintf( 'tools[%d].description is required.', $i );
				}
			}
		}

		// entry file existence is checked by the loader; here we just ensure it's a string.
		if ( ! empty( $decoded['entry'] ) && ! preg_match( '/^[a-z0-9_\-\/\.]+\.php$/', strtolower( (string) $decoded['entry'] ) ) ) {
			$errors[] = sprintf( 'entry "%s" must be a .php file path relative to pack root.', (string) $decoded['entry'] );
		}

		// Default fields.
		$normalized = array(
			'name'                    => isset( $decoded['name'] ) ? (string) $decoded['name'] : '',
			'slug'                    => isset( $decoded['slug'] ) ? (string) $decoded['slug'] : '',
			'version'                 => isset( $decoded['version'] ) ? (string) $decoded['version'] : '0.0.0',
			'author'                  => isset( $decoded['author'] ) ? (string) $decoded['author'] : '',
			'license'                 => isset( $decoded['license'] ) ? (string) $decoded['license'] : '',
			'description'             => isset( $decoded['description'] ) && is_string( $decoded['description'] ) ? (string) $decoded['description'] : '',
			'min_wp_webmcp_version'   => isset( $decoded['min_wp_webmcp_version'] ) ? (string) $decoded['min_wp_webmcp_version'] : '0.0.0',
			'tools'                   => isset( $decoded['tools'] ) && is_array( $decoded['tools'] ) ? array_values( $decoded['tools'] ) : array(),
			'taxonomies'              => isset( $decoded['taxonomies'] ) && is_array( $decoded['taxonomies'] ) ? array_values( array_map( 'strval', $decoded['taxonomies'] ) ) : array(),
			'post_types'              => isset( $decoded['post_types'] ) && is_array( $decoded['post_types'] ) ? array_values( array_map( 'strval', $decoded['post_types'] ) ) : array(),
			'seed_data'               => ! empty( $decoded['seed_data'] ),
			'entry'                   => isset( $decoded['entry'] ) ? (string) $decoded['entry'] : '',
			'free'                    => ! isset( $decoded['free'] ) || true === (bool) $decoded['free'],
			'_schema_version'         => self::SCHEMA_VERSION,
		);

		// Normalize tool fields (default name = key).
		foreach ( $normalized['tools'] as $i => $tool ) {
			$normalized['tools'][ $i ] = array(
				'key'         => isset( $tool['key'] ) ? (string) $tool['key'] : '',
				'name'        => isset( $tool['name'] ) && is_string( $tool['name'] ) ? (string) $tool['name'] : (string) $tool['key'],
				'description' => isset( $tool['description'] ) && is_string( $tool['description'] ) ? (string) $tool['description'] : '',
				'parameters'  => isset( $tool['parameters'] ) && is_array( $tool['parameters'] ) ? $tool['parameters'] : new \stdClass(),
			);
		}

		if ( ! empty( $errors ) ) {
			return array(
				'ok'       => false,
				'manifest' => null,
				'errors'   => $errors,
			);
		}

		return array(
			'ok'       => true,
			'manifest' => $normalized,
			'errors'   => array(),
		);
	}

	/**
	 * Read + parse a manifest from a directory.
	 *
	 * @param string $pack_dir Absolute path to the pack directory.
	 * @return array{ok: bool, manifest: ?array, errors: array<int, string>}
	 */
	public static function parse_dir( string $pack_dir ): array {
		$manifest_path = trailingslashit( $pack_dir ) . 'wp-webmcp-pack.json';
		if ( ! file_exists( $manifest_path ) ) {
			return array(
				'ok'       => false,
				'manifest' => null,
				'errors'   => array( sprintf( 'Manifest not found at %s', $manifest_path ) ),
			);
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- reading a local JSON manifest.
		$json = (string) file_get_contents( $manifest_path );
		return self::parse( $json );
	}
}
