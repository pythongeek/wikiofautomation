<?php
/**
 * Pack_Registry — install/uninstall/list packs; tracks installed packs in an option.
 *
 * SDK part of A6 (Vertical Tool Packs Marketplace). Backed by the `wpwebmcp_installed_packs`
 * option (an array keyed by pack_slug). Each pack's install() routine is responsible for:
 *   1. Creating CPTs + taxonomies (register_taxonomy / register_post_type)
 *   2. Seeding example data (if manifest.seed_data = true)
 *   3. Registering tool rows via WP_WebMCP_Tool_Repository::upsert_by_slug()
 *
 * Pack's uninstall() routine is responsible for the inverse:
 *   1. Removing tool rows (by tool_name)
 *   2. Deleting seeded posts (by slug)
 *   3. Optionally unregistering CPTs/taxonomies (note: WP doesn't actually support
 *      unregister_post_type at runtime — taxonomies can be unregistered)
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Pack_Registry {

	public const OPTION_KEY = 'wpwebmcp_installed_packs';

	/**
	 * Absolute filesystem path to the user's pack directory.
	 *
	 * wp-content/wp-webmcp-packs/<slug>/
	 *
	 * Created on first read if missing (lazy bootstrap).
	 */
	public static function packs_root(): string {
		$wp_content = wp_normalize_path( WP_CONTENT_DIR );
		return trailingslashit( $wp_content ) . 'wp-webmcp-packs';
	}

	/**
	 * Absolute filesystem path to bundled plugin packs.
	 */
	public static function bundled_root(): string {
		return trailingslashit( WEBMCP_NEXUS_PATH ) . 'packs';
	}

	/**
	 * Absolute path to a specific pack directory.
	 * Checks user pack root first; falls back to bundled plugin packs.
	 */
	public static function pack_dir( string $slug ): string {
		$slug        = sanitize_key( $slug );
		$user_dir    = trailingslashit( self::packs_root() ) . $slug;
		if ( is_dir( $user_dir ) ) {
			return $user_dir;
		}
		$bundled_dir = trailingslashit( self::bundled_root() ) . $slug;
		if ( is_dir( $bundled_dir ) ) {
			return $bundled_dir;
		}
		return $user_dir;
	}

	/**
	 * Read the installed-packs option, lazily creating it.
	 *
	 * @return array<string, array{manifest: array, installed_at: int, version: string}>
	 */
	public static function get_installed(): array {
		$installed = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $installed ) ) {
			$installed = array();
		}
		return $installed;
	}

	/**
	 * List installed packs with current manifest metadata.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function list_installed(): array {
		$installed = self::get_installed();
		$out       = array();
		foreach ( $installed as $slug => $meta ) {
			$out[] = array(
				'slug'              => $slug,
				'name'              => isset( $meta['manifest']['name'] ) ? (string) $meta['manifest']['name'] : $slug,
				'version'           => isset( $meta['version'] ) ? (string) $meta['version'] : (string) ( $meta['manifest']['version'] ?? '0.0.0' ),
				'author'            => isset( $meta['manifest']['author'] ) ? (string) $meta['manifest']['author'] : '',
				'description'       => isset( $meta['manifest']['description'] ) ? (string) $meta['manifest']['description'] : '',
				'tools'             => isset( $meta['manifest']['tools'] ) ? (array) $meta['manifest']['tools'] : array(),
				'taxonomies'        => isset( $meta['manifest']['taxonomies'] ) ? (array) $meta['manifest']['taxonomies'] : array(),
				'post_types'        => isset( $meta['manifest']['post_types'] ) ? (array) $meta['manifest']['post_types'] : array(),
				'installed_at'      => isset( $meta['installed_at'] ) ? (int) $meta['installed_at'] : 0,
				'free'              => ! isset( $meta['manifest']['free'] ) || true === (bool) ( $meta['manifest']['free'] ?? true ),
			);
		}
		// Sort by slug for deterministic output.
		usort(
			$out,
			function ( $a, $b ) {
				return strcmp( (string) $a['slug'], (string) $b['slug'] );
			}
		);
		return $out;
	}

	/**
	 * List packs that are discoverable on disk but not yet installed.
	 * Scans both user packs root and plugin bundled packs root.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function list_available(): array {
		$installed = self::get_installed();
		$out       = array();
		$seen      = array();

		$roots = array(
			self::packs_root(),
			self::bundled_root(),
		);

		foreach ( $roots as $root ) {
			if ( ! is_dir( $root ) ) {
				continue;
			}

			$dh = @opendir( $root );
			if ( ! $dh ) {
				continue;
			}

			while ( false !== ( $entry = readdir( $dh ) ) ) {
				if ( '.' === $entry || '..' === $entry ) {
					continue;
				}
				$dir = trailingslashit( $root ) . $entry;
				if ( ! is_dir( $dir ) ) {
					continue;
				}
				if ( isset( $installed[ $entry ] ) || isset( $seen[ $entry ] ) ) {
					continue;
				}
				$parsed = WP_WebMCP_Pack_Manifest::parse_dir( $dir );
				if ( ! $parsed['ok'] ) {
					continue;
				}
				$seen[ $entry ] = true;
				$out[] = array(
					'slug'        => $parsed['manifest']['slug'],
					'name'        => $parsed['manifest']['name'],
					'version'     => $parsed['manifest']['version'],
					'author'      => $parsed['manifest']['author'],
					'description' => $parsed['manifest']['description'],
					'free'        => $parsed['manifest']['free'] ?? true,
					'tools_count' => count( $parsed['manifest']['tools'] ),
					'post_types'  => (array) ( $parsed['manifest']['post_types'] ?? array() ),
					'taxonomies'  => (array) ( $parsed['manifest']['taxonomies'] ?? array() ),
				);
			}
			closedir( $dh );
		}

		usort(
			$out,
			function ( $a, $b ) {
				return strcmp( (string) $a['slug'], (string) $b['slug'] );
			}
		);
		return $out;
	}

	/**
	 * Install a pack by slug.
	 *
	 * @param string $slug Pack slug.
	 * @return array{ok: bool, error: ?string, manifest: ?array}
	 */
	public static function install( string $slug ): array {
		$slug = sanitize_key( $slug );
		if ( '' === $slug ) {
			return array( 'ok' => false, 'error' => 'Empty slug.', 'manifest' => null );
		}

		$installed = self::get_installed();
		if ( isset( $installed[ $slug ] ) ) {
			return array( 'ok' => false, 'error' => sprintf( 'Pack "%s" is already installed.', $slug ), 'manifest' => null );
		}

		$pack_dir = self::pack_dir( $slug );
		if ( ! is_dir( $pack_dir ) ) {
			return array( 'ok' => false, 'error' => sprintf( 'Pack directory not found: %s', $pack_dir ), 'manifest' => null );
		}

		$parsed = WP_WebMCP_Pack_Manifest::parse_dir( $pack_dir );
		if ( ! $parsed['ok'] ) {
			return array( 'ok' => false, 'error' => 'Manifest invalid: ' . implode( '; ', $parsed['errors'] ), 'manifest' => null );
		}
		$manifest = $parsed['manifest'];

		$entry_file = trailingslashit( $pack_dir ) . $manifest['entry'];
		if ( ! file_exists( $entry_file ) ) {
			return array( 'ok' => false, 'error' => sprintf( 'Entry file missing: %s', $manifest['entry'] ), 'manifest' => $manifest );
		}

		// Load bootstrap.
		// phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.UsingVariable -- pack author owns this file.
		require_once $entry_file;

		// Convention: bootstrap exposes WP_WebMCP_Pack_{StudlySlug}::install() + uninstall().
		$studly           = self::studly( $slug );
		$class_candidates = array(
			'WP_WebMCP_Pack_' . $studly,
			self::class . '_' . $studly,
		);

		$pack_class   = null;
		$install_func = null;
		foreach ( $class_candidates as $cls ) {
			if ( class_exists( $cls ) && is_callable( array( $cls, 'install' ) ) ) {
				$install_func = array( $cls, 'install' );
				$pack_class   = $cls;
				break;
			}
		}

		if ( null === $install_func ) {
			// Fallback: look for a globally-named function wpwebmcp_pack_install_{slug}.
			$fallback = 'wpwebmcp_pack_install_' . $slug;
			if ( function_exists( $fallback ) ) {
				$install_func = $fallback;
			} else {
				return array( 'ok' => false, 'error' => sprintf( 'Pack bootstrap does not expose an install() callable for "%s".', $slug ), 'manifest' => $manifest );
			}
		}

		$result = call_user_func( $install_func, $manifest );
		if ( is_wp_error( $result ) ) {
			return array( 'ok' => false, 'error' => $result->get_error_message(), 'manifest' => $manifest );
		}
		if ( false === $result ) {
			return array( 'ok' => false, 'error' => 'Pack install routine returned false.', 'manifest' => $manifest );
		}

		// Immediately boot the pack in the current request so CPTs and runner filters are active.
		if ( $pack_class && is_callable( array( $pack_class, 'boot' ) ) ) {
			call_user_func( array( $pack_class, 'boot' ) );
		} elseif ( function_exists( 'wpwebmcp_pack_boot_' . $slug ) ) {
			call_user_func( 'wpwebmcp_pack_boot_' . $slug );
		}

		$installed[ $slug ] = array(
			'manifest'    => $manifest,
			'installed_at' => time(),
			'version'     => $manifest['version'],
		);
		update_option( self::OPTION_KEY, $installed, false );

		return array( 'ok' => true, 'error' => null, 'manifest' => $manifest );
	}

	/**
	 * Uninstall a pack by slug.
	 *
	 * @param string $slug Pack slug.
	 * @return array{ok: bool, error: ?string}
	 */
	public static function uninstall( string $slug ): array {
		$slug      = sanitize_key( $slug );
		$installed = self::get_installed();
		if ( ! isset( $installed[ $slug ] ) ) {
			return array( 'ok' => false, 'error' => sprintf( 'Pack "%s" is not installed.', $slug ) );
		}

		$manifest   = $installed[ $slug ]['manifest'];
		$pack_dir   = self::pack_dir( $slug );
		$entry_file = trailingslashit( $pack_dir ) . $manifest['entry'];

		if ( file_exists( $entry_file ) ) {
			// phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.UsingVariable -- pack author owns this file.
			require_once $entry_file;
		}

		$studly           = self::studly( $slug );
		$class_candidates = array(
			'WP_WebMCP_Pack_' . $studly,
			self::class . '_' . $studly,
		);

		$uninstall_func = null;
		foreach ( $class_candidates as $cls ) {
			if ( class_exists( $cls ) && is_callable( array( $cls, 'uninstall' ) ) ) {
				$uninstall_func = array( $cls, 'uninstall' );
				break;
			}
		}

		if ( null === $uninstall_func ) {
			$fallback = 'wpwebmcp_pack_uninstall_' . $slug;
			if ( function_exists( $fallback ) ) {
				$uninstall_func = $fallback;
			} else {
				// Fall through: remove from registry.
				unset( $installed[ $slug ] );
				update_option( self::OPTION_KEY, $installed, false );
				return array( 'ok' => true, 'error' => null );
			}
		}

		$result = call_user_func( $uninstall_func, $manifest );
		if ( is_wp_error( $result ) ) {
			return array( 'ok' => false, 'error' => $result->get_error_message() );
		}

		unset( $installed[ $slug ] );
		update_option( self::OPTION_KEY, $installed, false );

		return array( 'ok' => true, 'error' => null );
	}

	/**
	 * Convert a slug to StudlyCase for class/function names.
	 *
	 * @param string $slug Pack slug.
	 * @return string
	 */
	public static function studly( string $slug ): string {
		$parts = explode( '-', $slug );
		$parts = array_map(
			function ( $p ) {
				return ucfirst( trim( $p ) );
			},
			$parts
		);
		return implode( '', $parts );
	}

	/**
	 * ============================================================
	 * F3 niche pack generator (v1.1.1). Adds industry/niche vertical packs
	 * as real directory packs (wp-webmcp-pack.json + data-driven
	 * bootstrap.php written into wp-content/wp-webmcp-packs/<slug>/).
	 * Trigger: admin-post.php?action=wpwebmcp_generate_pack&pack=<slug>
	 * (manage_options + nonce wpwebmcp_generate_pack).
	 */
	public static function niche_pack_catalogue(): array {
		return array(
			'restaurants' => array(
				'name' => 'Restaurants & Menus',
				'description' => 'Menu items, courses, and dietary tags for restaurants, cafes, and cloud kitchens. AI agents can search dishes, fetch details, and browse the menu structure.',
				'icon' => 'dashicons-food',
				'cpt' => array( 'post_type' => 'menu_item', 'singular' => 'Menu Item', 'plural' => 'Menu Items', 'rewrite' => 'menu' ),
				'taxonomies' => array(
					array( 'taxonomy' => 'menu_course', 'singular' => 'Menu Course', 'plural' => 'Menu Courses', 'hierarchical' => true ),
					array( 'taxonomy' => 'dietary_tag', 'singular' => 'Dietary Tag', 'plural' => 'Dietary Tags', 'hierarchical' => false ),
				),
				'tools' => array(
					array( 'key' => 'search_menu_items', 'name' => 'searchMenuItems', 'description' => 'Search restaurant menu items by keyword.', 'params' => array( array( 'name' => 'query', 'type' => 'string', 'required' => true, 'description' => 'Keyword to search dishes for.' ) ) ),
					array( 'key' => 'get_menu_item', 'name' => 'getMenuItem', 'description' => 'Get a single menu item by slug with course and dietary tags.', 'params' => array( array( 'name' => 'slug', 'type' => 'string', 'required' => false, 'description' => 'Menu item slug.' ) ) ),
					array( 'key' => 'list_menu_courses', 'name' => 'listMenuCourses', 'description' => 'List menu course categories with item counts.', 'params' => array() ),
					array( 'key' => 'get_latest_menu_items', 'name' => 'getLatestMenuItems', 'description' => 'Get the latest menu items.', 'params' => array( array( 'name' => 'limit', 'type' => 'integer', 'required' => false, 'description' => 'Max items (default 10).' ) ) ),
				),
				'seeds' => array(
					array( 'title' => 'Truffle Mushroom Risotto', 'excerpt' => 'Carnaroli rice, wild mushrooms, black truffle shave.', 'content' => 'A signature main: slow-stirred Carnaroli risotto finished with wild mushrooms, parmesan, and shaved black truffle.', 'terms' => array( 'menu_course' => array( 'Mains' ), 'dietary_tag' => array( 'Vegetarian' ) ) ),
					array( 'title' => 'Charred Octopus Salad', 'excerpt' => 'Grilled octopus, fingerlings, smoked paprika.', 'content' => 'Charcoal-grilled octopus over fingerling potatoes with smoked paprika aioli and parsley.', 'terms' => array( 'menu_course' => array( 'Starters' ), 'dietary_tag' => array( 'Gluten Free' ) ) ),
					array( 'title' => 'Margherita Flatbread', 'excerpt' => 'San Marzano, fior di latte, basil.', 'content' => 'Wood-fired flatbread with San Marzano tomato, fior di latte mozzarella, and fresh basil.', 'terms' => array( 'menu_course' => array( 'Starters' ), 'dietary_tag' => array( 'Vegetarian' ) ) ),
					array( 'title' => 'Dry-Aged Ribeye', 'excerpt' => '45-day dry-aged, bone marrow butter.', 'content' => '45-day dry-aged ribeye grilled over binchotan, finished with bone marrow butter and sea salt.', 'terms' => array( 'menu_course' => array( 'Mains' ), 'dietary_tag' => array( 'High Protein' ) ) ),
					array( 'title' => 'Dark Chocolate Fondant', 'excerpt' => '70% Valrhona center, olive oil crumb.', 'content' => 'Warm 70% dark chocolate fondant with a molten center, olive oil cake crumb, and creme fraiche.', 'terms' => array( 'menu_course' => array( 'Desserts' ), 'dietary_tag' => array( 'Vegetarian' ) ) ),
				),
			),
			'fitness-classes' => array(
				'name' => 'Fitness & Gym Classes',
				'description' => 'Class schedules for gyms, studios, and coaches. AI agents can search classes, get details, and browse class types and intensity levels.',
				'icon' => 'dashicons-universal-access',
				'cpt' => array( 'post_type' => 'fitness_class', 'singular' => 'Fitness Class', 'plural' => 'Fitness Classes', 'rewrite' => 'classes' ),
				'taxonomies' => array(
					array( 'taxonomy' => 'class_type', 'singular' => 'Class Type', 'plural' => 'Class Types', 'hierarchical' => true ),
					array( 'taxonomy' => 'intensity_level', 'singular' => 'Intensity Level', 'plural' => 'Intensity Levels', 'hierarchical' => false ),
				),
				'tools' => array(
					array( 'key' => 'search_fitness_classes', 'name' => 'searchFitnessClasses', 'description' => 'Search fitness classes by keyword.', 'params' => array( array( 'name' => 'query', 'type' => 'string', 'required' => true, 'description' => 'Keyword to search classes for.' ) ) ),
					array( 'key' => 'get_fitness_class', 'name' => 'getFitnessClass', 'description' => 'Get a single fitness class by slug.', 'params' => array( array( 'name' => 'slug', 'type' => 'string', 'required' => false, 'description' => 'Class slug.' ) ) ),
					array( 'key' => 'list_class_types', 'name' => 'listClassTypes', 'description' => 'List class type categories.', 'params' => array() ),
					array( 'key' => 'get_latest_fitness_classes', 'name' => 'getLatestFitnessClasses', 'description' => 'Get the latest fitness classes.', 'params' => array( array( 'name' => 'limit', 'type' => 'integer', 'required' => false, 'description' => 'Max items (default 10).' ) ) ),
				),
				'seeds' => array(
					array( 'title' => 'Sunrise Vinyasa Flow', 'excerpt' => '60 min breath-led flow, all levels.', 'content' => 'A breath-led vinyasa sequence building from gentle warm-ups to standing balances. Mats provided.', 'terms' => array( 'class_type' => array( 'Yoga' ), 'intensity_level' => array( 'Moderate' ) ) ),
					array( 'title' => 'HIIT45 Express', 'excerpt' => '45 min intervals, strength + cardio.', 'content' => 'High-intensity intervals alternating kettlebell strength blocks and rower sprints. Towel required.', 'terms' => array( 'class_type' => array( 'Conditioning' ), 'intensity_level' => array( 'High' ) ) ),
					array( 'title' => 'Barre Fundamentals', 'excerpt' => '50 min low-impact sculpt.', 'content' => 'Small isometric movements at the barre targeting core, glutes, and posture. Socks with grips recommended.', 'terms' => array( 'class_type' => array( 'Barre' ), 'intensity_level' => array( 'Low' ) ) ),
					array( 'title' => 'Olympic Lifting Lab', 'excerpt' => '75 min snatch + clean technique.', 'content' => 'Coach-led technique work on snatch and clean and jerk with video feedback. Limited to 8 lifters.', 'terms' => array( 'class_type' => array( 'Strength' ), 'intensity_level' => array( 'High' ) ) ),
					array( 'title' => 'Mobility & Recovery', 'excerpt' => '40 min stretch + foam rolling.', 'content' => 'Guided mobility, foam rolling, and breathwork to accelerate recovery between hard sessions.', 'terms' => array( 'class_type' => array( 'Recovery' ), 'intensity_level' => array( 'Low' ) ) ),
				),
			),
			'travel-tours' => array(
				'name' => 'Travel & Tour Operators',
				'description' => 'Tour listings for travel agencies and operators. AI agents can search tours, get itineraries, and browse destinations and tour styles.',
				'icon' => 'dashicons-palmtree',
				'cpt' => array( 'post_type' => 'tour', 'singular' => 'Tour', 'plural' => 'Tours', 'rewrite' => 'tours' ),
				'taxonomies' => array(
					array( 'taxonomy' => 'destination', 'singular' => 'Destination', 'plural' => 'Destinations', 'hierarchical' => true ),
					array( 'taxonomy' => 'tour_style', 'singular' => 'Tour Style', 'plural' => 'Tour Styles', 'hierarchical' => false ),
				),
				'tools' => array(
					array( 'key' => 'search_tours', 'name' => 'searchTours', 'description' => 'Search tours by keyword.', 'params' => array( array( 'name' => 'query', 'type' => 'string', 'required' => true, 'description' => 'Keyword to search tours for.' ) ) ),
					array( 'key' => 'get_tour', 'name' => 'getTour', 'description' => 'Get a single tour itinerary by slug.', 'params' => array( array( 'name' => 'slug', 'type' => 'string', 'required' => false, 'description' => 'Tour slug.' ) ) ),
					array( 'key' => 'list_destinations', 'name' => 'listDestinations', 'description' => 'List destination categories with tour counts.', 'params' => array() ),
					array( 'key' => 'get_latest_tours', 'name' => 'getLatestTours', 'description' => 'Get the latest published tours.', 'params' => array( array( 'name' => 'limit', 'type' => 'integer', 'required' => false, 'description' => 'Max items (default 10).' ) ) ),
				),
				'seeds' => array(
					array( 'title' => 'Kyoto Temple Cycle', 'excerpt' => '3 days, guided, e-bikes.', 'content' => 'Three-day guided e-bike tour through Kyoto temple districts with a tea ceremony and kaiseki dinner.', 'terms' => array( 'destination' => array( 'Japan' ), 'tour_style' => array( 'Guided' ) ) ),
					array( 'title' => 'Patagonia W Trek', 'excerpt' => '5 days, small group, refugios.', 'content' => 'Five-day small-group trek of the Torres del Paine W circuit with mountain refugio stays.', 'terms' => array( 'destination' => array( 'Chile' ), 'tour_style' => array( 'Adventure' ) ) ),
					array( 'title' => 'Tuscany Slow Food Week', 'excerpt' => '7 days, culinary, agriturismo.', 'content' => 'A week of Slow Food tastings, truffle hunting, and cooking classes from a family agriturismo.', 'terms' => array( 'destination' => array( 'Italy' ), 'tour_style' => array( 'Culinary' ) ) ),
					array( 'title' => 'Iceland Aurora Chase', 'excerpt' => '4 days, photography-led.', 'content' => 'Four-night northern lights expedition with an astrophotographer guide and glacier lagoon cruise.', 'terms' => array( 'destination' => array( 'Iceland' ), 'tour_style' => array( 'Photography' ) ) ),
					array( 'title' => 'Mekong Delta Homestay', 'excerpt' => '2 days, community-based.', 'content' => 'Two-day community-based homestay with floating market visits and cycling through rice paddies.', 'terms' => array( 'destination' => array( 'Vietnam' ), 'tour_style' => array( 'Culture' ) ) ),
				),
			),
		);
	}

	/**
	 * F3 Phase 4: generate a niche pack folder from the catalogue. Shared by the
	 * admin-post handler and the WP-CLI 'webmcp pack generate' command.
	 *
	 * @param string $slug Catalogue slug.
	 * @return array{ok:bool,error?:string}
	 */
	public static function write_pack_files( string $slug ): array {
		$slug = sanitize_key( $slug );
		$cat = self::niche_pack_catalogue();
		if ( '' === $slug || ! isset( $cat[ $slug ] ) ) { return array( 'ok' => false, 'error' => 'Unknown pack slug.' ); }
		$def = $cat[ $slug ];
		$dir = trailingslashit( self::packs_root() ) . $slug;
		if ( ! is_dir( $dir ) ) { wp_mkdir_p( $dir ); }
		if ( ! is_dir( $dir ) || ! wp_is_writable( $dir ) ) { return array( 'ok' => false, 'error' => 'Cannot write pack directory.' ); }
		$taxonomies = array();
		$tax_slugs = array();
		$tools = array();
		$seeds = array();
		foreach ( $def['taxonomies'] as $tx ) {
			$taxonomies[] = array( 'taxonomy' => $tx['taxonomy'], 'label_singular' => $tx['singular'], 'label_plural' => $tx['plural'], 'hierarchical' => ! empty( $tx['hierarchical'] ), 'post_type' => $def['cpt']['post_type'] );
			$tax_slugs[] = $tx['taxonomy'];
		}
		$tools = array();
		foreach ( $def['tools'] as $tl ) {
			$tools[] = array( 'key' => $tl['key'], 'name' => $tl['name'], 'description' => $tl['description'], 'parameters' => $tl['params'] );
		}
		$seeds = array();
		foreach ( $def['seeds'] as $sd ) {
			$seeds[] = array( 'post_type' => $def['cpt']['post_type'], 'title' => $sd['title'], 'excerpt' => $sd['excerpt'], 'content' => $sd['content'], 'terms' => $sd['terms'] );
		}
		$manifest = array(
			'name' => $def['name'], 'slug' => $slug, 'version' => '1.0.0',
			'author' => 'WebMCP Nexus', 'license' => 'GPL-2.0-or-later', 'entry' => 'bootstrap.php',
			'description' => $def['description'], 'icon' => $def['icon'],
			'cpts' => array( array( 'post_type' => $def['cpt']['post_type'], 'label_singular' => $def['cpt']['singular'], 'label_plural' => $def['cpt']['plural'], 'menu_icon' => $def['icon'], 'rewrite_slug' => $def['cpt']['rewrite'] ) ),
			'post_types' => array( $def['cpt']['post_type'] ), 'taxonomies' => $tax_slugs, 'taxonomy_defs' => $taxonomies, 'seed_data' => true,
			'tools' => $tools, 'seed_posts' => $seeds,
		);
		$json = wp_json_encode( $manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		file_put_contents( trailingslashit( $dir ) . 'wp-webmcp-pack.json', $json );
		file_put_contents( trailingslashit( $dir ) . 'bootstrap.php', self::generic_bootstrap_php( $slug ) );
		return array( 'ok' => true );
	}
	public static function handle_generate_pack(): void {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not allowed.' ); }
		$nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['_wpnonce'] ) ) : '';
		if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'wp_rest' ) ) { wp_die( 'Security check failed.' ); } // wp_rest nonce: mintable by authenticated admin clients
		$slug = isset( $_GET['pack'] ) ? sanitize_key( (string) wp_unslash( $_GET['pack'] ) ) : '';
		$result = self::write_pack_files( $slug );
		if ( empty( $result['ok'] ) ) { wp_die( esc_html( (string) ( $result['error'] ?? 'Pack generation failed.' ) ) ); }
		wp_safe_redirect( add_query_arg( array( 'page' => 'wp-webmcp-packs', 'notice' => 'generated_' . $slug ), admin_url( 'admin.php' ) ) );
		exit;
	}

	private static function generic_bootstrap_php( string $slug ): string {
		$studly = self::studly( $slug );
		$php = <<<'PACKPHP'
<?php
/**
 * Generated niche pack bootstrap (__SLUG__). Data-driven: CPTs,
 * taxonomies, tools, and seed posts are read from wp-webmcp-pack.json.
 *
 * @package WP_WebMCP_Pack___STUDLY__
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Pack___STUDLY__ {

	private static function manifest(): array {
		static $m = null;
		if ( null === $m ) {
			$dir = trailingslashit( WP_WebMCP_Pack_Registry::pack_dir( '__SLUG__' ) );
			$json = (string) file_get_contents( $dir . 'wp-webmcp-pack.json' );
			$raw = json_decode( $json, true ); // raw JSON: parse() flattens cpts/taxonomies to strings
			$m = is_array( $raw ) ? $raw : array();
		}
		return $m;
	}

	public static function boot(): void {
		add_action( 'init', array( self::class, 'register_types' ), 9 );
		add_filter( 'wpwebmcp_pack_runner___SLUG__', array( self::class, 'run_tool' ), 10, 3 );
	}

	public static function register_types(): void {
		$m = self::manifest();
		foreach ( (array) ( $m['taxonomy_defs'] ?? array() ) as $tax ) {
			register_taxonomy( $tax['taxonomy'], array( $tax['post_type'] ), array(
				'labels' => array( 'name' => $tax['label_plural'], 'singular_name' => $tax['label_singular'] ),
				'public' => true, 'hierarchical' => ! empty( $tax['hierarchical'] ), 'show_in_rest' => true,
			) );
		}
		foreach ( (array) ( $m['cpts'] ?? array() ) as $cpt ) {
			register_post_type( $cpt['post_type'], array(
				'labels' => array( 'name' => $cpt['label_plural'], 'singular_name' => $cpt['label_singular'] ),
				'public' => true, 'show_in_rest' => true, 'has_archive' => true,
				'menu_icon' => isset( $cpt['menu_icon'] ) ? $cpt['menu_icon'] : 'dashicons-admin-post', 'menu_position' => 7,
				'supports' => array( 'title', 'editor', 'excerpt', 'custom-fields' ),
				'rewrite' => array( 'slug' => isset( $cpt['rewrite_slug'] ) ? $cpt['rewrite_slug'] : $cpt['post_type'] ),
			) );
		}
	}

	public static function install( array $manifest ) {
		try {
		self::register_types();
		$post_type = self::manifest()['cpts'][0]['post_type'] ?? 'post';
		$existing = get_posts( array( 'post_type' => $post_type, 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids' ) );
		if ( empty( $existing ) ) { self::seed_posts(); }
		foreach ( (array) ( $manifest['tools'] ?? array() ) as $tool ) {
			$name = (string) ( $tool['name'] ?? $tool['key'] ?? '' );
			if ( '' === $name || ! class_exists( 'WP_WebMCP_Tool_Repository' ) ) { continue; }
			WP_WebMCP_Tool_Repository::upsert_by_slug( array(
				'tool_name' => $name,
				'tool_description' => (string) ( $tool['description'] ?? '' ),
				'tool_type' => 'read',
				'tool_scope' => '__SLUG__',
				'action_type' => 'hook',
				'action_value' => '__SLUG__::' . (string) ( $tool['key'] ?? '' ),
				'parameters' => isset( $tool['parameters'] ) ? (array) $tool['parameters'] : array(),
				'status' => 'active',
			) );
		}
		return true;
		} catch ( Throwable $e ) {
			return new WP_Error( 'niche_pack_install_failed', get_class( $e ) . ': ' . $e->getMessage() . ' @ ' . basename( $e->getFile() ) . ':' . $e->getLine() );
		}
	}

	public static function uninstall( array $manifest ) {
		foreach ( (array) ( $manifest['tools'] ?? array() ) as $tool ) {
			$name = (string) ( $tool['name'] ?? $tool['key'] ?? '' );
			if ( '' !== $name && class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
				$row = WP_WebMCP_Tool_Repository::find_by_slug( $name );
				if ( $row ) { WP_WebMCP_Tool_Repository::delete( (int) $row['id'] ); }
			}
		}
		$post_types = array();
		foreach ( (array) ( self::manifest()['cpts'] ?? array() ) as $cpt ) { $post_types[] = $cpt['post_type']; }
		if ( ! empty( $post_types ) ) {
			$seeded = get_posts( array( 'post_type' => $post_types, 'post_status' => 'any', 'posts_per_page' => -1, 'fields' => 'ids', 'meta_key' => '_wpwebmcp___SLUG___seed' ) );
			foreach ( (array) $seeded as $pid ) { wp_delete_post( (int) $pid, true ); }
		}
		return true;
	}

	private static function seed_posts(): void {
		$m = self::manifest();
		foreach ( (array) ( $m['seed_posts'] ?? array() ) as $seed ) {
			$pid = wp_insert_post( array(
				'post_type' => $seed['post_type'], 'post_status' => 'publish',
				'post_title' => $seed['title'], 'post_excerpt' => $seed['excerpt'], 'post_content' => $seed['content'],
			) );
			if ( $pid && ! is_wp_error( $pid ) ) {
				update_post_meta( $pid, '_wpwebmcp___SLUG___seed', 1 );
				foreach ( (array) ( $seed['terms'] ?? array() ) as $tax => $terms ) {
					wp_set_object_terms( $pid, array_map( 'sanitize_text_field', (array) $terms ), $tax, false );
				}
			}
		}
	}

	public static function run_tool( $default, $tool, $params ) {
		$m = self::manifest();
		$needle = strtolower( (string) $tool );
		$key = '';
		foreach ( (array) ( $m['tools'] ?? array() ) as $t ) {
			if ( strtolower( (string) ( $t['key'] ?? '' ) ) === $needle || strtolower( (string) ( $t['name'] ?? '' ) ) === $needle ) { $key = (string) $t['key']; break; }
		}
		if ( '' === $key ) { return $default; }
		$params = is_array( $params ) ? $params : array();
		$post_type = $m['cpts'][0]['post_type'] ?? 'post';
		if ( 0 === strpos( $key, 'search_' ) ) {
			$q = sanitize_text_field( (string) ( $params['query'] ?? $params['q'] ?? '' ) );
			$posts = get_posts( array( 'post_type' => $post_type, 's' => $q, 'posts_per_page' => 10, 'post_status' => 'publish' ) );
			// Keywords often live in taxonomy terms (like class_type Yoga) which core search ignores.
			$pack_taxes = array();
			foreach ( (array) ( $m['taxonomy_defs'] ?? array() ) as $tx ) { $pack_taxes[] = $tx['taxonomy']; }
			if ( '' !== $q && ! empty( $pack_taxes ) ) {
				$terms = get_terms( array( 'taxonomy' => $pack_taxes, 'search' => $q, 'hide_empty' => false, 'number' => 20 ) );
				if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
					$term_ids = array();
					foreach ( (array) $terms as $t ) { $term_ids[] = (int) $t->term_id; }
					$tax_clauses = array();
				foreach ( (array) $pack_taxes as $pt ) { $tax_clauses[] = array( 'taxonomy' => $pt, 'field' => 'term_id', 'terms' => $term_ids ); }
				$tagged = get_posts( array( 'post_type' => $post_type, 'posts_per_page' => 10, 'post_status' => 'publish', 'tax_query' => array_merge( array( 'relation' => 'OR' ), $tax_clauses ) ) );
					$have = array();
					foreach ( (array) $posts as $p ) { $have[] = (int) $p->ID; }
					foreach ( (array) $tagged as $p ) { if ( ! in_array( (int) $p->ID, $have, true ) ) { $posts[] = $p; } }
				}
			}
			return array( 'ok' => true, 'query' => $q, 'results' => self::shape( $posts ) );
		}
		if ( 0 === strpos( $key, 'get_latest_' ) ) {
			$n = max( 1, min( 20, (int) ( $params['limit'] ?? 10 ) ) );
			$posts = get_posts( array( 'post_type' => $post_type, 'posts_per_page' => $n, 'post_status' => 'publish' ) );
			return array( 'ok' => true, 'items' => self::shape( $posts ) );
		}
		if ( 0 === strpos( $key, 'list_' ) ) {
			foreach ( (array) ( $m['taxonomy_defs'] ?? array() ) as $tax ) {
				if ( false !== strpos( $key, str_replace( '-', '_', $tax['taxonomy'] ) ) ) {
					$terms = get_terms( array( 'taxonomy' => $tax['taxonomy'], 'hide_empty' => false ) );
					$out = array();
					if ( ! is_wp_error( $terms ) ) {
						foreach ( (array) $terms as $t2 ) { $out[] = array( 'term' => $t2->name, 'slug' => $t2->slug, 'count' => (int) $t2->count ); }
					}
					return array( 'ok' => true, 'taxonomy' => $tax['taxonomy'], 'terms' => $out );
				}
			}
		}
		if ( 0 === strpos( $key, 'get_' ) ) {
			$slug2 = sanitize_title( (string) ( $params['slug'] ?? '' ) );
			$posts = array();
			if ( '' !== $slug2 ) {
				$posts = get_posts( array( 'post_type' => $post_type, 'name' => $slug2, 'posts_per_page' => 1, 'post_status' => 'publish' ) );
			}
			if ( empty( $posts ) ) {
				$posts = get_posts( array( 'post_type' => $post_type, 'posts_per_page' => 1, 'post_status' => 'publish' ) );
			}
			$items = self::shape( $posts );
			return array( 'ok' => ! empty( $items ), 'item' => empty( $items ) ? null : $items[0] );
		}
		return $default;
	}

	private static function shape( array $posts ): array {
		$out = array();
		foreach ( $posts as $p ) {
			$out[] = array( 'title' => get_the_title( $p ), 'url' => get_permalink( $p ), 'excerpt' => wp_strip_all_tags( (string) get_the_excerpt( $p ) ), 'date' => get_the_date( 'c', $p ) );
		}
		return $out;
	}
}
PACKPHP;
		return str_replace( array( '__STUDLY__', '__SLUG__' ), array( $studly, $slug ), $php );
	}
}

add_action( 'admin_post_wpwebmcp_generate_pack', array( 'WP_WebMCP_Pack_Registry', 'handle_generate_pack' ) );
