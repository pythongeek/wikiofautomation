<?php
/**
 * Access_Control — Doc §3 + §5.8⑦ + §7.1 + §7.3.
 *
 * Manages role-based access control for WebMCP read and write tools.
 * Registers REST route `PUT /wpwebmcp/v1/access`.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Access_Control {

	/** Capability required to manage tool access. */
	private const CAPABILITY = 'manage_options';

	/**
	 * Default role × tool-type matrix (mirrors Part 16 #3 default).
	 *
	 * @var array<string, array<int,string>>
	 */
	public const DEFAULT_MATRIX = array(
		'administrator' => array( 'read', 'write' ),
		'editor'        => array( 'read' ),
		'author'        => array( 'read' ),
		'contributor'   => array( 'read' ),
		'subscriber'    => array( 'read' ),
		'anonymous'     => array( 'read' ),
	);

	/**
	 * Singleton hook entry (called from WP_WebMCP::define_api_hooks()).
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'rest_api_init',             array( __CLASS__, 'register_routes' ) );
		WP_WebMCP_Loader::register_filter( 'wpwebmcp_schema_role', array( __CLASS__, 'filter_role' ), 10, 1 );
		WP_WebMCP_Loader::register_filter( 'default_option_wpwebmcp_role_access', array( __CLASS__, 'filter_role_access' ), 10, 1 );
	}

	/**
	 * Register REST route PUT /wpwebmcp/v1/access.
	 */
	public static function register_routes(): void {
		register_rest_route(
			'wpwebmcp/v1',
			'/access',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_access' ),
					'permission_callback' => array( __CLASS__, 'check_admin' ),
				),
				array(
					'methods'             => array( 'POST', 'PUT', 'PATCH' ),
					'callback'            => array( __CLASS__, 'save' ),
					'permission_callback' => array( __CLASS__, 'check_admin' ),
				),
			)
		);
	}

	/**
	 * GET /access — return the current role access matrix.
	 */
	public static function get_access( WP_REST_Request $request ) {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return new WP_Error( 'wpwebmcp_forbidden', __( 'Forbidden.', 'webmcp-nexus' ), array( 'status' => 403 ) );
		}
		$matrix = get_option( 'wpwebmcp_role_access', self::DEFAULT_MATRIX );
		if ( is_string( $matrix ) ) {
			$matrix = json_decode( $matrix, true ) ?: self::DEFAULT_MATRIX;
		}
		return rest_ensure_response( array( 'ok' => true, 'access' => $matrix ) );
	}

	/**
	 * Permission check.
	 */
	public static function check_admin(): bool {
		return current_user_can( self::CAPABILITY );
	}

	/**
	 * Save the role access matrix via PUT /wpwebmcp/v1/access.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */
	public static function save( WP_REST_Request $request ) {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return new WP_Error( 'wpwebmcp_forbidden', __( 'Forbidden.', 'webmcp-nexus' ), array( 'status' => 403 ) );
		}

		$matrix = $request->get_json_params();
		if ( ! is_array( $matrix ) ) {
			return new WP_Error( 'wpwebmcp_bad_params', __( 'Matrix must be an object/array.', 'webmcp-nexus' ), array( 'status' => 400 ) );
		}

		$clean = array();
		$allowed_roles = array( 'administrator', 'editor', 'author', 'contributor', 'subscriber', 'anonymous' );
		foreach ( $allowed_roles as $role ) {
			$types = isset( $matrix[ $role ] ) && is_array( $matrix[ $role ] ) ? $matrix[ $role ] : array();
			$clean_types = array();
			if ( in_array( 'read', $types, true ) || 'anonymous' === $role ) {
				$clean_types[] = 'read';
			}
			// Anonymous can never have write access.
			if ( in_array( 'write', $types, true ) && 'anonymous' !== $role ) {
				$clean_types[] = 'write';
			}
			$clean[ $role ] = $clean_types;
		}

		update_option( 'wpwebmcp_role_access', $clean, false );
		wp_cache_flush();
		do_action( 'wpwebmcp_config_changed', array( 'wpwebmcp_role_access' => $clean ) );

		return rest_ensure_response(
			array(
				'ok'     => true,
				'matrix' => $clean,
				'detail' => __( 'Tool access saved.', 'webmcp-nexus' ),
			)
		);
	}

	/**
	 * Pass-through role filter (so callers can override `current_role`
	 * via `wpwebmcp_schema_role` in tests / future auth plugins).
	 */
	public static function filter_role( $role ) {
		if ( is_string( $role ) && '' !== $role ) {
			return $role;
		}
		return self::get_current_role();
	}

	/**
	 * Ensure `wpwebmcp_role_access` always returns a matrix even when the
	 * option is missing (fresh installs).
	 */
	public static function filter_role_access( $value ) {
		if ( is_array( $value ) && ! empty( $value ) ) {
			return $value;
		}
		return self::DEFAULT_MATRIX;
	}

	/**
	 * Get the current resolved role-access matrix.
	 *
	 * @return array<string, array<int, string>>
	 */
	public static function get_matrix(): array {
		$saved = get_option( 'wpwebmcp_role_access', array() );
		return ( is_array( $saved ) && ! empty( $saved ) ) ? $saved : self::DEFAULT_MATRIX;
	}

	/**
	 * Resolve the current caller's role key.
	 *
	 * @return string One of: administrator, editor, author, contributor, subscriber, anonymous.
	 */
	public static function get_current_role(): string {
		if ( ! is_user_logged_in() ) {
			return 'anonymous';
		}
		$user = wp_get_current_user();
		if ( empty( $user->roles ) || ! is_array( $user->roles ) ) {
			return 'anonymous';
		}
		return (string) $user->roles[0];
	}

	/**
	 * Whether the given role is allowed to invoke tools of the given type.
	 *
	 * @param string      $type  'read' | 'write'.
	 * @param string|null $role  Role key (default: current user).
	 */
	public static function current_role_can( string $type, ?string $role = null ): bool {
		if ( null === $role ) {
			$role = self::get_current_role();
		}
		$matrix  = self::get_matrix();
		$allowed = isset( $matrix[ $role ] ) && is_array( $matrix[ $role ] )
			? $matrix[ $role ]
			: $matrix['anonymous'];
		return in_array( $type, $allowed, true );
	}
}