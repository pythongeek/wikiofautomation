<?php
/**
 * Audit Meta Box — Module A A4 (AI-Readiness Audit — content-shape sidebar).
 *
 * Sidebar meta box shown on the post / page edit screen. Composes the
 * per-post audit score with content-shape guidance (TL;DR / FAQ / Takeaways /
 * Author bio / Last-updated date) so editors see exactly which structural
 * shapes the AI agents expect, side-by-side with the numeric score.
 *
 * Read-only — does not write to the post. Auto-creates the audit on render
 * via WP_WebMCP_Post_Audit.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Audit_Meta_Box {

	public static function init(): void {
		// Register a separate, dedicated meta box — keeps the existing
		// WebMCP Nexus exposure-tier box unchanged.
		add_action( 'add_meta_boxes', array( __CLASS__, 'register' ), 11 );
	}

	public static function register(): void {
		$post_types = (array) get_option( 'wpwebmcp_custom_post_types', array( 'post', 'page' ) );
		$post_types = apply_filters( 'wpwebmcp_post_type_tools', $post_types );
		$post_types = array_values( array_unique( array_filter( $post_types ) ) );
		if ( empty( $post_types ) ) {
			return;
		}
		add_meta_box(
			'wpwebmcp_audit_meta_box',
			__( 'AI-Readiness Audit (A4)', 'webmcp-nexus' ),
			array( __CLASS__, 'render' ),
			$post_types,
			'side',
			'high'
		);
	}

	public static function render( \WP_Post $post ): void {
		$audit = class_exists( 'WP_WebMCP_Post_Audit' )
			? WP_WebMCP_Post_Audit::audit_post( (int) $post->ID )
			: array( 'total' => 0, 'max' => 100, 'grade' => 'unknown', 'breakdown' => array() );

		$total   = (int) ( $audit['total'] ?? 0 );
		$max     = (int) ( $audit['max'] ?? 100 );
		$grade   = (string) ( $audit['grade'] ?? 'unknown' );
		$pct     = $max > 0 ? (int) round( ( $total / $max ) * 100 ) : 0;
		$color   = self::grade_color( $grade );

		// Content-shape signals — read-only diagnostic, not stored.
		$shape = self::content_shape_signals( $post );

		?>
		<div class="wpwm-audit-metabox">
			<div style="display:flex; align-items:center; gap:8px; margin-bottom:6px;">
				<div style="width:42px; height:42px; border-radius:50%; background:<?php echo esc_attr( $color ); ?>; color:#fff; font-weight:700; font-size:18px; display:flex; align-items:center; justify-content:center; flex:0 0 auto;">
					<?php echo esc_html( $grade ); ?>
				</div>
				<div>
					<div style="font-size:16px; font-weight:600;"><?php
						/* translators: %1$d: score, %2$d: max */
						printf( esc_html__( '%1$d / %2$d', 'webmcp-nexus' ), (int) $total, (int) $max );
					?></div>
					<div style="font-size:11px; color:var(--wpwm-text-muted, #646970);">
						<?php
						/* translators: %d: percent */
						printf( esc_html__( '%d%% AEO-ready', 'webmcp-nexus' ), (int) $pct );
						?>
					</div>
				</div>
			</div>

			<details style="margin-bottom:8px;">
				<summary style="cursor:pointer; font-size:12px; color:var(--wpwm-text-muted, #646970);"><?php esc_html_e( 'Score breakdown', 'webmcp-nexus' ); ?></summary>
				<ul style="margin:6px 0 0 0; padding-left:18px; font-size:12px; line-height:1.45;">
					<?php foreach ( (array) ( $audit['breakdown'] ?? array() ) as $row ) :
						$passes  = ! empty( $row['passes'] );
						$label   = (string) ( $row['label'] ?? '' );
						$points  = (int) ( $row['points'] ?? 0 );
						$hint    = (string) ( $row['hint'] ?? '' );
						?>
						<li style="margin-bottom:4px;">
							<strong style="color:<?php echo $passes ? '#006d2c' : '#9a6700'; ?>;">
								<?php echo $passes ? '✓' : '○'; ?>
								<?php echo esc_html( $label ); ?>
								(+<?php echo (int) $points; ?>)
							</strong>
							<?php if ( '' !== $hint && ! $passes ) : ?>
								<div style="color:var(--wpwm-text-muted, #646970); margin-left:14px;"><?php echo esc_html( $hint ); ?></div>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
			</details>

			<div style="border-top:1px solid #ddd; padding-top:8px;">
				<p style="margin:0 0 6px; font-size:12px; font-weight:600;"><?php esc_html_e( 'Content shape', 'webmcp-nexus' ); ?></p>
				<ul style="margin:0; padding-left:18px; font-size:12px; line-height:1.5;">
					<li><?php echo $shape['tldr']      ? '✓' : '○'; ?> <?php esc_html_e( 'TL;DR block', 'webmcp-nexus' ); ?></li>
					<li><?php echo $shape['faq']       ? '✓' : '○'; ?> <?php esc_html_e( 'FAQ block(s)', 'webmcp-nexus' ); ?></li>
					<li><?php echo $shape['takeaways'] ? '✓' : '○'; ?> <?php esc_html_e( 'Key-takeaways list', 'webmcp-nexus' ); ?></li>
					<li><?php echo $shape['author_bio'] ? '✓' : '○'; ?> <?php esc_html_e( 'Author bio with credentials', 'webmcp-nexus' ); ?></li>
					<li><?php echo $shape['last_updated'] ? '✓' : '○'; ?> <?php esc_html_e( 'Last-updated date', 'webmcp-nexus' ); ?></li>
				</ul>
				<?php if ( ! empty( $shape['hint'] ) ) : ?>
					<p style="margin:8px 0 0; font-size:11px; color:var(--wpwm-text-muted, #646970);">
						<?php echo esc_html( $shape['hint'] ); ?>
					</p>
				<?php endif; ?>
			</div>

			<p style="margin:10px 0 0; font-size:11px; color:var(--wpwm-text-muted, #646970);">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=wp-webmcp' ) ); ?>"><?php esc_html_e( 'Open sitewide audit', 'webmcp-nexus' ); ?></a>
			</p>
		</div>
		<?php
	}

	/**
	 * Lightweight, read-only structural inspection of the post content.
	 * Looks for shortcodes, block markers, and post-meta that indicate
	 * the editor has included each shape.
	 *
	 * @return array<string, mixed>
	 */
	private static function content_shape_signals( \WP_Post $post ): array {
		$content = (string) $post->post_content;

		// Shortcode hints (the plugin ships several that emit shapes).
		$tldr      = ( false !== stripos( $content, '[webmcp_summary' ) )
			|| has_block( 'core/paragraph', $post ); // best-effort — paragraph-rich body
		// Note: paragraph blocks are too generic; downgrade that signal.
		$tldr = ( false !== stripos( $content, '[webmcp_summary' ) );

		// FAQPage schema presence OR FAQ shortcode OR repeated "Q:" pattern.
		$faq = ( false !== stripos( $content, 'application/ld+json' ) && false !== stripos( $content, '"@type":"FAQPage"' ) )
			|| ( false !== stripos( $content, '[webmcp_faq' ) );

		// Key takeaways: webmcp_takeaways shortcode or numbered list block.
		$takeaways = ( false !== stripos( $content, '[webmcp_takeaways' ) )
			|| ( false !== stripos( $content, 'core/list' ) && (bool) preg_match( '/<ol[^>]*>.*<\/ol>/s', $content ) );

		// Author bio: shortcode or byline meta.
		$author_bio = ( false !== stripos( $content, '[webmcp_author' ) )
			|| '' !== (string) get_post_meta( $post->ID, 'wpwebmcp_author_bio', true );

		// Last-updated: tracked in A1c freshness meta OR explicit post meta.
		$last_updated = ( '' !== (string) get_post_meta( $post->ID, '_wpwebmcp_last_freshness_at', true ) )
			|| '' !== (string) get_post_meta( $post->ID, 'wpwebmcp_last_updated', true );

		// Hint string summarising which shapes are missing.
		$missing = array();
		if ( ! $tldr )      { $missing[] = __( 'TL;DR', 'webmcp-nexus' ); }
		if ( ! $faq )       { $missing[] = __( 'FAQ', 'webmcp-nexus' ); }
		if ( ! $takeaways ) { $missing[] = __( 'takeaways', 'webmcp-nexus' ); }
		if ( ! $author_bio ){ $missing[] = __( 'author bio', 'webmcp-nexus' ); }
		if ( ! $last_updated ) { $missing[] = __( 'last-updated date', 'webmcp-nexus' ); }
		$hint = empty( $missing )
			? __( 'All content shapes present.', 'webmcp-nexus' )
			: sprintf(
				/* translators: %s: comma-separated list */
				__( 'Missing: %s', 'webmcp-nexus' ),
				implode( ', ', $missing )
			);

		return array(
			'tldr'         => $tldr,
			'faq'          => $faq,
			'takeaways'    => $takeaways,
			'author_bio'   => $author_bio,
			'last_updated' => $last_updated,
			'hint'         => $hint,
		);
	}

	private static function grade_color( string $grade ): string {
		switch ( $grade ) {
			case 'A':  return '#006d2c';
			case 'B':  return '#1a7f37';
			case 'C':  return '#9a6700';
			case 'D':  return '#b32d2e';
			case 'F':  return '#8c2f1d';
			default:   return '#646970';
		}
	}
}
