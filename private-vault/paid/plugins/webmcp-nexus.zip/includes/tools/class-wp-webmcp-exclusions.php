<?php
/**
 * Exclusions — Doc §5.8 #6 + §7.1.
 *
 * Three REST routes (all `manage_options`):
 *   - GET  /wpwebmcp/v1/exclusions       → list current excluded IDs + display data
 *   - POST /wpwebmcp/v1/exclusions       → replace the wpwebmcp_excluded_ids option
 *   - GET  /wpwebmcp/v1/exclusions/search → title-contains WP_Query over public
 *                                          post types, ≤10 results, debounced
 *                                          client-side per Doc §5.8 #6.
 *
 * Also owns the `WP_WebMCP_Admin::render_screen()` page helper so the
 * Exclusions admin page shows the current chip list at load time.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_post__not_in -- exclusions are by definition a NOT IN query; no equivalent safe pattern available
final class WP_WebMCP_Exclusions {

	/** Capability required. */
	private const CAPABILITY = 'manage_options';

	/** Max search results per Doc §5.8 #6. */
	private const SEARCH_LIMIT = 10;

	/**
	 * Singleton hook entry. Called from WP_WebMCP::define_api_hooks()
	 * and from the Admin helper for the chip list.
	 *
	 * @return void
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Register the 3 routes per Doc §7.1.
	 */
	public static function register_routes(): void {
		$ns = 'wpwebmcp/v1';

		register_rest_route( $ns, '/exclusions', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_exclusions' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			),
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'save_exclusions' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
				'args'                => array(
					'ids' => array(
						'type'     => 'array',
						'required' => true,
						'items'    => array( 'type' => 'integer' ),
					),
				),
			),
		) );

		register_rest_route( $ns, '/exclusions/search', array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => array( __CLASS__, 'search_posts' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
			'args'                => array(
				's' => array(
					'type'              => 'string',
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
				),
			),
		) );
	}

	/**
	 * Permission callback for all 3 routes.
	 *
	 * @return bool|WP_Error
	 */
	public static function check_admin(): bool {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return new WP_Error(
				'wpwebmcp_forbidden',
				__( 'You do not have permission to manage WebMCP Nexus exclusions.', 'webmcp-nexus' ),
				array( 'status' => 403 )
			);
		}
		return true;
	}

	/**
	 * GET /exclusions — current excluded IDs + display metadata.
	 */
	/**
	 * F6: excluded post IDs, shared with llms.txt / markdown / manifest guards.
	 *
	 * @return int[]
	 */
	public static function get_excluded_ids(): array {
		$ids = (array) get_option( 'wpwebmcp_excluded_ids', array() );
		return array_values( array_filter( array_map( 'absint', $ids ) ) );
	}
	public static function get_exclusions() {
		$ids = (array) get_option( 'wpwebmcp_excluded_ids', array() );
		$ids = array_values( array_filter( array_map( 'absint', $ids ) ) );

		$chips = array();
		if ( ! empty( $ids ) ) {
			$posts = get_posts(
				array(
					'post__in'    => $ids,
					'post_type'   => 'any',
					'post_status' => 'any',
					'numberposts' => -1,
					'orderby'     => 'post__in',
				)
			);
			foreach ( $posts as $p ) {
				$chips[] = array(
					'id'    => (int) $p->ID,
					'title' => (string) $p->post_title,
					'type'  => (string) $p->post_type,
				);
			}
		}
		return rest_ensure_response(
			array(
				'ids'   => $ids,
				'chips' => $chips,
			)
		);
	}

	/**
	 * POST /exclusions — replace the entire excluded-ids array.
	 *
	 * Per spec: silently drop non-integers, no partial update.
	 */
	public static function save_exclusions( WP_REST_Request $request ) {
		$ids = $request->get_param( 'ids' );
		if ( ! is_array( $ids ) ) {
			return new WP_Error(
				'wpwebmcp_bad_params',
				__( 'ids must be an array.', 'webmcp-nexus' ),
				array( 'status' => 400 )
			);
		}
		$clean = array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
		update_option( 'wpwebmcp_excluded_ids', $clean, false );

		/**
		 * Fires after WebMCP exclusions are saved.
		 *
		 * @param int[] $clean Sanitized excluded post IDs.
		 */
		do_action( 'wpwebmcp_exclusions_saved', $clean );

		return rest_ensure_response(
			array(
				'ok'  => true,
				'ids' => $clean,
			)
		);
	}

	/**
	 * GET /exclusions/search — title-contains WP_Query, public post types only.
	 */
	public static function search_posts( WP_REST_Request $request ) {
		$s = (string) $request->get_param( 's' );
		$s = trim( $s );
		if ( '' === $s ) {
			return rest_ensure_response( array( 'results' => array() ) );
		}

		$public_pts = (array) get_option( 'wpwebmcp_custom_post_types', array( 'post', 'page' ) );
		$public_pts = apply_filters( 'wpwebmcp_post_type_tools', $public_pts );
		$public_pts = array_values( array_unique( array_filter( $public_pts ) ) );
		if ( empty( $public_pts ) ) {
			$public_pts = array( 'post', 'page' );
		}

		$excluded = array_map( 'absint', (array) get_option( 'wpwebmcp_excluded_ids', array() ) );

		$query = new WP_Query(
			array(
				'post_type'      => $public_pts,
				'post_status'    => 'publish',
				's'              => $s,
				'posts_per_page' => self::SEARCH_LIMIT,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'no_found_rows'  => true,
				'fields'         => 'ids',
				'post__not_in'   => $excluded,
			)
		);
		$ids = is_array( $query->posts ) ? $query->posts : array();

		$results = array();
		if ( ! empty( $ids ) ) {
			$posts = get_posts(
				array(
					'post__in'    => $ids,
					'post_type'   => 'any',
					'numberposts' => self::SEARCH_LIMIT,
					'orderby'     => 'post__in',
				)
			);
			foreach ( $posts as $p ) {
				$results[] = array(
					'id'    => (int) $p->ID,
					'title' => (string) $p->post_title,
					'type'  => (string) $p->post_type,
				);
			}
		}

		return rest_ensure_response( array( 'results' => $results ) );
	}

	/**
	 * Helper for the admin/Exclusions partial: returns the current chip
	 * list (same shape as get_exclusions).
	 *
	 * @return array<int, array{id:int,title:string,type:string}>
	 */
	public static function get_current_chips(): array {
		$ids = (array) get_option( 'wpwebmcp_excluded_ids', array() );
		$ids = array_values( array_filter( array_map( 'absint', $ids ) ) );
		if ( empty( $ids ) ) {
			return array();
		}
		$posts = get_posts(
			array(
				'post__in'    => $ids,
				'post_type'   => 'any',
				'post_status' => 'any',
				'numberposts' => -1,
				'orderby'     => 'post__in',
			)
		);
		$chips = array();
		foreach ( $posts as $p ) {
			$chips[] = array(
				'id'    => (int) $p->ID,
				'title' => (string) $p->post_title,
				'type'  => (string) $p->post_type,
			);
		}
		return $chips;
	}
}