<?php
/**
 * Meta Box — Doc §5.8 #10.
 *
 * Per-post WebMCP override (inherit / on / off). Renders on the side
 * metabox of every public post type listed in `wpwebmcp_custom_post_types`
 * (filtered via `wpwebmcp_post_type_tools` context).
 *
 * The "Preview manifest" link sets user meta `wpwebmcp_preview_seen`
 * when clicked — feeds the Dashboard checklist item ②.
 *
 * save_post guards (all required per spec):
 *   - autosave bail (`DOING_AUTOSAVE`)
 *   - revision bail (`wp_is_post_revision`)
 *   - nonce verify (`wpwebmcp_meta_box` action)
 *   - capability check (`current_user_can( 'edit_post', $id )`)
 *   - value whitelist `{inherit, on, off}`; unknown values are dropped
 *     (existing post meta is deleted on whitelist miss to keep state clean).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Meta_Box {

	/** Nonce action — used by both render + save. */
	private const NONCE_ACTION = 'wpwebmcp_meta_box';

	/** Allowed values for `_wpwebmcp_override`. */
	private const ALLOWED_OVERRIDE = array( '', 'on', 'off' );

	/** Allowed values for `_wpwebmcp_exposure_tier` (A2b). */
	private const ALLOWED_TIER = array( 'public', 'cited', 'premium' );

	/**
	 * Singleton hook entry. Called from WP_WebMCP::define_admin_hooks().
	 *
	 * @return void
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'init',           array( __CLASS__, 'register_post_meta_key' ) );
		WP_WebMCP_Loader::register_action( 'add_meta_boxes', array( __CLASS__, 'register' ) );
		WP_WebMCP_Loader::register_action( 'save_post',      array( __CLASS__, 'save' ), 10, 2 );
		WP_WebMCP_Loader::register_action( 'wp_ajax_wpwebmcp_mark_preview_seen', array( __CLASS__, 'ajax_mark_preview_seen' ) );
	}

	/**
	 * Register _wpwebmcp_override + _wpwebmcp_exposure_tier post meta keys
	 * to prevent REST/Gutenberg schema collisions.
	 */
	public static function register_post_meta_key(): void {
		register_post_meta(
			'',
			'_wpwebmcp_override',
			array(
				'show_in_rest'      => false,
				'single'            => true,
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => static function () {
					return current_user_can( 'edit_posts' );
				},
			)
		);

		// A2b: exposure-tier meta (per-post: public / cited / premium).
		register_post_meta(
			'',
			'_wpwebmcp_exposure_tier',
			array(
				'show_in_rest'      => false,
				'single'            => true,
				'type'              => 'string',
				'sanitize_callback' => array( __CLASS__, 'sanitize_tier' ),
				'auth_callback'     => function () {
					return current_user_can( 'edit_posts' );
				},
			)
		);
	}

	/**
	 * Sanitize callback for the exposure-tier meta. Falls back to 'public'
	 * for unknown values so a stale meta key can never lock a post out.
	 */
	public static function sanitize_tier( $value ): string {
		$v = is_string( $value ) ? sanitize_key( $value ) : '';
		return in_array( $v, self::ALLOWED_TIER, true ) ? $v : 'public';
	}

	/**
	 * AJAX handler to mark preview seen for the current user.
	 */
	public static function ajax_mark_preview_seen(): void {
		check_ajax_referer( 'wpwebmcp_preview_seen' );
		$user_id = get_current_user_id();
		if ( $user_id > 0 ) {
			update_user_meta( $user_id, 'wpwebmcp_preview_seen', 1 );
			wp_send_json_success();
		}
		wp_send_json_error( array( 'message' => 'no_user' ), 400 );
	}

	/**
	 * Register the WebMCP meta box on the configured public post types.
	 *
	 * `wpwebmcp_custom_post_types` is the option key; if empty or missing,
	 * fall back to `array( 'post', 'page' )` so the feature still works
	 * on the Step-0 default site.
	 *
	 * Filter `wpwebmcp_post_type_tools` lets third parties amend the list
	 * (per Doc Part 17 extensibility rules).
	 */
	public static function register(): void {
		$post_types = (array) get_option( 'wpwebmcp_custom_post_types', array( 'post', 'page' ) );
		$post_types = apply_filters( 'wpwebmcp_post_type_tools', $post_types );
		$post_types = array_values( array_unique( array_filter( $post_types ) ) );
		if ( empty( $post_types ) ) {
			return;
		}
		add_meta_box(
			'wpwebmcp_meta_box',
			__( 'WebMCP Nexus', 'webmcp-nexus' ),
			array( __CLASS__, 'render' ),
			$post_types,
			'side',
			'default'
		);
	}

	/**
	 * Render the meta box. Delegates to the partial, passing live data.
	 *
	 * @param \WP_Post $post Current post being edited.
	 */
	public static function render( \WP_Post $post ): void {
		$current_override = (string) get_post_meta( $post->ID, '_wpwebmcp_override', true );
		// A2b: current exposure tier (default 'public' when meta is absent).
		$current_tier = (string) get_post_meta( $post->ID, '_wpwebmcp_exposure_tier', true );
		if ( ! in_array( $current_tier, self::ALLOWED_TIER, true ) ) {
			$current_tier = 'public';
		}

		$excluded_ids = (array) get_option( 'wpwebmcp_excluded_ids', array() );
		$excluded_ids = array_map( 'absint', $excluded_ids );
		$excluded_summary = '';
		if ( in_array( (int) $post->ID, $excluded_ids, true ) ) {
			$excluded_summary = __( 'Excluded sitewide — override has no effect.', 'webmcp-nexus' );
		}

		$wpwebmcp_preview_seen = (bool) get_user_meta( get_current_user_id(), 'wpwebmcp_preview_seen', true );

		// Build the preview link per Doc §5.8⑩.
		$preview_url = wp_nonce_url(
			add_query_arg(
				array(
					'wpwebmcp_preview_manifest' => 1,
					'post_id'                    => (int) $post->ID,
				),
				admin_url( 'post.php' )
			),
			'wpwebmcp_preview'
		);

		// Pull partial; it uses the locals above.
		$partial = WEBMCP_NEXUS_PATH . 'admin/partials/wp-webmcp-meta-box.php';
		if ( file_exists( $partial ) ) {
			/** @noinspection PhpIncludeInspection */
			include $partial;
		}

		// Inline nonce + preview script.
		wp_nonce_field( self::NONCE_ACTION, '_wpwebmcp_meta_nonce', false );
		?>
		<script>
		(function () {
			var a = document.querySelector('.wpwm-metabox a[data-wpwm-preview-manifest]');
			if (!a) { return; }
			a.addEventListener('click', function (e) {
				e.preventDefault();
				fetch('<?php echo esc_url( rest_url( 'wpwebmcp/v1/manifest' ) ); ?>?post_id=<?php echo (int) $post->ID; ?>&_wpnonce=<?php echo esc_js( wp_create_nonce( 'wp_rest' ) ); ?>', { credentials: 'same-origin' })
					.then(function (r) { return r.json(); })
					.then(function () {
						return fetch('<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>', {
							method: 'POST',
							credentials: 'same-origin',
							headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
							body: 'action=wpwebmcp_mark_preview_seen&_ajax_nonce=<?php echo esc_js( wp_create_nonce( 'wpwebmcp_preview_seen' ) ); ?>'
						});
					})
					.then(function () { window.open(<?php echo wp_json_encode( $preview_url ); ?>, '_blank'); });
			});
		})();
		</script>
		<?php
	}

	/**
	 * save_post handler with all required guards.
	 *
	 * Order per Doc Part 17 "stop conditions":
	 *   1. autosave bail (DOING_AUTOSAVE)
	 *   2. revision bail (wp_is_post_revision)
	 *   3. user capability check
	 *   4. nonce verify
	 *   5. value whitelist
	 *   6. write or delete post meta
	 */
	public static function save( int $post_id, $post ): void {
		// 1. autosave bail.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		// 2. revision bail.
		if ( wp_is_post_revision( $post_id ) ) {
			return;
		}
		// 3. capability check.
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		// 4. nonce verify.
		$nonce = isset( $_POST['_wpwebmcp_meta_nonce'] )
			? sanitize_text_field( wp_unslash( (string) $_POST['_wpwebmcp_meta_nonce'] ) )
			: '';
		if ( '' === $nonce || ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			return;
		}

		// 5. value whitelist.
		$raw = isset( $_POST['_wpwebmcp_override'] )
			? sanitize_text_field( wp_unslash( (string) $_POST['_wpwebmcp_override'] ) )
			: '';
		if ( ! in_array( $raw, self::ALLOWED_OVERRIDE, true ) ) {
			// Unknown value — drop the meta so the field resets to inherit.
			delete_post_meta( $post_id, '_wpwebmcp_override' );
			return;
		}

		// 6. persist.
		if ( '' === $raw ) {
			delete_post_meta( $post_id, '_wpwebmcp_override' );
		} else {
			update_post_meta( $post_id, '_wpwebmcp_override', $raw );
		}

		// 7. A2b: persist the exposure tier (separate field, separate whitelist).
		$tier = isset( $_POST['_wpwebmcp_exposure_tier'] )
			? sanitize_key( wp_unslash( (string) $_POST['_wpwebmcp_exposure_tier'] ) )
			: 'public';
		if ( ! in_array( $tier, self::ALLOWED_TIER, true ) ) {
			// Unknown value — drop the meta so the field resets to public.
			delete_post_meta( $post_id, '_wpwebmcp_exposure_tier' );
		} elseif ( 'public' === $tier ) {
			delete_post_meta( $post_id, '_wpwebmcp_exposure_tier' );
		} else {
			update_post_meta( $post_id, '_wpwebmcp_exposure_tier', $tier );
		}
	}
}