<?php
/**
 * Settings — Doc §5.8② + §7.1.
 *
 * REST endpoint owner of `PUT /wpwebmcp/v1/settings` per Doc §7.1
 * (permission manage_options). Server-side field sanitization + an
 * allow-list of option keys taken from Part 16. Fires
 * `do_action('wpwebmcp_config_changed')` + `wp_cache_flush()` on success
 * (Doc §9.7 cache compatibility).
 *
 * Also owns the AJAX toggle endpoint:
 *   wp_ajax_wpwebmcp_toggle → flip wpwebmcp_enabled ONLY (per Step 6 spec).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Settings {

	/** Capability required to mutate settings. */
	private const CAPABILITY = 'manage_options';

	/**
	 * Allow-list of option keys that PUT /settings may write.
	 * Mirrors Part 16 with type hints for sanitize_field().
	 *
	 * Format: 'option_key' => 'type' where type ∈ bool|int|float|string|array(json).
	 *
	 * @var array<string,string>
	 */
	private const ALLOWED_KEYS = array(
		// General
		'wpwebmcp_enabled'                  => 'bool',
		'wpwebmcp_custom_post_types'        => 'array(json)',
		'wpwebmcp_performance_mode'         => 'bool',
		'wpwebmcp_polyfill_enabled'         => 'bool',
		'wpwebmcp_token_optimize'           => 'bool',
		// Tools & Policy
		'wpwebmcp_sandbox_mode'             => 'bool',
		// Rate Limits
		'wpwebmcp_rate_limit_read'          => 'int',
		'wpwebmcp_rate_limit_write'         => 'int',
		'wpwebmcp_max_calls_per_session'    => 'int',
		// Integrations
		'wpwebmcp_ga4_enabled'              => 'bool',
		'wpwebmcp_crawler_directives'       => 'array(json)',
		'wpwebmcp_custom_crawlers'          => 'array(json)',
		// Privacy
		'wpwebmcp_log_privacy_mode'         => 'bool',
		'wpwebmcp_log_retention_days'       => 'int',
		'wpwebmcp_bot_log_retention_days'   => 'int',
		// Advanced
		'wpwebmcp_wellknown_enabled'        => 'bool',
		'wpwebmcp_markdown_enabled'         => 'bool',
		'wpwebmcp_llmstxt_mode'             => 'string',
		'wpwebmcp_llmstxt_custom'           => 'string',
		'wpwebmcp_db_optimize_cron'         => 'bool',
		'wpwebmcp_cleanup_uninstall'        => 'bool',
		// Tool Access
		'wpwebmcp_role_access'              => 'array(json)',
		'wpwebmcp_alerts_enabled'            => 'bool',
		'wpwebmcp_alert_email'              => 'string',
		// Module 0 M0a: push server toggle
		'wpwebmcp_push_enabled'              => 'bool',
	);

	/**
	 * Singleton hook entry — called from WP_WebMCP::define_api_hooks().
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		WP_WebMCP_Loader::register_action( 'wp_ajax_wpwebmcp_toggle', array( __CLASS__, 'ajax_toggle' ) );
	}

	/**
	 * Register the PUT /settings REST route per Doc §7.1.
	 */
	public static function register_routes(): void {
		register_rest_route(
			'wpwebmcp/v1',
			'/settings',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_settings' ),
					'permission_callback' => array( __CLASS__, 'check_admin' ),
				),
				array(
					'methods'             => array( 'POST', 'PUT', 'PATCH' ),
					'callback'            => array( __CLASS__, 'save_settings' ),
					'permission_callback' => array( __CLASS__, 'check_admin' ),
				),
			)
		);
	}

	/**
	 * GET /settings — return all registered WebMCP options.
	 */
	public static function get_settings( WP_REST_Request $request ) {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return new WP_Error( 'wpwebmcp_forbidden', __( 'Forbidden.', 'webmcp-nexus' ), array( 'status' => 403 ) );
		}
		$data = array();
		foreach ( self::ALLOWED_KEYS as $key => $type ) {
			$data[ $key ] = get_option( $key );
		}
		return rest_ensure_response( array( 'ok' => true, 'settings' => $data ) );
	}

	/**
	 * Permission callback for the /settings route.
	 *
	 * @return bool|WP_Error
	 */
	public static function check_admin(): bool {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return new WP_Error(
				'wpwebmcp_forbidden',
				__( 'You do not have permission to manage WebMCP Nexus settings.', 'webmcp-nexus' ),
				array( 'status' => 403 )
			);
		}
		return true;
	}

	/**
	 * PUT/POST /settings — sanitize each key, write to DB, fire action + cache flush.
	 *
	 * Unknown keys in the request body are silently dropped (per spec).
	 * Returns the saved values so the client can refresh its UI in one round-trip.
	 */
	public static function save_settings( WP_REST_Request $request ) {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return new WP_Error( 'wpwebmcp_forbidden', __( 'Forbidden.', 'webmcp-nexus' ), array( 'status' => 403 ) );
		}

		$body = $request->get_json_params();
		if ( empty( $body ) || ! is_array( $body ) ) {
			$body = $request->get_body_params();
		}
		if ( empty( $body ) || ! is_array( $body ) ) {
			$body = array();
		}
		$saved = array();

		foreach ( self::ALLOWED_KEYS as $key => $type ) {
			if ( ! array_key_exists( $key, $body ) ) {
				continue;
			}
			$value = self::sanitize_field( $body[ $key ], $type, $key );
			update_option( $key, $value, false );
			$saved[ $key ] = $value;
		}

		// Cache compatibility per Doc §9.7.
		wp_cache_flush();
		/**
		 * Fires after WebMCP settings are saved.
		 *
		 * @param array $saved Map of option_key => saved_value.
		 */
		do_action( 'wpwebmcp_config_changed', $saved );

		return rest_ensure_response(
			array(
				'ok'     => true,
				'saved'  => $saved,
				'detail' => __( 'Settings saved.', 'webmcp-nexus' ),
			)
		);
	}

	/**
	 * AJAX toggle — flips `wpwebmcp_enabled` ONLY (per Step 6 spec).
	 *
	 * POST body: action=wpwebmcp_toggle, nonce=…, value=0|1.
	 *
	 * @return void Exits via wp_send_json_*.
	 */
	public static function ajax_toggle(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_send_json_error( array( 'code' => 'forbidden' ), 403 );
		}
		check_ajax_referer( 'wpwebmcp_admin_nonce', 'nonce' );

		// Per Step 6 spec: toggles wpwebmcp_enabled ONLY.
		$value  = isset( $_POST['value'] ) ? absint( $_POST['value'] ) : 0;
		update_option( 'wpwebmcp_enabled', (bool) $value, false );

		wp_cache_flush();
		do_action( 'wpwebmcp_config_changed', array( 'wpwebmcp_enabled' => (bool) $value ) );

		wp_send_json_success(
			array(
				'option' => 'wpwebmcp_enabled',
				'value'  => (bool) $value,
				'data'   => array( 'message' => __( 'Saved.', 'webmcp-nexus' ) ),
			)
		);
	}

	/**
	 * Sanitize a single option value by its declared type.
	 *
	 * @param mixed  $value Raw incoming value.
	 * @param string $type  One of bool|int|float|string|array(json).
	 * @param string $key   Option key (for filter name + error messages).
	 * @return mixed Sanitized value safe to persist via update_option().
	 */
	private static function sanitize_field( $value, string $type, string $key ) {
		// Optional per-key filter for third-party customisation.
		$value = apply_filters( 'wpwebmcp_setting_value_' . $key, $value, $type );

		switch ( $type ) {
			case 'bool':
				return (bool) $value;

			case 'int':
				return (int) $value;

			case 'float':
				return (float) $value;

			case 'string':
				if ( is_array( $value ) || is_object( $value ) ) {
					return '';
				}
				return (string) $value;

			case 'array(json)':
				// Accept arrays or JSON strings; normalize to a stored array.
				if ( is_string( $value ) ) {
					$decoded = json_decode( $value, true );
					$value   = is_array( $decoded ) ? $decoded : array();
				} elseif ( ! is_array( $value ) ) {
					$value = array();
				}
				return $value;
		}

		// Unknown type — defensive: return as-is (it's still up to the
		// schema layer to reject at write time).
		return $value;
	}
}