<?php
/**
 * Custom Tool Builder Controller — Doc §5.8 #3 + §7.1.
 *
 * Exposes REST CRUD API for custom WebMCP tool creation and lifecycle management:
 *   - GET    /wpwebmcp/v1/tools
 *   - POST   /wpwebmcp/v1/tools
 *   - GET    /wpwebmcp/v1/tools/{id}
 *   - PUT    /wpwebmcp/v1/tools/{id}
 *   - DELETE /wpwebmcp/v1/tools/{id}
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Tool_Builder {

	/** Required capability to manage tools. */
	private const CAPABILITY = 'manage_options';

	/**
	 * Initialize Tool Builder REST endpoints.
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Register REST routes for tool builder CRUD.
	 */
	public static function register_routes(): void {
		$ns = 'wpwebmcp/v1';

		register_rest_route(
			$ns,
			'/tools',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'list_tools' ),
					'permission_callback' => '__return_true',
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'create_tool' ),
					'permission_callback' => array( __CLASS__, 'check_admin' ),
				),
			)
		);

		register_rest_route(
			$ns,
			'/tools/(?P<id>\d+)',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_tool' ),
					'permission_callback' => array( __CLASS__, 'check_admin' ),
				),
				array(
					'methods'             => array( 'POST', 'PUT', 'PATCH' ),
					'callback'            => array( __CLASS__, 'update_tool' ),
					'permission_callback' => array( __CLASS__, 'check_admin' ),
				),
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => array( __CLASS__, 'delete_tool' ),
					'permission_callback' => array( __CLASS__, 'check_admin' ),
				),
			)
		);

		// Dedicated alias for custom tools CRUD.
		register_rest_route(
			$ns,
			'/custom-tools',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'list_tools' ),
					'permission_callback' => array( __CLASS__, 'check_admin' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'create_tool' ),
					'permission_callback' => array( __CLASS__, 'check_admin' ),
				),
			)
		);

		register_rest_route(
			$ns,
			'/custom-tools/(?P<id>\d+)',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_tool' ),
					'permission_callback' => array( __CLASS__, 'check_admin' ),
				),
				array(
					'methods'             => array( 'POST', 'PUT', 'PATCH' ),
					'callback'            => array( __CLASS__, 'update_tool' ),
					'permission_callback' => array( __CLASS__, 'check_admin' ),
				),
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => array( __CLASS__, 'delete_tool' ),
					'permission_callback' => array( __CLASS__, 'check_admin' ),
				),
			)
		);
	}

	/**
	 * Permission check.
	 */
	public static function check_admin(): bool {
		return current_user_can( self::CAPABILITY );
	}

	/**
	 * GET /wpwebmcp/v1/tools
	 */
	public static function list_tools( WP_REST_Request $request ) {
		// If caller is non-admin and not explicitly requesting custom tools,
		// serve the public tools index so external AI agents never get blocked.
		if ( ! current_user_can( self::CAPABILITY ) && ! $request->get_param( 'custom' ) ) {
			if ( class_exists( 'WP_WebMCP_Tools' ) ) {
				return WP_WebMCP_Tools::get_tools_index( $request );
			}
		}

		$rows  = class_exists( 'WP_WebMCP_Tool_Repository' )
			? WP_WebMCP_Tool_Repository::list_all()
			: array();
		$items = array();
		if ( is_array( $rows ) ) {
			foreach ( $rows as $row ) {
				$params = is_string( $row['parameters'] ?? null )
					? json_decode( (string) $row['parameters'], true )
					: ( $row['parameters'] ?? null );
				$row['parameters'] = is_array( $params ) ? $params : array();
				$items[] = $row;
			}
		}

		return rest_ensure_response(
			array(
				'ok'    => true,
				'tools' => $items,
			)
		);
	}

	/**
	 * POST /wpwebmcp/v1/tools
	 */
	public static function create_tool( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			return new WP_Error( 'wpwebmcp_bad_request', __( 'Invalid payload.', 'webmcp-nexus' ), array( 'status' => 400 ) );
		}

		$tool_name = sanitize_key( (string) ( $params['tool_name'] ?? '' ) );
		if ( '' === $tool_name ) {
			return new WP_Error( 'wpwebmcp_missing_name', __( 'Tool name is required (camelCase or alphanumeric).', 'webmcp-nexus' ), array( 'status' => 400 ) );
		}

		if ( WP_WebMCP_Tool_Repository::find_by_slug( $tool_name ) ) {
			return new WP_Error( 'wpwebmcp_tool_exists', __( 'A tool with this name already exists.', 'webmcp-nexus' ), array( 'status' => 409 ) );
		}

		$id = WP_WebMCP_Tool_Repository::insert( $params );
		if ( ! $id ) {
			return new WP_Error( 'wpwebmcp_insert_failed', __( 'Could not save tool.', 'webmcp-nexus' ), array( 'status' => 500 ) );
		}

		$created = WP_WebMCP_Tool_Repository::find_by_id( $id );
		return rest_ensure_response(
			array(
				'ok'   => true,
				'tool' => $created,
			)
		);
	}

	/**
	 * GET /wpwebmcp/v1/tools/{id}
	 */
	public static function get_tool( WP_REST_Request $request ) {
		$id   = (int) $request->get_param( 'id' );
		$tool = WP_WebMCP_Tool_Repository::find_by_id( $id );

		if ( ! $tool ) {
			return new WP_Error( 'wpwebmcp_not_found', __( 'Tool not found.', 'webmcp-nexus' ), array( 'status' => 404 ) );
		}

		return rest_ensure_response(
			array(
				'ok'   => true,
				'tool' => $tool,
			)
		);
	}

	/**
	 * PUT /wpwebmcp/v1/tools/{id}
	 */
	public static function update_tool( WP_REST_Request $request ) {
		$id   = (int) $request->get_param( 'id' );
		$tool = WP_WebMCP_Tool_Repository::find_by_id( $id );

		if ( ! $tool ) {
			return new WP_Error( 'wpwebmcp_not_found', __( 'Tool not found.', 'webmcp-nexus' ), array( 'status' => 404 ) );
		}

		$params = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			return new WP_Error( 'wpwebmcp_bad_request', __( 'Invalid payload.', 'webmcp-nexus' ), array( 'status' => 400 ) );
		}

		$ok = WP_WebMCP_Tool_Repository::update( $id, $params );
		if ( ! $ok ) {
			return new WP_Error( 'wpwebmcp_update_failed', __( 'Could not update tool.', 'webmcp-nexus' ), array( 'status' => 500 ) );
		}

		$updated = WP_WebMCP_Tool_Repository::find_by_id( $id );
		return rest_ensure_response(
			array(
				'ok'   => true,
				'tool' => $updated,
			)
		);
	}

	/**
	 * DELETE /wpwebmcp/v1/tools/{id}
	 */
	public static function delete_tool( WP_REST_Request $request ) {
		$id   = (int) $request->get_param( 'id' );
		$tool = WP_WebMCP_Tool_Repository::find_by_id( $id );

		if ( ! $tool ) {
			return new WP_Error( 'wpwebmcp_not_found', __( 'Tool not found.', 'webmcp-nexus' ), array( 'status' => 404 ) );
		}

		$ok = WP_WebMCP_Tool_Repository::delete( $id );
		return rest_ensure_response(
			array(
				'ok' => (bool) $ok,
				'id' => $id,
			)
		);
	}
}
