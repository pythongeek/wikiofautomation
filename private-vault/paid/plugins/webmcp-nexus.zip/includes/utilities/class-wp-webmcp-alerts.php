<?php
/**
 * Email Alerts Dispatcher — Doc §7.2 + §13.
 *
 * Dispatches notification emails to site administrators when rate limits
 * are hit repeatedly, critical tool execution errors occur, or the
 * health score drops significantly. Includes cooldown protection to
 * prevent spam.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Alerts {

	/** Cooldown window for identical alerts (1 hour). */
	private const COOLDOWN_SECONDS = 3600;

	/**
	 * Initialize alert hooks.
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_action( 'wpwebmcp_rate_limit_exceeded',   array( __CLASS__, 'handle_rate_limit_hook' ), 10, 3 );
		WP_WebMCP_Loader::register_action( 'wpwebmcp_health_score_dropped',   array( __CLASS__, 'handle_health_drop_hook' ), 10, 3 );
	}

	/**
	 * Hook adapter for rate limits.
	 */
	public static function handle_rate_limit_hook( string $slug, int $calls, int $limit ): void {
		$instance = new self();
		$instance->send_rate_limit_alert( $slug, $calls, $limit );
	}

	/**
	 * Hook adapter for health score drops.
	 */
	public static function handle_health_drop_hook( int $previous, int $current, string $message ): void {
		$instance = new self();
		$instance->send_health_drop_alert( $previous, $current, $message );
	}

	/**
	 * Check if email alerting is enabled.
	 */
	public function is_enabled(): bool {
		return (bool) get_option( 'wpwebmcp_alerts_enabled', false );
	}

	/**
	 * Get the target recipient email address.
	 */
	public function get_recipient(): string {
		$email = (string) get_option( 'wpwebmcp_alert_email', get_option( 'admin_email' ) );
		return sanitize_email( $email );
	}

	/**
	 * Send rate limit breach alert.
	 */
	public function send_rate_limit_alert( string $slug, int $calls, int $limit ): bool {
		if ( ! $this->is_enabled() ) {
			return false;
		}

		$cooldown_key = 'wpwm_alt_rl_' . sanitize_key( $slug );
		if ( false !== get_transient( $cooldown_key ) ) {
			return false;
		}

		$to      = $this->get_recipient();
		$site    = get_bloginfo( 'name' );
		$subject = sprintf( '[%s] WebMCP Rate Limit Exceeded: %s', $site, $slug );
		$message = sprintf(
			"Hello,\n\nThe tool '%s' has exceeded its rate limit on %s.\n\nCalls: %d / min (Limit: %d / min)\nTime: %s UTC\n\nPlease check your WebMCP Nexus Dashboard and Audit Log for details:\n%s\n\n— WebMCP Nexus",
			$slug,
			home_url(),
			$calls,
			$limit,
			gmdate( 'Y-m-d H:i:s' ),
			admin_url( 'admin.php?page=wp-webmcp-audit-log' )
		);

		set_transient( $cooldown_key, 1, self::COOLDOWN_SECONDS );
		return wp_mail( $to, $subject, $message, array( 'Content-Type: text/plain; charset=UTF-8' ) );
	}

	/**
	 * Send tool error alert.
	 */
	public function send_error_alert( string $slug, string $error_message ): bool {
		if ( ! $this->is_enabled() ) {
			return false;
		}

		$cooldown_key = 'wpwm_alt_err_' . sanitize_key( $slug );
		if ( false !== get_transient( $cooldown_key ) ) {
			return false;
		}

		$to      = $this->get_recipient();
		$site    = get_bloginfo( 'name' );
		$subject = sprintf( '[%s] WebMCP Tool Error: %s', $site, $slug );
		$message = sprintf(
			"Hello,\n\nA tool execution error occurred on %s for tool '%s'.\n\nError:\n%s\n\nTime: %s UTC\n\nAudit Log:\n%s\n\n— WebMCP Nexus",
			home_url(),
			$slug,
			$error_message,
			gmdate( 'Y-m-d H:i:s' ),
			admin_url( 'admin.php?page=wp-webmcp-audit-log' )
		);

		set_transient( $cooldown_key, 1, self::COOLDOWN_SECONDS );
		return wp_mail( $to, $subject, $message, array( 'Content-Type: text/plain; charset=UTF-8' ) );
	}

	/**
	 * Send health score drop alert.
	 */
	public function send_health_drop_alert( int $previous, int $current, string $detail ): bool {
		if ( ! $this->is_enabled() ) {
			return false;
		}

		$cooldown_key = 'wpwm_alt_hdrop';
		if ( false !== get_transient( $cooldown_key ) ) {
			return false;
		}

		$to      = $this->get_recipient();
		$site    = get_bloginfo( 'name' );
		$subject = sprintf( '[%s] WebMCP Health Score Dropped (%d → %d)', $site, $previous, $current );
		$message = sprintf(
			"Hello,\n\nThe WebMCP agent readiness health score on %s has dropped by %d points.\n\nPrevious Score: %d\nCurrent Score: %d\n\nDetails: %s\n\nPlease visit the WebMCP Dashboard to run validation and review recommendations:\n%s\n\n— WebMCP Nexus",
			home_url(),
			( $previous - $current ),
			$previous,
			$current,
			$detail,
			admin_url( 'admin.php?page=wp-webmcp' )
		);

		set_transient( $cooldown_key, 1, self::COOLDOWN_SECONDS );
		return wp_mail( $to, $subject, $message, array( 'Content-Type: text/plain; charset=UTF-8' ) );
	}
}
