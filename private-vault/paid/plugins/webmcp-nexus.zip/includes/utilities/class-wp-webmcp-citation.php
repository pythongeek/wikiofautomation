<?php
/**
 * Citation — Module A1a (AEO & Access-Control, citation-grade response wrapping).
 *
 * Builds citation objects from a WP post and decorates tool responses
 * with a top-level `citations` array. The intent: when an AI agent calls
 * any tool that returns post data, the response carries provenance
 * metadata (URL, title, author, date, license) so the agent can cite
 * the source accurately.
 *
 * Public surface:
 *   - build( int $post_id ): ?array   — single citation object for one post.
 *   - decorate( array $result ): array — walks a tool response, collects
 *                                        every post id it sees, attaches a
 *                                        deduplicated `citations` array.
 *   - default_license(): string      — pulls the site-wide option.
 *
 * License semantics:
 *   - Per-call the citation object always reflects the post's effective
 *     license. Today that's the site-wide setting `wpwebmcp_default_license`
 *     (option #45). The hook `wpwebmcp_citation_license` lets future
 *     per-post licensing override it without touching this class.
 *
 * Cost discipline:
 *   - decorate() short-circuits when no post IDs are found in the payload
 *     so non-post tool calls (getSiteInfo, searchSite, etc.) don't pay
 *     for any DB roundtrips.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Citation {

	/**
	 * Default license fallback when the option is unset or empty.
	 * Empty string means "license unspecified" — agents should still
	 * cite, but the field carries no explicit license hint.
	 */
	private const FALLBACK_LICENSE = '';

	/**
	 * Build a citation object for one post id.
	 *
	 * @param int                 $post_id
	 * @param array<string,mixed> $request_headers Optional REST headers map
	 *                                              (lowercase key => string|string[]).
	 *                                              Used by A2b to gate cited /
	 *                                              premium tiers on the request.
	 * @return array<string,mixed>|null  null when the post doesn't exist,
	 *                                   isn't a real published viewable post,
	 *                                   or the request isn't authorized for
	 *                                   the post's exposure tier.
	 */
	public static function build( int $post_id, array $request_headers = array() ): ?array {
		$post_id = absint( $post_id );
		if ( $post_id <= 0 ) {
			return null;
		}
		$p = get_post( $post_id );
		if ( ! $p ) {
			return null;
		}
		// Only emit citations for posts that exist in a viewable state.
		// Drafts, private posts, auto-drafts, revisions: skip so agents
		// don't cite something the public can't see.
		$viewable = in_array( (string) $p->post_status, array( 'publish', 'private' ), true );
		if ( ! $viewable ) {
			return null;
		}
		// A2b: exposure-tier gate. public = always allowed; cited / premium
		// require the matching signed header. If unauthorized, the citation
		// is withheld silently (no information leak about the post's tier).
		if ( class_exists( 'WP_WebMCP_Exposure_Tier' )
			&& ! WP_WebMCP_Exposure_Tier::is_authorized( $post_id, $request_headers ) ) {
			return null;
		}

		$license = self::license_for_post( $p );

		// A1b: surface the content-credentials chain + the latest hash so
		// downstream agents can verify provenance. Cheap: one get_post_meta
		// per citation, batched for tools that reference multiple posts
		// (the decorate() loop builds one citation per unique post id).
		$credentials = array();
		if ( class_exists( 'WP_WebMCP_Content_Credentials' ) ) {
			$credentials = WP_WebMCP_Content_Credentials::read( $post_id );
		}

		return array(
			'url'                 => (string) get_permalink( $p ),
			'title'               => (string) $p->post_title,
			'author'              => (string) get_the_author_meta( 'display_name', (int) $p->post_author ),
			'date'                => (string) mysql2date( 'c', (string) $p->post_date_gmt ),
			'license'             => $license,
			// A1b additions:
			'content_hash'        => self::current_content_hash( $p, $credentials ),
			'edit_chain_length'   => count( $credentials ),
		);
	}

	/**
	 * Latest content_hash from the credentials chain (if any), else
	 * compute one on-the-fly from the live post_content so first-time
	 * calls before the save_post hook fires still have a hash.
	 *
	 * @param WP_Post $post
	 * @param array<int, array{by:string, at:string, hash:string, action:string}> $credentials
	 */
	private static function current_content_hash( WP_Post $post, array $credentials ): string {
		if ( ! empty( $credentials ) ) {
			$latest = $credentials[ count( $credentials ) - 1 ];
			return (string) $latest['hash'];
		}
		if ( class_exists( 'WP_WebMCP_Content_Credentials' ) ) {
			return WP_WebMCP_Content_Credentials::content_hash( (string) $post->post_content );
		}
		return '';
	}

	/**
	 * Walk a tool response, find every post id, attach a deduplicated
	 * `citations` array at the top level.
	 *
	 * Heuristic: any integer value whose key is exactly `id` (or whose
	 * key ends with `_id` for foreign-style references like
	 * `post_id`, `attachment_id`, `author_id`).
	 *
	 * @param array<string,mixed>  $result
	 * @param array<string,mixed>  $request_headers Optional REST headers map;
	 *                                            forwarded to build() for A2b.
	 * @return array<string,mixed>  $result with a `citations` key added
	 *                               when at least one citation was found.
	 *                               Unchanged when no post ids were seen
	 *                               or every post is in a restricted tier.
	 */
	public static function decorate( array $result, array $request_headers = array() ): array {
		$ids = self::collect_post_ids( $result );
		if ( empty( $ids ) ) {
			return $result;
		}

		$citations = array();
		foreach ( $ids as $pid ) {
			$cit = self::build( $pid, $request_headers );
			if ( null === $cit ) {
				continue;
			}
			// De-dupe by url (stable, unique, agent-friendly).
			$key = (string) $cit['url'];
			if ( '' === $key ) {
				continue;
			}
			if ( ! isset( $citations[ $key ] ) ) {
				$citations[ $key ] = $cit;
			}
		}

		if ( empty( $citations ) ) {
			return $result;
		}

		// Place at the top, second key after `ok` if present so the
		// envelope stays predictable for downstream parsers.
		$ordered = array();
		if ( array_key_exists( 'ok', $result ) ) {
			$ordered['ok'] = $result['ok'];
		}
		$ordered['citations'] = array_values( $citations );
		foreach ( $result as $k => $v ) {
			if ( 'ok' === $k || 'citations' === $k ) {
				continue;
			}
			$ordered[ $k ] = $v;
		}
		return $ordered;
	}

	/**
	 * Read the site-wide default license option. Returns empty string when
	 * the option is missing.
	 */
	public static function default_license(): string {
		$opt = get_option( 'wpwebmcp_default_license', self::FALLBACK_LICENSE );
		return is_string( $opt ) ? trim( $opt ) : self::FALLBACK_LICENSE;
	}

	/**
	 * Resolve the license string for a single post. Today the answer is
	 * always the site-wide setting — but we keep a filter so a future
	 * per-post license meta can override without modifying this class.
	 */
	private static function license_for_post( WP_Post $post ): string {
		$license = self::default_license();

		/**
		 * Filter the license string attached to a citation.
		 *
		 * Receives the resolved license string + the WP_Post object.
		 * Return a non-empty string to override, or '' to keep the
		 * site-wide default for this citation.
		 *
		 * @param string $license
		 * @param WP_Post $post
		 */
		$filtered = (string) apply_filters( 'wpwebmcp_citation_license', $license, $post );
		return '' === $filtered ? $license : $filtered;
	}

	/**
	 * Recursively collect post ids from a tool response payload.
	 *
	 * @param mixed $node
	 * @param array<int,int> $out accumulator (passed by ref)
	 */
	private static function collect_post_ids_recursive( $node, array &$out ): void {
		if ( is_array( $node ) ) {
			foreach ( $node as $k => $v ) {
				$key = is_string( $k ) ? strtolower( $k ) : '';
				// Match plain `id` (top-level post ref) and `*_id` (foreign refs).
				if ( 'id' === $key || str_ends_with( $key, '_id' ) ) {
					if ( is_numeric( $v ) && (int) $v > 0 ) {
						$out[ (int) $v ] = (int) $v;
					}
				}
				self::collect_post_ids_recursive( $v, $out );
			}
		}
	}

	/**
	 * Public helper for the recursion entry point — keeps the recursive
	 * accumulator private while still callable from static methods.
	 *
	 * @param array<string,mixed> $result
	 * @return array<int,int>
	 */
	private static function collect_post_ids( array $result ): array {
		$out = array();
		self::collect_post_ids_recursive( $result, $out );
		ksort( $out );
		return $out;
	}
}
