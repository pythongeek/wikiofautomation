<?php
/**
 * Conflict Detector — Doc §10 (XF12) + §11.4.
 *
 * Inspects the WordPress environment for common third-party conflicts:
 *   - Physical robots.txt file blocking dynamic WP robots.txt generation.
 *   - Caching plugins that might cache dynamic headers or manifests.
 *   - SEO plugins modifying robots / meta headers.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Conflict_Detector {

	/**
	 * Run all conflict checks and return detected warnings.
	 *
	 * @return array<int, array{type: string, severity: string, message: string, resolution: string}>
	 */
	public static function get_conflicts(): array {
		$conflicts = array();

		// 1. Check physical robots.txt.
		if ( self::has_physical_robots_txt() ) {
			$conflicts[] = array(
				'type'       => 'physical_robots_txt',
				'severity'   => 'warning',
				'message'    => __( 'A physical robots.txt file was found in your site root.', 'webmcp-nexus' ),
				'resolution' => __( 'Physical robots.txt prevents dynamic AI crawler rules from being applied. Delete or merge your rules manually.', 'webmcp-nexus' ),
			);
		}

		// 2. Check caching plugins.
		$caching = self::detect_caching_plugins();
		if ( ! empty( $caching ) ) {
			$conflicts[] = array(
				'type'       => 'caching_plugin',
				'severity'   => 'info',
				'message'    => sprintf(
					/* translators: %s: plugin name */
					__( 'Active caching plugin detected: %s.', 'webmcp-nexus' ),
					implode( ', ', $caching )
				),
				'resolution' => __( 'Ensure /wp-json/wpwebmcp/ and /llms.txt endpoints are excluded from page caching.', 'webmcp-nexus' ),
			);
		}

		// 3. Check SEO plugins.
		$seo = self::detect_seo_plugins();
		if ( ! empty( $seo ) ) {
			$conflicts[] = array(
				'type'       => 'seo_plugin',
				'severity'   => 'info',
				'message'    => sprintf(
					/* translators: %s: plugin name */
					__( 'Active SEO plugin detected: %s.', 'webmcp-nexus' ),
					implode( ', ', $seo )
				),
				'resolution' => __( 'WebMCP AI crawler rules work alongside SEO plugins; review your robots.txt output.', 'webmcp-nexus' ),
			);
		}

		return $conflicts;
	}

	/**
	 * Check if a physical robots.txt file exists on the server.
	 */
	public static function has_physical_robots_txt(): bool {
		$path = ABSPATH . 'robots.txt';
		return file_exists( $path );
	}

	/**
	 * Detect active caching plugins.
	 *
	 * @return string[]
	 */
	public static function detect_caching_plugins(): array {
		$found = array();

		if ( defined( 'WP_ROCKET_VERSION' ) ) {
			$found[] = 'WP Rocket';
		}
		if ( defined( 'LSCWP_V' ) || class_exists( 'LiteSpeed_Cache' ) ) {
			$found[] = 'LiteSpeed Cache';
		}
		if ( defined( 'W3TC' ) || class_exists( 'W3_Root' ) ) {
			$found[] = 'W3 Total Cache';
		}
		if ( defined( 'WPCACHEHOME' ) ) {
			$found[] = 'WP Super Cache';
		}
		if ( class_exists( 'WP_Fastest_Cache' ) ) {
			$found[] = 'WP Fastest Cache';
		}

		return $found;
	}

	/**
	 * Detect active SEO plugins.
	 *
	 * @return string[]
	 */
	public static function detect_seo_plugins(): array {
		$found = array();

		if ( defined( 'WPSEO_VERSION' ) ) {
			$found[] = 'Yoast SEO';
		}
		if ( class_exists( 'RankMath' ) ) {
			$found[] = 'Rank Math SEO';
		}
		if ( defined( 'AIOSEO_VERSION' ) ) {
			$found[] = 'All in One SEO';
		}
		if ( defined( 'SEOPRESS_VERSION' ) ) {
			$found[] = 'SEOPress';
		}

		return $found;
	}
}
