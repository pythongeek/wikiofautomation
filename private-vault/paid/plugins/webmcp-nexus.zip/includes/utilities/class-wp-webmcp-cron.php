<?php
/**
 * Cron handlers — Doc §4.7 + §13.
 *
 * The 3 events (Doc §4.7):
 *   wpwebmcp_log_purge           (daily)    → Log_Repository::purge_before
 *   wpwebmcp_bot_analytics_rollup (daily)    → Bot_Log_Repository stats → wpwebmcp_bot_stats_30d transient + purge
 *   wpwebmcp_schema_validation   (weekly)   → Validator + admin notice/alert on drop ≥20
 *
 * Bodies:
 *   - purge_log + run_schema_validation land in Step 8.
 *   - rollup_bot_analytics stays a marked shell until Step 11 (logs that).
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Cron {

	/**
	 * Register the 3 cron callbacks. Called from WP_WebMCP::define_cron_hooks().
	 */
	public static function register_hooks(): void {
		WP_WebMCP_Loader::register_action( 'wpwebmcp_log_purge',            array( self::class, 'purge_log' ) );
		WP_WebMCP_Loader::register_action( 'wpwebmcp_bot_analytics_rollup', array( self::class, 'rollup_bot_analytics' ) );
		WP_WebMCP_Loader::register_action( 'wpwebmcp_schema_validation',    array( self::class, 'run_schema_validation' ) );
	}

	/**
	 * Daily log purge (Step 8 body).
	 *
	 * Reads `wpwebmcp_log_retention_days`, computes the cutoff timestamp,
	 * and calls Log_Repository::purge_before( $cutoff ).
	 */
	public static function purge_log(): void {
		$days = (int) get_option( 'wpwebmcp_log_retention_days', 30 );
		if ( $days <= 0 ) {
			// 0 = never purge (admin opt-in to keep forever).
			return;
		}
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );
		$deleted = class_exists( 'WP_WebMCP_Log_Repository' )
			? (int) WP_WebMCP_Log_Repository::purge_before( $cutoff )
			: 0;
		if ( $deleted > 0 && class_exists( 'WP_WebMCP_Logger' ) ) {
			WP_WebMCP_Logger::write(
				'cron.purge_log',
				array( 'days' => $days, 'deleted' => $deleted ),
				'success',
				'',
				0,
				0
			);
		}
	}

	/**
	 * Weekly schema self-check (Step 8 body).
	 *
	 * Runs WP_WebMCP_Validator::calculate_health_score(), compares against
	 * the previous cached score, and fires an admin notice + alert when
	 * the score drops by 20 points or more.
	 */
	public static function run_schema_validation(): void {
		if ( ! class_exists( 'WP_WebMCP_Validator' ) ) {
			return;
		}
		$previous = (int) ( WP_WebMCP_Validator::get_cached_score() ?? 100 );
		$current  = (int) WP_WebMCP_Validator::calculate_health_score();

		if ( ( $previous - $current ) >= 20 ) {
			$message = sprintf(
				/* translators: %1$d: Previous score, %2$d: Current score */
				__( 'WebMCP Nexus health score dropped from %1$d to %2$d (≥20 point drop). Run validation manually.', 'webmcp-nexus' ),
				$previous,
				$current
			);

			// Add admin notice (only on admin requests).
			WP_WebMCP_Loader::register_action(
				'admin_notices',
				static function () use ( $message ) {
					echo '<div class="notice notice-warning"><p>' . esc_html( $message ) . '</p></div>';
				}
			);

			// Fire the alert hook; WP_WebMCP_Alerts (Step 13) handles it.
			do_action( 'wpwebmcp_health_score_dropped', $previous, $current, $message );
		}
	}

	/**
	 * Daily bot analytics rollup — Step 11 body (NOT Step 8).
	 *
	 * Stub: logs that it fired. Step 11 replaces this body with the real
	 * stats aggregation + wpwebmcp_bot_stats_30d transient + old-row purge.
	 */
	public static function rollup_bot_analytics(): void {
		if ( class_exists( 'WP_WebMCP_Bot_Analytics' ) ) {
			WP_WebMCP_Bot_Analytics::rollup();
		}
		if ( class_exists( 'WP_WebMCP_Logger' ) ) {
			WP_WebMCP_Logger::write(
				'cron.rollup_bot_analytics',
				array( 'status' => 'completed' ),
				'success',
				'',
				0,
				0
			);
		}
	}
}