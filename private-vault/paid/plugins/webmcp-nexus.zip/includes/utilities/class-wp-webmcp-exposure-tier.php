<?php
/**
 * Exposure_Tier — Module A A2b (Content exposure tiers).
 *
 * Per-post access tier:
 *   public  — default; any tool response can include the citation.
 *   cited   — only when the request supplies a valid `X-Provide-Citation-Proof`
 *             header containing an HMAC-signed token for this post id.
 *   premium — only when the request supplies a valid `X-Premium-Receipt`
 *             header containing an HMAC-signed payment receipt for this post id.
 *
 * Tokens are base64url-encoded JSON objects with this shape:
 *   citation-proof:  { post_id, agent_slug, issued_at, exp, sig }
 *   premium-receipt: { post_id, payment_id, issued_at, exp, sig }
 *
 * The `sig` field is HMAC-SHA256 of `post_id|agent_or_payment|issued_at|exp`
 * using `wpwebmcp_exposure_secret` (a per-site key generated lazily on first
 * use). Tokens are short-lived (cited = 1h, premium = 24h) and bound to a
 * specific post id, so a stolen token cannot be used against a different post.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Exposure_Tier {

	/** Post meta key. Underscore prefix keeps it out of the Custom Fields UI. */
	public const META_KEY = '_wpwebmcp_exposure_tier';

	public const TIER_PUBLIC  = 'public';
	public const TIER_CITED   = 'cited';
	public const TIER_PREMIUM = 'premium';

	/** Request header names. WP_REST_Request::get_headers() returns these lowercase. */
	public const HEADER_CITATION_PROOF  = 'x_provide_citation_proof';
	public const HEADER_PREMIUM_RECEIPT = 'x_premium_receipt';

	/** Token TTLs per tier (seconds). Short for cited (typical RAG flow), longer for premium (paid access). */
	private const TOKEN_TTL_SECONDS = array(
		self::TIER_CITED   => 3600,    // 1 hour
		self::TIER_PREMIUM => 86400,   // 24 hours
	);

	/** Whitelist for the post meta value. Unknown values fall back to `public`. */
	private const ALLOWED_TIERS = array( self::TIER_PUBLIC, self::TIER_CITED, self::TIER_PREMIUM );

	/**
	 * Per-site HMAC secret. Lazy-generated on first use and stored in the
	 * `wpwebmcp_exposure_secret` option (non-autoloaded to keep it out of
	 * the alloptions cache that ships to every REST response).
	 */
	public static function secret(): string {
		$s = (string) get_option( 'wpwebmcp_exposure_secret', '' );
		if ( '' === $s ) {
			$s = bin2hex( random_bytes( 32 ) );
			update_option( 'wpwebmcp_exposure_secret', $s, false );
		}
		return $s;
	}

	/**
	 * Read the effective tier for a post. Missing/unknown values fall back
	 * to `public` so the meta being absent is always a safe default.
	 */
	public static function tier_for_post( int $post_id ): string {
		$post_id = absint( $post_id );
		if ( $post_id <= 0 ) {
			return self::TIER_PUBLIC;
		}
		$tier = (string) get_post_meta( $post_id, self::META_KEY, true );
		return in_array( $tier, self::ALLOWED_TIERS, true ) ? $tier : self::TIER_PUBLIC;
	}

	/**
	 * Persist a tier for a post. Storing `public` deletes the meta so the
	 * custom-fields box resets to "default".
	 */
	public static function set_tier( int $post_id, string $tier ): bool {
		$post_id = absint( $post_id );
		if ( $post_id <= 0 || ! in_array( $tier, self::ALLOWED_TIERS, true ) ) {
			return false;
		}
		if ( self::TIER_PUBLIC === $tier ) {
			delete_post_meta( $post_id, self::META_KEY );
			return true;
		}
		update_post_meta( $post_id, self::META_KEY, $tier );
		return true;
	}

	/**
	 * Decide whether the request headers authorize access for a post's tier.
	 *
	 * Returns true unconditionally for public posts, returns true for cited
	 * / premium posts only when the corresponding header is present, decodes
	 * to a valid JSON payload, post_id matches, exp is in the future, and
	 * the HMAC signature is valid.
	 *
	 * @param int                $post_id
	 * @param array<string,mixed> $headers Lowercase header map from WP_REST_Request::get_headers().
	 * @return bool
	 */
	public static function is_authorized( int $post_id, array $headers ): bool {
		$tier = self::tier_for_post( $post_id );
		if ( self::TIER_PUBLIC === $tier ) {
			return true;
		}
		$header_name  = self::TIER_CITED === $tier ? self::HEADER_CITATION_PROOF : self::HEADER_PREMIUM_RECEIPT;
		$header_value = self::extract_header( $headers, $header_name );
		if ( '' === $header_value ) {
			return false;
		}
		$payload = self::decode_token( $header_value );
		if ( null === $payload ) {
			return false;
		}
		if ( (int) ( $payload['post_id'] ?? 0 ) !== $post_id ) {
			return false;
		}
		if ( (int) ( $payload['exp'] ?? 0 ) < time() ) {
			return false;
		}
		$expected_sig = self::sign_payload( $payload, $post_id );
		if ( '' === $expected_sig ) {
			return false;
		}
		return hash_equals( $expected_sig, (string) ( $payload['sig'] ?? '' ) );
	}

	/**
	 * Mint a citation-proof token for a post. Used by the admin REST endpoint
	 * `POST /wp-json/wpwebmcp/v1/exposure/generate-proof` so admins can test
	 * the gate without hand-signing JSON.
	 *
	 * @param int    $post_id
	 * @param string $agent_slug Resolved agent slug (e.g. `gptbot`).
	 */
	public static function issue_citation_proof( int $post_id, string $agent_slug = 'unknown' ): ?string {
		$post_id = absint( $post_id );
		if ( $post_id <= 0 ) {
			return null;
		}
		$now   = time();
		$agent = sanitize_key( $agent_slug );
		if ( '' === $agent ) {
			$agent = 'unknown';
		}
		$payload = array(
			'post_id'    => $post_id,
			'agent_slug' => $agent,
			'issued_at'  => gmdate( 'c', $now ),
			'exp'        => $now + self::TOKEN_TTL_SECONDS[ self::TIER_CITED ],
		);
		$sig = self::sign_payload( $payload, $post_id );
		if ( '' === $sig ) {
			return null;
		}
		$payload['sig'] = $sig;
		return self::encode_token( $payload );
	}

	/**
	 * Mint a premium-receipt token for a post. For v1 the payment_id is
	 * accepted as-is from the admin (a future integration would substitute
	 * a verified Stripe / WooCommerce order id).
	 *
	 * @param int    $post_id
	 * @param string $payment_id Caller-supplied payment reference.
	 */
	public static function issue_premium_receipt( int $post_id, string $payment_id = '' ): ?string {
		$post_id = absint( $post_id );
		if ( $post_id <= 0 ) {
			return null;
		}
		$now = time();
		if ( '' === $payment_id ) {
			$payment_id = 'manual-' . bin2hex( random_bytes( 6 ) );
		} else {
			$payment_id = sanitize_text_field( $payment_id );
		}
		$payload = array(
			'post_id'    => $post_id,
			'payment_id' => $payment_id,
			'issued_at'  => gmdate( 'c', $now ),
			'exp'        => $now + self::TOKEN_TTL_SECONDS[ self::TIER_PREMIUM ],
		);
		$sig = self::sign_payload( $payload, $post_id );
		if ( '' === $sig ) {
			return null;
		}
		$payload['sig'] = $sig;
		return self::encode_token( $payload );
	}

	public static function allowed_tiers(): array {
		return self::ALLOWED_TIERS;
	}

	/**
	 * Extract a single header value from the REST-style headers map
	 * (which is `header_name => string|string[]`).
	 */
	private static function extract_header( array $headers, string $name ): string {
		if ( ! isset( $headers[ $name ] ) ) {
			return '';
		}
		$h = $headers[ $name ];
		return is_array( $h ) ? (string) ( $h[0] ?? '' ) : (string) $h;
	}

	/**
	 * Compute the HMAC-SHA256 signature over the canonical material.
	 *
	 * Canonical material: `post_id|agent_or_payment|issued_at|exp`. Including
	 * post_id binds the token to a single post. Including issued_at + exp
	 * binds it to a window. Including agent_or_payment binds it to the
	 * requesting agent / a specific payment so a leaked token can't be
	 * replayed by a different caller.
	 *
	 * @param array<string,mixed> $payload
	 */
	private static function sign_payload( array $payload, int $post_id ): string {
		$agent_or_payment = (string) ( $payload['agent_slug'] ?? $payload['payment_id'] ?? '' );
		if ( '' === $agent_or_payment ) {
			return '';
		}
		$material = $post_id . '|' . $agent_or_payment . '|' . (string) ( $payload['issued_at'] ?? '' ) . '|' . (int) ( $payload['exp'] ?? 0 );
		return hash_hmac( 'sha256', $material, self::secret() );
	}

	private static function encode_token( array $payload ): string {
		$json = wp_json_encode( $payload );
		if ( ! is_string( $json ) ) {
			return '';
		}
		return rtrim( strtr( base64_encode( $json ), '+/', '-_' ), '=' );
	}

	private static function decode_token( string $token ): ?array {
		$token = trim( $token );
		if ( '' === $token ) {
			return null;
		}
		$b64 = strtr( $token, '-_', '+/' );
		$pad = strlen( $b64 ) % 4;
		if ( 0 !== $pad ) {
			$b64 .= str_repeat( '=', 4 - $pad );
		}
		$json = base64_decode( $b64, true );
		if ( ! is_string( $json ) ) {
			return null;
		}
		$data = json_decode( $json, true );
		if ( ! is_array( $data ) ) {
			return null;
		}
		return $data;
	}
}
