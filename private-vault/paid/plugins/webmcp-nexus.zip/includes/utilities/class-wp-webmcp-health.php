<?php
/**
 * WordPress Site Health Integration — Doc §11.4.
 *
 * Integrates WebMCP Nexus diagnostics into the core WordPress Site Health tool
 * (Tools → Site Health), providing status checks for manifest reachability,
 * database schema integrity, and overall agent readiness score.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- health diagnostics run once per page load; `$placeholders` is built from hardcoded schema names
final class WP_WebMCP_Health {

	/**
	 * Initialize Site Health tests.
	 */
	public static function init(): void {
		WP_WebMCP_Loader::register_filter( 'site_status_tests', array( __CLASS__, 'register_tests' ) );
	}

	/**
	 * Register WebMCP tests into Site Health.
	 *
	 * @param array $tests Existing Site Health tests.
	 * @return array
	 */
	public static function register_tests( array $tests ): array {
		$tests['direct']['webmcp_manifest_accessible'] = array(
			'label' => __( 'WebMCP Manifest Status', 'webmcp-nexus' ),
			'test'  => array( __CLASS__, 'test_manifest' ),
		);

		$tests['direct']['webmcp_tables_present'] = array(
			'label' => __( 'WebMCP Database Tables', 'webmcp-nexus' ),
			'test'  => array( __CLASS__, 'test_tables' ),
		);

		$tests['direct']['webmcp_health_score'] = array(
			'label' => __( 'WebMCP Agent Readiness Score', 'webmcp-nexus' ),
			'test'  => array( __CLASS__, 'test_health_score' ),
		);

		return $tests;
	}

	/**
	 * Test 1: Verify manifest endpoint / schema generation.
	 */
	public static function test_manifest(): array {
		$result = array(
			'label'       => __( 'WebMCP agent manifest is generating properly', 'webmcp-nexus' ),
			'status'      => 'good',
			'badge'       => array(
				'label' => __( 'WebMCP', 'webmcp-nexus' ),
				'color' => 'blue',
			),
			'description' => sprintf(
				'<p>%s</p>',
				__( 'WebMCP Nexus generates a valid W3C WebMCP manifest for autonomous AI agents.', 'webmcp-nexus' )
			),
			'actions'     => '',
			'test'        => 'webmcp_manifest_accessible',
		);

		$enabled = (bool) get_option( 'wpwebmcp_enabled', true );
		if ( ! $enabled ) {
			$result['status']      = 'recommended';
			$result['label']       = __( 'WebMCP Nexus is currently disabled sitewide', 'webmcp-nexus' );
			$result['description'] = sprintf(
				'<p>%s</p>',
				__( 'The plugin is installed but WebMCP tool exposure is currently turned off in Settings.', 'webmcp-nexus' )
			);
			$result['actions']     = sprintf(
				'<p><a href="%s">%s</a></p>',
				esc_url( admin_url( 'admin.php?page=wp-webmcp-settings' ) ),
				__( 'Enable WebMCP Nexus', 'webmcp-nexus' )
			);
		}

		return $result;
	}

	/**
	 * Test 2: Database tables present.
	 */
	public static function test_tables(): array {
		global $wpdb;

		$tools_table = $wpdb->prefix . 'wpwebmcp_tools';
		$log_table   = $wpdb->prefix . 'wpwebmcp_log';
		$bot_table   = $wpdb->prefix . 'wpwebmcp_bot_log';

		$db_name = defined( 'DB_NAME' ) ? DB_NAME : (string) $wpdb->dbname;
		$found = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = %s AND table_name IN (%s, %s, %s)",
				$db_name,
				$tools_table,
				$log_table,
				$bot_table
			)
		);

		if ( 3 === $found ) {
			return array(
				'label'       => __( 'All WebMCP database tables exist', 'webmcp-nexus' ),
				'status'      => 'good',
				'badge'       => array(
					'label' => __( 'WebMCP', 'webmcp-nexus' ),
					'color' => 'blue',
				),
				'description' => sprintf(
					'<p>%s</p>',
					__( 'Custom tools, audit logging, and AI bot telemetry tables are all installed and active.', 'webmcp-nexus' )
				),
				'actions'     => '',
				'test'        => 'webmcp_tables_present',
			);
		}

		return array(
			'label'       => __( 'Some WebMCP database tables are missing', 'webmcp-nexus' ),
			'status'      => 'critical',
			'badge'       => array(
				'label' => __( 'WebMCP', 'webmcp-nexus' ),
				'color' => 'red',
			),
			'description' => sprintf(
				'<p>%s</p>',
				__( 'One or more required database tables were not created during activation.', 'webmcp-nexus' )
			),
			'actions'     => sprintf(
				'<p><a href="%s">%s</a></p>',
				esc_url( admin_url( 'admin.php?page=wp-webmcp-settings' ) ),
				__( 'Repair Database Tables', 'webmcp-nexus' )
			),
			'test'        => 'webmcp_tables_present',
		);
	}

	/**
	 * Test 3: Readiness score check.
	 */
	public static function test_health_score(): array {
		$score = class_exists( 'WP_WebMCP_Validator' )
			? (int) WP_WebMCP_Validator::calculate_health_score()
			: 100;

		if ( $score >= 80 ) {
			return array(
				'label'       => sprintf(
					/* translators: %d: score */
					__( 'WebMCP Agent Readiness Score: %d/100 (Optimal)', 'webmcp-nexus' ),
					$score
				),
				'status'      => 'good',
				'badge'       => array(
					'label' => __( 'WebMCP', 'webmcp-nexus' ),
					'color' => 'blue',
				),
				'description' => sprintf(
					'<p>%s</p>',
					__( 'Your site is fully optimized for discovery and interaction by AI agents.', 'webmcp-nexus' )
				),
				'actions'     => '',
				'test'        => 'webmcp_health_score',
			);
		}

		return array(
			'label'       => sprintf(
				/* translators: %d: score */
				__( 'WebMCP Agent Readiness Score: %d/100 (Improvements Recommended)', 'webmcp-nexus' ),
				$score
			),
			'status'      => 'recommended',
			'badge'       => array(
				'label' => __( 'WebMCP', 'webmcp-nexus' ),
				'color' => 'orange',
			),
			'description' => sprintf(
				'<p>%s</p>',
				__( 'Check the WebMCP Nexus Dashboard to see recommended security and configuration fixes.', 'webmcp-nexus' )
			),
			'actions'     => sprintf(
				'<p><a href="%s">%s</a></p>',
				esc_url( admin_url( 'admin.php?page=wp-webmcp' ) ),
				__( 'View WebMCP Dashboard', 'webmcp-nexus' )
			),
			'test'        => 'webmcp_health_score',
		);
	}

	/**
	 * Return the count of WebMCP tables currently present in the DB.
	 *
	 * Used by both the Site Health test and the REST /health endpoint so
	 * the same code path is exercised. Replaces the previous direct
	 * $wpdb query that lived in class-wp-webmcp-rest-tools.php.
	 *
	 * @return int Number of the 3 plugin tables found (0..3).
	 */
	public static function tables_present(): int {
		global $wpdb;
		$db_name    = defined( 'DB_NAME' ) ? DB_NAME : (string) $wpdb->dbname;
		$expected   = array(
			$wpdb->prefix . 'wpwebmcp_tools',
			$wpdb->prefix . 'wpwebmcp_log',
			$wpdb->prefix . 'wpwebmcp_bot_log',
		);
		$placeholders = implode( ',', array_fill( 0, count( $expected ), '%s' ) );
		$params       = array_merge( array( $db_name ), $expected );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
		$found = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = %s AND table_name IN ({$placeholders})",
				$params
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery
		return $found;
	}
// phpcs:enable WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}
