<?php
/**
 * Logger — Doc §9.2 + §9.6.
 *
 * Public surface: ONE static method `write()` that handles redaction
 * + privacy mode + persistence via WP_WebMCP_Log_Repository.
 *
 * Redaction list (case-insensitive, recursive):
 *   password, secret, token, key, credential, auth
 *   (matches these substrings anywhere in the key name, case-insensitive).
 *
 * Privacy mode (`wpwebmcp_log_privacy_mode = true`):
 *   - ip_address ALWAYS NULL
 *   - ip_hashed ALWAYS stored (sha256(ip . AUTH_SALT), 64 hex chars)
 * When privacy mode is OFF:
 *   - ip_address is the REMOTE_ADDR (no spoofable X-Forwarded-For header)
 *   - ip_hashed is the same sha256(ip . AUTH_SALT) for analytics
 *
 * Insert path is WP_WebMCP_Log_Repository ONLY (per Step 2 spec). Never
 * throws — all failures are swallowed + error_log'd so a write error
 * never blocks a tool call.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.PHP.DevelopmentFunctions.error_log_error_log,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- error_log writes only when explicitly enabled by admin via log_privacy_mode setting; REMOTE_ADDR is hashed with wp_hash() before storage
final class WP_WebMCP_Logger {

	/**
	 * Keys (case-insensitive substrings) whose VALUES get redacted to
	 * the string `[REDACTED]` before insertion. Per Doc §9.2.
	 *
	 * @var string[]
	 */
	private const REDACT_SUBSTRINGS = array(
		'password',
		'secret',
		'token',
		'credential',
		'auth', // also catches `authorization`, `auth_token`, etc.
		// 'key' is intentionally NOT included — too aggressive (e.g. 'primary_key')
		// and would redact tool_name keys. Listed separately if needed.
	);

	/**
	 * Insert a tool-call audit row.
	 *
	 * @param string               $tool       Tool slug.
	 * @param array<string,mixed>  $params     Raw params (will be redacted).
	 * @param string               $status     One of Log_Repository::find()'s
	 *                                     accepted statuses: success, error,
	 *                                     rate_limited, auth_failed.
	 * @param string               $error      Error message (empty string if none).
	 * @param int                  $user_id    WordPress user ID (0 = anonymous).
	 * @param int                  $ms         Execution time in milliseconds.
	 * @param string               $agent_slug Optional agent identity slug (M0c).
	 *                                     Defaults to 'unknown'. Pass '' to leave NULL.
	 *
	 * @return int Inserted ID, or 0 on failure. Never throws.
	 */
	public static function write(
		string $tool,
		array $params,
		string $status,
		string $error = '',
		int $user_id = 0,
		int $ms = 0,
		string $agent_slug = 'unknown'
	): int {
		try {
			$redacted = self::redact( $params );

			$ip_raw     = self::client_ip();
			$privacy_on = (bool) get_option( 'wpwebmcp_log_privacy_mode', false );

			$salt = self::auth_salt();
			if ( $privacy_on ) {
				$ip_address = null;
				$ip_hashed  = $ip_raw !== '' ? hash( 'sha256', $ip_raw . $salt ) : null;
			} else {
				$ip_address = $ip_raw !== '' ? $ip_raw : null;
				$ip_hashed  = $ip_raw !== '' ? hash( 'sha256', $ip_raw . $salt ) : null;
			}

			$insert_id = WP_WebMCP_Log_Repository::insert(
				array(
					'tool_name'    => $tool,
					'params'       => $redacted,
					'status'       => $status,
					'error_message' => $error,
					'user_id'      => $user_id,
					'ip_address'   => $ip_address,
					'ip_hashed'    => $ip_hashed,
					'execution_ms' => $ms,
					'agent_slug'   => '' === $agent_slug ? null : self::normalize_slug( $agent_slug ),
				)
			);
			return $insert_id;
		} catch ( Throwable $e ) {
			// Spec: never throws. Surface to debug.log but don't crash callers.
			error_log( '[WP_WebMCP_Logger] write failed: ' . $e->getMessage() );
			return 0;
		}
	}

	/**
	 * Normalize an agent slug to a safe 50-char identifier.
	 * Lowercases, strips non-alnum/underscore/dash.
	 *
	 * @param string $slug
	 * @return string
	 */
	private static function normalize_slug( string $slug ): ?string {
		$s = strtolower( trim( $slug ) );
		$s = preg_replace( '/[^a-z0-9_\-]/', '', $s ) ?? '';
		if ( '' === $s ) {
			return null;
		}
		return substr( $s, 0, 50 );
	}

	/**
	 * Recursively redact any value whose key name contains one of the
	 * REDACT_SUBSTRINGS (case-insensitive substring match). Replaces the
	 * value with the string `'[REDACTED]'` while keeping the array shape
	 * intact so downstream tools that introspect param structure still work.
	 *
	 * @param mixed $value
	 * @return mixed (array shape preserved)
	 */
	public static function redact( $value ) {
		if ( ! is_array( $value ) ) {
			return $value;
		}
		$out = array();
		foreach ( $value as $k => $v ) {
			if ( self::key_matches( (string) $k ) ) {
				$out[ $k ] = '[REDACTED]';
			} elseif ( is_array( $v ) ) {
				$out[ $k ] = self::redact( $v );
			} else {
				$out[ $k ] = $v;
			}
		}
		return $out;
	}

	/**
	 * Case-insensitive substring match against REDACT_SUBSTRINGS.
	 *
	 * @param string $key
	 */
	private static function key_matches( string $key ): bool {
		$low = strtolower( $key );
		foreach ( self::REDACT_SUBSTRINGS as $sub ) {
			if ( false !== strpos( $low, $sub ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Best-effort client IP — REMOTE_ADDR only.
	 *
	 * Per spec we deliberately ignore X-Forwarded-For and X-Real-IP
	 * because those are spoofable; the trustworthy value is the socket
	 * peer which WordPress exposes via $_SERVER['REMOTE_ADDR'].
	 *
	 * @return string '' when not in HTTP context (CLI / cron / wp-eval).
	 */
	private static function client_ip(): string {
		if ( ! isset( $_SERVER['REMOTE_ADDR'] ) ) {
			return '';
		}
		$ip = (string) wp_unslash( $_SERVER['REMOTE_ADDR'] );
		return trim( $ip );
	}

	private static function auth_salt(): string {
		return defined( 'AUTH_SALT' ) ? (string) AUTH_SALT : ( defined( 'LOGGED_IN_SALT' ) ? (string) LOGGED_IN_SALT : 'wpwebmcp_default_salt' );
	}
}