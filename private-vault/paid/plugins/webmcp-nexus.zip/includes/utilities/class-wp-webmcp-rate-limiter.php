<?php
/**
 * Rate Limiter — Doc §9.3 (object-cache-safe, fixes SP-1).
 *
 * Public surface: ONE static method `check_limit( string $slug ): bool`
 * that consults the configured read/write limits and returns false
 * once a caller exceeds the per-minute window.
 *
 * Storage strategy (dual path, per spec):
 *   - If `wp_using_ext_object_cache()` is true (Redis/Memcached):
 *       wp_cache_get/add → wp_cache_incr with 60 s expiration.
 *   - Otherwise (DB fallback, atomic):
 *       transients keyed `wpwm_rl_*` with 60 s TTL.
 *
 * Key format: `wpwm_rl_{slug}_{iphash16}` where iphash16 is the first
 * 16 hex chars of sha256(ip . AUTH_SALT). Two callers behind the same
 * NAT share the same bucket — intentional.
 *
 * Over-limit path:
 *   1. Log the failure via WP_WebMCP_Logger (status=rate_limited).
 *   2. Fire `wpwebmcp_rate_limit_exceeded` action.
 *   3. If WP_WebMCP_Alerts exists, defer to it. (Class lands Step 13.)
 *   4. Return false.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.Security.ValidatedSanitizedInput.MissingUnslash,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.PHP.DevelopmentFunctions.error_log_error_log -- rate limiter must read real-time counts; `$table` is hardcoded `$wpdb->options` literal
final class WP_WebMCP_Rate_Limiter {

	/**
	 * Window length per Doc §9.3 (60 seconds).
	 */
	private const WINDOW_SECONDS = 60;

	/**
	 * Built-in write tool slugs (Doc Part 8). Custom rows with
	 * `tool_type=write` are added at runtime via the option.
	 *
	 * @var string[]
	 */
	private const WRITE_BUILTIN = array(
		// Woo write tools (always write when present).
		'addToCart',
		'updateQuantity',
		'removeItem',
		'applyCoupon',
		// No built-in non-Woo write tools at this stage. Custom rows are
		// added via the option in is_write_tool() below.
	);

	/**
	 * Check whether `$slug` is allowed to run for the current caller
	 * under the configured rate limit.
	 *
	 * @param string $slug Tool slug to check.
	 * @return bool True if within the limit, false if exceeded.
	 */
	public static function check_limit( string $slug ): bool {
		$limit = self::limit_for( $slug );
		if ( $limit <= 0 ) {
			// 0 (or missing) = disabled, never block.
			return true;
		}
		$key  = self::key_for( $slug );
		$calls = self::incr( $key );

		if ( $calls > $limit ) {
			self::on_limit_exceeded( $slug, $calls, $limit );
			return false;
		}
		return true;
	}

	/**
	 * Check the per-agent rate limit (M0c).
	 *
	 * Each agent has its own bucket key (`wpwm_rl_agent_<slug>_<iphash16>`)
	 * so a noisy GPTBot cannot exhaust budget for a polite ClaudeBot. Falls
	 * back to the global limit when the agent's per-minute setting is 0
	 * (interpreted as "no override, use global"). Returns true (= pass) when
	 * identity resolution is disabled at the site level.
	 *
	 * @param string $slug       Tool slug (for over-limit telemetry).
	 * @param string $agent_slug Resolved agent identity slug (or 'unknown').
	 * @param int|null $limit_override Optional explicit limit (used by A2a policy
	 *                                rate-limit buckets). When null, falls back
	 *                                to the per-agent override option.
	 * @return bool True if within the per-agent limit.
	 */
	public static function check_limit_for_agent( string $slug, string $agent_slug, ?int $limit_override = null ): bool {
		if ( ! (bool) get_option( 'wpwebmcp_agent_identity_enabled', true ) ) {
			return true;
		}
		$limit = null !== $limit_override ? (int) $limit_override : self::per_agent_limit( $agent_slug );
		if ( $limit <= 0 ) {
			// No override configured → defer to the global check.
			return true;
		}
		$bucket_key = self::per_agent_key( $agent_slug );
		$calls      = self::incr( $bucket_key );

		if ( $calls > $limit ) {
			/**
			 * Fires when a per-agent rate limit is exceeded (M0c).
			 *
			 * @param string $slug       Tool slug.
			 * @param string $agent_slug Resolved agent slug.
			 * @param int    $calls      Call count in this window.
			 * @param int    $limit      Configured per-agent limit.
			 */
			do_action( 'wpwebmcp_agent_rate_limit_exceeded', $slug, $agent_slug, $calls, $limit );
			return false;
		}
		return true;
	}

	/**
	 * Resolve the per-agent override limit. 0 = no override.
	 *
	 * @param string $agent_slug
	 * @return int
	 */
	public static function per_agent_limit( string $agent_slug ): int {
		$settings = get_option( 'wpwebmcp_agent_settings', array() );
		if ( ! is_array( $settings ) || empty( $settings[ $agent_slug ] ) ) {
			return 0;
		}
		$row = $settings[ $agent_slug ];
		if ( ! is_array( $row ) ) {
			return 0;
		}
		if ( isset( $row['enabled'] ) && ! (bool) $row['enabled'] ) {
			// Admin explicitly disabled this agent: deny every call.
			return -1;
		}
		return isset( $row['per_minute_limit'] ) ? max( 0, (int) $row['per_minute_limit'] ) : 0;
	}

	/**
	 * Whether the agent is allowed at all (admin toggled enabled=true).
	 *
	 * @param string $agent_slug
	 * @return bool True if no override exists OR the override is enabled.
	 */
	public static function agent_allowed( string $agent_slug ): bool {
		$settings = get_option( 'wpwebmcp_agent_settings', array() );
		if ( ! is_array( $settings ) || ! isset( $settings[ $agent_slug ] ) ) {
			return true;
		}
		$row = $settings[ $agent_slug ];
		return is_array( $row ) ? (bool) ( $row['enabled'] ?? true ) : true;
	}

	/**
	 * Resolve the limit for a tool. Write tools use the write limit;
	 * everything else uses the read limit.
	 */
	private static function limit_for( string $slug ): int {
		$read  = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$write = (int) get_option( 'wpwebmcp_rate_limit_write', 20 );
		return self::is_write_tool( $slug ) ? $write : $read;
	}

	/**
	 * Build the per-agent bucket key.
	 */
	private static function per_agent_key( string $agent_slug ): string {
		$salt   = defined( 'AUTH_SALT' ) ? (string) AUTH_SALT : ( defined( 'LOGGED_IN_SALT' ) ? (string) LOGGED_IN_SALT : 'wpwebmcp_default_salt' );
		$iphash = substr( hash( 'sha256', self::ip() . $salt ), 0, 16 );
		$clean  = preg_replace( '/[^a-z0-9_\-]/', '', strtolower( $agent_slug ) ) ?? '';
		return 'wpwm_rl_agent_' . $clean . '_' . $iphash;
	}

	/**
	 * Whether the given tool slug is a write tool.
	 *
	 * Combines the built-in write list (Doc Part 8) with custom tool
	 * rows whose `tool_type=write` (from WP_WebMCP_Tool_Repository).
	 */
	public static function is_write_tool( string $slug ): bool {
		if ( in_array( $slug, self::WRITE_BUILTIN, true ) ) {
			return true;
		}
		if ( class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			$row = WP_WebMCP_Tool_Repository::find_by_slug( $slug );
			if ( $row && isset( $row['tool_type'] ) && 'write' === (string) $row['tool_type'] ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Atomic increment of the per-window counter.
	 *
	 * Returns the NEW count (after increment).
	 */
	private static function incr( string $key ): int {
		if ( function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache() ) {
			// Object cache path.
			if ( false === wp_cache_get( $key, 'wpwebmcp' ) ) {
				wp_cache_add( $key, 0, 'wpwebmcp', self::WINDOW_SECONDS );
			}
			$new = wp_cache_incr( $key, 1, 'wpwebmcp' );
			if ( false === $new ) {
				// Cache backend didn't increment; fall through to SQL.
				return self::sql_incr( $key );
			}
			return (int) $new;
		}
		// Transient + atomic SQL path.
		return self::sql_incr( $key );
	}

	/**
	 * Atomic SQL increment using a prepared UPDATE on the options table.
	 *
	 * Strategy: store the counter as a `transient` via set_transient
	 * with the same `wpwm_rl_*` key. The transient stores in `wp_options`
	 * with autoload=no (transient default). To make the increment atomic
	 * we use a single prepared UPDATE with `option_value + 1` (guarded
	 * by the existing key) — never `get_transient + set_transient`
	 * (race condition under concurrent calls).
	 *
	 * Returns the NEW count (after increment).
	 */
	private static function sql_incr( string $key ): int {
		global $wpdb;
		$table   = $wpdb->options;
		$opt_key = '_transient_' . $key;
		$now     = time();

		// 1. Ensure the transient row exists with a starting value.
		$existing = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT option_value FROM {$table} WHERE option_name = %s LIMIT 1",
				$opt_key
			)
		);
		if ( ! $existing ) {
			// wpdb->insert ignores $format by default; escape manually.
			$exp = $now + self::WINDOW_SECONDS;
			$wpdb->query(
				$wpdb->prepare(
					"INSERT IGNORE INTO {$table} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
					$opt_key,
					'1'
				)
			);
			return 1;
		}

		// 2. Atomic increment (prepared, no placeholders for the math).
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- atomic update; prepared.
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET option_value = (option_value + 1) WHERE option_name = %s",
				$opt_key
			)
		);

		$new = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT option_value FROM {$table} WHERE option_name = %s LIMIT 1",
				$opt_key
			)
		);
		return max( 1, $new );
	}

	/**
	 * Build the per-(slug, ip) bucket key.
	 *
	 * @return string `wpwm_rl_<slug>_<iphash16>`.
	 */
	private static function key_for( string $slug ): string {
		$salt   = defined( 'AUTH_SALT' ) ? (string) AUTH_SALT : ( defined( 'LOGGED_IN_SALT' ) ? (string) LOGGED_IN_SALT : 'wpwebmcp_default_salt' );
		$iphash = substr( hash( 'sha256', self::ip() . $salt ), 0, 16 );
		// sanitize_key allows alnum + underscore + dash; collapse slug to
		// the same alphabet.
		$clean_slug = sanitize_key( $slug );
		return 'wpwm_rl_' . $clean_slug . '_' . $iphash;
	}

	/**
	 * Trusted client IP — REMOTE_ADDR only, no spoofable headers.
	 *
	 * @return string '' when not in HTTP context (CLI / cron / wp-eval).
	 */
	private static function ip(): string {
		if ( ! isset( $_SERVER['REMOTE_ADDR'] ) ) {
			return '';
		}
		return trim( (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
	}

	/**
	 * Hook for over-limit responses. Logs the failure, fires the action,
	 * defers to WP_WebMCP_Alerts if the class exists (Step 13 lands that).
	 */
	private static function on_limit_exceeded( string $slug, int $calls, int $limit ): void {
		if ( class_exists( 'WP_WebMCP_Logger' ) ) {
			WP_WebMCP_Logger::write(
				$slug,
				array( 'calls' => $calls, 'limit' => $limit ),
				'rate_limited',
				__( 'Rate limit exceeded.', 'webmcp-nexus' ),
				get_current_user_id(),
				0
			);
		}
		/**
		 * Fires when a tool call exceeds the rate limit.
		 *
		 * @param string $slug
		 * @param int    $calls
		 * @param int    $limit
		 */
		do_action( 'wpwebmcp_rate_limit_exceeded', $slug, $calls, $limit );

		if ( class_exists( 'WP_WebMCP_Alerts' ) ) {
			try {
				$alerts = new WP_WebMCP_Alerts();
				if ( method_exists( $alerts, 'send_rate_limit_alert' ) ) {
					$alerts->send_rate_limit_alert( $slug, $calls, $limit );
				}
			} catch ( Throwable $e ) {
				// Alerts is best-effort; never break the caller.
				error_log( '[WP_WebMCP_Rate_Limiter] alerts hook failed: ' . $e->getMessage() );
			}
		}
	}
}