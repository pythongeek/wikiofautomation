<?php
/**
 * Sanitizer — Doc §9.1 + §9.5 + Step 12.
 *
 * Two responsibilities:
 *
 *   1. Output payload cleaning  (clean_result) — strips null bytes,
 *      sanitizes array keys via sanitize_key, and walks nested arrays
 *      recursively. Wired into the call pipeline at
 *      class-wp-webmcp-rest-tools.php via class_exists guard.
 *
 *   2. Prompt-injection sanitization (clean_text) — applies the 8
 *      regex patterns mandated by Doc §9.5 to any user-supplied string
 *      before it is returned to an AI agent. Replacement token is
 *      "[content removed by safety filter]". Patterns are append-only
 *      and filterable via wpwebmcp_sanitizer_patterns.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.PHP.DevelopmentFunctions.prevent_path_disclosure_error_reporting,WordPress.PHP.DevelopmentFunctions.error_log_error_log -- error_reporting/error_log calls are admin-triggered debug instrumentation; production logs go through WP_WebMCP_Logger
final class WP_WebMCP_Sanitizer {

	/**
	 * Replacement token used when a prompt-injection match is redacted.
	 */
	public const REDACTED_TOKEN = '[content removed by safety filter]';

	/**
	 * 8 prompt-injection pattern classes per Doc §9.5.
	 *
	 * Each entry is [ label, regex ]. All are case-insensitive. The
	 * `s` flag is used so the dot matches newlines (multi-line attacks).
	 *
	 * Append-only — never delete a pattern, only add new ones at the end.
	 * The list is filterable via wpwebmcp_sanitizer_patterns so plugin
	 * authors can extend (not weaken) the set.
	 *
	 * @return array<int, array{0:string,1:string}>
	 */
	public static function patterns(): array {
		$default = array(
			// 1. "ignore previous instructions" / "forget everything above".
			array(
				'ignore_previous',
				'/(?:ignore|disregard|forget|skip|override|bypass)\b[^.\n]{0,80}\b(?:all|any|previous|prior|above|preceding|earlier|past)\b[^.\n]{0,80}\b(?:instructions?|directives?|prompts?|rules?|context|messages?|commands?)/is',
			),
			// 2. System-prompt markers (e.g. <<<SYS>>>, <|system|>, [INST]).
			array(
				'system_marker',
				'/<\|\s*(?:system|system_prompt|system-message|im_start|endoftext)\s*\|>|<<<\s*SYS\s*>>>|\[INST\]|\[\/INST\]|<\|im_start\|>|<\|im_end\|>|###\s*(?:System|Assistant)\s*:/is',
			),
			// 3. Role hijack ("you are now ...", "act as ...").
			array(
				'role_hijack',
				'/\b(?:you\s+are\s+now|act\s+as|pretend\s+to\s+be|behave\s+as|roleplay\s+as|from\s+now\s+on\s+you\s+are|your\s+new\s+role\s+is)\b[^.\n]{0,120}/is',
			),
			// 4. DAN / jailbreak tokens.
			array(
				'jailbreak',
				'/\b(?:DAN|do\s+anything\s+now|jailbreak|jailbroken|developer\s+mode|god\s+mode|sudo\s+mode|unfiltered\s+mode|no\s+restrictions?)\b[^.\n]{0,80}/is',
			),
			// 5. Hidden instruction tags (<system>, <assistant>, <human>, <|...|>).
			//    Capture group (round parens) on the alternation so the \1 backref is valid.
			array(
				'hidden_tags',
				'/<\s*(system|assistant|human|user|prompt|instructions?|directive|secret|hidden|admin_only)\s*>[^<]*<\s*\/\s*\1\s*>|<\s*\|[^>|]{1,40}\|\s*>/is',
			),
			// 6. Base64-instruction blobs (≥40 base64 chars in a row).
			array(
				'base64_blob',
				'/\b[A-Za-z0-9+\/]{40,}={0,2}\b/',
			),
			// 7. Excessive zero-width / invisible chars (≥6 in a row).
			array(
				'zero_width',
				'/[\x{200B}\x{200C}\x{200D}\x{2060}\x{FEFF}]{6,}/u',
			),
			// 8. Markdown HTML-comment directives (<!-- do X -->).
			array(
				'md_comment_directive',
				'/<!--\s*(?:ignore|delete|reveal|exfiltrate|override|execute|run|call|send|post|delete|drop|truncate|update|wipe|reset|admin|system|root|sudo|password|secret|api[_-]?key|token)\b[^>]*-->/is',
			),
		);

		/**
		 * Filter the active prompt-injection patterns.
		 *
		 * Receives the default 8-tuple list; must return the same shape.
		 * Plugins may append additional tuples but MUST NOT remove
		 * existing ones (defence-in-depth principle).
		 *
		 * @param array<int, array{0:string,1:string}> $default
		 */
		return (array) apply_filters( 'wpwebmcp_sanitizer_patterns', $default );
	}

	/**
	 * Clean a tool execution result array recursively.
	 *
	 *   - null bytes stripped from strings
	 *   - array keys passed through sanitize_key
	 *   - non-string / non-array scalars pass through unchanged
	 *   - Module A1a: when a citation class is loaded, attaches a
	 *     deduplicated `citations` block at the top level. No DB hits
	 *     are made unless the payload contains at least one post id.
	 *   - Module A2b: when the post is in a cited / premium tier,
	 *     `request_headers` carries the matching signed token; without
	 *     it the citation is withheld silently.
	 *
	 * Backwards-compatible with the original signature so the call
	 * pipeline at class-wp-webmcp-rest-tools.php keeps working.
	 *
	 * @param array<string,mixed>  $data             Output payload.
	 * @param array<string,mixed>  $request_headers  Optional REST headers map;
	 *                                                threaded through to
	 *                                                Citation::decorate.
	 * @return array<string,mixed>
	 */
	public static function clean_result( array $data, array $request_headers = array() ): array {
		$clean = array();
		foreach ( $data as $k => $v ) {
			$clean_key = is_string( $k ) ? sanitize_key( $k ) : $k;
			if ( is_array( $v ) ) {
				$clean[ $clean_key ] = self::clean_result( $v, $request_headers );
			} elseif ( is_string( $v ) ) {
				$clean[ $clean_key ] = self::clean_text( $v );
			} else {
				$clean[ $clean_key ] = $v;
			}
		}
		// A1a citation layer: only runs when the Citation class is loaded
		// AND the payload contains a recognizable post id. Cheap guard
		// so non-post tools (getSiteInfo, searchSite, etc.) pay nothing.
		if ( class_exists( 'WP_WebMCP_Citation' ) && self::payload_has_id( $clean ) ) {
			$clean = WP_WebMCP_Citation::decorate( $clean, $request_headers );
		}
		return $clean;
	}

	/**
	 * Cheap structural check: does this payload contain any integer
	 * `id` / `*_id` value? Avoids a deeper recursion when the answer
	 * is obviously no.
	 *
	 * @param array<string,mixed> $data
	 */
	private static function payload_has_id( array $data ): bool {
		foreach ( $data as $k => $v ) {
			if ( is_array( $v ) ) {
				if ( self::payload_has_id( $v ) ) {
					return true;
				}
				continue;
			}
			if ( ! is_string( $k ) ) {
				continue;
			}
			$lower = strtolower( $k );
			if ( 'id' === $lower || str_ends_with( $lower, '_id' ) ) {
				if ( is_numeric( $v ) && (int) $v > 0 ) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Sanitize a single string. Strips null bytes and applies the
	 * 8 prompt-injection patterns from patterns().
	 *
	 * Defensive: if a pattern fails to compile (returns null from
	 * preg_replace), the original text is kept for that step so a
	 * single broken pattern can never wipe out the entire payload.
	 *
	 * @param string $text Raw string.
	 * @return string Sanitized string.
	 */
	public static function clean_text( string $text ): string {
		if ( '' === $text ) {
			return $text;
		}
		// Drop null bytes first (cheap, always).
		$text = str_replace( "\0", '', $text );

		foreach ( self::patterns() as $tuple ) {
			if ( ! is_array( $tuple ) || count( $tuple ) < 2 ) {
				continue;
			}
			$pattern = (string) $tuple[1];
			if ( '' === $pattern ) {
				continue;
			}
			// Surface compile errors to the PHP error log; keep the
			// original $text instead of casting null to "".
			// error_reporting() disabled - full path disclosure risk.

			// $previous = error_reporting( E_ALL );

			$previous = error_reporting();  // phpcs:ignore PluginCheck.CodeAnalysis.PHPErrorReporting.DirectErrorReportingCall
			$replaced = @preg_replace( $pattern, self::REDACTED_TOKEN, $text );
			// error_reporting( $previous );  // phpcs:ignore PluginCheck.CodeAnalysis.PHPErrorReporting.DirectErrorReportingCall
			if ( null !== $replaced ) {
				$text = $replaced;
			} else {
				error_log( '[WP_WebMCP_Sanitizer] Pattern "' . (string) ( $tuple[0] ?? 'unknown' ) . '" failed to compile; skipping. Pattern: ' . $pattern );
			}
		}
		return $text;
	}
// phpcs:enable WordPress.PHP.DevelopmentFunctions.prevent_path_disclosure_error_reporting,WordPress.PHP.DevelopmentFunctions.error_log_error_log
}
