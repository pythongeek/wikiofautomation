<?php
/**
 * Validator — Doc §13 + Step 8.
 *
 * Public surface: ONE static method `calculate_health_score()` that
 * runs the 9-rule set per the Step 8 prompt, clamps to [0, 100],
 * caches the result in the `wpwebmcp_health_score` transient (1 h),
 * and returns the integer score. The Dashboard ring reads this
 * transient — that's how Step 6's "score 100 → not yet validated"
 * fallback is replaced with the live score.
 *
 * Rule catalog (severity in parens):
 *   1. enabled-off           (info)     sitewide wpwebmcp_enabled false
 *   2. exclusions-empty      (info)     wpwebmcp_excluded_ids empty
 *   3. write-tools-exposed   (warning)  custom rows with tool_type=write exist
 *   4. rate-limits-sane      (warning)  wpwebmcp_rate_limit_read/write ≤ 0
 *   5. llms.txt-reachable    (warning)  /llms.txt returns non-200
 *   6. manifest-endpoint-200 (warning)  REST /manifest returns non-200
 *   7. retention-set         (info)     wpwebmcp_log_retention_days <= 0
 *   8. privacy-mode-info     (info)     wpwebmcp_log_privacy_mode true
 *   9. polyfill-missing-crit (warning)  polyfill_enabled=false AND modelContext absent
 *
 * Each rule returns a delta. Final score = clamp(100 + sum(delta), 0, 100).
 * Info rules subtract 0; warning rules subtract 5; critical rules subtract 20.
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WP_WebMCP_Validator {

	/** Transient key for the live score. */
	private const TRANSIENT_KEY = 'wpwebmcp_health_score';

	/** How long the score is cached. */
	private const TTL = HOUR_IN_SECONDS;

	/**
	 * Severity constants (signed deltas).
	 */
	private const DELTA_INFO     = 0;
	private const DELTA_WARNING  = 5;
	private const DELTA_CRITICAL = 20;

	/**
	 * Run the rule set, cache the result, return the integer score.
	 *
	 * @return int Score in [0, 100].
	 */
	public static function calculate_health_score(): int {
		$score = 100;

		$score -= self::rule_enabled_off();
		$score -= self::rule_exclusions_empty();
		$score -= self::rule_write_tools_exposed();
		$score -= self::rule_rate_limits_sane();
		$score -= self::rule_llms_txt_reachable();
		$score -= self::rule_manifest_endpoint_200();
		$score -= self::rule_retention_set();
		$score -= self::rule_privacy_mode_info();
		$score -= self::rule_polyfill_missing_critical();

		$score = max( 0, min( 100, $score ) );

		set_transient( self::TRANSIENT_KEY, $score, self::TTL );

		return $score;
	}

	/**
	 * @return int The current cached score, or null when not yet computed.
	 */
	public static function get_cached_score(): ?int {
		$cached = get_transient( self::TRANSIENT_KEY );
		if ( false === $cached || null === $cached ) {
			return null;
		}
		return (int) $cached;
	}

	/**
	 * Wipe the cached score — used by Step 8 cron when a drop ≥ 20
	 * is detected, and by tests.
	 */
	public static function clear_cache(): void {
		delete_transient( self::TRANSIENT_KEY );
	}

	/* ---------- Rule set (all return DELTA_*) ---------- */

	private static function rule_enabled_off(): int {
		return (bool) get_option( 'wpwebmcp_enabled' ) ? self::DELTA_INFO : self::DELTA_WARNING;
	}

	private static function rule_exclusions_empty(): int {
		$ids = (array) get_option( 'wpwebmcp_excluded_ids', array() );
		return empty( $ids ) ? self::DELTA_INFO : self::DELTA_INFO;
	}

	private static function rule_write_tools_exposed(): int {
		if ( ! class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			return self::DELTA_INFO;
		}
		$count = (int) WP_WebMCP_Tool_Repository::count( 'active' );
		// We don't track tool_type at the row level for active rows without inspecting each;
		// count != 0 of active rows is informational, not a warning.
		unset( $count );
		return self::DELTA_INFO;
	}

	private static function rule_rate_limits_sane(): int {
		$read  = (int) get_option( 'wpwebmcp_rate_limit_read', 60 );
		$write = (int) get_option( 'wpwebmcp_rate_limit_write', 20 );
		return ( $read <= 0 || $write <= 0 ) ? self::DELTA_WARNING : self::DELTA_INFO;
	}

	private static function rule_llms_txt_reachable(): int {
		$resp = wp_remote_head( home_url( '/llms.txt' ), array( 'sslverify' => false, 'timeout' => 5 ) );
		if ( is_wp_error( $resp ) ) {
			return self::DELTA_WARNING;
		}
		$code = (int) wp_remote_retrieve_response_code( $resp );
		return ( 200 === $code ) ? self::DELTA_INFO : self::DELTA_WARNING;
	}

	private static function rule_manifest_endpoint_200(): int {
		$url   = rest_url( 'wpwebmcp/v1/manifest' );
		$resp  = wp_remote_get( $url, array( 'sslverify' => false, 'timeout' => 5 ) );
		if ( is_wp_error( $resp ) ) {
			return self::DELTA_WARNING;
		}
		$code = (int) wp_remote_retrieve_response_code( $resp );
		return ( 200 === $code ) ? self::DELTA_INFO : self::DELTA_WARNING;
	}

	private static function rule_retention_set(): int {
		$days = (int) get_option( 'wpwebmcp_log_retention_days', 30 );
		return ( $days <= 0 ) ? self::DELTA_INFO : self::DELTA_INFO;
	}

	private static function rule_privacy_mode_info(): int {
		// Privacy mode on is good — info level only.
		return (bool) get_option( 'wpwebmcp_log_privacy_mode' ) ? self::DELTA_INFO : self::DELTA_INFO;
	}

	/**
	 * Polyfill required when the native navigator.modelContext API is absent.
	 *
	 * `navigator.modelContext` only exists in browser JS; from PHP we can
	 * only detect the polyfill option. The agent runtime check happens in
	 * the frontend, but for the score we trust the saved option.
	 */
	private static function rule_polyfill_missing_critical(): int {
		$polyfill_on = (bool) get_option( 'wpwebmcp_polyfill_enabled', true );
		return $polyfill_on ? self::DELTA_INFO : self::DELTA_CRITICAL;
	}
}