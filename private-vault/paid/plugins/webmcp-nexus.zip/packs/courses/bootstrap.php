<?php
/**
 * Courses & Online Learning Pack Bootstrap.
 *
 * Provides a dedicated course CPT, course_category & course_level taxonomies,
 * 5 seed courses, and 5 MCP tools callable by AI agents.
 *
 * @package WP_WebMCP_Pack_Courses
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.SlowDBQuery -- Pack tool queries require meta_query and tax_query for domain-specific filtering.
final class WP_WebMCP_Pack_Courses {

	public const POST_TYPE    = 'course';
	public const TAX_CATEGORY = 'course_category';
	public const TAX_LEVEL    = 'course_level';
	public const SLUG         = 'courses';
	public const VERSION      = '1.0.0';

	public static function instance(): self {
		static $inst = null;
		if ( null === $inst ) {
			$inst = new self();
		}
		return $inst;
	}

	public static function boot(): void {
		add_action( 'init', array( self::class, 'register_post_type' ), 9 );
		add_filter( 'wpwebmcp_pack_runner_courses', array( self::class, 'run_tool' ), 10, 3 );
	}

	public static function register_post_type(): void {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'        => array(
					'name'          => __( 'Courses', 'webmcp-nexus' ),
					'singular_name' => __( 'Course', 'webmcp-nexus' ),
					'add_new_item'  => __( 'Add New Course', 'webmcp-nexus' ),
					'edit_item'     => __( 'Edit Course', 'webmcp-nexus' ),
				),
				'public'        => true,
				'show_in_rest'  => true,
				'has_archive'   => true,
				'menu_icon'     => 'dashicons-welcome-learn-more',
				'menu_position' => 10,
				'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'custom-fields' ),
				'rewrite'       => array( 'slug' => 'courses' ),
			)
		);

		register_taxonomy(
			self::TAX_CATEGORY,
			array( self::POST_TYPE ),
			array(
				'labels'       => array(
					'name'          => __( 'Course Categories', 'webmcp-nexus' ),
					'singular_name' => __( 'Course Category', 'webmcp-nexus' ),
				),
				'public'       => true,
				'hierarchical' => true,
				'show_in_rest' => true,
				'rewrite'      => array( 'slug' => 'course-category' ),
			)
		);

		register_taxonomy(
			self::TAX_LEVEL,
			array( self::POST_TYPE ),
			array(
				'labels'       => array(
					'name'          => __( 'Difficulty Levels', 'webmcp-nexus' ),
					'singular_name' => __( 'Difficulty Level', 'webmcp-nexus' ),
				),
				'public'       => true,
				'hierarchical' => false,
				'show_in_rest' => true,
				'rewrite'      => array( 'slug' => 'course-level' ),
			)
		);
	}

	public static function install( array $manifest ) {
		self::register_post_type();

		$existing = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => array( 'publish', 'draft' ),
				'posts_per_page' => 1,
				'fields'         => 'ids',
			)
		);
		if ( empty( $existing ) ) {
			self::seed_example_courses();
		}

		foreach ( (array) ( $manifest['tools'] ?? array() ) as $tool ) {
			self::register_tool_row( $tool, $manifest );
		}

		return true;
	}

	public static function uninstall( array $manifest ) {
		foreach ( (array) ( $manifest['tools'] ?? array() ) as $tool ) {
			$tool_name = (string) ( $tool['name'] ?? $tool['key'] ?? '' );
			if ( '' === $tool_name ) {
				continue;
			}
			if ( class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
				$row = WP_WebMCP_Tool_Repository::find_by_slug( $tool_name );
				if ( $row ) {
					WP_WebMCP_Tool_Repository::delete( (int) $row['id'] );
				}
			}
		}

		$seeded = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_query'     => array(
					array(
						'key'     => '_wpwebmcp_courses_seed',
						'compare' => 'EXISTS',
					),
				),
			)
		);
		foreach ( (array) $seeded as $pid ) {
			wp_delete_post( (int) $pid, true );
		}

		return true;
	}

	private static function register_tool_row( array $tool, array $manifest ): void {
		if ( ! class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			return;
		}

		$tool_name = (string) ( $tool['name'] ?? $tool['key'] ?? '' );
		if ( '' === $tool_name ) {
			return;
		}

		$data = array(
			'tool_name'        => $tool_name,
			'tool_description' => (string) ( $tool['description'] ?? '' ),
			'tool_type'        => 'read',
			'tool_scope'       => self::SLUG,
			'action_type'      => 'hook',
			'action_value'     => self::SLUG . '::' . (string) ( $tool['key'] ?? '' ),
			'parameters'       => isset( $tool['parameters'] ) ? (array) $tool['parameters'] : array(),
			'status'           => 'active',
		);

		WP_WebMCP_Tool_Repository::upsert_by_slug( $data );
	}

	public static function run_tool( $default, string $tool_key, array $params ) {
		switch ( $tool_key ) {
			case 'search_courses':
				return self::tool_search( $params );

			case 'get_course':
				return self::tool_get( $params );

			case 'list_course_categories':
				return self::tool_list_categories();

			case 'get_course_curriculum':
				return self::tool_get_curriculum( $params );

			case 'get_featured_courses':
				return self::tool_get_featured( $params );

			default:
				return $default;
		}
	}

	private static function tool_search( array $params ): array {
		$max = isset( $params['max'] ) ? min( 25, max( 1, (int) $params['max'] ) ) : 10;

		$tax_query = array( 'relation' => 'AND' );
		if ( ! empty( $params['category'] ) ) {
			$tax_query[] = array(
				'taxonomy' => self::TAX_CATEGORY,
				'field'    => 'slug',
				'terms'    => sanitize_key( (string) $params['category'] ),
			);
		}
		if ( ! empty( $params['level'] ) ) {
			$tax_query[] = array(
				'taxonomy' => self::TAX_LEVEL,
				'field'    => 'slug',
				'terms'    => sanitize_key( (string) $params['level'] ),
			);
		}

		$args = array(
			'post_type'      => self::POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => $max,
		);

		if ( ! empty( $params['query'] ) ) {
			$args['s'] = sanitize_text_field( (string) $params['query'] );
		}
		if ( count( $tax_query ) > 1 ) {
			$args['tax_query'] = $tax_query;
		}

		$posts = get_posts( $args );
		$items = array();

		foreach ( $posts as $p ) {
			$items[] = array(
				'id'         => $p->ID,
				'title'      => $p->post_title,
				'summary'    => wp_strip_all_tags( $p->post_excerpt ?: wp_trim_words( $p->post_content, 25 ) ),
				'instructor' => (string) get_post_meta( $p->ID, '_course_instructor', true ),
				'duration'   => (string) get_post_meta( $p->ID, '_course_duration', true ),
				'price'      => (string) get_post_meta( $p->ID, '_course_price', true ),
				'rating'     => (float) get_post_meta( $p->ID, '_course_rating', true ),
				'category'   => wp_get_post_terms( $p->ID, self::TAX_CATEGORY, array( 'fields' => 'names' ) ),
				'level'      => wp_get_post_terms( $p->ID, self::TAX_LEVEL, array( 'fields' => 'names' ) ),
				'permalink'  => get_permalink( $p->ID ),
			);
		}

		return array(
			'count'   => count( $items ),
			'courses' => $items,
		);
	}

	private static function tool_get( array $params ): array {
		$id = isset( $params['course_id'] ) ? (int) $params['course_id'] : 0;
		if ( $id <= 0 ) {
			return array( 'error' => 'Invalid course_id parameter.' );
		}

		$post = get_post( $id );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return array( 'error' => sprintf( 'Course %d not found.', $id ) );
		}

		return array(
			'id'            => $post->ID,
			'title'         => $post->post_title,
			'description'   => wp_strip_all_tags( $post->post_content ),
			'instructor'    => (string) get_post_meta( $post->ID, '_course_instructor', true ),
			'duration'      => (string) get_post_meta( $post->ID, '_course_duration', true ),
			'lessons_count' => (int) get_post_meta( $post->ID, '_course_lessons_count', true ),
			'price'         => (string) get_post_meta( $post->ID, '_course_price', true ),
			'rating'        => (float) get_post_meta( $post->ID, '_course_rating', true ),
			'curriculum'    => (array) get_post_meta( $post->ID, '_course_curriculum', true ),
			'category'      => wp_get_post_terms( $post->ID, self::TAX_CATEGORY, array( 'fields' => 'names' ) ),
			'level'         => wp_get_post_terms( $post->ID, self::TAX_LEVEL, array( 'fields' => 'names' ) ),
			'permalink'     => get_permalink( $post->ID ),
		);
	}

	private static function tool_list_categories(): array {
		$terms = get_terms(
			array(
				'taxonomy'   => self::TAX_CATEGORY,
				'hide_empty' => false,
			)
		);
		$out   = array();
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$out[] = array(
					'name'  => $t->name,
					'slug'  => $t->slug,
					'count' => (int) $t->count,
				);
			}
		}
		return array( 'course_categories' => $out );
	}

	private static function tool_get_curriculum( array $params ): array {
		$id = isset( $params['course_id'] ) ? (int) $params['course_id'] : 0;
		if ( $id <= 0 ) {
			return array( 'error' => 'Invalid course_id parameter.' );
		}

		$post = get_post( $id );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return array( 'error' => sprintf( 'Course %d not found.', $id ) );
		}

		$curr = get_post_meta( $post->ID, '_course_curriculum', true );
		return array(
			'course_id'  => $post->ID,
			'title'      => $post->post_title,
			'curriculum' => is_array( $curr ) ? $curr : array(),
		);
	}

	private static function tool_get_featured( array $params ): array {
		$max = isset( $params['max'] ) ? min( 10, max( 1, (int) $params['max'] ) ) : 5;

		$posts = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => $max,
				'meta_query'     => array(
					array(
						'key'     => '_course_is_featured',
						'value'   => '1',
						'compare' => '=',
					),
				),
			)
		);

		$items = array();
		foreach ( $posts as $p ) {
			$items[] = array(
				'id'         => $p->ID,
				'title'      => $p->post_title,
				'instructor' => (string) get_post_meta( $p->ID, '_course_instructor', true ),
				'duration'   => (string) get_post_meta( $p->ID, '_course_duration', true ),
				'rating'     => (float) get_post_meta( $p->ID, '_course_rating', true ),
				'category'   => wp_get_post_terms( $p->ID, self::TAX_CATEGORY, array( 'fields' => 'names' ) ),
				'level'      => wp_get_post_terms( $p->ID, self::TAX_LEVEL, array( 'fields' => 'names' ) ),
				'permalink'  => get_permalink( $p->ID ),
			);
		}

		return array( 'featured_courses' => $items );
	}

	private static function seed_example_courses(): void {
		$seeds = array(
			array(
				'title'         => 'Building Autonomous AI Agents with MCP & Web Protocols',
				'content'       => 'Comprehensive engineering masterclass on implementing the Model Context Protocol (MCP), designing robust tool schemas, managing memory states, and deploying autonomous web agents.',
				'instructor'    => 'Dr. Aris Thorne',
				'duration'      => '14.5 hours',
				'lessons_count' => 38,
				'price'         => '$129',
				'rating'        => 4.95,
				'featured'      => '1',
				'category'      => 'artificial-intelligence',
				'level'         => 'intermediate',
				'curriculum'    => array(
					array( 'module' => '1. MCP Protocol Core', 'lessons' => array( 'Client/Server Handshake', 'JSON-RPC Framing', 'SSE Transport' ) ),
					array( 'module' => '2. Tool Dispatch Architecture', 'lessons' => array( 'Tool Discovery & Manifests', 'Parameter Schema Validation', 'Security Boundaries' ) ),
					array( 'module' => '3. Real-World Integration', 'lessons' => array( 'Connecting to Claude Desktop', 'Connecting Cursor IDE', 'Autonomous Execution' ) ),
				),
			),
			array(
				'title'         => 'Complete Modern PHP 8.3 & Enterprise Design Patterns',
				'content'       => 'Deep dive into modern PHP features: typed properties, attributes, match expressions, readonly classes, fiber concurrency, and building bulletproof modular architectures.',
				'instructor'    => 'Elena Rostova',
				'duration'      => '22.0 hours',
				'lessons_count' => 54,
				'price'         => '$99',
				'rating'        => 4.88,
				'featured'      => '1',
				'category'      => 'computer-science',
				'level'         => 'intermediate',
				'curriculum'    => array(
					array( 'module' => '1. PHP 8 Core Evolution', 'lessons' => array( 'Type System & Union Types', 'Enums & Match Expressions', 'Attributes & Reflection' ) ),
					array( 'module' => '2. Enterprise Architecture', 'lessons' => array( 'Dependency Injection', 'Repository Pattern', 'Event-Driven Systems' ) ),
				),
			),
			array(
				'title'         => 'Answer Engine Optimization (AEO): The Next Era of Web Search',
				'content'       => 'Learn how Perplexity, ChatGPT Search, Claude, and Gemini retrieve, score, and cite web content. Master JSON-LD microdata, schema.org graphs, and agent visibility scoring.',
				'instructor'    => 'Sarah Lin',
				'duration'      => '8.0 hours',
				'lessons_count' => 20,
				'price'         => '$89',
				'rating'        => 4.92,
				'featured'      => '1',
				'category'      => 'business',
				'level'         => 'beginner',
				'curriculum'    => array(
					array( 'module' => '1. How LLM Crawlers Work', 'lessons' => array( 'Crawler User-Agents & Frequency', 'Direct Token Parsing', 'llms.txt Standard' ) ),
					array( 'module' => '2. Structured Citation Graphs', 'lessons' => array( 'Schema.org Graph Nodes', 'Entity Verification', 'Measuring Citation Share' ) ),
				),
			),
			array(
				'title'         => 'UI/UX Design for AI Applications & Conversational Canvas',
				'content'       => 'Create delightful, modern user experiences tailored for AI generative tools: multimodal input streams, contextual canvas sidebars, streaming typography, and reactive feedback.',
				'instructor'    => 'Marcus Sterling',
				'duration'      => '11.0 hours',
				'lessons_count' => 28,
				'price'         => '$119',
				'rating'        => 4.85,
				'featured'      => '0',
				'category'      => 'design',
				'level'         => 'intermediate',
				'curriculum'    => array(
					array( 'module' => '1. Conversational Canvas UI', 'lessons' => array( 'Streaming Message Tokens', 'Block Code Previews', 'Diff Rendering' ) ),
					array( 'module' => '2. Agent Feedback Loops', 'lessons' => array( 'Confirmation Modals', 'Branching Timelines', 'Confidence Indicators' ) ),
				),
			),
			array(
				'title'         => 'Web Performance Engineering & Core Web Vitals Mastery',
				'content'       => 'Diagnose and eliminate layout shifts, optimize INP down to single-digit milliseconds, stream server-rendered components, and tune asset caching strategies.',
				'instructor'    => 'David Kim',
				'duration'      => '9.5 hours',
				'lessons_count' => 24,
				'price'         => '$79',
				'rating'        => 4.90,
				'featured'      => '0',
				'category'      => 'computer-science',
				'level'         => 'advanced',
				'curriculum'    => array(
					array( 'module' => '1. Core Web Vitals Internals', 'lessons' => array( 'LCP Optimization Strategies', 'INP Breakdown & Long Tasks', 'CLS Fixes' ) ),
					array( 'module' => '2. Runtime Performance', 'lessons' => array( 'JavaScript Memory Leaks', 'Browser Paint Cycles', 'Edge Caching' ) ),
				),
			),
		);

		foreach ( $seeds as $data ) {
			$pid = wp_insert_post(
				array(
					'post_type'    => self::POST_TYPE,
					'post_title'   => $data['title'],
					'post_content' => $data['content'],
					'post_status'  => 'publish',
				)
			);
			if ( $pid && ! is_wp_error( $pid ) ) {
				update_post_meta( $pid, '_wpwebmcp_courses_seed', '1' );
				update_post_meta( $pid, '_course_instructor', $data['instructor'] );
				update_post_meta( $pid, '_course_duration', $data['duration'] );
				update_post_meta( $pid, '_course_lessons_count', $data['lessons_count'] );
				update_post_meta( $pid, '_course_price', $data['price'] );
				update_post_meta( $pid, '_course_rating', $data['rating'] );
				update_post_meta( $pid, '_course_is_featured', $data['featured'] );
				update_post_meta( $pid, '_course_curriculum', $data['curriculum'] );

				wp_set_object_terms( $pid, $data['category'], self::TAX_CATEGORY );
				wp_set_object_terms( $pid, $data['level'], self::TAX_LEVEL );
			}
		}
	}
}
// phpcs:enable WordPress.DB.SlowDBQuery
