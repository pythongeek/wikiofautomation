<?php
/**
 * Events & Conferences Pack Bootstrap.
 *
 * Provides a dedicated event_listing CPT, event_category & event_city taxonomies,
 * 5 seed events, and 5 MCP tools callable by AI agents.
 *
 * @package WP_WebMCP_Pack_Events
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.SlowDBQuery -- Pack tool queries require meta_query and tax_query for domain-specific filtering.
final class WP_WebMCP_Pack_Events {

	public const POST_TYPE    = 'event_listing';
	public const TAX_CATEGORY = 'event_category';
	public const TAX_CITY     = 'event_city';
	public const SLUG         = 'events';
	public const VERSION      = '1.0.0';

	public static function instance(): self {
		static $inst = null;
		if ( null === $inst ) {
			$inst = new self();
		}
		return $inst;
	}

	public static function boot(): void {
		add_action( 'init', array( self::class, 'register_post_type' ), 9 );
		add_filter( 'wpwebmcp_pack_runner_events', array( self::class, 'run_tool' ), 10, 3 );
	}

	public static function register_post_type(): void {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'        => array(
					'name'          => __( 'Events', 'webmcp-nexus' ),
					'singular_name' => __( 'Event', 'webmcp-nexus' ),
					'add_new_item'  => __( 'Add New Event', 'webmcp-nexus' ),
					'edit_item'     => __( 'Edit Event', 'webmcp-nexus' ),
				),
				'public'        => true,
				'show_in_rest'  => true,
				'has_archive'   => true,
				'menu_icon'     => 'dashicons-calendar-alt',
				'menu_position' => 8,
				'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'custom-fields' ),
				'rewrite'       => array( 'slug' => 'events' ),
			)
		);

		register_taxonomy(
			self::TAX_CATEGORY,
			array( self::POST_TYPE ),
			array(
				'labels'       => array(
					'name'          => __( 'Event Categories', 'webmcp-nexus' ),
					'singular_name' => __( 'Event Category', 'webmcp-nexus' ),
				),
				'public'       => true,
				'hierarchical' => true,
				'show_in_rest' => true,
				'rewrite'      => array( 'slug' => 'event-category' ),
			)
		);

		register_taxonomy(
			self::TAX_CITY,
			array( self::POST_TYPE ),
			array(
				'labels'       => array(
					'name'          => __( 'Event Locations', 'webmcp-nexus' ),
					'singular_name' => __( 'Event Location', 'webmcp-nexus' ),
				),
				'public'       => true,
				'hierarchical' => true,
				'show_in_rest' => true,
				'rewrite'      => array( 'slug' => 'event-city' ),
			)
		);
	}

	public static function install( array $manifest ) {
		self::register_post_type();

		$existing = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => array( 'publish', 'draft' ),
				'posts_per_page' => 1,
				'fields'         => 'ids',
			)
		);
		if ( empty( $existing ) ) {
			self::seed_example_events();
		}

		foreach ( (array) ( $manifest['tools'] ?? array() ) as $tool ) {
			self::register_tool_row( $tool, $manifest );
		}

		return true;
	}

	public static function uninstall( array $manifest ) {
		foreach ( (array) ( $manifest['tools'] ?? array() ) as $tool ) {
			$tool_name = (string) ( $tool['name'] ?? $tool['key'] ?? '' );
			if ( '' === $tool_name ) {
				continue;
			}
			if ( class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
				$row = WP_WebMCP_Tool_Repository::find_by_slug( $tool_name );
				if ( $row ) {
					WP_WebMCP_Tool_Repository::delete( (int) $row['id'] );
				}
			}
		}

		$seeded = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_query'     => array(
					array(
						'key'     => '_wpwebmcp_events_seed',
						'compare' => 'EXISTS',
					),
				),
			)
		);
		foreach ( (array) $seeded as $pid ) {
			wp_delete_post( (int) $pid, true );
		}

		return true;
	}

	private static function register_tool_row( array $tool, array $manifest ): void {
		if ( ! class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			return;
		}

		$tool_name = (string) ( $tool['name'] ?? $tool['key'] ?? '' );
		if ( '' === $tool_name ) {
			return;
		}

		$data = array(
			'tool_name'        => $tool_name,
			'tool_description' => (string) ( $tool['description'] ?? '' ),
			'tool_type'        => 'read',
			'tool_scope'       => self::SLUG,
			'action_type'      => 'hook',
			'action_value'     => self::SLUG . '::' . (string) ( $tool['key'] ?? '' ),
			'parameters'       => isset( $tool['parameters'] ) ? (array) $tool['parameters'] : array(),
			'status'           => 'active',
		);

		WP_WebMCP_Tool_Repository::upsert_by_slug( $data );
	}

	public static function run_tool( $default, string $tool_key, array $params ) {
		switch ( $tool_key ) {
			case 'search_events':
				return self::tool_search( $params );

			case 'get_event':
				return self::tool_get( $params );

			case 'list_event_categories':
				return self::tool_list_categories();

			case 'get_upcoming_events':
				return self::tool_get_upcoming( $params );

			case 'get_event_schedule':
				return self::tool_get_schedule( $params );

			default:
				return $default;
		}
	}

	private static function tool_search( array $params ): array {
		$max = isset( $params['max'] ) ? min( 25, max( 1, (int) $params['max'] ) ) : 10;

		$tax_query = array( 'relation' => 'AND' );
		if ( ! empty( $params['category'] ) ) {
			$tax_query[] = array(
				'taxonomy' => self::TAX_CATEGORY,
				'field'    => 'slug',
				'terms'    => sanitize_key( (string) $params['category'] ),
			);
		}
		if ( ! empty( $params['city'] ) ) {
			$tax_query[] = array(
				'taxonomy' => self::TAX_CITY,
				'field'    => 'slug',
				'terms'    => sanitize_key( (string) $params['city'] ),
			);
		}

		$meta_query = array( 'relation' => 'AND' );
		if ( ! empty( $params['upcoming_only'] ) ) {
			$meta_query[] = array(
				'key'     => '_event_start_date',
				'value'   => gmdate( 'Y-m-d' ),
				'compare' => '>=',
				'type'    => 'DATE',
			);
		}

		$args = array(
			'post_type'      => self::POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => $max,
		);

		if ( ! empty( $params['query'] ) ) {
			$args['s'] = sanitize_text_field( (string) $params['query'] );
		}
		if ( count( $tax_query ) > 1 ) {
			$args['tax_query'] = $tax_query;
		}
		if ( count( $meta_query ) > 1 ) {
			$args['meta_query'] = $meta_query;
		}

		$posts = get_posts( $args );
		$items = array();

		foreach ( $posts as $p ) {
			$items[] = array(
				'id'           => $p->ID,
				'title'        => $p->post_title,
				'summary'      => wp_strip_all_tags( $p->post_excerpt ?: wp_trim_words( $p->post_content, 25 ) ),
				'start_date'   => (string) get_post_meta( $p->ID, '_event_start_date', true ),
				'end_date'     => (string) get_post_meta( $p->ID, '_event_end_date', true ),
				'venue'        => (string) get_post_meta( $p->ID, '_event_venue', true ),
				'ticket_price' => (string) get_post_meta( $p->ID, '_event_ticket_price', true ),
				'categories'   => wp_get_post_terms( $p->ID, self::TAX_CATEGORY, array( 'fields' => 'names' ) ),
				'location'     => wp_get_post_terms( $p->ID, self::TAX_CITY, array( 'fields' => 'names' ) ),
				'permalink'    => get_permalink( $p->ID ),
			);
		}

		return array(
			'count'  => count( $items ),
			'events' => $items,
		);
	}

	private static function tool_get( array $params ): array {
		$id = isset( $params['event_id'] ) ? (int) $params['event_id'] : 0;
		if ( $id <= 0 ) {
			return array( 'error' => 'Invalid event_id parameter.' );
		}

		$post = get_post( $id );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return array( 'error' => sprintf( 'Event %d not found.', $id ) );
		}

		return array(
			'id'           => $post->ID,
			'title'        => $post->post_title,
			'description'  => wp_strip_all_tags( $post->post_content ),
			'start_date'   => (string) get_post_meta( $post->ID, '_event_start_date', true ),
			'end_date'     => (string) get_post_meta( $post->ID, '_event_end_date', true ),
			'venue'        => (string) get_post_meta( $post->ID, '_event_venue', true ),
			'address'      => (string) get_post_meta( $post->ID, '_event_address', true ),
			'ticket_price' => (string) get_post_meta( $post->ID, '_event_ticket_price', true ),
			'ticket_url'   => (string) get_post_meta( $post->ID, '_event_ticket_url', true ),
			'schedule'     => (array) get_post_meta( $post->ID, '_event_schedule', true ),
			'categories'   => wp_get_post_terms( $post->ID, self::TAX_CATEGORY, array( 'fields' => 'names' ) ),
			'location'     => wp_get_post_terms( $post->ID, self::TAX_CITY, array( 'fields' => 'names' ) ),
			'permalink'    => get_permalink( $post->ID ),
		);
	}

	private static function tool_list_categories(): array {
		$terms = get_terms(
			array(
				'taxonomy'   => self::TAX_CATEGORY,
				'hide_empty' => false,
			)
		);
		$out   = array();
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$out[] = array(
					'name'  => $t->name,
					'slug'  => $t->slug,
					'count' => (int) $t->count,
				);
			}
		}
		return array( 'event_categories' => $out );
	}

	private static function tool_get_upcoming( array $params ): array {
		$max  = isset( $params['max'] ) ? min( 15, max( 1, (int) $params['max'] ) ) : 5;
		$days = isset( $params['days'] ) ? max( 1, (int) $params['days'] ) : 60;

		$posts = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => $max,
				'meta_key'       => '_event_start_date',
				'orderby'        => 'meta_value',
				'order'          => 'ASC',
				'meta_query'     => array(
					array(
						'key'     => '_event_start_date',
						'value'   => gmdate( 'Y-m-d' ),
						'compare' => '>=',
						'type'    => 'DATE',
					),
				),
			)
		);

		$items = array();
		foreach ( $posts as $p ) {
			$items[] = array(
				'id'         => $p->ID,
				'title'      => $p->post_title,
				'start_date' => (string) get_post_meta( $p->ID, '_event_start_date', true ),
				'venue'      => (string) get_post_meta( $p->ID, '_event_venue', true ),
				'location'   => wp_get_post_terms( $p->ID, self::TAX_CITY, array( 'fields' => 'names' ) ),
				'permalink'  => get_permalink( $p->ID ),
			);
		}

		return array( 'upcoming_events' => $items );
	}

	private static function tool_get_schedule( array $params ): array {
		$id = isset( $params['event_id'] ) ? (int) $params['event_id'] : 0;
		if ( $id <= 0 ) {
			return array( 'error' => 'Invalid event_id parameter.' );
		}

		$post = get_post( $id );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return array( 'error' => sprintf( 'Event %d not found.', $id ) );
		}

		$schedule = get_post_meta( $post->ID, '_event_schedule', true );
		return array(
			'event_id' => $post->ID,
			'title'    => $post->post_title,
			'schedule' => is_array( $schedule ) ? $schedule : array(),
		);
	}

	private static function seed_example_events(): void {
		$future = function( int $days_ahead ) {
			return gmdate( 'Y-m-d', time() + ( $days_ahead * DAY_IN_SECONDS ) );
		};

		$seeds = array(
			array(
				'title'        => 'Global AI & Autonomous Agents Summit 2026',
				'content'      => 'The premier developer and researcher conference exploring MCP architectures, autonomous tool routing, and enterprise LLM deployment.',
				'start_date'   => $future( 14 ),
				'end_date'     => $future( 16 ),
				'venue'        => 'Moscone Convention Center',
				'address'      => '747 Howard St, San Francisco, CA 94103',
				'price'        => '$499 General / $199 Virtual',
				'ticket_url'   => 'https://example.com/tickets/ai-summit-2026',
				'category'     => 'conference',
				'city'         => 'san-francisco',
				'schedule'     => array(
					array( 'time' => '09:00 AM', 'title' => 'Keynote: The Architecture of WebMCP', 'speaker' => 'Dr. Aris Thorne' ),
					array( 'time' => '11:30 AM', 'title' => 'Hands-on Building MCP Servers in PHP', 'speaker' => 'Clara Vance' ),
					array( 'time' => '02:00 PM', 'title' => 'Agent Governance & Policy Enforcement', 'speaker' => 'Liam Sterling' ),
				),
			),
			array(
				'title'        => 'Hands-on WordPress Full Site Editing & AI Workshop',
				'content'      => 'Intensive 1-day deep dive for theme and plugin developers looking to wire real-time AI tools into block themes and custom Gutenberg patterns.',
				'start_date'   => $future( 28 ),
				'end_date'     => $future( 28 ),
				'venue'        => 'Kings Place Tech Lab',
				'address'      => '90 York Way, London N1 9AG, UK',
				'price'        => '£149 In-Person',
				'ticket_url'   => 'https://example.com/tickets/wp-fse-workshop',
				'category'     => 'workshop',
				'city'         => 'london',
				'schedule'     => array(
					array( 'time' => '10:00 AM', 'title' => 'Block Variations & AI Assistants', 'speaker' => 'Oliver Bennett' ),
					array( 'time' => '01:30 PM', 'title' => 'Creating Headless Endpoints for Claude & Cursor', 'speaker' => 'Maya Patel' ),
				),
			),
			array(
				'title'        => 'Next-Gen Open Web & Schema.org Hackathon',
				'content'      => '48-hour collaborative hackathon building open data graphs, structured microdata parsers, and citation-friendly web applications.',
				'start_date'   => $future( 45 ),
				'end_date'     => $future( 47 ),
				'venue'        => 'Factory Berlin Görlitzer Park',
				'address'      => 'Lohmühlenstraße 65, 12435 Berlin, Germany',
				'price'        => 'Free (RSVP Required)',
				'ticket_url'   => 'https://example.com/tickets/openweb-hack-berlin',
				'category'     => 'hackathon',
				'city'         => 'berlin',
				'schedule'     => array(
					array( 'time' => '06:00 PM', 'title' => 'Team Formation & Challenge Reveal', 'speaker' => 'Hackathon Organizers' ),
					array( 'time' => '12:00 PM', 'title' => 'Midway Mentorship Sessions', 'speaker' => 'Industry Mentors' ),
					array( 'time' => '04:00 PM', 'title' => 'Live Demos & Award Ceremony', 'speaker' => 'Judge Panel' ),
				),
			),
			array(
				'title'        => 'Worldwide Virtual AEO & Agentic Visibility Webinar',
				'content'      => 'Live streaming webinar discussing how Answer Engine Optimization (AEO) is surpassing traditional SEO for AI-driven search engines.',
				'start_date'   => $future( 7 ),
				'end_date'     => $future( 7 ),
				'venue'        => 'Live Online Stream (Zoom)',
				'address'      => 'Online / Global',
				'price'        => 'Free',
				'ticket_url'   => 'https://example.com/tickets/aeo-webinar',
				'category'     => 'webinar',
				'city'         => 'virtual',
				'schedule'     => array(
					array( 'time' => '01:00 PM EST', 'title' => 'The Death of the 10 Blue Links', 'speaker' => 'Sarah Lin' ),
					array( 'time' => '01:45 PM EST', 'title' => 'Auditing Your Site for LLM Readiness', 'speaker' => 'Sarah Lin & Guest Panel' ),
				),
			),
			array(
				'title'        => 'Tokyo AI Builders & Engineers Meetup',
				'content'      => 'Bi-monthly casual evening meetup for local engineers building with open LLMs, WebMCP, and autonomous browser agents.',
				'start_date'   => $future( 21 ),
				'end_date'     => $future( 21 ),
				'venue'        => 'Shibuya WeWork Lounge',
				'address'      => '1-2-3 Shibuya, Tokyo 150-0002, Japan',
				'price'        => '¥1,000 (Includes refreshments)',
				'ticket_url'   => 'https://example.com/tickets/tokyo-ai-meetup',
				'category'     => 'meetup',
				'city'         => 'tokyo',
				'schedule'     => array(
					array( 'time' => '07:00 PM', 'title' => 'Lightning Talks: Edge AI in Production', 'speaker' => 'Kenji Sato' ),
					array( 'time' => '08:00 PM', 'title' => 'Open Networking & Agent Demos', 'speaker' => 'All Attendees' ),
				),
			),
		);

		foreach ( $seeds as $data ) {
			$pid = wp_insert_post(
				array(
					'post_type'    => self::POST_TYPE,
					'post_title'   => $data['title'],
					'post_content' => $data['content'],
					'post_status'  => 'publish',
				)
			);
			if ( $pid && ! is_wp_error( $pid ) ) {
				update_post_meta( $pid, '_wpwebmcp_events_seed', '1' );
				update_post_meta( $pid, '_event_start_date', $data['start_date'] );
				update_post_meta( $pid, '_event_end_date', $data['end_date'] );
				update_post_meta( $pid, '_event_venue', $data['venue'] );
				update_post_meta( $pid, '_event_address', $data['address'] );
				update_post_meta( $pid, '_event_ticket_price', $data['price'] );
				update_post_meta( $pid, '_event_ticket_url', $data['ticket_url'] );
				update_post_meta( $pid, '_event_schedule', $data['schedule'] );

				wp_set_object_terms( $pid, $data['category'], self::TAX_CATEGORY );
				wp_set_object_terms( $pid, $data['city'], self::TAX_CITY );
			}
		}
	}
}
// phpcs:enable WordPress.DB.SlowDBQuery
