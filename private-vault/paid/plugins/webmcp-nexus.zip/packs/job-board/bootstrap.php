<?php
/**
 * Job Board & Careers Pack Bootstrap.
 *
 * Provides a dedicated job_posting CPT, job_department & job_type taxonomies,
 * 5 seed jobs, and 5 MCP tools callable by AI agents.
 *
 * @package WP_WebMCP_Pack_JobBoard
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.SlowDBQuery -- Pack tool queries require meta_query and tax_query for domain-specific filtering.
final class WP_WebMCP_Pack_JobBoard {

	public const POST_TYPE      = 'job_posting';
	public const TAX_DEPARTMENT = 'job_department';
	public const TAX_TYPE       = 'job_type';
	public const SLUG           = 'job-board';
	public const VERSION        = '1.0.0';

	public static function instance(): self {
		static $inst = null;
		if ( null === $inst ) {
			$inst = new self();
		}
		return $inst;
	}

	public static function boot(): void {
		add_action( 'init', array( self::class, 'register_post_type' ), 9 );
		add_filter( 'wpwebmcp_pack_runner_job-board', array( self::class, 'run_tool' ), 10, 3 );
	}

	public static function register_post_type(): void {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'        => array(
					'name'          => __( 'Jobs', 'webmcp-nexus' ),
					'singular_name' => __( 'Job', 'webmcp-nexus' ),
					'add_new_item'  => __( 'Add New Job', 'webmcp-nexus' ),
					'edit_item'     => __( 'Edit Job', 'webmcp-nexus' ),
				),
				'public'        => true,
				'show_in_rest'  => true,
				'has_archive'   => true,
				'menu_icon'     => 'dashicons-businessman',
				'menu_position' => 9,
				'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'custom-fields' ),
				'rewrite'       => array( 'slug' => 'careers' ),
			)
		);

		register_taxonomy(
			self::TAX_DEPARTMENT,
			array( self::POST_TYPE ),
			array(
				'labels'       => array(
					'name'          => __( 'Departments', 'webmcp-nexus' ),
					'singular_name' => __( 'Department', 'webmcp-nexus' ),
				),
				'public'       => true,
				'hierarchical' => true,
				'show_in_rest' => true,
				'rewrite'      => array( 'slug' => 'department' ),
			)
		);

		register_taxonomy(
			self::TAX_TYPE,
			array( self::POST_TYPE ),
			array(
				'labels'       => array(
					'name'          => __( 'Job Types', 'webmcp-nexus' ),
					'singular_name' => __( 'Job Type', 'webmcp-nexus' ),
				),
				'public'       => true,
				'hierarchical' => true,
				'show_in_rest' => true,
				'rewrite'      => array( 'slug' => 'job-type' ),
			)
		);
	}

	public static function install( array $manifest ) {
		self::register_post_type();

		$existing = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => array( 'publish', 'draft' ),
				'posts_per_page' => 1,
				'fields'         => 'ids',
			)
		);
		if ( empty( $existing ) ) {
			self::seed_example_jobs();
		}

		foreach ( (array) ( $manifest['tools'] ?? array() ) as $tool ) {
			self::register_tool_row( $tool, $manifest );
		}

		return true;
	}

	public static function uninstall( array $manifest ) {
		foreach ( (array) ( $manifest['tools'] ?? array() ) as $tool ) {
			$tool_name = (string) ( $tool['name'] ?? $tool['key'] ?? '' );
			if ( '' === $tool_name ) {
				continue;
			}
			if ( class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
				$row = WP_WebMCP_Tool_Repository::find_by_slug( $tool_name );
				if ( $row ) {
					WP_WebMCP_Tool_Repository::delete( (int) $row['id'] );
				}
			}
		}

		$seeded = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_query'     => array(
					array(
						'key'     => '_wpwebmcp_job_board_seed',
						'compare' => 'EXISTS',
					),
				),
			)
		);
		foreach ( (array) $seeded as $pid ) {
			wp_delete_post( (int) $pid, true );
		}

		return true;
	}

	private static function register_tool_row( array $tool, array $manifest ): void {
		if ( ! class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			return;
		}

		$tool_name = (string) ( $tool['name'] ?? $tool['key'] ?? '' );
		if ( '' === $tool_name ) {
			return;
		}

		$data = array(
			'tool_name'        => $tool_name,
			'tool_description' => (string) ( $tool['description'] ?? '' ),
			'tool_type'        => 'read',
			'tool_scope'       => self::SLUG,
			'action_type'      => 'hook',
			'action_value'     => self::SLUG . '::' . (string) ( $tool['key'] ?? '' ),
			'parameters'       => isset( $tool['parameters'] ) ? (array) $tool['parameters'] : array(),
			'status'           => 'active',
		);

		WP_WebMCP_Tool_Repository::upsert_by_slug( $data );
	}

	public static function run_tool( $default, string $tool_key, array $params ) {
		switch ( $tool_key ) {
			case 'search_jobs':
				return self::tool_search( $params );

			case 'get_job_details':
				return self::tool_get( $params );

			case 'list_job_departments':
				return self::tool_list_departments();

			case 'get_remote_jobs':
				return self::tool_get_remote( $params );

			case 'get_job_requirements':
				return self::tool_get_requirements( $params );

			default:
				return $default;
		}
	}

	private static function tool_search( array $params ): array {
		$max = isset( $params['max'] ) ? min( 25, max( 1, (int) $params['max'] ) ) : 10;

		$tax_query = array( 'relation' => 'AND' );
		if ( ! empty( $params['department'] ) ) {
			$tax_query[] = array(
				'taxonomy' => self::TAX_DEPARTMENT,
				'field'    => 'slug',
				'terms'    => sanitize_key( (string) $params['department'] ),
			);
		}
		if ( ! empty( $params['job_type'] ) ) {
			$tax_query[] = array(
				'taxonomy' => self::TAX_TYPE,
				'field'    => 'slug',
				'terms'    => sanitize_key( (string) $params['job_type'] ),
			);
		}

		$meta_query = array( 'relation' => 'AND' );
		if ( ! empty( $params['remote_only'] ) ) {
			$meta_query[] = array(
				'key'     => '_job_is_remote',
				'value'   => '1',
				'compare' => '=',
			);
		}

		$args = array(
			'post_type'      => self::POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => $max,
		);

		if ( ! empty( $params['query'] ) ) {
			$args['s'] = sanitize_text_field( (string) $params['query'] );
		}
		if ( count( $tax_query ) > 1 ) {
			$args['tax_query'] = $tax_query;
		}
		if ( count( $meta_query ) > 1 ) {
			$args['meta_query'] = $meta_query;
		}

		$posts = get_posts( $args );
		$items = array();

		foreach ( $posts as $p ) {
			$items[] = array(
				'id'          => $p->ID,
				'title'       => $p->post_title,
				'summary'     => wp_strip_all_tags( $p->post_excerpt ?: wp_trim_words( $p->post_content, 25 ) ),
				'salary'      => (string) get_post_meta( $p->ID, '_job_salary', true ),
				'location'    => (string) get_post_meta( $p->ID, '_job_location', true ),
				'is_remote'   => '1' === (string) get_post_meta( $p->ID, '_job_is_remote', true ),
				'department'  => wp_get_post_terms( $p->ID, self::TAX_DEPARTMENT, array( 'fields' => 'names' ) ),
				'job_type'    => wp_get_post_terms( $p->ID, self::TAX_TYPE, array( 'fields' => 'names' ) ),
				'permalink'   => get_permalink( $p->ID ),
			);
		}

		return array(
			'count' => count( $items ),
			'jobs'  => $items,
		);
	}

	private static function tool_get( array $params ): array {
		$id = isset( $params['job_id'] ) ? (int) $params['job_id'] : 0;
		if ( $id <= 0 ) {
			return array( 'error' => 'Invalid job_id parameter.' );
		}

		$post = get_post( $id );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return array( 'error' => sprintf( 'Job %d not found.', $id ) );
		}

		return array(
			'id'               => $post->ID,
			'title'            => $post->post_title,
			'description'      => wp_strip_all_tags( $post->post_content ),
			'salary'           => (string) get_post_meta( $post->ID, '_job_salary', true ),
			'location'         => (string) get_post_meta( $post->ID, '_job_location', true ),
			'is_remote'        => '1' === (string) get_post_meta( $post->ID, '_job_is_remote', true ),
			'experience_level' => (string) get_post_meta( $post->ID, '_job_experience_level', true ),
			'requirements'     => (array) get_post_meta( $post->ID, '_job_requirements', true ),
			'benefits'         => (array) get_post_meta( $post->ID, '_job_benefits', true ),
			'apply_email'      => (string) get_post_meta( $post->ID, '_job_apply_email', true ),
			'department'       => wp_get_post_terms( $post->ID, self::TAX_DEPARTMENT, array( 'fields' => 'names' ) ),
			'job_type'         => wp_get_post_terms( $post->ID, self::TAX_TYPE, array( 'fields' => 'names' ) ),
			'permalink'        => get_permalink( $post->ID ),
		);
	}

	private static function tool_list_departments(): array {
		$terms = get_terms(
			array(
				'taxonomy'   => self::TAX_DEPARTMENT,
				'hide_empty' => false,
			)
		);
		$out   = array();
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$out[] = array(
					'name'  => $t->name,
					'slug'  => $t->slug,
					'count' => (int) $t->count,
				);
			}
		}
		return array( 'departments' => $out );
	}

	private static function tool_get_remote( array $params ): array {
		$max = isset( $params['max'] ) ? min( 20, max( 1, (int) $params['max'] ) ) : 10;

		$posts = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => $max,
				'meta_query'     => array(
					array(
						'key'     => '_job_is_remote',
						'value'   => '1',
						'compare' => '=',
					),
				),
			)
		);

		$items = array();
		foreach ( $posts as $p ) {
			$items[] = array(
				'id'         => $p->ID,
				'title'      => $p->post_title,
				'salary'     => (string) get_post_meta( $p->ID, '_job_salary', true ),
				'department' => wp_get_post_terms( $p->ID, self::TAX_DEPARTMENT, array( 'fields' => 'names' ) ),
				'job_type'   => wp_get_post_terms( $p->ID, self::TAX_TYPE, array( 'fields' => 'names' ) ),
				'permalink'  => get_permalink( $p->ID ),
			);
		}

		return array( 'remote_jobs' => $items );
	}

	private static function tool_get_requirements( array $params ): array {
		$id = isset( $params['job_id'] ) ? (int) $params['job_id'] : 0;
		if ( $id <= 0 ) {
			return array( 'error' => 'Invalid job_id parameter.' );
		}

		$post = get_post( $id );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return array( 'error' => sprintf( 'Job %d not found.', $id ) );
		}

		$reqs = get_post_meta( $post->ID, '_job_requirements', true );
		$lvl  = get_post_meta( $post->ID, '_job_experience_level', true );

		return array(
			'job_id'           => $post->ID,
			'title'            => $post->post_title,
			'experience_level' => (string) $lvl,
			'requirements'     => is_array( $reqs ) ? $reqs : array(),
		);
	}

	private static function seed_example_jobs(): void {
		$seeds = array(
			array(
				'title'            => 'Staff AI Platform Engineer',
				'content'          => 'Architect and scale our model context protocol (MCP) agent infrastructure. You will design low-latency tool dispatchers, telemetry pipelines, and secure policy boundaries.',
				'salary'           => '$185,000 - $225,000 + Equity',
				'location'         => 'San Francisco, CA / Remote',
				'is_remote'        => '1',
				'experience_level' => 'Staff / 7+ years',
				'department'       => 'engineering',
				'job_type'         => 'full-time',
				'requirements'     => array( 'Expertise in distributed systems & low-latency APIs', 'Deep familiarity with MCP specifications & LLM tooling', 'Proficiency in PHP 8.x, TypeScript, and Go', 'Strong grasp of web security & authorization models' ),
				'benefits'         => array( '100% employer-covered health & dental', 'Flexible PTO with mandatory minimums', '$3,000 annual home office setup stipend', 'Annual learning & conference allowance' ),
				'apply_email'      => 'careers@example.com',
			),
			array(
				'title'            => 'Senior Product Designer (AI Interactions)',
				'content'          => 'Design the future of human-agent collaboration. You will lead interface design across web dashboards, conversational canvas extensions, and visual policy editors.',
				'salary'           => '$145,000 - $175,000 + Equity',
				'location'         => 'New York, NY / Remote',
				'is_remote'        => '1',
				'experience_level' => 'Senior / 5+ years',
				'department'       => 'design',
				'job_type'         => 'full-time',
				'requirements'     => array( 'Proven portfolio of complex SaaS product design', 'Experience designing AI/ML interfaces and interaction patterns', 'Mastery of Figma, design systems, and rapid prototyping', 'Empathy for both developer and non-technical personas' ),
				'benefits'         => array( 'Comprehensive health, vision, and mental health benefits', '401(k) matching up to 4%', 'Parental leave up to 16 weeks fully paid' ),
				'apply_email'      => 'design-jobs@example.com',
			),
			array(
				'title'            => 'Principal Solutions Architect (WordPress Ecosystem)',
				'content'          => 'Partner with high-traffic publishers and enterprise WooCommerce merchants to implement WebMCP visibility, automated AEO audits, and custom vertical tool packs.',
				'salary'           => '$160,000 - $190,000',
				'location'         => 'London, UK / Remote',
				'is_remote'        => '1',
				'experience_level' => 'Principal / 6+ years',
				'department'       => 'sales',
				'job_type'         => 'full-time',
				'requirements'     => array( 'Deep expertise in WordPress VIP architecture and REST APIs', 'Client-facing consulting and technical solution delivery', 'Understanding of enterprise search engines and LLM crawlers', 'Outstanding written and verbal presentation skills' ),
				'benefits'         => array( 'UK pension matching scheme', 'Private healthcare insurance', 'Flexible remote-first work culture' ),
				'apply_email'      => 'solutions@example.com',
			),
			array(
				'title'            => 'Technical Content & Growth Marketer',
				'content'          => 'Craft educational tutorials, benchmark case studies, and documentation for developers adopting agentic web protocols and Answer Engine Optimization.',
				'salary'           => '$95,000 - $120,000',
				'location'         => 'Austin, TX',
				'is_remote'        => '0',
				'experience_level' => 'Mid-Level / 3+ years',
				'department'       => 'marketing',
				'job_type'         => 'full-time',
				'requirements'     => array( 'Track record of writing technical content read by thousands of developers', 'Basic understanding of HTML, APIs, and modern SEO/AEO', 'Experience managing technical documentation and community forums' ),
				'benefits'         => array( 'Downtown Austin office with catered lunches', 'Wellness stipend and commuter benefits' ),
				'apply_email'      => 'growth@example.com',
			),
			array(
				'title'            => 'Open Source Developer Advocate (Intern / Co-op)',
				'content'          => 'Build open-source vertical tool packs, create starter repositories, and interact with the WordPress and AI engineering community.',
				'salary'           => '$40 - $50 / hour',
				'location'         => 'Remote (Worldwide)',
				'is_remote'        => '1',
				'experience_level' => 'Entry / Student',
				'department'       => 'engineering',
				'job_type'         => 'internship',
				'requirements'     => array( 'Familiarity with PHP and modern JavaScript', 'Passion for open-source software and developer tooling', 'Eagerness to learn agent protocols and LLM integration' ),
				'benefits'         => array( 'Direct mentorship from senior architects', 'Flexible hours around academic schedules' ),
				'apply_email'      => 'internships@example.com',
			),
		);

		foreach ( $seeds as $data ) {
			$pid = wp_insert_post(
				array(
					'post_type'    => self::POST_TYPE,
					'post_title'   => $data['title'],
					'post_content' => $data['content'],
					'post_status'  => 'publish',
				)
			);
			if ( $pid && ! is_wp_error( $pid ) ) {
				update_post_meta( $pid, '_wpwebmcp_job_board_seed', '1' );
				update_post_meta( $pid, '_job_salary', $data['salary'] );
				update_post_meta( $pid, '_job_location', $data['location'] );
				update_post_meta( $pid, '_job_is_remote', $data['is_remote'] );
				update_post_meta( $pid, '_job_experience_level', $data['experience_level'] );
				update_post_meta( $pid, '_job_requirements', $data['requirements'] );
				update_post_meta( $pid, '_job_benefits', $data['benefits'] );
				update_post_meta( $pid, '_job_apply_email', $data['apply_email'] );

				wp_set_object_terms( $pid, $data['department'], self::TAX_DEPARTMENT );
				wp_set_object_terms( $pid, $data['job_type'], self::TAX_TYPE );
			}
		}
	}
}
// phpcs:enable WordPress.DB.SlowDBQuery
