<?php
/**
 * Real Estate & Properties Pack Bootstrap.
 *
 * Provides a dedicated property_listing CPT, property_type & property_city taxonomies,
 * 5 seed properties, and 5 MCP tools callable by AI agents.
 *
 * @package WP_WebMCP_Pack_RealEstate
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.SlowDBQuery -- Pack tool queries require meta_query and tax_query for domain-specific filtering.
final class WP_WebMCP_Pack_RealEstate {

	public const POST_TYPE = 'property_listing';
	public const TAX_TYPE  = 'property_type';
	public const TAX_CITY  = 'property_city';
	public const SLUG      = 'real-estate';
	public const VERSION   = '1.0.0';

	public static function instance(): self {
		static $inst = null;
		if ( null === $inst ) {
			$inst = new self();
		}
		return $inst;
	}

	public static function boot(): void {
		add_action( 'init', array( self::class, 'register_post_type' ), 9 );
		add_filter( 'wpwebmcp_pack_runner_real-estate', array( self::class, 'run_tool' ), 10, 3 );
	}

	public static function register_post_type(): void {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'        => array(
					'name'          => __( 'Properties', 'webmcp-nexus' ),
					'singular_name' => __( 'Property', 'webmcp-nexus' ),
					'add_new_item'  => __( 'Add New Property', 'webmcp-nexus' ),
					'edit_item'     => __( 'Edit Property', 'webmcp-nexus' ),
				),
				'public'        => true,
				'show_in_rest'  => true,
				'has_archive'   => true,
				'menu_icon'     => 'dashicons-building',
				'menu_position' => 7,
				'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'custom-fields' ),
				'rewrite'       => array( 'slug' => 'properties' ),
			)
		);

		register_taxonomy(
			self::TAX_TYPE,
			array( self::POST_TYPE ),
			array(
				'labels'       => array(
					'name'          => __( 'Property Types', 'webmcp-nexus' ),
					'singular_name' => __( 'Property Type', 'webmcp-nexus' ),
				),
				'public'       => true,
				'hierarchical' => true,
				'show_in_rest' => true,
				'rewrite'      => array( 'slug' => 'property-type' ),
			)
		);

		register_taxonomy(
			self::TAX_CITY,
			array( self::POST_TYPE ),
			array(
				'labels'       => array(
					'name'          => __( 'Cities & Locations', 'webmcp-nexus' ),
					'singular_name' => __( 'City / Location', 'webmcp-nexus' ),
				),
				'public'       => true,
				'hierarchical' => true,
				'show_in_rest' => true,
				'rewrite'      => array( 'slug' => 'location' ),
			)
		);
	}

	public static function install( array $manifest ) {
		self::register_post_type();

		$existing = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => array( 'publish', 'draft' ),
				'posts_per_page' => 1,
				'fields'         => 'ids',
			)
		);
		if ( empty( $existing ) ) {
			self::seed_example_properties();
		}

		foreach ( (array) ( $manifest['tools'] ?? array() ) as $tool ) {
			self::register_tool_row( $tool, $manifest );
		}

		return true;
	}

	public static function uninstall( array $manifest ) {
		foreach ( (array) ( $manifest['tools'] ?? array() ) as $tool ) {
			$tool_name = (string) ( $tool['name'] ?? $tool['key'] ?? '' );
			if ( '' === $tool_name ) {
				continue;
			}
			if ( class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
				$row = WP_WebMCP_Tool_Repository::find_by_slug( $tool_name );
				if ( $row ) {
					WP_WebMCP_Tool_Repository::delete( (int) $row['id'] );
				}
			}
		}

		$seeded = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_query'     => array(
					array(
						'key'     => '_wpwebmcp_real_estate_seed',
						'compare' => 'EXISTS',
					),
				),
			)
		);
		foreach ( (array) $seeded as $pid ) {
			wp_delete_post( (int) $pid, true );
		}

		return true;
	}

	private static function register_tool_row( array $tool, array $manifest ): void {
		if ( ! class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			return;
		}

		$tool_name = (string) ( $tool['name'] ?? $tool['key'] ?? '' );
		if ( '' === $tool_name ) {
			return;
		}

		$data = array(
			'tool_name'        => $tool_name,
			'tool_description' => (string) ( $tool['description'] ?? '' ),
			'tool_type'        => 'read',
			'tool_scope'       => self::SLUG,
			'action_type'      => 'hook',
			'action_value'     => self::SLUG . '::' . (string) ( $tool['key'] ?? '' ),
			'parameters'       => isset( $tool['parameters'] ) ? (array) $tool['parameters'] : array(),
			'status'           => 'active',
		);

		WP_WebMCP_Tool_Repository::upsert_by_slug( $data );
	}

	public static function run_tool( $default, string $tool_key, array $params ) {
		switch ( $tool_key ) {
			case 'search_properties':
				return self::tool_search( $params );

			case 'get_property':
				return self::tool_get( $params );

			case 'list_property_types':
				return self::tool_list_types();

			case 'list_property_cities':
				return self::tool_list_cities();

			case 'get_featured_properties':
				return self::tool_get_featured( $params );

			default:
				return $default;
		}
	}

	private static function tool_search( array $params ): array {
		$max = isset( $params['max'] ) ? min( 25, max( 1, (int) $params['max'] ) ) : 10;

		$tax_query = array( 'relation' => 'AND' );
		if ( ! empty( $params['property_type'] ) ) {
			$tax_query[] = array(
				'taxonomy' => self::TAX_TYPE,
				'field'    => 'slug',
				'terms'    => sanitize_key( (string) $params['property_type'] ),
			);
		}
		if ( ! empty( $params['city'] ) ) {
			$tax_query[] = array(
				'taxonomy' => self::TAX_CITY,
				'field'    => 'slug',
				'terms'    => sanitize_key( (string) $params['city'] ),
			);
		}

		$meta_query = array( 'relation' => 'AND' );
		if ( isset( $params['min_price'] ) && is_numeric( $params['min_price'] ) ) {
			$meta_query[] = array(
				'key'     => '_property_price',
				'value'   => (float) $params['min_price'],
				'type'    => 'NUMERIC',
				'compare' => '>=',
			);
		}
		if ( isset( $params['max_price'] ) && is_numeric( $params['max_price'] ) ) {
			$meta_query[] = array(
				'key'     => '_property_price',
				'value'   => (float) $params['max_price'],
				'type'    => 'NUMERIC',
				'compare' => '<=',
			);
		}
		if ( isset( $params['bedrooms'] ) && is_numeric( $params['bedrooms'] ) ) {
			$meta_query[] = array(
				'key'     => '_property_bedrooms',
				'value'   => (int) $params['bedrooms'],
				'type'    => 'NUMERIC',
				'compare' => '>=',
			);
		}

		$args = array(
			'post_type'      => self::POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => $max,
		);

		if ( ! empty( $params['query'] ) ) {
			$args['s'] = sanitize_text_field( (string) $params['query'] );
		}
		if ( count( $tax_query ) > 1 ) {
			$args['tax_query'] = $tax_query;
		}
		if ( count( $meta_query ) > 1 ) {
			$args['meta_query'] = $meta_query;
		}

		$posts = get_posts( $args );
		$items = array();

		foreach ( $posts as $p ) {
			$items[] = array(
				'id'            => $p->ID,
				'title'         => $p->post_title,
				'summary'       => wp_strip_all_tags( $p->post_excerpt ?: wp_trim_words( $p->post_content, 25 ) ),
				'price'         => (float) get_post_meta( $p->ID, '_property_price', true ),
				'bedrooms'      => (int) get_post_meta( $p->ID, '_property_bedrooms', true ),
				'bathrooms'     => (float) get_post_meta( $p->ID, '_property_bathrooms', true ),
				'sqft'          => (int) get_post_meta( $p->ID, '_property_sqft', true ),
				'property_type' => wp_get_post_terms( $p->ID, self::TAX_TYPE, array( 'fields' => 'names' ) ),
				'city'          => wp_get_post_terms( $p->ID, self::TAX_CITY, array( 'fields' => 'names' ) ),
				'permalink'     => get_permalink( $p->ID ),
			);
		}

		return array(
			'count'      => count( $items ),
			'properties' => $items,
		);
	}

	private static function tool_get( array $params ): array {
		$id = isset( $params['property_id'] ) ? (int) $params['property_id'] : 0;
		if ( $id <= 0 ) {
			return array( 'error' => 'Invalid property_id parameter.' );
		}

		$post = get_post( $id );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return array( 'error' => sprintf( 'Property %d not found.', $id ) );
		}

		return array(
			'id'            => $post->ID,
			'title'         => $post->post_title,
			'description'   => wp_strip_all_tags( $post->post_content ),
			'price'         => (float) get_post_meta( $post->ID, '_property_price', true ),
			'bedrooms'      => (int) get_post_meta( $post->ID, '_property_bedrooms', true ),
			'bathrooms'     => (float) get_post_meta( $post->ID, '_property_bathrooms', true ),
			'sqft'          => (int) get_post_meta( $post->ID, '_property_sqft', true ),
			'address'       => (string) get_post_meta( $post->ID, '_property_address', true ),
			'amenities'     => (array) get_post_meta( $post->ID, '_property_amenities', true ),
			'agent'         => array(
				'name'  => (string) get_post_meta( $post->ID, '_property_agent_name', true ),
				'phone' => (string) get_post_meta( $post->ID, '_property_agent_phone', true ),
			),
			'property_type' => wp_get_post_terms( $post->ID, self::TAX_TYPE, array( 'fields' => 'names' ) ),
			'city'          => wp_get_post_terms( $post->ID, self::TAX_CITY, array( 'fields' => 'names' ) ),
			'permalink'     => get_permalink( $post->ID ),
		);
	}

	private static function tool_list_types(): array {
		$terms = get_terms(
			array(
				'taxonomy'   => self::TAX_TYPE,
				'hide_empty' => false,
			)
		);
		$out   = array();
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$out[] = array(
					'name'  => $t->name,
					'slug'  => $t->slug,
					'count' => (int) $t->count,
				);
			}
		}
		return array( 'property_types' => $out );
	}

	private static function tool_list_cities(): array {
		$terms = get_terms(
			array(
				'taxonomy'   => self::TAX_CITY,
				'hide_empty' => false,
			)
		);
		$out   = array();
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$out[] = array(
					'name'  => $t->name,
					'slug'  => $t->slug,
					'count' => (int) $t->count,
				);
			}
		}
		return array( 'cities' => $out );
	}

	private static function tool_get_featured( array $params ): array {
		$max = isset( $params['max'] ) ? min( 10, max( 1, (int) $params['max'] ) ) : 5;

		$posts = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => $max,
				'meta_query'     => array(
					array(
						'key'     => '_property_is_featured',
						'value'   => '1',
						'compare' => '=',
					),
				),
			)
		);

		$items = array();
		foreach ( $posts as $p ) {
			$items[] = array(
				'id'       => $p->ID,
				'title'    => $p->post_title,
				'price'    => (float) get_post_meta( $p->ID, '_property_price', true ),
				'bedrooms' => (int) get_post_meta( $p->ID, '_property_bedrooms', true ),
				'sqft'     => (int) get_post_meta( $p->ID, '_property_sqft', true ),
				'city'     => wp_get_post_terms( $p->ID, self::TAX_CITY, array( 'fields' => 'names' ) ),
			);
		}

		return array( 'featured_properties' => $items );
	}

	private static function seed_example_properties(): void {
		$seeds = array(
			array(
				'title'     => 'Modern Waterfront Villa with Private Dock',
				'content'   => 'Contemporary luxury estate featuring panoramic waterfront views, soaring 14-foot ceilings, and high-end Italian finishes throughout. Includes private boat dock and heated infinity pool.',
				'price'     => 3850000,
				'bedrooms'  => 5,
				'bathrooms' => 6,
				'sqft'      => 5800,
				'address'   => '1042 Oceanview Boulevard, Miami, FL 33139',
				'type'      => 'villa',
				'city'      => 'miami',
				'featured'  => '1',
				'amenities' => array( 'Infinity Pool', 'Private Dock', 'Smart Home System', 'Wine Cellar', '3-Car Garage' ),
				'agent'     => array( 'name' => 'Sophia Martinez', 'phone' => '+1 (305) 555-0192' ),
			),
			array(
				'title'     => 'High-Floor Luxury Penthouse in Tribeca',
				'content'   => 'Spectacular loft penthouse with private wraparound terrace, custom Boffi kitchen, floor-to-ceiling soundproof windows, and private keyed elevator entry.',
				'price'     => 4950000,
				'bedrooms'  => 3,
				'bathrooms' => 3.5,
				'sqft'      => 3200,
				'address'   => '74 Franklin Street, Penthouse B, New York, NY 10013',
				'type'      => 'penthouse',
				'city'      => 'new-york',
				'featured'  => '1',
				'amenities' => array( 'Wraparound Terrace', 'Doorman', 'Fitness Center', 'Keyed Elevator', 'Storage Locker' ),
				'agent'     => array( 'name' => 'Alexander Hayes', 'phone' => '+1 (212) 555-0144' ),
			),
			array(
				'title'     => 'Mid-Century Architectural Gem in Hollywood Hills',
				'content'   => 'Restored mid-century masterpiece perched above Sunset Strip. Seamless indoor-outdoor living, terrazzo flooring, cedar tongue-and-groove ceilings, and solar power array.',
				'price'     => 2650000,
				'bedrooms'  => 4,
				'bathrooms' => 3,
				'sqft'      => 2900,
				'address'   => '2180 Laurel Canyon Boulevard, Los Angeles, CA 90046',
				'type'      => 'house',
				'city'      => 'los-angeles',
				'featured'  => '1',
				'amenities' => array( 'Canyon Views', 'Solar Array', 'Pool & Spa', 'Fire Pit', 'EV Charger' ),
				'agent'     => array( 'name' => 'Elena Vance', 'phone' => '+1 (310) 555-0188' ),
			),
			array(
				'title'     => 'Eco-Friendly Modern Craftsman near Downtown',
				'content'   => 'Net-zero ready home in trendy Austin neighborhood. Features native landscaping, spray foam insulation, custom white oak cabinetry, and spacious covered back patio.',
				'price'     => 895000,
				'bedrooms'  => 3,
				'bathrooms' => 2.5,
				'sqft'      => 2150,
				'address'   => '1408 East 6th Street, Austin, TX 78702',
				'type'      => 'house',
				'city'      => 'austin',
				'featured'  => '0',
				'amenities' => array( 'EV Charging', 'Rainwater Harvesting', 'Quartz Counters', 'Walk to Dining' ),
				'agent'     => array( 'name' => 'Marcus Reed', 'phone' => '+1 (512) 555-0163' ),
			),
			array(
				'title'     => 'Sleek Downtown Loft with Exposed Brick',
				'content'   => 'Authentic industrial timber loft in the heart of the city. Original exposed brick, heavy timber beams, modern concrete countertops, and in-unit laundry.',
				'price'     => 525000,
				'bedrooms'  => 2,
				'bathrooms' => 2,
				'sqft'      => 1450,
				'address'   => '312 North May Street, Chicago, IL 60607',
				'type'      => 'apartment',
				'city'      => 'chicago',
				'featured'  => '0',
				'amenities' => array( 'Exposed Brick', 'Timber Beams', 'Rooftop Deck', 'Bike Storage' ),
				'agent'     => array( 'name' => 'David Kim', 'phone' => '+1 (312) 555-0177' ),
			),
		);

		foreach ( $seeds as $data ) {
			$pid = wp_insert_post(
				array(
					'post_type'    => self::POST_TYPE,
					'post_title'   => $data['title'],
					'post_content' => $data['content'],
					'post_status'  => 'publish',
				)
			);
			if ( $pid && ! is_wp_error( $pid ) ) {
				update_post_meta( $pid, '_wpwebmcp_real_estate_seed', '1' );
				update_post_meta( $pid, '_property_price', $data['price'] );
				update_post_meta( $pid, '_property_bedrooms', $data['bedrooms'] );
				update_post_meta( $pid, '_property_bathrooms', $data['bathrooms'] );
				update_post_meta( $pid, '_property_sqft', $data['sqft'] );
				update_post_meta( $pid, '_property_address', $data['address'] );
				update_post_meta( $pid, '_property_is_featured', $data['featured'] );
				update_post_meta( $pid, '_property_amenities', $data['amenities'] );
				update_post_meta( $pid, '_property_agent_name', $data['agent']['name'] );
				update_post_meta( $pid, '_property_agent_phone', $data['agent']['phone'] );

				wp_set_object_terms( $pid, $data['type'], self::TAX_TYPE );
				wp_set_object_terms( $pid, $data['city'], self::TAX_CITY );
			}
		}
	}
}
// phpcs:enable WordPress.DB.SlowDBQuery
