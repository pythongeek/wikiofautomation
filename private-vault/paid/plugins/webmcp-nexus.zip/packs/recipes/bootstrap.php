<?php
/**
 * Recipes pack bootstrap.
 *
 * A6 Vertical Tool Packs Marketplace — first free pack (recipes).
 *
 * Conventions exposed for the SDK loader:
 *   - Class:        WP_WebMCP_Pack_Recipes
 *   - install():    creates the recipe CPT + cuisines/dietary taxonomies, seeds
 *                   6 example recipes, and registers 7 tool rows in wpwebmcp_tools.
 *   - uninstall():  removes the seeded posts, deletes the tool rows, and clears
 *                   the install flag (CPT/taxonomies stay registered because WP
 *                   doesn't truly unregister them at runtime — operators can flush
 *                   permalinks after uninstall to drop the rewrite rules).
 *
 * The pack's tool runner hooks the wpwebmcp_pack_runner_recipes filter to receive
 * tool calls routed by the Pack_Filter_Bridge.
 *
 * @package WP_WebMCP_Pack_Recipes
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.DB.SlowDBQuery -- Pack tool queries require meta_query and tax_query for domain-specific filtering.
final class WP_WebMCP_Pack_Recipes {

	public const POST_TYPE   = 'recipe';
	public const TAX_CUISINE = 'cuisine';
	public const TAX_DIETARY = 'dietary';
	public const VERSION     = '1.0.0';

	/**
	 * Singleton entry point used by the registry to call install()/uninstall().
	 */
	public static function instance(): self {
		static $inst = null;
		if ( null === $inst ) {
			$inst = new self();
		}
		return $inst;
	}

	/**
	 * Boot hooks on every request. Called by WP_WebMCP_Pack_Loader when the pack
	 * is in the installed registry. Registers CPTs/taxonomies and the runner filter.
	 */
	public static function boot(): void {
		add_action( 'init', array( self::class, 'register_post_type' ), 9 );
		add_filter( 'wpwebmcp_pack_runner_recipes', array( self::class, 'run_tool' ), 10, 3 );
	}

	/* ============================================================
	 * CPT + taxonomy registration (idempotent — safe to call twice)
	 * ============================================================ */

	public static function register_post_type(): void {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'          => array(
					'name'          => __( 'Recipes', 'webmcp-nexus' ),
					'singular_name' => __( 'Recipe', 'webmcp-nexus' ),
					'add_new_item'  => __( 'Add New Recipe', 'webmcp-nexus' ),
					'edit_item'     => __( 'Edit Recipe', 'webmcp-nexus' ),
				),
				'public'         => true,
				'show_in_rest'   => true,
				'has_archive'    => true,
				'menu_icon'      => 'dashicons-food',
				'menu_position'  => 6,
				'supports'       => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'custom-fields' ),
				'rewrite'        => array( 'slug' => 'recipes' ),
			)
		);

		register_taxonomy(
			self::TAX_CUISINE,
			array( self::POST_TYPE ),
			array(
				'labels'        => array(
					'name'          => __( 'Cuisines', 'webmcp-nexus' ),
					'singular_name' => __( 'Cuisine', 'webmcp-nexus' ),
				),
				'public'        => true,
				'hierarchical'  => true,
				'show_in_rest'  => true,
				'rewrite'       => array( 'slug' => 'cuisine' ),
			)
		);

		register_taxonomy(
			self::TAX_DIETARY,
			array( self::POST_TYPE ),
			array(
				'labels'        => array(
					'name'          => __( 'Dietary', 'webmcp-nexus' ),
					'singular_name' => __( 'Dietary tag', 'webmcp-nexus' ),
				),
				'public'        => true,
				'hierarchical'  => false,
				'show_in_rest'  => true,
				'rewrite'       => array( 'slug' => 'dietary' ),
			)
		);
	}

	/* ============================================================
	 * Install routine
	 * ============================================================ */

	/**
	 * Install the pack.
	 *
	 * @param array $manifest Parsed manifest from WP_WebMCP_Pack_Manifest::parse().
	 * @return true|\WP_Error
	 */
	public static function install( array $manifest ) {
		// Make sure CPT/taxonomies exist before we insert posts.
		self::register_post_type();

		// Seed example recipes (idempotent: skip if any recipe exists).
		$existing = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => array( 'publish', 'draft' ),
				'posts_per_page' => 1,
				'fields'         => 'ids',
			)
		);
		if ( empty( $existing ) ) {
			self::seed_example_recipes();
		}

		// Register each tool row.
		foreach ( (array) ( $manifest['tools'] ?? array() ) as $tool ) {
			self::register_tool_row( $tool, $manifest );
		}

		return true;
	}

	/**
	 * Uninstall the pack.
	 *
	 * @param array $manifest Parsed manifest (for tool list).
	 * @return true
	 */
	public static function uninstall( array $manifest ) {
		// Delete tool rows first.
		foreach ( (array) ( $manifest['tools'] ?? array() ) as $tool ) {
			$tool_name = (string) ( $tool['name'] ?? $tool['key'] ?? '' );
			if ( '' === $tool_name ) {
				continue;
			}
			if ( class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
				$row = WP_WebMCP_Tool_Repository::find_by_slug( $tool_name );
				if ( $row ) {
					WP_WebMCP_Tool_Repository::delete( (int) $row['id'] );
				}
			}
		}

		// Delete seeded posts (those with _wpwebmcp_recipes_seed meta).
		$seeded = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_query'     => array(
					array(
						'key'     => '_wpwebmcp_recipes_seed',
						'compare' => 'EXISTS',
					),
				),
			)
		);
		foreach ( (array) $seeded as $pid ) {
			wp_delete_post( (int) $pid, true );
		}

		// Note: we do NOT call unregister_post_type / unregister_taxonomy here because
		// WordPress doesn't fully support runtime unregistration. Permalinks will keep
		// working until admin manually flushes them via Settings -> Permalinks.
		return true;
	}

	/* ============================================================
	 * Tool row registration
	 * ============================================================ */

	private static function register_tool_row( array $tool, array $manifest ): void {
		if ( ! class_exists( 'WP_WebMCP_Tool_Repository' ) ) {
			return;
		}

		$tool_name = (string) ( $tool['name'] ?? $tool['key'] ?? '' );
		if ( '' === $tool_name ) {
			return;
		}

		$data = array(
			'tool_name'        => $tool_name,
			'tool_description' => (string) ( $tool['description'] ?? '' ),
			'tool_type'        => 'read',
			'tool_scope'       => 'recipes',
			'action_type'      => 'hook',
			'action_value'     => 'recipes::' . (string) ( $tool['key'] ?? '' ),
			'parameters'       => isset( $tool['parameters'] ) ? (array) $tool['parameters'] : array(),
			'status'           => 'active',
		);

		WP_WebMCP_Tool_Repository::upsert_by_slug( $data );
	}

	/* ============================================================
	 * Tool runner (filter callback)
	 * ============================================================ */

	/**
	 * Receives a tool call routed by WP_WebMCP_Pack_Filter_Bridge.
	 *
	 * @param mixed  $default  Default response (returned unchanged on no-match).
	 * @param string $tool_key Tool key inside the recipes pack.
	 * @param array  $params   Tool call parameters.
	 * @return array|\WP_Error
	 */
	public static function run_tool( $default, string $tool_key, array $params ) {
		switch ( $tool_key ) {
			case 'search_recipes':
				return self::tool_search( $params );

			case 'get_recipe':
				return self::tool_get( $params );

			case 'list_recipe_cuisines':
				return self::tool_list_cuisines();

			case 'get_recipe_ingredients':
				return self::tool_get_ingredients( $params );

			case 'get_recipe_steps':
				return self::tool_get_steps( $params );

			case 'find_recipes_by_ingredient':
				return self::tool_find_by_ingredient( $params );

			case 'get_random_recipe':
				return self::tool_random( $params );

			default:
				return $default;
		}
	}

	/* ============================================================
	 * Tool implementations
	 * ============================================================ */

	private static function tool_search( array $params ): array {
		$max     = isset( $params['max'] ) ? max( 1, min( 25, (int) $params['max'] ) ) : 10;
		$query   = isset( $params['query'] ) ? trim( (string) $params['query'] ) : '';
		$cuisine = isset( $params['cuisine'] ) ? trim( (string) $params['cuisine'] ) : '';
		$dietary = isset( $params['dietary'] ) ? trim( (string) $params['dietary'] ) : '';

		$args = array(
			'post_type'      => self::POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => $max,
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		if ( '' !== $query ) {
			$args['s'] = $query;
		}

		$tax_query = array();
		if ( '' !== $cuisine ) {
			$tax_query[] = array(
				'taxonomy' => self::TAX_CUISINE,
				'field'    => 'slug',
				'terms'    => sanitize_title( $cuisine ),
			);
		}
		if ( '' !== $dietary ) {
			$tax_query[] = array(
				'taxonomy' => self::TAX_DIETARY,
				'field'    => 'slug',
				'terms'    => sanitize_title( $dietary ),
			);
		}
		if ( ! empty( $tax_query ) ) {
			$args['tax_query'] = $tax_query;
		}

		$posts = get_posts( $args );
		return array(
			'query'    => $query,
			'cuisine'  => $cuisine,
			'dietary'  => $dietary,
			'count'    => count( $posts ),
			'recipes'  => array_map( array( self::class, 'summarize_post' ), $posts ),
		);
	}

	private static function tool_get( array $params ): array {
		$recipe_id = isset( $params['recipe_id'] ) ? (int) $params['recipe_id'] : 0;
		if ( $recipe_id <= 0 ) {
			return array( 'error' => 'recipe_id is required.' );
		}
		$post = get_post( $recipe_id );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return array( 'error' => sprintf( 'No recipe found with id %d.', $recipe_id ) );
		}
		$summary         = self::summarize_post( $post );
		$summary['content'] = wp_strip_all_tags( (string) $post->post_content );
		return $summary;
	}

	private static function tool_list_cuisines(): array {
		$terms = get_terms(
			array(
				'taxonomy'   => self::TAX_CUISINE,
				'hide_empty' => false,
			)
		);
		if ( is_wp_error( $terms ) ) {
			return array( 'cuisines' => array(), 'error' => $terms->get_error_message() );
		}
		$out = array();
		foreach ( (array) $terms as $t ) {
			$out[] = array(
				'slug'  => (string) $t->slug,
				'name'  => (string) $t->name,
				'count' => (int) $t->count,
			);
		}
		return array( 'count' => count( $out ), 'cuisines' => $out );
	}

	private static function tool_get_ingredients( array $params ): array {
		$recipe_id = isset( $params['recipe_id'] ) ? (int) $params['recipe_id'] : 0;
		if ( $recipe_id <= 0 ) {
			return array( 'error' => 'recipe_id is required.' );
		}
		$ingredients = get_post_meta( $recipe_id, '_recipe_ingredients', true );
		if ( ! is_array( $ingredients ) ) {
			$ingredients = array();
		}
		return array(
			'recipe_id'   => $recipe_id,
			'ingredients' => array_values( array_map( 'strval', $ingredients ) ),
		);
	}

	private static function tool_get_steps( array $params ): array {
		$recipe_id = isset( $params['recipe_id'] ) ? (int) $params['recipe_id'] : 0;
		if ( $recipe_id <= 0 ) {
			return array( 'error' => 'recipe_id is required.' );
		}
		$steps = get_post_meta( $recipe_id, '_recipe_steps', true );
		if ( ! is_array( $steps ) ) {
			$steps = array();
		}
		return array(
			'recipe_id' => $recipe_id,
			'steps'     => array_values( array_map( 'strval', $steps ) ),
		);
	}

	private static function tool_find_by_ingredient( array $params ): array {
		$ingredient = isset( $params['ingredient'] ) ? trim( (string) $params['ingredient'] ) : '';
		$max        = isset( $params['max'] ) ? max( 1, min( 25, (int) $params['max'] ) ) : 10;
		if ( '' === $ingredient ) {
			return array( 'error' => 'ingredient is required.' );
		}

		// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- ingredient search across recipes by meta_value LIKE.
		$candidates = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 200, // bounded, then filter in PHP.
				'meta_query'     => array(
					array(
						'key'     => '_recipe_ingredients',
						'compare' => 'EXISTS',
					),
				),
			)
		);

		$matches = array();
		$needle  = strtolower( $ingredient );
		foreach ( (array) $candidates as $p ) {
			$ingredients = (array) get_post_meta( $p->ID, '_recipe_ingredients', true );
			foreach ( $ingredients as $line ) {
				if ( false !== strpos( strtolower( (string) $line ), $needle ) ) {
					$matches[] = $p;
					break;
				}
			}
			if ( count( $matches ) >= $max ) {
				break;
			}
		}

		return array(
			'ingredient' => $ingredient,
			'count'      => count( $matches ),
			'recipes'    => array_map( array( self::class, 'summarize_post' ), $matches ),
		);
	}

	private static function tool_random( array $params ): array {
		$cuisine = isset( $params['cuisine'] ) ? trim( (string) $params['cuisine'] ) : '';

		$args = array(
			'post_type'      => self::POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'orderby'        => 'rand',
		);
		if ( '' !== $cuisine ) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => self::TAX_CUISINE,
					'field'    => 'slug',
					'terms'    => sanitize_title( $cuisine ),
				),
			);
		}
		$posts = get_posts( $args );
		if ( empty( $posts ) ) {
			return array( 'recipe' => null, 'note' => 'No recipes found for the given filter.' );
		}
		return array( 'recipe' => self::summarize_post( $posts[0] ) );
	}

	/* ============================================================
	 * Helpers
	 * ============================================================ */

	/**
	 * Convert a recipe post to a JSON-safe summary object.
	 *
	 * @param \WP_Post $post Recipe post.
	 * @return array<string, mixed>
	 */
	private static function summarize_post( $post ): array {
		$cuisines = wp_get_post_terms( $post->ID, self::TAX_CUISINE, array( 'fields' => 'names' ) );
		$dietary  = wp_get_post_terms( $post->ID, self::TAX_DIETARY, array( 'fields' => 'names' ) );

		$prep_min  = (int) get_post_meta( $post->ID, '_recipe_prep_minutes', true );
		$cook_min  = (int) get_post_meta( $post->ID, '_recipe_cook_minutes', true );
		$servings  = (int) get_post_meta( $post->ID, '_recipe_servings', true );

		return array(
			'id'            => (int) $post->ID,
			'title'         => (string) $post->post_title,
			'slug'          => (string) $post->post_name,
			'excerpt'       => (string) $post->post_excerpt,
			'permalink'     => (string) get_permalink( $post->ID ),
			'cuisines'      => array_map( 'strval', is_array( $cuisines ) ? $cuisines : array() ),
			'dietary'       => array_map( 'strval', is_array( $dietary ) ? $dietary : array() ),
			'prep_minutes'  => $prep_min,
			'cook_minutes'  => $cook_min,
			'total_minutes' => $prep_min + $cook_min,
			'servings'      => $servings,
		);
	}

	/* ============================================================
	 * Seed data — 6 example recipes on first install.
	 * ============================================================ */

	private static function seed_example_recipes(): void {
		$examples = array(
			array(
				'title'    => 'Spaghetti Aglio e Olio',
				'cuisine'  => 'italian',
				'dietary'  => array( 'vegetarian' ),
				'prep'     => 5,
				'cook'     => 15,
				'servings' => 2,
				'ing'      => array(
					'200g spaghetti',
					'4 cloves garlic, thinly sliced',
					'60ml extra-virgin olive oil',
					'1 tsp red pepper flakes',
					'30g fresh parsley, chopped',
					'Salt to taste',
					'Lemon zest from 1 lemon',
				),
				'steps'    => array(
					'Bring a large pot of generously salted water to a boil.',
					'Cook spaghetti until al dente, reserving 1 cup pasta water.',
					'In a wide pan, warm olive oil over medium-low heat and add sliced garlic. Cook gently until pale gold, about 3 minutes.',
					'Add red pepper flakes and half the parsley; stir once.',
					'Toss drained pasta into the pan with a splash of pasta water. Stir vigorously to emulsify.',
					'Finish with lemon zest, remaining parsley, and salt. Serve immediately.',
				),
				'excerpt'  => 'A 20-minute weeknight classic — garlic, olive oil, chili, parsley.',
			),
			array(
				'title'    => 'Miso-Glazed Salmon',
				'cuisine'  => 'japanese',
				'dietary'  => array( 'gluten-free' ),
				'prep'     => 10,
				'cook'     => 15,
				'servings' => 2,
				'ing'      => array(
					'2 salmon fillets (150g each)',
					'3 tbsp white miso paste',
					'1 tbsp mirin',
					'1 tbsp sake',
					'1 tsp honey',
					'1 tsp grated ginger',
					'Sesame seeds and scallions to garnish',
				),
				'steps'    => array(
					'Whisk miso, mirin, sake, honey, and ginger into a smooth glaze.',
					'Pat salmon dry and brush generously with the glaze. Marinate 10 minutes.',
					'Preheat broiler to high. Line a tray with foil.',
					'Broil salmon 8-10 cm from heat for 8-10 minutes until caramelized.',
					'Garnish with sesame seeds and sliced scallions. Serve with rice and greens.',
				),
				'excerpt'  => 'Sweet-savory glaze caramelizes under the broiler for a glossy finish.',
			),
			array(
				'title'    => 'Chickpea & Coconut Curry',
				'cuisine'  => 'indian',
				'dietary'  => array( 'vegan', 'gluten-free' ),
				'prep'     => 10,
				'cook'     => 25,
				'servings' => 4,
				'ing'      => array(
					'2 tbsp coconut oil',
					'1 large onion, diced',
					'3 cloves garlic, minced',
					'1 tbsp grated ginger',
					'2 tbsp curry powder',
					'1 tsp ground turmeric',
					'400g canned chickpeas, drained',
					'400ml full-fat coconut milk',
					'200g baby spinach',
					'Juice of 1 lime',
					'Salt to taste',
				),
				'steps'    => array(
					'Heat coconut oil in a heavy pot over medium heat.',
					'Sauté onion until translucent, about 5 minutes. Add garlic and ginger; cook 1 minute.',
					'Stir in curry powder and turmeric; toast 30 seconds until fragrant.',
					'Add chickpeas and coconut milk. Simmer 15 minutes.',
					'Stir in spinach until wilted. Finish with lime juice and salt.',
					'Serve over basmati rice or with naan.',
				),
				'excerpt'  => 'Pantry-friendly, weeknight-easy, deeply comforting.',
			),
			array(
				'title'    => 'Classic Margherita Pizza',
				'cuisine'  => 'italian',
				'dietary'  => array( 'vegetarian' ),
				'prep'     => 15,
				'cook'     => 12,
				'servings' => 2,
				'ing'      => array(
					'1 ball (250g) pizza dough',
					'80g San Marzano tomatoes, hand-crushed',
					'100g fresh mozzarella, torn',
					'Fresh basil leaves',
					'2 tbsp olive oil',
					'Salt to taste',
				),
				'steps'    => array(
					'Preheat oven and pizza stone to 250°C.',
					'Stretch dough into a 30cm round on parchment.',
					'Spread crushed tomatoes thinly, leaving a 1cm border.',
					'Scatter mozzarella and a pinch of salt.',
					'Bake 8-10 minutes until crust is blistered and cheese bubbles.',
					'Top with basil and a drizzle of olive oil. Slice and serve.',
				),
				'excerpt'  => 'The Neapolitan classic — three toppings done right.',
			),
			array(
				'title'    => 'Lemon-Herb Roast Chicken',
				'cuisine'  => 'french',
				'dietary'  => array( 'gluten-free' ),
				'prep'     => 15,
				'cook'     => 75,
				'servings' => 4,
				'ing'      => array(
					'1 whole chicken (1.5 kg)',
					'1 lemon, halved',
					'4 cloves garlic',
					'3 tbsp fresh thyme',
					'3 tbsp fresh rosemary',
					'3 tbsp olive oil',
					'Salt and pepper to taste',
				),
				'steps'    => array(
					'Preheat oven to 200°C.',
					'Pat chicken dry. Rub all over with olive oil, salt, and pepper.',
					'Stuff cavity with lemon halves, garlic, and half the herbs.',
					'Tuck remaining herbs under the skin and over the breast.',
					'Roast 65-75 minutes until juices run clear and skin is golden.',
					'Rest 10 minutes before carving. Spoon pan juices over to serve.',
				),
				'excerpt'  => 'Sunday-roast classic with crispy skin and bright, herby aromatics.',
			),
			array(
				'title'    => 'Avocado Toast with Chili Crisp',
				'cuisine'  => 'modern',
				'dietary'  => array( 'vegan', 'vegetarian' ),
				'prep'     => 5,
				'cook'     => 3,
				'servings' => 1,
				'ing'      => array(
					'1 thick slice sourdough bread',
					'1 ripe avocado',
					'1 tsp lemon juice',
					'1 tsp chili crisp',
					'Flaky salt to taste',
					'Sliced radish and microgreens (optional)',
				),
				'steps'    => array(
					'Toast sourdough until deeply golden.',
					'Mash avocado with lemon juice and a pinch of salt.',
					'Spread avocado generously over toast.',
					'Top with chili crisp, flaky salt, and radish slices if using.',
					'Eat immediately while toast is warm.',
				),
				'excerpt'  => 'Five-minute breakfast with big flavor payoff.',
			),
		);

		foreach ( $examples as $r ) {
			$post_id = wp_insert_post(
				array(
					'post_type'    => self::POST_TYPE,
					'post_status'  => 'publish',
					'post_title'   => (string) $r['title'],
					'post_name'    => sanitize_title( (string) $r['title'] ),
					'post_excerpt' => (string) $r['excerpt'],
					'post_content' => '',
				),
				true
			);
			if ( is_wp_error( $post_id ) || ! $post_id ) {
				continue;
			}

			update_post_meta( $post_id, '_wpwebmcp_recipes_seed', 1 );
			update_post_meta( $post_id, '_recipe_ingredients', $r['ing'] );
			update_post_meta( $post_id, '_recipe_steps', $r['steps'] );
			update_post_meta( $post_id, '_recipe_prep_minutes', $r['prep'] );
			update_post_meta( $post_id, '_recipe_cook_minutes', $r['cook'] );
			update_post_meta( $post_id, '_recipe_servings', $r['servings'] );

			if ( ! empty( $r['cuisine'] ) ) {
				wp_set_object_terms( $post_id, (string) $r['cuisine'], self::TAX_CUISINE );
			}
			if ( ! empty( $r['dietary'] ) ) {
				wp_set_object_terms( $post_id, (array) $r['dietary'], self::TAX_DIETARY );
			}
		}
	}
}

/* ============================================================
 * Compatibility shim — let the registry call install/uninstall via class
 * methods on WP_WebMCP_Pack_Recipes (in addition to the static methods).
 * ============================================================ */

WP_WebMCP_Pack_Recipes::boot();
// phpcs:enable WordPress.DB.SlowDBQuery
