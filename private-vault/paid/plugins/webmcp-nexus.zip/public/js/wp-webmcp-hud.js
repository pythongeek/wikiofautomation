/**
 * WebMCP Nexus — Frontend Agent HUD & Interactive Inspector Controller.
 * Enables live testing of WebMCP tools, manifest inspection, agent simulation,
 * and seamless MCP Client connection (Claude Desktop, Cursor, WebMCP.dev).
 */

(function () {
	'use strict';

	function initHUD() {
		// Only run once
		if (document.getElementById('wpwm-hud-root')) {
			return;
		}

		var manifestScript = document.getElementById('webmcp-manifest');
		var manifestData = null;
		if (manifestScript && manifestScript.textContent) {
			try {
				manifestData = JSON.parse(manifestScript.textContent);
			} catch (e) {
				console.warn('[WebMCP HUD] Failed to parse manifest:', e);
			}
		}

		var tools = (manifestData && Array.isArray(manifestData.tools)) ? manifestData.tools : [];
		var policyEl = document.querySelector('meta[name="webmcp-policy"]');
		var policyContent = policyEl ? policyEl.getAttribute('content') : 'allow=read-tools';
		var cfg = window.WPWEBMCP || {};

		var siteOrigin = window.location.origin || '';
		var mcpEndpoint = cfg.mcpUrl || (cfg.restUrl ? cfg.restUrl.replace(/\/call\/?$/, '/mcp') : (siteOrigin + '/wp-json/wpwebmcp/v1/mcp'));
		var sseEndpoint = cfg.sseUrl || (cfg.restUrl ? cfg.restUrl.replace(/\/call\/?$/, '/sse') : (siteOrigin + '/wp-json/wpwebmcp/v1/sse'));

		var claudeConfigSnippet = JSON.stringify({
			mcpServers: {
				webmcp_site: {
					url: mcpEndpoint
				}
			}
		}, null, 2);

		var webmcpDevSnippet = JSON.stringify({
			mcpServers: {
				webmcp: {
					command: "npx",
					args: ["-y", "@jason.today/webmcp@latest", "--mcp"]
				}
			}
		}, null, 2);

		// Container
		var root = document.createElement('div');
		root.id = 'wpwm-hud-root';

		// 1. Floating Pill Button
		var pill = document.createElement('div');
		pill.className = 'wpwm-hud-pill';
		pill.setAttribute('role', 'button');
		pill.setAttribute('aria-label', 'Open WebMCP Agent Inspector');
		pill.innerHTML =
			'<div class="wpwm-hud-pill-dot"></div>' +
			'<div class="wpwm-hud-pill-title">' +
			'<span>WebMCP Active</span>' +
			'<span class="wpwm-hud-pill-badge">' + tools.length + ' Tools</span>' +
			'</div>';

		// 2. Backdrop
		var backdrop = document.createElement('div');
		backdrop.className = 'wpwm-hud-backdrop';

		// 3. Slide-over Deck
		var deck = document.createElement('div');
		deck.className = 'wpwm-hud-deck';
		deck.innerHTML =
			'<div class="wpwm-hud-header">' +
			'  <div class="wpwm-hud-brand">' +
			'    <div class="wpwm-hud-logo">⚡</div>' +
			'    <div>' +
			'      <h3 class="wpwm-hud-title">WebMCP Agent Inspector</h3>' +
			'      <p class="wpwm-hud-subtitle">Live AI Agent Tools &amp; Protocol Playground</p>' +
			'    </div>' +
			'  </div>' +
			'  <button type="button" class="wpwm-hud-close" aria-label="Close Inspector">&times;</button>' +
			'</div>' +
			'<div class="wpwm-hud-tabs">' +
			'  <button type="button" class="wpwm-hud-tab wpwm-active" data-tab="playground">Playground</button>' +
			'  <button type="button" class="wpwm-hud-tab" data-tab="connect">Connect Clients</button>' +
			'  <button type="button" class="wpwm-hud-tab" data-tab="manifest">Manifest JSON</button>' +
			'  <button type="button" class="wpwm-hud-tab" data-tab="status">Protocol Status</button>' +
			'</div>' +
			'<div class="wpwm-hud-body">' +
			'  <!-- TAB 1: PLAYGROUND -->' +
			'  <div class="wpwm-hud-section wpwm-active" id="wpwm-tab-playground">' +
			'    <div class="wpwm-hud-field">' +
			'      <label class="wpwm-hud-label" for="wpwm-tool-select">Select Available Tool</label>' +
			'      <select id="wpwm-tool-select" class="wpwm-hud-select"></select>' +
			'    </div>' +
			'    <div id="wpwm-tool-desc" class="wpwm-hud-desc"></div>' +
			'    <form id="wpwm-params-form"></form>' +
			'    <button type="button" id="wpwm-run-btn" class="wpwm-hud-btn">' +
			'      <span>▶ Run Tool Call</span>' +
			'    </button>' +
			'    <div id="wpwm-result-container" class="wpwm-hud-result-box" style="display:none;">' +
			'      <div class="wpwm-hud-result-header">' +
			'        <span id="wpwm-res-status" class="wpwm-hud-badge-pill">200 OK (32ms)</span>' +
			'        <button type="button" id="wpwm-copy-res" class="wpwm-hud-copy-btn">Copy JSON</button>' +
			'      </div>' +
			'      <pre id="wpwm-result-code" class="wpwm-hud-code"></pre>' +
			'    </div>' +
			'  </div>' +
			'  <!-- TAB 2: CONNECT CLIENTS -->' +
			'  <div class="wpwm-hud-section" id="wpwm-tab-connect">' +
			'    <p style="font-size:12px; color:var(--wpwm-hud-text-muted); line-height:1.5; margin-bottom:12px;">' +
			'      Connect your desktop MCP client (Claude Desktop, Cursor, Windsurf, or WebMCP.dev bridge) directly to this site:' +
			'    </p>' +
			'    <div class="wpwm-hud-field">' +
			'      <div style="display:flex; justify-content:space-between; align-items:center;">' +
			'        <label class="wpwm-hud-label">Claude Desktop Configuration (claude_desktop_config.json)</label>' +
			'        <button type="button" id="wpwm-copy-claude-cfg" class="wpwm-hud-copy-btn">Copy Config</button>' +
			'      </div>' +
			'      <div class="wpwm-hud-result-box">' +
			'        <pre id="wpwm-claude-cfg-code" class="wpwm-hud-code">' + escapeHtml(claudeConfigSnippet) + '</pre>' +
			'      </div>' +
			'    </div>' +
			'    <div class="wpwm-hud-field" style="margin-top:14px;">' +
			'      <div style="display:flex; justify-content:space-between; align-items:center;">' +
			'        <label class="wpwm-hud-label">WebMCP.dev Bridge Client (@jason.today/webmcp)</label>' +
			'        <button type="button" id="wpwm-copy-webmcp-cfg" class="wpwm-hud-copy-btn">Copy Config</button>' +
			'      </div>' +
			'      <div class="wpwm-hud-result-box">' +
			'        <pre id="wpwm-webmcp-cfg-code" class="wpwm-hud-code">' + escapeHtml(webmcpDevSnippet) + '</pre>' +
			'      </div>' +
			'    </div>' +
			'    <div style="margin-top:14px; padding:10px; background:rgba(79,70,229,0.1); border:1px solid rgba(79,70,229,0.3); border-radius:6px;">' +
			'      <span style="font-size:11px; font-weight:bold; color:var(--wpwm-hud-neon-green);">DIRECT MCP ENDPOINTS:</span>' +
			'      <div style="font-size:11px; color:#cbd5e1; margin-top:4px; font-family:monospace; word-break:break-all;">' +
			'        JSON-RPC: ' + escapeHtml(mcpEndpoint) + '<br>' +
			'        SSE Stream: ' + escapeHtml(sseEndpoint) +
			'      </div>' +
			'    </div>' +
			'  </div>' +
			'  <!-- TAB 3: MANIFEST -->' +
			'  <div class="wpwm-hud-section" id="wpwm-tab-manifest">' +
			'    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">' +
			'      <span style="font-size:12px; color:var(--wpwm-hud-text-muted);">Page Context: <strong>' + (cfg.pageType || 'General') + '</strong></span>' +
			'      <button type="button" id="wpwm-copy-manifest" class="wpwm-hud-copy-btn">Copy Manifest</button>' +
			'    </div>' +
			'    <div class="wpwm-hud-result-box">' +
			'      <pre id="wpwm-manifest-code" class="wpwm-hud-code">' + escapeHtml(JSON.stringify(manifestData, null, 2)) + '</pre>' +
			'    </div>' +
			'  </div>' +
			'  <!-- TAB 4: STATUS -->' +
			'  <div class="wpwm-hud-section" id="wpwm-tab-status">' +
			'    <div class="wpwm-hud-grid">' +
			'      <div class="wpwm-hud-stat-tile">' +
			'        <div class="wpwm-hud-stat-tile-val">' + tools.length + '</div>' +
			'        <div class="wpwm-hud-stat-tile-lbl">Exposed Tools</div>' +
			'      </div>' +
			'      <div class="wpwm-hud-stat-tile">' +
			'        <div class="wpwm-hud-stat-tile-val" style="color:var(--wpwm-hud-neon-green);">Compliant</div>' +
			'        <div class="wpwm-hud-stat-tile-lbl">W3C / WebMCP.dev / MCP</div>' +
			'      </div>' +
			'    </div>' +
			'    <div class="wpwm-hud-desc">' +
			'      <strong>WebMCP Policy:</strong> ' + escapeHtml(policyContent) +
			'    </div>' +
			'    <div style="margin-top:16px;">' +
			'      <p style="font-size:12px; color:var(--wpwm-hud-text-muted); line-height:1.5;">' +
			'        This page exposes structured tools, prompts, and resources to AI agents (Claude, Cursor, Gemini, OpenAI) via browser <code>navigator.modelContext</code>, <code>document.modelContext</code>, and <code>window.webmcp</code>.' +
			'      </p>' +
			'      <div style="display:flex; gap:8px; margin-top:12px; flex-wrap:wrap;">' +
			'        <a href="/llms.txt" target="_blank" class="wpwm-hud-copy-btn" style="text-decoration:none;">Open /llms.txt</a>' +
			'        <a href="/.well-known/mcp.json" target="_blank" class="wpwm-hud-copy-btn" style="text-decoration:none;">Open /mcp.json</a>' +
			'        <a href="/.well-known/agent.json" target="_blank" class="wpwm-hud-copy-btn" style="text-decoration:none;">Open /agent.json</a>' +
			'      </div>' +
			'    </div>' +
			'  </div>' +
			'</div>';

		root.appendChild(pill);
		root.appendChild(backdrop);
		root.appendChild(deck);
		document.body.appendChild(root);

		// Event handlers
		function toggleDeck(open) {
			if (open) {
				deck.classList.add('wpwm-open');
				backdrop.classList.add('wpwm-open');
			} else {
				deck.classList.remove('wpwm-open');
				backdrop.classList.remove('wpwm-open');
			}
		}

		pill.addEventListener('click', function () { toggleDeck(true); });
		backdrop.addEventListener('click', function () { toggleDeck(false); });
		deck.querySelector('.wpwm-hud-close').addEventListener('click', function () { toggleDeck(false); });

		// Tab switching
		var tabs = deck.querySelectorAll('.wpwm-hud-tab');
		tabs.forEach(function (tab) {
			tab.addEventListener('click', function () {
				tabs.forEach(function (t) { t.classList.remove('wpwm-active'); });
				tab.classList.add('wpwm-active');
				var target = tab.getAttribute('data-tab');
				deck.querySelectorAll('.wpwm-hud-section').forEach(function (sec) {
					sec.classList.remove('wpwm-active');
				});
				var targetSec = deck.querySelector('#wpwm-tab-' + target);
				if (targetSec) { targetSec.classList.add('wpwm-active'); }
			});
		});

		// Populate Tools dropdown
		var toolSelect = deck.querySelector('#wpwm-tool-select');
		var descEl = deck.querySelector('#wpwm-tool-desc');
		var paramsForm = deck.querySelector('#wpwm-params-form');

		if (tools.length === 0) {
			toolSelect.innerHTML = '<option value="">No tools active on this page</option>';
			descEl.textContent = 'Tools are either disabled or excluded for this specific view.';
		} else {
			tools.forEach(function (t) {
				var opt = document.createElement('option');
				opt.value = t.name;
				opt.textContent = t.name;
				toolSelect.appendChild(opt);
			});

			function renderParams(toolName) {
				var tool = tools.find(function (t) { return t.name === toolName; });
				if (!tool) { return; }

				descEl.textContent = tool.description || 'No description provided.';
				paramsForm.innerHTML = '';

				var schema = tool.inputSchema || {};
				var props = schema.properties || {};
				var required = Array.isArray(schema.required) ? schema.required : [];

				var propKeys = Object.keys(props);
				if (propKeys.length === 0) {
					var emptyP = document.createElement('p');
					emptyP.style.fontSize = '12px';
					emptyP.style.color = 'var(--wpwm-hud-text-muted)';
					emptyP.textContent = 'This tool takes no parameters (runs directly).';
					paramsForm.appendChild(emptyP);
					return;
				}

				propKeys.forEach(function (key) {
					var spec = props[key] || {};
					var isReq = required.includes(key);
					var fieldBox = document.createElement('div');
					fieldBox.className = 'wpwm-hud-field';

					var label = document.createElement('label');
					label.className = 'wpwm-hud-label';
					label.setAttribute('for', 'wpwm-input-' + key);
					label.textContent = key + (isReq ? ' *' : '');
					fieldBox.appendChild(label);

					var input;
					if (spec.enum && Array.isArray(spec.enum)) {
						input = document.createElement('select');
						input.className = 'wpwm-hud-select';
						spec.enum.forEach(function (ev) {
							var eo = document.createElement('option');
							eo.value = ev;
							eo.textContent = ev;
							input.appendChild(eo);
						});
					} else if (spec.type === 'integer' || spec.type === 'number') {
						input = document.createElement('input');
						input.type = 'number';
						input.className = 'wpwm-hud-input';
						if (typeof spec.minimum === 'number') input.min = spec.minimum;
						if (typeof spec.maximum === 'number') input.max = spec.maximum;
						if (typeof spec.default !== 'undefined') {
							input.value = spec.default;
						} else if ((key === 'post_id' || key === 'id' || key === 'postId' || key === 'video_id' || key === 'event_id') && cfg.postId) {
							input.value = cfg.postId;
							input.placeholder = 'Defaults to current post (' + cfg.postId + ')';
						} else if (key === 'limit') {
							input.value = 5;
						}
					} else {
						input = document.createElement('input');
						input.type = 'text';
						input.className = 'wpwm-hud-input';
						if ((key === 'post_id' || key === 'id' || key === 'postId') && cfg.postId) {
							input.value = cfg.postId;
							input.placeholder = 'Defaults to current post (' + cfg.postId + ')';
						} else if (key === 'query' || key === 's') {
							input.placeholder = 'e.g. search keyword';
							input.value = 'WordPress';
						} else if (key === 'path') {
							input.placeholder = 'e.g. / or /category/news/';
							input.value = '/';
						} else if (key === 'topic' || key === 'category') {
							input.placeholder = 'e.g. general or news';
							input.value = 'general';
						}
					}

					input.name = key;
					input.id = 'wpwm-input-' + key;
					if (isReq) input.required = true;
					fieldBox.appendChild(input);
					paramsForm.appendChild(fieldBox);
				});
			}

			toolSelect.addEventListener('change', function () {
				renderParams(this.value);
			});

			if (tools[0]) {
				renderParams(tools[0].name);
			}
		}

		// Run Tool Call
		var runBtn = deck.querySelector('#wpwm-run-btn');
		var resContainer = deck.querySelector('#wpwm-result-container');
		var resCode = deck.querySelector('#wpwm-result-code');
		var resStatus = deck.querySelector('#wpwm-res-status');

		runBtn.addEventListener('click', function () {
			var toolName = toolSelect.value;
			if (!toolName) { return; }

			var formData = new FormData(paramsForm);
			var params = {};
			formData.forEach(function (val, key) {
				if (val !== '') {
					params[key] = !isNaN(val) && val.trim() !== '' ? Number(val) : val;
				}
			});

			if (cfg.postId && !params.post_id && !params.postId && !params.id) {
				params.post_id = Number(cfg.postId);
			}

			runBtn.disabled = true;
			runBtn.textContent = 'Executing...';
			var startTime = performance.now();

			var callUrl = (cfg.restUrl || '/wp-json/wpwebmcp/v1/call/') + encodeURIComponent(toolName);
			var nonce = cfg.nonce || '';

			fetch(callUrl, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': nonce
				},
				body: JSON.stringify(params)
			})
			.then(function (r) {
				var ms = Math.round(performance.now() - startTime);
				resStatus.textContent = r.status + ' ' + r.statusText + ' (' + ms + 'ms)';
				if (r.ok) {
					resStatus.style.background = 'var(--wpwm-hud-neon-green-glow)';
					resStatus.style.borderColor = 'var(--wpwm-hud-neon-green)';
					resStatus.style.color = 'var(--wpwm-hud-neon-green)';
				} else {
					resStatus.style.background = 'rgba(239, 68, 68, 0.2)';
					resStatus.style.borderColor = '#ef4444';
					resStatus.style.color = '#ef4444';
				}
				return r.json();
			})
			.then(function (data) {
				resContainer.style.display = 'block';
				resCode.textContent = JSON.stringify(data, null, 2);
			})
			.catch(function (err) {
				resContainer.style.display = 'block';
				resStatus.textContent = 'Network Error';
				resCode.textContent = JSON.stringify({ error: err.message }, null, 2);
			})
			.finally(function () {
				runBtn.disabled = false;
				runBtn.innerHTML = '<span>▶ Run Tool Call</span>';
			});
		});

		// Copy Buttons
		deck.querySelector('#wpwm-copy-res').addEventListener('click', function () {
			navigator.clipboard.writeText(resCode.textContent).then(function () {
				alert('Tool result copied to clipboard!');
			});
		});

		deck.querySelector('#wpwm-copy-manifest').addEventListener('click', function () {
			navigator.clipboard.writeText(JSON.stringify(manifestData, null, 2)).then(function () {
				alert('Manifest JSON copied to clipboard!');
			});
		});

		deck.querySelector('#wpwm-copy-claude-cfg').addEventListener('click', function () {
			navigator.clipboard.writeText(claudeConfigSnippet).then(function () {
				alert('Claude Desktop config copied to clipboard!');
			});
		});

		deck.querySelector('#wpwm-copy-webmcp-cfg').addEventListener('click', function () {
			navigator.clipboard.writeText(webmcpDevSnippet).then(function () {
				alert('WebMCP bridge config copied to clipboard!');
			});
		});
	}

	function escapeHtml(str) {
		return String(str || '').replace(/[&<>"']/g, function (c) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initHUD);
	} else {
		initHUD();
	}
})();
