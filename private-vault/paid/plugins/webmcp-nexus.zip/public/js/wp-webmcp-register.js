/*!
 * WebMCP Nexus — registration runner (W3C WebMCP, Chrome ModelContext & WebMCP.dev spec).
 *
 * Reads the manifest from #webmcp-manifest and declarative forms, registers
 * every tool via navigator.modelContext, document.modelContext, and window.webmcp
 * using registerTool(), provideContext(), registerPrompt(), and registerResource().
 *
 * Localized vars (window.WPWEBMCP, exactly 8):
 *   restUrl, nonce, analyticsUrl, postId, pageType, userRole,
 *   performanceMode, ga4Enabled
 *
 * @package WP_WebMCP
 * @since   1.0.0
 */
(function () {
	'use strict';

	if (typeof window === 'undefined' || typeof document === 'undefined') {
		return;
	}

	var WPWEBMCP = window.WPWEBMCP || {};
	var MAX_BODY_BYTES = 16 * 1024;
	var registered = false;
	var globalAbortController = (typeof AbortController !== 'undefined') ? new AbortController() : null;

	/* ---------------- helpers ---------------- */

	function readManifest() {
		var el = document.getElementById('webmcp-manifest');
		if (!el) {
			return null;
		}
		try {
			var text = el.textContent || el.innerHTML || '{}';
			return JSON.parse(text);
		} catch (e) {
			return null;
		}
	}

	function scanDeclarativeForms() {
		var formTools = [];
		try {
			var forms = document.querySelectorAll('form[toolname]');
			for (var i = 0; i < forms.length; i++) {
				var form = forms[i];
				var name = form.getAttribute('toolname');
				if (!name) continue;

				var desc = form.getAttribute('tooldescription') || ('Submit ' + name + ' form');
				var properties = {};
				var required = [];

				var inputs = form.querySelectorAll('input, select, textarea');
				for (var j = 0; j < inputs.length; j++) {
					var input = inputs[j];
					var inputName = input.name || input.id;
					if (!inputName || input.type === 'submit' || input.type === 'button') continue;

					var paramDesc = input.getAttribute('toolparamdescription') || input.getAttribute('placeholder') || inputName;
					properties[inputName] = {
						type: input.type === 'number' ? 'integer' : 'string',
						description: paramDesc
					};
					if (input.hasAttribute('required')) {
						required.push(inputName);
					}
				}

				var isWrite = form.method && form.method.toUpperCase() === 'POST';
				formTools.push({
					name: name,
					description: desc,
					inputSchema: {
						type: 'object',
						properties: properties,
						required: required
					},
					annotations: {
						readOnlyHint: !isWrite,
						untrustedContentHint: false
					},
					exposedTo: ['*'],
					'x-webmcp-type': isWrite ? 'write' : 'read',
					'x-webmcp-form-element': form
				});
			}
		} catch (e) {
			// No-op
		}
		return formTools;
	}

	function getRegistries() {
		var list = [];
		// 1. document.modelContext (Chrome 150+ standard)
		if (typeof document !== 'undefined' && document.modelContext) {
			list.push(document.modelContext);
		}
		// 2. navigator.modelContext (Chrome 146-149 standard & polyfill)
		if (typeof navigator !== 'undefined' && navigator.modelContext) {
			if (list.indexOf(navigator.modelContext) === -1) {
				list.push(navigator.modelContext);
			}
		}
		// 3. window.modelContext & window.webmcp
		if (typeof window !== 'undefined') {
			if (window.webmcp && list.indexOf(window.webmcp) === -1) {
				list.push(window.webmcp);
			}
			if (window.modelContext && list.indexOf(window.modelContext) === -1) {
				list.push(window.modelContext);
			}
		}
		return list;
	}

	function isSameOrigin(urlString) {
		try {
			var u = new URL(urlString, window.location.origin);
			return u.origin === window.location.origin;
		} catch (e) {
			return false;
		}
	}

	function sendBeacon(analyticsUrl, toolName, postId) {
		if (typeof navigator === 'undefined' || typeof navigator.sendBeacon !== 'function' || !analyticsUrl) {
			return;
		}
		try {
			var blob = new Blob(
				[JSON.stringify({ tool: toolName, post_id: postId })],
				{ type: 'application/json' }
			);
			navigator.sendBeacon(analyticsUrl, blob);
		} catch (e) {
			// No-op. Beacon is best-effort; never throw.
		}
	}

	function fireGA4Event(toolName, postId) {
		try {
			if (typeof window.gtag !== 'function') {
				return;
			}
			window.gtag('event', 'webmcp_tool_call', {
				tool_name: toolName,
				post_id: postId
			});
		} catch (e) {
			// No-op.
		}
	}

	function buildExecuteFn(tool) {
		return function execute(params) {
			params = params || {};

			// Navigate action_type (custom tools only).
			if (tool['x-webmcp-action'] === 'navigate') {
				var target = tool['x-webmcp-action-value'] || (params && params.path) || '';
				if (!target) {
					return Promise.resolve({ ok: false, error: 'empty_navigate_target' });
				}
				if (!isSameOrigin(target)) {
					return Promise.resolve({ ok: false, error: 'cross_origin_blocked' });
				}
				try {
					window.location.href = target;
					return Promise.resolve({ ok: true, result: 'navigated', url: target });
				} catch (e) {
					return Promise.resolve({ ok: false, error: 'navigate_failed' });
				}
			}

			// Form auto-fill & submission if attached to a declarative form
			if (tool['x-webmcp-form-element'] && typeof tool['x-webmcp-form-element'].submit === 'function') {
				try {
					var form = tool['x-webmcp-form-element'];
					for (var fieldName in params) {
						if (Object.prototype.hasOwnProperty.call(params, fieldName)) {
							var field = form.elements[fieldName];
							if (field) field.value = params[fieldName];
						}
					}
					if (form.getAttribute('toolautosubmit') !== null) {
						form.submit();
						return Promise.resolve({ ok: true, result: 'form_submitted', form: tool.name });
					}
				} catch (err) {
					// Fallback to REST call
				}
			}

			// Default: POST to REST endpoint.
			var body = JSON.stringify({
				tool: tool.name,
				params: params,
				arguments: params,
				post_id: WPWEBMCP.postId || 0
			});
			if (body.length > MAX_BODY_BYTES) {
				return Promise.resolve({ ok: false, error: 'payload_too_large' });
			}

			var base = WPWEBMCP.restUrl || '/wp-json/wpwebmcp/v1/call/';
			if (base.charAt(base.length - 1) !== '/') {
				base += '/';
			}
			if (base.indexOf('/call/') === -1) {
				base += 'call/';
			}
			var callUrl = base + encodeURIComponent(tool.name);

			return fetch(callUrl, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': WPWEBMCP.nonce || ''
				},
				credentials: 'include',
				body: body
			}).then(function (resp) {
				if (!resp || !resp.ok) {
					return resp ? resp.json().catch(function () { return { ok: false, status: resp.status }; }) : { ok: false };
				}
				return resp.json();
			}).then(function (data) {
				if (data && data.ok !== false) {
					if (WPWEBMCP.analyticsUrl) {
						sendBeacon(WPWEBMCP.analyticsUrl, tool.name, WPWEBMCP.postId || 0);
					}
					if (WPWEBMCP.ga4Enabled) {
						fireGA4Event(tool.name, WPWEBMCP.postId || 0);
					}
				}
				return data;
			}).catch(function (err) {
				return { ok: false, error: 'network_error', message: err ? err.message : '' };
			});
		};
	}

	function registerStandardWebMCPResourcesAndPrompts() {
		if (!window.webmcp) return;

		// 1. Resources (WebMCP.dev format)
		window.webmcp.registerResource(
			'page-content',
			'Current page HTML and DOM structure',
			{ uri: 'page://current', mimeType: 'text/html' },
			function (uri) {
				return {
					contents: [
						{ uri: uri, mimeType: 'text/html', text: (document.body ? document.body.innerHTML : '') }
					]
				};
			}
		);

		window.webmcp.registerResource(
			'element-content',
			'Content of a specific DOM element by ID',
			{ uriTemplate: 'element://{elementId}', mimeType: 'text/html' },
			function (uri) {
				var elementId = uri.replace('element://', '');
				var element = document.getElementById(elementId);
				if (!element) {
					throw new Error('Element with ID "' + elementId + '" not found');
				}
				return {
					contents: [
						{ uri: uri, mimeType: 'text/html', text: element.innerHTML }
					]
				};
			}
		);

		window.webmcp.registerResource(
			'site-info',
			'WordPress site metadata and active configuration',
			{ uri: 'wp://siteinfo', mimeType: 'application/json' },
			function (uri) {
				var manifest = readManifest();
				return {
					contents: [
						{ uri: uri, mimeType: 'application/json', text: JSON.stringify(manifest ? manifest.site : {}) }
					]
				};
			}
		);

		// 2. Prompts (WebMCP.dev format)
		window.webmcp.registerPrompt(
			'summarize-page',
			'Generate a comprehensive summary of the current webpage content',
			[],
			function () {
				return {
					messages: [
						{
							role: 'user',
							content: {
								type: 'text',
								text: 'Please summarize the main points and key information from this webpage.'
							}
						}
					]
				};
			}
		);

		window.webmcp.registerPrompt(
			'search-content',
			'Search articles and content matching a specific query topic',
			[
				{ name: 'topic', description: 'Topic or keyword to search for', required: true }
			],
			function (args) {
				return {
					messages: [
						{
							role: 'user',
							content: {
								type: 'text',
								text: 'Search and analyze site content regarding "' + (args && args.topic ? args.topic : '') + '".'
							}
						}
					]
				};
			}
		);
	}

	function tagDevToolsDOM(toolsCount) {
		try {
			if (typeof document !== 'undefined' && document.documentElement) {
				document.documentElement.setAttribute('data-webmcp', 'active');
				document.documentElement.setAttribute('data-webmcp-tools', String(toolsCount));
				document.documentElement.setAttribute('data-mcp', 'enabled');
				document.documentElement.setAttribute('data-mcp-version', '1.0.0');
			}
		} catch (e) {
			// No-op
		}
	}

	function logDevToolsBanner(tools) {
		try {
			if (typeof console !== 'undefined' && console.log && !window.__WPWEBMCP_LOGGED__) {
				window.__WPWEBMCP_LOGGED__ = true;
				var badgeStyle = 'background: #4f46e5; color: #ffffff; padding: 3px 8px; border-radius: 4px; font-weight: bold; font-family: system-ui, sans-serif;';
				var countStyle = 'color: #10b981; font-weight: bold; font-family: system-ui, sans-serif;';
				var codeStyle = 'background: #1e1e2e; color: #a5b4fc; padding: 1px 4px; border-radius: 3px; font-family: monospace;';

				console.log(
					'%cWebMCP Nexus%c Model Context Protocol Active | %c' + tools.length + ' tools registered%c',
					badgeStyle,
					'',
					countStyle,
					''
				);
				console.log(
					'🛠️ Inspect active tools: %cwindow.__MCP__.getTools()%c or %cwindow.webmcp.getTools()%c',
					codeStyle,
					'',
					codeStyle,
					''
				);
			}
		} catch (e) {
			// No-op
		}
	}

	function setupDevToolsMessaging(toolObjects, manifest) {
		if (typeof window === 'undefined' || typeof window.addEventListener !== 'function') {
			return;
		}

		window.addEventListener('message', function (event) {
			if (!event || !event.data || typeof event.data !== 'object') {
				return;
			}
			var type = event.data.type;
			var replyTo = event.source || window;

			if (type === 'MCP_DEVTOOLS_PING' || type === 'WEBMCP_PING') {
				try {
					replyTo.postMessage({
						type: 'MCP_DEVTOOLS_PONG',
						version: '1.0.0',
						protocolVersion: '2024-11-05',
						toolsCount: toolObjects.length,
						mcpEndpoint: (WPWEBMCP.restUrl ? WPWEBMCP.restUrl.replace(/\/call\/?$/, '/mcp') : '/wp-json/wpwebmcp/v1/mcp')
					}, '*');
				} catch (e) {}
			} else if (type === 'MCP_GET_TOOLS' || type === 'WEBMCP_GET_TOOLS' || type === 'MODEL_CONTEXT_GET_TOOLS') {
				try {
					replyTo.postMessage({
						type: 'MCP_TOOLS_RESPONSE',
						tools: toolObjects,
						manifest: manifest
					}, '*');
				} catch (e) {}
			} else if (type === 'MCP_GET_MANIFEST' || type === 'WEBMCP_GET_MANIFEST') {
				try {
					replyTo.postMessage({
						type: 'MCP_MANIFEST_RESPONSE',
						manifest: manifest
					}, '*');
				} catch (e) {}
			} else if (type === 'MCP_CALL_TOOL' || type === 'WEBMCP_CALL_TOOL') {
				var toolName = event.data.name || event.data.tool;
				var params = event.data.params || event.data.arguments || {};
				var callId = event.data.callId || event.data.id || null;

				var target = null;
				for (var i = 0; i < toolObjects.length; i++) {
					if (toolObjects[i].name === toolName) {
						target = toolObjects[i];
						break;
					}
				}

				if (target && typeof target.execute === 'function') {
					target.execute(params).then(function (result) {
						try {
							replyTo.postMessage({
								type: 'MCP_TOOL_RESULT',
								callId: callId,
								name: toolName,
								result: result,
								ok: true
							}, '*');
						} catch (e) {}
					}).catch(function (err) {
						try {
							replyTo.postMessage({
								type: 'MCP_TOOL_RESULT',
								callId: callId,
								name: toolName,
								error: err ? err.message : 'Execution failed',
								ok: false
							}, '*');
						} catch (e) {}
					});
				}
			}
		});
	}

	function registerAll(manifest) {
		if (registered || !manifest || !Array.isArray(manifest.tools)) {
			return;
		}
		registered = true;

		var registries = getRegistries();
		var toolObjects = [];
		var seenNames = {};
		var signal = globalAbortController ? globalAbortController.signal : undefined;

		// 1. Process manifest tools
		for (var i = 0; i < manifest.tools.length; i++) {
			var tool = manifest.tools[i];
			if (!tool || !tool.name || typeof tool.name !== 'string') {
				continue;
			}
			var executeFn = buildExecuteFn(tool);
			var schema = tool.inputSchema || tool.parameters || { type: 'object', properties: {} };
			if (typeof schema !== 'object' || Array.isArray(schema)) {
				schema = { type: 'object', properties: {} };
			}

			var annotations = tool.annotations || {
				readOnlyHint: tool['x-webmcp-type'] !== 'write',
				untrustedContentHint: ['searchSite', 'getPostContent', 'searchProducts', 'searchDocumentation', 'searchVideos', 'searchEvents'].indexOf(tool.name) !== -1
			};
			var exposedTo = tool.exposedTo || ['*'];

			var toolObj = {
				name: tool.name,
				description: tool.description || '',
				inputSchema: schema,
				annotations: annotations,
				exposedTo: exposedTo,
				execute: executeFn
			};

			seenNames[tool.name] = true;
			toolObjects.push(toolObj);

			// Register tool in every active model context registry
			for (var r = 0; r < registries.length; r++) {
				var reg = registries[r];
				if (reg && typeof reg.registerTool === 'function') {
					try {
						reg.registerTool(toolObj, { signal: signal });
					} catch (e) {
						try {
							reg.registerTool(tool.name, toolObj, executeFn);
						} catch (err2) {}
					}
				}
			}
		}

		// 2. Process declarative forms
		var formTools = scanDeclarativeForms();
		for (var f = 0; f < formTools.length; f++) {
			var ft = formTools[f];
			if (!seenNames[ft.name]) {
				seenNames[ft.name] = true;
				ft.execute = buildExecuteFn(ft);
				toolObjects.push(ft);
				for (var r2 = 0; r2 < registries.length; r2++) {
					if (registries[r2] && typeof registries[r2].registerTool === 'function') {
						try {
							registries[r2].registerTool(ft, { signal: signal });
						} catch (e) {}
					}
				}
			}
		}

		// 3. Register standard WebMCP resources and prompts
		registerStandardWebMCPResourcesAndPrompts();

		// 4. Batch provide context if supported
		for (var k = 0; k < registries.length; k++) {
			var rObj = registries[k];
			if (rObj && typeof rObj.provideContext === 'function') {
				try {
					rObj.provideContext({ tools: toolObjects });
				} catch (e) {}
			}
		}

		// 5. Expose global helpers
		window.WPWEBMCP_TOOLS = toolObjects;
		window.WPWEBMCP_MANIFEST = manifest;
		window.WPWEBMCP_CALL = function (name, params) {
			for (var idx = 0; idx < toolObjects.length; idx++) {
				if (toolObjects[idx].name === name) {
					return toolObjects[idx].execute(params || {});
				}
			}
			return Promise.reject(new Error('Tool "' + name + '" not found'));
		};

		// 6. DevTools DOM tagging & messaging
		tagDevToolsDOM(toolObjects.length);
		logDevToolsBanner(toolObjects);
		setupDevToolsMessaging(toolObjects, manifest);

		// 7. Dispatch custom events
		try {
			if (typeof window.dispatchEvent === 'function' && typeof CustomEvent === 'function') {
				var ev = new CustomEvent('webmcp:ready', { detail: { count: toolObjects.length, tools: toolObjects, manifest: manifest } });
				window.dispatchEvent(ev);
				if (typeof document !== 'undefined' && typeof document.dispatchEvent === 'function') {
					document.dispatchEvent(ev);
				}
				window.dispatchEvent(new CustomEvent('modelcontext:ready', { detail: { tools: toolObjects } }));
				window.dispatchEvent(new CustomEvent('mcp:ready', { detail: { count: toolObjects.length } }));
			}
		} catch (e) {}
	}

	function doRegister() {
		var manifest = readManifest();
		if (!manifest) {
			if (document.readyState === 'loading') {
				document.addEventListener('DOMContentLoaded', function () {
					var m = readManifest();
					if (m) { registerAll(m); }
				}, { once: true });
			}
			return;
		}
		registerAll(manifest);
	}

	/* ---------------- entry ---------------- */

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', doRegister, { once: true });
		document.addEventListener('readystatechange', function () {
			if (document.readyState !== 'loading') {
				doRegister();
			}
		}, { once: true });
	} else {
		doRegister();
	}

	// Expose unregister helper for SPA / AbortController
	window.WPWEBMCP_UNREGISTER = function () {
		if (globalAbortController) {
			globalAbortController.abort();
		}
		registered = false;
	};
})();