=== WebMCP Nexus — AI Agent Visibility & AEO Toolkit ===
Contributors: mcpnexus, n4nion
Tags: ai, agent, mcp, aeo, seo
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 1.0.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI agent toolkit for WordPress: MCP manifest, AEO audit, citations, freshness pings, policy governance. 100% self-hosted PHP.

== Why WebMCP Nexus ==

Modern AI agents do not scrape pages the way Googlebot does. They consume structured tool manifests (MCP / JSON-LD), respect per-agent policy rules, and reward sites that publish citation-friendly metadata. Most WordPress plugins ignore this audience. WebMCP Nexus is built for it.

== Features ==

* MCP tool manifest — exposes 50+ built-in tools (getSiteInfo, searchSite, getPostContent, getPostMeta, getSitemap, getFeaturedContent, getRelatedPosts, getSearchSuggestions, navigateTo, filterByTaxonomy, getArchivePosts, getBreakingNews, getArticlesByTopic, getEventsByDate, getRecipe, getProductDetails) over the standard `/wp-json/wpwebmcp/v1/...` namespace.
* AEO audit (0-100 score) — heuristic grading on every post: JSON-LD coverage, FAQ/HowTo schema, Article author + date, freshness metadata, exposure tier, excerpt presence, featured image. Real DB rows, deterministic, runs in <50ms.
* Citation leaderboard — tracks which AI agents are citing your content most, with verified identity attribution and ranking.
* Answer-gap detector — 35 curated questions across 7 verticals scored against your tool inventory. Spots the questions your content does not yet answer.
* Schema-to-tool sync — scans your posts' inline JSON-LD and suggests new MCP tools to register based on `@type` (Product, FAQPage, Recipe, LocalBusiness, HowTo, Event, Course, Article).
* Freshness pings — IndexNow + SSE broadcast on every publish immediately signals AI engines that the content changed.
* Policy builder — first-match-wins rules engine for agents × paths × actions, with a 4-segment preset library (News, WooCommerce, Tech Docs, Local Business).
* Bot analytics — every AI agent visit recorded with user-agent, path, timestamp, classification.
* Citation wrapping — every tool response carries source citation metadata so agents cite correctly.
* Tool Builder — admin UI to create custom MCP tools without writing PHP.
* Forms — self-hosted form builder with WP DB storage and webhook delivery.
* Push server — self-hosted SSE pub/sub for real-time agent notifications.
* Markdown export — auto-generated `/wp-content/uploads/webmcp-nexus-snapshot.md`.
* `llms.txt` — auto-generated `/llms.txt` and `/llms-full.txt` per the llms.txt spec.
* `/well-known/webmcp-nexus.txt` — discovery file for AI engines that probe well-known endpoints.

== AEO Audit ==

The AEO audit grades every post on a 0-100 scale. It checks seven weighted contributions: JSON-LD presence (20 pts), FAQ/HowTo schema presence (20 pts), Article author + date (10 pts), freshness metadata (10 pts), explicit exposure tier (15 pts), excerpt presence (15 pts), featured image (10 pts). Every score is a real DB query against wp_posts, wp_postmeta, and taxonomy tables — no LLM, no external API. The audit also produces a leaderboard across the entire site and a "missing tools" feed listing which tools the gap detector and schema-to-tool sync found are absent.

== Policy-first agent governance ==

A2a policy rules let you say "block GPTBot from /checkout/* but allow Claude from anywhere" or "rate-limit Perplexity to 30 RPM on /search/*". Rules are first-match-wins. The preset library ships with sensible defaults for News publishers, WooCommerce stores, Tech Documentation, and Local Businesses.

== Tool Packs (Recipes example bundled) ==

WebMCP Nexus ships a Tool Packs SDK in the `wp-content/wp-webmcp-packs/<slug>/` convention. The plugin bundles an official Recipes pack (CPT + cuisine/dietary taxonomies + 6 example recipes + 7 search/get tools). Developers and site owners can drop custom tool pack folders into the packs directory with a `wp-webmcp-pack.json` manifest.

== Privacy ==

WebMCP Nexus does not phone home. No telemetry. No external API calls. Every feature runs in PHP on your own WordPress install.

== Installation ==

1. Upload the plugin zip via Plugins -> Add New -> Upload Plugin.
2. Activate the plugin.
3. (Optional) Visit Settings -> WebMCP Nexus to configure your policy preset and freshness pings.
4. The MCP manifest is automatically available at `/wp-json/wpwebmcp/v1/manifest`.

== Frequently Asked Questions ==

= Does WebMCP Nexus send any data to external servers? =

No. Every feature runs in PHP on your WordPress install. The plugin has no API keys, no cloud calls, and no telemetry.

= Will this slow down my site? =

No. The MCP manifest is generated on demand by REST requests. Schema.org builders run only on content view. The AEO audit is a single indexed DB query with a 5-minute transient cache.

= Does this work with WooCommerce? =

Yes. There is a dedicated Woo integration that exposes product/cart/checkout/order tools.

= Does this work with ACF? =

Yes. ACF fields are auto-exposed as tool input schema.

= Is this compatible with RankMath / Yoast / AIOSEO? =

Yes. WebMCP Nexus does not duplicate SEO features. It adds an AEO / agent layer on top of whatever SEO plugin you use.

= Does this work on multisite? =

Yes. The plugin is network-active compatible. Each site can have its own policy preset.

= What happens on uninstall? =

The uninstall.php removes all 3 plugin tables and plugin-specific options. Post content, users, and other plugin data are untouched.

== Screenshots ==

1. Dashboard with AEO audit leaderboard.
2. Policy builder visual editor.
3. AEO audit per-post sidebar meta box.
4. Answer-gap detector with 35-question bank.
5. Citation leaderboard with AI agent rankings.
6. Tool Builder admin UI.

== Changelog ==

= 1.0.0 =
* Initial release on WordPress.org.
* 50+ built-in MCP tools.
* AEO audit, citation leaderboard, answer-gap detector, schema-to-tool sync.
* Policy builder with 4-segment preset library.
* Bot analytics, freshness pings, push server, llms.txt, markdown export.
* Tool Builder admin UI, Forms module, Woo + ACF integrations.
* Official Recipes Tool Pack bundled.

== Upgrade Notice ==

= 1.0.0 =
First public release.
