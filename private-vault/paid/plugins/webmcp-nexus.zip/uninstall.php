<?php
/**
 * Uninstall handler for WebMCP Nexus.
 *
 * Removes the 3 plugin tables and all plugin-specific options. Runs only when
 * the user clicks "Delete" on the plugin (not on simple deactivation). Static
 * class names preserved to match the rest of the free plugin's PHP class
 * hierarchy (no class renames in the free build).
 *
 * @package WebMCP_Nexus
 */

// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.SchemaChange,WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- uninstall.php is the WP-standard schema-drop handler; $wpwebmcp_table/$wpwebmcp_options/$wpwebmcp_crons are short-lived local variables in a one-shot script context
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

$wpwebmcp_tables = array(
	$wpdb->prefix . 'wpwebmcp_tools',
	$wpdb->prefix . 'wpwebmcp_log',
	$wpdb->prefix . 'wpwebmcp_bot_log',
	$wpdb->prefix . 'wpwebmcp_write_log',
	$wpdb->prefix . 'webmcp_tools',
	$wpdb->prefix . 'webmcp_log',
	$wpdb->prefix . 'webmcp_write_log',
);

foreach ( $wpwebmcp_tables as $wpwebmcp_table ) {
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Predefined array of plugin table names cannot use query placeholders.
	$wpdb->query( "DROP TABLE IF EXISTS {$wpwebmcp_table}" );
}

// Plugin-specific options.
$wpwebmcp_options = array(
	'wpwebmcp_db_version',
	'wpwebmcp_default_options',
	'wpwebmcp_settings',
	'wpwebmcp_policies',
	'wpwebmcp_access_control',
	'wpwebmcp_exclusions',
	'wpwebmcp_freshness_enabled',
	'wpwebmcp_freshness_endpoint',
	'wpwebmcp_push_enabled',
	'wpwebmcp_push_max_subscribers',
	'wpwebmcp_push_connection_ttl',
	'wpwebmcp_push_heartbeat_seconds',
	'wpwebmcp_paused_agents',
	'wpwebmcp_sandbox_mode',
	'wpwebmcp_rate_limit_rpm',
	'wpwebmcp_log_retention_days',
	'wpwebmcp_cron_version',
	'wpwebmcp_alerts_state',
	'wpwebmcp_health_state',
	'wpwebmcp_installed_packs',
);

foreach ( $wpwebmcp_options as $wpwebmcp_option ) {
	// phpcs:ignore WordPress.OptionsUpdate.NewOption, WordPress.DB.DirectDatabaseQuery
	delete_option( $wpwebmcp_option );
	// phpcs:ignore WordPress.OptionsUpdate.NewOption, WordPress.DB.DirectDatabaseQuery
	delete_site_option( $wpwebmcp_option );
}

// Clean cron events.
$wpwebmcp_crons = array(
	'wpwebmcp_freshness_ping',
	'wpwebmcp_bot_analytics_prune',
	'wpwebmcp_aggregator_sync',
	'wpwebmcp_write_log_prune',
	'wpwebmcp_health_check',
);
foreach ( $wpwebmcp_crons as $wpwebmcp_cron ) {
	$wpwebmcp_timestamp = wp_next_scheduled( $wpwebmcp_cron );
	if ( $wpwebmcp_timestamp ) {
		wp_unschedule_event( $wpwebmcp_timestamp, $wpwebmcp_cron );
	}
	wp_clear_scheduled_hook( $wpwebmcp_cron );
}
