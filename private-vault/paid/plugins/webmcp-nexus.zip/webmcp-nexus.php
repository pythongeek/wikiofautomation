<?php
/**
 * Plugin Name:       WebMCP Nexus — AI Agent Visibility & AEO Toolkit
 * Plugin URI:        https://webmcp-nexus.com
 * Description:       Make your WordPress site fully discoverable by AI agents (ChatGPT, Claude, Gemini, Perplexity, Copilot, Cursor). Provides a complete MCP tool manifest, AEO audit, citation tracking, schema-to-tool sync, answer-gap detector, freshness pings, and policy-first agent governance. 100% self-hosted in PHP — no external service required.
 * Version:           1.1.3
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Tested up to:      7.1
 * Author:            WebMCP Nexus
 * Author URI:        https://webmcp-nexus.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       webmcp-nexus
 * Domain Path:       /languages
 * Network:           true
 *
 * WebMCP Nexus is the free, self-hosted AEO toolkit. Every feature in this plugin
 * runs on your own WordPress install — no API keys, no cloud calls, no telemetry.
 *
 * @package WebMCP_Nexus
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WEBMCP_NEXUS_VERSION',  '1.1.3' );
define( 'WEBMCP_NEXUS_DB_VERSION', 3 );
define( 'WEBMCP_NEXUS_PATH',      plugin_dir_path( __FILE__ ) );
define( 'WEBMCP_NEXUS_URL',       plugin_dir_url( __FILE__ ) );
define( 'WEBMCP_NEXUS_BASENAME', plugin_basename( __FILE__ ) );

define( 'WEBMCP_NEXUS_ADMIN',    plugin_dir_path( __FILE__ ) . 'admin/' );

require_once WEBMCP_NEXUS_PATH . 'includes/class-wp-webmcp-loader.php';
require_once WEBMCP_NEXUS_PATH . 'includes/class-wp-webmcp-activator.php';
require_once WEBMCP_NEXUS_PATH . 'includes/class-wp-webmcp-deactivator.php';
require_once WEBMCP_NEXUS_PATH . 'includes/class-wp-webmcp-i18n.php';

register_activation_hook(
	__FILE__,
	static function () {
		if ( ! class_exists( 'WP_WebMCP_Activator' ) ) {
			require_once WEBMCP_NEXUS_PATH . 'includes/class-wp-webmcp-activator.php';
		}
		WP_WebMCP_Activator::activate();
	}
);

register_deactivation_hook(
	__FILE__,
	static function () {
		if ( ! class_exists( 'WP_WebMCP_Deactivator' ) ) {
			require_once WEBMCP_NEXUS_PATH . 'includes/class-wp-webmcp-deactivator.php';
		}
		WP_WebMCP_Deactivator::deactivate();
	}
);

if ( file_exists( WEBMCP_NEXUS_PATH . 'includes/class-wp-webmcp-loader.php' ) ) {
	require_once WEBMCP_NEXUS_PATH . 'includes/class-wp-webmcp-loader.php';
}

if ( file_exists( WEBMCP_NEXUS_PATH . 'includes/class-wp-webmcp.php' ) ) {
	require_once WEBMCP_NEXUS_PATH . 'includes/class-wp-webmcp.php';
}

add_action(
	'plugins_loaded',
	static function () {
		if ( class_exists( 'WP_WebMCP' ) ) {
			WP_WebMCP::instance()->run();
		}
	}
);
